package com.ganageo.app.ui.tools

import android.content.Context
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFontFamilyResolver
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import com.ganageo.app.model.ToolId
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.exp
import kotlin.math.sin

// ---------------------------------------------------------------------------
// Presentaciones animadas de las herramientas.
//
// Cada escena se dibuja con figuras simples (sin imágenes): pesa casi nada y
// se ve nítida en cualquier pantalla. Se mueve solo cuando:
//   · la tarjeta está en pantalla (la lista no dibuja las de afuera),
//   · la lista NO se está deslizando,
//   · el usuario tiene las animaciones activadas en Perfil,
//   · el celular no está en ahorro de batería ni con animaciones apagadas.
// Si no, se queda quieta en su cuadro final (que ya explica la herramienta).
// ---------------------------------------------------------------------------

/** Colores de la categoría para pintar la escena. */
internal data class ScenePalette(val container: Color, val badge: Color, val accent: Color)

/** Una escena se dibuja en un lienzo fijo de 170 x 100 unidades. p = avance de 0 a 1. */
internal class ToolScene(val draw: DrawScope.(p: Float, pal: ScenePalette, text: SceneText) -> Unit)

/** ¿Pueden moverse ahora las presentaciones? (lo decide la lista de herramientas). */
internal val LocalToolMotion = staticCompositionLocalOf<State<Boolean>> { NoMotion }

private object NoMotion : State<Boolean> {
    override val value: Boolean = false
}

/** Para miniaturas: siempre quietas. */
internal val StaticToolMotion: State<Boolean> = NoMotion

internal fun toolSceneFor(tool: ToolId): ToolScene? = ScenesByTool[tool]

/** Animaciones del sistema apagadas o ahorro de batería = escenas quietas. */
@Composable
internal fun rememberSystemMotionAllowed(): Boolean {
    val context = LocalContext.current
    return remember(context) { systemMotionAllowed(context) }
}

private fun systemMotionAllowed(context: Context): Boolean {
    val scale = runCatching {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
    }.getOrDefault(1f)
    val powerSave = runCatching {
        context.getSystemService(PowerManager::class.java)?.isPowerSaveMode == true
    }.getOrDefault(false)
    return scale > 0f && !powerSave
}

private const val SW = 170f
private const val SH = 100f

/** Cuadro de descanso: todo visible (el resultado de la herramienta). */
private const val REST_FRAME = 0.86f
private const val MOTION_START_DELAY_MS = 260L
private const val MIN_FRAME_NANOS = 30_000_000L

@Composable
internal fun AnimatedToolScene(
    tool: ToolId,
    scene: ToolScene,
    palette: ScenePalette,
    contentDescription: String?,
    modifier: Modifier
) {
    val motion = LocalToolMotion.current
    val progress = remember(tool) { mutableFloatStateOf(REST_FRAME) }
    // Cada herramienta con su propio ritmo para que no se muevan todas igual.
    val periodMs = remember(tool) { 3_400f + (tool.ordinal % 5) * 170f }

    LaunchedEffect(tool, motion) {
        snapshotFlow { motion.value }.collectLatest { moving ->
            if (!moving) return@collectLatest // se congela en el cuadro actual
            // Espera a que la lista quede quieta de verdad (evita trabas al soltar el dedo).
            delay(MOTION_START_DELAY_MS)
            val startProgress = progress.floatValue
            val startNanos = withFrameNanos { it }
            var lastDrawNanos = startNanos
            while (true) {
                withFrameNanos { now ->
                    // 30 cuadros por segundo: se ve fluido y cuesta la mitad.
                    if (now - lastDrawNanos >= MIN_FRAME_NANOS) {
                        lastDrawNanos = now
                        val elapsedMs = (now - startNanos) / 1_000_000f
                        progress.floatValue = (startProgress + elapsedMs / periodMs) % 1f
                    }
                }
            }
        }
    }

    // Un solo juego de textos medidos para todas las tarjetas (antes: uno por tarjeta).
    val fontResolver = LocalFontFamilyResolver.current
    val sceneText = remember(fontResolver) { sharedSceneText(fontResolver) }
    val semanticsModifier = if (contentDescription != null) {
        Modifier.semantics { this.contentDescription = contentDescription }
    } else {
        Modifier
    }

    Spacer(
        modifier = modifier
            .then(semanticsModifier)
            .drawWithCache {
                // Fondo: se arma una sola vez por tamaño (no en cada cuadro).
                val sx = size.width / SW
                val sy = size.height / SH
                val fit = min(sx, sy)
                val offX = (size.width - SW * fit) / 2f
                val offY = (size.height - SH * fit) / 2f
                val background = Brush.verticalGradient(
                    listOf(palette.badge, palette.container),
                    startY = 0f,
                    endY = size.height
                )
                val glow = Brush.radialGradient(
                    listOf(palette.accent.copy(alpha = 0.18f), palette.accent.copy(alpha = 0f)),
                    center = Offset(size.width * 0.5f, size.height * 0.1f),
                    radius = size.width * 0.6f
                )
                val gridColor = Color.White.copy(alpha = 0.07f)
                onDrawBehind {
                    drawRect(background)
                    var gx = 10f * sx
                    while (gx < size.width) {
                        drawLine(gridColor, Offset(gx, 0f), Offset(gx, size.height), strokeWidth = 0.5f * sx)
                        gx += 14f * sx
                    }
                    var gy = 8f * sy
                    while (gy < size.height) {
                        drawLine(gridColor, Offset(0f, gy), Offset(size.width, gy), strokeWidth = 0.5f * sy)
                        gy += 14f * sy
                    }
                    drawRect(glow)
                    val p = progress.floatValue // solo esto cambia: redibuja sin recomponer
                    withTransform({
                        translate(offX, offY)
                        scale(fit, fit, pivot = Offset.Zero)
                    }) {
                        scene.draw(this, p, palette, sceneText)
                    }
                }
            }
    )
}

// ---------------------------------------------------------------------------
// Textos de las escenas: se miden una sola vez, en unidades de la escena.
// ---------------------------------------------------------------------------
/** display: texto real cuando la clave es otra (ej. "bit1" se ve como "1" en otro tamaño). */
private data class LabelSpec(val size: Float, val bold: Boolean = true, val display: String? = null)

private val LabelSpecs = mapOf(
    "PDF" to LabelSpec(6.4f), "DOCX" to LabelSpec(6.4f), "XLSX" to LabelSpec(6.4f), "JPG" to LabelSpec(6.4f),
    "B" to LabelSpec(6f), "I" to LabelSpec(6f), "U" to LabelSpec(6f),
    "GANA GEO" to LabelSpec(9.5f), "1 / 2" to LabelSpec(4.8f),
    "1" to LabelSpec(15f), "2" to LabelSpec(15f), "3" to LabelSpec(15f),
    "Unido" to LabelSpec(6f), "Firma" to LabelSpec(5.2f, bold = false),
    // Imágenes
    "ZIP" to LabelSpec(6.4f), "PNG" to LabelSpec(6.4f), "WEBP" to LabelSpec(6.4f),
    "4.2 MB" to LabelSpec(6f), "320 KB" to LabelSpec(6f), "-92%" to LabelSpec(5.4f),
    "1920 × 1080" to LabelSpec(5.4f), "800 × 450" to LabelSpec(5.4f),
    "© Tu marca" to LabelSpec(7f), "Tu marca" to LabelSpec(5f),
    // Trabajo y empleo
    "Normal" to LabelSpec(5.4f, bold = false), "Extra" to LabelSpec(5.4f, bold = false),
    "Total" to LabelSpec(5.6f, bold = false), "8 h" to LabelSpec(6.4f), "+2 h" to LabelSpec(6.4f),
    "S/ 96" to LabelSpec(10f), "Cotización" to LabelSpec(5.6f), "IGV 18%" to LabelSpec(5.2f),
    "S/ 118" to LabelSpec(7.4f), "S/ 2,450" to LabelSpec(6.2f), "S/ 1,280" to LabelSpec(6.2f),
    "S/ 1,170" to LabelSpec(7.6f), "!" to LabelSpec(8f), "S/ 100" to LabelSpec(8f), "30%" to LabelSpec(9f),
    "0/4" to LabelSpec(8f), "1/4" to LabelSpec(8f), "2/4" to LabelSpec(8f), "3/4" to LabelSpec(8f), "4/4" to LabelSpec(8f),
    // Estudio y escritura
    "bit0" to LabelSpec(9f, display = "0"), "bit1" to LabelSpec(9f, display = "1"),
    "BIN" to LabelSpec(5f), "DEC" to LabelSpec(5f), "HEX" to LabelSpec(5f),
    "10" to LabelSpec(12f), "hexA" to LabelSpec(12f, display = "A"),
    "APA" to LabelSpec(5.4f), "MLA" to LabelSpec(5.4f), "IEEE" to LabelSpec(5.4f),
    "Autor" to LabelSpec(5f, bold = false), "Título" to LabelSpec(5f, bold = false), "Año" to LabelSpec(5f, bold = false),
    "quotes" to LabelSpec(12f, display = "“ ”"),
    "optA" to LabelSpec(5.4f, display = "A"), "optB" to LabelSpec(5.4f, display = "B"),
    "optC" to LabelSpec(5.4f, display = "C"), "optD" to LabelSpec(5.4f, display = "D"),
    "18/20" to LabelSpec(8.4f), "25 min" to LabelSpec(7.4f),
    "L" to LabelSpec(5f), "M" to LabelSpec(5f), "J" to LabelSpec(5f), "V" to LabelSpec(5f),
    "+12%" to LabelSpec(6f), "?" to LabelSpec(22f), "NOV" to LabelSpec(6f),
    "Aa" to LabelSpec(11f), "AA" to LabelSpec(11f),
    // Números y matemática
    "2+3×4" to LabelSpec(6.5f), "= 14" to LabelSpec(8.5f), "sin x" to LabelSpec(6f, bold = false),
    "100 cm" to LabelSpec(6.4f), "1 m" to LabelSpec(7.4f), "0 °C" to LabelSpec(6.4f), "32 °F" to LabelSpec(6.4f),
    "S/ 80" to LabelSpec(9f), "S/ 60" to LabelSpec(9f), "-25%" to LabelSpec(6.4f),
    "12" to LabelSpec(5.4f), "15" to LabelSpec(5.4f), "09" to LabelSpec(5.4f), "17" to LabelSpec(5.4f),
    "Prom. 13" to LabelSpec(6.2f), "Aprobado" to LabelSpec(6.4f),
    "6" to LabelSpec(6f), "8" to LabelSpec(6f), "A = 24" to LabelSpec(6.4f), "r" to LabelSpec(6f),
    // Ciencias y análisis
    "m2" to LabelSpec(8f, display = "2"), "m1" to LabelSpec(8f, display = "1"),
    "m0" to LabelSpec(8f, display = "0"), "m3" to LabelSpec(8f, display = "3"),
    "det = 6" to LabelSpec(6.2f), "integral" to LabelSpec(16f, display = "∫"),
    "2x + 4 = 10" to LabelSpec(7f), "2x = 6" to LabelSpec(7f), "x = 3" to LabelSpec(9f),
    "x" to LabelSpec(5.4f), "y" to LabelSpec(5.4f), "Media 14" to LabelSpec(6f),
    "F = m·a" to LabelSpec(7f), "Fe" to LabelSpec(14f), "26" to LabelSpec(5f), "55.85" to LabelSpec(5f),
    "O" to LabelSpec(8f), "H" to LabelSpec(6f), "18 g/mol" to LabelSpec(6.4f),
    // Visores, rápidas y juego
    "1 / 12" to LabelSpec(5.4f), "3 / 12" to LabelSpec(5.4f), "PPTX" to LabelSpec(6.4f),
    "colA" to LabelSpec(4.6f, display = "A"), "colB" to LabelSpec(4.6f, display = "B"),
    "colC" to LabelSpec(4.6f, display = "C"), "colD" to LabelSpec(4.6f, display = "D"),
    "row1" to LabelSpec(4.6f, display = "1"), "row2" to LabelSpec(4.6f, display = "2"),
    "row3" to LabelSpec(4.6f, display = "3"), "row4" to LabelSpec(4.6f, display = "4"),
    "Σ 2,450" to LabelSpec(5.4f),
    "12 palabras" to LabelSpec(6f), "64 palabras" to LabelSpec(6f), "128 palabras" to LabelSpec(6f),
    "1 min" to LabelSpec(6.4f), "Estudio" to LabelSpec(4.8f, bold = false), "Descanso" to LabelSpec(4.8f, bold = false),
    "25:00" to LabelSpec(8f), "5:00" to LabelSpec(8f)
)

private val SceneUnitDensity = Density(1f, 1f)

internal class SceneText(private val measurer: TextMeasurer) {
    private val cache = HashMap<String, TextLayoutResult>()

    operator fun get(text: String): TextLayoutResult = cache.getOrPut(text) {
        val spec = LabelSpecs[text] ?: LabelSpec(6f)
        measurer.measure(
            text = spec.display ?: text,
            style = TextStyle(
                fontSize = spec.size.sp,
                fontWeight = if (spec.bold) FontWeight.Bold else FontWeight.Medium
            ),
            softWrap = false,
            maxLines = 1,
            density = SceneUnitDensity
        )
    }
}

// Los textos se miden una sola vez para toda la app (solo se usa en el hilo de pantalla).
private var sharedTextResolver: FontFamily.Resolver? = null
private var sharedText: SceneText? = null

private fun sharedSceneText(resolver: FontFamily.Resolver): SceneText {
    val current = sharedText
    if (current != null && sharedTextResolver === resolver) return current
    val created = SceneText(
        TextMeasurer(
            defaultFontFamilyResolver = resolver,
            defaultDensity = SceneUnitDensity,
            defaultLayoutDirection = LayoutDirection.Ltr,
            cacheSize = 0
        )
    )
    sharedTextResolver = resolver
    sharedText = created
    return created
}

// ---------------------------------------------------------------------------
// Utilidades de tiempo y dibujo
// ---------------------------------------------------------------------------
private fun clamp01(v: Float) = v.coerceIn(0f, 1f)
private fun seg(p: Float, a: Float, b: Float) = clamp01((p - a) / (b - a))
private fun eOut(t: Float): Float { val u = 1f - t; return 1f - u * u * u }
private fun eIO(t: Float): Float = if (t < 0.5f) 4f * t * t * t else { val u = -2f * t + 2f; 1f - u * u * u / 2f }
private fun back(t: Float): Float { val c1 = 1.70158f; val c3 = c1 + 1f; val u = t - 1f; return 1f + c3 * u * u * u + c1 * u * u }
private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
/** Al final de cada vuelta todo se desvanece suave para empezar otra vez. */
private fun fadeLoop(p: Float) = 1f - seg(p, 0.93f, 1f)
/** Al inicio de cada vuelta aparece suave (evita saltos). */
private fun fadeIn(p: Float) = seg(p, 0f, 0.05f)

private val Paper = Color(0xFFF4F6F8)
private val PaperLine = Color(0xFFC3CAD3)
private val PdfRed = Color(0xFFE5484D)
private val OkGreen = Color(0xFF3DDC84)
private val PhoneDark = Color(0xFF1C2430)
private val Ink = Color(0xFF2B3A55)
private val Sun = Color(0xFFFFD54F)

private fun DrawScope.rr(x: Float, y: Float, w: Float, h: Float, r: Float, color: Color, alpha: Float = 1f) {
    if (alpha <= 0f || w <= 0f || h <= 0f) return
    val rad = min(r, min(w, h) / 2f)
    drawRoundRect(color, Offset(x, y), Size(w, h), CornerRadius(rad, rad), alpha = clamp01(alpha))
}

private fun DrawScope.rrStroke(x: Float, y: Float, w: Float, h: Float, r: Float, color: Color, lw: Float, alpha: Float = 1f) {
    if (alpha <= 0f) return
    drawRoundRect(color, Offset(x, y), Size(w, h), CornerRadius(r, r), style = Stroke(lw), alpha = clamp01(alpha))
}

private fun DrawScope.ln(x1: Float, y1: Float, x2: Float, y2: Float, color: Color, lw: Float, alpha: Float = 1f) {
    if (alpha <= 0f) return
    drawLine(color, Offset(x1, y1), Offset(x2, y2), strokeWidth = lw, cap = StrokeCap.Round, alpha = clamp01(alpha))
}

private fun DrawScope.dot(x: Float, y: Float, r: Float, color: Color, alpha: Float = 1f) {
    if (alpha <= 0f || r <= 0f) return
    drawCircle(color, r, Offset(x, y), alpha = clamp01(alpha))
}

private fun DrawScope.label(t: SceneText, text: String, cx: Float, cy: Float, color: Color, alpha: Float = 1f) {
    if (alpha <= 0f) return
    val layout = t[text]
    drawText(
        layout,
        color = color,
        topLeft = Offset(cx - layout.size.width / 2f, cy - layout.size.height / 2f),
        alpha = clamp01(alpha)
    )
}

/** Texto alineado a la izquierda (x = inicio). */
private fun DrawScope.labelStart(t: SceneText, text: String, x: Float, cy: Float, color: Color, alpha: Float = 1f) {
    if (alpha <= 0f) return
    val layout = t[text]
    drawText(layout, color = color, topLeft = Offset(x, cy - layout.size.height / 2f), alpha = clamp01(alpha))
}

/** Texto alineado a la derecha (x = final). */
private fun DrawScope.labelEnd(t: SceneText, text: String, x: Float, cy: Float, color: Color, alpha: Float = 1f) {
    if (alpha <= 0f) return
    val layout = t[text]
    drawText(layout, color = color, topLeft = Offset(x - layout.size.width, cy - layout.size.height / 2f), alpha = clamp01(alpha))
}

private fun DrawScope.page(x: Float, y: Float, w: Float, h: Float, alpha: Float = 1f, lines: Int = 4) {
    if (alpha <= 0f) return
    rr(x + 1.2f, y + 1.6f, w, h, 3f, Color.Black, 0.22f * alpha)
    rr(x, y, w, h, 3f, Paper, alpha)
    for (i in 0 until lines) {
        val ly = y + h * 0.30f + i * (h * 0.15f)
        if (ly > y + h - 4f) break
        ln(x + w * 0.14f, ly, x + w * (if (i % 2 == 1) 0.70f else 0.86f), ly, PaperLine, 1.6f, alpha)
    }
}

private fun DrawScope.badge(t: SceneText, text: String, x: Float, y: Float, color: Color, alpha: Float = 1f, scale: Float = 1f) {
    if (alpha <= 0f || scale <= 0f) return
    withTransform({
        translate(x, y)
        scale(scale, scale, pivot = Offset.Zero)
    }) {
        rr(-11f, -5.5f, 22f, 11f, 3f, color, alpha)
        label(t, text, 0f, 0.4f, Color.White, alpha)
    }
}

private fun DrawScope.arrow(x1: Float, x2: Float, y: Float, color: Color, t: Float, alpha: Float = 1f) {
    if (t <= 0f || alpha <= 0f) return
    val xe = lerp(x1, x2, t)
    ln(x1, y, xe, y, color, 2.2f, alpha)
    if (t > 0.6f) {
        val a = alpha * seg(t, 0.6f, 1f)
        ln(xe, y, xe - 4.5f, y - 3.5f, color, 2.2f, a)
        ln(xe, y, xe - 4.5f, y + 3.5f, color, 2.2f, a)
    }
}

private fun DrawScope.check(x: Float, y: Float, s: Float, color: Color, t: Float, alpha: Float = 1f) {
    if (t <= 0f || alpha <= 0f) return
    val t1 = clamp01(t * 2f)
    val t2 = clamp01(t * 2f - 1f)
    val p1x = x - s * 0.5f; val p1y = y
    val p2x = x - s * 0.15f; val p2y = y + s * 0.35f
    val p3x = x + s * 0.55f; val p3y = y - s * 0.4f
    ln(p1x, p1y, lerp(p1x, p2x, t1), lerp(p1y, p2y, t1), color, s * 0.28f, alpha)
    if (t2 > 0f) ln(p2x, p2y, lerp(p2x, p3x, t2), lerp(p2y, p3y, t2), color, s * 0.28f, alpha)
}

private fun DrawScope.photo(x: Float, y: Float, w: Float, h: Float, alpha: Float, sky: Color, hill: Color) {
    if (alpha <= 0f) return
    rr(x, y, w, h, 2.5f, Color.White, alpha)
    val ix = x + 1.6f; val iy = y + 1.6f; val iw = w - 3.2f; val ih = h - 3.2f
    rr(ix, iy, iw, ih, 1.6f, sky, alpha)
    clipRect(ix, iy, ix + iw, iy + ih) {
        val mountains = Path().apply {
            moveTo(ix, iy + ih)
            lineTo(ix + iw * 0.35f, iy + ih * 0.45f)
            lineTo(ix + iw * 0.60f, iy + ih * 0.80f)
            lineTo(ix + iw * 0.78f, iy + ih * 0.58f)
            lineTo(ix + iw, iy + ih)
            close()
        }
        drawPath(mountains, hill, alpha = clamp01(alpha))
    }
    dot(ix + iw * 0.78f, iy + ih * 0.28f, min(iw, ih) * 0.13f, Sun, alpha)
}

private val DashEffect = PathEffect.dashPathEffect(floatArrayOf(3f, 2f))

private fun DrawScope.dashedRect(x: Float, y: Float, w: Float, h: Float, color: Color, lw: Float, alpha: Float) {
    if (alpha <= 0f) return
    drawRect(color, Offset(x, y), Size(w, h), alpha = clamp01(alpha), style = Stroke(lw, pathEffect = DashEffect))
}

/** Etiqueta redonda (tamaño, porcentaje). */
private fun DrawScope.pill(
    t: SceneText, text: String, x: Float, y: Float, w: Float,
    color: Color, textColor: Color, alpha: Float = 1f, scale: Float = 1f
) {
    if (alpha <= 0f || scale <= 0f) return
    withTransform({
        translate(x, y)
        scale(scale, scale, pivot = Offset.Zero)
    }) {
        rr(-w / 2f, -5f, w, 10f, 5f, color, alpha)
        label(t, text, 0f, 0.4f, textColor, alpha)
    }
}

// ---------------------------------------------------------------------------
// Datos fijos de las escenas (se crean una sola vez)
// ---------------------------------------------------------------------------
private val EditorLineWidths = floatArrayOf(48f, 40f, 52f, 30f, 44f)
private val OrganizerSlots = floatArrayOf(22f, 68f, 114f)
private val OrganizerStart = intArrayOf(3, 1, 2)
private val OrganizerLabels = arrayOf("1", "2", "3")

private class PhotoSpec(val x: Float, val y: Float, val sky: Color, val hill: Color)

private val ImagesToPdfStarts = arrayOf(
    PhotoSpec(12f, 12f, Color(0xFF6FB7FF), Color(0xFF3DDC84)),
    PhotoSpec(30f, 38f, Color(0xFFFFB35A), Color(0xFFE5484D)),
    PhotoSpec(12f, 64f, Color(0xFFC997FF), Color(0xFF6DE1D2))
)

private val PdfToImagesColors = arrayOf(
    Color(0xFF6FB7FF) to Color(0xFF3DDC84),
    Color(0xFFFFB35A) to Color(0xFFE5484D),
    Color(0xFFC997FF) to Color(0xFF6DE1D2),
    Color(0xFF74F1FF) to Color(0xFF22A06B)
)

/** Firma tipo cursiva, en puntos (x, y) seguidos. */
private val SignaturePoints: FloatArray by lazy {
    val curves = arrayOf(
        floatArrayOf(54f, 70f, 58f, 52f, 64f, 52f, 63f, 64f),
        floatArrayOf(63f, 64f, 62f, 74f, 70f, 60f, 74f, 62f),
        floatArrayOf(74f, 62f, 78f, 64f, 78f, 70f, 82f, 66f),
        floatArrayOf(82f, 66f, 88f, 56f, 92f, 58f, 90f, 68f),
        floatArrayOf(90f, 68f, 89f, 74f, 98f, 62f, 102f, 60f),
        floatArrayOf(102f, 60f, 108f, 58f, 106f, 70f, 112f, 66f),
        floatArrayOf(112f, 66f, 116f, 62f, 118f, 58f, 120f, 58f)
    )
    val steps = 14
    val out = FloatArray(curves.size * (steps + 1) * 2)
    var k = 0
    for (c in curves) {
        for (i in 0..steps) {
            val t = i / steps.toFloat()
            val mt = 1f - t
            val a = mt * mt * mt; val b = 3f * mt * mt * t; val cc = 3f * mt * t * t; val d = t * t * t
            out[k++] = a * c[0] + b * c[2] + cc * c[4] + d * c[6]
            out[k++] = a * c[1] + b * c[3] + cc * c[5] + d * c[7]
        }
    }
    out
}

private const val RAD_TO_DEG = 57.29578f

private val SkyBlue = Color(0xFF6FB7FF)
private val HillGreen = Color(0xFF3DDC84)
private val SkyOrange = Color(0xFFFFB35A)
private val HillRed = Color(0xFFE5484D)
private val SkyPurple = Color(0xFFC997FF)
private val HillTeal = Color(0xFF6DE1D2)
private val ImageBrown = Color(0xFFC97A1E)
private val WorkDark = Color(0xFF0E2417)
private val WorkHeader = Color(0xFF1F5135)
private val WorkMuted = Color(0xFFA8C4B2)
private val SoftRed = Color(0xFFFF6B6B)
private val Gray = Color(0xFF9AA6B4)

private val IncomeBars = floatArrayOf(22f, 30f, 18f, 34f, 26f)
private val ExpenseBars = floatArrayOf(12f, 16f, 20f, 10f, 14f)
private val InventoryBoxes = arrayOf(
    floatArrayOf(16f, 44f, 22f, 18f), floatArrayOf(40f, 44f, 18f, 14f), floatArrayOf(60f, 44f, 24f, 20f),
    floatArrayOf(18f, 80f, 20f, 16f), floatArrayOf(42f, 80f, 26f, 22f), floatArrayOf(70f, 80f, 18f, 14f)
)
private val InventoryStock = arrayOf(0.9f to 0.62f, 0.7f to 0.48f, 0.6f to 0.14f)
private val ChecklistLengths = floatArrayOf(40f, 32f, 44f, 28f)
private val ChecklistLabels = arrayOf("0/4", "1/4", "2/4", "3/4", "4/4")
private val CvSkills = floatArrayOf(0.9f, 0.7f, 0.8f)

private val StudyDark = Color(0xFF1E0F33)
private val StudyMuted = Color(0xFFBFA8DE)
private val StudyInk = Color(0xFF2E184B)
private val Teal = Color(0xFF6DE1D2)
private val Coin = Color(0xFFE7B84B)
private val NumberBits = intArrayOf(1, 0, 1, 0)
private val CitationChips = arrayOf("Autor", "Título", "Año")
private val CitationLengths = floatArrayOf(44f, 60f, 24f)
private val CitationTabs = arrayOf("APA", "MLA", "IEEE")
private val ExamOptions = arrayOf("optA", "optB", "optC", "optD")
private val WeekDays = arrayOf("L", "M", "M", "J", "V")
private val PlannerFill = arrayOf(
    intArrayOf(0, 0), intArrayOf(1, 1), intArrayOf(2, 0), intArrayOf(3, 2),
    intArrayOf(4, 1), intArrayOf(0, 2), intArrayOf(2, 2), intArrayOf(1, 0)
)
private val CoinStacks = intArrayOf(3, 5, 8)
private val AgendaDots = arrayOf(
    intArrayOf(1, 0, 0), intArrayOf(3, 1, 1), intArrayOf(0, 2, 2), intArrayOf(4, 2, 0), intArrayOf(2, 3, 1)
)
private val TextLineLengths = floatArrayOf(30f, 54f, 22f, 44f, 38f)
private val TextLineOffsets = floatArrayOf(12f, 2f, 20f, 8f, 4f)
private val TextLineOrder = intArrayOf(2, 0, 4, 3, 1)

private val MathDark = Color(0xFF0A1B30)
private val MathMuted = Color(0xFF9CC3E6)
private val MathInk = Color(0xFF102A48)
private val CalcPresses = arrayOf(0 to 0.08f, 7 to 0.14f, 1 to 0.2f, 11 to 0.26f, 15 to 0.34f)
private val GradeValues = floatArrayOf(12f, 15f, 9f, 17f)
private val GradeLabels = arrayOf("12", "15", "09", "17")
private val TriangleX = floatArrayOf(22f, 22f, 82f, 22f)
private val TriangleY = floatArrayOf(30f, 80f, 80f, 30f)

private val SciDark = Color(0xFF0A2528)
private val SciMuted = Color(0xFF9FD9DF)
private val SciInk = Color(0xFF06292D)
private val MatrixCells = arrayOf("m2", "m1", "m0", "m3")
private val HistogramBars = floatArrayOf(6f, 12f, 22f, 34f, 40f, 34f, 22f, 12f, 6f)

/** Escribe el texto de a pocos, de izquierda a derecha. */
private fun DrawScope.revealText(t: SceneText, text: String, x: Float, cy: Float, color: Color, progress: Float, alpha: Float) {
    if (progress <= 0f || alpha <= 0f) return
    val layout = t[text]
    clipRect(x, cy - layout.size.height, x + layout.size.width * clamp01(progress), cy + layout.size.height) {
        labelStart(t, text, x, cy, color, alpha)
    }
}

private val ViewerDark = Color(0xFF151F2B)
private val QuickDark = Color(0xFF0F262B)
private val QrInk = Color(0xFF0B1F24)
private val ExcelGreen = Color(0xFF22A06B)
private val PptOrange = Color(0xFFD35230)
private val PptSoft = Color(0xFFF0A58E)
private val SheetCols = arrayOf("colA", "colB", "colC", "colD")
private val SheetRows = arrayOf("row1", "row2", "row3", "row4")
private val SheetValues = floatArrayOf(0.7f, 0.4f, 0.9f, 0.55f, 0.3f, 0.8f, 0.6f, 0.45f, 0.85f, 0.5f, 0.65f, 0.35f, 0.75f, 0.6f, 0.4f, 0.9f)
private val WordCounterLines = floatArrayOf(64f, 58f, 66f, 40f, 60f, 52f, 30f)
private val BarcodeWidths = intArrayOf(2, 1, 1, 3, 1, 2, 1, 1, 2, 3, 1, 1, 2, 1, 3, 1)
private val SlideBars = floatArrayOf(16f, 26f, 20f, 34f)

/** Código QR de 11 x 11 fijo: 2 = esquina de ubicación, 1 = punto, 0 = vacío. */
private const val QR_SIZE = 11
private val QrGrid: IntArray by lazy {
    var seed = 7L
    fun rnd(): Float {
        seed = (seed * 1103515245L + 12345L) and 0x7fffffffL
        return seed / 2147483647f
    }
    IntArray(QR_SIZE * QR_SIZE) { i ->
        val r = i / QR_SIZE
        val c = i % QR_SIZE
        fun inFinder(fr: Int, fc: Int) = r >= fr && r < fr + 3 && c >= fc && c < fc + 3
        if (inFinder(0, 0) || inFinder(0, 8) || inFinder(8, 0)) 2 else if (rnd() > 0.5f) 1 else 0
    }
}

/** Orden "al azar" (pero fijo) en que aparecen los puntos del QR. */
private val QrOrder: IntArray by lazy {
    var seed = 99L
    fun rnd(): Float {
        seed = (seed * 1103515245L + 12345L) and 0x7fffffffL
        return seed / 2147483647f
    }
    QrGrid.indices.filter { QrGrid[it] == 1 }.map { it to rnd() }.sortedBy { it.second }.map { it.first }.toIntArray()
}

private fun periodicGroupColor(col: Int, accent: Color): Color = when {
    col == 0 -> Color(0xFFFF8A8A)
    col == 1 -> SkyOrange
    col < 12 -> Color(0xFF5CC8D1)
    col < 17 -> accent
    else -> SkyPurple
}

private fun periodicHasCell(row: Int, col: Int): Boolean = when {
    row == 0 -> col == 0 || col == 17
    row < 3 -> col < 2 || col > 11
    else -> true
}

// ---------------------------------------------------------------------------
// Escenas: Documentos y PDF
// ---------------------------------------------------------------------------
private val ScenesByTool: Map<ToolId, ToolScene> = mapOf(

    // Escáner: la luz recorre la hoja en el celular y sale un PDF limpio.
    ToolId.DOCUMENT_SCANNER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        rr(22f, 10f, 44f, 80f, 8f, PhoneDark)
        rrStroke(22f, 10f, 44f, 80f, 8f, Color(0xFF3E4A5C), 1.2f)
        rr(40f, 13f, 8f, 2f, 1f, Color(0xFF3E4A5C))
        val sx = 26f; val sy = 18f; val sw = 36f; val sh = 64f
        rr(sx, sy, sw, sh, 2.5f, Color(0xFFE9EDF2))
        for (i in 0 until 6) {
            val ly = sy + 12f + i * 8f
            ln(sx + 5f, ly, sx + (if (i % 2 == 1) 24f else 31f), ly, Color(0xFFAEB7C2), 1.5f)
        }
        val ca = 0.6f + 0.4f * sin(p * PI.toFloat() * 6f)
        val bl = 6f
        // Esquinas del encuadre (como una cámara que detecta la hoja)
        ln(sx + 1f, sy + 1f, sx + 1f + bl, sy + 1f, pal.accent, 1.6f, ca); ln(sx + 1f, sy + 1f, sx + 1f, sy + 1f + bl, pal.accent, 1.6f, ca)
        ln(sx + sw - 1f, sy + 1f, sx + sw - 1f - bl, sy + 1f, pal.accent, 1.6f, ca); ln(sx + sw - 1f, sy + 1f, sx + sw - 1f, sy + 1f + bl, pal.accent, 1.6f, ca)
        ln(sx + 1f, sy + sh - 1f, sx + 1f + bl, sy + sh - 1f, pal.accent, 1.6f, ca); ln(sx + 1f, sy + sh - 1f, sx + 1f, sy + sh - 1f - bl, pal.accent, 1.6f, ca)
        ln(sx + sw - 1f, sy + sh - 1f, sx + sw - 1f - bl, sy + sh - 1f, pal.accent, 1.6f, ca); ln(sx + sw - 1f, sy + sh - 1f, sx + sw - 1f, sy + sh - 1f - bl, pal.accent, 1.6f, ca)
        val st = seg(p, 0.06f, 0.48f)
        if (st > 0f && st < 1f) {
            val ly = sy + sh * eIO(st)
            drawRect(
                Brush.verticalGradient(
                    listOf(pal.accent.copy(alpha = 0f), pal.accent.copy(alpha = 0.45f)),
                    startY = ly - 9f,
                    endY = ly
                ),
                topLeft = Offset(sx, ly - 9f),
                size = Size(sw, 9f)
            )
            ln(sx - 2f, ly, sx + sw + 2f, ly, Color.White, 1.6f)
        }
        arrow(74f, 96f, 50f, pal.accent, eOut(seg(p, 0.48f, 0.6f)), fl)
        val pt = eOut(seg(p, 0.56f, 0.72f))
        if (pt > 0f) {
            val ox = lerp(12f, 0f, pt)
            page(106f + ox, 16f, 46f, 64f, pt * fl, 0)
            for (i in 0 until 3) {
                val tt = seg(p, 0.68f + i * 0.06f, 0.76f + i * 0.06f)
                val ly = 34f + i * 13f
                check(114f + ox, ly, 6f, OkGreen, tt, fl)
                ln(121f + ox, ly, lerp(121f, 145f, eOut(tt)) + ox, ly, PaperLine, 1.6f, fl * clamp01(tt * 3f))
            }
            badge(t, "PDF", 112f + ox, 16f, PdfRed, pt * fl, back(seg(p, 0.6f, 0.74f)))
        }
    },

    // Editor: se escribe en la hoja con barra de formato y sale en Word, Excel o PDF.
    ToolId.TEXT_TO_PDF to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val x = 50f; val y = 9f; val w = 70f; val h = 82f
        rr(x + 1.2f, y + 1.6f, w, h, 3f, Color.Black, 0.22f)
        rr(x, y, w, h, 3f, Paper)
        rr(x + 4f, y + 4f, w - 8f, 9f, 2f, Color(0xFFDDE3EA))
        label(t, "B", x + 10f, y + 8.8f, Ink)
        label(t, "I", x + 18f, y + 8.8f, Ink)
        label(t, "U", x + 26f, y + 8.8f, Ink)
        rr(x + w - 20f, y + 6f, 12f, 5f, 1.5f, pal.accent, 0.8f)
        var curX = -1f
        var curY = 0f
        for (i in 0 until 5) {
            val tt = seg(p, 0.06f + i * 0.1f, 0.15f + i * 0.1f)
            if (tt <= 0f) break
            val ly = y + 22f + i * 10f
            val lw = EditorLineWidths[i] * tt
            ln(x + 8f, ly, x + 8f + lw, ly, if (i == 0) Ink else Color(0xFF9AA6B4), if (i == 0) 2.4f else 1.7f)
            curX = x + 8f + lw + 1.5f
            curY = ly
        }
        if (curX >= 0f && p < 0.6f && (p * 12f).toInt() % 2 == 0) {
            ln(curX, curY - 3.5f, curX, curY + 3.5f, pal.accent, 1.2f)
        }
        val formats = arrayOf("DOCX", "XLSX", "PDF")
        val colors = arrayOf(Color(0xFF3D7BFF), Color(0xFF22A06B), PdfRed)
        val rows = floatArrayOf(22f, 50f, 78f)
        for (i in 0 until 3) {
            val tt = seg(p, 0.58f + i * 0.06f, 0.7f + i * 0.06f)
            if (tt > 0f) {
                arrow(123f, 134f, rows[i], pal.accent, eOut(tt), fl)
                badge(t, formats[i], 149f, rows[i], colors[i], fl, back(tt))
            }
        }
    },

    // Marca, numera y protege: marca de agua, número de página y candado que se cierra.
    ToolId.PDF_WATERMARK_SECURITY to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        page(34f, 14f, 56f, 76f, 1f, 0)
        page(28f, 10f, 56f, 76f, 1f, 5)
        val wm = seg(p, 0.08f, 0.3f)
        if (wm > 0f) {
            rotate(-0.55f * RAD_TO_DEG, pivot = Offset(56f, 50f)) {
                label(t, "GANA GEO", 56f, 50f, pal.accent, 0.55f * wm * fl)
            }
        }
        val nt = seg(p, 0.3f, 0.45f)
        if (nt > 0f) {
            rr(48f, 78f, 16f, 7f, 3.5f, Ink, fl * nt)
            label(t, "1 / 2", 56f, 81.7f, Color.White, fl * nt)
        }
        val lx = 126f; val ly = 56f
        val lift = lerp(-9f, 0f, eOut(seg(p, 0.5f, 0.66f)))
        val shackle = Path().apply {
            moveTo(lx - 8f, ly - 4f + lift * 0.15f)
            lineTo(lx - 8f, ly - 12f + lift)
            arcTo(Rect(lx - 8f, ly - 20f + lift, lx + 8f, ly - 4f + lift), 180f, 180f, false)
            lineTo(lx + 8f, ly - 4f + lift)
        }
        if (fl > 0f) {
            drawPath(shackle, Color(0xFFE7ECF2), alpha = clamp01(fl), style = Stroke(4f, cap = StrokeCap.Round))
        }
        val locked = seg(p, 0.64f, 0.72f)
        rr(lx - 14f, ly - 5f, 28f, 24f, 5f, if (locked > 0.5f) OkGreen else pal.accent, fl)
        dot(lx, ly + 4f, 3f, Color(0xFF2A0E10), fl)
        rr(lx - 1.2f, ly + 4f, 2.4f, 7f, 1f, Color(0xFF2A0E10), fl)
        if (locked > 0f && locked < 1f) {
            drawCircle(
                OkGreen,
                radius = lerp(14f, 24f, locked),
                center = Offset(lx, ly + 7f),
                alpha = clamp01((1f - locked) * fl),
                style = Stroke(1.5f)
            )
        }
    },

    // Imágenes a PDF: las fotos vuelan y se acomodan dentro de un PDF.
    ToolId.IMAGES_TO_PDF to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val px = 108f; val py = 12f; val pw = 48f; val ph = 72f
        rr(px + 1.2f, py + 1.6f, pw, ph, 3f, Color.Black, 0.22f)
        rr(px, py, pw, ph, 3f, Paper)
        arrow(74f, 96f, 48f, pal.accent, 1f, 0.35f)
        for (i in 0 until 3) {
            val start = ImagesToPdfStarts[i]
            val tt = eIO(seg(p, 0.12f + i * 0.12f, 0.38f + i * 0.12f))
            val x = lerp(start.x, px + 5f, tt)
            val y = lerp(start.y, py + 8f + i * 21f, tt)
            val w = lerp(34f, 38f, tt)
            val h = lerp(24f, 17f, tt)
            val rot = (1f - tt) * (i - 1) * 0.18f * RAD_TO_DEG
            rotate(rot, pivot = Offset(x + w / 2f, y + h / 2f)) {
                photo(x, y, w, h, fl * fi, start.sky, start.hill)
            }
        }
        badge(t, "PDF", px + pw - 6f, py + 2f, PdfRed, fl * seg(p, 0.72f, 0.8f), back(seg(p, 0.72f, 0.84f)))
    },

    // Organizar PDF: las páginas se ordenan 1-2-3 y se unen en un solo PDF.
    ToolId.PDF_ORGANIZER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val alpha = fl * fadeIn(p)
        val y0 = 24f; val w = 34f; val h = 48f
        val t1 = eIO(seg(p, 0.1f, 0.42f))
        val t2 = eIO(seg(p, 0.5f, 0.7f))
        // Al unir, la página 1 queda adelante.
        for (k in 0 until 3) {
            val n = if (t2 > 0f) 3 - k else k + 1
            val i = OrganizerStart.indexOf(n)
            var x = lerp(OrganizerSlots[i], OrganizerSlots[n - 1], t1)
            var y = y0 - sin(PI.toFloat() * t1) * (if (n == 3) 14f else -8f)
            x = lerp(x, 58f + (3 - n) * 4f, t2)
            y = lerp(y, 16f + (3 - n) * 3f, t2)
            rr(x + 1.2f, y + 1.6f, w, h, 3f, Color.Black, 0.22f * alpha)
            rr(x, y, w, h, 3f, Paper, alpha)
            ln(x + 6f, y + 9f, x + 24f, y + 9f, PaperLine, 1.5f, alpha)
            ln(x + 6f, y + 15f, x + 28f, y + 15f, PaperLine, 1.5f, alpha)
            label(t, OrganizerLabels[n - 1], x + w / 2f, y + h * 0.62f, pal.accent, alpha)
        }
        val bt = seg(p, 0.7f, 0.82f)
        if (bt > 0f) {
            badge(t, "PDF", 100f, 19f, PdfRed, fl, back(bt))
            val ct = seg(p, 0.74f, 0.86f)
            rr(62f, 78f, 34f, 10f, 5f, OkGreen, fl * ct)
            label(t, "Unido", 79f, 83.4f, Color(0xFF06210F), fl * ct)
        }
    },

    // PDF a imágenes: del PDF salen fotos en cuadrícula.
    ToolId.PDF_TO_IMAGES to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        page(16f, 12f, 48f, 72f, 1f, 5)
        badge(t, "PDF", 26f, 13f, PdfRed)
        arrow(70f, 92f, 48f, pal.accent, eOut(seg(p, 0.08f, 0.22f)), fl)
        for (i in 0 until 4) {
            val tt = seg(p, 0.22f + i * 0.09f, 0.36f + i * 0.09f)
            if (tt <= 0f) continue
            val gx = 100f + (i % 2) * 32f
            val gy = 22f + (i / 2) * 30f
            val s = back(tt)
            val (sky, hill) = PdfToImagesColors[i]
            withTransform({
                translate(gx + 14f, gy + 11f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                photo(-14f, -11f, 28f, 22f, fl, sky, hill)
            }
        }
        val jt = seg(p, 0.66f, 0.78f)
        if (jt > 0f) badge(t, "JPG", 148f, 84f, Color(0xFFFFB35A), fl, back(jt))
    },

    // Firmar PDF: una pluma dibuja la firma sobre la línea y aparece el check.
    ToolId.SIGN_PDF to ToolScene { p, _, t ->
        val fl = fadeLoop(p)
        page(36f, 8f, 98f, 84f, 1f, 2)
        ln(52f, 74f, 118f, 74f, Color(0xFF9AA6B4), 1.2f)
        label(t, "Firma", 85f, 80.5f, Color(0xFF8792A2))
        val tt = seg(p, 0.1f, 0.62f)
        if (tt > 0f) {
            val points = SignaturePoints
            val total = points.size / 2
            val n = max(1, (total * eIO(tt)).toInt()).coerceAtMost(total)
            val ink = Path().apply {
                moveTo(points[0], points[1])
                for (i in 1 until n) lineTo(points[i * 2], points[i * 2 + 1])
            }
            if (fl > 0f) {
                drawPath(
                    ink,
                    Color(0xFF1F3A93),
                    alpha = clamp01(fl),
                    style = Stroke(1.9f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
            if (tt < 1f) {
                val ex = points[(n - 1) * 2]
                val ey = points[(n - 1) * 2 + 1]
                rotate(-0.7f * RAD_TO_DEG, pivot = Offset(ex, ey)) {
                    rr(ex - 1.6f, ey - 18f, 3.2f, 15f, 1.2f, Ink)
                    val nib = Path().apply {
                        moveTo(ex - 1.6f, ey - 3f)
                        lineTo(ex + 1.6f, ey - 3f)
                        lineTo(ex, ey + 1f)
                        close()
                    }
                    drawPath(nib, Color(0xFFE7B84B))
                }
            }
        }
        val ct = seg(p, 0.66f, 0.78f)
        if (ct > 0f) {
            dot(124f, 22f, 9f * back(ct), OkGreen, fl)
            check(124f, 22.5f, 9f, Color(0xFF06210F), seg(p, 0.7f, 0.82f), fl)
        }
    }
,

    // -----------------------------------------------------------------------
    // Imágenes
    // -----------------------------------------------------------------------

    // Estudio por lote: varias fotos se acomodan en un collage con marco y salen en ZIP.
    ToolId.IMAGE_BATCH_STUDIO to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val fx = 62f; val fy = 14f; val fw = 58f; val fh = 72f
        rr(fx - 2f, fy - 2f, fw + 4f, fh + 4f, 4f, Color.White, eOut(seg(p, 0.46f, 0.6f)) * fl)
        val cw = (fw - 6f) / 2f
        val ch = (fh - 6f) / 2f
        for (i in 0 until 4) {
            val tt = eIO(seg(p, 0.08f + i * 0.08f, 0.34f + i * 0.08f))
            val tx = fx + 2f + (i % 2) * (cw + 2f)
            val ty = fy + 2f + (i / 2) * (ch + 2f)
            val x = lerp(18f + i * 3f, tx, tt)
            val y = lerp(26f + i * 4f, ty, tt)
            val w = lerp(36f, cw, tt)
            val h = lerp(27f, ch, tt)
            val rot = (1f - tt) * (i - 1.5f) * 0.12f * RAD_TO_DEG
            val (sky, hill) = PdfToImagesColors[i]
            rotate(rot, pivot = Offset(x + w / 2f, y + h / 2f)) {
                photo(x, y, w, h, fl * fi, sky, hill)
            }
        }
        val zt = seg(p, 0.64f, 0.76f)
        if (zt > 0f) {
            arrow(126f, 138f, 50f, pal.accent, eOut(zt), fl)
            badge(t, "ZIP", 153f, 50f, ImageBrown, fl, back(zt))
        }
    },

    // Comprimir: la foto se achica, la barra de peso baja y sale "320 KB  -92%".
    ToolId.COMPRESS_IMAGE to ToolScene { p, _, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val tt = eIO(seg(p, 0.12f, 0.5f))
        dashedRect(14f, 12f, 70f, 52f, Color.White, 0.8f, 0.4f * seg(p, 0.2f, 0.4f) * fl)
        photo(lerp(14f, 100f, tt), lerp(12f, 24f, tt), lerp(70f, 44f, tt), lerp(52f, 33f, tt), fl * fi, SkyBlue, HillGreen)
        val la = lerp(1f, 0.55f, seg(p, 0.12f, 0.3f)) * fi * fl
        label(t, "4.2 MB", 49f, 76f, Color.White, la)
        ln(38f, 76f, 60f, 76f, Color.White, 0.9f, la * seg(p, 0.3f, 0.42f))
        rr(20f, 86f, 60f, 4f, 2f, Color.Black, 0.25f * fi * fl)
        rr(20f, 86f, lerp(60f, 16f, tt), 4f, 2f, if (tt < 0.5f) PdfRed else OkGreen, fl * fi)
        val rt = seg(p, 0.52f, 0.64f)
        if (rt > 0f) {
            label(t, "320 KB", 122f, 66f, Color.White, fl * rt)
            pill(t, "-92%", 122f, 79f, 22f, OkGreen, Color(0xFF06210F), fl, back(seg(p, 0.6f, 0.72f)))
        }
    },

    // Cambiar tamaño: se arrastra la esquina y cambia la medida.
    ToolId.RESIZE_IMAGE to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 24f; val y = 12f
        val tt = eIO(seg(p, 0.15f, 0.55f))
        val w = lerp(84f, 52f, tt)
        val h = lerp(63f, 39f, tt)
        dashedRect(x, y, 84f, 63f, Color.White, 0.8f, 0.45f * fi)
        photo(x, y, w, h, fl * fi, SkyOrange, HillRed)
        dot(x + w, y + h, 3.4f, Color.White, fl * fi)
        dot(x + w, y + h, 2f, pal.accent, fl * fi)
        val before = tt < 0.5f
        pill(
            t,
            if (before) "1920 × 1080" else "800 × 450",
            140f, 40f, 38f,
            if (before) Color(0xFF2A1608) else pal.accent,
            if (before) Color.White else Color(0xFF3A1F06),
            fl * fi
        )
        if (tt >= 1f) check(140f, 56f, 7f, OkGreen, seg(p, 0.58f, 0.7f), fl)
    },

    // Convertir formato: una foto JPG sale como PNG y WEBP.
    ToolId.CONVERT_IMAGE to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        photo(14f, 24f, 52f, 40f, 1f, SkyBlue, HillGreen)
        badge(t, "JPG", 58f, 24f, ImageBrown)
        arrow(72f, 90f, 44f, pal.accent, eOut(seg(p, 0.08f, 0.2f)), fl)
        for (i in 0 until 2) {
            val tt = seg(p, 0.22f + i * 0.18f, 0.38f + i * 0.18f)
            if (tt <= 0f) continue
            val ox = 98f
            val oy = if (i == 0) 12f else 52f
            val s = back(tt)
            withTransform({
                translate(ox + 22f, oy + 16f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                photo(-22f, -16f, 44f, 32f, fl, SkyBlue, HillGreen)
            }
            badge(
                t,
                if (i == 0) "PNG" else "WEBP",
                ox + 44f, oy + 2f,
                if (i == 0) Color(0xFF3D7BFF) else Color(0xFF22A06B),
                fl, s
            )
        }
    },

    // Recortar y girar: el marco de recorte se cierra y la foto recortada gira.
    ToolId.CROP_ROTATE_IMAGE to ToolScene { p, pal, _ ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val px = 12f; val py = 16f; val pw = 72f; val ph = 54f
        photo(px, py, pw, ph, fi, SkyPurple, HillTeal)
        val tt = eIO(seg(p, 0.08f, 0.36f))
        val cx = lerp(px, px + 16f, tt)
        val cy = lerp(py, py + 8f, tt)
        val cw = lerp(pw, 40f, tt)
        val ch = lerp(ph, 38f, tt)
        val dim = 0.5f * tt * fi
        rr(px, py, pw, cy - py, 0f, Color.Black, dim)
        rr(px, cy + ch, pw, py + ph - cy - ch, 0f, Color.Black, dim)
        rr(px, cy, cx - px, ch, 0f, Color.Black, dim)
        rr(cx + cw, cy, px + pw - cx - cw, ch, 0f, Color.Black, dim)
        if (fi > 0f) {
            drawRect(Color.White, Offset(cx, cy), Size(cw, ch), alpha = clamp01(fi), style = Stroke(0.6f))
            for (k in 1..2) {
                ln(cx + cw * k / 3f, cy, cx + cw * k / 3f, cy + ch, Color.White, 0.6f, fi * 0.5f)
                ln(cx, cy + ch * k / 3f, cx + cw, cy + ch * k / 3f, Color.White, 0.6f, fi * 0.5f)
            }
            val l = 5f
            ln(cx, cy, cx + l, cy, Color.White, 1.8f, fi); ln(cx, cy, cx, cy + l, Color.White, 1.8f, fi)
            ln(cx + cw, cy, cx + cw - l, cy, Color.White, 1.8f, fi); ln(cx + cw, cy, cx + cw, cy + l, Color.White, 1.8f, fi)
            ln(cx, cy + ch, cx + l, cy + ch, Color.White, 1.8f, fi); ln(cx, cy + ch, cx, cy + ch - l, Color.White, 1.8f, fi)
            ln(cx + cw, cy + ch, cx + cw - l, cy + ch, Color.White, 1.8f, fi); ln(cx + cw, cy + ch, cx + cw, cy + ch - l, Color.White, 1.8f, fi)
        }
        arrow(90f, 104f, 44f, pal.accent, eOut(seg(p, 0.4f, 0.5f)), fl)
        val at = seg(p, 0.48f, 0.56f)
        if (at > 0f) {
            val rt = eIO(seg(p, 0.56f, 0.76f))
            rotate(rt * 90f, pivot = Offset(134f, 44f)) {
                photo(114f, 25f, 40f, 38f, fl * at, SkyPurple, HillTeal)
            }
            if (rt > 0f) {
                drawArc(
                    color = pal.accent,
                    startAngle = -0.35f * 180f,
                    sweepAngle = rt * 0.6f * 180f,
                    useCenter = false,
                    topLeft = Offset(134f - 27f, 44f - 27f),
                    size = Size(54f, 54f),
                    alpha = clamp01(fl * at),
                    style = Stroke(1.6f, cap = StrokeCap.Round)
                )
            }
        }
    },

    // Marca de agua: aparece "© Tu marca", luego se repite y sube la opacidad.
    ToolId.WATERMARK_IMAGE to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val px = 14f; val py = 10f; val pw = 104f; val ph = 78f
        photo(px, py, pw, ph, 1f, SkyOrange, HillRed)
        val t1 = eOut(seg(p, 0.1f, 0.32f))
        if (t1 > 0f) {
            val tx = lerp(110f, 96f, t1)
            label(t, "© Tu marca", tx + 0.5f, 78.6f, Color.Black, 0.35f * t1 * fl)
            label(t, "© Tu marca", tx, 78f, Color.White, t1 * fl * 0.95f)
        }
        val t2 = seg(p, 0.4f, 0.6f)
        if (t2 > 0f) {
            clipRect(px, py, px + pw, py + ph) {
                for (r in 0 until 3) {
                    for (k in 0 until 3) {
                        val cx = px + 18f + k * 34f + (r % 2) * 12f
                        val cy = py + 16f + r * 22f
                        rotate(-0.45f * RAD_TO_DEG, pivot = Offset(cx, cy)) {
                            label(t, "Tu marca", cx, cy, Color.White, 0.35f * t2 * fl)
                        }
                    }
                }
            }
        }
        val sx = 142f
        ln(sx, 18f, sx, 80f, Color.White, 2.2f, 0.25f)
        val ky = lerp(72f, 30f, eIO(seg(p, 0.12f, 0.6f)))
        ln(sx, ky, sx, 80f, pal.accent, 2.2f, fl)
        dot(sx, ky, 4f, Color.White, fl)
        dot(sx, ky, 2.2f, pal.accent, fl)
    }
,

    // -----------------------------------------------------------------------
    // Trabajo y empleo
    // -----------------------------------------------------------------------

    // CV: eliges plantilla, se arma la hoja (foto, secciones, habilidades) y sale en PDF.
    ToolId.CV_BUILDER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        for (i in 0 until 2) {
            val ty = 16f + i * 36f
            rr(12f, ty, 26f, 32f, 2.5f, Paper, 0.9f)
            rr(12f, ty, 26f, 7f, 2.5f, if (i == 0) pal.accent else Gray, 0.9f)
            ln(16f, ty + 13f, 32f, ty + 13f, PaperLine, 1.2f)
            ln(16f, ty + 18f, 28f, ty + 18f, PaperLine, 1.2f)
            ln(16f, ty + 23f, 33f, ty + 23f, PaperLine, 1.2f)
        }
        rrStroke(10.5f, 14.5f, 29f, 35f, 3.5f, pal.accent, 1.4f, seg(p, 0.04f, 0.14f) * fl)
        val x = 48f; val y = 8f; val w = 62f; val h = 84f
        rr(x + 1.2f, y + 1.6f, w, h, 3f, Color.Black, 0.22f)
        rr(x, y, w, h, 3f, Paper)
        rr(x, y, w, 14f, 3f, WorkHeader)
        dot(x + 10f, y + 14f, 7f, pal.accent)
        dot(x + 10f, y + 12.2f, 2.6f, WorkHeader)
        rr(x + 5.6f, y + 15.6f, 8.8f, 4f, 2f, WorkHeader)
        ln(x + 21f, y + 6f, x + 50f, y + 6f, Color.White, 2.2f)
        ln(x + 21f, y + 10.5f, x + 40f, y + 10.5f, Color(0xFFA8E6C0), 1.4f)
        for (k in 0 until 2) {
            val sy = if (k == 0) y + 28f else y + 48f
            val lines = if (k == 0) 3 else 2
            val tt = seg(p, 0.12f + k * 0.16f, 0.28f + k * 0.16f)
            if (tt <= 0f) continue
            rr(x + 6f, sy - 3f, 14f * eOut(tt), 3.2f, 1.5f, WorkHeader, fi)
            for (j in 0 until lines) {
                val lt = seg(p, 0.16f + k * 0.16f + j * 0.04f, 0.26f + k * 0.16f + j * 0.04f)
                ln(x + 6f, sy + 4f + j * 5f, x + 6f + lerp(0f, if (j % 2 == 1) 36f else 46f, eOut(lt)), sy + 4f + j * 5f, PaperLine, 1.4f, fi * clamp01(lt * 4f))
            }
        }
        for (j in 0 until 3) {
            val tt = eOut(seg(p, 0.46f + j * 0.05f, 0.6f + j * 0.05f))
            val by = y + 66f + j * 6f
            rr(x + 6f, by, 46f, 2.6f, 1.3f, Color(0xFFDDE3EA), fi)
            rr(x + 6f, by, 46f * CvSkills[j] * tt, 2.6f, 1.3f, pal.accent, fi)
        }
        val pt = seg(p, 0.64f, 0.76f)
        if (pt > 0f) {
            arrow(116f, 128f, 50f, pal.accent, eOut(pt), fl)
            badge(t, "PDF", 143f, 50f, PdfRed, fl, back(pt))
        }
    },

    // Horas de trabajo: el reloj avanza, se suman horas normales y extra y sale el pago.
    ToolId.WORK_HOURS to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val cx = 42f; val cy = 48f; val r = 29f
        dot(cx, cy, r + 3f, WorkDark)
        dot(cx, cy, r, Paper)
        for (i in 0 until 12) {
            val a = i / 12f * 2f * PI.toFloat()
            val inner = r - (if (i % 3 == 0) 7f else 5f)
            ln(
                cx + kotlin.math.cos(a) * (r - 3f), cy + sin(a) * (r - 3f),
                cx + kotlin.math.cos(a) * inner, cy + sin(a) * inner,
                Gray, if (i % 3 == 0) 1.6f else 1f
            )
        }
        val tt = eIO(seg(p, 0.05f, 0.55f))
        if (tt > 0f && fl > 0f) {
            drawArc(
                color = pal.accent,
                startAngle = -90f,
                sweepAngle = tt * 360f * 0.83f,
                useCenter = true,
                topLeft = Offset(cx - (r - 2f), cy - (r - 2f)),
                size = Size((r - 2f) * 2f, (r - 2f) * 2f),
                alpha = clamp01(0.35f * fl)
            )
        }
        val hourA = -PI.toFloat() / 2f + tt * 2f * PI.toFloat() * 0.83f
        val minA = -PI.toFloat() / 2f + tt * 2f * PI.toFloat() * 10f
        ln(cx, cy, cx + kotlin.math.cos(hourA) * 15f, cy + sin(hourA) * 15f, Color(0xFF1F3A2B), 3f)
        ln(cx, cy, cx + kotlin.math.cos(minA) * 22f, cy + sin(minA) * 22f, Color(0xFF2B6A47), 1.8f)
        dot(cx, cy, 2.6f, Color(0xFF1F3A2B))
        val bx = 86f; val by = 16f; val bw = 68f
        rr(bx, by, bw, 68f, 5f, WorkDark, 0.9f)
        val r1 = seg(p, 0.25f, 0.35f)
        labelStart(t, "Normal", bx + 7f, by + 14f, WorkMuted, r1 * fl)
        labelEnd(t, "8 h", bx + bw - 7f, by + 14f, Color.White, r1 * fl)
        val r2 = seg(p, 0.38f, 0.48f)
        labelStart(t, "Extra", bx + 7f, by + 28f, WorkMuted, r2 * fl)
        labelEnd(t, "+2 h", bx + bw - 7f, by + 28f, pal.accent, r2 * fl)
        val r3 = seg(p, 0.55f, 0.68f)
        if (r3 > 0f) {
            ln(bx + 7f, by + 40f, bx + bw - 7f, by + 40f, Color(0xFF2F5A40), 1f, fl)
            labelStart(t, "Total", bx + 7f, by + 52f, WorkMuted, r3 * fl)
            val s = back(r3)
            withTransform({
                translate(bx + bw - 7f, by + 52f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                labelEnd(t, "S/ 96", 0f, 0f, OkGreen, fl)
            }
        }
    },

    // Cotización e IGV: se agregan ítems, sale "IGV 18%" y el total.
    ToolId.QUOTE_IGV to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 34f; val y = 8f; val w = 84f; val h = 84f
        rr(x + 1.2f, y + 1.6f, w, h, 3f, Color.Black, 0.22f)
        rr(x, y, w, h, 3f, Paper)
        rr(x, y, w, 12f, 3f, WorkHeader)
        labelStart(t, "Cotización", x + 6f, y + 6.4f, Color.White)
        for (i in 0 until 3) {
            val tt = seg(p, 0.08f + i * 0.08f, 0.18f + i * 0.08f)
            val ry = y + 22f + i * 9f
            val a = fi * clamp01(tt * 4f)
            ln(x + 6f, ry, x + 6f + lerp(0f, if (i == 1) 30f else 38f, eOut(tt)), ry, Gray, 1.5f, a)
            rr(x + w - 20f, ry - 2f, 14f * eOut(tt), 4f, 1.5f, Color(0xFFC9D3DD), a)
        }
        ln(x + 6f, y + 52f, x + w - 6f, y + 52f, Color(0xFFDDE3EA), 1f, seg(p, 0.34f, 0.42f) * fi)
        val igv = seg(p, 0.42f, 0.54f)
        if (igv > 0f) pill(t, "IGV 18%", x + w - 18f, y + 60f, 28f, pal.accent, Color(0xFF0B2A17), fl, back(igv))
        val tt = seg(p, 0.58f, 0.7f)
        if (tt > 0f) {
            rr(x + 5f, y + 68f, w - 10f, 12f, 3f, WorkHeader, fl * tt)
            labelStart(t, "Total", x + 10f, y + 74.4f, Color(0xFFA8E6C0), fl * tt)
            val s = back(tt)
            withTransform({
                translate(x + w - 10f, y + 74.4f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                labelEnd(t, "S/ 118", 0f, 0f, Color.White, fl)
            }
        }
        val ct = seg(p, 0.72f, 0.84f)
        if (ct > 0f) {
            dot(x + w + 14f, y + 20f, 8f * back(ct), OkGreen, fl)
            check(x + w + 14f, y + 20.5f, 8f, Color(0xFF06210F), seg(p, 0.76f, 0.86f), fl)
        }
    },

    // Ingresos y gastos: barras de lo que entra y sale, la línea del saldo y el resultado.
    ToolId.INCOME_EXPENSE_TRACKER to ToolScene { p, _, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val base = 56f; val x0 = 16f
        ln(x0, base, x0 + 92f, base, Color.White, 0.8f, 0.4f * fi)
        for (i in 0 until 5) {
            val tt = eOut(seg(p, 0.06f + i * 0.06f, 0.22f + i * 0.06f))
            val bx = x0 + 6f + i * 18f
            rr(bx, base - IncomeBars[i] * tt, 6f, IncomeBars[i] * tt, 1.5f, OkGreen, fi * fl)
            rr(bx + 7f, base, 6f, ExpenseBars[i] * tt, 1.5f, SoftRed, fi * fl)
        }
        val lt = seg(p, 0.42f, 0.66f)
        if (lt > 0f && fl > 0f) {
            val px = FloatArray(5)
            val py = FloatArray(5)
            var acc = 0f
            for (i in 0 until 5) {
                acc += IncomeBars[i] - ExpenseBars[i]
                px[i] = x0 + 12f + i * 18f
                py[i] = base - 6f - acc * 0.55f
            }
            val n = lt * 4f
            val whole = n.toInt()
            val frac = n - whole
            val line = Path().apply {
                moveTo(px[0], py[0])
                for (i in 1..whole) lineTo(px[i], py[i])
                if (frac > 0f && whole + 1 < 5) lineTo(lerp(px[whole], px[whole + 1], frac), lerp(py[whole], py[whole + 1], frac))
            }
            drawPath(line, Color.White, alpha = clamp01(fl), style = Stroke(1.6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            if (lt >= 1f) dot(px[4], py[4], 2.4f, Color.White, fl)
        }
        val rx = 120f
        labelStart(t, "S/ 2,450", rx, 22f, OkGreen, seg(p, 0.3f, 0.4f) * fl)
        labelStart(t, "S/ 1,280", rx, 38f, SoftRed, seg(p, 0.4f, 0.5f) * fl)
        val tt = seg(p, 0.66f, 0.78f)
        if (tt > 0f) {
            rr(rx - 3f, 60f, 46f, 14f, 4f, WorkDark, fl * tt)
            labelStart(t, "S/ 1,170", rx + 1f, 67.4f, Color.White, fl * tt)
        }
    },

    // Inventario: llegan cajas a los estantes, baja el stock y salta la alerta de mínimo.
    ToolId.INVENTORY_BASIC to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val shelf = Color(0xFFC8A57A)
        ln(12f, 44f, 92f, 44f, shelf, 2.4f, fi)
        ln(12f, 80f, 92f, 80f, shelf, 2.4f, fi)
        for (i in InventoryBoxes.indices) {
            val b = InventoryBoxes[i]
            val tt = seg(p, 0.04f + i * 0.05f, 0.14f + i * 0.05f)
            if (tt <= 0f) continue
            val bx = b[0]; val bw = b[2]; val bh = b[3]
            val yy = lerp(b[1] - bh - 30f, b[1] - bh, eOut(tt))
            val a = fi * fl * clamp01(tt * 3f)
            rr(bx, yy, bw, bh, 1.5f, Color(0xFFD9A066), a)
            rr(bx + bw / 2f - 2f, yy, 4f, bh, 0f, Color(0xFFB9824A), a)
            ln(bx + 2f, yy + 3f, bx + bw - 2f, yy + 3f, Color(0xFFE8BE8A), 0.8f, a)
        }
        val bx = 104f
        val st = eIO(seg(p, 0.4f, 0.66f))
        for (i in InventoryStock.indices) {
            val (from, to) = InventoryStock[i]
            val by = 26f + i * 20f
            val v = lerp(from, to, st)
            rr(bx, by, 46f, 6f, 3f, WorkDark, fi)
            rr(bx, by, 46f * v, 6f, 3f, if (v < 0.25f) SoftRed else pal.accent, fi * fl)
        }
        ln(bx + 46f * 0.25f, 20f, bx + 46f * 0.25f, 74f, Sun, 0.8f, 0.7f * fi)
        val at = seg(p, 0.66f, 0.74f)
        if (at > 0f) {
            val pulse = 1f + 0.12f * sin(p * PI.toFloat() * 14f)
            val s = back(at) * pulse
            withTransform({
                translate(158f, 66f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                dot(0f, 0f, 6f, SoftRed, fl)
                label(t, "!", 0f, 0.5f, Color.White, fl)
            }
        }
    },

    // Comisiones y ganancias: del precio sale la parte de ganancia y el porcentaje.
    ToolId.COMMISSION_MARGIN to ToolScene { p, _, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        if (fi > 0f) {
            val tag = Path().apply {
                moveTo(14f, 36f); lineTo(22f, 26f); lineTo(62f, 26f); lineTo(62f, 52f); lineTo(22f, 52f); close()
            }
            drawPath(tag, Paper, alpha = clamp01(fi))
        }
        dot(23f, 39f, 2.2f, Color(0xFF173825), fi)
        label(t, "S/ 100", 43f, 39.5f, Color(0xFF173825), fi)
        val bt = eIO(seg(p, 0.12f, 0.4f))
        rr(14f, 66f, 80f, 8f, 4f, Gray, fi * fl)
        rr(14f + 80f * (1f - 0.3f * bt), 66f, 80f * 0.3f * bt, 8f, 4f, OkGreen, fi * fl)
        if (bt > 0f) ln(70f, 62f, 70f, 78f, Color.White, 0.8f, 0.6f * bt * fl)
        val cx = 128f; val cy = 48f; val r = 20f
        if (fi > 0f) drawCircle(WorkDark, r, Offset(cx, cy), alpha = clamp01(fi), style = Stroke(7f))
        val at = eIO(seg(p, 0.42f, 0.66f))
        if (at > 0f && fl > 0f) {
            drawArc(
                color = OkGreen,
                startAngle = -90f,
                sweepAngle = 360f * 0.3f * at,
                useCenter = false,
                topLeft = Offset(cx - r, cy - r),
                size = Size(r * 2f, r * 2f),
                alpha = clamp01(fl),
                style = Stroke(7f, cap = StrokeCap.Round)
            )
        }
        val tt = seg(p, 0.6f, 0.72f)
        if (tt > 0f) {
            val s = back(tt)
            withTransform({
                translate(cx, cy)
                scale(s, s, pivot = Offset.Zero)
            }) {
                label(t, "30%", 0f, 0.6f, Color.White, fl)
            }
        }
    },

    // Checklist: se marcan las tareas una por una y el anillo llega a 4/4.
    ToolId.WORK_CHECKLIST to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 24f; val y = 12f; val w = 70f; val h = 80f
        rr(x + 1.2f, y + 1.6f, w, h, 4f, Color.Black, 0.22f)
        rr(x, y, w, h, 4f, Paper)
        rr(x + w / 2f - 12f, y - 4f, 24f, 9f, 3f, Color(0xFF5F6B7A))
        var done = 0
        for (i in 0 until 4) {
            val ry = y + 18f + i * 16f
            val tt = seg(p, 0.12f + i * 0.13f, 0.2f + i * 0.13f)
            rrStroke(x + 7f, ry - 4.5f, 9f, 9f, 2f, Gray, 1.2f)
            ln(x + 21f, ry, x + 21f + ChecklistLengths[i], ry, Gray, 1.6f, fi)
            if (tt > 0f) {
                rr(x + 7f, ry - 4.5f, 9f, 9f, 2f, OkGreen, clamp01(tt * 2f) * fl)
                check(x + 11.5f, ry + 0.2f, 6f, Color(0xFF06210F), tt, fl)
                val strike = eOut(seg(p, 0.16f + i * 0.13f, 0.26f + i * 0.13f))
                ln(x + 21f, ry, x + 21f + ChecklistLengths[i] * strike, ry, Color(0xFF5F6B7A), 1f, fl)
                done++
            }
        }
        val cx = 128f; val cy = 50f; val r = 18f
        if (fi > 0f) drawCircle(WorkDark, r, Offset(cx, cy), alpha = clamp01(fi), style = Stroke(5f))
        val prog = clamp01((p - 0.12f) / (0.65f - 0.12f))
        val sweep = min(done / 4f, prog * 1.02f)
        if (sweep > 0f && fl > 0f) {
            drawArc(
                color = pal.accent,
                startAngle = -90f,
                sweepAngle = 360f * sweep,
                useCenter = false,
                topLeft = Offset(cx - r, cy - r),
                size = Size(r * 2f, r * 2f),
                alpha = clamp01(fl),
                style = Stroke(5f, cap = StrokeCap.Round)
            )
        }
        label(t, ChecklistLabels[done], cx, cy + 0.6f, Color.White, fi * fl)
    }
,

    // -----------------------------------------------------------------------
    // Estudio y escritura
    // -----------------------------------------------------------------------

    // Sistemas numéricos: los bits se encienden (1010) y salen DEC 10 y HEX A.
    ToolId.NUMBER_SYSTEMS to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        for (i in 0 until 4) {
            val x = 16f + i * 19f
            val y = 24f
            val shown = seg(p, 0.08f + i * 0.08f, 0.16f + i * 0.08f) > 0.5f
            val on = shown && NumberBits[i] == 1
            rr(x, y, 16f, 22f, 3f, if (on) pal.accent else StudyDark, fi)
            label(t, if (on) "bit1" else "bit0", x + 8f, y + 11.5f, if (on) StudyInk else Color(0xFF7E6A9C), fi)
        }
        label(t, "BIN", 50f, 54f, StudyMuted, fi)
        arrow(92f, 102f, 35f, pal.accent, eOut(seg(p, 0.42f, 0.5f)), fl)
        for (k in 0 until 2) {
            val st = if (k == 0) 0.5f else 0.62f
            val tt = seg(p, st, st + 0.12f)
            if (tt <= 0f) continue
            val cy = (if (k == 0) 16f else 52f) + 13f
            val s = back(tt)
            withTransform({
                translate(130f, cy)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-24f, -13f, 48f, 26f, 5f, StudyDark, fl)
                labelStart(t, if (k == 0) "DEC" else "HEX", -19f, -6f, StudyMuted, fl)
                label(t, if (k == 0) "10" else "hexA", 4f, 2f, Color.White, fl)
            }
        }
    },

    // Referencias: autor, título y año entran a la ficha y se elige APA, MLA o IEEE.
    ToolId.CITATION_GENERATOR to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        rr(14f, 24f, 26f, 36f, 2f, Color(0xFF7B4FB8), fi)
        rr(14f, 24f, 4f, 36f, 1f, Color(0xFF5B3790), fi)
        ln(22f, 32f, 36f, 32f, Color(0xFFE9DDFB), 1.4f, fi)
        ln(22f, 37f, 33f, 37f, Color(0xFFE9DDFB), 1.2f, fi)
        val cx = 58f; val cy = 26f; val cw = 98f; val ch = 52f
        rr(cx + 1.2f, cy + 1.6f, cw, ch, 4f, Color.Black, 0.22f * fi)
        rr(cx, cy, cw, ch, 4f, Paper, fi)
        label(t, "quotes", cx + 10f, cy + 12f, pal.accent, fi)
        for (i in 0 until 3) {
            val st = 0.06f + i * 0.1f
            val tt = eIO(seg(p, st, st + 0.16f))
            val tx = cx + 20f
            val ty = cy + 16f + i * 11f
            if (tt < 1f) {
                withTransform({ translate(lerp(28f, tx + 12f, tt), lerp(44f, ty, tt)) }) {
                    rr(-12f, -4.5f, 24f, 9f, 4.5f, pal.accent, fi)
                    label(t, CitationChips[i], 0f, 0.4f, StudyInk, fi)
                }
            } else {
                ln(tx, ty, tx + CitationLengths[i], ty, if (i == 1) Ink else Gray, if (i == 1) 2f else 1.6f, fl)
            }
        }
        val sel = when {
            p < 0.42f -> -1
            p < 0.55f -> 2
            p < 0.68f -> 1
            else -> 0
        }
        for (i in 0 until 3) {
            val x = cx + 16f + i * 28f
            val on = i == sel
            rr(x - 12f, 11f, 24f, 10f, 5f, if (on) pal.accent else StudyDark, fi)
            label(t, CitationTabs[i], x, 16.4f, if (on) StudyInk else StudyMuted, fi)
        }
    },

    // Exámenes: se marca la alternativa correcta, corre el tiempo y sale la nota.
    ToolId.EXAM_BUILDER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 18f; val y = 10f; val w = 98f; val h = 80f
        rr(x + 1.2f, y + 1.6f, w, h, 4f, Color.Black, 0.22f)
        rr(x, y, w, h, 4f, Paper)
        ln(x + 8f, y + 11f, x + 80f, y + 11f, Ink, 2.2f)
        ln(x + 8f, y + 17f, x + 60f, y + 17f, Gray, 1.5f)
        val pick = seg(p, 0.3f, 0.38f)
        for (i in 0 until 4) {
            val oy = y + 30f + i * 13f
            val chosen = i == 1 && pick > 0f
            val dimO = if (i != 1) 1f - 0.45f * pick else 1f
            if (chosen) rr(x + 5f, oy - 5.5f, w - 10f, 11f, 5.5f, OkGreen, 0.25f * pick * fl)
            dot(x + 12f, oy, 4.6f, if (chosen) OkGreen else Color(0xFFE3E8EE), fi)
            label(t, ExamOptions[i], x + 12f, oy + 0.4f, if (chosen) Color(0xFF06210F) else Color(0xFF5F6B7A), fi * dimO)
            ln(x + 21f, oy, x + 21f + (if (i % 2 == 1) 44f else 56f), oy, Gray, 1.5f, fi * dimO)
        }
        if (pick > 0f) {
            val ripple = 1f - seg(p, 0.28f, 0.4f)
            if (ripple > 0f && fl > 0f) {
                drawCircle(
                    OkGreen,
                    radius = lerp(2f, 10f, seg(p, 0.28f, 0.36f)),
                    center = Offset(x + 60f, y + 43f),
                    alpha = clamp01(ripple * fl),
                    style = Stroke(1.2f)
                )
            }
            check(x + w - 12f, y + 43f, 6f, Color(0xFF06210F), seg(p, 0.36f, 0.46f), fl)
        }
        val tc = 140f
        if (fi > 0f) drawCircle(StudyDark, 10f, Offset(tc, 26f), alpha = clamp01(fi), style = Stroke(3.5f))
        val left = 1f - eIO(seg(p, 0.05f, 0.55f)) * 0.7f
        if (fl > 0f) {
            drawArc(
                color = pal.accent, startAngle = -90f, sweepAngle = 360f * left, useCenter = false,
                topLeft = Offset(tc - 10f, 16f), size = Size(20f, 20f),
                alpha = clamp01(fl), style = Stroke(3.5f, cap = StrokeCap.Round)
            )
        }
        ln(tc, 26f, tc, 20f, Color.White, 1.2f, fi)
        ln(tc, 26f, tc + 4f, 26f, Color.White, 1.2f, fi)
        val st = seg(p, 0.58f, 0.7f)
        if (st > 0f) {
            val s = back(st)
            withTransform({
                translate(140f, 62f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-17f, -9f, 34f, 18f, 6f, OkGreen, fl)
                label(t, "18/20", 0f, 0.6f, Color(0xFF06210F), fl)
            }
        }
    },

    // Planificador: el pomodoro avanza, se llena el horario y suena el recordatorio.
    ToolId.STUDY_PLANNER_PRO to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val cx = 40f; val cy = 50f; val r = 24f
        if (fi > 0f) drawCircle(StudyDark, r, Offset(cx, cy), alpha = clamp01(fi), style = Stroke(6f))
        val tt = eIO(seg(p, 0.05f, 0.55f))
        if (tt > 0f && fl > 0f) {
            drawArc(
                color = pal.accent, startAngle = -90f, sweepAngle = 360f * tt, useCenter = false,
                topLeft = Offset(cx - r, cy - r), size = Size(r * 2f, r * 2f),
                alpha = clamp01(fl), style = Stroke(6f, cap = StrokeCap.Round)
            )
        }
        label(t, "25 min", cx, cy + 0.6f, Color.White, fi)
        val gx = 82f; val gy = 22f
        for (i in WeekDays.indices) label(t, WeekDays[i], gx + 6f + i * 15f, gy - 6f, StudyMuted, fi)
        for (col in 0 until 5) for (row in 0 until 3) rr(gx + col * 15f, gy + row * 17f, 12f, 14f, 2.5f, StudyDark, fi)
        for (i in PlannerFill.indices) {
            val f = seg(p, 0.12f + i * 0.05f, 0.2f + i * 0.05f)
            if (f <= 0f) continue
            val col = PlannerFill[i][0]
            val row = PlannerFill[i][1]
            val color = when (i % 3) { 0 -> pal.accent; 1 -> Teal; else -> SkyOrange }
            val s = back(f)
            withTransform({
                translate(gx + col * 15f + 6f, gy + row * 17f + 7f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-6f, -7f, 12f, 14f, 2.5f, color, fl)
            }
        }
        val bt = seg(p, 0.62f, 0.74f)
        if (bt > 0f) {
            val swing = sin(p * PI.toFloat() * 20f) * 0.25f * (1f - seg(p, 0.7f, 0.8f))
            val s = back(bt)
            withTransform({
                translate(cx + 20f, cy - 22f)
                rotate(swing * RAD_TO_DEG, pivot = Offset.Zero)
                scale(s, s, pivot = Offset.Zero)
            }) {
                dot(0f, 0f, 6.5f, Sun, fl)
                rr(-7f, 1f, 14f, 3f, 1.5f, Sun, fl)
                dot(0f, 5.4f, 1.8f, Sun, fl)
            }
        }
    },

    // Finanzas: las monedas crecen con el interés y los gastos se reparten en el anillo.
    ToolId.FINANCE_CALCULATOR to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        for (stack in 0 until 3) {
            val tt = eOut(seg(p, 0.06f + stack * 0.1f, 0.26f + stack * 0.1f))
            val n = (CoinStacks[stack] * tt).roundToInt()
            for (k in 0 until n) {
                val x = 14f + stack * 20f
                val y = 80f - k * 5f
                rr(x, y, 16f, 4.4f, 2.2f, Coin, fi * fl)
                ln(x + 3f, y + 2.2f, x + 13f, y + 2.2f, Color(0xFFC9962E), 0.8f, fi * fl)
            }
        }
        val ct = seg(p, 0.36f, 0.56f)
        if (ct > 0f && fl > 0f) {
            val steps = (20 * ct).toInt()
            val curve = Path().apply {
                for (i in 0..steps) {
                    val u = i / 20f
                    val x = 14f + u * 54f
                    val y = 70f - u.pow(1.8f) * 44f
                    if (i == 0) moveTo(x, y) else lineTo(x, y)
                }
            }
            drawPath(curve, Color.White, alpha = clamp01(fl), style = Stroke(1.6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        val pt = seg(p, 0.52f, 0.62f)
        if (pt > 0f) pill(t, "+12%", 58f, 18f, 24f, OkGreen, Color(0xFF06210F), fl, back(pt))
        val cx = 124f; val cy = 50f; val r = 20f
        if (fi > 0f) drawCircle(StudyDark, r, Offset(cx, cy), alpha = clamp01(fi), style = Stroke(8f))
        var a0 = -90f
        for (i in 0 until 3) {
            val fraction = when (i) { 0 -> 0.5f; 1 -> 0.3f; else -> 0.2f }
            val color = when (i) { 0 -> pal.accent; 1 -> Teal; else -> SkyOrange }
            val tt = eIO(seg(p, 0.2f + i * 0.12f, 0.34f + i * 0.12f))
            val sweep = 360f * fraction * tt - 3.4f
            if (sweep > 0f && fl > 0f) {
                drawArc(
                    color = color, startAngle = a0 + 1.7f, sweepAngle = sweep, useCenter = false,
                    topLeft = Offset(cx - r, cy - r), size = Size(r * 2f, r * 2f),
                    alpha = clamp01(fl), style = Stroke(8f)
                )
            }
            a0 += 360f * fraction
        }
    },

    // Flashcards: la tarjeta "?" gira, muestra la respuesta correcta y avanza el progreso.
    ToolId.FLASHCARDS to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        rr(58f, 24f, 60f, 58f, 6f, Color(0xFF5A3590), 0.6f * fi)
        rr(54f, 20f, 60f, 58f, 6f, Color(0xFF6A41A6), 0.8f * fi)
        val ft = seg(p, 0.2f, 0.4f)
        val sx = max(abs(cos(ft * PI.toFloat())), 0.02f)
        val showBack = ft > 0.5f
        withTransform({
            translate(80f, 46f)
            scale(sx, 1f, pivot = Offset.Zero)
        }) {
            if (!showBack) {
                rr(-32f, -30f, 64f, 60f, 6f, pal.accent, fi)
                label(t, "?", 0f, 1.5f, StudyInk, fi)
            } else {
                rr(-32f, -30f, 64f, 60f, 6f, Paper, fl)
                ln(-22f, -14f, 18f, -14f, Ink, 2.2f, fl)
                ln(-22f, -6f, 10f, -6f, Gray, 1.5f, fl)
                ln(-22f, 1f, 16f, 1f, Gray, 1.5f, fl)
                dot(18f, 16f, 7f, OkGreen, fl)
                check(18f, 16.4f, 7f, Color(0xFF06210F), seg(p, 0.42f, 0.52f), fl)
            }
        }
        for (i in 0 until 5) {
            val tt = seg(p, 0.48f + i * 0.06f, 0.54f + i * 0.06f)
            dot(60f + i * 10f, 90f, 2.6f, StudyDark, fi)
            if (tt > 0f) dot(60f + i * 10f, 90f, 2.6f * back(tt), pal.accent, fl)
        }
    },

    // Agenda académica: los cursos se marcan en el calendario y llega la tarea con ✓.
    ToolId.ACADEMIC_PLANNER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 14f; val y = 12f; val w = 72f; val h = 78f
        rr(x + 1.2f, y + 1.6f, w, h, 4f, Color.Black, 0.22f)
        rr(x, y, w, h, 4f, Paper)
        rr(x, y, w, 14f, 4f, Color(0xFF5B3790))
        label(t, "NOV", x + w / 2f, y + 7.4f, Color.White)
        for (r in 0 until 4) for (k in 0 until 5) rr(x + 6f + k * 13f, y + 20f + r * 14f, 10f, 10f, 2f, Color(0xFFE9EDF2))
        for (i in AgendaDots.indices) {
            val d = AgendaDots[i]
            val tt = seg(p, 0.08f + i * 0.06f, 0.16f + i * 0.06f)
            if (tt <= 0f) continue
            val color = when (d[2]) { 0 -> pal.accent; 1 -> Teal; else -> SkyOrange }
            dot(x + 11f + d[0] * 13f, y + 25f + d[1] * 14f, 3.4f * back(tt), color, fi * fl)
        }
        val ct = eOut(seg(p, 0.42f, 0.56f))
        if (ct > 0f) {
            val cx = 96f + lerp(30f, 0f, ct)
            val cy = 34f
            val a = ct * fl
            rr(cx + 1.2f, cy + 1.6f, 62f, 30f, 4f, Color.Black, 0.22f * a)
            rr(cx, cy, 62f, 30f, 4f, Paper, a)
            rr(cx, cy, 4f, 30f, 2f, pal.accent, a)
            ln(cx + 20f, cy + 10f, cx + 54f, cy + 10f, Ink, 2f, a)
            ln(cx + 20f, cy + 18f, cx + 46f, cy + 18f, Gray, 1.4f, a)
            rrStroke(cx + 8f, cy + 6f, 8f, 8f, 2f, Gray, 1.2f, a)
            val k = seg(p, 0.6f, 0.7f)
            if (k > 0f) {
                rr(cx + 8f, cy + 6f, 8f, 8f, 2f, OkGreen, fl * clamp01(k * 2f))
                check(cx + 12f, cy + 10.2f, 5.4f, Color(0xFF06210F), k, fl)
            }
        }
    },

    // Herramientas de texto: el texto desordenado se limpia y ordena, y "Aa" pasa a "AA".
    ToolId.TEXT_TOOLKIT to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 14f; val y = 14f
        rr(x, y, 80f, 72f, 5f, StudyDark, fi)
        val tt = eIO(seg(p, 0.1f, 0.45f))
        for (i in 0 until 5) {
            val target = TextLineOrder.indexOf(i)
            val ry = lerp(y + 12f + i * 12f, y + 12f + target * 12f, tt)
            val ox = lerp(TextLineOffsets[i], 0f, tt)
            val len = TextLineLengths[i]
            ln(x + 8f + ox, ry, x + 8f + ox + len, ry, if (i == 1 && tt < 0.5f) Color(0xFFFF8A8A) else Color(0xFFE9DDFB), 2f, fi)
            if (tt < 0.4f && i % 2 == 0) {
                val sq = x + 8f + ox + len * 0.4f
                val squiggle = Path().apply {
                    for (k in 0..8) {
                        val xx = sq + k * 1.5f
                        val yy = ry + 2.5f + (if (k % 2 == 1) 0.8f else -0.8f)
                        if (k == 0) moveTo(xx, yy) else lineTo(xx, yy)
                    }
                }
                val a = fi * (1f - tt * 2.5f)
                if (a > 0f) drawPath(squiggle, SoftRed, alpha = clamp01(a), style = Stroke(0.8f))
            }
        }
        val at = seg(p, 0.5f, 0.62f)
        if (at > 0f) {
            arrow(98f, 106f, 50f, pal.accent, eOut(at), fl)
            val s = back(at)
            withTransform({
                translate(130f, 50f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-22f, -14f, 44f, 28f, 7f, pal.accent, fl)
                label(t, if (p >= 0.62f) "AA" else "Aa", 0f, 1f, StudyInk, fl)
            }
        }
        val sp = seg(p, 0.62f, 0.72f)
        if (sp > 0f && sp < 1f) {
            for (k in 0 until 4) {
                val a = k * PI.toFloat() / 2f + 0.4f
                val d = lerp(22f, 32f, sp)
                dot(130f + cos(a) * d, 50f + sin(a) * d * 0.7f, 1.6f * (1f - sp), Sun, fl)
            }
        }
    }
,

    // -----------------------------------------------------------------------
    // Números y matemática
    // -----------------------------------------------------------------------

    // Calculadora científica: se presionan teclas, sale "= 14" y se dibuja la gráfica.
    ToolId.SCIENTIFIC_CALCULATOR to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 22f; val y = 8f; val w = 58f
        rr(x, y, w, 84f, 7f, PhoneDark, fi)
        rr(x + 5f, y + 6f, w - 10f, 20f, 3f, Color(0xFFDCEBFA), fi)
        for (i in 0 until 16) {
            val kx = x + 6f + (i % 4) * 12.5f
            val ky = y + 31f + (i / 4) * 12.5f
            rr(kx, ky, 10f, 10f, 2.5f, if (i % 4 == 3) pal.accent else Color(0xFF334155), fi)
        }
        for ((key, start) in CalcPresses) {
            val tt = seg(p, start, start + 0.06f)
            if (tt > 0f && tt < 1f) {
                val kx = x + 6f + (key % 4) * 12.5f
                val ky = y + 31f + (key / 4) * 12.5f
                rr(kx, ky, 10f, 10f, 2.5f, Color.White, 0.7f * sin(tt * PI.toFloat()) * fl)
            }
        }
        val res = seg(p, 0.4f, 0.5f)
        labelEnd(t, "2+3×4", x + w - 8f, y + 12f, Ink, fi * (1f - res * 0.4f))
        if (res > 0f) {
            val s = back(res)
            withTransform({
                translate(x + w - 8f, y + 21f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                labelEnd(t, "= 14", 0f, 0f, Color(0xFF0B4F8A), fl)
            }
        }
        val gx = 92f; val gy = 50f
        ln(gx, gy, gx + 64f, gy, Color.White, 0.8f, 0.4f * fi)
        ln(gx + 6f, 20f, gx + 6f, 80f, Color.White, 0.8f, 0.4f * fi)
        val ct = seg(p, 0.3f, 0.7f)
        if (ct > 0f && fl > 0f) {
            val steps = (40 * ct).toInt()
            val wave = Path().apply {
                for (i in 0..steps) {
                    val u = i / 40f
                    val xx = gx + 6f + u * 56f
                    val yy = gy - sin(u * PI.toFloat() * 2.4f) * 18f
                    if (i == 0) moveTo(xx, yy) else lineTo(xx, yy)
                }
            }
            drawPath(wave, pal.accent, alpha = clamp01(fl), style = Stroke(1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        labelStart(t, "sin x", gx + 40f, 24f, MathMuted, seg(p, 0.6f, 0.7f) * fl)
    },

    // Conversor: 100 cm → 1 m y 0 °C → 32 °F (la regla y el termómetro se llenan).
    ToolId.UNIT_CONVERTER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val rx = 14f; val ry = 18f
        rr(rx, ry, 74f, 14f, 2f, Color(0xFFF4D27A), fi)
        for (i in 0..14) {
            val xx = rx + 3f + i * 5f
            ln(xx, ry, xx, ry + (if (i % 5 == 0) 7f else 4f), Color(0xFF8A6A1E), 0.8f, fi)
        }
        rr(rx, ry + 15f, 74f * eOut(seg(p, 0.06f, 0.28f)), 3f, 1.5f, pal.accent, fi * fl)
        labelStart(t, "100 cm", rx, ry + 26f, Color.White, fi)
        val at = seg(p, 0.28f, 0.4f)
        if (at > 0f) {
            arrow(96f, 112f, ry + 7f, pal.accent, eOut(at), fl)
            val s = back(seg(p, 0.34f, 0.46f))
            withTransform({
                translate(136f, ry + 7f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-18f, -8f, 36f, 16f, 5f, MathDark, fl)
                label(t, "1 m", 0f, 0.4f, Color.White, fl)
            }
        }
        val tx = 30f; val ty = 56f
        rr(tx - 4f, ty, 8f, 30f, 4f, Color(0xFFE9EEF5), fi)
        dot(tx, ty + 32f, 6f, Color(0xFFE9EEF5), fi)
        dot(tx, ty + 32f, 4.2f, SoftRed, fi)
        val mt = eIO(seg(p, 0.45f, 0.66f))
        rr(tx - 2f, lerp(ty + 26f, ty + 6f, mt), 4f, lerp(6f, 26f, mt) + 2f, 1.5f, SoftRed, fi * fl)
        labelStart(t, "0 °C", tx + 12f, ty + 16f, Color.White, fi)
        val bt = seg(p, 0.62f, 0.72f)
        if (bt > 0f) {
            arrow(96f, 112f, ty + 16f, pal.accent, eOut(bt), fl)
            val s = back(seg(p, 0.66f, 0.78f))
            withTransform({
                translate(136f, ty + 16f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-18f, -8f, 36f, 16f, 5f, MathDark, fl)
                label(t, "32 °F", 0f, 0.4f, Color.White, fl)
            }
        }
    },

    // Porcentajes: la etiqueta S/ 80 recibe "-25%", queda en S/ 60 y la tajada sale del pastel.
    ToolId.PERCENT_RULE to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        if (fi > 0f) {
            val tag = Path().apply {
                moveTo(12f, 40f); lineTo(22f, 26f); lineTo(78f, 26f); lineTo(78f, 54f); lineTo(22f, 54f); close()
            }
            drawPath(tag, Paper, alpha = clamp01(fi))
        }
        dot(22f, 40f, 2.4f, MathInk, fi)
        val st = seg(p, 0.28f, 0.38f)
        label(t, "S/ 80", 50f, 40.5f, MathInk, fi * (1f - 0.45f * st))
        ln(36f, 41f, 64f, 39f, PdfRed, 1.6f, fl * st)
        val sk = seg(p, 0.12f, 0.24f)
        if (sk > 0f) {
            val s = lerp(2.2f, 1f, eOut(sk))
            val a = fl * clamp01(sk * 2f)
            withTransform({
                translate(70f, 26f)
                rotate(-0.2f * RAD_TO_DEG, pivot = Offset.Zero)
                scale(s, s, pivot = Offset.Zero)
            }) {
                dot(0f, 0f, 11f, PdfRed, a)
                label(t, "-25%", 0f, 0.4f, Color.White, a)
            }
        }
        val nt = seg(p, 0.38f, 0.5f)
        if (nt > 0f) {
            val s = back(nt)
            withTransform({
                translate(46f, 72f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-20f, -9f, 40f, 18f, 6f, OkGreen, fl)
                label(t, "S/ 60", 0f, 0.6f, Color(0xFF06210F), fl)
            }
        }
        val cx = 128f; val cy = 50f; val r = 22f
        if (fi > 0f) {
            drawArc(pal.accent, 0f, 270f, true, Offset(cx - r, cy - r), Size(r * 2f, r * 2f), alpha = clamp01(fi))
            val pull = eOut(seg(p, 0.5f, 0.66f)) * 6f
            val ox = 0.7071f * pull
            val oy = -0.7071f * pull
            drawArc(PdfRed, -90f, 90f, true, Offset(cx - r + ox, cy - r + oy), Size(r * 2f, r * 2f), alpha = clamp01(fi))
        }
    },

    // Promedios y notas: suben las notas, aparece el promedio y el sello "Aprobado".
    ToolId.GRADES_AVERAGES to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val base = 82f
        ln(14f, base, 96f, base, Color.White, 0.8f, 0.4f * fi)
        for (i in 0 until 4) {
            val tt = eOut(seg(p, 0.06f + i * 0.08f, 0.24f + i * 0.08f))
            val bx = 20f + i * 19f
            val bh = GradeValues[i] * 3f * tt
            rr(bx, base - bh, 12f, bh, 2f, if (GradeValues[i] < 11f) SoftRed else pal.accent, fi * fl)
            label(t, GradeLabels[i], bx + 6f, base - bh - 5f, Color.White, fi * fl * clamp01(tt * 3f))
        }
        val at = seg(p, 0.44f, 0.56f)
        if (at > 0f) {
            val ay = base - 13.25f * 3f
            if (fl > 0f) {
                drawLine(
                    Sun, Offset(14f, ay), Offset(14f + 82f * eOut(at), ay),
                    strokeWidth = 1f, alpha = clamp01(fl * at), pathEffect = DashEffect
                )
            }
            val s = back(at)
            withTransform({
                translate(128f, 36f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-22f, -8f, 44f, 16f, 5f, MathDark, fl)
                label(t, "Prom. 13", 0f, 0.4f, Sun, fl)
            }
        }
        val pt = seg(p, 0.6f, 0.72f)
        if (pt > 0f) {
            val s = lerp(1.8f, 1f, eOut(pt))
            val a = fl * clamp01(pt * 2f)
            withTransform({
                translate(128f, 64f)
                rotate(-0.14f * RAD_TO_DEG, pivot = Offset.Zero)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rrStroke(-24f, -8f, 48f, 16f, 4f, OkGreen, 1.6f, a)
                label(t, "Aprobado", 0f, 0.4f, OkGreen, a)
            }
        }
    },

    // Geometría: se dibuja el triángulo (6 y 8), se pinta su área "A = 24" y gira el radio del círculo.
    ToolId.GEOMETRY to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val ft = eOut(seg(p, 0.4f, 0.52f))
        if (ft > 0f && fl > 0f) {
            val area = Path().apply {
                moveTo(TriangleX[0], TriangleY[0]); lineTo(TriangleX[1], TriangleY[1]); lineTo(TriangleX[2], TriangleY[2]); close()
            }
            drawPath(area, pal.accent, alpha = clamp01(0.35f * ft * fl))
        }
        val et = seg(p, 0.06f, 0.38f) * 3f
        if (et > 0f) {
            val edges = Path().apply {
                moveTo(TriangleX[0], TriangleY[0])
                for (k in 0 until 3) {
                    val e = clamp01(et - k)
                    if (e <= 0f) break
                    lineTo(lerp(TriangleX[k], TriangleX[k + 1], e), lerp(TriangleY[k], TriangleY[k + 1], e))
                }
            }
            val a = fi * (if (et < 3f) 1f else fl)
            if (a > 0f) drawPath(edges, Color.White, alpha = clamp01(a), style = Stroke(1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        if (et > 1.2f) rrStroke(22f, 74f, 6f, 6f, 0f, Color.White, 1f, fi * fl)
        label(t, "6", 14f, 56f, MathMuted, fi * clamp01(et - 0.5f))
        label(t, "8", 52f, 88f, MathMuted, fi * clamp01(et - 1.5f))
        val at = seg(p, 0.52f, 0.64f)
        if (at > 0f) {
            val s = back(at)
            withTransform({
                translate(42f, 66f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                label(t, "A = 24", 0f, 0f, Color.White, fl)
            }
        }
        val cx = 128f; val cy = 50f; val r = 22f
        val rt = eIO(seg(p, 0.3f, 0.62f))
        if (rt > 0f && fl > 0f) {
            drawArc(pal.accent, 0f, 360f * rt, true, Offset(cx - r, cy - r), Size(r * 2f, r * 2f), alpha = clamp01(0.18f * fl * rt))
            drawArc(
                pal.accent, 0f, 360f * rt, false, Offset(cx - r, cy - r), Size(r * 2f, r * 2f),
                alpha = clamp01(fl), style = Stroke(1.8f, cap = StrokeCap.Round)
            )
        }
        val ang = 2f * PI.toFloat() * rt
        ln(cx, cy, cx + cos(ang) * r, cy + sin(ang) * r, Color.White, 1.4f, fi * fl)
        dot(cx, cy, 2f, Color.White, fi)
        label(t, "r", cx + cos(ang) * r * 0.5f, cy + sin(ang) * r * 0.5f - 4f, Color.White, fi * fl * clamp01(rt * 4f))
    }
,

    // -----------------------------------------------------------------------
    // Ciencias y análisis
    // -----------------------------------------------------------------------

    // Matemática avanzada: se arma una matriz con su determinante y se pinta la integral.
    ToolId.ADVANCED_MATH to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val bx = 14f; val by = 24f; val bw = 46f; val bh = 44f
        for (side in 0 until 2) {
            val x = if (side == 0) bx else bx + bw
            val d = if (side == 0) 1f else -1f
            ln(x, by, x, by + bh, Color.White, 1.6f, fi)
            ln(x, by, x + 5f * d, by, Color.White, 1.6f, fi)
            ln(x, by + bh, x + 5f * d, by + bh, Color.White, 1.6f, fi)
        }
        for (i in 0 until 4) {
            val tt = seg(p, 0.06f + i * 0.06f, 0.14f + i * 0.06f)
            if (tt <= 0f) continue
            val s = back(tt)
            withTransform({
                translate(bx + 13f + (i % 2) * 20f, by + 13f + (i / 2) * 18f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                label(t, MatrixCells[i], 0f, 0.5f, Color.White, fi * fl)
            }
        }
        val dt = seg(p, 0.34f, 0.46f)
        if (dt > 0f) pill(t, "det = 6", bx + bw / 2f, 84f, 34f, pal.accent, SciInk, fl, back(dt))
        val gx = 74f; val base = 76f
        ln(gx, base, gx + 84f, base, Color.White, 0.8f, 0.4f * fi)
        ln(gx + 4f, 16f, gx + 4f, base, Color.White, 0.8f, 0.4f * fi)
        val at = eIO(seg(p, 0.46f, 0.7f))
        if (at > 0f && fl > 0f) {
            val x1 = gx + 20f
            val x2 = gx + 20f + 48f * at
            val area = Path().apply {
                moveTo(x1, base)
                var x = x1
                while (x <= x2) {
                    lineTo(x, base - 10f - sin((x - gx) / 84f * PI.toFloat()) * 42f)
                    x += 2f
                }
                lineTo(x2, base)
                close()
            }
            drawPath(area, pal.accent, alpha = clamp01(0.35f * fl))
        }
        if (fi > 0f) {
            val curve = Path().apply {
                var x = gx + 4f
                moveTo(x, base - 10f - sin((x - gx) / 84f * PI.toFloat()) * 42f)
                while (x <= gx + 82f) {
                    x += 2f
                    lineTo(x, base - 10f - sin((x - gx) / 84f * PI.toFloat()) * 42f)
                }
            }
            drawPath(curve, pal.accent, alpha = clamp01(fi), style = Stroke(1.8f))
        }
        val it2 = seg(p, 0.42f, 0.54f)
        if (it2 > 0f) {
            val s = back(it2)
            withTransform({
                translate(gx + 16f, 28f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                label(t, "integral", 0f, 0f, Color.White, fl)
            }
        }
    },

    // Ecuaciones: los pasos se escriben solos hasta "x = 3" con ✓.
    ToolId.EQUATION_SOLVER to ToolScene { p, _, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        rr(14f, 10f, 112f, 80f, 6f, SciDark, fi)
        revealText(t, "2x + 4 = 10", 24f, 28f, Color.White, seg(p, 0.06f, 0.24f), fi * fl)
        if (p > 0.24f) ln(40f, 36f, 40f, 40f, SciMuted, 1f, fl * seg(p, 0.24f, 0.28f))
        revealText(t, "2x = 6", 24f, 48f, Color.White, seg(p, 0.28f, 0.42f), fl)
        val ft = seg(p, 0.46f, 0.58f)
        if (ft > 0f) {
            rr(20f, 60f, 52f, 18f, 5f, OkGreen, 0.25f * ft * fl)
            revealText(t, "x = 3", 26f, 69.5f, OkGreen, ft, fl)
        }
        val ct = seg(p, 0.62f, 0.74f)
        if (ct > 0f) {
            dot(146f, 69f, 9f * back(ct), OkGreen, fl)
            check(146f, 69.5f, 9f, Color(0xFF06210F), seg(p, 0.66f, 0.78f), fl)
        }
    },

    // Graficador: se dibujan una recta, una parábola y una onda sobre la cuadrícula.
    ToolId.FUNCTION_GRAPHER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val ox = 86f; val oy = 52f
        var gx = 22f
        while (gx <= 150f) { ln(gx, 14f, gx, 90f, Color.White, 0.5f, 0.12f * fi); gx += 16f }
        var gy = 20f
        while (gy <= 86f) { ln(18f, gy, 156f, gy, Color.White, 0.5f, 0.12f * fi); gy += 16f }
        ln(18f, oy, 156f, oy, Color.White, 1f, 0.6f * fi)
        ln(ox, 14f, ox, 90f, Color.White, 1f, 0.6f * fi)
        label(t, "x", 152f, oy - 5f, SciMuted, fi)
        label(t, "y", ox + 5f, 16f, SciMuted, fi)
        for (k in 0 until 3) {
            val start = 0.08f + k * 0.22f
            val tt = seg(p, start, start + 0.22f)
            if (tt <= 0f || fl <= 0f) continue
            val x0 = if (k == 1) 50f else 22f
            val x1 = if (k == 1) 122f else 150f
            val xe = lerp(x0, x1, tt)
            val color = when (k) { 0 -> pal.accent; 1 -> SkyOrange; else -> SkyPurple }
            val curve = Path().apply {
                var x = x0
                while (x <= xe) {
                    val y = when (k) {
                        0 -> oy - (x - ox) * 0.45f
                        1 -> 30f + ((x - ox) / 36f).pow(2) * 50f
                        else -> oy - sin((x - 22f) / 128f * PI.toFloat() * 3f) * 16f
                    }
                    if (x == x0) moveTo(x, y) else lineTo(x, y)
                    x += 2f
                }
            }
            drawPath(curve, color, alpha = clamp01(fl), style = Stroke(1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    },

    // Estadística: suben las barras, aparece la campana, la media y el diagrama de caja.
    ToolId.STATISTICS to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val base = 80f
        ln(10f, base, 104f, base, Color.White, 0.8f, 0.4f * fi)
        for (i in HistogramBars.indices) {
            val tt = eOut(seg(p, 0.05f + i * 0.035f, 0.2f + i * 0.035f))
            val h = HistogramBars[i] * tt
            rr(14f + i * 10f, base - h, 8f, h, 1.5f, pal.accent, 0.85f * fi * fl)
        }
        val ct = seg(p, 0.42f, 0.62f)
        if (ct > 0f && fl > 0f) {
            val xe = lerp(10f, 104f, ct)
            val bell = Path().apply {
                var x = 10f
                while (x <= xe) {
                    val u = (x - 58f) / 18f
                    val y = base - 44f * exp(-u * u / 2f)
                    if (x == 10f) moveTo(x, y) else lineTo(x, y)
                    x += 2f
                }
            }
            drawPath(bell, Color.White, alpha = clamp01(fl), style = Stroke(1.6f))
        }
        val mt = seg(p, 0.6f, 0.7f)
        if (mt > 0f) {
            if (fl > 0f) drawLine(Sun, Offset(58f, 30f), Offset(58f, base), strokeWidth = 1f, alpha = clamp01(fl * mt), pathEffect = DashEffect)
            val s = back(mt)
            withTransform({
                translate(134f, 32f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-22f, -8f, 44f, 16f, 5f, SciDark, fl)
                label(t, "Media 14", 0f, 0.4f, Sun, fl)
            }
        }
        val bt = seg(p, 0.68f, 0.8f)
        if (bt > 0f) {
            val y = 62f
            val a = fl * bt
            ln(110f, y, 158f, y, Color.White, 1f, a)
            rr(122f, y - 6f, 24f, 12f, 2f, pal.accent, a * 0.9f)
            ln(133f, y - 6f, 133f, y + 6f, SciDark, 1.4f, a)
            ln(110f, y - 4f, 110f, y + 4f, Color.White, 1f, a)
            ln(158f, y - 4f, 158f, y + 4f, Color.White, 1f, a)
        }
    },

    // Física: una fuerza empuja el bloque (F = m·a) y se enciende el foco.
    ToolId.PHYSICS_CALCULATOR to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        ln(10f, 78f, 104f, 78f, Color.White, 1f, 0.5f * fi)
        var hx = 12f
        while (hx < 104f) { ln(hx, 78f, hx - 4f, 84f, Color.White, 0.6f, 0.25f * fi); hx += 8f }
        val tt = eIO(seg(p, 0.08f, 0.5f))
        val bx = lerp(16f, 70f, tt)
        val speed = sin(tt * PI.toFloat()) * fl
        for (k in 0 until 3) ln(bx - 4f - k * 2f, 66f + k * 4f, bx - 12f - k * 4f, 66f + k * 4f, Color.White, 1f, 0.5f * speed)
        rr(bx, 62f, 20f, 16f, 3f, pal.accent, fi)
        arrow(bx - 18f, bx - 2f, 70f, SkyOrange, 1f, fi * seg(p, 0.04f, 0.12f) * (1f - seg(p, 0.5f, 0.6f)))
        label(t, "F = m·a", 56f, 26f, Color.White, seg(p, 0.18f, 0.3f) * fl)
        val cx = 136f; val cy = 44f
        val on = seg(p, 0.56f, 0.64f)
        if (on > 0f) {
            val pulse = 0.85f + 0.15f * sin(p * PI.toFloat() * 12f)
            dot(cx, cy, 22f * pulse, Sun, 0.18f * on * fl)
            for (k in 0 until 8) {
                val a = k * PI.toFloat() / 4f
                ln(cx + cos(a) * 16f, cy + sin(a) * 16f, cx + cos(a) * (20f + 3f * pulse), cy + sin(a) * (20f + 3f * pulse), Sun, 1.4f, on * fl)
            }
        }
        val lit = on > 0f
        dot(cx, cy, 12f, if (lit) Color(0xFFFFE58A) else Color(0xFF2C5A60), fi)
        rr(cx - 6f, cy + 10f, 12f, 10f, 2f, Gray, fi)
        ln(cx - 6f, cy + 14f, cx + 6f, cy + 14f, Color(0xFF5F6B7A), 0.8f, fi)
        ln(cx - 6f, cy + 17f, cx + 6f, cy + 17f, Color(0xFF5F6B7A), 0.8f, fi)
        val filament = if (lit) Color(0xFFC9962E) else Color(0xFF7FA9AE)
        ln(cx - 4f, cy + 4f, cx, cy - 3f, filament, 1f, fi)
        ln(cx, cy - 3f, cx + 4f, cy + 4f, filament, 1f, fi)
    },

    // Tabla periódica: se encienden los grupos por color y el Hierro (Fe) se agranda en su ficha.
    ToolId.PERIODIC_TABLE to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val cs = 5.2f; val x0 = 8f; val y0 = 16f
        val idle = Color(0xFF1E474C)
        for (r in 0 until 7) {
            for (col in 0 until 18) {
                if (!periodicHasCell(r, col)) continue
                val lit = seg(p, 0.04f + col * 0.02f, 0.12f + col * 0.02f) > 0f
                rr(x0 + col * cs, y0 + r * cs, cs - 1f, cs - 1f, 0.8f, if (lit) periodicGroupColor(col, pal.accent) else idle, fi * (if (lit) 0.85f else 1f))
            }
        }
        for (r in 0 until 2) {
            for (k in 0 until 14) {
                val lit = seg(p, 0.4f + k * 0.005f, 0.46f + k * 0.005f) > 0f
                rr(x0 + (3 + k) * cs, y0 + 7.6f * cs + r * cs, cs - 1f, cs - 1f, 0.8f, if (lit) Color(0xFF8FE3B0) else idle, fi)
            }
        }
        val zt = eOut(seg(p, 0.48f, 0.64f))
        if (zt > 0f) {
            val fx = x0 + 7f * cs
            val fy = y0 + 3f * cs
            val x = lerp(fx, 114f, zt)
            val y = lerp(fy, 22f, zt)
            val w = lerp(cs - 1f, 44f, zt)
            val h = lerp(cs - 1f, 54f, zt)
            rr(x, y, w, h, lerp(0.8f, 5f, zt), Color(0xFF5CC8D1), fl)
            if (zt > 0.6f) {
                val a = clamp01((zt - 0.6f) / 0.4f) * fl
                labelStart(t, "26", x + 5f, y + 8f, SciInk, a)
                label(t, "Fe", x + w / 2f, y + h / 2f + 1f, SciInk, a)
                label(t, "55.85", x + w / 2f, y + h - 8f, SciInk, a)
            }
        }
    },

    // Química: se arma la molécula de agua (H₂O), se llena el matraz y sale "18 g/mol".
    ToolId.CHEMISTRY_CALCULATOR to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val ox = 44f; val oy = 44f
        val bt = seg(p, 0.18f, 0.32f)
        ln(ox, oy, lerp(ox, 26f, bt), lerp(oy, 62f, bt), Color.White, 2f, fi * fl)
        ln(ox, oy, lerp(ox, 62f, bt), lerp(oy, 62f, bt), Color.White, 2f, fi * fl)
        val ot = seg(p, 0.04f, 0.16f)
        if (ot > 0f) {
            val s = back(ot)
            withTransform({
                translate(ox, oy)
                scale(s, s, pivot = Offset.Zero)
            }) {
                dot(0f, 0f, 12f, SoftRed, fi * fl)
                label(t, "O", 0f, 0.5f, Color.White, fi * fl)
            }
        }
        for (i in 0 until 2) {
            val ht = seg(p, 0.26f + i * 0.06f, 0.36f + i * 0.06f)
            if (ht <= 0f) continue
            val s = back(ht)
            withTransform({
                translate(if (i == 0) 26f else 62f, 62f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                dot(0f, 0f, 7f, Paper, fi * fl)
                label(t, "H", 0f, 0.4f, Color(0xFF113A3F), fi * fl)
            }
        }
        val fx = 128f
        if (fi > 0f) {
            val flask = Path().apply {
                moveTo(fx - 6f, 16f); lineTo(fx - 6f, 36f); lineTo(fx - 22f, 72f)
                lineTo(fx - 21f, 76f); lineTo(fx - 17f, 78f); lineTo(fx + 17f, 78f)
                lineTo(fx + 21f, 76f); lineTo(fx + 22f, 72f); lineTo(fx + 6f, 36f); lineTo(fx + 6f, 16f)
            }
            drawPath(flask, Color.White, alpha = clamp01(fi), style = Stroke(1.4f, join = StrokeJoin.Round))
        }
        val lv = eIO(seg(p, 0.38f, 0.6f))
        if (lv > 0f && fl > 0f) {
            val ly = lerp(77f, 52f, lv)
            val half = 6f + (ly - 36f) / (72f - 36f) * 16f
            val liquid = Path().apply {
                moveTo(fx - half, ly); lineTo(fx + half, ly); lineTo(fx + 21f, 76.5f); lineTo(fx - 21f, 76.5f); close()
            }
            drawPath(liquid, pal.accent, alpha = clamp01(0.8f * fl))
            for (k in 0 until 3) {
                val bp = (p * 3f + k * 0.33f) % 1f
                dot(fx - 8f + k * 8f, lerp(74f, ly + 2f, bp), 1.4f, Color.White, 0.7f * fl * lv * (1f - bp))
            }
        }
        val rt = seg(p, 0.62f, 0.74f)
        if (rt > 0f) pill(t, "18 g/mol", fx, 89f, 40f, OkGreen, Color(0xFF06210F), fl, back(rt))
    }
,

    // -----------------------------------------------------------------------
    // Visores
    // -----------------------------------------------------------------------

    // Visor PDF: las páginas se desplazan, se resalta lo buscado y la lupa amplía.
    ToolId.PDF_VIEWER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val vx = 16f; val vy = 10f; val vw = 70f; val vh = 80f
        rr(vx, vy, vw, vh, 6f, ViewerDark, fi)
        val off = eIO(seg(p, 0.06f, 0.5f)) * 48f
        clipRect(vx + 4f, vy + 4f, vx + vw - 4f, vy + vh - 4f) {
            for (k in 0 until 4) {
                val py = vy + 8f + k * 48f - off
                page(vx + 10f, py, vw - 20f, 42f, fi, 4)
                if (k == 2 && p > 0.5f) {
                    rr(vx + 16f, py + 42f * 0.45f - 2.5f, 32f * seg(p, 0.5f, 0.6f), 5f, 1.5f, Sun, 0.6f * fl)
                }
            }
        }
        badge(t, "PDF", vx + 12f, vy + 6f, PdfRed, fi)
        rr(vx + vw / 2f - 14f, vy + vh - 11f, 28f, 9f, 4.5f, Color.Black, 0.5f * fi)
        label(t, if (p < 0.3f) "1 / 12" else "3 / 12", vx + vw / 2f, vy + vh - 6.2f, Color.White, fi)
        val mt = eOut(seg(p, 0.58f, 0.74f))
        if (mt > 0f && fl > 0f) {
            val mx = lerp(60f, 126f, mt)
            val my = lerp(56f, 46f, mt)
            val r = 20f
            val lens = Path().apply { addOval(Rect(mx - r, my - r, mx + r, my + r)) }
            clipPath(lens) {
                rr(mx - r, my - r, 2f * r, 2f * r, 0f, Paper, fl)
                ln(mx - 16f, my - 8f, mx + 14f, my - 8f, PaperLine, 3f, fl)
                rr(mx - 16f, my - 1f, 26f, 6f, 2f, Sun, 0.6f * fl)
                ln(mx - 16f, my + 10f, mx + 10f, my + 10f, PaperLine, 3f, fl)
            }
            drawCircle(pal.accent, r, Offset(mx, my), alpha = clamp01(fl), style = Stroke(3f))
            ln(mx + r * 0.72f, my + r * 0.72f, mx + r * 1.15f, my + r * 1.15f, pal.accent, 4.5f, fl)
        }
    },

    // Visor Word: el documento se muestra (título, párrafos y tabla) y el ojo indica "solo lectura".
    ToolId.WORD_VIEWER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 26f; val y = 8f; val w = 78f; val h = 84f
        rr(x + 1.2f, y + 1.6f, w, h, 3f, Color.Black, 0.22f)
        rr(x, y, w, h, 3f, Paper)
        val ys = floatArrayOf(12f, 22f, 28f, 34f, 44f, 52f)
        val lens = floatArrayOf(50f, 62f, 56f, 60f, 36f, 58f)
        for (i in 0 until 6) {
            val tt = seg(p, 0.06f + i * 0.06f, 0.14f + i * 0.06f)
            val color = when (i) { 0 -> Ink; 4 -> Color(0xFF3D7BFF); else -> Gray }
            val lw = when (i) { 0 -> 2.8f; 4 -> 2.2f; else -> 1.5f }
            ln(x + 8f, y + ys[i], x + 8f + lens[i] * eOut(tt), y + ys[i], color, lw, fi * clamp01(tt * 4f))
        }
        val tt = seg(p, 0.44f, 0.58f)
        if (tt > 0f) {
            val tx = x + 8f; val ty = y + 60f; val tw = 62f; val th = 18f
            val a = fl * tt
            rr(tx, ty, tw, 9f, 0f, Color(0xFF3D7BFF), 0.25f * a)
            if (a > 0f) drawRect(Gray, Offset(tx, ty), Size(tw, th), alpha = clamp01(a), style = Stroke(0.8f))
            ln(tx, ty + 9f, tx + tw, ty + 9f, Gray, 0.8f, a)
            ln(tx + tw / 3f, ty, tx + tw / 3f, ty + th, Gray, 0.8f, a)
            ln(tx + tw * 2f / 3f, ty, tx + tw * 2f / 3f, ty + th, Gray, 0.8f, a)
        }
        badge(t, "DOCX", x + 12f, y + 2f, Color(0xFF3D7BFF), fi)
        val et = seg(p, 0.6f, 0.72f)
        if (et > 0f && fl > 0f) {
            val blink = if (abs(sin(p * PI.toFloat() * 3f)) > 0.97f) 0.2f else 1f
            val s = back(et)
            withTransform({
                translate(136f, 50f)
                scale(s, s * blink, pivot = Offset.Zero)
            }) {
                drawOval(pal.accent, Offset(-18f, -10f), Size(36f, 20f), alpha = clamp01(fl), style = Stroke(2.4f))
                dot(0f, 0f, 5.5f, pal.accent, fl)
                dot(0f, 0f, 2.4f, Color(0xFF233244), fl)
            }
        }
    },

    // Visor Excel: la hoja se llena, la selección baja por la columna y sale la suma.
    ToolId.EXCEL_VIEWER to ToolScene { p, _, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 14f; val y = 14f; val cw = 26f; val ch = 12f
        rr(x - 1f, y - 1f, 4 * cw + 12f, 5 * ch + 2f, 3f, Paper, fi)
        rr(x + 10f, y, 4 * cw, ch, 0f, ExcelGreen, fi)
        for (i in 0 until 4) label(t, SheetCols[i], x + 10f + i * cw + cw / 2f, y + 6.4f, Color.White, fi)
        for (r in 1 until 5) label(t, SheetRows[r - 1], x + 5f, y + r * ch + 6.4f, Color(0xFF5F6B7A), fi)
        for (i in 0..4) ln(x + 10f + i * cw, y, x + 10f + i * cw, y + 5 * ch, Color(0xFFC9D3DD), 0.6f, 0.6f * fi)
        for (r in 0..5) ln(x, y + r * ch, x + 10f + 4 * cw, y + r * ch, Color(0xFFC9D3DD), 0.6f, 0.6f * fi)
        for (i in 0 until 16) {
            val r = 1 + i / 4
            val k = i % 4
            val tt = seg(p, 0.06f + i * 0.025f, 0.12f + i * 0.025f)
            rr(x + 12f + k * cw, y + r * ch + 4f, (cw - 6f) * SheetValues[i] * eOut(tt), 4f, 1.5f, if (k == 3) ExcelGreen else Gray, fi * fl * clamp01(tt * 3f))
        }
        val st = eIO(seg(p, 0.5f, 0.7f))
        val sr = 1 + (3f * st).roundToInt()
        rrStroke(x + 10f + 3 * cw, y + sr * ch, cw, ch, 1f, ExcelGreen, 1.8f, fl * seg(p, 0.48f, 0.52f))
        badge(t, "XLSX", 150f, y + 4f, ExcelGreen, fi)
        val tt = seg(p, 0.72f, 0.82f)
        if (tt > 0f) pill(t, "Σ 2,450", 150f, y + 40f, 34f, ExcelGreen, Color.White, fl, back(tt))
    },

    // Visor PowerPoint: las diapositivas pasan (título, barras, pastel) con su tira de miniaturas.
    ToolId.POWERPOINT_VIEWER to ToolScene { p, _, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val sx = 30f; val sy = 10f; val sw = 96f; val sh = 54f
        rr(sx + 1.2f, sy + 1.6f, sw, sh, 3f, Color.Black, 0.22f * fi)
        val slide = when { p < 0.3f -> 0; p < 0.6f -> 1; else -> 2 }
        val tr = when { p < 0.3f -> 0f; p < 0.6f -> seg(p, 0.3f, 0.38f); else -> seg(p, 0.6f, 0.68f) }
        clipRect(sx, sy, sx + sw, sy + sh) {
            if (tr > 0f && tr < 1f) {
                drawSlide(slide - 1, sx - sw * eIO(tr), sy, sw, sh, fi)
                drawSlide(slide, sx + sw * (1f - eIO(tr)), sy, sw, sh, fi)
            } else {
                drawSlide(slide, sx, sy, sw, sh, fi)
            }
        }
        for (i in 0 until 3) {
            val tx = sx + 14f + i * 24f
            val ty = sy + sh + 8f
            rr(tx, ty, 20f, 12f, 2f, if (i == slide) Paper else Color(0xFF4A5D75), fi)
            if (i == slide) rrStroke(tx - 1.5f, ty - 1.5f, 23f, 15f, 3f, PptOrange, 1.4f, fl)
        }
        badge(t, "PPTX", sx + sw - 4f, sy - 1f, PptOrange, fi)
    },

    // -----------------------------------------------------------------------
    // Herramientas rápidas
    // -----------------------------------------------------------------------

    // QR y códigos de barras: el QR se arma punto por punto, se escanea y sale ✓.
    ToolId.QR_TOOL to ToolScene { p, pal, _ ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 20f; val y = 12f; val m = 6.6f; val n = QR_SIZE
        rr(x - 4f, y - 4f, n * m + 8f, n * m + 8f, 4f, Color.White, fi)
        for (corner in 0 until 3) {
            val fr = if (corner == 1) 0 else if (corner == 2) 8 else 0
            val fc = if (corner == 1) 8 else 0
            val r0 = if (corner == 2) 8 else fr
            rr(x + fc * m, y + r0 * m, 3 * m, 3 * m, 1.5f, QrInk, fi)
            rr(x + fc * m + m * 0.6f, y + r0 * m + m * 0.6f, 3 * m - m * 1.2f, 3 * m - m * 1.2f, 1f, Color.White, fi)
            rr(x + fc * m + m, y + r0 * m + m, m, m, 0.8f, QrInk, fi)
        }
        val order = QrOrder
        val shown = (order.size * eOut(seg(p, 0.05f, 0.45f))).toInt()
        val dotAlpha = clamp01(fi * fl)
        for (i in 0 until shown) {
            val idx = order[i]
            val r = idx / n
            val k = idx % n
            drawRect(QrInk, Offset(x + k * m + 0.4f, y + r * m + 0.4f), Size(m - 0.8f, m - 0.8f), alpha = dotAlpha)
        }
        val st = seg(p, 0.5f, 0.72f)
        if (st > 0f && st < 1f) {
            val ly = y - 2f + (n * m + 4f) * eIO(st)
            ln(x - 6f, ly, x + n * m + 6f, ly, pal.accent, 2f, fl)
            rr(x - 4f, ly - 6f, n * m + 8f, 6f, 0f, pal.accent, 0.18f * fl)
        }
        val ct = seg(p, 0.72f, 0.84f)
        if (ct > 0f) {
            dot(x + n * m, y, 8f * back(ct), OkGreen, fl)
            check(x + n * m, y + 0.5f, 8f, Color(0xFF06210F), seg(p, 0.76f, 0.86f), fl)
        }
        val bx = 114f; val by = 22f
        rr(bx - 4f, by - 4f, 48f, 50f, 3f, Color.White, fi)
        var cx = bx
        for (i in BarcodeWidths.indices) {
            val w = BarcodeWidths[i] * 1.3f
            val tt = seg(p, 0.2f + i * 0.015f, 0.26f + i * 0.015f)
            if (i % 2 == 0 && tt > 0f) rr(cx, by, w, 38f * eOut(tt), 0f, QrInk, fi * fl)
            cx += w + 0.8f
        }
    },

    // Contador de palabras: se escribe el texto, sube el conteo y sale el tiempo de lectura.
    ToolId.WORD_COUNTER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val x = 14f; val y = 12f
        rr(x, y, 82f, 76f, 5f, QuickDark, fi)
        var lastX = -1f
        var lastY = 0f
        for (i in WordCounterLines.indices) {
            val tt = seg(p, 0.05f + i * 0.07f, 0.12f + i * 0.07f)
            if (tt <= 0f) continue
            val ly = y + 12f + i * 9f
            val len = WordCounterLines[i] * tt
            ln(x + 8f, ly, x + 8f + len, ly, Color(0xFFE3F7F4), 1.6f, fi * fl)
            lastX = x + 8f + len + 2f
            lastY = ly
        }
        if (lastX >= 0f && p < 0.56f && (p * 14f).toInt() % 2 == 0) ln(lastX, lastY - 3f, lastX, lastY + 3f, pal.accent, 1.1f, fl)
        val count = when { p < 0.22f -> "12 palabras"; p < 0.42f -> "64 palabras"; else -> "128 palabras" }
        rr(134f - 28f, 32f - 10f, 56f, 20f, 6f, pal.accent, fi)
        label(t, count, 134f, 32.5f, SciInk, fi)
        val rt = seg(p, 0.58f, 0.7f)
        if (rt > 0f) {
            val s = back(rt)
            withTransform({
                translate(134f, 62f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-28f, -9f, 56f, 18f, 6f, QuickDark, fl)
                dot(-17f, 0f, 5f, Color.White, fl)
                ln(-17f, 0f, -17f, -3f, QuickDark, 1f, fl)
                ln(-17f, 0f, -15f, 0f, QuickDark, 1f, fl)
                label(t, "1 min", 4f, 0.5f, Color.White, fl)
            }
        }
    },

    // Cronómetro y temporizador: se presiona el botón, la aguja gira y salen Estudio 25:00 y Descanso 5:00.
    ToolId.STOPWATCH_TIMER to ToolScene { p, pal, t ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        val cx = 48f; val cy = 56f; val r = 27f
        val press = 1f - 0.12f * sin(PI.toFloat() * seg(p, 0.02f, 0.08f))
        rr(cx - 5f, cy - r - 11f * press, 10f, 6f, 2f, Gray, fi)
        rr(cx - 2f, cy - r - 6f, 4f, 6f, 1f, Gray, fi)
        dot(cx, cy, r + 3f, QuickDark, fi)
        dot(cx, cy, r, Paper, fi)
        for (i in 0 until 12) {
            val a = i / 12f * 2f * PI.toFloat()
            ln(cx + cos(a) * (r - 3f), cy + sin(a) * (r - 3f), cx + cos(a) * (r - 6f), cy + sin(a) * (r - 6f), Gray, if (i % 3 == 0) 1.6f else 1f, fi)
        }
        val tt = eIO(seg(p, 0.06f, 0.7f))
        if (tt > 0f && fl > 0f) {
            drawArc(pal.accent, -90f, 360f * tt, true, Offset(cx - (r - 2f), cy - (r - 2f)), Size((r - 2f) * 2f, (r - 2f) * 2f), alpha = clamp01(0.3f * fl))
        }
        val a = -PI.toFloat() / 2f + tt * 2f * PI.toFloat() * 3f
        ln(cx, cy, cx + cos(a) * (r - 6f), cy + sin(a) * (r - 6f), PdfRed, 1.6f, fi)
        dot(cx, cy, 2.4f, Ink, fi)
        for (i in 0 until 2) {
            val st = if (i == 0) 0.2f else 0.45f
            val rt = seg(p, st, st + 0.12f)
            if (rt <= 0f) continue
            val s = back(rt)
            withTransform({
                translate(130f, 34f + i * 26f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                rr(-28f, -10f, 56f, 20f, 6f, if (i == 0) pal.accent else QuickDark, fl)
                labelStart(t, if (i == 0) "Estudio" else "Descanso", -24f, -4f, if (i == 0) SciInk else Color(0xFFA8D5CF), fl)
                labelEnd(t, if (i == 0) "25:00" else "5:00", 24f, 3f, if (i == 0) SciInk else Color.White, fl)
            }
        }
    },

    // -----------------------------------------------------------------------
    // Juego (tarjeta de Geo Aventuras en Herramientas; el juego no cambia)
    // -----------------------------------------------------------------------

    // Un personaje salta entre plataformas, recoge monedas y aparece un corazón dorado.
    ToolId.GEO_ADVENTURES to ToolScene { p, pal, _ ->
        val fl = fadeLoop(p)
        val fi = fadeIn(p)
        for (k in 0 until 3) {
            val px = 10f + k * 54f
            val py = 72f - k * 14f
            rr(px, py, 42f, 10f, 3f, Color(0xFF2C5A7A), fi)
            rr(px, py, 42f, 3.5f, 2f, OkGreen, fi)
        }
        for (k in 0 until 2) {
            val coinX = if (k == 0) 58f else 112f
            val coinY = if (k == 0) 36f else 22f
            val taken = if (k == 0) 0.22f else 0.52f
            if (p <= taken) {
                val spin = max(abs(cos(p * PI.toFloat() * 6f)), 0.15f)
                withTransform({
                    translate(coinX, coinY)
                    scale(spin, 1f, pivot = Offset.Zero)
                }) {
                    dot(0f, 0f, 4.6f, Sun, fi)
                    dot(0f, 0f, 2.6f, Coin, fi)
                }
            } else {
                val sp = seg(p, taken, taken + 0.1f)
                if (sp < 1f) {
                    for (i in 0 until 5) {
                        val ang = i * 2f * PI.toFloat() / 5f
                        dot(coinX + cos(ang) * 8f * sp, coinY + sin(ang) * 8f * sp, 1.6f * (1f - sp), Sun, fl)
                    }
                }
            }
        }
        val j1 = seg(p, 0.1f, 0.34f)
        val j2 = seg(p, 0.4f, 0.64f)
        val hx: Float
        val hy: Float
        if (j2 > 0f) {
            hx = lerp(85f, 139f, eIO(j2))
            hy = lerp(51f, 37f, j2) - sin(PI.toFloat() * j2) * 22f
        } else {
            hx = lerp(31f, 85f, eIO(j1))
            hy = lerp(65f, 51f, j1) - sin(PI.toFloat() * j1) * 22f
        }
        val squash = 1f + 0.12f * sin(p * PI.toFloat() * 30f) * (1f - seg(p, 0.64f, 0.7f))
        withTransform({
            translate(hx, hy)
            scale(1f / squash, squash, pivot = Offset.Zero)
        }) {
            dot(0f, 0f, 7f, pal.accent, fi)
            dot(-2.4f, -1.5f, 1.6f, Color(0xFF102E45), fi)
            dot(2.4f, -1.5f, 1.6f, Color(0xFF102E45), fi)
        }
        val ht = seg(p, 0.68f, 0.8f)
        if (ht > 0f && fl > 0f) {
            val s = back(ht)
            withTransform({
                translate(150f, 18f)
                scale(s, s, pivot = Offset.Zero)
            }) {
                val heart = Path().apply {
                    addOval(Rect(-6.6f, -4.6f, 0.6f, 2.6f))
                    addOval(Rect(-0.6f, -4.6f, 6.6f, 2.6f))
                    moveTo(-6.4f, 0f); lineTo(6.4f, 0f); lineTo(0f, 7.5f); close()
                }
                drawPath(heart, Sun, alpha = clamp01(fl))
            }
        }
    }
)

/** Diapositivas del visor PowerPoint: 0 = título, 1 = barras, 2 = pastel. */
private fun DrawScope.drawSlide(k: Int, x: Float, y: Float, w: Float, h: Float, alpha: Float) {
    rr(x, y, w, h, 3f, Paper, alpha)
    rr(x, y, w, 12f, 0f, PptOrange, alpha)
    ln(x + 8f, y + 6f, x + 50f, y + 6f, Color.White, 2f, alpha)
    when (k) {
        0 -> {
            ln(x + 10f, y + 24f, x + 70f, y + 24f, Ink, 3f, alpha)
            ln(x + 10f, y + 34f, x + 56f, y + 34f, Gray, 1.6f, alpha)
            ln(x + 10f, y + 41f, x + 62f, y + 41f, Gray, 1.6f, alpha)
        }
        1 -> for (i in SlideBars.indices) {
            rr(x + 14f + i * 14f, y + 50f - SlideBars[i], 9f, SlideBars[i], 1.5f, if (i == 3) PptOrange else PptSoft, alpha)
        }
        else -> if (alpha > 0f) {
            val r = 15f
            drawArc(PptOrange, -90f, 234f, true, Offset(x + 48f - r, y + 32f - r), Size(r * 2f, r * 2f), alpha = clamp01(alpha))
            drawArc(PptSoft, 144f, 126f, true, Offset(x + 48f - r, y + 32f - r), Size(r * 2f, r * 2f), alpha = clamp01(alpha))
        }
    }
}
