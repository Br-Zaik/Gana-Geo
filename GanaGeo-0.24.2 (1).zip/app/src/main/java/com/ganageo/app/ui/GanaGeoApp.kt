package com.ganageo.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.app.Activity
import android.content.Context
import android.text.format.DateUtils
import android.widget.Toast
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.TableChart
import com.ganageo.app.data.RecentFile
import com.ganageo.app.data.RecentFilesTracker
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.TextFields
import com.google.android.play.core.review.ReviewManagerFactory
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import com.ganageo.app.ui.theme.MutedGreen
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Gavel
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Policy
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.SupportAgent
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Handyman
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Redeem
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScaffoldDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material.icons.rounded.Animation
import com.ganageo.app.ui.tools.WeekSummaryCard
import com.ganageo.app.ui.tools.rewardsInLastWeek
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ganageo.app.AuthPhase
import com.ganageo.app.GanaGeoUiState
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.R
import com.ganageo.app.model.DashboardData
import com.ganageo.app.model.LedgerEntry
import com.ganageo.app.model.ToolCategory
import com.ganageo.app.model.ToolId
import com.ganageo.app.ui.tools.ToolThumbnail
import com.ganageo.app.ui.tools.ToolsCatalogCategories
import com.ganageo.app.ui.tools.categoryAccentColor
import com.ganageo.app.ui.tools.categoryContainerColor
import com.ganageo.app.ui.tools.toolsInCategory
import com.ganageo.app.model.Withdrawal
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.tools.ToolsScreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.sin

private val penFormatter: NumberFormat = NumberFormat.getCurrencyInstance(Locale("es", "PE"))

@Composable
fun GanaGeoApp(
    viewModel: GanaGeoViewModel,
    onGoogleLogin: () -> Unit,
    onSignOut: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    val requestGoogleLogin: () -> Unit = {
        if (!uiState.isLoading) {
            onGoogleLogin()
        }
    }

    // Calificación en Google Play: una sola vez, al volver de una herramienta.
    val context = LocalContext.current
    LaunchedEffect(uiState.reviewPromptRequested) {
        if (!uiState.reviewPromptRequested) return@LaunchedEffect
        viewModel.consumeReviewPrompt()
        context.findActivityForReview()?.let { activity -> launchInAppReview(activity) }
    }

    // Tamaño de letra elegido en Perfil (se suma al del celular).
    val baseDensity = LocalDensity.current
    val textFactor = TextSizeFactors[uiState.textSizeStep.coerceIn(0, TextSizeFactors.lastIndex)]
    val appDensity = remember(baseDensity, textFactor) {
        Density(
            density = baseDensity.density,
            fontScale = (baseDensity.fontScale * textFactor).coerceAtMost(2f)
        )
    }

    CompositionLocalProvider(LocalDensity provides appDensity) {
    Box(modifier = Modifier.fillMaxSize()) {
        when (uiState.authPhase) {
            AuthPhase.ConfigurationMissing -> ConfigurationMissingScreen()
            AuthPhase.Initializing -> {
                if (uiState.dashboard != null) {
                    MainShell(
                        uiState = uiState,
                        viewModel = viewModel,
                        onRefresh = viewModel::refreshDashboard,
                        onWithdraw = viewModel::requestWithdrawal,
                        onCancelWithdrawal = viewModel::cancelWithdrawal,
                        onSignOut = onSignOut,
                        onNoticeShown = viewModel::clearNotice
                    )
                } else {
                    LoadingScreen("Preparando Gana Geo…")
                }
            }
            AuthPhase.CompletingSignIn -> LoadingScreen("Finalizando el acceso con Google…")
            AuthPhase.SignedOut -> {
                LaunchedEffect(Unit) { viewModel.enterGuestMode() }
                LoadingScreen("Abriendo como invitado…")
            }
            AuthPhase.Guest -> GuestToolsShell(
                uiState = uiState,
                viewModel = viewModel,
                onGoogleLogin = requestGoogleLogin,
                onNoticeShown = viewModel::clearNotice
            )
            AuthPhase.DeviceConflict -> DeviceConflictScreen(
                message = uiState.deviceConflictMessage
                    ?: "La instalación actual no tiene autorización para usar esta cuenta.",
                error = uiState.error,
                loading = uiState.isLoading,
                canReplace = uiState.canReplaceDevice,
                onReplace = viewModel::replacePreviousInstallation,
                onRetry = viewModel::refreshDashboard,
                onChangeAccount = onSignOut
            )
            AuthPhase.SignedIn -> MainShell(
                uiState = uiState,
                viewModel = viewModel,
                onRefresh = viewModel::refreshDashboard,
                onWithdraw = viewModel::requestWithdrawal,
                onCancelWithdrawal = viewModel::cancelWithdrawal,
                onSignOut = onSignOut,
                onNoticeShown = viewModel::clearNotice
            )
        }
    }
    }
}

@Composable
private fun ConfigurationMissingScreen() {
    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.logo_gana_geo),
                contentDescription = "Logo Gana Geo",
                modifier = Modifier.size(142.dp)
            )
            Spacer(Modifier.height(24.dp))
            Text("Falta conectar Supabase", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text(
                "Copia local.properties.example como local.properties y pega la clave pública publishable/anon de tu proyecto. Nunca pegues service_role ni el Client Secret de Google dentro de la app.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun LoadingScreen(text: String) {
    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator(color = NeonGreen)
            Spacer(Modifier.height(16.dp))
            Text(text)
        }
    }
}

@Composable
private fun DeviceConflictScreen(
    message: String,
    error: String?,
    loading: Boolean,
    canReplace: Boolean,
    onReplace: () -> Unit,
    onRetry: () -> Unit,
    onChangeAccount: () -> Unit
) {
    var showConfirmation by rememberSaveable { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(Gold.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Lock,
                    contentDescription = null,
                    tint = Gold,
                    modifier = Modifier.size(38.dp)
                )
            }
            Spacer(Modifier.height(20.dp))
            Text(
                if (canReplace) "Tu cuenta está en otro celular" else "No se puede abrir aquí",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            Text(
                message,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            if (!error.isNullOrBlank()) {
                Spacer(Modifier.height(16.dp))
                NoticeCard(error, isError = true)
            }

            Spacer(Modifier.height(26.dp))
            if (canReplace) {
                Button(
                    onClick = { showConfirmation = true },
                    enabled = !loading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonGreen,
                        contentColor = DeepGreen
                    )
                ) {
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                            color = DeepGreen
                        )
                    } else {
                        Text("Usar mi cuenta aquí", fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            OutlinedButton(
                onClick = onRetry,
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Reintentar")
            }
            TextButton(onClick = onChangeAccount, enabled = !loading) {
                Icon(Icons.Rounded.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Usar otra cuenta")
            }
        }
    }

    if (showConfirmation) {
        AlertDialog(
            onDismissRequest = { if (!loading) showConfirmation = false },
            title = { Text("¿Usar tu cuenta en este celular?") },
            text = {
                Text(
                    "El otro celular se cerrará. Puedes cambiar hasta 3 veces al mes y " +
                        "los retiros a Yape se activan 24 horas después del cambio."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmation = false
                        onReplace()
                    },
                    enabled = !loading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonGreen,
                        contentColor = DeepGreen
                    )
                ) {
                    Text("Sí, usar aquí")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showConfirmation = false },
                    enabled = !loading
                ) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
private fun LoginScreen(
    loading: Boolean,
    error: String?,
    onGoogleLogin: () -> Unit,
    onGuest: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.logo_gana_geo),
                contentDescription = "Logo Gana Geo",
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(180.dp)
            )
            Spacer(Modifier.height(24.dp))
            Text("Gana Geo", style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(8.dp))
            Text(
                "Encuestas, ofertas y recompensas verificadas en un solo lugar.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(28.dp))

            Button(
                onClick = onGoogleLogin,
                enabled = !loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonGreen,
                    contentColor = DeepGreen
                )
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = DeepGreen
                    )
                } else {
                    Text("Continuar con Google", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = onGuest,
                enabled = !loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Rounded.Person, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Entrar como invitado", fontWeight = FontWeight.Bold)
            }
            Text(
                "Acceso sin cuenta a herramientas gratuitas que funcionan localmente.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp)
            )

            if (!error.isNullOrBlank()) {
                Spacer(Modifier.height(16.dp))
                NoticeCard(error, isError = true)
            }

            Spacer(Modifier.height(22.dp))
            Text(
                "Las herramientas son lo principal. Geo Rewards es un beneficio adicional por usar créditos comprados.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun GuestToolsShell(
    uiState: GanaGeoUiState,
    viewModel: GanaGeoViewModel,
    onGoogleLogin: () -> Unit,
    onNoticeShown: () -> Unit
) {
    var immersiveContent by remember { mutableStateOf(false) }
    var showLegal by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    if (showLegal) LegalCenterDialog(
        textSizeStep = uiState.textSizeStep,
        onTextSize = viewModel::setTextSize,
        animationsEnabled = uiState.animationsEnabled,
        onAnimationsChange = viewModel::setAnimationsEnabled,
        onDismiss = { showLegal = false }
    )

    // Atajos del ícono: herramienta gratis se abre; premium pide iniciar sesión.
    var toolsEpoch by remember { mutableIntStateOf(0) }
    LaunchedEffect(uiState.shortcutToolName) {
        val name = uiState.shortcutToolName ?: return@LaunchedEffect
        viewModel.consumeShortcut()
        val tool = ToolId.entries.firstOrNull { it.name == name } ?: return@LaunchedEffect
        if (tool.creditCost > 0) {
            viewModel.requestLoginForTool(name)
        } else {
            immersiveContent = false
            viewModel.rememberTool(name)
            toolsEpoch++
        }
    }

    val lockedToolName = uiState.loginPromptToolName
    if (lockedToolName != null) {
        val toolTitle = remember(lockedToolName) {
            runCatching { ToolId.valueOf(lockedToolName).title }.getOrNull()
        }
        LoginPromptSheet(
            toolTitle = toolTitle,
            enabled = !uiState.isLoading,
            onContinue = {
                viewModel.acceptLoginPrompt()
                onGoogleLogin()
            },
            onDismiss = viewModel::dismissLoginPrompt
        )
    }

    LaunchedEffect(uiState.error, uiState.message) {
        val notice = uiState.error ?: uiState.message
        if (!notice.isNullOrBlank()) {
            snackbarHostState.showSnackbar(notice)
            onNoticeShown()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = if (immersiveContent) WindowInsets(0, 0, 0, 0) else ScaffoldDefaults.contentWindowInsets,
        topBar = {
            if (!immersiveContent) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding(),
                    color = Color(0xFF061D12),
                    shadowElevation = 0.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(R.drawable.logo_gana_geo),
                            contentDescription = null,
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Gana Geo",
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { showLegal = true }) {
                            Icon(Icons.Rounded.Info, contentDescription = "Ayuda y ajustes", tint = Color(0xFF9AB8A5))
                        }
                        Button(
                            onClick = onGoogleLogin,
                            enabled = !uiState.isLoading,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonGreen,
                                contentColor = DeepGreen
                            ),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text("Iniciar sesión", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            if (immersiveContent) Modifier.fillMaxSize()
            else Modifier.fillMaxSize().padding(padding)
        ) {
            Column(Modifier.fillMaxSize()) {
                if (!immersiveContent) OfflineBanner(visible = uiState.isOffline)
                Box(Modifier.weight(1f)) {
                    key(toolsEpoch) {
                        ToolsScreen(
                            uiState = uiState,
                            viewModel = viewModel,
                            guestMode = true,
                            onImmersiveChanged = { immersiveContent = it }
                        )
                    }
                }
            }
        }
    }
}

private data class TabItem(
    val label: String,
    val icon: ImageVector
)

@Composable
private fun MainShell(
    uiState: GanaGeoUiState,
    viewModel: GanaGeoViewModel,
    onRefresh: () -> Unit,
    onWithdraw: (String, String, String) -> Unit,
    onCancelWithdrawal: (String) -> Unit,
    onSignOut: () -> Unit,
    onNoticeShown: () -> Unit
) {
    var selectedTab by remember {
        mutableIntStateOf(viewModel.rememberedMainTab.coerceIn(0, GanaGeoViewModel.MAIN_TAB_COUNT - 1))
    }
    var immersiveContent by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.message, uiState.error, uiState.dashboard) {
        val notice = if (uiState.dashboard != null) uiState.error ?: uiState.message else uiState.message
        if (!notice.isNullOrBlank()) {
            snackbarHostState.showSnackbar(notice)
            onNoticeShown()
        }
    }

    // 3 pestañas, sin pantallas repetidas: Herramientas (principal, con
    // "Continuar", favoritos y archivos), Billetera (saldo, Rewards, tu semana
    // y retiros) y Perfil (cuenta, ajustes, legal y ayuda).
    val tabs = remember {
        listOf(
            TabItem("Herramientas", Icons.Rounded.Handyman),
            TabItem("Billetera", Icons.Rounded.AccountBalanceWallet),
            TabItem("Perfil", Icons.Rounded.Person)
        )
    }

    val goToTab: (Int) -> Unit = { index ->
        immersiveContent = false
        selectedTab = index
        viewModel.rememberMainTab(index)
    }
    var toolsEpoch by remember { mutableIntStateOf(0) }
    val openTool: (String) -> Unit = { toolName ->
        viewModel.rememberTool(toolName)
        goToTab(GanaGeoViewModel.TAB_TOOLS)
    }

    // Atajos del ícono (mantener presionado Gana Geo en el inicio del celular).
    LaunchedEffect(uiState.shortcutToolName) {
        val name = uiState.shortcutToolName ?: return@LaunchedEffect
        viewModel.consumeShortcut()
        viewModel.rememberTool(name)
        toolsEpoch++
        goToTab(GanaGeoViewModel.TAB_TOOLS)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = if (immersiveContent) WindowInsets(0, 0, 0, 0) else ScaffoldDefaults.contentWindowInsets,
        bottomBar = {
            if (!immersiveContent) NavigationBar(containerColor = Color(0xFF061D12)) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { goToTab(index) },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepGreen,
                            selectedTextColor = NeonGreen,
                            indicatorColor = NeonGreen,
                            unselectedIconColor = Color(0xFF9AB8A5),
                            unselectedTextColor = Color(0xFF9AB8A5)
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = if (immersiveContent) Modifier.fillMaxSize()
            else Modifier.fillMaxSize().padding(padding)
        ) {
            val dashboard = uiState.dashboard
            if (dashboard == null && uiState.isLoading) {
                DashboardSkeleton()
            } else if (dashboard == null) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        if (uiState.isOffline) Icons.Rounded.CloudOff else Icons.Rounded.ErrorOutline,
                        contentDescription = null,
                        tint = if (uiState.isOffline) Color(0xFF9AB8A5) else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(46.dp)
                    )
                    Spacer(Modifier.height(14.dp))
                    Text(
                        if (uiState.isOffline) "Sin internet. Conéctate y toca Reintentar."
                        else uiState.error ?: "No se pudo cargar tu cuenta.",
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    OutlinedButton(onClick = onRefresh, enabled = !uiState.isLoading) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Reintentar")
                    }
                    TextButton(onClick = onSignOut, enabled = !uiState.isLoading) {
                        Text("Cambiar de cuenta")
                    }
                }
            } else {
                when (selectedTab) {
                    GanaGeoViewModel.TAB_TOOLS -> key(toolsEpoch) {
                        ToolsScreen(
                            uiState,
                            viewModel,
                            onImmersiveChanged = { immersiveContent = it }
                        )
                    }
                    GanaGeoViewModel.TAB_WALLET -> WalletScreen(
                        dashboard = dashboard,
                        weeklyToolUses = uiState.weeklyToolUses,
                        hideBalances = uiState.hideBalances,
                        onToggleHide = viewModel::toggleHideBalances,
                        onBuyCredits = {
                            viewModel.rememberTool(null)
                            viewModel.rememberToolsCategory("Todas")
                            goToTab(GanaGeoViewModel.TAB_TOOLS)
                        },
                        onWithdraw = onWithdraw,
                        onCancelWithdrawal = onCancelWithdrawal
                    )
                    else -> ProfileScreen(
                        dashboard = dashboard,
                        textSizeStep = uiState.textSizeStep,
                        onTextSize = viewModel::setTextSize,
                        animationsEnabled = uiState.animationsEnabled,
                        onAnimationsChange = viewModel::setAnimationsEnabled,
                        onSignOut = onSignOut,
                        onDeleteAccount = viewModel::deleteAccount
                    )
                }
            }

            if (!immersiveContent) {
                Box(Modifier.align(Alignment.TopCenter).fillMaxWidth()) {
                    OfflineBanner(visible = uiState.isOffline)
                }
            }

            if (uiState.isLoading && dashboard != null) {
                // Barra fina arriba en vez de oscurecer la pantalla.
                // Bloquea toques mientras guarda, sin tapar el contenido.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        )
                ) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .align(Alignment.TopCenter),
                        color = NeonGreen,
                        trackColor = Color.Transparent
                    )
                }
            }
        }
    }
}

/** Lo que se muestra en lugar de los montos cuando el usuario los oculta (ojito). */
private const val HIDDEN_AMOUNT = "••••"

@Composable
private fun BalanceCard(
    title: String,
    value: String,
    description: String,
    icon: ImageVector,
    accent: Color,
    footer: @Composable (() -> Unit)? = null
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color(0xFF1E5A3A)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(accent.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = accent)
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.labelLarge, color = MutedGreen)
                    Text(
                        value,
                        style = MaterialTheme.typography.headlineSmall.copy(fontFeatureSettings = "tnum"),
                        color = accent,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(description, style = MaterialTheme.typography.bodySmall, color = MutedGreen)
            if (footer != null) {
                Spacer(Modifier.height(10.dp))
                footer()
            }
        }
    }
}

@Composable
private fun HowItWorksRow() {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text("¿Cómo funciona?", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.Top) {
                HowStep(Icons.Rounded.ShoppingCart, "Compras créditos", NeonGreen, Modifier.weight(1f))
                Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MutedGreen, modifier = Modifier.padding(top = 10.dp))
                HowStep(Icons.Rounded.Handyman, "Los usas", NeonGreen, Modifier.weight(1f))
                Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MutedGreen, modifier = Modifier.padding(top = 10.dp))
                HowStep(Icons.Rounded.Redeem, "Ganas Rewards", Gold, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun HowStep(icon: ImageVector, label: String, accent: Color, modifier: Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(accent.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = accent)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
    }
}

private enum class LedgerFilter(val label: String) { ALL("Todo"), REWARDS("Rewards"), WITHDRAWALS("Retiros") }

private fun LedgerEntry.matches(filter: LedgerFilter): Boolean = when (filter) {
    LedgerFilter.ALL -> true
    LedgerFilter.REWARDS -> entryType in setOf("tool_reward", "game_reward", "referral_reward", "purchase_points")
    LedgerFilter.WITHDRAWALS -> entryType in setOf("withdrawal", "reversal", "adjustment")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WalletScreen(
    dashboard: DashboardData,
    weeklyToolUses: Int,
    hideBalances: Boolean,
    onToggleHide: () -> Unit,
    onBuyCredits: () -> Unit,
    onWithdraw: (String, String, String) -> Unit,
    onCancelWithdrawal: (String) -> Unit
) {
    var showWithdrawDialog by rememberSaveable { mutableStateOf(false) }
    var openDoc by remember { mutableStateOf<LegalDoc?>(null) }
    var filter by rememberSaveable { mutableStateOf(LedgerFilter.ALL) }
    val features = dashboard.features
    val canWithdraw = features.withdrawalsEnabled &&
        dashboard.wallet.availableAmount >= features.minWithdrawal
    val filteredLedger = remember(dashboard.ledger, filter) { dashboard.ledger.filter { it.matches(filter) } }
    fun money(value: Double) = if (hideBalances) "S/ $HIDDEN_AMOUNT" else penFormatter.format(value)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "wallet_title", contentType = "header") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Billetera",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onToggleHide) {
                    Icon(
                        if (hideBalances) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                        contentDescription = if (hideBalances) "Mostrar saldo" else "Ocultar saldo",
                        tint = MutedGreen
                    )
                }
            }
        }

        item(key = "wallet_credits", contentType = "balance") {
            BalanceCard(
                title = "Créditos",
                value = if (hideBalances) HIDDEN_AMOUNT else dashboard.toolCredits.availableCredits.toString(),
                description = "Para usar herramientas de pago. Se compran con Google Play y no se cambian por dinero.",
                icon = Icons.Rounded.Bolt,
                accent = NeonGreen
            ) {
                Button(
                    onClick = onBuyCredits,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) {
                    Text("Comprar créditos · S/ 5 o S/ 10", fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }

        item(key = "wallet_rewards", contentType = "balance") {
            BalanceCard(
                title = "Geo Rewards",
                value = if (hideBalances) HIDDEN_AMOUNT else dashboard.wallet.internalPoints.toString(),
                description = "Puntos de fidelidad: cada 10 créditos comprados que usas = 50 Rewards.",
                icon = Icons.Rounded.Redeem,
                accent = Gold
            ) {
                Text(
                    "Ver reglas de Geo Rewards",
                    color = Gold,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { openDoc = LegalDoc.REWARDS }
                        .padding(vertical = 6.dp)
                )
            }
        }

        item(key = "wallet_soles", contentType = "balance") {
            BalanceCard(
                title = "Saldo en soles",
                value = money(dashboard.wallet.availableAmount),
                description = if (dashboard.wallet.lockedAmount > 0) {
                    "En revisión: ${money(dashboard.wallet.lockedAmount)}. Solo se retira por Yape."
                } else {
                    "Lo que podrás retirar por Yape (mínimo S/ ${"%.0f".format(features.minWithdrawal)})."
                },
                icon = Icons.Rounded.AccountBalanceWallet,
                accent = Color(0xFFEAF5EE)
            ) {
                Button(
                    onClick = { showWithdrawDialog = true },
                    enabled = canWithdraw,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) {
                    Icon(Icons.Rounded.Payments, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (features.withdrawalsEnabled) "Retirar por Yape" else "Retiro por Yape · pronto")
                }
            }
        }

        item(key = "wallet_how", contentType = "info") { HowItWorksRow() }

        item(key = "wallet_week", contentType = "week") {
            val recentFiles by RecentFilesTracker.files.collectAsStateWithLifecycle()
            val filesThisWeek = remember(recentFiles) { RecentFilesTracker.createdThisWeek() }
            val rewardsThisWeek = remember(dashboard.ledger) { rewardsInLastWeek(dashboard.ledger) }
            WeekSummaryCard(
                toolUses = weeklyToolUses,
                files = filesThisWeek,
                rewards = rewardsThisWeek,
                hideBalances = hideBalances
            )
        }

        if (dashboard.withdrawals.isNotEmpty()) {
            item(key = "wallet_requests_title", contentType = "section_title") {
                Text("Solicitudes de retiro", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            items(dashboard.withdrawals, key = { "w_${it.id}" }, contentType = { "withdrawal" }) { withdrawal ->
                WithdrawalRow(withdrawal, onCancelWithdrawal)
            }
        }

        item(key = "wallet_history_title", contentType = "section_title") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Movimientos",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                LedgerFilter.entries.forEach { option ->
                    val selected = option == filter
                    Text(
                        option.label,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (selected) DeepGreen else MutedGreen,
                        modifier = Modifier
                            .padding(start = 6.dp)
                            .clip(RoundedCornerShape(50))
                            .background(if (selected) NeonGreen else Color.White.copy(alpha = 0.06f))
                            .clickable { filter = option }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
        if (filteredLedger.isEmpty()) {
            item(key = "wallet_history_empty", contentType = "empty") {
                EmptyCard(
                    if (filter == LedgerFilter.ALL) "Aún no tienes movimientos. Tus Rewards aparecerán aquí."
                    else "No hay movimientos de este tipo."
                )
            }
        } else {
            items(filteredLedger, key = { "l_${it.id}" }, contentType = { "ledger" }) { entry ->
                LedgerRow(entry)
            }
        }
    }

    if (showWithdrawDialog) {
        WithdrawalDialog(
            available = dashboard.wallet.availableAmount,
            minimum = features.minWithdrawal,
            onDismiss = { showWithdrawDialog = false },
            onSubmit = { amount, destination ->
                showWithdrawDialog = false
                onWithdraw(amount, "yape", destination)
            }
        )
    }

    openDoc?.let { doc -> LegalDialog(doc = doc, onDismiss = { openDoc = null }) }
}

@Composable
private fun WithdrawalDialog(
    available: Double,
    minimum: Double,
    onDismiss: () -> Unit,
    onSubmit: (String, String) -> Unit
) {
    var amount by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    val amountValue = amount.replace(',', '.').toDoubleOrNull()
    val phoneOk = GanaGeoViewModel.isValidYapePhone(phone)
    val amountOk = amountValue != null && amountValue >= minimum && amountValue <= available

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Retirar por Yape") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Disponible: ${penFormatter.format(available)} · mínimo ${penFormatter.format(minimum)}")
                OutlinedTextField(
                    value = amount,
                    onValueChange = { input -> amount = input.filter { it.isDigit() || it == '.' || it == ',' }.take(8) },
                    label = { Text("Monto en soles") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    isError = amount.isNotBlank() && !amountOk
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { input -> phone = input.filter { it.isDigit() || it == '+' || it == ' ' }.take(15) },
                    label = { Text("Número de Yape (9 dígitos)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    isError = phone.isNotBlank() && !phoneOk
                )
                Text(
                    "El número debe estar a tu nombre. El retiro queda en revisión y se paga manualmente por Yape. No hay pagos automáticos.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(amount, phone) },
                enabled = amountOk && phoneOk,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
                Text("Enviar solicitud")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun WithdrawalRow(withdrawal: Withdrawal, onCancel: (String) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(penFormatter.format(withdrawal.amount), fontWeight = FontWeight.Bold)
                    Text(
                        "${withdrawal.paymentMethod.replaceFirstChar { it.uppercase() }} · ${maskPhone(withdrawal.paymentDestination)}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                StatusChip(withdrawal.status)
            }
            if (!withdrawal.rejectionReason.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(withdrawal.rejectionReason, color = MaterialTheme.colorScheme.error)
            }
            if (withdrawal.status in setOf("pending", "under_review")) {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { onCancel(withdrawal.id) }) {
                    Icon(Icons.Rounded.Cancel, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Cancelar solicitud")
                }
            }
        }
    }
}

private fun maskPhone(raw: String): String {
    val digits = raw.filter(Char::isDigit)
    return if (digits.length >= 4) "••• ${digits.takeLast(3)}" else raw
}

@Composable
private fun StatusChip(status: String) {
    val (label, color) = when (status) {
        "paid" -> "Pagado" to NeonGreen
        "approved" -> "Aprobado" to Gold
        "rejected" -> "Rechazado" to MaterialTheme.colorScheme.error
        "cancelled" -> "Cancelado" to Color(0xFF9AB8A5)
        "under_review" -> "En revisión" to Gold
        else -> "Pendiente" to Color(0xFF74C7FF)
    }
    Text(
        label,
        color = color,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(100.dp))
            .background(color.copy(alpha = 0.13f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    )
}

private fun readableAccountStatus(status: String): String = when (status) {
    "active" -> "Cuenta activa"
    "inactive" -> "Cuenta inactiva"
    "under_review" -> "Cuenta en revisión"
    "suspended" -> "Cuenta suspendida"
    "deleted" -> "Cuenta eliminada"
    else -> "Cuenta"
}

@Composable
private fun ProfileScreen(
    dashboard: DashboardData,
    textSizeStep: Int,
    onTextSize: (Int) -> Unit,
    animationsEnabled: Boolean,
    onAnimationsChange: (Boolean) -> Unit,
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit
) {
    val context = LocalContext.current
    var openDoc by remember { mutableStateOf<LegalDoc?>(null) }
    var showSupport by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var showFaq by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "profile_header", contentType = "header") {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(R.drawable.logo_gana_geo),
                    contentDescription = null,
                    modifier = Modifier.size(88.dp)
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    dashboard.profile.displayName ?: "Usuario",
                    style = MaterialTheme.typography.headlineSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    readableAccountStatus(dashboard.profile.accountStatus),
                    color = if (dashboard.profile.accountStatus == "active") NeonGreen
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item(key = "profile_geo_id", contentType = "card") {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Tu Geo ID", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            dashboard.profile.geoId.toString(),
                            style = MaterialTheme.typography.headlineMedium,
                            color = NeonGreen,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(
                                ClipData.newPlainText("Geo ID", dashboard.profile.geoId.toString())
                            )
                        }) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copiar Geo ID")
                        }
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Perú · Soles (PEN) · Identifica tu cuenta dentro de Gana Geo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item(key = "profile_settings_title", contentType = "section_title") {
            Text("Ajustes", style = MaterialTheme.typography.titleMedium)
        }
        item(key = "profile_settings", contentType = "menu") {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column {
                    TextSizeSelector(
                        step = textSizeStep,
                        onSelect = onTextSize,
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp)
                    )
                    AnimationsToggleRow(enabled = animationsEnabled, onChange = onAnimationsChange)
                    ProfileMenuRow(Icons.Rounded.Notifications, "Avisos y recordatorios") {
                        openNotificationSettings(context)
                    }
                }
            }
        }

        item(key = "profile_app_title", contentType = "section_title") {
            Text("Gana Geo", style = MaterialTheme.typography.titleMedium)
        }
        item(key = "profile_app", contentType = "menu") {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column {
                    ProfileMenuRow(Icons.Rounded.HelpOutline, "Preguntas frecuentes") { showFaq = true }
                    ProfileMenuRow(Icons.Rounded.Star, "Califica en Google Play") { openPlayStore(context) }
                    ProfileMenuRow(Icons.Rounded.Share, "Compartir con amigos") { shareApp(context) }
                }
            }
        }

        item(key = "profile_legal_title", contentType = "section_title") {
            Text("Legal y ayuda", style = MaterialTheme.typography.titleMedium)
        }
        item(key = "profile_legal", contentType = "menu") {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column {
                    ProfileMenuRow(Icons.Rounded.Policy, "Política de privacidad") { openDoc = LegalDoc.PRIVACY }
                    ProfileMenuRow(Icons.Rounded.Gavel, "Términos y condiciones") { openDoc = LegalDoc.TERMS }
                    ProfileMenuRow(Icons.Rounded.Redeem, "Reglas de Geo Rewards") { openDoc = LegalDoc.REWARDS }
                    ProfileMenuRow(Icons.Rounded.SupportAgent, "Ayuda y soporte") { showSupport = true }
                }
            }
        }

        item(key = "profile_signout", contentType = "action") {
            OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Cerrar sesión")
            }
        }

        item(key = "profile_delete", contentType = "action") {
            TextButton(onClick = { showDelete = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(8.dp))
                Text("Eliminar cuenta", color = MaterialTheme.colorScheme.error)
            }
        }
    }

    openDoc?.let { doc -> LegalDialog(doc = doc, onDismiss = { openDoc = null }) }

    if (showFaq) FaqDialog(onDismiss = { showFaq = false })

    if (showSupport) {
        AlertDialog(
            onDismissRequest = { showSupport = false },
            title = { Text("Ayuda y soporte") },
            text = {
                Text(
                    "Escríbenos a ${LegalTexts.supportContact}. Indica tu Geo ID (${dashboard.profile.geoId}) y explica el problema. Nunca te pediremos contraseñas ni códigos.",
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            confirmButton = { TextButton(onClick = { showSupport = false }) { Text("Entendido") } }
        )
    }

    if (showDelete) {
        DeleteAccountDialog(
            rewards = dashboard.wallet.internalPoints,
            credits = dashboard.toolCredits.availableCredits,
            onDismiss = { showDelete = false },
            onConfirm = {
                showDelete = false
                onDeleteAccount()
            }
        )
    }
}

@Composable
private fun ProfileMenuRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, modifier = Modifier.weight(1f))
        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color(0xFF9AB8A5))
    }
}

@Composable
private fun DeleteAccountDialog(
    rewards: Long,
    credits: Long,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    var confirmText by rememberSaveable { mutableStateOf("") }
    val confirmed = confirmText.trim().equals("ELIMINAR", ignoreCase = true)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Eliminar cuenta") },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(LegalTexts.body(LegalDoc.DELETE), style = MaterialTheme.typography.bodyMedium)
                if (rewards > 0 || credits > 0) {
                    NoticeCard(
                        "Vas a perder $credits créditos y $rewards Geo Rewards.",
                        isError = true
                    )
                }
                OutlinedTextField(
                    value = confirmText,
                    onValueChange = { confirmText = it.take(12) },
                    label = { Text("Escribe ELIMINAR para confirmar") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = confirmed,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = Color.White
                )
            ) {
                Text("Eliminar")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun LegalDialog(doc: LegalDoc, onDismiss: () -> Unit) {
    val body = remember(doc) { LegalTexts.body(doc) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(doc.title) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(body, style = MaterialTheme.typography.bodyMedium)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
private fun LegalCenterDialog(
    textSizeStep: Int,
    onTextSize: (Int) -> Unit,
    animationsEnabled: Boolean,
    onAnimationsChange: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var openDoc by remember { mutableStateOf<LegalDoc?>(null) }
    var showFaq by remember { mutableStateOf(false) }
    val current = openDoc
    if (current != null) {
        LegalDialog(doc = current, onDismiss = { openDoc = null })
        return
    }
    if (showFaq) {
        FaqDialog(onDismiss = { showFaq = false })
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ayuda y ajustes") },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                TextSizeSelector(
                    step = textSizeStep,
                    onSelect = onTextSize,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
                AnimationsToggleRow(enabled = animationsEnabled, onChange = onAnimationsChange)
                ProfileMenuRow(Icons.Rounded.HelpOutline, "Preguntas frecuentes") { showFaq = true }
                ProfileMenuRow(Icons.Rounded.Share, "Compartir con amigos") { shareApp(context) }
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                ProfileMenuRow(Icons.Rounded.Policy, "Política de privacidad") { openDoc = LegalDoc.PRIVACY }
                ProfileMenuRow(Icons.Rounded.Gavel, "Términos y condiciones") { openDoc = LegalDoc.TERMS }
                ProfileMenuRow(Icons.Rounded.Redeem, "Reglas de Geo Rewards") { openDoc = LegalDoc.REWARDS }
                ProfileMenuRow(Icons.Rounded.DeleteForever, "Cómo eliminar una cuenta") { openDoc = LegalDoc.DELETE }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
private fun LedgerRow(entry: LedgerEntry) {
    val positive = entry.pointsDelta > 0 || entry.cashDelta > 0
    val amountText = when {
        entry.pointsDelta != 0L -> "${if (entry.pointsDelta > 0) "+" else ""}${entry.pointsDelta} Rewards"
        entry.cashDelta != 0.0 -> "${if (entry.cashDelta > 0) "+" else ""}${penFormatter.format(entry.cashDelta)}"
        else -> "Sin cambio"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background((if (positive) NeonGreen else Gold).copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (positive) Icons.Rounded.CheckCircle else Icons.Rounded.Payments,
                    contentDescription = null,
                    tint = if (positive) NeonGreen else Gold
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(entry.description ?: entry.entryType.readableEntryType(), fontWeight = FontWeight.SemiBold)
                Text(
                    readableProvider(entry.provider),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text(
                amountText,
                color = if (positive) NeonGreen else Gold,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun readableProvider(provider: String?): String = when (provider) {
    "geo_adventures" -> "Geo Aventuras"
    "gana_geo_tools" -> "Herramientas"
    "gana_geo", "gana_geo_cancel", "gana_geo_paid", "gana_geo_reject" -> "Billetera"
    else -> "Gana Geo"
}

private fun String.readableEntryType(): String = when (this) {
    "game_reward" -> "Rewards por vida dorada"
    "referral_reward" -> "Recompensa por referido"
    "purchase_points" -> "Créditos comprados"
    "tool_reward" -> "Rewards por herramientas"
    "withdrawal" -> "Retiro solicitado"
    "reversal" -> "Devolución"
    else -> "Ajuste de saldo"
}

@Composable
private fun EmptyCard(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Info, contentDescription = null, tint = Gold)
            Spacer(Modifier.width(12.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun NoticeCard(text: String, isError: Boolean) {
    val color = if (isError) MaterialTheme.colorScheme.error else Gold
    Card(
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.10f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(
                if (isError) Icons.Rounded.ErrorOutline else Icons.Rounded.Info,
                contentDescription = null,
                tint = color
            )
            Spacer(Modifier.width(10.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}


@Composable
private fun OfflineBanner(visible: Boolean) {
    AnimatedVisibility(
        visible = visible,
        enter = expandVertically(),
        exit = shrinkVertically()
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF3A2F0B)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Rounded.CloudOff,
                    contentDescription = null,
                    tint = Gold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Sin conexión. Las herramientas gratis siguen funcionando.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFFFE9A8),
                    maxLines = 2
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LoginPromptSheet(
    toolTitle: String?,
    enabled: Boolean,
    onContinue: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF0B2A1A)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 24.dp, bottom = 28.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(NeonGreen.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Lock, contentDescription = null, tint = NeonGreen)
            }
            Spacer(Modifier.height(14.dp))
            Text(
                if (toolTitle != null) "$toolTitle es premium" else "Herramienta premium",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Inicia sesión para usarla. Es gratis y toma segundos.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF9AB8A5)
            )
            Spacer(Modifier.height(18.dp))
            LoginBenefit(Icons.Rounded.ShoppingCart, "Compra créditos con Google Play")
            LoginBenefit(Icons.Rounded.Redeem, "Gana Geo Rewards al usarlos")
            LoginBenefit(Icons.Rounded.Favorite, "Tus recientes en cualquier celular")
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onContinue,
                enabled = enabled,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonGreen,
                    contentColor = DeepGreen
                )
            ) {
                Text("Continuar con Google", fontWeight = FontWeight.Bold)
            }
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Ahora no", color = Color(0xFF9AB8A5))
            }
        }
    }
}

@Composable
private fun LoginBenefit(icon: ImageVector, text: String) {
    Row(
        modifier = Modifier.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun DashboardSkeleton() {
    val transition = rememberInfiniteTransition(label = "skeleton")
    val pulse by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 850, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "skeletonAlpha"
    )
    val block = Color(0xFF123A26)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .graphicsLayer { alpha = pulse },
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier
                .width(160.dp)
                .height(22.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(block)
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(120.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(block)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            repeat(3) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(86.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(block)
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            repeat(3) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(86.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(block)
                )
            }
        }
        Box(
            Modifier
                .width(120.dp)
                .height(18.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(block)
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(block)
        )
    }
}


private val TextSizeFactors = listOf(1f, 1.1f, 1.2f)
private val TextSizeLabels = listOf("Normal", "Grande", "Muy grande")

@Composable
private fun TextSizeSelector(step: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.TextFields, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Text("Tamaño de letra")
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextSizeLabels.forEachIndexed { index, label ->
                val selected = index == step
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) NeonGreen else Color.White.copy(alpha = 0.06f))
                        .clickable { onSelect(index) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        color = if (selected) DeepGreen else MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

private val FaqItems = listOf(
    "¿Qué es gratis?" to
        "Calculadoras, visores, estudio, trabajo y herramientas rápidas son gratis y funcionan sin cuenta. Las de PDF e imágenes usan créditos.",
    "¿Cómo consigo créditos?" to
        "Se compran con Google Play: S/5 = 50 créditos y S/10 = 100 créditos. Necesitas iniciar sesión.",
    "¿Qué son los Geo Rewards?" to
        "Puntos que ganas al usar herramientas con créditos. Mira las reglas en \"Reglas de Geo Rewards\".",
    "¿Cómo retiro mi dinero?" to
        "Solo por Yape, a tu número de 9 dígitos, desde Billetera. El mínimo es S/5 y se puede cuando los retiros estén habilitados.",
    "¿Necesito internet?" to
        "Las herramientas gratis funcionan sin internet. Para créditos, Rewards y retiros sí necesitas conexión.",
    "¿Mis archivos se suben a internet?" to
        "No. Tus PDF y fotos se trabajan dentro de tu celular.",
    "¿Puedo usar mi cuenta en otro celular?" to
        "Tu cuenta funciona en un celular a la vez. Si cambias de celular, solo inicia sesión en el nuevo: la cuenta pasa sola (máximo 3 cambios al mes).",
    "¿Cómo guardo favoritos?" to
        "Mantén presionada una herramienta. Sale una estrellita y aparece primero en Inicio.",
    "¿Cómo borro mi cuenta?" to
        "En Perfil, toca \"Eliminar cuenta\". Se borran tus créditos y Rewards."
)

@Composable
private fun FaqDialog(onDismiss: () -> Unit) {
    var open by remember { mutableIntStateOf(-1) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Preguntas frecuentes") },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                FaqItems.forEachIndexed { index, (question, answer) ->
                    val expanded = open == index
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { open = if (expanded) -1 else index }
                            .padding(vertical = 10.dp, horizontal = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                question,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                Icons.Rounded.ChevronRight,
                                contentDescription = null,
                                tint = Color(0xFF9AB8A5),
                                modifier = Modifier.graphicsLayer { rotationZ = if (expanded) 90f else 0f }
                            )
                        }
                        if (expanded) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                answer,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (index < FaqItems.lastIndex) HorizontalDivider(color = Color.White.copy(alpha = 0.06f))
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "¿Otra duda? Escríbenos a ${LegalTexts.supportContact}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

private const val PLAY_STORE_WEB = "https://play.google.com/store/apps/details?id="

private fun shareApp(context: Context) {
    val text = "Te recomiendo Gana Geo: herramientas para PDF, fotos, estudio y trabajo. " +
        PLAY_STORE_WEB + context.packageName
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    runCatching {
        context.startActivity(
            Intent.createChooser(send, "Compartir Gana Geo").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

private fun openPlayStore(context: Context) {
    val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + context.packageName))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val opened = runCatching { context.startActivity(market) }.isSuccess
    if (!opened) {
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(PLAY_STORE_WEB + context.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}

private fun openNotificationSettings(context: Context) {
    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val opened = runCatching { context.startActivity(intent) }.isSuccess
    if (!opened) {
        runCatching {
            context.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}

private tailrec fun Context.findActivityForReview(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivityForReview()
    else -> null
}

/** Ventana oficial de Google Play. Si Play decide no mostrarla, no pasa nada. */
private fun launchInAppReview(activity: Activity) {
    runCatching {
        val manager = ReviewManagerFactory.create(activity)
        manager.requestReviewFlow().addOnCompleteListener { request ->
            if (request.isSuccessful && !activity.isFinishing) {
                runCatching { manager.launchReviewFlow(activity, request.result) }
            }
        }
    }
}

/** Interruptor para las presentaciones animadas de las herramientas. */
@Composable
private fun AnimationsToggleRow(enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChange(!enabled) }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Animation, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("Animaciones")
            Text(
                "Presentaciones que se mueven en Herramientas",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = enabled,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = DeepGreen,
                checkedTrackColor = NeonGreen
            )
        )
    }
}
