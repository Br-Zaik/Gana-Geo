# Gana Geo Android v0.10.34

Version enfocada exclusivamente en corregir la sincronizacion de trampas y mecanismos del multijugador local sobre la v0.10.33. No cambia la jugabilidad base, dificultad, saltos ni diseno de los 20 niveles. No modifica login, Google, Supabase ni sesion.

## Mundo de trampas autoritativo

- El anfitrion es la unica autoridad de las trampas y mecanismos transitorios durante una partida local.
- Los clientes ya no publican ni fusionan su propio estado transitorio de plataformas, pinchos, plantas, rocas, bolas, crushers, agujeros, launchers o cajas explosivas.
- Cuando un cliente entra en el trigger de una trampa envia una solicitud compacta al host; espera la respuesta autoritativa antes de aplicar el cambio.
- Cada trampa usa un ciclo numerado. Una solicitud vieja no puede volver a activar una trampa despues de que ya se ejecuto o se rearmo.
- Cada solicitud de cliente usa una secuencia monotona y el host procesa cada secuencia una sola vez, por lo que repetir un paquete no repite el mecanismo.
- Los snapshots del host llevan una revision monotona; un cliente ignora snapshots viejos o repetidos.
- El protocolo LAN pasa a `GANAGEO_LOCAL_V2` para impedir mezclar esta sincronizacion con APK antiguos incompatibles. Todos los telefonos de una sala deben usar v0.10.34.

## Rearmado

- El rearmado sigue ocurriendo solo en el host.
- Una trampa se rearma despues de completar su efecto/cooldown y solo cuando todos los GEO vivos han salido de su zona.
- Al rearmarse, el nuevo estado se replica a todos los clientes; el jugador que viene atras vuelve a encontrar la trampa disponible.
- Las trampas no pueden entrar en un bucle por un estado atrasado del cliente.
- Llaves, interruptores y progreso permanente siguen separados de las trampas transitorias.

## Trafico LAN

- Los clientes transmiten solicitudes compactas `g3r` en lugar de un segundo mundo de trampas.
- El host transmite el snapshot autoritativo `g3` y omite el `worldState` transitorio de los demas clientes al redistribuir la sala.
- Posiciones/jugadores conservan la sincronizacion LAN existente de la v0.10.33; esta version no cambia fisicas ni timings de juego.

## Validacion realizada

- Contrato estatico de autoridad/sincronizacion: **26/26 PASS**.
- Prueba aislada del algoritmo de ciclos, secuencias duplicadas, solicitudes viejas y revisiones: **PASS**.
- Revision del compilador Kotlin sin dependencias Android: no detecto errores de parser ni referencias nuevas fuera de alcance; no sustituye el build Android real.
- El intento de `:app:compileDebugKotlin` no pudo comenzar porque este entorno no puede resolver `services.gradle.org` para descargar Gradle 8.13. La compilacion Android completa debe confirmarse en GitHub Actions.

## Proteccion

Los 12 archivos protegidos de login/Google/Supabase/sesion y SQL 01-07 mantienen exactamente los SHA-256 registrados en `PROTECTED_FILES_SHA256.txt`.
