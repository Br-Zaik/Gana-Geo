# Gana Geo Android v0.10.36

Correccion de compilacion de la animacion previa al selector de cuentas de Google agregada en v0.10.35.

## Correccion

- Se agrego el import faltante `androidx.compose.animation.core.animateFloat`.
- Esto corrige `Unresolved reference: animateFloat` en `GanaGeoApp.kt` y los errores secundarios de inferencia de tipo en las animaciones `haloScale` y `particleShift`.

## Flujo conservado

- Invitado -> Iniciar sesion -> animacion Gana Geo -> selector de cuentas de Google.
- Sin campos de correo ni contrasena.
- No se modifica `MainActivity`, `GanaGeoViewModel`, repositorio, Supabase ni la logica real de autenticacion/persistencia.

## Version

- versionCode: 52
- versionName: 0.10.36
