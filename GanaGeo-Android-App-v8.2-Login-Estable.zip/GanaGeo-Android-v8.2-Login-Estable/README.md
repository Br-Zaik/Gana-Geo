# Gana Geo Android v8.1

> Corrección del acceso nativo: Google recibe el nonce SHA-256 y Supabase recibe el nonce original. La compilación también fuerza y verifica una firma Debug estable.

Proyecto Android de **Gana Geo**, preparado para GitHub Actions. Esta revisión incorpora las herramientas de V7 y corrige el acceso, las reinstalaciones y el bloqueo infinito de la cuenta.

## Funciones principales

- Interfaz en verde oscuro y verde neón.
- Acceso nativo con Google mediante Android Credential Manager.
- Supabase Auth recibe el Google ID Token directamente; no se abre Chrome.
- Perfil, Geo ID, puntos, billetera, movimientos y retiros.
- Una instalación activa por cuenta.
- Reemplazo confirmado de la instalación anterior después de reinstalar o cambiar de celular.
- Verificación de la instalación activa en retiros y herramientas pagadas.
- Herramientas gratuitas y herramientas con créditos procesadas localmente.
- Compilación automática del APK con GitHub Actions.

## Lo que no está fingido

La app no inventa ganancias ni acredita saldo real desde el celular. Las encuestas, ofertas y anuncios permanecen como “Próximamente” hasta integrar proveedores reales con postbacks verificables. Los retiros se registran en Supabase, pero el pago sigue requiriendo un proceso administrativo o un proveedor autorizado.

## 1. Configuración local o en GitHub

La URL actual de Supabase es:

```text
https://pnbpeehcbqkdhjueyldn.supabase.co
```

Para compilar localmente, copia `local.properties.example` como `local.properties` y completa:

```properties
SUPABASE_URL=https://pnbpeehcbqkdhjueyldn.supabase.co
SUPABASE_ANON_KEY=TU_CLAVE_PUBLICA
GOOGLE_WEB_CLIENT_ID=TU_CLIENT_ID_WEB.apps.googleusercontent.com
```

En GitHub crea estos secretos en:

```text
Settings → Secrets and variables → Actions
```

```text
SUPABASE_ANON_KEY
GOOGLE_WEB_CLIENT_ID
```

Usa únicamente la clave pública Publishable/anon y el **Client ID**, nunca:

- `service_role`
- contraseña de PostgreSQL
- Client Secret de Google

## 2. Configurar Google

En Google Auth Platform / Google Cloud deben existir dos clientes OAuth dentro del mismo proyecto:

### Cliente de tipo Web

Su Client ID se coloca en `GOOGLE_WEB_CLIENT_ID` y debe coincidir con la configuración del proveedor Google en Supabase.

### Cliente de tipo Android

```text
Paquete: com.ganageo.app
SHA-1: huella de la clave que firma el APK
```

Para el APK Debug de GitHub debes registrar la SHA-1 de esa firma. El workflow conserva una firma Debug estable en la caché del repositorio y muestra su SHA-1 en el paso **Preparar firma Debug estable**. Ejecuta Actions una vez, copia esa SHA-1 a Google y vuelve a compilar. Si eliminas la caché, se generará otra firma y tendrás que registrar la nueva huella.

Para publicar en Play Store usa una clave de publicación propia y registra también la huella de Play App Signing; no uses la firma Debug para producción.

El acceso nuevo usa Credential Manager y ya no necesita el deep link `ganageo://login-callback` para Google.

## 3. Actualizar Supabase

Para una base ya creada con las versiones anteriores, ejecuta completo en Supabase SQL Editor:

```text
supabase/04_native_login_device_replacement.sql
```

Ese archivo actualiza de forma conjunta:

- `register_my_device`
- `replace_my_device`
- `assert_active_installation`
- `request_withdrawal`
- `cancel_my_withdrawal`
- `begin_tool_operation`
- `complete_tool_operation`
- `cancel_tool_operation`

También elimina las firmas antiguas que permitían operaciones sin comprobar la instalación.

En un proyecto completamente nuevo, ejecuta en este orden:

```text
supabase/01_schema.sql
supabase/02_secure_app_functions.sql
supabase/03_tool_credits.sql
```

No ejecutes solo el APK nuevo sin actualizar el SQL: el botón para reemplazar una instalación y las RPC protegidas no funcionarán.

## 4. Reinstalación o cambio de celular

El identificador de instalación es un UUID local, no IMEI ni número de serie. Al reinstalar, Android elimina ese UUID y la app genera uno nuevo.

Cuando Supabase detecta que la cuenta aún tiene otra instalación activa, la app muestra:

```text
Reemplazar instalación anterior
```

Tras la confirmación:

- la instalación anterior queda en estado `replaced`;
- la instalación actual queda en estado `active`;
- la anterior deja de poder ejecutar retiros y herramientas pagadas;
- una instalación activa vinculada a otra cuenta no se puede tomar automáticamente.

## 5. Compilar en GitHub Actions

Ejecuta:

```text
Actions → Compilar Gana Geo → Run workflow
```

El flujo instala Java 17, Android 36 y Gradle 8.13. El artefacto resultante se llama:

```text
Gana-Geo-v8-Login-Nativo-Dispositivo
```

Si falta `SUPABASE_ANON_KEY`, la compilación se detiene intencionalmente. Si falta `GOOGLE_WEB_CLIENT_ID`, compila, pero el acceso mostrará el error de configuración en lugar de abrir Google.

## 6. Herramientas de V7

### Gratuitas

- Calculadora científica.
- Conversor de unidades.
- Porcentajes y regla de tres.
- Promedios y notas ponderadas.
- Geometría.
- Crear y leer QR.
- Contador de palabras y caracteres.
- Cronómetro y temporizador.

### Con créditos

- Imágenes a PDF.
- Organizar, extraer, eliminar, girar y unir páginas PDF.
- PDF a imágenes.
- Firma dibujada sobre PDF.
- Comprimir, redimensionar, convertir, recortar y girar imágenes.
- Texto y marca de agua.

Los archivos se procesan en el teléfono y no se suben a Supabase.

```text
Pack Geo 50  = 50 créditos (precio previsto S/5)
Pack Geo 100 = 100 créditos (precio previsto S/10)
Cada 10 créditos comprados y utilizados = 50 Geo Rewards
Retiro mínimo: 500 Geo Rewards = S/5
```

En Debug existen créditos simulados de prueba sin valor real. Las compras reales deben verificarse en un backend con Google Play Developer API antes de llamar a `grant_verified_tool_pack`.

## Reglas de seguridad

- RLS limita las lecturas a datos del usuario autenticado.
- El APK no puede escribir saldos arbitrariamente.
- Las operaciones sensibles exigen sesión y el UUID de la instalación activa.
- El reemplazo de instalación requiere una sesión Google válida y confirmación expresa.
- Se utiliza un nonce criptográfico durante el acceso nativo.
- El cierre de sesión limpia el estado de Credential Manager para permitir escoger otra cuenta.

Este control evita el uso accidental simultáneo desde dos instalaciones oficiales. No reemplaza un sistema antifraude completo contra clientes modificados; para ese nivel se necesita backend propio, verificación de integridad y monitoreo.

## Estructura

```text
app/                         Código Android
supabase/                    Esquema y RPC seguras
.github/workflows/           Compilación automática
local.properties.example     Plantilla sin secretos
docs/                        Guías de prueba
```

Consulta `CAMBIOS_V8_LOGIN_NATIVO.txt` y `docs/PRUEBAS_HERRAMIENTAS_V7.md`.