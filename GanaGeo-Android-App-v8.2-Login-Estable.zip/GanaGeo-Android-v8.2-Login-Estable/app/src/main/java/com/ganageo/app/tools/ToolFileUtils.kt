package com.ganageo.app.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import androidx.documentfile.provider.DocumentFile
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.BitMatrix
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object ToolFileUtils {
    private const val MAX_BITMAP_EDGE = 4096

    suspend fun loadBitmap(context: Context, uri: Uri): Bitmap = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val maxEdge = max(info.size.width, info.size.height)
                if (maxEdge > MAX_BITMAP_EDGE) {
                    decoder.setTargetSampleSize((maxEdge.toFloat() / MAX_BITMAP_EDGE).roundToInt().coerceAtLeast(1))
                }
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_BITMAP_EDGE) sample *= 2
            val options = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            } ?: error("No se pudo abrir la imagen.")
        }
    }

    suspend fun writeBitmap(
        context: Context,
        bitmap: Bitmap,
        output: Uri,
        format: Bitmap.CompressFormat,
        quality: Int
    ) = withContext(Dispatchers.IO) {
        context.contentResolver.openOutputStream(output, "w")?.use { stream ->
            check(bitmap.compress(format, quality.coerceIn(1, 100), stream)) {
                "No se pudo guardar la imagen."
            }
        } ?: error("No se pudo abrir el archivo de destino.")
    }

    suspend fun createPdfFromImages(
        context: Context,
        imageUris: List<Uri>,
        output: Uri
    ) = withContext(Dispatchers.IO) {
        require(imageUris.isNotEmpty()) { "Selecciona al menos una imagen." }
        val document = PdfDocument()
        try {
            val pageWidth = 595
            val pageHeight = 842
            imageUris.forEachIndexed { index, uri ->
                val bitmap = loadBitmap(context, uri)
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = document.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawColor(Color.WHITE)
                val margin = 24f
                val destination = fitRect(
                    bitmap.width.toFloat(),
                    bitmap.height.toFloat(),
                    margin,
                    margin,
                    pageWidth - margin,
                    pageHeight - margin
                )
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                canvas.drawBitmap(bitmap, null, destination, paint)
                document.finishPage(page)
                bitmap.recycle()
            }
            context.contentResolver.openOutputStream(output, "w")?.use(document::writeTo)
                ?: error("No se pudo crear el PDF.")
        } finally {
            document.close()
        }
    }

    suspend fun pdfToImages(
        context: Context,
        input: Uri,
        outputTree: Uri,
        format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG,
        quality: Int = 92
    ): Int = withContext(Dispatchers.IO) {
        val folder = DocumentFile.fromTreeUri(context, outputTree)
            ?: error("No se pudo abrir la carpeta elegida.")
        val pfd = context.contentResolver.openFileDescriptor(input, "r")
            ?: error("No se pudo abrir el PDF.")
        var count = 0
        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                for (index in 0 until renderer.pageCount) {
                    renderer.openPage(index).use { page ->
                        val targetWidth = min(1800, page.width * 2).coerceAtLeast(page.width)
                        val targetHeight = (targetWidth.toFloat() / page.width * page.height).roundToInt()
                        val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val extension = if (format == Bitmap.CompressFormat.PNG) "png" else "jpg"
                        val mime = if (format == Bitmap.CompressFormat.PNG) "image/png" else "image/jpeg"
                        val file = folder.createFile(mime, "pagina_${(index + 1).toString().padStart(3, '0')}.$extension")
                            ?: error("No se pudo crear la imagen ${index + 1}.")
                        context.contentResolver.openOutputStream(file.uri, "w")?.use { stream ->
                            check(bitmap.compress(format, quality, stream))
                        } ?: error("No se pudo escribir la imagen ${index + 1}.")
                        bitmap.recycle()
                        count++
                    }
                }
            }
        }
        count
    }

    suspend fun mergePdfs(context: Context, inputs: List<Uri>, output: Uri) = withContext(Dispatchers.IO) {
        require(inputs.size >= 2) { "Selecciona dos o más PDF." }
        initializePdfBox(context)
        val tempFiles = inputs.map { copyUriToTemp(context, it, ".pdf") }
        val destination = File(context.cacheDir, "merge_${UUID.randomUUID()}.pdf")
        try {
            PDFMergerUtility().apply {
                tempFiles.forEach(::addSource)
                destinationFileName = destination.absolutePath
                mergeDocuments(MemoryUsageSetting.setupTempFileOnly())
            }
            copyFileToUri(context, destination, output)
        } finally {
            tempFiles.forEach(File::delete)
            destination.delete()
        }
    }

    suspend fun organizePdf(
        context: Context,
        input: Uri,
        output: Uri,
        pageOrder: List<Int>,
        rotation: Int = 0
    ) = withContext(Dispatchers.IO) {
        initializePdfBox(context)
        val sourceFile = copyUriToTemp(context, input, ".pdf")
        val targetFile = File(context.cacheDir, "organized_${UUID.randomUUID()}.pdf")
        try {
            PDDocument.load(sourceFile).use { source ->
                require(source.numberOfPages > 0) { "El PDF no contiene páginas." }
                val indexes = if (pageOrder.isEmpty()) {
                    (0 until source.numberOfPages).toList()
                } else {
                    pageOrder.map { requested ->
                        require(requested in 1..source.numberOfPages) {
                            "La página $requested no existe. El PDF tiene ${source.numberOfPages} páginas."
                        }
                        requested - 1
                    }
                }
                PDDocument().use { target ->
                    indexes.forEach { index ->
                        val imported = target.importPage(source.getPage(index))
                        if (rotation != 0) {
                            imported.rotation = ((imported.rotation + rotation) % 360 + 360) % 360
                        }
                    }
                    target.save(targetFile)
                }
            }
            copyFileToUri(context, targetFile, output)
        } finally {
            sourceFile.delete()
            targetFile.delete()
        }
    }

    suspend fun signPdf(
        context: Context,
        input: Uri,
        output: Uri,
        signature: Bitmap,
        pageNumber: Int
    ) = withContext(Dispatchers.IO) {
        initializePdfBox(context)
        val sourceFile = copyUriToTemp(context, input, ".pdf")
        val targetFile = File(context.cacheDir, "signed_${UUID.randomUUID()}.pdf")
        try {
            PDDocument.load(sourceFile).use { document ->
                require(document.numberOfPages > 0) { "El PDF no contiene páginas." }
                require(pageNumber in 1..document.numberOfPages) {
                    "La página indicada no existe."
                }
                val page = document.getPage(pageNumber - 1)
                val bytes = ByteArrayOutputStream().use { buffer ->
                    signature.compress(Bitmap.CompressFormat.PNG, 100, buffer)
                    buffer.toByteArray()
                }
                val image = PDImageXObject.createFromByteArray(document, bytes, "firma")
                val box = page.mediaBox
                val desiredWidth = min(150f, box.width * 0.32f)
                val desiredHeight = desiredWidth * signature.height / signature.width.toFloat()
                val x = box.lowerLeftX + box.width - desiredWidth - 36f
                val y = box.lowerLeftY + 36f
                PDPageContentStream(
                    document,
                    page,
                    PDPageContentStream.AppendMode.APPEND,
                    true,
                    true
                ).use { stream ->
                    stream.drawImage(image, x, y, desiredWidth, desiredHeight)
                }
                document.save(targetFile)
            }
            copyFileToUri(context, targetFile, output)
        } finally {
            sourceFile.delete()
            targetFile.delete()
        }
    }

    fun resize(bitmap: Bitmap, width: Int, height: Int, keepAspect: Boolean): Bitmap {
        require(width > 0 && height > 0) { "Las dimensiones deben ser mayores que cero." }
        if (!keepAspect) return Bitmap.createScaledBitmap(bitmap, width, height, true)
        val scale = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val targetWidth = max(1, (bitmap.width * scale).roundToInt())
        val targetHeight = max(1, (bitmap.height * scale).roundToInt())
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }

    fun centerCrop(bitmap: Bitmap, ratioWidth: Int, ratioHeight: Int): Bitmap {
        require(ratioWidth > 0 && ratioHeight > 0)
        val targetRatio = ratioWidth.toFloat() / ratioHeight
        val currentRatio = bitmap.width.toFloat() / bitmap.height
        val cropWidth: Int
        val cropHeight: Int
        if (currentRatio > targetRatio) {
            cropHeight = bitmap.height
            cropWidth = (cropHeight * targetRatio).roundToInt()
        } else {
            cropWidth = bitmap.width
            cropHeight = (cropWidth / targetRatio).roundToInt()
        }
        val left = (bitmap.width - cropWidth) / 2
        val top = (bitmap.height - cropHeight) / 2
        return Bitmap.createBitmap(bitmap, left, top, cropWidth, cropHeight)
    }

    fun rotateFlip(bitmap: Bitmap, degrees: Float, flipHorizontal: Boolean, flipVertical: Boolean): Bitmap {
        val matrix = Matrix().apply {
            postScale(if (flipHorizontal) -1f else 1f, if (flipVertical) -1f else 1f)
            postRotate(degrees)
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    fun addWatermark(bitmap: Bitmap, text: String, opacity: Int, textSizePercent: Int): Bitmap {
        require(text.isNotBlank()) { "Escribe el texto de la marca de agua." }
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val size = max(18f, result.width * textSizePercent.coerceIn(2, 20) / 100f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            alpha = (255 * opacity.coerceIn(5, 100) / 100f).roundToInt()
            textSize = size
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(3f, 1f, 1f, Color.BLACK)
        }
        val bounds = RectF()
        val width = paint.measureText(text)
        bounds.set(
            max(16f, result.width - width - 24f),
            max(size + 16f, result.height - 24f),
            result.width - 16f,
            result.height - 8f
        )
        canvas.drawText(text, bounds.left, bounds.top, paint)
        return result
    }

    fun generateQr(text: String, size: Int = 900): Bitmap {
        require(text.isNotBlank()) { "Escribe el contenido del QR." }
        val matrix: BitMatrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val pixels = IntArray(size * size)
        for (y in 0 until size) {
            val offset = y * size
            for (x in 0 until size) pixels[offset + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
        }
        return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, size, 0, 0, size, size)
        }
    }

    fun decodeQr(bitmap: Bitmap): String {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val source = RGBLuminanceSource(width, height, pixels)
        val result = MultiFormatReader().decode(BinaryBitmap(HybridBinarizer(source)))
        return result.text
    }

    private fun fitRect(
        sourceWidth: Float,
        sourceHeight: Float,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float
    ): RectF {
        val availableWidth = right - left
        val availableHeight = bottom - top
        val scale = min(availableWidth / sourceWidth, availableHeight / sourceHeight)
        val width = sourceWidth * scale
        val height = sourceHeight * scale
        val x = left + (availableWidth - width) / 2f
        val y = top + (availableHeight - height) / 2f
        return RectF(x, y, x + width, y + height)
    }

    private fun initializePdfBox(context: Context) {
        PDFBoxResourceLoader.init(context.applicationContext)
    }

    private fun copyUriToTemp(context: Context, uri: Uri, suffix: String): File {
        val file = File(context.cacheDir, "tool_${UUID.randomUUID()}$suffix")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(file).use(input::copyTo)
        } ?: error("No se pudo leer el archivo.")
        return file
    }

    private fun copyFileToUri(context: Context, source: File, output: Uri) {
        context.contentResolver.openOutputStream(output, "w")?.use { destination ->
            source.inputStream().use { it.copyTo(destination) }
        } ?: error("No se pudo escribir el archivo de salida.")
    }
}
