package com.ganageo.app.data

import com.ganageo.app.model.DashboardData
import com.ganageo.app.model.LedgerEntry
import com.ganageo.app.model.Profile
import com.ganageo.app.model.ToolCreditAccount
import com.ganageo.app.model.ToolOperationReservation
import com.ganageo.app.model.ToolOperationResult
import com.ganageo.app.model.Wallet
import com.ganageo.app.model.Withdrawal
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.Google
import io.github.jan.supabase.auth.providers.builtin.IDToken
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class GanaGeoRepository(
    private val client: SupabaseClient
) {
    suspend fun signInWithGoogleIdToken(idToken: String, nonce: String) {
        require(idToken.isNotBlank()) { "Google no devolvió un token de acceso válido." }
        require(nonce.isNotBlank()) { "No se pudo validar la solicitud de acceso con Google." }
        client.auth.signInWith(IDToken) {
            this.idToken = idToken
            provider = Google
            this.nonce = nonce
        }
    }

    suspend fun signOut() {
        client.auth.signOut()
    }

    fun currentUserId(): String? = client.auth.currentSessionOrNull()?.user?.id

    suspend fun registerMyDevice(installationId: String) {
        client.postgrest.rpc(
            function = "register_my_device",
            parameters = buildJsonObject {
                put("p_installation_hash", installationId)
            }
        )
    }

    suspend fun replaceMyDevice(installationId: String) {
        client.postgrest.rpc(
            function = "replace_my_device",
            parameters = buildJsonObject {
                put("p_installation_hash", installationId)
            }
        )
    }

    suspend fun loadDashboard(installationId: String): DashboardData {
        val userId = currentUserId() ?: error("No hay una sesión activa.")

        // Se valida antes de cualquier lectura. Sin la RPC segura, el panel no se abre.
        try {
            registerMyDevice(installationId)
        } catch (error: Throwable) {
            val raw = error.message.orEmpty()
            val functionMissing = raw.contains("PGRST202", ignoreCase = true) ||
                raw.contains("Could not find the function", ignoreCase = true) ||
                (raw.contains("register_my_device", ignoreCase = true) &&
                    raw.contains("not found", ignoreCase = true))

            if (functionMissing) {
                error(
                    "El control de instalación no está actualizado en Supabase. " +
                        "Ejecuta supabase/04_native_login_device_replacement.sql."
                )
            }
            throw error
        }

        val profile = client.from("profiles")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeSingle<Profile>()

        val wallet = client.from("wallets")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeSingle<Wallet>()

        val ledger = client.from("ledger_entries")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeList<LedgerEntry>()
            .sortedByDescending { it.createdAt.orEmpty() }
            .take(50)

        val withdrawals = client.from("withdrawals")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeList<Withdrawal>()
            .sortedByDescending { it.requestedAt.orEmpty() }
            .take(50)

        val toolCredits = try {
            client.from("tool_credit_accounts")
                .select {
                    filter { eq("user_id", userId) }
                }
                .decodeSingle<ToolCreditAccount>()
        } catch (_: Throwable) {
            ToolCreditAccount(userId = userId)
        }

        return DashboardData(
            profile = profile,
            wallet = wallet,
            ledger = ledger,
            withdrawals = withdrawals,
            deviceNotice = null,
            toolCredits = toolCredits
        )
    }

    suspend fun beginToolOperation(
        toolCode: String,
        creditCost: Long,
        installationId: String
    ): ToolOperationReservation {
        return client.postgrest.rpc(
            function = "begin_tool_operation",
            parameters = buildJsonObject {
                put("p_tool_code", toolCode)
                put("p_credit_cost", creditCost)
                put("p_installation_hash", installationId)
            }
        ).decodeList<ToolOperationReservation>().single()
    }

    suspend fun completeToolOperation(
        operationId: String,
        installationId: String
    ): ToolOperationResult {
        return client.postgrest.rpc(
            function = "complete_tool_operation",
            parameters = buildJsonObject {
                put("p_operation_id", operationId)
                put("p_installation_hash", installationId)
            }
        ).decodeList<ToolOperationResult>().single()
    }

    suspend fun cancelToolOperation(operationId: String, installationId: String) {
        client.postgrest.rpc(
            function = "cancel_tool_operation",
            parameters = buildJsonObject {
                put("p_operation_id", operationId)
                put("p_installation_hash", installationId)
            }
        )
    }

    suspend fun requestWithdrawal(
        amount: Double,
        paymentMethod: String,
        destination: String,
        installationId: String
    ) {
        client.postgrest.rpc(
            function = "request_withdrawal",
            parameters = buildJsonObject {
                put("p_amount", amount)
                put("p_payment_method", paymentMethod)
                put("p_payment_destination", destination.trim())
                put("p_installation_hash", installationId)
            }
        )
    }

    suspend fun cancelWithdrawal(withdrawalId: String, installationId: String) {
        client.postgrest.rpc(
            function = "cancel_my_withdrawal",
            parameters = buildJsonObject {
                put("p_withdrawal_id", withdrawalId)
                put("p_installation_hash", installationId)
            }
        )
    }
}
