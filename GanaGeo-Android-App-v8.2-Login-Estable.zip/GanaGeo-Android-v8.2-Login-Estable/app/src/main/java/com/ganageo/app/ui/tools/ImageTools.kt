package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch

@Composable
fun ImageToolScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var quality by rememberSaveable { mutableStateOf(75f) }
    var widthText by rememberSaveable { mutableStateOf("1080") }
    var heightText by rememberSaveable { mutableStateOf("1080") }
    var keepAspect by rememberSaveable { mutableStateOf(true) }
    var format by rememberSaveable { mutableStateOf("JPG") }
    var ratio by rememberSaveable { mutableStateOf("1:1") }
    var rotation by rememberSaveable { mutableStateOf("0°") }
    var flipH by rememberSaveable { mutableStateOf(false) }
    var flipV by rememberSaveable { mutableStateOf(false) }
    var watermark by rememberSaveable { mutableStateOf("") }
    var opacity by rememberSaveable { mutableStateOf(55f) }
    var textSize by rememberSaveable { mutableStateOf(6f) }

    fun outputSpec(): Triple<String, String, Bitmap.CompressFormat> = when (tool) {
        ToolId.CONVERT_IMAGE -> when (format) {
            "PNG" -> Triple("image/png", "imagen_convertida.png", Bitmap.CompressFormat.PNG)
            "WebP" -> Triple("image/webp", "imagen_convertida.webp", Bitmap.CompressFormat.WEBP)
            else -> Triple("image/jpeg", "imagen_convertida.jpg", Bitmap.CompressFormat.JPEG)
        }
        else -> Triple("image/jpeg", "imagen_procesada.jpg", Bitmap.CompressFormat.JPEG)
    }

    val selectLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        input = uri
        preview = null
        if (uri != null) {
            scope.launch {
                runCatching { ToolFileUtils.loadBitmap(context, uri) }
                    .onSuccess { preview = it }
                    .onFailure { onMessage(it.message ?: "No se pudo abrir la imagen.") }
            }
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("image/*")
    ) { output ->
        val sourceUri = input
        if (output != null && sourceUri != null) {
            scope.launch {
                runPaidTool(viewModel, tool) {
                    val source = ToolFileUtils.loadBitmap(context, sourceUri)
                    var transformed: Bitmap = source
                    try {
                        transformed = when (tool) {
                            ToolId.RESIZE_IMAGE -> ToolFileUtils.resize(
                                source,
                                widthText.toIntOrNull() ?: error("Ancho inválido."),
                                heightText.toIntOrNull() ?: error("Alto inválido."),
                                keepAspect
                            )
                            ToolId.CROP_ROTATE_IMAGE -> {
                                val (rw, rh) = when (ratio) {
                                    "4:5" -> 4 to 5
                                    "9:16" -> 9 to 16
                                    "16:9" -> 16 to 9
                                    else -> 1 to 1
                                }
                                val cropped = ToolFileUtils.centerCrop(source, rw, rh)
                                try {
                                    ToolFileUtils.rotateFlip(
                                        cropped,
                                        rotation.removeSuffix("°").toFloatOrNull() ?: 0f,
                                        flipH,
                                        flipV
                                    )
                                } finally {
                                    if (cropped !== source && !cropped.isRecycled) cropped.recycle()
                                }
                            }
                            ToolId.WATERMARK_IMAGE -> ToolFileUtils.addWatermark(
                                source,
                                watermark,
                                opacity.toInt(),
                                textSize.toInt()
                            )
                            else -> source
                        }
                        val spec = outputSpec()
                        val outputQuality = if (tool == ToolId.COMPRESS_IMAGE) quality.toInt() else 92
                        ToolFileUtils.writeBitmap(context, transformed, output, spec.third, outputQuality)
                    } finally {
                        if (transformed !== source && !transformed.isRecycled) transformed.recycle()
                        if (!source.isRecycled) source.recycle()
                    }
                }.onSuccess { onMessage(successMessage("Imagen guardada correctamente.", it)) }
                    .onFailure { onMessage(it.message ?: "No se pudo procesar la imagen.") }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Costo por exportación: ${tool.creditCost} créditos", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (input == null) "Selecciona una imagen" else "Imagen lista", style = MaterialTheme.typography.titleLarge)
                        OutlinedButton(onClick = { selectLauncher.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.Folder, contentDescription = null)
                            Text(" Elegir imagen")
                        }
                        preview?.let { bitmap ->
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Vista previa",
                                modifier = Modifier.fillMaxWidth().height(240.dp),
                                contentScale = ContentScale.Fit
                            )
                            Text("${bitmap.width} × ${bitmap.height} px", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            item {
                when (tool) {
                    ToolId.COMPRESS_IMAGE -> SettingCard("Calidad de compresión") {
                        Text("Calidad: ${quality.toInt()} %")
                        Slider(value = quality, onValueChange = { quality = it }, valueRange = 20f..95f)
                        Text("Una calidad menor reduce más el peso. El tamaño final depende del contenido de la fotografía.")
                    }
                    ToolId.RESIZE_IMAGE -> SettingCard("Dimensiones") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NumberInput(widthText, { widthText = it }, "Ancho", Modifier.weight(1f))
                            NumberInput(heightText, { heightText = it }, "Alto", Modifier.weight(1f))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = keepAspect, onCheckedChange = { keepAspect = it })
                            Text("Mantener proporción sin deformar")
                        }
                    }
                    ToolId.CONVERT_IMAGE -> SettingCard("Formato de salida") {
                        ChoiceButtons(listOf("JPG", "PNG", "WebP"), format) { format = it }
                    }
                    ToolId.CROP_ROTATE_IMAGE -> SettingCard("Recorte y orientación") {
                        Text("Proporción")
                        ChoiceButtons(listOf("1:1", "4:5", "9:16", "16:9"), ratio) { ratio = it }
                        Text("Rotación")
                        ChoiceButtons(listOf("0°", "90°", "180°", "270°"), rotation) { rotation = it }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = flipH, onCheckedChange = { flipH = it })
                            Text("Voltear horizontal")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = flipV, onCheckedChange = { flipV = it })
                            Text("Voltear vertical")
                        }
                    }
                    ToolId.WATERMARK_IMAGE -> SettingCard("Marca de agua") {
                        OutlinedTextField(
                            value = watermark,
                            onValueChange = { watermark = it.take(120) },
                            label = { Text("Texto") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("Opacidad: ${opacity.toInt()} %")
                        Slider(value = opacity, onValueChange = { opacity = it }, valueRange = 10f..100f)
                        Text("Tamaño: ${textSize.toInt()} % del ancho")
                        Slider(value = textSize, onValueChange = { textSize = it }, valueRange = 3f..14f)
                    }
                    else -> Unit
                }
            }
            item {
                val spec = outputSpec()
                Button(
                    onClick = {
                        launchPaidExport(viewModel, tool, onMessage) {
                            saveLauncher.launch(spec.second)
                        }
                    },
                    enabled = input != null && (tool != ToolId.WATERMARK_IMAGE || watermark.isNotBlank()),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) {
                    Icon(Icons.Rounded.Save, contentDescription = null)
                    Text(" Procesar y guardar · ${tool.creditCost} créditos")
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFCC32).copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
                    Text(
                        "El archivo original nunca se reemplaza. La aplicación crea una copia nueva y solo descuenta créditos si el proceso termina correctamente.",
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            content()
        }
    }
}

@Composable
private fun ChoiceButtons(options: List<String>, selected: String, onSelected: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        options.chunked(3).forEach { rowOptions ->
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                rowOptions.forEach { option ->
                    FilledTonalButton(
                        onClick = { onSelected(option) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (selected == option) NeonGreen else CardGreen,
                            contentColor = if (selected == option) DeepGreen else Color.White
                        )
                    ) { Text(option) }
                }
                repeat(3 - rowOptions.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun NumberInput(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit).take(5)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
        singleLine = true
    )
}
