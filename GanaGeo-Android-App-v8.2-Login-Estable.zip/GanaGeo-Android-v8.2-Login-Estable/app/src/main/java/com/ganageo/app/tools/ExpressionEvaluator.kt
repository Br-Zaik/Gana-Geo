package com.ganageo.app.tools

import kotlin.math.E
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

class ExpressionEvaluator(private val degrees: Boolean = true) {
    fun evaluate(raw: String): Double {
        val normalized = raw
            .replace('×', '*')
            .replace('÷', '/')
            .replace('−', '-')
            .replace(',', '.')
            .replace("π", "pi", ignoreCase = false)
        val parser = Parser(normalized)
        val result = parser.parseExpression()
        parser.skipSpaces()
        if (!parser.isEnd()) error("Expresión incompleta")
        if (!result.isFinite()) error("Resultado fuera de rango")
        return result
    }

    private inner class Parser(private val text: String) {
        private var index = 0

        fun isEnd(): Boolean = index >= text.length

        fun skipSpaces() {
            while (index < text.length && text[index].isWhitespace()) index++
        }

        fun parseExpression(): Double {
            var value = parseTerm()
            while (true) {
                skipSpaces()
                value = when {
                    match('+') -> value + parseTerm()
                    match('-') -> value - parseTerm()
                    else -> return value
                }
            }
        }

        private fun parseTerm(): Double {
            var value = parsePower()
            while (true) {
                skipSpaces()
                value = when {
                    match('*') -> value * parsePower()
                    match('/') -> {
                        val divisor = parsePower()
                        if (divisor == 0.0) error("No se puede dividir entre cero")
                        value / divisor
                    }
                    else -> return value
                }
            }
        }

        private fun parsePower(): Double {
            var value = parseUnary()
            skipSpaces()
            if (match('^')) value = value.pow(parsePower())
            return value
        }

        private fun parseUnary(): Double {
            skipSpaces()
            return when {
                match('+') -> parseUnary()
                match('-') -> -parseUnary()
                else -> parsePrimary()
            }
        }

        private fun parsePrimary(): Double {
            skipSpaces()
            if (match('(')) {
                val value = parseExpression()
                requireMatch(')')
                return value
            }

            if (index < text.length && (text[index].isDigit() || text[index] == '.')) {
                return parseNumber()
            }

            val name = parseIdentifier()
            return when (name.lowercase()) {
                "pi" -> PI
                "e" -> E
                "sin", "cos", "tan", "asin", "acos", "atan", "sqrt", "log", "ln", "abs" -> {
                    requireMatch('(')
                    val argument = parseExpression()
                    requireMatch(')')
                    applyFunction(name.lowercase(), argument)
                }
                else -> error("Función o valor desconocido: $name")
            }
        }

        private fun parseNumber(): Double {
            val start = index
            var seenExponent = false
            while (index < text.length) {
                val c = text[index]
                when {
                    c.isDigit() || c == '.' -> index++
                    (c == 'e' || c == 'E') && !seenExponent -> {
                        seenExponent = true
                        index++
                        if (index < text.length && (text[index] == '+' || text[index] == '-')) index++
                    }
                    else -> break
                }
            }
            return text.substring(start, index).toDoubleOrNull()
                ?: error("Número inválido")
        }

        private fun parseIdentifier(): String {
            skipSpaces()
            val start = index
            while (index < text.length && text[index].isLetter()) index++
            if (start == index) error("Se esperaba un número o función")
            return text.substring(start, index)
        }

        private fun applyFunction(name: String, value: Double): Double {
            fun toRadiansIfNeeded(v: Double) = if (degrees) Math.toRadians(v) else v
            fun fromRadiansIfNeeded(v: Double) = if (degrees) Math.toDegrees(v) else v
            return when (name) {
                "sin" -> sin(toRadiansIfNeeded(value))
                "cos" -> cos(toRadiansIfNeeded(value))
                "tan" -> tan(toRadiansIfNeeded(value))
                "asin" -> fromRadiansIfNeeded(asin(value))
                "acos" -> fromRadiansIfNeeded(acos(value))
                "atan" -> fromRadiansIfNeeded(atan(value))
                "sqrt" -> {
                    if (value < 0) error("La raíz requiere un valor positivo")
                    sqrt(value)
                }
                "log" -> {
                    if (value <= 0) error("El logaritmo requiere un valor positivo")
                    log10(value)
                }
                "ln" -> {
                    if (value <= 0) error("El logaritmo requiere un valor positivo")
                    ln(value)
                }
                "abs" -> abs(value)
                else -> error("Función no admitida")
            }
        }

        private fun match(expected: Char): Boolean {
            skipSpaces()
            if (index < text.length && text[index] == expected) {
                index++
                return true
            }
            return false
        }

        private fun requireMatch(expected: Char) {
            if (!match(expected)) error("Falta '$expected'")
        }
    }
}
