package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch

@Composable
fun ImagesToPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }

    val selectLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
        images = it.take(60)
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        if (output != null && images.isNotEmpty()) {
            scope.launch {
                runPaidTool(viewModel, tool) { ToolFileUtils.createPdfFromImages(context, images, output) }
                    .onSuccess { onMessage(successMessage("PDF creado con ${images.size} imágenes.", it)) }
                    .onFailure { onMessage(it.message ?: "No se pudo crear el PDF.") }
            }
        }
    }

    ToolPage(tool, onBack) {
        FileSelectionCard(
            title = "Fotografías seleccionadas",
            detail = if (images.isEmpty()) "Todavía no seleccionaste imágenes." else "${images.size} imágenes listas. Se conservará el orden elegido.",
            button = "Seleccionar imágenes",
            onClick = { selectLauncher.launch(arrayOf("image/*")) }
        )
        Button(
            onClick = {
                launchPaidExport(viewModel, tool, onMessage) {
                    saveLauncher.launch("documento_gana_geo.pdf")
                }
            },
            enabled = images.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null)
            Text(" Crear PDF · ${tool.creditCost} créditos")
        }
        InfoToolText("Cada imagen se ajusta a una página A4 sin deformarse. El proceso ocurre dentro del celular.")
    }
}

@Composable
fun PdfToImagesScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var format by rememberSaveable { mutableStateOf("JPG") }

    val inputLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { input = it }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        val source = input
        if (tree != null && source != null) {
            scope.launch {
                runPaidTool(viewModel, tool) {
                    ToolFileUtils.pdfToImages(
                        context,
                        source,
                        tree,
                        if (format == "PNG") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                    )
                }.onSuccess { onMessage(successMessage("Páginas exportadas en la carpeta seleccionada.", it)) }
                    .onFailure { onMessage(it.message ?: "No se pudo convertir el PDF.") }
            }
        }
    }

    ToolPage(tool, onBack) {
        FileSelectionCard(
            "PDF seleccionado",
            if (input == null) "Selecciona un archivo PDF." else "PDF listo para convertir.",
            "Elegir PDF"
        ) { inputLauncher.launch(arrayOf("application/pdf")) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("JPG", "PNG").forEach { option ->
                FilledTonalButton(
                    onClick = { format = option },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = if (format == option) NeonGreen else CardGreen,
                        contentColor = if (format == option) DeepGreen else Color.White
                    )
                ) { Text(option) }
            }
        }
        Button(
            onClick = {
                launchPaidExport(viewModel, tool, onMessage) {
                    folderLauncher.launch(null)
                }
            },
            enabled = input != null,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.Folder, contentDescription = null)
            Text(" Elegir carpeta y convertir · ${tool.creditCost} créditos")
        }
        InfoToolText("Cada página se exporta como una imagen numerada. El PDF original no se modifica.")
    }
}

@Composable
fun PdfOrganizerScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val modes = listOf("Unir PDF", "Reordenar páginas", "Extraer o dividir", "Eliminar páginas", "Girar páginas")
    var modeIndex by rememberSaveable { mutableStateOf(0) }
    var inputs by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var pagesText by rememberSaveable { mutableStateOf("") }
    var rotation by rememberSaveable { mutableStateOf("90") }

    val multiLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
        inputs = it.take(20)
    }
    val singleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
        inputs = listOfNotNull(it)
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        if (output == null || inputs.isEmpty()) return@rememberLauncherForActivityResult
        scope.launch {
            val mode = modes[modeIndex]
            runPaidTool(viewModel, tool) {
                if (modeIndex == 0) {
                    ToolFileUtils.mergePdfs(context, inputs, output)
                } else {
                    val requested = parsePageList(pagesText)
                    val order = when (modeIndex) {
                        1, 2 -> requested
                        3 -> {
                            val pageCount = pdfPageCount(context, inputs.first())
                            val removed = requested.toSet()
                            (1..pageCount).filterNot(removed::contains)
                        }
                        else -> emptyList()
                    }
                    ToolFileUtils.organizePdf(
                        context = context,
                        input = inputs.first(),
                        output = output,
                        pageOrder = order,
                        rotation = if (modeIndex == 4) rotation.toIntOrNull() ?: 90 else 0
                    )
                }
            }.onSuccess { onMessage(successMessage("PDF procesado correctamente.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar el PDF.") }
        }
    }

    ToolPage(tool, onBack) {
        SimpleDropdown("Operación", modes, modeIndex) {
            modeIndex = it
            inputs = emptyList()
            pagesText = ""
        }
        FileSelectionCard(
            title = if (modeIndex == 0) "PDF seleccionados" else "PDF seleccionado",
            detail = if (inputs.isEmpty()) "No hay archivos elegidos." else "${inputs.size} archivo(s) listo(s).",
            button = if (modeIndex == 0) "Elegir varios PDF" else "Elegir PDF",
            onClick = {
                if (modeIndex == 0) multiLauncher.launch(arrayOf("application/pdf"))
                else singleLauncher.launch(arrayOf("application/pdf"))
            }
        )
        when (modeIndex) {
            1 -> PageListField(pagesText, { pagesText = it }, "Orden nuevo", "Ejemplo: 3,1,2,4")
            2 -> PageListField(pagesText, { pagesText = it }, "Páginas a extraer", "Ejemplo: 1-3,7,9")
            3 -> PageListField(pagesText, { pagesText = it }, "Páginas a eliminar", "Ejemplo: 2,5-7")
            4 -> SimpleDropdown("Rotación", listOf("90°", "180°", "270°"), listOf("90", "180", "270").indexOf(rotation).coerceAtLeast(0)) {
                rotation = listOf("90", "180", "270")[it]
            }
        }
        Button(
            onClick = {
                launchPaidExport(viewModel, tool, onMessage) {
                    saveLauncher.launch("pdf_procesado.pdf")
                }
            },
            enabled = when (modeIndex) {
                0 -> inputs.size >= 2
                1, 2, 3 -> inputs.size == 1 && pagesText.isNotBlank()
                else -> inputs.size == 1
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.Save, contentDescription = null)
            Text(" Guardar resultado · ${tool.creditCost} créditos")
        }
        InfoToolText("Los PDF protegidos con contraseña o dañados pueden no abrirse. Nunca se reemplaza el archivo original.")
    }
}

@Composable
fun SignPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var pageText by rememberSaveable { mutableStateOf("1") }
    val strokes = remember { mutableStateListOf<MutableList<Offset>>() }
    var signaturePadSize by remember { mutableStateOf(IntSize.Zero) }

    val inputLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { input = it }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val source = input
        if (output != null && source != null) {
            scope.launch {
                runPaidTool(viewModel, tool) {
                    val signature = signatureBitmap(strokes, signaturePadSize)
                    try {
                        ToolFileUtils.signPdf(context, source, output, signature, pageText.toIntOrNull() ?: 1)
                    } finally {
                        if (!signature.isRecycled) signature.recycle()
                    }
                }.onSuccess { onMessage(successMessage("Documento firmado y guardado.", it)) }
                    .onFailure { onMessage(it.message ?: "No se pudo firmar el PDF.") }
            }
        }
    }

    ToolPage(tool, onBack) {
        FileSelectionCard(
            "PDF seleccionado",
            if (input == null) "Selecciona el documento que deseas firmar." else "Documento listo.",
            "Elegir PDF"
        ) { inputLauncher.launch(arrayOf("application/pdf")) }
        OutlinedTextField(
            value = pageText,
            onValueChange = { pageText = it.filter(Char::isDigit).take(4) },
            label = { Text("Página donde se colocará la firma") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Text("Dibuja tu firma", fontWeight = FontWeight.Bold)
        SignaturePad(strokes, onSizeChanged = { signaturePadSize = it })
        OutlinedButton(onClick = { strokes.clear() }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.Refresh, contentDescription = null)
            Text(" Limpiar firma")
        }
        Button(
            onClick = {
                launchPaidExport(viewModel, tool, onMessage) {
                    saveLauncher.launch("documento_firmado.pdf")
                }
            },
            enabled = input != null && strokes.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.Save, contentDescription = null)
            Text(" Firmar y guardar · ${tool.creditCost} créditos")
        }
        InfoToolText("La firma se coloca en la esquina inferior derecha de la página elegida. Conserva siempre una copia del original.")
    }
}

@Composable
private fun SignaturePad(
    strokes: MutableList<MutableList<Offset>>,
    onSizeChanged: (IntSize) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)
            .background(Color.White, RoundedCornerShape(16.dp))
            .onSizeChanged(onSizeChanged)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { point -> strokes.add(mutableListOf(point)) },
                    onDrag = { change, _ ->
                        change.consume()
                        strokes.lastOrNull()?.add(change.position)
                    }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            strokes.forEach { stroke ->
                if (stroke.size == 1) drawCircle(Color.Black, radius = 2.5f, center = stroke.first())
                else {
                    val path = Path().apply {
                        moveTo(stroke.first().x, stroke.first().y)
                        stroke.drop(1).forEach { lineTo(it.x, it.y) }
                    }
                    drawPath(path, Color.Black, style = Stroke(width = 5f, cap = StrokeCap.Round))
                }
            }
        }
    }
}

private fun signatureBitmap(strokes: List<List<Offset>>, padSize: IntSize): Bitmap {
    require(strokes.isNotEmpty()) { "Dibuja una firma antes de continuar." }
    require(padSize.width > 0 && padSize.height > 0) { "La firma todavía no está lista." }
    val bitmap = Bitmap.createBitmap(900, 300, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    canvas.drawColor(AndroidColor.TRANSPARENT)
    val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.BLACK
        strokeWidth = 8f
        style = AndroidPaint.Style.STROKE
        strokeCap = AndroidPaint.Cap.ROUND
        strokeJoin = AndroidPaint.Join.ROUND
    }
    val scaleX = 900f / padSize.width.toFloat()
    val scaleY = 300f / padSize.height.toFloat()
    strokes.forEach { stroke ->
        if (stroke.size >= 2) {
            val path = android.graphics.Path().apply {
                moveTo(stroke.first().x * scaleX, stroke.first().y * scaleY)
                stroke.drop(1).forEach { lineTo(it.x * scaleX, it.y * scaleY) }
            }
            canvas.drawPath(path, paint)
        }
    }
    return bitmap
}

@Composable
private fun ToolPage(tool: ToolId, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Costo por exportación: ${tool.creditCost} créditos", onBack)
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) { content() }
            }
        }
    }
}

@Composable
private fun FileSelectionCard(title: String, detail: String, button: String, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
            Text(detail, color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Folder, contentDescription = null)
                Text(" $button")
            }
        }
    }
}

@Composable
private fun PageListField(value: String, onChange: (String) -> Unit, label: String, hint: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { ch -> ch.isDigit() || ch == ',' || ch == '-' || ch.isWhitespace() }.take(300)) },
        label = { Text(label) },
        supportingText = { Text(hint) },
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun InfoToolText(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFCC32).copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
        Text(text, modifier = Modifier.padding(14.dp), color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun parsePageList(raw: String): List<Int> {
    if (raw.isBlank()) return emptyList()
    val result = mutableListOf<Int>()
    raw.split(',').map(String::trim).filter(String::isNotBlank).forEach { token ->
        if ('-' in token) {
            val ends = token.split('-', limit = 2).map { it.trim().toIntOrNull() ?: error("Rango inválido: $token") }
            require(ends[0] > 0 && ends[1] >= ends[0]) { "Rango inválido: $token" }
            result += ends[0]..ends[1]
        } else {
            val page = token.toIntOrNull() ?: error("Página inválida: $token")
            require(page > 0) { "Las páginas comienzan en 1." }
            result += page
        }
    }
    return result
}

private suspend fun pdfPageCount(context: android.content.Context, uri: Uri): Int =
    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: error("No se pudo abrir el PDF.")
        pfd.use { descriptor -> android.graphics.pdf.PdfRenderer(descriptor).use { it.pageCount } }
    }
