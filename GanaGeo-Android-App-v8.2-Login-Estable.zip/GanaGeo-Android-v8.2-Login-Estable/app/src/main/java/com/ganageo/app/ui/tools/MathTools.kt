package com.ganageo.app.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.ExpressionEvaluator
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen
import java.text.DecimalFormat
import kotlin.math.PI
import kotlin.math.pow

private val resultFormat = DecimalFormat("0.##########")

@Composable
fun ScientificCalculatorScreen(onBack: () -> Unit) {
    var expression by rememberSaveable { mutableStateOf("") }
    var result by rememberSaveable { mutableStateOf("0") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var degrees by rememberSaveable { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxSize()) {
        ToolHeader("Calculadora científica", "Funciones matemáticas sin conexión", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        OutlinedTextField(
                            value = expression,
                            onValueChange = { expression = it.take(120) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Expresión") },
                            placeholder = { Text("Ejemplo: sin(30)+sqrt(16)") },
                            singleLine = false
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            result,
                            style = MaterialTheme.typography.displaySmall,
                            color = NeonGreen,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.End
                        )
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (degrees) "Grados" else "Radianes", modifier = Modifier.weight(1f))
                            Switch(checked = degrees, onCheckedChange = { degrees = it })
                        }
                    }
                }
            }
            item {
                val rows = listOf(
                    listOf("sin(", "cos(", "tan(", "sqrt("),
                    listOf("log(", "ln(", "abs(", "π"),
                    listOf("7", "8", "9", "÷"),
                    listOf("4", "5", "6", "×"),
                    listOf("1", "2", "3", "−"),
                    listOf("0", ".", "(", ")"),
                    listOf("^", "+", "⌫", "C")
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    rows.forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { key ->
                                FilledTonalButton(
                                    onClick = {
                                        expression = when (key) {
                                            "C" -> ""
                                            "⌫" -> expression.dropLast(1)
                                            else -> expression + key
                                        }
                                        error = null
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(vertical = 12.dp)
                                ) { Text(key, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                    Button(
                        onClick = {
                            runCatching { ExpressionEvaluator(degrees).evaluate(expression) }
                                .onSuccess {
                                    result = resultFormat.format(it)
                                    error = null
                                }
                                .onFailure { error = it.message ?: "Expresión inválida" }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                    ) { Text("Calcular") }
                }
            }
        }
    }
}

data class UnitDef(val name: String, val factor: Double, val offset: Double = 0.0)

data class UnitCategoryDef(val name: String, val units: List<UnitDef>, val temperature: Boolean = false)

private val unitCategories = listOf(
    UnitCategoryDef("Longitud", listOf(
        UnitDef("Milímetro", 0.001), UnitDef("Centímetro", 0.01), UnitDef("Metro", 1.0),
        UnitDef("Kilómetro", 1000.0), UnitDef("Pulgada", 0.0254), UnitDef("Pie", 0.3048),
        UnitDef("Yarda", 0.9144), UnitDef("Milla", 1609.344)
    )),
    UnitCategoryDef("Área", listOf(
        UnitDef("mm²", 0.000001), UnitDef("cm²", 0.0001), UnitDef("m²", 1.0),
        UnitDef("Hectárea", 10000.0), UnitDef("km²", 1_000_000.0), UnitDef("Pie²", 0.09290304)
    )),
    UnitCategoryDef("Volumen", listOf(
        UnitDef("Mililitro", 0.001), UnitDef("Litro", 1.0), UnitDef("m³", 1000.0),
        UnitDef("Galón US", 3.785411784), UnitDef("Taza US", 0.2365882365)
    )),
    UnitCategoryDef("Masa", listOf(
        UnitDef("Miligramo", 0.000001), UnitDef("Gramo", 0.001), UnitDef("Kilogramo", 1.0),
        UnitDef("Tonelada", 1000.0), UnitDef("Libra", 0.45359237), UnitDef("Onza", 0.028349523125)
    )),
    UnitCategoryDef("Tiempo", listOf(
        UnitDef("Segundo", 1.0), UnitDef("Minuto", 60.0), UnitDef("Hora", 3600.0),
        UnitDef("Día", 86400.0), UnitDef("Semana", 604800.0)
    )),
    UnitCategoryDef("Velocidad", listOf(
        UnitDef("m/s", 1.0), UnitDef("km/h", 0.2777777778), UnitDef("mph", 0.44704), UnitDef("Nudo", 0.514444)
    )),
    UnitCategoryDef("Datos", listOf(
        UnitDef("Byte", 1.0), UnitDef("KB", 1024.0), UnitDef("MB", 1024.0.pow(2)),
        UnitDef("GB", 1024.0.pow(3)), UnitDef("TB", 1024.0.pow(4))
    )),
    UnitCategoryDef("Temperatura", listOf(UnitDef("Celsius", 1.0), UnitDef("Fahrenheit", 1.0), UnitDef("Kelvin", 1.0)), true)
)

@Composable
fun UnitConverterScreen(onBack: () -> Unit) {
    var categoryIndex by rememberSaveable { mutableStateOf(0) }
    var fromIndex by rememberSaveable { mutableStateOf(0) }
    var toIndex by rememberSaveable { mutableStateOf(1) }
    var input by rememberSaveable { mutableStateOf("") }
    val category = unitCategories[categoryIndex]
    val value = input.replace(',', '.').toDoubleOrNull()
    val converted = value?.let {
        if (category.temperature) convertTemperature(it, category.units[fromIndex].name, category.units[toIndex].name)
        else it * category.units[fromIndex].factor / category.units[toIndex].factor
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Conversor de unidades", "Conversiones académicas y cotidianas", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                SimpleDropdown(
                    label = "Categoría",
                    options = unitCategories.map { it.name },
                    selectedIndex = categoryIndex,
                    onSelected = {
                        categoryIndex = it
                        fromIndex = 0
                        toIndex = minOf(1, unitCategories[it].units.lastIndex)
                    }
                )
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it.take(30) },
                            label = { Text("Valor") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth()
                        )
                        SimpleDropdown("De", category.units.map { it.name }, fromIndex) { fromIndex = it }
                        SimpleDropdown("A", category.units.map { it.name }, toIndex) { toIndex = it }
                        Text(
                            converted?.let { resultFormat.format(it) } ?: "—",
                            style = MaterialTheme.typography.displaySmall,
                            color = NeonGreen,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

private fun convertTemperature(value: Double, from: String, to: String): Double {
    val celsius = when (from) {
        "Fahrenheit" -> (value - 32) * 5 / 9
        "Kelvin" -> value - 273.15
        else -> value
    }
    return when (to) {
        "Fahrenheit" -> celsius * 9 / 5 + 32
        "Kelvin" -> celsius + 273.15
        else -> celsius
    }
}

@Composable
fun PercentRuleScreen(onBack: () -> Unit) {
    var base by rememberSaveable { mutableStateOf("") }
    var percent by rememberSaveable { mutableStateOf("") }
    var a by rememberSaveable { mutableStateOf("") }
    var b by rememberSaveable { mutableStateOf("") }
    var c by rememberSaveable { mutableStateOf("") }
    val baseValue = base.replace(',', '.').toDoubleOrNull()
    val percentValue = percent.replace(',', '.').toDoubleOrNull()
    val percentResult = if (baseValue != null && percentValue != null) baseValue * percentValue / 100 else null
    val ruleResult = listOf(a, b, c).map { it.replace(',', '.').toDoubleOrNull() }.let { values ->
        if (values.all { it != null } && values[0] != 0.0) values[1]!! * values[2]!! / values[0]!! else null
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Porcentajes y regla de tres", "Cálculos rápidos con resultados claros", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                CalculationCard("Porcentaje") {
                    NumberField(base, { base = it }, "Cantidad base")
                    NumberField(percent, { percent = it }, "Porcentaje %")
                    ResultText(percentResult)
                    if (baseValue != null && percentValue != null) {
                        Text("Aumento: ${resultFormat.format(baseValue + percentResult!!)} · Descuento: ${resultFormat.format(baseValue - percentResult)}")
                    }
                }
            }
            item {
                CalculationCard("Regla de tres directa") {
                    Text("Si A corresponde a B, entonces C corresponde a X")
                    NumberField(a, { a = it }, "A")
                    NumberField(b, { b = it }, "B")
                    NumberField(c, { c = it }, "C")
                    ResultText(ruleResult, prefix = "X = ")
                }
            }
        }
    }
}

@Composable
fun GradesAverageScreen(onBack: () -> Unit) {
    val scores = remember { mutableStateListOf("", "", "", "") }
    val weights = remember { mutableStateListOf("25", "25", "25", "25") }
    var passingGrade by rememberSaveable { mutableStateOf("11") }
    val validScores = scores.map { it.replace(',', '.').toDoubleOrNull() }
    val simple = validScores.filterNotNull().takeIf { it.isNotEmpty() }?.average()
    val weightedParts = validScores.zip(weights.map { it.replace(',', '.').toDoubleOrNull() })
        .filter { it.first != null && it.second != null }
    val weightTotal = weightedParts.sumOf { it.second!! }
    val weighted = if (weightedParts.isNotEmpty() && weightTotal > 0) {
        weightedParts.sumOf { it.first!! * it.second!! } / weightTotal
    } else null
    val pass = passingGrade.replace(',', '.').toDoubleOrNull()

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Promedios y notas", "Escala libre y promedio ponderado", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                CalculationCard("Notas") {
                    scores.indices.forEach { index ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = scores[index],
                                onValueChange = { scores[index] = it.take(8) },
                                label = { Text("Nota ${index + 1}") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = weights[index],
                                onValueChange = { weights[index] = it.take(6) },
                                label = { Text("Peso %") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    NumberField(passingGrade, { passingGrade = it }, "Nota mínima aprobatoria")
                    Text("Promedio simple: ${simple?.let { resultFormat.format(it) } ?: "—"}", style = MaterialTheme.typography.titleMedium)
                    Text("Promedio ponderado: ${weighted?.let { resultFormat.format(it) } ?: "—"}", style = MaterialTheme.typography.titleMedium, color = NeonGreen)
                    if (weighted != null && pass != null) {
                        Text(if (weighted >= pass) "Resultado: aprobado" else "Resultado: todavía no alcanza la nota mínima")
                    }
                }
            }
        }
    }
}

@Composable
fun GeometryScreen(onBack: () -> Unit) {
    val shapes = listOf("Rectángulo", "Triángulo", "Círculo", "Cilindro", "Prisma rectangular", "Esfera")
    var shapeIndex by rememberSaveable { mutableStateOf(0) }
    var a by rememberSaveable { mutableStateOf("") }
    var b by rememberSaveable { mutableStateOf("") }
    var c by rememberSaveable { mutableStateOf("") }
    val x = a.replace(',', '.').toDoubleOrNull()
    val y = b.replace(',', '.').toDoubleOrNull()
    val z = c.replace(',', '.').toDoubleOrNull()
    val results = when (shapeIndex) {
        0 -> if (x != null && y != null) listOf("Área" to x * y, "Perímetro" to 2 * (x + y)) else emptyList()
        1 -> if (x != null && y != null) listOf("Área" to x * y / 2) else emptyList()
        2 -> if (x != null) listOf("Área" to PI * x.pow(2), "Circunferencia" to 2 * PI * x) else emptyList()
        3 -> if (x != null && y != null) listOf("Volumen" to PI * x.pow(2) * y, "Área total" to 2 * PI * x * (x + y)) else emptyList()
        4 -> if (x != null && y != null && z != null) listOf("Volumen" to x * y * z, "Área total" to 2 * (x * y + x * z + y * z)) else emptyList()
        else -> if (x != null) listOf("Volumen" to 4.0 / 3.0 * PI * x.pow(3), "Área" to 4 * PI * x.pow(2)) else emptyList()
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Geometría", "Áreas, perímetros y volúmenes", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { SimpleDropdown("Figura", shapes, shapeIndex) { shapeIndex = it; a = ""; b = ""; c = "" } }
            item {
                CalculationCard(shapes[shapeIndex]) {
                    when (shapeIndex) {
                        0 -> { NumberField(a, { a = it }, "Base"); NumberField(b, { b = it }, "Altura") }
                        1 -> { NumberField(a, { a = it }, "Base"); NumberField(b, { b = it }, "Altura") }
                        2 -> NumberField(a, { a = it }, "Radio")
                        3 -> { NumberField(a, { a = it }, "Radio"); NumberField(b, { b = it }, "Altura") }
                        4 -> { NumberField(a, { a = it }, "Largo"); NumberField(b, { b = it }, "Ancho"); NumberField(c, { c = it }, "Alto") }
                        else -> NumberField(a, { a = it }, "Radio")
                    }
                    results.forEach { (label, value) ->
                        Text("$label: ${resultFormat.format(value)}", style = MaterialTheme.typography.titleMedium, color = NeonGreen)
                    }
                }
            }
        }
    }
}

@Composable
private fun CalculationCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            content()
        }
    }
}

@Composable
private fun NumberField(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.take(30)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth(),
        singleLine = true
    )
}

@Composable
private fun ResultText(value: Double?, prefix: String = "Resultado: ") {
    Text(
        value?.let { prefix + resultFormat.format(it) } ?: "$prefix—",
        style = MaterialTheme.typography.titleLarge,
        color = NeonGreen
    )
}

@Composable
fun SimpleDropdown(label: String, options: List<String>, selectedIndex: Int, onSelected: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(options.getOrElse(selectedIndex) { "" })
            }
            Text("▼")
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.fillMaxWidth(0.9f)
        ) {
            options.forEachIndexed { index, option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelected(index)
                        expanded = false
                    }
                )
            }
        }
    }
}
