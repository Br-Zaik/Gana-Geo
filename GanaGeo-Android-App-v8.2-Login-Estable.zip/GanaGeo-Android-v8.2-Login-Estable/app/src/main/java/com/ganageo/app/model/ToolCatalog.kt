package com.ganageo.app.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.CropRotate
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Draw
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Merge
import androidx.compose.material.icons.rounded.Percent
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.QrCode
import androidx.compose.material.icons.rounded.Rule
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Transform
import androidx.compose.ui.graphics.vector.ImageVector

enum class ToolCategory(val title: String, val subtitle: String) {
    MATH("Números y matemática", "Cálculos, notas, geometría y conversiones"),
    PDF("Documentos y PDF", "Crear, organizar, convertir y firmar PDF"),
    IMAGE("Imágenes", "Comprimir, transformar y exportar imágenes"),
    QUICK("Herramientas rápidas", "QR, texto, cronómetro y temporizador")
}

enum class ToolId(
    val title: String,
    val subtitle: String,
    val category: ToolCategory,
    val icon: ImageVector,
    val creditCost: Int = 0
) {
    SCIENTIFIC_CALCULATOR(
        "Calculadora científica",
        "Operaciones, trigonometría, raíces y logaritmos",
        ToolCategory.MATH,
        Icons.Rounded.Calculate
    ),
    UNIT_CONVERTER(
        "Conversor de unidades",
        "Longitud, área, volumen, masa, temperatura y más",
        ToolCategory.MATH,
        Icons.Rounded.SwapHoriz
    ),
    PERCENT_RULE(
        "Porcentajes y regla de tres",
        "Calcula aumentos, descuentos y proporciones",
        ToolCategory.MATH,
        Icons.Rounded.Percent
    ),
    GRADES_AVERAGES(
        "Promedios y notas",
        "Promedio simple, ponderado y nota necesaria",
        ToolCategory.MATH,
        Icons.Rounded.School
    ),
    GEOMETRY(
        "Geometría",
        "Áreas, perímetros y volúmenes",
        ToolCategory.MATH,
        Icons.Rounded.Straighten
    ),

    IMAGES_TO_PDF(
        "Imágenes a PDF",
        "Combina fotografías en un PDF A4",
        ToolCategory.PDF,
        Icons.Rounded.PictureAsPdf,
        5
    ),
    PDF_ORGANIZER(
        "Organizar PDF",
        "Une, divide, extrae, elimina, reordena y gira páginas",
        ToolCategory.PDF,
        Icons.Rounded.Merge,
        10
    ),
    PDF_TO_IMAGES(
        "PDF a imágenes",
        "Exporta páginas como JPG o PNG",
        ToolCategory.PDF,
        Icons.Rounded.Description,
        5
    ),
    SIGN_PDF(
        "Firmar PDF",
        "Dibuja tu firma y colócala en el documento",
        ToolCategory.PDF,
        Icons.Rounded.Draw,
        5
    ),

    COMPRESS_IMAGE(
        "Comprimir imagen",
        "Reduce el peso y conserva la mejor calidad posible",
        ToolCategory.IMAGE,
        Icons.Rounded.Compress,
        5
    ),
    RESIZE_IMAGE(
        "Cambiar tamaño",
        "Ajusta ancho, alto y proporción",
        ToolCategory.IMAGE,
        Icons.Rounded.Transform,
        5
    ),
    CONVERT_IMAGE(
        "Convertir formato",
        "JPG, PNG y WebP",
        ToolCategory.IMAGE,
        Icons.Rounded.Image,
        5
    ),
    CROP_ROTATE_IMAGE(
        "Recortar, girar y voltear",
        "Relaciones 1:1, 4:5, 9:16 y rotaciones",
        ToolCategory.IMAGE,
        Icons.Rounded.CropRotate,
        5
    ),
    WATERMARK_IMAGE(
        "Texto y marca de agua",
        "Agrega texto, nombre, fecha o firma",
        ToolCategory.IMAGE,
        Icons.Rounded.TextFields,
        5
    ),

    QR_TOOL(
        "Crear y leer QR",
        "Genera QR y escanea con cámara o imagen",
        ToolCategory.QUICK,
        Icons.Rounded.QrCode
    ),
    WORD_COUNTER(
        "Contador de palabras",
        "Palabras, caracteres, líneas y tiempo de lectura",
        ToolCategory.QUICK,
        Icons.Rounded.Rule
    ),
    STOPWATCH_TIMER(
        "Cronómetro y temporizador",
        "Mide sesiones de estudio y descansos",
        ToolCategory.QUICK,
        Icons.Rounded.Timer
    )
}
