package com.ganageo.app.ui.tools

import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import kotlinx.coroutines.delay

suspend fun runPaidTool(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    action: suspend () -> Unit
): Result<Long> {
    val reservation = viewModel.reserveToolUse(tool.name.lowercase(), tool.creditCost.toLong())
        .getOrElse { return Result.failure(it) }

    try {
        action()
    } catch (error: Throwable) {
        runCatching { viewModel.cancelToolUse(reservation) }
        return Result.failure(error)
    }

    // El archivo ya fue generado. No liberamos la reserva si falla momentáneamente
    // la confirmación, porque eso permitiría obtener el resultado sin consumir créditos.
    var lastError: Throwable? = null
    repeat(3) { attempt ->
        val completion = viewModel.completeToolUse(reservation)
        completion.onSuccess { return Result.success(it) }
        lastError = completion.exceptionOrNull()
        if (attempt < 2) delay(700L * (attempt + 1))
    }

    return Result.failure(
        IllegalStateException(
            "El archivo se creó, pero el servidor no pudo confirmar el consumo de créditos. " +
                "No repitas la operación; revisa tu conexión y actualiza la cuenta.",
            lastError
        )
    )
}

fun successMessage(base: String, awarded: Long): String =
    if (awarded > 0) "$base Ganaste $awarded Geo Rewards." else base

fun launchPaidExport(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onMessage: (String) -> Unit,
    launch: () -> Unit
) {
    if (viewModel.hasEnoughToolCredits(tool.creditCost.toLong())) {
        launch()
    } else {
        onMessage("No tienes créditos suficientes para esta herramienta.")
    }
}
