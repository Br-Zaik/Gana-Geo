package com.ganageo.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ganageo.app.data.DeviceIdentityStore
import com.ganageo.app.data.GanaGeoRepository
import com.ganageo.app.data.LocalToolReservation
import com.ganageo.app.data.SupabaseProvider
import com.ganageo.app.data.TestToolBalance
import com.ganageo.app.data.ToolCreditsStore
import com.ganageo.app.model.DashboardData
import com.ganageo.app.model.ToolOperationReservation
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.status.SessionStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.UUID

sealed interface AuthPhase {
    data object ConfigurationMissing : AuthPhase
    data object Initializing : AuthPhase
    data object CompletingSignIn : AuthPhase
    data object SignedOut : AuthPhase
    data object DeviceConflict : AuthPhase
    data object SignedIn : AuthPhase
}

data class GanaGeoUiState(
    val authPhase: AuthPhase = AuthPhase.Initializing,
    val dashboard: DashboardData? = null,
    val testToolBalance: TestToolBalance = TestToolBalance(),
    val isLoading: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    val deviceConflictMessage: String? = null,
    val canReplaceDevice: Boolean = false
)

data class ToolUseReservation(
    val id: String,
    val cost: Long,
    val isLocalTest: Boolean,
    val localReservation: LocalToolReservation? = null
)

class GanaGeoViewModel(application: Application) : AndroidViewModel(application) {
    private val client = SupabaseProvider.client
    private val repository = client?.let(::GanaGeoRepository)
    private val deviceStore = DeviceIdentityStore(application)
    private val toolCreditsStore = ToolCreditsStore(application)

    private var dashboardJob: Job? = null
    private var loadedDashboardUserId: String? = null

    private val _uiState = MutableStateFlow(
        GanaGeoUiState(
            authPhase = if (SupabaseProvider.isConfigured) {
                AuthPhase.Initializing
            } else {
                AuthPhase.ConfigurationMissing
            }
        )
    )
    val uiState: StateFlow<GanaGeoUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            if (BuildConfig.DEBUG) toolCreditsStore.recoverInterruptedReservations()
            refreshTestToolBalance()
        }

        if (client != null && repository != null) {
            viewModelScope.launch {
                client.auth.sessionStatus.collect { status ->
                    when (status) {
                        SessionStatus.Initializing -> {
                            if (_uiState.value.authPhase !in setOf(
                                    AuthPhase.CompletingSignIn,
                                    AuthPhase.DeviceConflict
                                )
                            ) {
                                _uiState.update { it.copy(authPhase = AuthPhase.Initializing) }
                            }
                        }

                        is SessionStatus.Authenticated -> markAuthenticatedAndLoad()

                        is SessionStatus.NotAuthenticated -> {
                            val state = _uiState.value
                            val preserveError = state.authPhase == AuthPhase.SignedOut &&
                                !state.error.isNullOrBlank()
                            if (!preserveError && state.authPhase != AuthPhase.CompletingSignIn) {
                                resetToSignedOut()
                            }
                        }

                        is SessionStatus.RefreshFailure -> {
                            loadedDashboardUserId = null
                            _uiState.update {
                                it.copy(
                                    authPhase = AuthPhase.SignedOut,
                                    dashboard = null,
                                    isLoading = false,
                                    error = "La sesión venció. Inicia sesión nuevamente.",
                                    deviceConflictMessage = null,
                                    canReplaceDevice = false
                                )
                            }
                        }

                        else -> Unit
                    }
                }
            }
        }
    }

    fun onNativeGoogleSignInStarted() {
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.CompletingSignIn,
                dashboard = null,
                isLoading = true,
                error = null,
                message = null,
                deviceConflictMessage = null,
                canReplaceDevice = false
            )
        }
    }

    fun onNativeGoogleSignInCancelled() {
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.SignedOut,
                isLoading = false,
                error = "El acceso con Google fue cancelado antes de completarse."
            )
        }
    }

    fun onNativeGoogleSignInError(message: String) {
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.SignedOut,
                dashboard = null,
                isLoading = false,
                error = message
            )
        }
    }

    fun signInWithGoogleIdToken(idToken: String, nonce: String) {
        val repo = repository ?: run {
            onNativeGoogleSignInError("Supabase no está configurado en esta compilación.")
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.CompletingSignIn,
                    isLoading = true,
                    error = null,
                    message = null
                )
            }

            runCatching {
                withTimeout(SIGN_IN_TIMEOUT_MS) {
                    repo.signInWithGoogleIdToken(idToken, nonce)
                }
            }.onSuccess {
                markAuthenticatedAndLoad()
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedOut,
                        dashboard = null,
                        isLoading = false,
                        error = error.userMessage("No se pudo completar el acceso nativo con Google.")
                    )
                }
            }
        }
    }

    fun reconcileSession() {
        if (client == null || _uiState.value.authPhase == AuthPhase.ConfigurationMissing) return

        viewModelScope.launch {
            if (client.auth.currentSessionOrNull() != null &&
                _uiState.value.authPhase != AuthPhase.DeviceConflict
            ) {
                markAuthenticatedAndLoad()
            }
        }
    }

    fun refreshDashboard() {
        val repo = repository ?: return
        dashboardJob?.cancel()
        dashboardJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.SignedIn,
                    isLoading = true,
                    error = null,
                    deviceConflictMessage = null,
                    canReplaceDevice = false
                )
            }

            runCatching {
                withTimeout(DASHBOARD_TIMEOUT_MS) {
                    val installationId = deviceStore.getOrCreateInstallationId()
                    repo.loadDashboard(installationId)
                }
            }.onSuccess { dashboard ->
                loadedDashboardUserId = repo.currentUserId()
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedIn,
                        dashboard = dashboard,
                        isLoading = false,
                        error = null,
                        deviceConflictMessage = null,
                        canReplaceDevice = false
                    )
                }
            }.onFailure { error ->
                val conflict = error.deviceConflictInfo()
                if (conflict != null) {
                    loadedDashboardUserId = null
                    _uiState.update {
                        it.copy(
                            authPhase = AuthPhase.DeviceConflict,
                            dashboard = null,
                            isLoading = false,
                            error = null,
                            deviceConflictMessage = conflict.message,
                            canReplaceDevice = conflict.canReplace
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            authPhase = AuthPhase.SignedIn,
                            dashboard = null,
                            isLoading = false,
                            error = error.userMessage("No se pudieron cargar tus datos.")
                        )
                    }
                }
            }
        }
    }

    fun replacePreviousInstallation() {
        val repo = repository ?: return
        if (!_uiState.value.canReplaceDevice) return

        // Usa el mismo Job del panel para evitar dos autorizaciones simultáneas.
        dashboardJob?.cancel()
        dashboardJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.DeviceConflict,
                    dashboard = null,
                    isLoading = true,
                    error = null,
                    message = null
                )
            }

            runCatching {
                withTimeout(DASHBOARD_TIMEOUT_MS) {
                    val installationId = deviceStore.getOrCreateInstallationId()

                    // El servidor reemplaza la instalación anterior y activa esta.
                    repo.replaceMyDevice(installationId)

                    // La validación y la carga se completan antes de cambiar de pantalla.
                    repo.loadDashboard(installationId)
                }
            }.onSuccess { dashboard ->
                loadedDashboardUserId = repo.currentUserId()
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedIn,
                        dashboard = dashboard,
                        isLoading = false,
                        error = null,
                        deviceConflictMessage = null,
                        canReplaceDevice = false,
                        message = "Esta instalación quedó autorizada."
                    )
                }
            }.onFailure { error ->
                val conflict = error.deviceConflictInfo()
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.DeviceConflict,
                        dashboard = null,
                        isLoading = false,
                        error = error.userMessage(
                            "No se pudo autorizar esta instalación. Comprueba la conexión y vuelve a intentarlo."
                        ),
                        deviceConflictMessage = conflict?.message
                            ?: it.deviceConflictMessage,
                        canReplaceDevice = conflict?.canReplace
                            ?: it.canReplaceDevice
                    )
                }
            }
        }
    }

    fun hasEnoughToolCredits(cost: Long): Boolean {
        if (cost <= 0) return true
        val serverCredits = _uiState.value.dashboard?.toolCredits?.availableCredits ?: 0
        val testCredits = if (BuildConfig.DEBUG) _uiState.value.testToolBalance.availableCredits else 0
        return serverCredits >= cost || testCredits >= cost
    }

    fun addTestToolCredits(amount: Long) {
        if (!BuildConfig.DEBUG) return
        viewModelScope.launch {
            runCatching { toolCreditsStore.addTestCredits(amount) }
                .onSuccess {
                    refreshTestToolBalance()
                    _uiState.update {
                        it.copy(message = "Se agregaron $amount créditos de prueba. No tienen valor real.")
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(error = error.userMessage("No se pudieron agregar créditos de prueba."))
                    }
                }
        }
    }

    suspend fun reserveToolUse(toolCode: String, cost: Long): Result<ToolUseReservation> {
        if (cost <= 0) {
            return Result.success(
                ToolUseReservation(UUID.randomUUID().toString(), 0, isLocalTest = true)
            )
        }

        val serverAvailable = _uiState.value.dashboard?.toolCredits?.availableCredits ?: 0
        val repo = repository
        if (serverAvailable >= cost && repo != null) {
            return runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                val reservation: ToolOperationReservation = repo.beginToolOperation(
                    toolCode = toolCode,
                    creditCost = cost,
                    installationId = installationId
                )
                refreshDashboard()
                ToolUseReservation(
                    id = reservation.operationId,
                    cost = reservation.reservedCredits,
                    isLocalTest = false
                )
            }
        }

        if (BuildConfig.DEBUG) {
            return runCatching {
                val local = toolCreditsStore.reserve(cost)
                refreshTestToolBalance()
                ToolUseReservation(
                    id = local.id,
                    cost = local.cost,
                    isLocalTest = true,
                    localReservation = local
                )
            }
        }

        return Result.failure(IllegalStateException("No tienes créditos suficientes."))
    }

    suspend fun completeToolUse(reservation: ToolUseReservation): Result<Long> {
        if (reservation.cost == 0L) return Result.success(0)
        return if (reservation.isLocalTest) {
            val local = reservation.localReservation
                ?: return Result.failure(IllegalStateException("Reserva local inválida."))
            runCatching { toolCreditsStore.complete(local) }
                .onSuccess { refreshTestToolBalance() }
        } else {
            val repo = repository
                ?: return Result.failure(IllegalStateException("Servidor no disponible."))
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.completeToolOperation(reservation.id, installationId).awardedPoints
            }.onSuccess { refreshDashboard() }
        }
    }

    suspend fun cancelToolUse(reservation: ToolUseReservation) {
        if (reservation.cost == 0L) return
        if (reservation.isLocalTest) {
            reservation.localReservation?.let { toolCreditsStore.cancel(it) }
            refreshTestToolBalance()
        } else {
            val installationId = deviceStore.getOrCreateInstallationId()
            repository?.cancelToolOperation(reservation.id, installationId)
            refreshDashboard()
        }
    }

    private suspend fun refreshTestToolBalance() {
        if (!BuildConfig.DEBUG) return
        val balance = toolCreditsStore.readBalance()
        _uiState.update { it.copy(testToolBalance = balance) }
    }

    fun requestWithdrawal(amountText: String, method: String, destination: String) {
        val repo = repository ?: return
        val amount = amountText.replace(',', '.').toDoubleOrNull()
        val available = _uiState.value.dashboard?.wallet?.availableAmount ?: 0.0

        when {
            amount == null || amount < 5.0 -> {
                _uiState.update { it.copy(error = "El retiro mínimo es S/5.") }
                return
            }

            amount > available -> {
                _uiState.update { it.copy(error = "No tienes saldo disponible suficiente.") }
                return
            }

            destination.trim().length < 5 -> {
                _uiState.update { it.copy(error = "Escribe un número o correo válido para el pago.") }
                return
            }
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.requestWithdrawal(amount, method, destination, installationId)
            }.onSuccess {
                _uiState.update {
                    it.copy(
                        message = "Solicitud registrada. El saldo quedó bloqueado hasta su revisión.",
                        isLoading = false
                    )
                }
                refreshDashboard()
            }.onFailure { error ->
                handleSensitiveOperationFailure(
                    error = error,
                    fallback = "No se pudo registrar el retiro. Ejecuta primero el SQL seguro incluido."
                )
            }
        }
    }

    fun cancelWithdrawal(withdrawalId: String) {
        val repo = repository ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.cancelWithdrawal(withdrawalId, installationId)
            }.onSuccess {
                _uiState.update {
                    it.copy(message = "Solicitud cancelada y saldo liberado.", isLoading = false)
                }
                refreshDashboard()
            }.onFailure { error ->
                handleSensitiveOperationFailure(error, "No se pudo cancelar la solicitud.")
            }
        }
    }

    private fun handleSensitiveOperationFailure(error: Throwable, fallback: String) {
        val conflict = error.deviceConflictInfo()
        if (conflict != null) {
            loadedDashboardUserId = null
            dashboardJob?.cancel()
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.DeviceConflict,
                    dashboard = null,
                    isLoading = false,
                    error = null,
                    deviceConflictMessage = conflict.message,
                    canReplaceDevice = conflict.canReplace
                )
            }
        } else {
            _uiState.update {
                it.copy(isLoading = false, error = error.userMessage(fallback))
            }
        }
    }

    fun signOut() {
        val repo = repository ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching { repo.signOut() }
                .onSuccess {
                    loadedDashboardUserId = null
                    dashboardJob?.cancel()
                    resetToSignedOut()
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = error.userMessage("No se pudo cerrar la sesión.")
                        )
                    }
                }
        }
    }

    fun clearNotice() {
        _uiState.update { it.copy(message = null, error = null) }
    }

    private fun markAuthenticatedAndLoad() {
        val userId = repository?.currentUserId()
        if (userId.isNullOrBlank()) {
            _uiState.update {
                it.copy(authPhase = AuthPhase.CompletingSignIn, isLoading = true)
            }
            return
        }

        if (_uiState.value.authPhase == AuthPhase.DeviceConflict) return

        // El evento de sesión y el resultado del selector de Google pueden llegar
        // casi al mismo tiempo. No inicies una segunda carga para el mismo usuario.
        if (dashboardJob?.isActive == true &&
            _uiState.value.authPhase == AuthPhase.SignedIn
        ) return

        val shouldLoadDashboard = loadedDashboardUserId != userId ||
            _uiState.value.dashboard == null
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.SignedIn,
                isLoading = shouldLoadDashboard,
                error = null
            )
        }

        if (shouldLoadDashboard) refreshDashboard()
    }

    private fun resetToSignedOut() {
        loadedDashboardUserId = null
        dashboardJob?.cancel()
        _uiState.value = GanaGeoUiState(authPhase = AuthPhase.SignedOut)
    }

    private data class DeviceConflictInfo(
        val message: String,
        val canReplace: Boolean
    )

    private fun Throwable.deviceConflictInfo(): DeviceConflictInfo? {
        val raw = message.orEmpty()
        return when {
            raw.contains("account is already linked to another active device", ignoreCase = true) ->
                DeviceConflictInfo(
                    message = "Tu cuenta sigue vinculada a una instalación anterior. Puede ser una reinstalación o un cambio de teléfono.",
                    canReplace = true
                )

            raw.contains("device is already linked to another account", ignoreCase = true) ->
                DeviceConflictInfo(
                    message = "Esta instalación ya está vinculada a otra cuenta. Cierra sesión y entra con esa cuenta, o solicita ayuda para liberarla.",
                    canReplace = false
                )

            raw.contains("installation is not active", ignoreCase = true) ->
                DeviceConflictInfo(
                    message = "Esta instalación fue reemplazada por otra y ya no tiene acceso a la cuenta.",
                    canReplace = false
                )

            else -> null
        }
    }

    private fun Throwable.userMessage(fallback: String): String {
        if (this is TimeoutCancellationException) {
            return "$fallback La conexión tardó demasiado; vuelve a intentarlo."
        }

        val raw = message.orEmpty()
        return when {
            raw.contains("account is not active", ignoreCase = true) ->
                "Tu cuenta no está activa. Comunícate con soporte antes de continuar."

            raw.contains("insufficient", ignoreCase = true) ->
                "No tienes saldo o créditos suficientes."

            raw.contains("PGRST202", ignoreCase = true) ||
                (raw.contains("function", ignoreCase = true) &&
                    raw.contains("not", ignoreCase = true)) ->
                "$fallback La función requerida todavía no existe en Supabase."

            raw.contains("Nonces mismatch", ignoreCase = true) ->
                "$fallback La validación de seguridad del acceso no coincidió. Instala la versión corregida de Gana Geo."

            raw.isNotBlank() -> {
                val concise = raw
                    .substringBefore("\nURL:")
                    .substringBefore(" URL:")
                    .substringBefore("\nHeaders:")
                    .substringBefore(" Headers:")
                    .trim()
                if (concise.isBlank()) fallback else "$fallback ${concise.take(180)}"
            }

            else -> fallback
        }
    }

    private companion object {
        const val SIGN_IN_TIMEOUT_MS = 25_000L
        const val DASHBOARD_TIMEOUT_MS = 20_000L
    }
}
