package com.ganageo.app

import android.os.Build
import android.content.Intent
import android.os.Bundle
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import android.view.WindowManager
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import androidx.lifecycle.lifecycleScope
import com.ganageo.app.ui.GanaGeoApp
import com.ganageo.app.ui.theme.GanaGeoTheme
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.security.SecureRandom

class MainActivity : ComponentActivity() {
    private val viewModel: GanaGeoViewModel by viewModels()
    private val credentialManager by lazy { CredentialManager.create(this) }
    private var googleSignInJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        // Muestra el logo mientras arranca; se quita solo al dibujar la primera pantalla.
        installSplashScreen()
        super.onCreate(savedInstanceState)
        val systemBarScrim = android.graphics.Color.rgb(6, 29, 18)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(systemBarScrim))
        window.decorView.setBackgroundColor(systemBarScrim)
        window.statusBarColor = systemBarScrim
        window.navigationBarColor = systemBarScrim
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                } else {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
        }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(systemBarScrim),
            navigationBarStyle = SystemBarStyle.dark(systemBarScrim)
        )

        if (savedInstanceState == null) handleShortcutIntent(intent)

        setContent {
            GanaGeoTheme {
                GanaGeoApp(
                    viewModel = viewModel,
                    onGoogleLogin = ::launchNativeGoogleSignIn,
                    onSignOut = ::signOutAndClearCredentialState
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShortcutIntent(intent)
    }

    /** Atajos al mantener presionado el ícono de Gana Geo. */
    private fun handleShortcutIntent(intent: Intent?) {
        val safeIntent = intent ?: return
        val toolName = safeIntent.getStringExtra(EXTRA_OPEN_TOOL) ?: return
        safeIntent.removeExtra(EXTRA_OPEN_TOOL)
        viewModel.openFromShortcut(toolName)
    }

    override fun onResume() {
        super.onResume()
        viewModel.reconcileSession()
    }

    private fun launchNativeGoogleSignIn() {
        if (googleSignInJob?.isActive == true) return

        val webClientId = BuildConfig.GOOGLE_WEB_CLIENT_ID.trim()
        if (webClientId.isBlank()) {
            viewModel.onNativeGoogleSignInError(
                "Falta GOOGLE_WEB_CLIENT_ID. Agrega en GitHub el ID del cliente OAuth de tipo Web usado por Supabase."
            )
            return
        }

        googleSignInJob = lifecycleScope.launch {
            viewModel.onNativeGoogleSignInStarted()
            val rawNonce = generateSecureRandomNonce()
            val googleNonce = sha256Hex(rawNonce)

            try {
                val googleOption = GetSignInWithGoogleOption.Builder(webClientId)
                    .setNonce(googleNonce)
                    .build()
                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleOption)
                    .build()

                val response = credentialManager.getCredential(
                    context = this@MainActivity,
                    request = request
                )

                val credential = response.credential
                if (credential !is CustomCredential ||
                    credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                ) {
                    viewModel.onNativeGoogleSignInError(
                        "Android devolvió una credencial que no pertenece a Google."
                    )
                    return@launch
                }

                val googleCredential = GoogleIdTokenCredential.createFrom(credential.data)
                viewModel.signInWithGoogleIdToken(
                    idToken = googleCredential.idToken,
                    nonce = rawNonce
                )
            } catch (_: GetCredentialCancellationException) {
                viewModel.onNativeGoogleSignInCancelled()
            } catch (_: NoCredentialException) {
                viewModel.onNativeGoogleSignInError(
                    "No se encontró una cuenta de Google disponible. Agrega una cuenta al teléfono y vuelve a intentarlo."
                )
            } catch (error: GetCredentialException) {
                viewModel.onNativeGoogleSignInError(
                    "No se pudo abrir el selector de cuentas de Google: ${error.message.orEmpty().take(160)}"
                )
            } catch (error: Throwable) {
                viewModel.onNativeGoogleSignInError(
                    "No se pudo iniciar sesión con Google: ${error.message.orEmpty().take(160)}"
                )
            }
        }
    }

    private fun signOutAndClearCredentialState() {
        viewModel.signOut()
        lifecycleScope.launch {
            runCatching {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            }
        }
    }

    private fun generateSecureRandomNonce(byteLength: Int = 32): String {
        val randomBytes = ByteArray(byteLength)
        SecureRandom().nextBytes(randomBytes)
        return Base64.encodeToString(
            randomBytes,
            Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING
        )
    }

    companion object {
        const val EXTRA_OPEN_TOOL = "open_tool"
    }
}
