package com.ganageo.app.tools

import kotlin.math.abs

/**
 * Íconos que el lector confunde con letras al lado de un título:
 * "8 PERFIL" (el muñequito leído como 8), "6 CONTACTO" (el teléfono),
 * "lCONOCIMIENTOS" (el borde del círculo pegado como "l").
 * Sin Android: se prueba en la computadora.
 */
object ScanIcons {

    /** Palabra con su caja y el color de su tinta (null si no se pudo medir). */
    class Word(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int, val ink: Int?)

    private fun dist(a: Int, b: Int): Int =
        abs(((a shr 16) and 0xFF) - ((b shr 16) and 0xFF)) +
            abs(((a shr 8) and 0xFF) - ((b shr 8) and 0xFF)) +
            abs((a and 0xFF) - (b and 0xFF))

    private val bullets = setOf("•", "·", "●", "▪", "■", "-", "–", "—", "e", "o", "°", "*")

    /**
     * Cuántas palabras del principio del renglón son en realidad un ícono.
     * Una palabra cortita (1 o 2 signos) separada del resto, de OTRO color que el
     * texto, o mucho más alta que las letras, es un ícono.
     */
    fun leadingIcons(words: List<Word>): Int {
        if (words.size < 2) return 0
        var dropped = 0
        while (dropped < 2 && words.size - dropped >= 2) {
            val first = words[dropped]
            val next = words[dropped + 1]
            val text = first.text.trim()
            if (text.isEmpty() || text.length > 3 || text in bullets) break
            // Alto de la letra: el del resto del renglón (no el de la palabra de al lado,
            // que también puede ser un ícono).
            val rest = words.subList(dropped + 1, words.size).map { (it.bottom - it.top).coerceAtLeast(1) }.sorted()
            val lineHeight = rest[rest.size / 2]
            val gap = next.left - first.right
            if (gap < lineHeight * 0.25f) break
            val otherColor = text.length <= 2 && first.ink != null && next.ink != null && dist(first.ink, next.ink) > 90
            val taller = (first.bottom - first.top) > lineHeight * 1.3f
            if (!otherColor && !taller) break
            dropped++
        }
        return dropped
    }

    /**
     * Quita un trazo pegado al principio de una palabra en mayúsculas
     * ("lCONOCIMIENTOS" → "CONOCIMIENTOS") si sin él es una palabra conocida.
     */
    fun stripGlued(word: String, known: (String) -> Boolean): String {
        if (word.length < 5) return word
        val first = word[0]
        val second = word[1]
        if (first !in "lI|!1" || !second.isLetter() || !second.isUpperCase()) return word
        val rest = word.substring(1)
        // Una palabra en mayúsculas no empieza con "l" minúscula, "|" ni "!".
        if (first in "l|!") return rest
        return if (known(rest.lowercase()) && !known(word.lowercase())) rest else word
    }
}
