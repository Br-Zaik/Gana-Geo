package com.ganageo.app.tools

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * "Mejorar imágenes" del Escáner: las piezas que se sacan de la hoja (logos, fotos,
 * íconos) se pasan por una IA local que las limpia (Original) o las agranda x2 con
 * más nitidez. Las letras no: esas ya se escriben nuevas.
 *
 * IA: Real-ESRGAN realesr-animevideov3 (Xintao Wang y otros, licencia BSD 3-Clause),
 * la misma de "Mejorar imagen" de Zeta Paint. Siempre agranda x4:
 *  - x2 = x4 promediado 2x2 (más nítido que agrandar x2 directo).
 *  - Original (x1) = x4 promediado 4x4: limpia el JPG y los bordes sin agrandar.
 * Trabaja por pedazos con borde de solape (la memoria no depende del tamaño) y se
 * puede cancelar entre pedazos.
 *
 * Lo transparente (la forma recortada de un ícono) no deja halo: antes de la IA se
 * rellena con el color del borde más cercano; la transparencia se agranda aparte.
 *
 * Esta IA es de dibujos: en una FOTO deja las texturas "pintadas" (rocas, tierra).
 * Por eso en fotos va solo un poco de IA ([PHOTO_MIX], limpia el JPG) sobre la foto
 * agrandada suave, y después un realce de bordes clásico ([sharpen]): nítida y natural.
 *
 * Sin Android (la IA se pasa como [Model]): se prueba en la PC.
 */
object ScanUpscale {

    /** La red: recibe RGB 0..1 en planos (3·h·w) y devuelve 3·(4h)·(4w). */
    fun interface Model {
        fun run(chw: FloatArray, height: Int, width: Int): FloatArray
    }

    /** Solape alrededor de cada pedazo (píxeles de entrada): sin costuras. */
    const val PAD = 12

    /** Cuánto de la IA va en una foto (el resto es la foto agrandada suave). */
    const val PHOTO_MIX = 0.3f

    /** Realce de bordes de las fotos (máscara de enfoque). */
    const val PHOTO_SHARPEN = 0.5f

    /** Lado mínimo de una pieza para mejorarla (más chica no se nota). */
    const val MIN_SIDE = 6

    /**
     * Pieza mejorada: [scale] 1 (Original) o 2 (x2). Fotos: mezcla con [PHOTO_MIX].
     * [progress] (pedazos hechos, total): devolver false cancela (devuelve null).
     */
    fun enhance(
        pixels: IntArray,
        width: Int,
        height: Int,
        scale: Int,
        tile: Int,
        model: Model,
        progress: ((Int, Int) -> Boolean)? = null
    ): IntArray? {
        val ai = upscale(pixels, width, height, scale, tile, PAD, model, progress) ?: return null
        if (!isPhoto(pixels, width, height)) return ai
        val soft = resizeSmooth(pixels, width, height, scale)
        return sharpen(blend(ai, soft, PHOTO_MIX), width * scale, height * scale, PHOTO_SHARPEN)
    }

    /**
     * Máscara de enfoque: color + (color − color borroso)·[amount]. Borroso = Gauss
     * (sigma 1, en dos pasadas). La transparencia no cambia.
     */
    fun sharpen(pixels: IntArray, width: Int, height: Int, amount: Float): IntArray {
        if (width < 3 || height < 3 || amount <= 0f) return pixels
        val kernel = floatArrayOf(0.0044f, 0.054f, 0.242f, 0.3992f, 0.242f, 0.054f, 0.0044f)
        val count = width * height
        val r = FloatArray(count)
        val g = FloatArray(count)
        val b = FloatArray(count)
        for (i in 0 until count) {
            val c = pixels[i]
            r[i] = ((c shr 16) and 255).toFloat()
            g[i] = ((c shr 8) and 255).toFloat()
            b[i] = (c and 255).toFloat()
        }
        fun blur(src: FloatArray): FloatArray {
            val mid = FloatArray(count)
            for (y in 0 until height) {
                val row = y * width
                for (x in 0 until width) {
                    var sum = 0f
                    for (k in -3..3) sum += src[row + (x + k).coerceIn(0, width - 1)] * kernel[k + 3]
                    mid[row + x] = sum
                }
            }
            val out = FloatArray(count)
            for (y in 0 until height) for (x in 0 until width) {
                var sum = 0f
                for (k in -3..3) sum += mid[(y + k).coerceIn(0, height - 1) * width + x] * kernel[k + 3]
                out[y * width + x] = sum
            }
            return out
        }
        val br = blur(r)
        val bg = blur(g)
        val bb = blur(b)
        val out = IntArray(count)
        for (i in 0 until count) {
            fun v(a: Float, blurred: Float) = (a + (a - blurred) * amount).roundToInt().coerceIn(0, 255)
            out[i] = (pixels[i] and -0x1000000) or (v(r[i], br[i]) shl 16) or (v(g[i], bg[i]) shl 8) or v(b[i], bb[i])
        }
        return out
    }

    /**
     * Agranda con la IA. [scale] 1, 2 o 4. Devuelve ARGB de (w·scale)×(h·scale), o null
     * si se canceló.
     */
    fun upscale(
        pixels: IntArray,
        width: Int,
        height: Int,
        scale: Int,
        tile: Int,
        pad: Int,
        model: Model,
        progress: ((Int, Int) -> Boolean)? = null
    ): IntArray? {
        require(scale == 1 || scale == 2 || scale == 4) { "escala" }
        require(width > 0 && height > 0 && pixels.size >= width * height) { "tamaño" }
        val side = max(16, tile)
        val outWidth = width * scale
        val outHeight = height * scale
        val hasAlpha = pixels.any { (it ushr 24) < 255 }
        val rgb = if (hasAlpha) fillTransparent(pixels, width, height) else pixels
        val out = IntArray(outWidth * outHeight)
        val tilesX = (width + side - 1) / side
        val tilesY = (height + side - 1) / side
        val total = tilesX * tilesY
        var done = 0
        if (progress != null && !progress(0, total)) return null
        val factor = 4 / scale
        val inverse = 1f / (factor * factor)
        for (j in 0 until tilesY) {
            for (i in 0 until tilesX) {
                val x0 = i * side
                val y0 = j * side
                val x1 = min(width, x0 + side)
                val y1 = min(height, y0 + side)
                val px0 = max(0, x0 - pad)
                val py0 = max(0, y0 - pad)
                val px1 = min(width, x1 + pad)
                val py1 = min(height, y1 + pad)
                val tileWidth = px1 - px0
                val tileHeight = py1 - py0
                val plane = tileWidth * tileHeight
                val input = FloatArray(3 * plane)
                for (y in 0 until tileHeight) {
                    val from = (py0 + y) * width + px0
                    val to = y * tileWidth
                    for (x in 0 until tileWidth) {
                        val c = rgb[from + x]
                        input[to + x] = ((c shr 16) and 255) / 255f
                        input[plane + to + x] = ((c shr 8) and 255) / 255f
                        input[2 * plane + to + x] = (c and 255) / 255f
                    }
                }
                val result = model.run(input, tileHeight, tileWidth)
                val resultWidth = tileWidth * 4
                val resultPlane = resultWidth * tileHeight * 4
                check(result.size >= 3 * resultPlane) { "salida de la IA corta" }
                // Solo la parte sin solape, promediada a la escala pedida.
                val cx0 = (x0 - px0) * 4
                val cy0 = (y0 - py0) * 4
                val copyWidth = (x1 - x0) * scale
                val copyHeight = (y1 - y0) * scale
                for (y in 0 until copyHeight) {
                    val dest = (y0 * scale + y) * outWidth + x0 * scale
                    for (x in 0 until copyWidth) {
                        val s0 = (cy0 + factor * y) * resultWidth + cx0 + factor * x
                        var r = 0f
                        var g = 0f
                        var b = 0f
                        for (yy in 0 until factor) {
                            val s = s0 + yy * resultWidth
                            for (xx in 0 until factor) {
                                r += result[s + xx]
                                g += result[resultPlane + s + xx]
                                b += result[2 * resultPlane + s + xx]
                            }
                        }
                        out[dest + x] = (0xFF shl 24) or (byte(r * inverse) shl 16) or (byte(g * inverse) shl 8) or byte(b * inverse)
                    }
                }
                done++
                if (progress != null && !progress(done, total)) return null
            }
        }
        if (hasAlpha) applyAlpha(pixels, width, height, out, outWidth, outHeight)
        return out
    }

    private fun byte(value: Float): Int = (value * 255f).roundToInt().coerceIn(0, 255)

    /**
     * ¿Es una foto (muchos colores y tonos seguidos) o un dibujo plano (ícono, logo)?
     * Se cuentan los colores distintos (agrupados de a 16 tonos) entre lo que se ve.
     */
    fun isPhoto(pixels: IntArray, width: Int, height: Int): Boolean {
        if (width < 24 || height < 24) return false
        val seen = BooleanArray(4096)
        var distinct = 0
        var opaque = 0
        val step = max(1, ((width.toLong() * height) / 40_000L).toInt())
        var i = 0
        val count = width * height
        while (i < count) {
            val c = pixels[i]
            if ((c ushr 24) >= 200) {
                opaque++
                val key = (((c shr 20) and 15) shl 8) or (((c shr 12) and 15) shl 4) or ((c shr 4) and 15)
                if (!seen[key]) {
                    seen[key] = true
                    distinct++
                }
            }
            i += step
        }
        if (opaque < 400) return false
        return distinct >= 260
    }

    /** a·t + b·(1−t), con la transparencia de [a]. */
    fun blend(a: IntArray, b: IntArray, t: Float): IntArray {
        val out = IntArray(a.size)
        val u = 1f - t
        for (i in a.indices) {
            val p = a[i]
            val q = b[i]
            val r = (((p shr 16) and 255) * t + ((q shr 16) and 255) * u).roundToInt()
            val g = (((p shr 8) and 255) * t + ((q shr 8) and 255) * u).roundToInt()
            val bl = ((p and 255) * t + (q and 255) * u).roundToInt()
            out[i] = (p and -0x1000000) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or bl.coerceIn(0, 255)
        }
        return out
    }

    /** Agranda sin IA (bilineal con transparencia premultiplicada: sin bordes oscuros). */
    fun resizeSmooth(pixels: IntArray, width: Int, height: Int, scale: Int): IntArray {
        if (scale == 1) return pixels.copyOf(width * height)
        val outWidth = width * scale
        val outHeight = height * scale
        val out = IntArray(outWidth * outHeight)
        val s = 1f / scale
        for (y in 0 until outHeight) {
            val fy = (y + 0.5f) * s - 0.5f
            val y0 = floor(fy).toInt()
            val ty = fy - y0
            val ya = y0.coerceIn(0, height - 1) * width
            val yb = (y0 + 1).coerceIn(0, height - 1) * width
            for (x in 0 until outWidth) {
                val fx = (x + 0.5f) * s - 0.5f
                val x0 = floor(fx).toInt()
                val tx = fx - x0
                val xa = x0.coerceIn(0, width - 1)
                val xb = (x0 + 1).coerceIn(0, width - 1)
                val c00 = pixels[ya + xa]
                val c01 = pixels[ya + xb]
                val c10 = pixels[yb + xa]
                val c11 = pixels[yb + xb]
                val a00 = (c00 ushr 24) * (1 - tx) * (1 - ty)
                val a01 = (c01 ushr 24) * tx * (1 - ty)
                val a10 = (c10 ushr 24) * (1 - tx) * ty
                val a11 = (c11 ushr 24) * tx * ty
                val alpha = a00 + a01 + a10 + a11
                if (alpha < 0.5f) {
                    out[y * outWidth + x] = 0
                    continue
                }
                fun channel(shift: Int) = ((((c00 shr shift) and 255) * a00 + ((c01 shr shift) and 255) * a01 +
                    ((c10 shr shift) and 255) * a10 + ((c11 shr shift) and 255) * a11) / alpha).roundToInt().coerceIn(0, 255)
                out[y * outWidth + x] = (min(255, alpha.roundToInt()) shl 24) or (channel(16) shl 16) or (channel(8) shl 8) or channel(0)
            }
        }
        return out
    }

    /** Color de lo transparente = el del borde visible más cercano (hasta 16 px; más lejos, blanco). */
    fun fillTransparent(pixels: IntArray, width: Int, height: Int): IntArray {
        val count = width * height
        val colors = IntArray(count)
        val ok = BooleanArray(count)
        var front = IntArray(count)
        var frontSize = 0
        for (i in 0 until count) {
            if ((pixels[i] ushr 24) >= 128) {
                colors[i] = pixels[i] or (0xFF shl 24)
                ok[i] = true
                front[frontSize++] = i
            }
        }
        var next = IntArray(count)
        var pass = 0
        while (pass < 16 && frontSize > 0) {
            var nextSize = 0
            for (k in 0 until frontSize) {
                val i = front[k]
                val x = i % width
                val y = i / width
                for (d in 0 until 4) {
                    val q = when (d) {
                        0 -> if (x > 0) i - 1 else -1
                        1 -> if (x < width - 1) i + 1 else -1
                        2 -> if (y > 0) i - width else -1
                        else -> if (y < height - 1) i + width else -1
                    }
                    if (q < 0 || ok[q]) continue
                    ok[q] = true
                    colors[q] = colors[i]
                    next[nextSize++] = q
                }
            }
            val swap = front
            front = next
            next = swap
            frontSize = nextSize
            pass++
        }
        for (i in 0 until count) if (!ok[i]) colors[i] = -1
        return colors
    }

    /** Transparencia agrandada (bilineal) sobre el resultado de la IA. */
    fun applyAlpha(pixels: IntArray, width: Int, height: Int, out: IntArray, outWidth: Int, outHeight: Int) {
        val sx = width / outWidth.toFloat()
        val sy = height / outHeight.toFloat()
        for (y in 0 until outHeight) {
            val fy = (y + 0.5f) * sy - 0.5f
            val y0 = floor(fy).toInt()
            val ty = fy - y0
            val ya = y0.coerceIn(0, height - 1)
            val yb = (y0 + 1).coerceIn(0, height - 1)
            for (x in 0 until outWidth) {
                val fx = (x + 0.5f) * sx - 0.5f
                val x0 = floor(fx).toInt()
                val tx = fx - x0
                val xa = x0.coerceIn(0, width - 1)
                val xb = (x0 + 1).coerceIn(0, width - 1)
                val a = (pixels[ya * width + xa] ushr 24) * (1 - tx) * (1 - ty) +
                    (pixels[ya * width + xb] ushr 24) * tx * (1 - ty) +
                    (pixels[yb * width + xa] ushr 24) * (1 - tx) * ty +
                    (pixels[yb * width + xb] ushr 24) * tx * ty
                val i = y * outWidth + x
                out[i] = (out[i] and 0x00FFFFFF) or (a.roundToInt().coerceIn(0, 255) shl 24)
            }
        }
    }

    /**
     * Escala que se usa de verdad: la pedida, salvo que la pieza sea muy grande
     * (más de [maxPixels] al final): entonces Original (no se agranda).
     */
    fun safeScale(width: Int, height: Int, wanted: Int, maxPixels: Long): Int =
        if (wanted >= 2 && width.toLong() * height * wanted * wanted > maxPixels) 1 else wanted

    /** Huella del contenido de una pieza (para guardar el resultado y no repetir el trabajo). */
    fun fingerprint(pixels: IntArray, width: Int, height: Int): String {
        var h1 = 1125899906842597L
        var h2 = 7L
        for (c in pixels) {
            h1 = 31 * h1 + c
            h2 = h2 * 1_000_003L xor c.toLong()
        }
        return "${width}x${height}_${java.lang.Long.toHexString(h1)}${java.lang.Long.toHexString(h2 and 0xFFFFFF)}"
    }
}
