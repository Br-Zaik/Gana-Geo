package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Piezas simples (sin Android) para rearmar un párrafo escaneado como texto de verdad:
 * unir los renglones leídos en un solo párrafo y volver a cortarlo en renglones
 * cuando la persona lo cambia.
 */
object ScanRebuild {
    private val hyphenEnd = Regex("[\\p{L}]-$")

    /**
     * Une los renglones de un párrafo. Si un renglón termina en palabra cortada
     * con guion ("explota-" + "ción"), la junta sin el guion.
     */
    fun joinLines(lines: List<String>): String {
        val result = StringBuilder()
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (result.isEmpty()) {
                result.append(line)
                continue
            }
            val cut = hyphenEnd.containsMatchIn(result) && line.first().isLowerCase()
            if (cut) {
                result.setLength(result.length - 1)
            } else {
                result.append(' ')
            }
            result.append(line)
        }
        return result.toString()
    }

    /**
     * Corta el texto en renglones que entren en [maxWidth]. Respeta los saltos de
     * línea que escribió la persona. Una palabra que no entra sola se parte por letras.
     */
    fun wrap(text: String, maxWidth: Float, measure: (String) -> Float): List<String> =
        wrap(text, maxWidth, maxWidth, measure)

    /** Igual, pero desde el segundo renglón el ancho es [restWidth] (sangría de viñetas). */
    fun wrap(text: String, firstWidth: Float, restWidth: Float, measure: (String) -> Float): List<String> {
        val result = ArrayList<String>()
        if (firstWidth <= 0f || restWidth <= 0f) {
            result += text.split('\n')
            return result
        }
        for (paragraph in text.split('\n')) {
            val words = paragraph.split(' ').filter { it.isNotEmpty() }
            if (words.isEmpty()) {
                result += ""
                continue
            }
            val line = StringBuilder()
            fun width() = if (result.isEmpty()) firstWidth else restWidth
            for (word in words) {
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (measure(candidate) <= width()) {
                    line.setLength(0)
                    line.append(candidate)
                    continue
                }
                if (line.isNotEmpty()) {
                    result += line.toString()
                    line.setLength(0)
                }
                if (measure(word) <= width()) {
                    line.append(word)
                    continue
                }
                // Palabra más ancha que el renglón: se parte por letras.
                var piece = StringBuilder()
                for (char in word) {
                    if (piece.isNotEmpty() && measure(piece.toString() + char) > width()) {
                        result += piece.toString()
                        piece = StringBuilder()
                    }
                    piece.append(char)
                }
                line.append(piece)
            }
            result += line.toString()
        }
        return result
    }

    /** Valor que deja fuera los extremos: el del puesto [fraction] (0 = menor, 1 = mayor). */
    fun quantile(values: List<Float>, fraction: Float): Float {
        if (values.isEmpty()) return 0f
        val sorted = values.sorted()
        val index = ((sorted.size - 1) * fraction.coerceIn(0f, 1f)).toInt()
        return sorted[index]
    }

    /**
     * Junta los pedazos de un mismo renglón y quita los repetidos. El lector a veces
     * corta un renglón en dos o lo lee dos veces encimado.
     * Devuelve grupos de índices: cada grupo es un renglón final, de izquierda a derecha.
     */
    fun mergeLines(lines: List<OcrLine>): List<IntArray> {
        val order = lines.indices.sortedWith(compareBy({ lines[it].top }, { lines[it].left }))
        val removed = BooleanArray(lines.size)
        // 1) Repetidos: misma altura y encimados de costado. Queda el más ancho.
        for (i in order.indices) {
            val a = order[i]
            if (removed[a]) continue
            for (j in i + 1 until order.size) {
                val b = order[j]
                if (removed[b]) continue
                val la = lines[a]
                val lb = lines[b]
                if (lb.top > la.bottom) break
                val vertical = min(la.bottom, lb.bottom) - max(la.top, lb.top)
                val minHeight = min(la.bottom - la.top, lb.bottom - lb.top).coerceAtLeast(1)
                if (vertical < minHeight * 0.6f) continue
                val horizontal = min(la.right, lb.right) - max(la.left, lb.left)
                val minWidth = min(la.right - la.left, lb.right - lb.left).coerceAtLeast(1)
                if (horizontal > minWidth * 0.3f) {
                    val keepA = (la.right - la.left) >= (lb.right - lb.left)
                    removed[if (keepA) b else a] = true
                    if (!keepA) break
                }
            }
        }
        // 2) Pedazos seguidos en la misma línea, con poco espacio: un solo renglón.
        val alive = order.filter { !removed[it] }
        val used = BooleanArray(lines.size)
        val groups = ArrayList<IntArray>()
        for (start in alive) {
            if (used[start]) continue
            val group = arrayListOf(start)
            used[start] = true
            var current = lines[start]
            var extended = true
            while (extended) {
                extended = false
                var best = -1
                var bestGap = Int.MAX_VALUE
                for (other in alive) {
                    if (used[other]) continue
                    val candidate = lines[other]
                    val height = max(current.bottom - current.top, candidate.bottom - candidate.top).coerceAtLeast(1)
                    val vertical = min(current.bottom, candidate.bottom) - max(current.top, candidate.top)
                    val similar = abs((current.bottom - current.top) - (candidate.bottom - candidate.top)) <= height * 0.3f
                    val gap = candidate.left - current.right
                    if (vertical >= height * 0.6f && similar && gap >= -height / 4 && gap <= height * 0.7f && gap < bestGap) {
                        best = other
                        bestGap = gap
                    }
                }
                if (best >= 0) {
                    used[best] = true
                    group += best
                    val next = lines[best]
                    current = OcrLine(
                        current.text + " " + next.text,
                        min(current.left, next.left), min(current.top, next.top),
                        max(current.right, next.right), max(current.bottom, next.bottom)
                    )
                    extended = true
                }
            }
            groups += group.toIntArray()
        }
        return groups
    }

    private val cleanWord = Regex("^[(¿¡\\\"'“]*(\\p{Lu}?\\p{Ll}+|\\p{Lu}+|\\d+([.,:/-]\\d+)*%?|[\\p{L}\\d]{1,2})[)\\\"'”.,;:!?%]*$")

    /** Qué tan "limpio" se leyó un texto (0 a 1): palabras normales sobre el total. */
    fun textScore(text: String): Float {
        val tokens = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return 0f
        val good = tokens.count { cleanWord.matches(it) || it in setOf("-", "—", "–", "·", "•", "/", "&") }
        return good.toFloat() / tokens.size
    }

    /** Tamaños de hoja conocidos: nombre, ancho y alto en milímetros. */
    val papers = listOf(
        Triple("A4", 210f, 297f),
        Triple("Carta", 215.9f, 279.4f),
        Triple("Oficio", 215.9f, 330.2f),
        Triple("Legal", 215.9f, 355.6f),
        Triple("A5", 148f, 210f)
    )

    /** La hoja que corresponde a una foto recortada (o -1 si no se parece a ninguna). */
    fun paperOf(width: Int, height: Int): Int {
        if (width <= 0 || height <= 0) return -1
        val ratio = max(width, height).toFloat() / min(width, height)
        var best = -1
        var bestError = 0.045f
        papers.forEachIndexed { index, (_, w, h) ->
            if (index == 4) return@forEachIndexed // A5 tiene la misma forma que A4
            val error = abs(ratio - h / w) / (h / w)
            if (error < bestError) {
                best = index
                bestError = error
            }
        }
        return best
    }

    /** Ángulo que más se repite (mediana), en grados. */
    fun medianAngle(angles: List<Float>): Float = if (angles.isEmpty()) 0f else quantile(angles, 0.5f)

    private val listMarker = Regex("^(\\s*(?:[•·▪◦●○■□➢►✓✔*-]|–|—|\\d{1,3}[.)](?:-)?|[a-zA-Z][.)])\\s+)")

    /** Si el texto empieza con viñeta o número de lista ("• ", "1. ", "a) "), cuántas letras ocupa. */
    fun listPrefix(text: String): Int = listMarker.find(text)?.value?.length ?: 0
}
