package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Para elegir la letra más parecida a la de la foto (como hace Acrobat):
 * se toma la forma de una palabra en la foto (dónde hay tinta), se dibuja esa
 * misma palabra con cada letra disponible y se compara punto por punto.
 *
 * Aquí solo está la parte de comparar (sin Android), para poder probarla.
 */
object ScanFontMatch {
    /** Alto con que se comparan las palabras (en puntos de muestra). */
    const val SAMPLE_HEIGHT = 30

    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun dist(a: Int, b: Int) = abs(red(a) - red(b)) + abs(green(a) - green(b)) + abs(blue(a) - blue(b))

    /**
     * Cuánta tinta hay en cada punto (0 a 1): 0 = color del papel, 1 = color de la letra.
     */
    fun inkMap(pixels: IntArray, width: Int, height: Int, background: Int, ink: Int): FloatArray {
        val result = FloatArray(width * height)
        val full = dist(ink, background).coerceAtLeast(40).toFloat()
        // Transición corta alrededor de la mitad: el borde borroso de la foto no
        // engorda la letra (si no, todo parecería negrita).
        val low = full * 0.34f
        val high = full * 0.66f
        for (i in 0 until min(pixels.size, width * height)) {
            val d = dist(pixels[i], background)
            result[i] = ((d - low) / (high - low)).coerceIn(0f, 1f)
        }
        return result
    }

    /**
     * Borde de la tinta: [izquierda, arriba, derecha, abajo). Se ignoran filas y
     * columnas con muy poca tinta (manchas, pedazos del renglón vecino).
     */
    fun inkBounds(map: FloatArray, width: Int, height: Int): IntArray? {
        if (width <= 0 || height <= 0) return null
        val rows = FloatArray(height)
        val columns = FloatArray(width)
        for (y in 0 until height) for (x in 0 until width) {
            val v = map[y * width + x]
            rows[y] += v
            columns[x] += v
        }
        val rowMax = rows.maxOrNull() ?: 0f
        val columnMax = columns.maxOrNull() ?: 0f
        if (rowMax < 0.5f || columnMax < 0.5f) return null
        val rowLimit = max(0.35f, rowMax * 0.006f)
        val columnLimit = max(0.35f, columnMax * 0.01f)
        // Filas: se toma el tramo seguido más grande con tinta (descarta el renglón vecino).
        var bestTop = -1
        var bestBottom = -1
        var bestMass = 0f
        var y = 0
        while (y < height) {
            if (rows[y] < rowLimit) {
                y++
                continue
            }
            val start = y
            var mass = 0f
            while (y < height && rows[y] >= rowLimit) {
                mass += rows[y]
                y++
            }
            if (mass > bestMass) {
                bestMass = mass
                bestTop = start
                bestBottom = y
            }
        }
        var left = 0
        while (left < width && columns[left] < columnLimit) left++
        var right = width
        while (right > left && columns[right - 1] < columnLimit) right--
        if (bestTop < 0 || right - left < 2 || bestBottom - bestTop < 2) return null
        return intArrayOf(left, bestTop, right, bestBottom)
    }

    /** Recorta [bounds] del mapa y lo lleva a outWidth x outHeight (promedio por área). */
    fun resample(map: FloatArray, width: Int, bounds: IntArray, outWidth: Int, outHeight: Int): FloatArray {
        val result = FloatArray(outWidth * outHeight)
        val sourceWidth = (bounds[2] - bounds[0]).toFloat()
        val sourceHeight = (bounds[3] - bounds[1]).toFloat()
        val stepX = sourceWidth / outWidth
        val stepY = sourceHeight / outHeight
        for (oy in 0 until outHeight) {
            val y0 = bounds[1] + oy * stepY
            val y1 = y0 + stepY
            for (ox in 0 until outWidth) {
                val x0 = bounds[0] + ox * stepX
                val x1 = x0 + stepX
                var sum = 0f
                var area = 0f
                var yy = y0.toInt()
                while (yy < y1 && yy < bounds[3]) {
                    val coverY = min(y1, yy + 1f) - max(y0, yy.toFloat())
                    var xx = x0.toInt()
                    while (xx < x1 && xx < bounds[2]) {
                        val coverX = min(x1, xx + 1f) - max(x0, xx.toFloat())
                        val weight = coverX * coverY
                        if (weight > 0f) {
                            sum += map[yy * width + xx] * weight
                            area += weight
                        }
                        xx++
                    }
                    yy++
                }
                result[oy * outWidth + ox] = if (area > 0f) sum / area else 0f
            }
        }
        return result
    }

    /** Lleva la tinta dibujada (0 a 1) a la misma escala que [inkMap]. */
    fun sharpen(values: FloatArray): FloatArray =
        FloatArray(values.size) { ((values[it] - 0.34f) / 0.32f).coerceIn(0f, 1f) }

    /** Parecido entre dos formas del mismo tamaño (0 a 1): tinta en común / tinta total. */
    fun similarity(a: FloatArray, b: FloatArray): Float {
        var common = 0f
        var total = 0f
        for (i in 0 until min(a.size, b.size)) {
            common += min(a[i], b[i])
            total += max(a[i], b[i])
        }
        return if (total <= 0f) 0f else common / total
    }

    /**
     * Puntaje de una letra para una palabra: parecido de forma, menos un castigo si
     * la palabra dibujada sale mucho más ancha o angosta que en la foto.
     * widthRatio = ancho dibujado / ancho en la foto (con el mismo alto).
     */
    fun score(similarity: Float, widthRatio: Float): Float =
        similarity - 0.9f * abs(ln(widthRatio.coerceIn(0.2f, 5f)))

    private val marks = Regex("\\p{Mn}+")

    /**
     * El texto sin tildes ni virgulillas. Para medir: las tildes de la foto quedan
     * separadas de la letra y no se cuentan en el alto del renglón.
     */
    fun withoutMarks(text: String): String =
        java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFD).replace(marks, "")
}
