package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Borra las letras de una foto dejando el fondo como era (como hace Acrobat al
 * "editar un escaneo"). Solo se borran los puntos de las letras, no el renglón
 * entero: las barras de color, sus bordes, sombras y degradados quedan igual.
 *
 * 1. En cada caja de texto se mira el color que domina (el fondo) y se marcan los
 *    puntos que se alejan de él (la letra, su borde suave y su sombra).
 * 2. Cada punto marcado se rellena mezclando los colores sin marcar que tiene a
 *    la izquierda, a la derecha, arriba y abajo (pesa más el más cercano).
 * 3. Sobre una foto o un degradado (fondo con textura) la letra se reconoce por su
 *    color de tinta y no por "lo distinto al fondo", y al relleno se le devuelve el
 *    grano de la foto, copiado de justo arriba o abajo del renglón. Así no queda
 *    una mancha lisa ni borrosa.
 *
 * Trabaja sobre un arreglo de colores ARGB (sin Android) para poder probarlo.
 */
object ScanInpaint {
    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun dist(a: Int, b: Int) = abs(red(a) - red(b)) + abs(green(a) - green(b)) + abs(blue(a) - blue(b))
    private fun rgb(r: Int, g: Int, b: Int): Int =
        -0x1000000 or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    /** boxes: cajas [izquierda, arriba, derecha, abajo) de cada renglón, en píxeles. */
    fun eraseInk(pixels: IntArray, width: Int, height: Int, boxes: List<IntArray>) {
        if (width <= 0 || height <= 0 || pixels.size < width * height || boxes.isEmpty()) return
        val mask = BooleanArray(width * height)
        var minX = width
        var minY = height
        var maxX = 0
        var maxY = 0
        val flat = ArrayList<IntArray>() // cajas de fondo liso: [izq, arriba, der, abajo, color]
        val textured = ArrayList<IntArray>() // cajas sobre foto o degradado: [izq, arriba, der, abajo]
        for (raw in boxes) {
            val left = raw[0].coerceIn(0, width)
            val top = raw[1].coerceIn(0, height)
            val right = raw[2].coerceIn(left, width)
            val bottom = raw[3].coerceIn(top, height)
            if (right - left < 2 || bottom - top < 2) continue
            val grow = max(1, ((bottom - top) * 0.09f).roundToInt())
            val plain = if (isTextured(pixels, width, height, left, top, right, bottom)) {
                markInkOnTexture(pixels, width, height, mask, left, top, right, bottom)
                textured += intArrayOf(left - grow, top - grow, right + grow, bottom + grow)
                null
            } else {
                markInk(pixels, width, height, mask, left, top, right, bottom)
            }
            dilate(mask, width, height, left, top, right, bottom, grow)
            if (plain != null) flat += intArrayOf(left - grow, top - grow, right + grow, bottom + grow, plain)
            minX = min(minX, left - grow)
            minY = min(minY, top - grow)
            maxX = max(maxX, right + grow)
            maxY = max(maxY, bottom + grow)
        }
        if (maxX <= minX || maxY <= minY) return
        val left = minX.coerceAtLeast(0)
        val top = minY.coerceAtLeast(0)
        val right = maxX.coerceAtMost(width)
        val bottom = maxY.coerceAtMost(height)
        fill(pixels, width, height, mask, left, top, right, bottom)
        // Fondo liso (papel, barra de un color): se pinta parejo, sin rayitas.
        for (box in flat) {
            for (y in box[1].coerceAtLeast(0) until box[3].coerceAtMost(height)) {
                val row = y * width
                for (x in box[0].coerceAtLeast(0) until box[2].coerceAtMost(width)) {
                    if (mask[row + x]) pixels[row + x] = box[4]
                }
            }
        }
        // Suavizado de lo rellenado (quita el "tejido" que deja la mezcla).
        repeat(2) { smooth(pixels, width, height, mask, left, top, right, bottom) }
        // Sobre una foto: se le devuelve el grano.
        for (box in textured) addGrain(pixels, width, height, mask, box[0], box[1], box[2], box[3])
    }

    /** Luz de un color (0..255). */
    private fun lum(c: Int) = (red(c) * 299 + green(c) * 587 + blue(c) * 114) / 1000

    /**
     * ¿El renglón está sobre una foto o un degradado? Se miran los costados y lo de
     * arriba y abajo: si cambian mucho de color, el fondo tiene textura.
     */
    private fun isTextured(pixels: IntArray, width: Int, height: Int, left: Int, top: Int, right: Int, bottom: Int): Boolean {
        val boxHeight = bottom - top
        val band = max(2, boxHeight / 4)
        val samples = ArrayList<Int>()
        val stepX = max(1, (right - left) / 60)
        for (y in (top - band - 2).coerceAtLeast(0) until (top - 2).coerceAtLeast(0)) {
            var x = left
            while (x < right) { samples += pixels[y * width + x]; x += stepX }
        }
        for (y in (bottom + 2).coerceAtMost(height) until (bottom + band + 2).coerceAtMost(height)) {
            var x = left
            while (x < right) { samples += pixels[y * width + x]; x += stepX }
        }
        val side = max(3, (boxHeight * 0.35f).roundToInt())
        for (y in top until bottom) {
            for (x in (left - side).coerceAtLeast(0) until left) samples += pixels[y * width + x]
            for (x in right until (right + side).coerceAtMost(width)) samples += pixels[y * width + x]
        }
        if (samples.size < 20) return false
        // Papel con letras al lado: casi todo es del mismo color (las letras son pocas).
        // Foto o degradado: buena parte se aleja del color del medio.
        val lums = samples.map { lum(it) }.sorted()
        val middle = lums[lums.size / 2]
        val away = lums.count { abs(it - middle) > 22 }
        return away > lums.size * 0.38f
    }

    /**
     * Marca la letra sobre un fondo con textura: la tinta es el grupo de colores más
     * distinto del fondo; un punto es letra si se parece más a la tinta que al fondo
     * de su misma columna (lo que hay justo arriba y abajo del renglón).
     */
    private fun markInkOnTexture(pixels: IntArray, width: Int, height: Int, mask: BooleanArray, left: Int, top: Int, right: Int, bottom: Int) {
        val boxHeight = bottom - top
        val gap = max(2, boxHeight / 6)
        // Fondo de cada columna: mezcla de arriba y abajo (sigue al degradado).
        fun columnBackground(x: Int, y: Int): Int {
            val above = (top - gap).takeIf { it >= 0 }?.let { pixels[it * width + x] }
            val below = (bottom + gap).takeIf { it < height }?.let { pixels[it * width + x] }
            if (above == null) return below ?: pixels[y * width + x]
            if (below == null) return above
            val t = ((y - top + gap).toFloat() / (boxHeight + gap * 2)).coerceIn(0f, 1f)
            return rgb(
                (red(above) * (1 - t) + red(below) * t).roundToInt(),
                (green(above) * (1 - t) + green(below) * t).roundToInt(),
                (blue(above) * (1 - t) + blue(below) * t).roundToInt()
            )
        }
        // Tinta: el 12 % de puntos más alejados de su fondo.
        val distances = IntArray((right - left) * boxHeight)
        var k = 0
        for (y in top until bottom) for (x in left until right) {
            distances[k++] = dist(pixels[y * width + x], columnBackground(x, y))
        }
        val sorted = distances.copyOf().also { it.sort() }
        val cut = sorted[(sorted.size * 0.88f).toInt().coerceIn(0, sorted.size - 1)]
        if (cut < 40) return
        var r = 0L
        var g = 0L
        var b = 0L
        var n = 0
        k = 0
        for (y in top until bottom) for (x in left until right) {
            if (distances[k++] >= cut) {
                val c = pixels[y * width + x]
                r += red(c); g += green(c); b += blue(c); n++
            }
        }
        if (n == 0) return
        val ink = rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
        k = 0
        for (y in top until bottom) {
            val row = y * width
            for (x in left until right) {
                val c = pixels[row + x]
                val bg = columnBackground(x, y)
                val toInk = dist(c, ink)
                val toBg = dist(c, bg)
                // Letra (y su borde suave): más cerca de la tinta que del fondo, o muy lejos del fondo.
                if (toInk * 10 < toBg * 9 || distances[k] >= cut) mask[row + x] = true
                k++
            }
        }
    }

    /**
     * Devuelve el grano de la foto a lo rellenado: a cada punto se le suma la
     * diferencia (punto menos su promedio) de un punto sin marcar de arriba o abajo.
     */
    private fun addGrain(pixels: IntArray, width: Int, height: Int, mask: BooleanArray, left0: Int, top0: Int, right0: Int, bottom0: Int) {
        val left = left0.coerceIn(0, width)
        val right = right0.coerceIn(left, width)
        val top = top0.coerceIn(0, height)
        val bottom = bottom0.coerceIn(top, height)
        val boxHeight = bottom - top
        if (right - left < 2 || boxHeight < 2) return
        fun localMean(x: Int, y: Int): Int {
            var rr = 0
            var gg = 0
            var bb = 0
            var n = 0
            for (dy in -2..2) {
                val yy = y + dy
                if (yy < 0 || yy >= height) continue
                for (dx in -2..2) {
                    val xx = x + dx
                    if (xx < 0 || xx >= width) continue
                    val c = pixels[yy * width + xx]
                    rr += red(c); gg += green(c); bb += blue(c); n++
                }
            }
            return rgb(rr / n, gg / n, bb / n)
        }
        val grain = IntArray((right - left) * boxHeight) { Int.MIN_VALUE }
        for (y in top until bottom) {
            for (x in left until right) {
                if (!mask[y * width + x]) continue
                // Donante: el mismo punto, un renglón más arriba (o más abajo).
                val up = y - boxHeight - 2
                val down = y + boxHeight + 2
                val donorY = when {
                    up >= 0 && !mask[up * width + x] -> up
                    down < height && !mask[down * width + x] -> down
                    else -> -1
                }
                if (donorY < 0) continue
                val c = pixels[donorY * width + x]
                val mean = localMean(x, donorY)
                val dr = (red(c) - red(mean)).coerceIn(-60, 60)
                val dg = (green(c) - green(mean)).coerceIn(-60, 60)
                val db = (blue(c) - blue(mean)).coerceIn(-60, 60)
                grain[(y - top) * (right - left) + x - left] = ((dr + 128) shl 16) or ((dg + 128) shl 8) or (db + 128)
            }
        }
        for (y in top until bottom) {
            for (x in left until right) {
                val g = grain[(y - top) * (right - left) + x - left]
                if (g == Int.MIN_VALUE) continue
                val c = pixels[y * width + x]
                pixels[y * width + x] = rgb(
                    red(c) + ((g shr 16) and 0xFF) - 128,
                    green(c) + ((g shr 8) and 0xFF) - 128,
                    blue(c) + (g and 0xFF) - 128
                )
            }
        }
    }

    /** Promedio 5x5 solo sobre los puntos rellenados. */
    private fun smooth(pixels: IntArray, width: Int, height: Int, mask: BooleanArray, left: Int, top: Int, right: Int, bottom: Int) {
        val w = right - left
        val h = bottom - top
        if (w <= 0 || h <= 0) return
        val source = IntArray(w * h)
        for (y in 0 until h) System.arraycopy(pixels, (top + y) * width + left, source, y * w, w)
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (!mask[(top + y) * width + left + x]) continue
                var r = 0
                var g = 0
                var b = 0
                var n = 0
                for (dy in -2..2) {
                    val yy = y + dy
                    if (yy < 0 || yy >= h) continue
                    for (dx in -2..2) {
                        val xx = x + dx
                        if (xx < 0 || xx >= w) continue
                        val c = source[yy * w + xx]
                        r += red(c)
                        g += green(c)
                        b += blue(c)
                        n++
                    }
                }
                pixels[(top + y) * width + left + x] = rgb(r / n, g / n, b / n)
            }
        }
    }

    /**
     * Marca los puntos de letra de una caja (lo que se aleja del color que domina).
     * Se mira también un poco arriba y abajo (tildes, colas de g, p, y), pero si una
     * fila de ese margen es casi toda "distinta", es otro fondo (la hoja fuera de una
     * barra) y no se toca.
     */
    private fun markInk(pixels: IntArray, width: Int, height: Int, mask: BooleanArray, left: Int, top: Int, right: Int, bottom: Int): Int? {
        // Fondo: lo que hay a los costados del renglón, a su misma altura (en una barra
        // de título es la barra; arriba o abajo podría ser la hoja).
        val histR = IntArray(256)
        val histG = IntArray(256)
        val histB = IntArray(256)
        var count = 0
        val side = max(3, ((bottom - top) * 0.35f).roundToInt())
        for (y in top until bottom) {
            val row = y * width
            for (x in (left - side).coerceAtLeast(0) until left) {
                val c = pixels[row + x]
                histR[red(c)]++; histG[green(c)]++; histB[blue(c)]++; count++
            }
            for (x in right until (right + side).coerceAtMost(width)) {
                val c = pixels[row + x]
                histR[red(c)]++; histG[green(c)]++; histB[blue(c)]++; count++
            }
        }
        if (count < (bottom - top) * 2) {
            java.util.Arrays.fill(histR, 0)
            java.util.Arrays.fill(histG, 0)
            java.util.Arrays.fill(histB, 0)
            count = 0
            for (y in top until bottom) for (x in left until right) {
                val c = pixels[y * width + x]
                histR[red(c)]++; histG[green(c)]++; histB[blue(c)]++; count++
            }
        }
        val background = rgb(median(histR, count), median(histG, count), median(histB, count))
        var far = 0
        for (y in top until bottom) for (x in left until right) {
            val d = dist(pixels[y * width + x], background)
            if (d > far) far = d
        }
        if (far < 30) return null // no hay letra
        // Umbral bajo: los bordes suaves de la letra también se borran (si no, quedan fantasmas).
        val threshold = max(24, far / 10)
        val boxHeight = bottom - top
        val extraTop = (boxHeight * 0.22f).roundToInt()
        val extraBottom = (boxHeight * 0.12f).roundToInt()
        val from = (top - extraTop).coerceAtLeast(0)
        val to = (bottom + extraBottom).coerceAtMost(height)
        val span = right - left
        for (y in from until to) {
            val row = y * width
            val margin = y < top || y >= bottom
            if (margin) {
                var different = 0
                for (x in left until right) if (dist(pixels[row + x], background) >= threshold) different++
                if (different * 10 > span * 6) continue
            }
            for (x in left until right) {
                if (dist(pixels[row + x], background) >= threshold) mask[row + x] = true
            }
        }
        // ¿Fondo liso? Lo que no es letra casi no cambia de color.
        var deviation = 0L
        var plain = 0
        for (y in top until bottom) {
            val row = y * width
            for (x in left until right) {
                if (mask[row + x]) continue
                deviation += dist(pixels[row + x], background)
                plain++
            }
        }
        return if (plain > 0 && deviation / plain <= 10) background else null
    }

    /** Agranda lo marcado unos puntos (bordes suaves de la letra). */
    private fun dilate(mask: BooleanArray, width: Int, height: Int, left: Int, top: Int, right: Int, bottom: Int, radius: Int) {
        val l = (left - radius).coerceAtLeast(0)
        val t = (top - radius).coerceAtLeast(0)
        val r = (right + radius).coerceAtMost(width)
        val b = (bottom + radius).coerceAtMost(height)
        val w = r - l
        val h = b - t
        if (w <= 0 || h <= 0) return
        val horizontal = BooleanArray(w * h)
        for (y in 0 until h) {
            val row = (t + y) * width + l
            var last = -radius - 1
            // Hacia la derecha y hacia la izquierda, recordando la última marca.
            for (x in 0 until w) {
                if (mask[row + x]) last = x
                if (x - last <= radius) horizontal[y * w + x] = true
            }
            last = w + radius + 1
            for (x in w - 1 downTo 0) {
                if (mask[row + x]) last = x
                if (last - x <= radius) horizontal[y * w + x] = true
            }
        }
        for (x in 0 until w) {
            var last = -radius - 1
            for (y in 0 until h) {
                if (horizontal[y * w + x]) last = y
                if (y - last <= radius) mask[(t + y) * width + l + x] = true
            }
            last = h + radius + 1
            for (y in h - 1 downTo 0) {
                if (horizontal[y * w + x]) last = y
                if (last - y <= radius) mask[(t + y) * width + l + x] = true
            }
        }
    }

    /**
     * Rellena lo marcado. Primero de izquierda a derecha (se guarda el color y el
     * largo del tramo), después de arriba abajo, y se mezclan los dos.
     */
    private fun fill(pixels: IntArray, width: Int, height: Int, mask: BooleanArray, left: Int, top: Int, right: Int, bottom: Int) {
        val w = right - left
        val h = bottom - top
        // Color estimado de izquierda a derecha; en el byte alto, el largo del tramo (1..255; 0 = sin dato).
        val horizontal = IntArray(w * h)
        for (y in 0 until h) {
            val row = (top + y) * width
            var x = 0
            while (x < w) {
                if (!mask[row + left + x]) {
                    x++
                    continue
                }
                var start = left + x
                var end = left + x
                while (start > 0 && mask[row + start - 1]) start--
                while (end < width - 1 && mask[row + end + 1]) end++
                val before = sample(pixels, mask, row, start - 1, -1, width)
                val after = sample(pixels, mask, row, end + 1, 1, width)
                val length = end - start + 1
                val weight = length.coerceIn(1, 255)
                for (px in max(start, left) .. min(end, right - 1)) {
                    val t = (px - start + 1f) / (length + 1f)
                    val color = mix(before, after, t) ?: continue
                    horizontal[y * w + px - left] = (weight shl 24) or (color and 0xFFFFFF)
                }
                x = min(end, right - 1) - left + 1
            }
        }
        for (cx in 0 until w) {
            val column = left + cx
            var y = 0
            while (y < h) {
                if (!mask[(top + y) * width + column]) {
                    y++
                    continue
                }
                var start = top + y
                var end = top + y
                while (start > 0 && mask[(start - 1) * width + column]) start--
                while (end < height - 1 && mask[(end + 1) * width + column]) end++
                val before = sampleColumn(pixels, mask, column, start - 1, -1, width, height)
                val after = sampleColumn(pixels, mask, column, end + 1, 1, width, height)
                val length = end - start + 1
                for (py in max(start, top) .. min(end, bottom - 1)) {
                    val t = (py - start + 1f) / (length + 1f)
                    val vertical = mix(before, after, t)
                    val packed = horizontal[(py - top) * w + cx]
                    val horizontalLength = (packed ushr 24) and 0xFF
                    val color = when {
                        vertical != null && horizontalLength > 0 -> {
                            // Pesa más el tramo más corto (el borde más cercano).
                            val wh = 1f / horizontalLength
                            val wv = 1f / length
                            mix(packed or -0x1000000, vertical, wv / (wh + wv))
                        }
                        vertical != null -> vertical
                        horizontalLength > 0 -> packed or -0x1000000
                        else -> null
                    } ?: continue
                    pixels[py * width + column] = color or -0x1000000
                }
                y = min(end, bottom - 1) - top + 1
            }
        }
    }

    /** Promedio de hasta 2 puntos sin marcar desde [start] hacia [step] en una fila. */
    private fun sample(pixels: IntArray, mask: BooleanArray, row: Int, start: Int, step: Int, width: Int): Int? {
        var r = 0
        var g = 0
        var b = 0
        var found = 0
        var x = start
        while (found < 2 && x in 0 until width && !mask[row + x]) {
            val c = pixels[row + x]
            r += red(c)
            g += green(c)
            b += blue(c)
            found++
            x += step
        }
        return if (found == 0) null else rgb(r / found, g / found, b / found)
    }

    private fun sampleColumn(pixels: IntArray, mask: BooleanArray, column: Int, start: Int, step: Int, width: Int, height: Int): Int? {
        var r = 0
        var g = 0
        var b = 0
        var found = 0
        var y = start
        while (found < 2 && y in 0 until height && !mask[y * width + column]) {
            val c = pixels[y * width + column]
            r += red(c)
            g += green(c)
            b += blue(c)
            found++
            y += step
        }
        return if (found == 0) null else rgb(r / found, g / found, b / found)
    }

    private fun mix(a: Int?, b: Int?, t: Float): Int? {
        if (a == null) return b
        if (b == null) return a
        val u = 1f - t
        return rgb(
            (red(a) * u + red(b) * t + 0.5f).toInt(),
            (green(a) * u + green(b) * t + 0.5f).toInt(),
            (blue(a) * u + blue(b) * t + 0.5f).toInt()
        )
    }

    private fun median(histogram: IntArray, total: Int): Int {
        if (total <= 0) return 255
        val half = total / 2
        var seen = 0
        for (value in 0 until 256) {
            seen += histogram[value]
            if (seen > half) return value
        }
        return 255
    }
}
