package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Guías para alinear al mover algo en la hoja (como en PowerPoint o Canva) y
 * márgenes reales de la hoja. Sin Android: se prueba en la computadora.
 *
 * Todo va en píxeles de la foto.
 */
object ScanGuides {

    /** Caja simple. */
    class Box(val left: Float, val top: Float, val right: Float, val bottom: Float) {
        val centerX: Float get() = (left + right) / 2f
        val centerY: Float get() = (top + bottom) / 2f
        fun moved(dx: Float, dy: Float) = Box(left + dx, top + dy, right + dx, bottom + dy)
    }

    /**
     * Línea guía para dibujar. [vertical] = línea de arriba a abajo en x = [position];
     * si no, de izquierda a derecha en y = [position]. Va de [start] a [end].
     */
    class Guide(val vertical: Boolean, val position: Float, val start: Float, val end: Float)

    /** Resultado del imán: cuánto mover de verdad y qué guías mostrar. */
    class Snap(val dx: Float, val dy: Float, val guides: List<Guide>)

    /** Margen izquierdo y derecho del texto de la hoja. */
    class Margins(val left: Float, val right: Float) {
        val center: Float get() = (left + right) / 2f
    }

    /**
     * Márgenes de la hoja según dónde empiezan los renglones.
     * Izquierda: el borde más a la izquierda donde empiezan al menos dos renglones
     * (un número de página suelto no cuenta). Derecha: igual que la izquierda
     * (las hojas suelen tener márgenes parejos), salvo que el texto llegue más allá.
     */
    fun margins(lefts: List<Float>, rights: List<Float>, pageWidth: Float): Margins {
        if (pageWidth <= 0f) return Margins(0f, 0f)
        val fallbackLeft = pageWidth * 0.1f
        if (lefts.isEmpty()) return Margins(fallbackLeft, pageWidth - fallbackLeft)
        val sorted = lefts.sorted()
        val tolerance = pageWidth * 0.012f
        var left = sorted.first()
        for (index in sorted.indices) {
            val value = sorted[index]
            val near = sorted.count { abs(it - value) <= tolerance }
            if (near >= 2 || sorted.size < 3) {
                left = value
                break
            }
        }
        left = left.coerceIn(pageWidth * 0.01f, pageWidth * 0.45f)
        var right = pageWidth - left
        if (rights.isNotEmpty()) {
            val sortedRights = rights.sorted()
            val far = sortedRights[((sortedRights.size - 1) * 0.9f).toInt()]
            if (far > right) right = far
        }
        right = right.coerceIn(left + pageWidth * 0.1f, pageWidth * 0.99f)
        return Margins(left, right)
    }

    /**
     * Imán al mover [moving] en ([dx], [dy]). Se pega (si está a menos de
     * [threshold]) a los bordes y centros de [others], al centro de la hoja y a
     * los márgenes. Devuelve el movimiento corregido y las guías que se ven.
     */
    fun snap(
        moving: Box,
        dx: Float,
        dy: Float,
        others: List<Box>,
        pageWidth: Float,
        pageHeight: Float,
        margins: Margins,
        threshold: Float
    ): Snap {
        val moved = moving.moved(dx, dy)

        // ---- Horizontal: bordes izquierdo, centro y derecho ----
        val xAnchors = floatArrayOf(moved.left, moved.centerX, moved.right)
        var bestX = Float.NaN
        var bestXShift = 0f
        var bestXDistance = threshold
        // Los márgenes y el centro de la hoja van primero: ganan si empatan.
        val pageXs = floatArrayOf(margins.left, margins.center, margins.right, pageWidth / 2f)
        val pageXAnchor = intArrayOf(0, 1, 2, 1)
        for (index in pageXs.indices) {
            val distance = abs(xAnchors[pageXAnchor[index]] - pageXs[index])
            if (distance < bestXDistance) {
                bestXDistance = distance
                bestX = pageXs[index]
                bestXShift = pageXs[index] - xAnchors[pageXAnchor[index]]
            }
        }
        for (other in others) {
            val targets = floatArrayOf(other.left, other.centerX, other.right)
            // Izquierda con izquierda, centro con centro, derecha con derecha.
            for (anchor in 0..2) {
                val distance = abs(xAnchors[anchor] - targets[anchor])
                if (distance < bestXDistance - 0.01f) {
                    bestXDistance = distance
                    bestX = targets[anchor]
                    bestXShift = targets[anchor] - xAnchors[anchor]
                }
            }
        }

        // ---- Vertical: arriba, centro y abajo ----
        val yAnchors = floatArrayOf(moved.top, moved.centerY, moved.bottom)
        var bestY = Float.NaN
        var bestYShift = 0f
        var bestYDistance = threshold
        run {
            val distance = abs(moved.centerY - pageHeight / 2f)
            if (distance < bestYDistance) {
                bestYDistance = distance
                bestY = pageHeight / 2f
                bestYShift = pageHeight / 2f - moved.centerY
            }
        }
        for (other in others) {
            val targets = floatArrayOf(other.top, other.centerY, other.bottom)
            for (anchor in 0..2) {
                val distance = abs(yAnchors[anchor] - targets[anchor])
                if (distance < bestYDistance - 0.01f) {
                    bestYDistance = distance
                    bestY = targets[anchor]
                    bestYShift = targets[anchor] - yAnchors[anchor]
                }
            }
        }

        val finalDx = dx + (if (bestX.isNaN()) 0f else bestXShift)
        val finalDy = dy + (if (bestY.isNaN()) 0f else bestYShift)
        val placed = moving.moved(finalDx, finalDy)
        val guides = ArrayList<Guide>(2)
        val near = threshold * 0.05f + 0.5f
        if (!bestX.isNaN()) {
            // La guía cruza todo lo que quedó alineado en esa línea.
            var top = placed.top
            var bottom = placed.bottom
            val pageLine = pageXs.any { abs(it - bestX) <= near }
            for (other in others) {
                if (abs(other.left - bestX) <= near || abs(other.centerX - bestX) <= near || abs(other.right - bestX) <= near) {
                    top = min(top, other.top)
                    bottom = max(bottom, other.bottom)
                }
            }
            if (pageLine) {
                top = 0f
                bottom = pageHeight
            }
            guides += Guide(vertical = true, position = bestX, start = top, end = bottom)
        }
        if (!bestY.isNaN()) {
            var left = placed.left
            var right = placed.right
            val pageLine = abs(bestY - pageHeight / 2f) <= near
            for (other in others) {
                if (abs(other.top - bestY) <= near || abs(other.centerY - bestY) <= near || abs(other.bottom - bestY) <= near) {
                    left = min(left, other.left)
                    right = max(right, other.right)
                }
            }
            if (pageLine) {
                left = 0f
                right = pageWidth
            }
            guides += Guide(vertical = false, position = bestY, start = left, end = right)
        }
        return Snap(finalDx, finalDy, guides)
    }
}
