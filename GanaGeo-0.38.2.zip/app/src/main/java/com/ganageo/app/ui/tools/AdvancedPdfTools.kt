package com.ganageo.app.ui.tools

import android.net.Uri
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyListItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Redo
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.AdvancedFileUtils
import com.ganageo.app.tools.PageSelectionParser
import com.ganageo.app.tools.PdfMargin
import com.ganageo.app.tools.PdfOrientation
import com.ganageo.app.tools.PdfPaperSize
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import java.io.File
import java.util.UUID
import org.json.JSONObject

private const val TEXT_PDF_DRAFT_LIMIT = 15
private const val TEXT_PDF_MAX_CHARS = 300_000
private const val EDITOR_HISTORY_LIMIT = 24

private enum class EditorDocumentFormat(
    val label: String,
    val shortLabel: String,
    val extension: String,
    val mimeType: String
) {
    PDF("PDF", "PDF", "pdf", "application/pdf"),
    WORD("Word", "DOCX", "docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    EXCEL("Excel", "XLSX", "xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    POWERPOINT("PowerPoint", "PPTX", "pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    TEXT("Texto", "TXT", "txt", "text/plain")
}

private enum class EditorTextAlignment { LEFT, CENTER, RIGHT }

private data class EditorTextStyleSpan(
    val start: Int,
    val end: Int,
    val scale: Float = 1f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val strike: Boolean = false,
    /** ARGB del color de letra. 0 = hereda el color del documento. */
    val color: Int = 0,
    /** ARGB del resaltado. 0 = sin resaltar. */
    val highlight: Int = 0
)

private data class TextPdfDraft(
    val id: String,
    val name: String,
    val body: String,
    val formatName: String = EditorDocumentFormat.WORD.name,
    val fontSize: Float = 14f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val styleSpans: List<EditorTextStyleSpan> = emptyList(),
    val alignmentIndex: Int = EditorTextAlignment.LEFT.ordinal,
    val paperIndex: Int = PdfPaperSize.A4.ordinal,
    val orientationIndex: Int = PdfOrientation.PORTRAIT.ordinal,
    val marginIndex: Int = PdfMargin.NORMAL.ordinal,
    val pageNumbers: Boolean = true,
    val columns: Int = 1,
    /** Interlineado como multiplicador: 1.0 sencillo, 1.5, 2.0 doble. */
    val lineSpacing: Float = 1.32f,
    /** ARGB del color de página. 0 = blanco. */
    val pageColorArgb: Int = 0,
    val pageBorder: Boolean = false,
    val watermark: String = "",
    val header: String = "",
    val footer: String = "",
    val sourceUriText: String = "",
    val modifiedAt: Long = System.currentTimeMillis()
) {
    val format: EditorDocumentFormat
        get() = runCatching { EditorDocumentFormat.valueOf(formatName) }.getOrDefault(EditorDocumentFormat.WORD)
}

private data class EditorExpandedTextStyles(
    val scales: FloatArray,
    val bold: BooleanArray,
    val italic: BooleanArray,
    val underline: BooleanArray,
    val strike: BooleanArray,
    val color: IntArray,
    val highlight: IntArray
) {
    companion object {
        fun empty(size: Int) = EditorExpandedTextStyles(
            FloatArray(size) { 1f },
            BooleanArray(size),
            BooleanArray(size),
            BooleanArray(size),
            BooleanArray(size),
            IntArray(size),
            IntArray(size)
        )
    }
}

private data class EditorSelectionFormatState(
    val hasSelection: Boolean = false,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val strike: Boolean = false
)

private data class EditorHistoryState(
    val body: String,
    val styleSpans: List<EditorTextStyleSpan>
)

private fun editorExpandTextStyles(
    textLength: Int,
    spans: List<EditorTextStyleSpan>
): EditorExpandedTextStyles {
    val styles = EditorExpandedTextStyles.empty(textLength)
    spans.forEach { span ->
        val from = span.start.coerceIn(0, textLength)
        val to = span.end.coerceIn(from, textLength)
        for (index in from until to) {
            styles.scales[index] = span.scale.coerceIn(0.65f, 2.2f)
            styles.bold[index] = span.bold
            styles.italic[index] = span.italic
            styles.underline[index] = span.underline
            styles.strike[index] = span.strike
            styles.color[index] = span.color
            styles.highlight[index] = span.highlight
        }
    }
    return styles
}

private fun editorCompressTextStyles(styles: EditorExpandedTextStyles): List<EditorTextStyleSpan> {
    val size = styles.scales.size
    if (size == 0) return emptyList()
    val result = mutableListOf<EditorTextStyleSpan>()
    var start = 0
    fun sameStyle(a: Int, b: Int): Boolean =
        kotlin.math.abs(styles.scales[a] - styles.scales[b]) < 0.005f &&
            styles.bold[a] == styles.bold[b] &&
            styles.italic[a] == styles.italic[b] &&
            styles.underline[a] == styles.underline[b] &&
            styles.strike[a] == styles.strike[b] &&
            styles.color[a] == styles.color[b] &&
            styles.highlight[a] == styles.highlight[b]
    fun append(end: Int) {
        if (end <= start) return
        val scale = styles.scales[start]
        val bold = styles.bold[start]
        val italic = styles.italic[start]
        val underline = styles.underline[start]
        val strike = styles.strike[start]
        val color = styles.color[start]
        val highlight = styles.highlight[start]
        val plain = kotlin.math.abs(scale - 1f) <= 0.005f && !bold && !italic && !underline &&
            !strike && color == 0 && highlight == 0
        if (!plain) {
            result += EditorTextStyleSpan(start, end, scale, bold, italic, underline, strike, color, highlight)
        }
    }
    for (index in 1 until size) {
        if (!sameStyle(start, index)) {
            append(index)
            start = index
        }
    }
    append(size)
    return result
}

private fun editorRemapTextStyleSpans(
    oldText: String,
    newText: String,
    spans: List<EditorTextStyleSpan>
): List<EditorTextStyleSpan> {
    if (newText.isEmpty() || spans.isEmpty()) return emptyList()
    val oldStyles = editorExpandTextStyles(oldText.length, spans)
    var prefix = 0
    while (prefix < oldText.length && prefix < newText.length && oldText[prefix] == newText[prefix]) prefix++
    var suffix = 0
    while (
        suffix < oldText.length - prefix &&
        suffix < newText.length - prefix &&
        oldText[oldText.length - 1 - suffix] == newText[newText.length - 1 - suffix]
    ) suffix++

    val next = EditorExpandedTextStyles.empty(newText.length)
    fun copyStyle(oldIndex: Int, newIndex: Int) {
        if (oldIndex !in oldStyles.scales.indices || newIndex !in next.scales.indices) return
        next.scales[newIndex] = oldStyles.scales[oldIndex]
        next.bold[newIndex] = oldStyles.bold[oldIndex]
        next.italic[newIndex] = oldStyles.italic[oldIndex]
        next.underline[newIndex] = oldStyles.underline[oldIndex]
        next.strike[newIndex] = oldStyles.strike[oldIndex]
        next.color[newIndex] = oldStyles.color[oldIndex]
        next.highlight[newIndex] = oldStyles.highlight[oldIndex]
    }
    for (index in 0 until prefix.coerceAtMost(newText.length)) copyStyle(index, index)
    for (offset in 0 until suffix) {
        copyStyle(oldText.length - suffix + offset, newText.length - suffix + offset)
    }

    val insertedStart = prefix
    val insertedEnd = newText.length - suffix
    if (insertedEnd > insertedStart) {
        val inheritOldIndex = when {
            prefix > 0 -> prefix - 1
            prefix < oldText.length -> prefix
            else -> -1
        }
        if (inheritOldIndex >= 0) {
            for (index in insertedStart until insertedEnd) copyStyle(inheritOldIndex, index)
        }
    }
    return editorCompressTextStyles(next)
}

private fun editorAdjustSelectionStyle(
    textLength: Int,
    spans: List<EditorTextStyleSpan>,
    selection: TextRange,
    scaleDelta: Float = 0f,
    toggleBold: Boolean = false,
    toggleItalic: Boolean = false,
    toggleUnderline: Boolean = false,
    toggleStrike: Boolean = false,
    /** -1 = no tocar, 0 = quitar el color, otro = ARGB a aplicar. */
    setColor: Int = -1,
    setHighlight: Int = -1,
    clearFormat: Boolean = false
): List<EditorTextStyleSpan> {
    val from = minOf(selection.start, selection.end).coerceIn(0, textLength)
    val to = maxOf(selection.start, selection.end).coerceIn(from, textLength)
    if (to <= from) return spans
    val styles = editorExpandTextStyles(textLength, spans)
    if (clearFormat) {
        for (index in from until to) {
            styles.scales[index] = 1f
            styles.bold[index] = false
            styles.italic[index] = false
            styles.underline[index] = false
            styles.strike[index] = false
            styles.color[index] = 0
            styles.highlight[index] = 0
        }
        return editorCompressTextStyles(styles)
    }
    // Se activa el estilo salvo que TODA la selección ya lo tenga: así el mismo
    // botón pone y quita, igual que en Word.
    val makeBold = if (toggleBold) !(from until to).all { styles.bold[it] } else false
    val makeItalic = if (toggleItalic) !(from until to).all { styles.italic[it] } else false
    val makeUnderline = if (toggleUnderline) !(from until to).all { styles.underline[it] } else false
    val makeStrike = if (toggleStrike) !(from until to).all { styles.strike[it] } else false
    for (index in from until to) {
        if (kotlin.math.abs(scaleDelta) > 0.0001f) {
            styles.scales[index] = (styles.scales[index] + scaleDelta).coerceIn(0.65f, 2.2f)
        }
        if (toggleBold) styles.bold[index] = makeBold
        if (toggleItalic) styles.italic[index] = makeItalic
        if (toggleUnderline) styles.underline[index] = makeUnderline
        if (toggleStrike) styles.strike[index] = makeStrike
        if (setColor >= 0) styles.color[index] = setColor
        if (setHighlight >= 0) styles.highlight[index] = setHighlight
    }
    return editorCompressTextStyles(styles)
}

/**
 * Cambia mayúsculas y minúsculas del tramo seleccionado (o de todo el texto si
 * no hay selección). El largo del texto no varía, así que los estilos siguen
 * cuadrando sin remapear nada.
 */
private fun editorChangeCase(text: String, selection: TextRange, mode: Int): String {
    if (text.isEmpty()) return text
    val from = minOf(selection.start, selection.end).coerceIn(0, text.length)
    val to = maxOf(selection.start, selection.end).coerceIn(from, text.length)
    val start = if (to > from) from else 0
    val end = if (to > from) to else text.length
    val target = text.substring(start, end)
    val locale = java.util.Locale("es")
    val changed = when (mode) {
        0 -> target.uppercase(locale)
        1 -> target.lowercase(locale)
        2 -> target.lowercase(locale).split(" ").joinToString(" ") { word ->
            if (word.isBlank()) word else word.replaceFirstChar { it.titlecase(locale) }
        }
        else -> buildString {
            target.forEach { char ->
                append(if (char.isUpperCase()) char.lowercaseChar() else char.uppercaseChar())
            }
        }
    }
    return text.substring(0, start) + changed + text.substring(end)
}

private fun editorSelectionFormatState(
    textLength: Int,
    spans: List<EditorTextStyleSpan>,
    selection: TextRange
): EditorSelectionFormatState {
    val from = minOf(selection.start, selection.end).coerceIn(0, textLength)
    val to = maxOf(selection.start, selection.end).coerceIn(from, textLength)
    if (to <= from) return EditorSelectionFormatState()
    val styles = editorExpandTextStyles(textLength, spans)
    return EditorSelectionFormatState(
        hasSelection = true,
        bold = (from until to).all { styles.bold[it] },
        italic = (from until to).all { styles.italic[it] },
        underline = (from until to).all { styles.underline[it] },
        strike = (from until to).all { styles.strike[it] }
    )
}

private fun editorTextStyleTransformation(
    spans: List<EditorTextStyleSpan>,
    baseFontSize: androidx.compose.ui.unit.TextUnit
): VisualTransformation = VisualTransformation { source ->
    val builder = AnnotatedString.Builder(source)
    spans.forEach { span ->
        val from = span.start.coerceIn(0, source.length)
        val to = span.end.coerceIn(from, source.length)
        if (to > from) {
            val decoration = when {
                span.underline && span.strike ->
                    TextDecoration.combine(listOf(TextDecoration.Underline, TextDecoration.LineThrough))
                span.underline -> TextDecoration.Underline
                span.strike -> TextDecoration.LineThrough
                else -> null
            }
            builder.addStyle(
                SpanStyle(
                    fontSize = (baseFontSize.value * span.scale.coerceIn(0.65f, 2.2f)).sp,
                    fontWeight = if (span.bold) FontWeight.Bold else null,
                    fontStyle = if (span.italic) androidx.compose.ui.text.font.FontStyle.Italic else null,
                    textDecoration = decoration,
                    color = if (span.color != 0) Color(span.color) else Color.Unspecified,
                    background = if (span.highlight != 0) Color(span.highlight) else Color.Unspecified
                ),
                from,
                to
            )
        }
    }
    TransformedText(builder.toAnnotatedString(), OffsetMapping.Identity)
}

private fun textPdfDraftDirectory(context: android.content.Context): File =
    File(context.filesDir, "text_pdf_drafts").apply { mkdirs() }

private fun textPdfDraftFile(context: android.content.Context, id: String): File =
    File(textPdfDraftDirectory(context), "${id.replace(Regex("[^A-Za-z0-9_-]"), "_")}.json")

private fun saveTextPdfDraft(context: android.content.Context, draft: TextPdfDraft) {
    val normalized = draft.copy(
        name = draft.name.trim().ifBlank { "Documento sin título" }.take(80),
        body = draft.body.take(TEXT_PDF_MAX_CHARS),
        formatName = draft.format.name,
        fontSize = draft.fontSize.coerceIn(8f, 32f),
        styleSpans = draft.styleSpans.mapNotNull { span ->
            val from = span.start.coerceIn(0, draft.body.length)
            val to = span.end.coerceIn(from, draft.body.length)
            if (to <= from) null else span.copy(
                start = from,
                end = to,
                scale = span.scale.coerceIn(0.65f, 2.2f)
            )
        },
        alignmentIndex = draft.alignmentIndex.coerceIn(0, EditorTextAlignment.entries.lastIndex),
        paperIndex = draft.paperIndex.coerceIn(0, PdfPaperSize.entries.lastIndex),
        orientationIndex = draft.orientationIndex.coerceIn(0, PdfOrientation.entries.lastIndex),
        marginIndex = draft.marginIndex.coerceIn(0, PdfMargin.entries.lastIndex),
        columns = draft.columns.coerceIn(1, 2),
        lineSpacing = draft.lineSpacing.coerceIn(1f, 2.5f),
        watermark = draft.watermark.take(40),
        header = draft.header.take(120),
        footer = draft.footer.take(120),
        sourceUriText = draft.sourceUriText.take(2048),
        modifiedAt = draft.modifiedAt.coerceAtLeast(1L)
    )
    val json = JSONObject().apply {
        put("version", 6)
        put("id", normalized.id)
        put("name", normalized.name)
        put("body", normalized.body)
        put("formatName", normalized.formatName)
        put("fontSize", normalized.fontSize.toDouble())
        put("bold", normalized.bold)
        put("italic", normalized.italic)
        put("underline", normalized.underline)
        put("styleSpans", org.json.JSONArray().apply {
            normalized.styleSpans.forEach { span ->
                put(JSONObject().apply {
                    put("start", span.start)
                    put("end", span.end)
                    put("scale", span.scale.toDouble())
                    put("bold", span.bold)
                    put("italic", span.italic)
                    put("underline", span.underline)
                    put("strike", span.strike)
                    put("color", span.color)
                    put("highlight", span.highlight)
                })
            }
        })
        put("alignmentIndex", normalized.alignmentIndex)
        put("paperIndex", normalized.paperIndex)
        put("orientationIndex", normalized.orientationIndex)
        put("marginIndex", normalized.marginIndex)
        put("pageNumbers", normalized.pageNumbers)
        put("columns", normalized.columns)
        put("lineSpacing", normalized.lineSpacing.toDouble())
        put("pageColorArgb", normalized.pageColorArgb)
        put("pageBorder", normalized.pageBorder)
        put("watermark", normalized.watermark)
        put("header", normalized.header)
        put("footer", normalized.footer)
        put("sourceUriText", normalized.sourceUriText)
        put("modifiedAt", normalized.modifiedAt)
    }
    val target = textPdfDraftFile(context, normalized.id)
    val temp = File(target.parentFile, "${target.name}.tmp")
    temp.writeText(json.toString())
    if (!temp.renameTo(target)) {
        target.writeText(json.toString())
        temp.delete()
    }
    textPdfDraftDirectory(context).listFiles()
        .orEmpty()
        .filter { it.isFile && it.extension.equals("json", true) }
        .sortedByDescending { file -> readTextPdfDraft(file)?.modifiedAt ?: file.lastModified() }
        .drop(TEXT_PDF_DRAFT_LIMIT)
        .forEach { it.delete() }
}

private fun readTextPdfDraft(file: File): TextPdfDraft? = runCatching {
    val json = JSONObject(file.readText())
    val version = json.optInt("version", 1)
    if (version !in 1..6) return@runCatching null
    val storedFormat = if (version >= 2) json.optString("formatName", EditorDocumentFormat.WORD.name)
        else EditorDocumentFormat.WORD.name
    TextPdfDraft(
        id = json.optString("id").ifBlank { file.nameWithoutExtension },
        name = json.optString("name", "Documento sin título"),
        body = json.optString("body", "").take(TEXT_PDF_MAX_CHARS),
        formatName = runCatching { EditorDocumentFormat.valueOf(storedFormat).name }
            .getOrDefault(EditorDocumentFormat.WORD.name),
        fontSize = json.optDouble("fontSize", 14.0).toFloat().coerceIn(8f, 32f),
        bold = json.optBoolean("bold", false),
        italic = json.optBoolean("italic", false),
        underline = json.optBoolean("underline", false),
        styleSpans = if (version >= 5) {
            val array = json.optJSONArray("styleSpans")
            buildList {
                if (array != null) {
                    for (index in 0 until array.length()) {
                        val item = array.optJSONObject(index) ?: continue
                        val from = item.optInt("start", 0).coerceAtLeast(0)
                        val to = item.optInt("end", from).coerceAtLeast(from)
                        if (to > from) {
                            add(
                                EditorTextStyleSpan(
                                    start = from,
                                    end = to,
                                    scale = item.optDouble("scale", 1.0).toFloat().coerceIn(0.65f, 2.2f),
                                    bold = item.optBoolean("bold", false),
                                    italic = item.optBoolean("italic", false),
                                    underline = item.optBoolean("underline", false),
                                    strike = item.optBoolean("strike", false),
                                    color = item.optInt("color", 0),
                                    highlight = item.optInt("highlight", 0)
                                )
                            )
                        }
                    }
                }
            }
        } else emptyList(),
        alignmentIndex = json.optInt("alignmentIndex", 0).coerceIn(0, EditorTextAlignment.entries.lastIndex),
        paperIndex = json.optInt("paperIndex", PdfPaperSize.A4.ordinal).coerceIn(0, PdfPaperSize.entries.lastIndex),
        orientationIndex = json.optInt("orientationIndex", PdfOrientation.PORTRAIT.ordinal).coerceIn(0, PdfOrientation.entries.lastIndex),
        marginIndex = json.optInt("marginIndex", PdfMargin.NORMAL.ordinal).coerceIn(0, PdfMargin.entries.lastIndex),
        pageNumbers = json.optBoolean("pageNumbers", true),
        columns = if (version >= 4) json.optInt("columns", 1).coerceIn(1, 2) else 1,
        lineSpacing = json.optDouble("lineSpacing", 1.32).toFloat().coerceIn(1f, 2.5f),
        pageColorArgb = json.optInt("pageColorArgb", 0),
        pageBorder = json.optBoolean("pageBorder", false),
        watermark = json.optString("watermark", "").take(40),
        header = json.optString("header", "").take(120),
        footer = json.optString("footer", "").take(120),
        sourceUriText = if (version >= 3) json.optString("sourceUriText", "").take(2048) else "",
        modifiedAt = json.optLong("modifiedAt", file.lastModified().coerceAtLeast(1L))
    )
}.getOrNull()

private suspend fun loadTextPdfDrafts(context: android.content.Context): List<TextPdfDraft> = withContext(Dispatchers.IO) {
    textPdfDraftDirectory(context).listFiles()
        .orEmpty()
        .asSequence()
        .filter { it.isFile && it.extension.equals("json", true) }
        .mapNotNull(::readTextPdfDraft)
        .sortedByDescending { it.modifiedAt }
        .take(TEXT_PDF_DRAFT_LIMIT)
        .toList()
}

private fun newTextPdfDraft(
    body: String = "",
    name: String = "",
    format: EditorDocumentFormat = EditorDocumentFormat.WORD,
    sourceUriText: String = ""
): TextPdfDraft = TextPdfDraft(
    id = UUID.randomUUID().toString(),
    name = name.trim().ifBlank {
        "Documento " + android.text.format.DateFormat.format("dd-MM HH-mm", System.currentTimeMillis()).toString()
    }.take(80),
    body = body.take(TEXT_PDF_MAX_CHARS),
    formatName = format.name,
    sourceUriText = sourceUriText.take(2048),
    modifiedAt = System.currentTimeMillis()
)

private fun textPdfOutputName(name: String): String {
    val safe = name.trim()
        .ifBlank { "documento" }
        .replace(Regex("[\\/:*?\"<>|]"), "_")
        .substringBeforeLast('.')
        .take(72)
    return "$safe.pdf"
}

private fun editorFormatFromName(name: String): EditorDocumentFormat = when (name.substringAfterLast('.', "").lowercase()) {
    "pdf" -> EditorDocumentFormat.PDF
    "docx" -> EditorDocumentFormat.WORD
    "xlsx" -> EditorDocumentFormat.EXCEL
    "pptx" -> EditorDocumentFormat.POWERPOINT
    else -> EditorDocumentFormat.TEXT
}

private suspend fun importEditorDocument(context: android.content.Context, uri: Uri): TextPdfDraft = withContext(Dispatchers.IO) {
    val displayName = runCatching { ToolFileUtils.displayName(context, uri) }.getOrDefault("Documento")
    val format = editorFormatFromName(displayName)
    val temp = File.createTempFile("editor_import_", ".${format.extension}", context.cacheDir)
    try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            temp.outputStream().use { output -> input.copyTo(output) }
        } ?: error("No se pudo abrir el archivo")
        val text = when (format) {
            EditorDocumentFormat.PDF -> editorExtractPdfText(context, temp)
            EditorDocumentFormat.WORD -> editorExtractDocxText(temp)
            EditorDocumentFormat.EXCEL -> editorExtractXlsxText(temp)
            EditorDocumentFormat.POWERPOINT -> editorExtractPptxText(temp)
            EditorDocumentFormat.TEXT -> temp.readText()
        }.trim().take(TEXT_PDF_MAX_CHARS)
        newTextPdfDraft(
            body = text,
            name = displayName.substringBeforeLast('.').ifBlank { format.label },
            format = format,
            sourceUriText = uri.toString()
        )
    } finally {
        temp.delete()
    }
}

private fun editorExtractPdfText(context: android.content.Context, file: File): String {
    com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(context.applicationContext)
    return com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { document ->
        require(document.numberOfPages <= 250) { "El PDF es demasiado grande para editarlo como texto." }
        com.tom_roush.pdfbox.text.PDFTextStripper().getText(document)
    }
}

private fun editorExtractDocxText(file: File): String = java.util.zip.ZipFile(file).use { zip ->
    val entry = zip.getEntry("word/document.xml") ?: error("DOCX no válido")
    zip.getInputStream(entry).use { stream ->
        val parser = android.util.Xml.newPullParser().apply { setInput(stream, "UTF-8") }
        val out = StringBuilder()
        while (parser.eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && out.length < TEXT_PDF_MAX_CHARS) {
            when (parser.eventType) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name.substringAfter(':')) {
                    "t" -> out.append(parser.nextText())
                    "tab" -> out.append('\t')
                    "br" -> out.append('\n')
                }
                org.xmlpull.v1.XmlPullParser.END_TAG -> if (parser.name.substringAfter(':') == "p") out.append('\n')
            }
            parser.next()
        }
        out.toString()
    }
}

private fun editorExtractPptxText(file: File): String = java.util.zip.ZipFile(file).use { zip ->
    val slideEntries = zip.entries().asSequence().toList()
        .filter { it.name.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
        .sortedBy { it.name.removePrefix("ppt/slides/slide").removeSuffix(".xml").toIntOrNull() ?: Int.MAX_VALUE }
    require(slideEntries.isNotEmpty()) { "PPTX no válido" }
    val slides = mutableListOf<String>()
    slideEntries.forEach { entry ->
        if (slides.sumOf { it.length } >= TEXT_PDF_MAX_CHARS) return@forEach
        val parts = mutableListOf<String>()
        zip.getInputStream(entry).use { stream ->
            val parser = android.util.Xml.newPullParser().apply { setInput(stream, "UTF-8") }
            while (parser.eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (parser.eventType == org.xmlpull.v1.XmlPullParser.START_TAG && parser.name.substringAfter(':') == "t") {
                    val value = parser.nextText().trim()
                    if (value.isNotBlank()) parts.add(value)
                }
                parser.next()
            }
        }
        slides.add(parts.joinToString("\n").take(TEXT_PDF_MAX_CHARS))
    }
    slides.joinToString("\u000C").take(TEXT_PDF_MAX_CHARS)
}

private fun editorExtractXlsxText(file: File): String = java.util.zip.ZipFile(file).use { zip ->
    val shared = mutableListOf<String>()
    zip.getEntry("xl/sharedStrings.xml")?.let { entry ->
        zip.getInputStream(entry).use { stream ->
            val parser = android.util.Xml.newPullParser().apply { setInput(stream, "UTF-8") }
            var insideSi = false
            var value = StringBuilder()
            while (parser.eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && shared.size < 20_000) {
                when (parser.eventType) {
                    org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name.substringAfter(':')) {
                        "si" -> { insideSi = true; value = StringBuilder() }
                        "t" -> if (insideSi) value.append(parser.nextText())
                    }
                    org.xmlpull.v1.XmlPullParser.END_TAG -> if (parser.name.substringAfter(':') == "si") {
                        shared += value.toString()
                        insideSi = false
                    }
                }
                parser.next()
            }
        }
    }

    val sheetEntry = zip.entries().asSequence().toList()
        .filter { it.name.matches(Regex("xl/worksheets/sheet\\d+\\.xml")) }
        .minByOrNull { it.name.removePrefix("xl/worksheets/sheet").removeSuffix(".xml").toIntOrNull() ?: Int.MAX_VALUE }
        ?: error("XLSX no válido")

    val rows = linkedMapOf<Int, MutableMap<Int, String>>()
    zip.getInputStream(sheetEntry).use { stream ->
        val parser = android.util.Xml.newPullParser().apply { setInput(stream, "UTF-8") }
        var rowIndex = 0
        var cellRef = ""
        var cellType = ""
        var cellValue = ""
        var inlineValue = ""
        while (parser.eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && rows.size < 800) {
            when (parser.eventType) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name.substringAfter(':')) {
                    "row" -> rowIndex = parser.getAttributeValue(null, "r")?.toIntOrNull() ?: (rowIndex + 1)
                    "c" -> {
                        cellRef = parser.getAttributeValue(null, "r").orEmpty()
                        cellType = parser.getAttributeValue(null, "t").orEmpty()
                        cellValue = ""
                        inlineValue = ""
                    }
                    "v" -> cellValue = parser.nextText()
                    "t" -> if (cellType == "inlineStr") inlineValue += parser.nextText()
                }
                org.xmlpull.v1.XmlPullParser.END_TAG -> if (parser.name.substringAfter(':') == "c") {
                    val col = editorExcelColumnIndex(cellRef)
                    if (col in 0..99 && rowIndex in 1..2000) {
                        val resolved = when (cellType) {
                            "s" -> shared.getOrNull(cellValue.toIntOrNull() ?: -1).orEmpty()
                            "inlineStr" -> inlineValue
                            "b" -> if (cellValue == "1") "VERDADERO" else "FALSO"
                            else -> cellValue
                        }
                        rows.getOrPut(rowIndex) { linkedMapOf() }[col] = resolved
                    }
                }
            }
            parser.next()
        }
    }
    if (rows.isEmpty()) {
        ""
    } else {
        val maxCol = rows.values.flatMap { it.keys }.maxOrNull()?.coerceAtMost(99) ?: 0
        rows.entries.joinToString("\n") { (_, cells) ->
            (0..maxCol).joinToString("\t") { col -> cells[col].orEmpty() }.trimEnd('\t')
        }
    }
}

private fun editorExcelColumnIndex(ref: String): Int {
    var result = 0
    var found = false
    for (ch in ref) {
        if (!ch.isLetter()) break
        found = true
        result = result * 26 + (ch.uppercaseChar() - 'A' + 1)
    }
    return if (found) result - 1 else 0
}

private fun editorToggleBullets(text: String): String {
    val lines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
    val nonBlank = lines.filter { it.isNotBlank() }
    val alreadyBulleted = nonBlank.isNotEmpty() && nonBlank.all { it.trimStart().startsWith("• ") }
    return lines.joinToString("\n") { line ->
        if (line.isBlank()) line
        else if (alreadyBulleted) line.replaceFirst(Regex("^\\s*•\\s+"), "")
        else "• ${line.trimStart()}"
    }
}

private fun editorNumberLines(text: String): String {
    val lines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
    var number = 1
    return lines.joinToString("\n") { line ->
        if (line.isBlank()) line else "${number++}. ${line.trimStart().replaceFirst(Regex("^\\d+[.)]\\s+"), "")}"
    }
}

private data class EditorSlide(val title: String, val body: String)

private fun editorParseSlides(text: String): List<EditorSlide> {
    val normalized = text.replace("\r\n", "\n").replace('\r', '\n')
    val rawSlides = when {
        normalized.contains('\u000C') -> normalized.split('\u000C')
        normalized.contains("──────── Diapositiva") -> normalized.split(Regex("\\n*──────── Diapositiva \\d+ ────────\\n*"))
        else -> listOf(normalized)
    }.filter { it.isNotBlank() }
    if (rawSlides.isEmpty()) return listOf(EditorSlide("Título", ""))
    return rawSlides.take(80).mapIndexed { index, raw ->
        val lines = raw.trim().split('\n')
        val title = lines.firstOrNull()?.trim().orEmpty().ifBlank { "Diapositiva ${index + 1}" }
        val body = lines.drop(1).joinToString("\n").trim()
        EditorSlide(title.take(180), body.take(20_000))
    }
}

private fun editorSerializeSlides(slides: List<EditorSlide>): String = slides.joinToString("\u000C") { slide ->
    buildString {
        append(slide.title.trim())
        if (slide.body.isNotBlank()) {
            append('\n')
            append(slide.body.trimEnd())
        }
    }
}.take(TEXT_PDF_MAX_CHARS)

private fun editorGridFromBody(text: String, minRows: Int = 20, minCols: Int = 8): MutableList<MutableList<String>> {
    val sourceRows = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
    val maxCols = sourceRows.maxOfOrNull { it.split('\t').size } ?: 0
    val rows = maxOf(minRows, sourceRows.size.coerceAtMost(500))
    val cols = maxOf(minCols, maxCols.coerceAtMost(50))
    return MutableList(rows) { row ->
        val source = sourceRows.getOrNull(row)?.split('\t').orEmpty()
        MutableList(cols) { col -> source.getOrNull(col).orEmpty() }
    }
}

private fun editorGridToBody(grid: List<List<String>>): String {
    val lastRow = grid.indexOfLast { row -> row.any { it.isNotBlank() } }
    if (lastRow < 0) return ""
    return grid.take(lastRow + 1).joinToString("\n") { row ->
        val lastCol = row.indexOfLast { it.isNotBlank() }
        if (lastCol < 0) "" else row.take(lastCol + 1).joinToString("\t")
    }.take(TEXT_PDF_MAX_CHARS)
}

private fun editorExcelColumnName(index: Int): String {
    var value = index + 1
    val result = StringBuilder()
    while (value > 0) {
        val rem = (value - 1) % 26
        result.append(('A'.code + rem).toChar())
        value = (value - 1) / 26
    }
    return result.reverse().toString()
}

private fun editorExcelCellCoordinates(ref: String): Pair<Int, Int>? {
    val match = Regex("^([A-Za-z]+)(\\d+)$").matchEntire(ref.trim()) ?: return null
    val colText = match.groupValues[1].uppercase()
    val row = match.groupValues[2].toIntOrNull()?.minus(1) ?: return null
    var col = 0
    for (ch in colText) col = col * 26 + (ch - 'A' + 1)
    return row to (col - 1)
}

private fun editorExcelNumber(value: String): Double? = value.trim().replace(',', '.').toDoubleOrNull()

private fun editorEvaluateExcelFormula(
    raw: String,
    grid: List<List<String>>,
    depth: Int = 0,
    visiting: MutableSet<String> = mutableSetOf()
): String {
    if (!raw.startsWith("=")) return raw
    if (depth > 12) return "#CICLO"
    val formula = raw.drop(1).trim()

    fun cellValue(ref: String): Double? {
        val key = ref.uppercase()
        if (!visiting.add(key)) return null
        val coordinates = editorExcelCellCoordinates(key) ?: return null.also { visiting.remove(key) }
        val cell = grid.getOrNull(coordinates.first)?.getOrNull(coordinates.second).orEmpty()
        val evaluated = if (cell.startsWith("=")) editorEvaluateExcelFormula(cell, grid, depth + 1, visiting) else cell
        visiting.remove(key)
        return editorExcelNumber(evaluated)
    }

    val rangeMatch = Regex("(?i)^(SUM|AVERAGE|MIN|MAX|COUNT)\\(([A-Z]+\\d+):([A-Z]+\\d+)\\)$").matchEntire(formula)
    if (rangeMatch != null) {
        val op = rangeMatch.groupValues[1].uppercase()
        val start = editorExcelCellCoordinates(rangeMatch.groupValues[2]) ?: return "#REF!"
        val end = editorExcelCellCoordinates(rangeMatch.groupValues[3]) ?: return "#REF!"
        val values = mutableListOf<Double>()
        for (r in minOf(start.first, end.first)..maxOf(start.first, end.first)) {
            for (c in minOf(start.second, end.second)..maxOf(start.second, end.second)) {
                val ref = "${editorExcelColumnName(c)}${r + 1}"
                cellValue(ref)?.let(values::add)
            }
        }
        val result = when (op) {
            "SUM" -> values.sum()
            "AVERAGE" -> if (values.isEmpty()) 0.0 else values.average()
            "MIN" -> values.minOrNull() ?: 0.0
            "MAX" -> values.maxOrNull() ?: 0.0
            "COUNT" -> values.size.toDouble()
            else -> 0.0
        }
        return if (result % 1.0 == 0.0) result.toLong().toString() else "%.4f".format(java.util.Locale.US, result).trimEnd('0').trimEnd('.')
    }

    val simple = Regex("(?i)^([A-Z]+\\d+|[-+]?\\d+(?:[.,]\\d+)?)\\s*([+\\-*/])\\s*([A-Z]+\\d+|[-+]?\\d+(?:[.,]\\d+)?)$").matchEntire(formula)
    if (simple != null) {
        fun operand(token: String): Double? = if (token.firstOrNull()?.isLetter() == true) cellValue(token) else editorExcelNumber(token)
        val a = operand(simple.groupValues[1]) ?: return "#VALOR!"
        val b = operand(simple.groupValues[3]) ?: return "#VALOR!"
        val result = when (simple.groupValues[2]) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> if (kotlin.math.abs(b) < 1e-12) return "#DIV/0!" else a / b
            else -> return "#VALOR!"
        }
        return if (result % 1.0 == 0.0) result.toLong().toString() else "%.4f".format(java.util.Locale.US, result).trimEnd('0').trimEnd('.')
    }

    val singleCell = Regex("(?i)^[A-Z]+\\d+$").matchEntire(formula)
    if (singleCell != null) return cellValue(formula)?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "#REF!"
    return raw
}

private fun editorXmlEscape(value: String): String = value
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")
    .replace("'", "&apos;")

private fun editorZipText(zip: java.util.zip.ZipOutputStream, name: String, text: String) {
    zip.putNextEntry(java.util.zip.ZipEntry(name))
    zip.write(text.toByteArray(Charsets.UTF_8))
    zip.closeEntry()
}

/** Convierte un ARGB de Android al RRGGBB en hexadecimal que usa OOXML. */
private fun editorHexColor(argb: Int): String =
    String.format(java.util.Locale.US, "%06X", argb and 0xFFFFFF)

/**
 * Resaltado de OOXML. Word solo admite una lista cerrada de nombres, así que se
 * elige el más cercano al color que puso el usuario en vez de inventar uno.
 */
private fun editorHighlightName(argb: Int): String {
    val red = (argb shr 16) and 0xFF
    val green = (argb shr 8) and 0xFF
    val blue = argb and 0xFF
    val options = listOf(
        "yellow" to Triple(255, 255, 0),
        "green" to Triple(0, 255, 0),
        "cyan" to Triple(0, 255, 255),
        "magenta" to Triple(255, 0, 255),
        "red" to Triple(255, 0, 0),
        "blue" to Triple(0, 0, 255),
        "darkYellow" to Triple(128, 128, 0),
        "lightGray" to Triple(192, 192, 192)
    )
    return options.minByOrNull { (_, rgb) ->
        val (r, g, b) = rgb
        (r - red) * (r - red) + (g - green) * (g - green) + (b - blue) * (b - blue)
    }?.first ?: "yellow"
}

private suspend fun editorCreateDocx(context: android.content.Context, output: Uri, draft: TextPdfDraft) = withContext(Dispatchers.IO) {
    val body = draft.body.replace("\r\n", "\n").replace('\r', '\n')
    val styles = editorExpandTextStyles(body.length, draft.styleSpans)
    val baseHalfPoints = (draft.fontSize * 2).roundToInt().coerceIn(16, 64)
    val alignment = when (draft.alignmentIndex.coerceIn(0, 2)) {
        1 -> "center"
        2 -> "right"
        else -> "left"
    }
    // OOXML mide el interlineado en veinteavos de punto sobre 240 = línea sencilla.
    val lineTwips = (draft.lineSpacing.coerceIn(1f, 2.5f) * 240f).roundToInt()

    /** Un run por cada tramo con el mismo formato: así el DOCX se ve como el editor. */
    fun runsFor(paragraph: String, offset: Int): String {
        if (paragraph.isEmpty()) return ""
        val pieces = StringBuilder()
        var index = 0
        while (index < paragraph.length) {
            val absolute = offset + index
            val hasStyle = absolute in styles.scales.indices
            val scale = if (hasStyle) styles.scales[absolute] else 1f
            val bold = if (hasStyle) styles.bold[absolute] else false
            val italic = if (hasStyle) styles.italic[absolute] else false
            val underline = if (hasStyle) styles.underline[absolute] else false
            val strike = if (hasStyle) styles.strike[absolute] else false
            val color = if (hasStyle) styles.color[absolute] else 0
            val highlight = if (hasStyle) styles.highlight[absolute] else 0

            var end = index + 1
            while (end < paragraph.length) {
                val next = offset + end
                val sameStyle = next in styles.scales.indices &&
                    kotlin.math.abs(styles.scales[next] - scale) < 0.005f &&
                    styles.bold[next] == bold && styles.italic[next] == italic &&
                    styles.underline[next] == underline && styles.strike[next] == strike &&
                    styles.color[next] == color && styles.highlight[next] == highlight
                if (!sameStyle) break
                end++
            }

            val properties = buildString {
                if (bold || draft.bold) append("<w:b/>")
                if (italic || draft.italic) append("<w:i/>")
                if (underline || draft.underline) append("<w:u w:val=\"single\"/>")
                if (strike) append("<w:strike/>")
                if (color != 0) append("<w:color w:val=\"${editorHexColor(color)}\"/>")
                if (highlight != 0) append("<w:highlight w:val=\"${editorHighlightName(highlight)}\"/>")
                append("<w:sz w:val=\"${(baseHalfPoints * scale).roundToInt().coerceIn(8, 200)}\"/>")
            }
            val text = editorXmlEscape(paragraph.substring(index, end))
            pieces.append("<w:r><w:rPr>$properties</w:rPr><w:t xml:space=\"preserve\">$text</w:t></w:r>")
            index = end
        }
        return pieces.toString()
    }

    var cursor = 0
    val bodyXml = buildString {
        body.split('\n').forEach { paragraph ->
            append("<w:p><w:pPr><w:jc w:val=\"$alignment\"/>")
            append("<w:spacing w:line=\"$lineTwips\" w:lineRule=\"auto\"/>")
            if (draft.pageColorArgb != 0) {
                append("<w:shd w:val=\"clear\" w:fill=\"${editorHexColor(draft.pageColorArgb)}\"/>")
            }
            append("</w:pPr>")
            append(runsFor(paragraph, cursor))
            append("</w:p>")
            cursor += paragraph.length + 1
        }
    }

    val paper = PdfPaperSize.entries.getOrElse(draft.paperIndex) { PdfPaperSize.A4 }
    val landscape = PdfOrientation.entries.getOrElse(draft.orientationIndex) { PdfOrientation.PORTRAIT } == PdfOrientation.LANDSCAPE
    // 1 punto = 20 twips. Word trabaja en twips, no en puntos.
    val widthTwips = ((if (landscape) paper.heightPoints else paper.widthPoints).takeIf { it > 0 } ?: 595) * 20
    val heightTwips = ((if (landscape) paper.widthPoints else paper.heightPoints).takeIf { it > 0 } ?: 842) * 20
    val marginTwips = (PdfMargin.entries.getOrElse(draft.marginIndex) { PdfMargin.NORMAL }.points * 20).coerceAtLeast(400)
    val orientationAttr = if (landscape) " w:orient=\"landscape\"" else ""
    val columnsXml = if (draft.columns == 2) "<w:cols w:num=\"2\" w:space=\"425\"/>" else ""
    val pageBorders = if (draft.pageBorder) {
        "<w:pgBorders w:offsetFrom=\"page\">" +
            listOf("top", "left", "bottom", "right").joinToString("") { side ->
                "<w:$side w:val=\"single\" w:sz=\"12\" w:space=\"24\" w:color=\"595959\"/>"
            } + "</w:pgBorders>"
    } else ""
    val pageColorXml = if (draft.pageColorArgb != 0) {
        "<w:background w:color=\"${editorHexColor(draft.pageColorArgb)}\"/>"
    } else ""

    val documentXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">$pageColorXml<w:body>$bodyXml<w:sectPr><w:pgSz w:w="$widthTwips" w:h="$heightTwips"$orientationAttr/><w:pgMar w:top="$marginTwips" w:right="$marginTwips" w:bottom="$marginTwips" w:left="$marginTwips"/>$pageBorders$columnsXml</w:sectPr></w:body></w:document>"""
    val types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>"""
    val rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>"""
    context.contentResolver.openOutputStream(output, "w")?.use { raw ->
        java.util.zip.ZipOutputStream(raw).use { zip ->
            editorZipText(zip, "[Content_Types].xml", types)
            editorZipText(zip, "_rels/.rels", rels)
            editorZipText(zip, "word/document.xml", documentXml)
        }
    } ?: error("No se pudo crear el DOCX")
}

private suspend fun editorCreateXlsx(context: android.content.Context, output: Uri, draft: TextPdfDraft) = withContext(Dispatchers.IO) {
    val grid = editorGridFromBody(draft.body, 1, 1)
    val rowsXml = buildString {
        grid.forEachIndexed { r, row ->
            val last = row.indexOfLast { it.isNotBlank() }
            if (last < 0) return@forEachIndexed
            append("<row r=\"${r + 1}\">")
            row.take(last + 1).forEachIndexed { c, value ->
                if (value.isBlank()) return@forEachIndexed
                val ref = "${editorExcelColumnName(c)}${r + 1}"
                val trimmed = value.trim()
                if (trimmed.startsWith("=")) {
                    append("<c r=\"$ref\"><f>${editorXmlEscape(trimmed.drop(1))}</f></c>")
                } else {
                    val number = editorExcelNumber(trimmed)
                    if (number != null) append("<c r=\"$ref\"><v>${number}</v></c>")
                    else append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${editorXmlEscape(value)}</t></is></c>")
                }
            }
            append("</row>")
        }
    }
    val sheet = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>$rowsXml</sheetData></worksheet>"""
    val workbook = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Hoja1" sheetId="1" r:id="rId1"/></sheets></workbook>"""
    val workbookRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>"""
    val types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>"""
    val rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
    context.contentResolver.openOutputStream(output, "w")?.use { raw ->
        java.util.zip.ZipOutputStream(raw).use { zip ->
            editorZipText(zip, "[Content_Types].xml", types)
            editorZipText(zip, "_rels/.rels", rels)
            editorZipText(zip, "xl/workbook.xml", workbook)
            editorZipText(zip, "xl/_rels/workbook.xml.rels", workbookRels)
            editorZipText(zip, "xl/worksheets/sheet1.xml", sheet)
        }
    } ?: error("No se pudo crear el XLSX")
}

private fun editorPptTextBox(id: Int, name: String, text: String, x: Int, y: Int, cx: Int, cy: Int, fontSize: Int): String {
    val paragraphs = text.replace("\r\n", "\n").replace('\r', '\n').split('\n').joinToString("") { line ->
        "<a:p><a:r><a:rPr lang=\"es-PE\" sz=\"${fontSize * 100}\"/><a:t>${editorXmlEscape(line)}</a:t></a:r><a:endParaRPr lang=\"es-PE\"/></a:p>"
    }
    return """<p:sp><p:nvSpPr><p:cNvPr id="$id" name="${editorXmlEscape(name)}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="$x" y="$y"/><a:ext cx="$cx" cy="$cy"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr wrap="square"/><a:lstStyle/>$paragraphs</p:txBody></p:sp>"""
}

private suspend fun editorCreatePptx(context: android.content.Context, output: Uri, draft: TextPdfDraft) = withContext(Dispatchers.IO) {
    val slides = editorParseSlides(draft.body)
    val typesSlides = slides.indices.joinToString("") { index -> "<Override PartName=\"/ppt/slides/slide${index + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>" }
    val types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>$typesSlides</Types>"""
    val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/></Relationships>"""
    val slideIds = slides.indices.joinToString("") { index -> "<p:sldId id=\"${256 + index}\" r:id=\"rId${index + 2}\"/>" }
    val presentation = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>$slideIds</p:sldIdLst><p:sldSz cx="12192000" cy="6858000" type="screen16x9"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>"""
    val presentationRels = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
        append("<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster\" Target=\"slideMasters/slideMaster1.xml\"/>")
        slides.indices.forEach { index -> append("<Relationship Id=\"rId${index + 2}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide\" Target=\"slides/slide${index + 1}.xml\"/>") }
        append("</Relationships>")
    }
    val master = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld name="GanaGeo"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld><p:sldLayoutIdLst><p:sldLayoutId id="1" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle/><p:bodyStyle/><p:otherStyle/></p:txStyles></p:sldMaster>"""
    val masterRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/></Relationships>"""
    val layout = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="blank" preserve="1"><p:cSld name="En blanco"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld></p:sldLayout>"""
    val layoutRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>"""
    val theme = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="GanaGeo"><a:themeElements><a:clrScheme name="GanaGeo"><a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1><a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="1F1F1F"/></a:dk2><a:lt2><a:srgbClr val="F2F2F2"/></a:lt2><a:accent1><a:srgbClr val="2E8B57"/></a:accent1><a:accent2><a:srgbClr val="3976D3"/></a:accent2><a:accent3><a:srgbClr val="E36B39"/></a:accent3><a:accent4><a:srgbClr val="8E5BB7"/></a:accent4><a:accent5><a:srgbClr val="4AA3A2"/></a:accent5><a:accent6><a:srgbClr val="D4A72C"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme><a:fontScheme name="GanaGeo"><a:majorFont><a:latin typeface="Aptos Display"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Aptos"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="GanaGeo"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>"""

    context.contentResolver.openOutputStream(output, "w")?.use { raw ->
        java.util.zip.ZipOutputStream(raw).use { zip ->
            editorZipText(zip, "[Content_Types].xml", types)
            editorZipText(zip, "_rels/.rels", rootRels)
            editorZipText(zip, "ppt/presentation.xml", presentation)
            editorZipText(zip, "ppt/_rels/presentation.xml.rels", presentationRels)
            editorZipText(zip, "ppt/slideMasters/slideMaster1.xml", master)
            editorZipText(zip, "ppt/slideMasters/_rels/slideMaster1.xml.rels", masterRels)
            editorZipText(zip, "ppt/slideLayouts/slideLayout1.xml", layout)
            editorZipText(zip, "ppt/slideLayouts/_rels/slideLayout1.xml.rels", layoutRels)
            editorZipText(zip, "ppt/theme/theme1.xml", theme)
            slides.forEachIndexed { index, slide ->
                val titleBox = editorPptTextBox(2, "Título", slide.title, 762000, 457200, 10668000, 1219200, 28)
                val bodyBox = editorPptTextBox(3, "Contenido", slide.body, 914400, 1828800, 10363200, 4114800, 18)
                val slideXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>$titleBox$bodyBox</p:spTree></p:cSld></p:sld>"""
                val slideRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/></Relationships>"""
                editorZipText(zip, "ppt/slides/slide${index + 1}.xml", slideXml)
                editorZipText(zip, "ppt/slides/_rels/slide${index + 1}.xml.rels", slideRels)
            }
        }
    } ?: error("No se pudo crear el PPTX")
}

private suspend fun editorCreateSpreadsheetPdf(context: android.content.Context, output: Uri, draft: TextPdfDraft) = withContext(Dispatchers.IO) {
    val grid = editorGridFromBody(draft.body, 1, 1)
    val pdf = android.graphics.pdf.PdfDocument()
    try {
        val pageW = 842
        val pageH = 595
        val margin = 32f
        val rowH = 28f
        val colW = 100f
        val maxCols = ((pageW - margin * 2) / colW).toInt().coerceAtLeast(1)
        val maxRows = ((pageH - margin * 2 - rowH) / rowH).toInt().coerceAtLeast(1)
        val usedRows = (grid.indexOfLast { it.any(String::isNotBlank) } + 1).coerceAtLeast(1)
        val usedCols = (grid.maxOfOrNull { it.indexOfLast(String::isNotBlank) + 1 } ?: 1).coerceAtLeast(1)
        val headerPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.DKGRAY; textSize = 12f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        val textPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 11f }
        val linePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.LTGRAY; style = android.graphics.Paint.Style.STROKE; strokeWidth = 1f }
        var pageNumber = 1
        var rowStart = 0
        while (rowStart < usedRows) {
            var colStart = 0
            while (colStart < usedCols) {
                val page = pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageW, pageH, pageNumber++).create())
                val canvas = page.canvas
                canvas.drawColor(android.graphics.Color.WHITE)
                for (c in 0 until minOf(maxCols, usedCols - colStart)) {
                    val x = margin + c * colW
                    canvas.drawText(editorExcelColumnName(colStart + c), x + 6f, margin + 18f, headerPaint)
                }
                for (r in 0 until minOf(maxRows, usedRows - rowStart)) {
                    val y = margin + rowH + r * rowH
                    canvas.drawText((rowStart + r + 1).toString(), 4f, y + 18f, headerPaint)
                    for (c in 0 until minOf(maxCols, usedCols - colStart)) {
                        val x = margin + c * colW
                        canvas.drawRect(x, y, x + colW, y + rowH, linePaint)
                        val raw = grid.getOrNull(rowStart + r)?.getOrNull(colStart + c).orEmpty()
                        val display = editorEvaluateExcelFormula(raw, grid).take(18)
                        canvas.drawText(display, x + 5f, y + 18f, textPaint)
                    }
                }
                pdf.finishPage(page)
                colStart += maxCols
            }
            rowStart += maxRows
        }
        context.contentResolver.openOutputStream(output, "w")?.use(pdf::writeTo) ?: error("No se pudo crear el PDF")
    } finally { pdf.close() }
}

private suspend fun editorCreatePresentationPdf(context: android.content.Context, output: Uri, draft: TextPdfDraft) = withContext(Dispatchers.IO) {
    val slides = editorParseSlides(draft.body)
    val pdf = android.graphics.pdf.PdfDocument()
    try {
        slides.forEachIndexed { index, slide ->
            val pageW = 1280
            val pageH = 720
            val page = pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageW, pageH, index + 1).create())
            val canvas = page.canvas
            canvas.drawColor(android.graphics.Color.WHITE)
            val titlePaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(31, 31, 31); textSize = 44f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
            val bodyPaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(50, 50, 50); textSize = 28f }
            val titleLayout = android.text.StaticLayout.Builder.obtain(slide.title, 0, slide.title.length, titlePaint, 1080).setIncludePad(false).setMaxLines(2).build()
            canvas.save(); canvas.translate(100f, 72f); titleLayout.draw(canvas); canvas.restore()
            val body = slide.body.ifBlank { " " }
            val bodyLayout = android.text.StaticLayout.Builder.obtain(body, 0, body.length, bodyPaint, 1080).setIncludePad(false).setLineSpacing(4f, 1.12f).build()
            canvas.save(); canvas.translate(100f, 220f); bodyLayout.draw(canvas); canvas.restore()
            val numPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.GRAY; textSize = 18f; textAlign = android.graphics.Paint.Align.RIGHT }
            canvas.drawText("${index + 1}/${slides.size}", 1220f, 680f, numPaint)
            pdf.finishPage(page)
        }
        context.contentResolver.openOutputStream(output, "w")?.use(pdf::writeTo) ?: error("No se pudo crear el PDF")
    } finally { pdf.close() }
}

private suspend fun editorCreateStyledPdf(
    context: android.content.Context,
    output: Uri,
    draft: TextPdfDraft
) = withContext(Dispatchers.IO) {
    require(draft.body.isNotBlank()) { "El documento está vacío" }
    val paper = PdfPaperSize.entries.getOrElse(draft.paperIndex) { PdfPaperSize.A4 }
    val orientation = PdfOrientation.entries.getOrElse(draft.orientationIndex) { PdfOrientation.PORTRAIT }
    val marginSetting = PdfMargin.entries.getOrElse(draft.marginIndex) { PdfMargin.NORMAL }
    val baseWidth = paper.widthPoints.takeIf { it > 0 } ?: PdfPaperSize.A4.widthPoints
    val baseHeight = paper.heightPoints.takeIf { it > 0 } ?: PdfPaperSize.A4.heightPoints
    val width = if (orientation == PdfOrientation.LANDSCAPE) baseHeight else baseWidth
    val height = if (orientation == PdfOrientation.LANDSCAPE) baseWidth else baseHeight
    val margin = marginSetting.points.coerceAtLeast(20)
    val pageNumberReserve = if (draft.pageNumbers) 24 else 0
    val headerReserve = if (draft.header.isNotBlank()) 22 else 0
    val footerReserve = if (draft.footer.isNotBlank()) 22 else 0
    val usableHeight = (height - margin * 2 - pageNumberReserve - headerReserve - footerReserve).coerceAtLeast(120)
    val textTop = margin + headerReserve
    val columns = draft.columns.coerceIn(1, 2)
    val gutter = if (columns == 2) 24 else 0
    val usableWidth = (width - margin * 2).coerceAtLeast(120)
    val columnWidth = ((usableWidth - gutter * (columns - 1)) / columns).coerceAtLeast(80)

    val styled = android.text.SpannableString(draft.body)
    draft.styleSpans.forEach { span ->
        val from = span.start.coerceIn(0, styled.length)
        val to = span.end.coerceIn(from, styled.length)
        if (to <= from) return@forEach
        if (kotlin.math.abs(span.scale - 1f) > 0.005f) {
            styled.setSpan(
                android.text.style.RelativeSizeSpan(span.scale.coerceIn(0.65f, 2.2f)),
                from,
                to,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        val style = when {
            span.bold && span.italic -> android.graphics.Typeface.BOLD_ITALIC
            span.bold -> android.graphics.Typeface.BOLD
            span.italic -> android.graphics.Typeface.ITALIC
            else -> android.graphics.Typeface.NORMAL
        }
        if (style != android.graphics.Typeface.NORMAL) {
            styled.setSpan(
                android.text.style.StyleSpan(style),
                from,
                to,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        if (span.underline) {
            styled.setSpan(
                android.text.style.UnderlineSpan(),
                from,
                to,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        if (span.strike) {
            styled.setSpan(
                android.text.style.StrikethroughSpan(),
                from,
                to,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        if (span.color != 0) {
            styled.setSpan(
                android.text.style.ForegroundColorSpan(span.color),
                from,
                to,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        if (span.highlight != 0) {
            styled.setSpan(
                android.text.style.BackgroundColorSpan(span.highlight),
                from,
                to,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }

    val baseTypefaceStyle = when {
        draft.bold && draft.italic -> android.graphics.Typeface.BOLD_ITALIC
        draft.bold -> android.graphics.Typeface.BOLD
        draft.italic -> android.graphics.Typeface.ITALIC
        else -> android.graphics.Typeface.NORMAL
    }
    val paint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.SUBPIXEL_TEXT_FLAG).apply {
        color = android.graphics.Color.BLACK
        textSize = draft.fontSize.coerceIn(8f, 32f)
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, baseTypefaceStyle)
        isUnderlineText = draft.underline
    }
    val alignment = when (draft.alignmentIndex.coerceIn(0, 2)) {
        1 -> android.text.Layout.Alignment.ALIGN_CENTER
        2 -> android.text.Layout.Alignment.ALIGN_OPPOSITE
        else -> android.text.Layout.Alignment.ALIGN_NORMAL
    }
    val layout = android.text.StaticLayout.Builder
        .obtain(styled, 0, styled.length, paint, columnWidth)
        .setAlignment(alignment)
        .setIncludePad(false)
        .setLineSpacing(0f, draft.lineSpacing.coerceIn(1f, 2.5f))
        .build()

    val pdf = android.graphics.pdf.PdfDocument()
    try {
        var lineIndex = 0
        var pageNumber = 1
        while (lineIndex < layout.lineCount || (layout.lineCount == 0 && pageNumber == 1)) {
            val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(width, height, pageNumber).create()
            val page = pdf.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawColor(if (draft.pageColorArgb != 0) draft.pageColorArgb else android.graphics.Color.WHITE)

            // La marca de agua va debajo del texto y en diagonal, como en Word.
            if (draft.watermark.isNotBlank()) {
                val markPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.argb(46, 0, 0, 0)
                    textAlign = android.graphics.Paint.Align.CENTER
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
                    textSize = (width / draft.watermark.length.coerceAtLeast(4).toFloat() * 1.9f).coerceIn(28f, 120f)
                }
                canvas.save()
                canvas.rotate(-38f, width / 2f, height / 2f)
                canvas.drawText(draft.watermark, width / 2f, height / 2f, markPaint)
                canvas.restore()
            }

            for (column in 0 until columns) {
                if (lineIndex >= layout.lineCount) break
                val startLine = lineIndex
                val startTop = layout.getLineTop(startLine)
                var endLine = startLine
                while (endLine < layout.lineCount) {
                    val segmentHeight = layout.getLineBottom(endLine) - startTop
                    if (segmentHeight > usableHeight && endLine > startLine) break
                    endLine++
                    if (segmentHeight > usableHeight) break
                }
                if (endLine <= startLine) endLine = (startLine + 1).coerceAtMost(layout.lineCount)
                val columnLeft = margin + column * (columnWidth + gutter)
                canvas.save()
                canvas.clipRect(
                    columnLeft.toFloat(),
                    textTop.toFloat(),
                    (columnLeft + columnWidth).toFloat(),
                    (textTop + usableHeight).toFloat()
                )
                canvas.translate(columnLeft.toFloat(), (textTop - startTop).toFloat())
                layout.draw(canvas)
                canvas.restore()
                lineIndex = endLine
            }

            if (draft.pageBorder) {
                val borderPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    style = android.graphics.Paint.Style.STROKE
                    strokeWidth = 1.6f
                    color = android.graphics.Color.argb(150, 0, 0, 0)
                }
                val inset = (margin / 2f).coerceAtLeast(10f)
                canvas.drawRect(inset, inset, width - inset, height - inset, borderPaint)
            }

            val edgePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.DKGRAY
                textSize = 9.5f
            }
            if (draft.header.isNotBlank()) {
                canvas.drawText(draft.header, margin.toFloat(), (margin + 10).toFloat(), edgePaint)
            }
            if (draft.footer.isNotBlank()) {
                canvas.drawText(draft.footer, margin.toFloat(), (height - margin + 12).toFloat(), edgePaint)
            }

            if (draft.pageNumbers) {
                val numberPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.DKGRAY
                    textSize = 9f
                    textAlign = android.graphics.Paint.Align.CENTER
                }
                canvas.drawText(pageNumber.toString(), width / 2f, (height - 10).toFloat(), numberPaint)
            }
            pdf.finishPage(page)
            pageNumber++
            require(pageNumber <= 500) { "El documento supera el límite de páginas" }
            if (layout.lineCount == 0) break
        }
        context.contentResolver.openOutputStream(output, "w")?.use { stream ->
            pdf.writeTo(stream)
        } ?: error("No se pudo crear el PDF")
    } finally {
        pdf.close()
    }
}

@Composable
fun TextToPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var drafts by remember { mutableStateOf<List<TextPdfDraft>>(emptyList()) }
    var activeDraft by remember { mutableStateOf<TextPdfDraft?>(null) }
    var loadingDrafts by remember { mutableStateOf(true) }
    var importing by remember { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf<TextPdfDraft?>(null) }
    var pendingNativeExport by remember { mutableStateOf<TextPdfDraft?>(null) }

    suspend fun refreshDrafts() {
        loadingDrafts = true
        drafts = loadTextPdfDrafts(context)
        loadingDrafts = false
    }

    LaunchedEffect(Unit) { refreshDrafts() }

    val openDocument = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        importing = true
        scope.launch {
            runCatching { importEditorDocument(context, uri) }
                .onSuccess { imported ->
                    withContext(Dispatchers.IO) { saveTextPdfDraft(context, imported) }
                    activeDraft = imported
                    refreshDrafts()
                }
                .onFailure { error -> onMessage(error.message ?: "No se pudo abrir el documento") }
            importing = false
        }
    }

    val savePdf = rememberLauncherForActivityResult(TrackedCreateDocument("application/pdf")) { output ->
        val exportDraft = pendingExport
        pendingExport = null
        if (output == null || exportDraft == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                when (exportDraft.format) {
                    EditorDocumentFormat.EXCEL -> editorCreateSpreadsheetPdf(context, output, exportDraft)
                    EditorDocumentFormat.POWERPOINT -> editorCreatePresentationPdf(context, output, exportDraft)
                    else -> if (exportDraft.styleSpans.isNotEmpty()) {
                        editorCreateStyledPdf(context, output, exportDraft)
                    } else {
                        AdvancedFileUtils.createTextPdf(
                            context = context,
                            output = output,
                            text = exportDraft.body,
                            options = AdvancedFileUtils.TextPdfOptions(
                                title = "",
                                author = "",
                                fontSize = exportDraft.fontSize,
                                lineSpacing = 1.32f,
                                paperSize = PdfPaperSize.entries.getOrElse(exportDraft.paperIndex) { PdfPaperSize.A4 },
                                orientation = PdfOrientation.entries.getOrElse(exportDraft.orientationIndex) { PdfOrientation.PORTRAIT },
                                margin = PdfMargin.entries.getOrElse(exportDraft.marginIndex) { PdfMargin.NORMAL },
                                pageNumbers = exportDraft.pageNumbers,
                                header = "",
                                bold = exportDraft.bold,
                                italic = exportDraft.italic,
                                underline = exportDraft.underline,
                                alignment = exportDraft.alignmentIndex,
                                columns = exportDraft.columns
                            )
                        )
                    }
                }
            }.onSuccess { reward ->
                onMessage(successMessage("Documento PDF guardado", reward))
            }.onFailure { error ->
                onMessage(error.message ?: "No se pudo guardar el PDF")
            }
            processing = false
        }
    }

    fun nativeExportResult(output: Uri?, expected: EditorDocumentFormat) {
        val exportDraft = pendingNativeExport
        pendingNativeExport = null
        if (output == null || exportDraft == null) return
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                when (expected) {
                    EditorDocumentFormat.WORD -> editorCreateDocx(context, output, exportDraft)
                    EditorDocumentFormat.EXCEL -> editorCreateXlsx(context, output, exportDraft)
                    EditorDocumentFormat.POWERPOINT -> editorCreatePptx(context, output, exportDraft)
                    else -> error("Formato nativo no disponible")
                }
            }.onSuccess { reward ->
                onMessage(successMessage("${expected.shortLabel} guardado", reward))
            }.onFailure { error ->
                onMessage(error.message ?: "No se pudo guardar ${expected.shortLabel}")
            }
            processing = false
        }
    }

    val saveDocx = rememberLauncherForActivityResult(TrackedCreateDocument(EditorDocumentFormat.WORD.mimeType)) { output ->
        nativeExportResult(output, EditorDocumentFormat.WORD)
    }
    val saveXlsx = rememberLauncherForActivityResult(TrackedCreateDocument(EditorDocumentFormat.EXCEL.mimeType)) { output ->
        nativeExportResult(output, EditorDocumentFormat.EXCEL)
    }
    val savePptx = rememberLauncherForActivityResult(TrackedCreateDocument(EditorDocumentFormat.POWERPOINT.mimeType)) { output ->
        nativeExportResult(output, EditorDocumentFormat.POWERPOINT)
    }

    fun createDraft(format: EditorDocumentFormat) {
        val created = newTextPdfDraft(format = format)
        activeDraft = created
        scope.launch { withContext(Dispatchers.IO) { saveTextPdfDraft(context, created) } }
    }

    fun closeEditor(draft: TextPdfDraft) {
        val saved = draft.copy(modifiedAt = System.currentTimeMillis())
        activeDraft = null
        scope.launch {
            withContext(Dispatchers.IO) { saveTextPdfDraft(context, saved) }
            refreshDrafts()
        }
    }

    BackHandler(enabled = activeDraft != null) {
        activeDraft?.let(::closeEditor)
    }

    val draft = activeDraft
    if (draft == null) {
        DocumentEditorHome(
            drafts = drafts,
            loading = loadingDrafts,
            importing = importing,
            onBack = onBack,
            onNew = ::createDraft,
            onOpenFile = {
                openDocument.launch(
                    arrayOf(
                        "application/pdf",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        "text/plain"
                    )
                )
            },
            onOpenDraft = { activeDraft = it },
            onRefresh = { scope.launch { refreshDrafts() } }
        )
        return
    }

    LaunchedEffect(draft) {
        delay(500)
        withContext(Dispatchers.IO) { saveTextPdfDraft(context, draft) }
    }

    var undoStack by remember(draft.id) {
        mutableStateOf(listOf(EditorHistoryState(draft.body, draft.styleSpans)))
    }
    var redoStack by remember(draft.id) { mutableStateOf<List<EditorHistoryState>>(emptyList()) }
    var toolbarPanel by remember(draft.id) { mutableIntStateOf(0) }

    LaunchedEffect(draft.body, draft.styleSpans) {
        delay(500)
        val currentDraft = activeDraft?.takeIf { it.id == draft.id } ?: return@LaunchedEffect
        val current = EditorHistoryState(currentDraft.body, currentDraft.styleSpans)
        if (undoStack.lastOrNull() != current) {
            undoStack = (undoStack + current).takeLast(EDITOR_HISTORY_LIMIT)
            redoStack = emptyList()
        }
    }

    fun undo() {
        if (undoStack.size <= 1) return
        val current = undoStack.last()
        val target = undoStack[undoStack.lastIndex - 1]
        undoStack = undoStack.dropLast(1)
        redoStack = (redoStack + current).takeLast(EDITOR_HISTORY_LIMIT)
        activeDraft = draft.copy(
            body = target.body,
            styleSpans = target.styleSpans,
            modifiedAt = System.currentTimeMillis()
        )
    }

    fun redo() {
        val target = redoStack.lastOrNull() ?: return
        redoStack = redoStack.dropLast(1)
        undoStack = (undoStack + target).takeLast(EDITOR_HISTORY_LIMIT)
        activeDraft = draft.copy(
            body = target.body,
            styleSpans = target.styleSpans,
            modifiedAt = System.currentTimeMillis()
        )
    }

    fun persistNow(message: Boolean = true) {
        val ready = draft.copy(modifiedAt = System.currentTimeMillis())
        activeDraft = ready
        scope.launch {
            withContext(Dispatchers.IO) { saveTextPdfDraft(context, ready) }
            if (message) onMessage("Documento guardado en Gana Geo")
        }
    }

    fun exportPdf() {
        if (draft.body.isBlank()) {
            onMessage("El documento está vacío")
            return
        }
        val ready = draft.copy(modifiedAt = System.currentTimeMillis())
        activeDraft = ready
        scope.launch { withContext(Dispatchers.IO) { saveTextPdfDraft(context, ready) } }
        launchPaidExport(viewModel, tool, onMessage) {
            pendingExport = ready
            savePdf.launch(textPdfOutputName(ready.name))
        }
    }

    fun exportNative() {
        if (draft.body.isBlank()) {
            onMessage("El documento está vacío")
            return
        }
        if (draft.format == EditorDocumentFormat.PDF || draft.format == EditorDocumentFormat.TEXT) {
            exportPdf()
            return
        }
        val ready = draft.copy(modifiedAt = System.currentTimeMillis())
        activeDraft = ready
        scope.launch { withContext(Dispatchers.IO) { saveTextPdfDraft(context, ready) } }
        launchPaidExport(viewModel, tool, onMessage) {
            pendingNativeExport = ready
            val base = ready.name.trim().ifBlank { ready.format.label }.replace(Regex("[\\/:*?\"<>|]"), "_").substringBeforeLast('.').take(72)
            when (ready.format) {
                EditorDocumentFormat.WORD -> saveDocx.launch("$base.docx")
                EditorDocumentFormat.EXCEL -> saveXlsx.launch("$base.xlsx")
                EditorDocumentFormat.POWERPOINT -> savePptx.launch("$base.pptx")
                else -> Unit
            }
        }
    }

    DocumentEditorWorkspace(
        draft = draft,
        processing = processing,
        toolbarPanel = toolbarPanel,
        canUndo = undoStack.size > 1,
        canRedo = redoStack.isNotEmpty(),
        onToolbarPanelChange = { toolbarPanel = it },
        onDraftChange = { activeDraft = it.copy(modifiedAt = System.currentTimeMillis()) },
        onDone = { closeEditor(draft) },
        onSave = { persistNow() },
        onUndo = ::undo,
        onRedo = ::redo,
        onExportPdf = ::exportPdf,
        onExportNative = ::exportNative,
        onMessage = onMessage
    )
}

@Composable
private fun DocumentEditorHome(
    drafts: List<TextPdfDraft>,
    loading: Boolean,
    importing: Boolean,
    onBack: () -> Unit,
    onNew: (EditorDocumentFormat) -> Unit,
    onOpenFile: () -> Unit,
    onOpenDraft: (TextPdfDraft) -> Unit,
    onRefresh: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Color(0xFF101010)).statusBarsPadding().navigationBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(60.dp).background(Color(0xFF171717)).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.Close, "Cerrar", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text("Editor de documentos", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                Text("Offline · PDF · Word · Excel · PowerPoint", color = Color(0xFFB8B8B8), style = MaterialTheme.typography.bodySmall)
            }
            Box(
                modifier = Modifier.background(Color(0xFF21372B), RoundedCornerShape(10.dp)).padding(horizontal = 9.dp, vertical = 5.dp)
            ) {
                Text("OFFLINE", color = NeonGreen, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
            }
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Button(
                onClick = onOpenFile,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                enabled = !importing,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
                Icon(Icons.Rounded.FolderOpen, null)
                Text(if (importing) "  Abriendo documento…" else "  Abrir PDF, Word, Excel o PowerPoint", fontWeight = FontWeight.Black)
            }
            if (importing) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

            Text("Nuevo documento", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EditorHomeFormatButton(EditorDocumentFormat.PDF, Color(0xFFE94F58), Modifier.weight(1f)) { onNew(EditorDocumentFormat.PDF) }
                EditorHomeFormatButton(EditorDocumentFormat.WORD, Color(0xFF3976D3), Modifier.weight(1f)) { onNew(EditorDocumentFormat.WORD) }
                EditorHomeFormatButton(EditorDocumentFormat.EXCEL, Color(0xFF2E8B57), Modifier.weight(1f)) { onNew(EditorDocumentFormat.EXCEL) }
                EditorHomeFormatButton(EditorDocumentFormat.POWERPOINT, Color(0xFFE36B39), Modifier.weight(1f)) { onNew(EditorDocumentFormat.POWERPOINT) }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Documentos recientes", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, "Actualizar", tint = Color.White) }
            }

            when {
                loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NeonGreen)
                }
                drafts.isEmpty() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("Todavía no hay documentos", color = Color(0xFFB8B8B8))
                }
                else -> LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    lazyListItems(drafts, key = { it.id }) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onOpenDraft(item) },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1D1D1D)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(13.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                EditorFormatBadge(item.format, 46.dp)
                                Column(Modifier.weight(1f)) {
                                    Text(item.name, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text(
                                        "${item.format.label} · ${item.body.length} caracteres · ${android.text.format.DateUtils.getRelativeTimeSpanString(item.modifiedAt)}",
                                        color = Color(0xFFAFAFAF),
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorHomeFormatButton(
    format: EditorDocumentFormat,
    accent: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(78.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF1E1E1E))
            .clickable(onClick = onClick)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                modifier = Modifier.background(accent, RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text(format.shortLabel, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
            }
            Text(format.label, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}

@Composable
private fun EditorFormatBadge(format: EditorDocumentFormat, size: androidx.compose.ui.unit.Dp) {
    val accent = when (format) {
        EditorDocumentFormat.PDF -> Color(0xFFE94F58)
        EditorDocumentFormat.WORD -> Color(0xFF3976D3)
        EditorDocumentFormat.EXCEL -> Color(0xFF2E8B57)
        EditorDocumentFormat.POWERPOINT -> Color(0xFFE36B39)
        EditorDocumentFormat.TEXT -> Color(0xFF6F7780)
    }
    Box(
        modifier = Modifier.size(size).background(accent, RoundedCornerShape(11.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(format.shortLabel, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun DocumentEditorWorkspace(
    draft: TextPdfDraft,
    processing: Boolean,
    toolbarPanel: Int,
    canUndo: Boolean,
    canRedo: Boolean,
    onToolbarPanelChange: (Int) -> Unit,
    onDraftChange: (TextPdfDraft) -> Unit,
    onDone: () -> Unit,
    onSave: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onExportPdf: () -> Unit,
    onExportNative: () -> Unit,
    onMessage: (String) -> Unit
) {
    if (draft.format == EditorDocumentFormat.EXCEL) {
        SpreadsheetEditorWorkspace(
            draft = draft,
            processing = processing,
            canUndo = canUndo,
            canRedo = canRedo,
            onDraftChange = onDraftChange,
            onDone = onDone,
            onSave = onSave,
            onUndo = onUndo,
            onRedo = onRedo,
            onExportPdf = onExportPdf,
            onExportNative = onExportNative
        )
        return
    }
    if (draft.format == EditorDocumentFormat.POWERPOINT) {
        PresentationEditorWorkspace(
            draft = draft,
            processing = processing,
            canUndo = canUndo,
            canRedo = canRedo,
            onDraftChange = onDraftChange,
            onDone = onDone,
            onSave = onSave,
            onUndo = onUndo,
            onRedo = onRedo,
            onExportPdf = onExportPdf,
            onExportNative = onExportNative
        )
        return
    }

    val paper = PdfPaperSize.entries.getOrElse(draft.paperIndex) { PdfPaperSize.A4 }
    val orientation = PdfOrientation.entries.getOrElse(draft.orientationIndex) { PdfOrientation.PORTRAIT }
    val margin = PdfMargin.entries.getOrElse(draft.marginIndex) { PdfMargin.NORMAL }
    val alignment = EditorTextAlignment.entries.getOrElse(draft.alignmentIndex) { EditorTextAlignment.LEFT }
    var zoom by remember(draft.id) { mutableFloatStateOf(1f) }
    var panX by remember(draft.id) { mutableFloatStateOf(0f) }
    var panY by remember(draft.id) { mutableFloatStateOf(0f) }
    var editorValue by remember(draft.id) { mutableStateOf(TextFieldValue(draft.body)) }
    var showOriginalPdf by remember(draft.id) { mutableStateOf(draft.format == EditorDocumentFormat.PDF && draft.sourceUriText.isNotBlank()) }

    LaunchedEffect(draft.body) {
        if (editorValue.text != draft.body) {
            val start = editorValue.selection.start.coerceIn(0, draft.body.length)
            val end = editorValue.selection.end.coerceIn(0, draft.body.length)
            editorValue = TextFieldValue(draft.body, selection = TextRange(start, end))
        }
    }

    fun updateEditorValue(next: TextFieldValue) {
        val limitedText = next.text.take(TEXT_PDF_MAX_CHARS)
        val limited = if (limitedText == next.text) next else TextFieldValue(
            text = limitedText,
            selection = TextRange(
                next.selection.start.coerceIn(0, limitedText.length),
                next.selection.end.coerceIn(0, limitedText.length)
            )
        )
        editorValue = limited
        if (limited.text != draft.body) {
            onDraftChange(
                draft.copy(
                    body = limited.text,
                    styleSpans = editorRemapTextStyleSpans(draft.body, limited.text, draft.styleSpans)
                )
            )
        }
    }

    val selectionFormat = editorSelectionFormatState(draft.body.length, draft.styleSpans, editorValue.selection)

    fun adjustSelectionScale(delta: Float) {
        if (!selectionFormat.hasSelection) {
            onDraftChange(draft.copy(fontSize = (draft.fontSize + delta * 10f).coerceIn(8f, 32f)))
            return
        }
        onDraftChange(
            draft.copy(
                styleSpans = editorAdjustSelectionStyle(
                    textLength = draft.body.length,
                    spans = draft.styleSpans,
                    selection = editorValue.selection,
                    scaleDelta = delta
                )
            )
        )
    }

    fun toggleSelectionBold() {
        if (!selectionFormat.hasSelection) {
            onDraftChange(draft.copy(bold = !draft.bold))
            return
        }
        onDraftChange(draft.copy(styleSpans = editorAdjustSelectionStyle(draft.body.length, draft.styleSpans, editorValue.selection, toggleBold = true)))
    }

    fun toggleSelectionItalic() {
        if (!selectionFormat.hasSelection) {
            onDraftChange(draft.copy(italic = !draft.italic))
            return
        }
        onDraftChange(draft.copy(styleSpans = editorAdjustSelectionStyle(draft.body.length, draft.styleSpans, editorValue.selection, toggleItalic = true)))
    }

    fun toggleSelectionUnderline() {
        if (!selectionFormat.hasSelection) {
            onDraftChange(draft.copy(underline = !draft.underline))
            return
        }
        onDraftChange(draft.copy(styleSpans = editorAdjustSelectionStyle(draft.body.length, draft.styleSpans, editorValue.selection, toggleUnderline = true)))
    }

    fun toggleSelectionStrike() {
        onDraftChange(draft.copy(styleSpans = editorAdjustSelectionStyle(draft.body.length, draft.styleSpans, editorValue.selection, toggleStrike = true)))
    }

    fun applySelectionColor(argb: Int) {
        onDraftChange(draft.copy(styleSpans = editorAdjustSelectionStyle(draft.body.length, draft.styleSpans, editorValue.selection, setColor = argb)))
    }

    fun applySelectionHighlight(argb: Int) {
        onDraftChange(draft.copy(styleSpans = editorAdjustSelectionStyle(draft.body.length, draft.styleSpans, editorValue.selection, setHighlight = argb)))
    }

    fun clearSelectionFormat() {
        if (!selectionFormat.hasSelection) {
            onDraftChange(draft.copy(bold = false, italic = false, underline = false, styleSpans = emptyList()))
            return
        }
        onDraftChange(draft.copy(styleSpans = editorAdjustSelectionStyle(draft.body.length, draft.styleSpans, editorValue.selection, clearFormat = true)))
    }

    fun changeSelectionCase(mode: Int) {
        val changed = editorChangeCase(draft.body, editorValue.selection, mode)
        if (changed == draft.body) return
        // El texto conserva su longitud, así que los estilos siguen en su sitio.
        onDraftChange(draft.copy(body = changed))
        editorValue = TextFieldValue(changed, editorValue.selection)
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF0E0E0E)).statusBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(58.dp).background(Color(0xFF171717)).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.clickable(onClick = onDone).padding(horizontal = 8.dp, vertical = 10.dp)
            ) {
                Text("Listo", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
            IconButton(onClick = onSave) { Icon(Icons.Rounded.Save, "Guardar", tint = Color(0xFFDADADA)) }
            IconButton(onClick = onUndo, enabled = canUndo) {
                Icon(Icons.Rounded.Undo, "Deshacer", tint = if (canUndo) Color(0xFFDADADA) else Color(0xFF555555))
            }
            IconButton(onClick = onRedo, enabled = canRedo) {
                Icon(Icons.Rounded.Redo, "Rehacer", tint = if (canRedo) Color(0xFFDADADA) else Color(0xFF555555))
            }
            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier.background(Color(0xFF2B2B2B), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text(draft.format.shortLabel, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = onDone) { Icon(Icons.Rounded.Close, "Cerrar", tint = Color(0xFFDADADA)) }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF101010))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 72.dp)
            ) {
                if (showOriginalPdf && draft.sourceUriText.isNotBlank() && draft.format == EditorDocumentFormat.PDF) {
                    DocumentEditorViewerSurface(
                        formatName = draft.format.name,
                        sourceUriText = draft.sourceUriText,
                        modifier = Modifier.fillMaxSize(),
                        onMessage = onMessage
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 8.dp)
                            .background(Color(0xB31B1B1B), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "Vista original · toca aquí para editar una copia",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { showOriginalPdf = false }
                        )
                    }
                } else {
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxSize()
                            .clipToBounds()
                            .pointerInput(draft.id) {
                                awaitEachGesture {
                                    do {
                                        val event = awaitPointerEvent(PointerEventPass.Initial)
                                        val pressed = event.changes.filter { it.pressed }
                                        if (pressed.size >= 2) {
                                            val viewportW = size.width.toFloat().coerceAtLeast(1f)
                                            val viewportH = size.height.toFloat().coerceAtLeast(1f)
                                            val centroidX = pressed.sumOf { it.position.x.toDouble() }.toFloat() / pressed.size
                                            val centroidY = pressed.sumOf { it.position.y.toDouble() }.toFloat() / pressed.size
                                            val oldZoom = zoom.coerceIn(1f, 4f)
                                            val requestedZoom = (oldZoom * event.calculateZoom()).coerceIn(1f, 4f)
                                            val actualFactor = requestedZoom / oldZoom.coerceAtLeast(0.001f)
                                            val drag = event.calculatePan()
                                            val relativeX = centroidX - viewportW / 2f
                                            val relativeY = centroidY - viewportH / 2f
                                            val nextX = panX * actualFactor + relativeX * (1f - actualFactor) + drag.x
                                            val nextY = panY * actualFactor + relativeY * (1f - actualFactor) + drag.y
                                            val extraX = (viewportW * (requestedZoom - 1f) / 2f).coerceAtLeast(0f)
                                            val extraY = (viewportH * (requestedZoom - 1f) / 2f).coerceAtLeast(0f)
                                            zoom = requestedZoom
                                            panX = if (extraX <= 0.5f) 0f else nextX.coerceIn(-extraX, extraX)
                                            panY = if (extraY <= 0.5f) 0f else nextY.coerceIn(-extraY, extraY)
                                            if (requestedZoom <= 1.001f) {
                                                panX = 0f
                                                panY = 0f
                                            }
                                            event.changes.forEach { it.consume() }
                                        }
                                    } while (event.changes.any { it.pressed })
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        val baseRatio = when (draft.format) {
                            EditorDocumentFormat.POWERPOINT -> 16f / 9f
                            EditorDocumentFormat.EXCEL -> 1.18f
                            else -> {
                                val pw = paper.widthPoints.takeIf { it > 0 } ?: PdfPaperSize.A4.widthPoints
                                val ph = paper.heightPoints.takeIf { it > 0 } ?: PdfPaperSize.A4.heightPoints
                                if (orientation == PdfOrientation.LANDSCAPE) ph.toFloat() / pw.toFloat() else pw.toFloat() / ph.toFloat()
                            }
                        }.coerceIn(0.5f, 2.0f)
                        val availableRatio = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
                        val pageWidth = if (baseRatio >= availableRatio) maxWidth.value * 0.96f else maxHeight.value * 0.96f * baseRatio
                        val pageHeight = pageWidth / baseRatio
                        val pagePadding = when (margin) {
                            PdfMargin.NONE -> 8.dp
                            PdfMargin.SMALL -> 12.dp
                            PdfMargin.NORMAL -> 20.dp
                            PdfMargin.LARGE -> 30.dp
                        }

                        Box(
                            modifier = Modifier
                                .width(pageWidth.dp)
                                .height(pageHeight.dp)
                                .graphicsLayer(
                                    scaleX = zoom,
                                    scaleY = zoom,
                                    translationX = panX,
                                    translationY = panY,
                                    clip = true
                                )
                                .background(Color.White)
                        ) {
                            if (draft.format == EditorDocumentFormat.EXCEL) {
                                Canvas(Modifier.fillMaxSize()) {
                                    val gridColor = androidx.compose.ui.graphics.Color(0xFFE0E5E2)
                                    var x = 0f
                                    while (x < size.width) {
                                        drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                                        x += 72f
                                    }
                                    var y = 0f
                                    while (y < size.height) {
                                        drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                                        y += 34f
                                    }
                                }
                            }

                            BasicTextField(
                                value = editorValue,
                                onValueChange = ::updateEditorValue,
                                visualTransformation = editorTextStyleTransformation(draft.styleSpans, draft.fontSize.sp),
                                modifier = Modifier.fillMaxSize().padding(pagePadding),
                                textStyle = MaterialTheme.typography.bodyLarge.copy(
                                    color = Color.Black,
                                    fontSize = draft.fontSize.sp,
                                    lineHeight = androidx.compose.ui.unit.TextUnit.Unspecified,
                                    fontFamily = if (draft.format == EditorDocumentFormat.EXCEL) FontFamily.Monospace else FontFamily.Default,
                                    fontWeight = if (draft.bold) FontWeight.Bold else FontWeight.Normal,
                                    fontStyle = if (draft.italic) androidx.compose.ui.text.font.FontStyle.Italic else androidx.compose.ui.text.font.FontStyle.Normal,
                                    textDecoration = if (draft.underline) TextDecoration.Underline else TextDecoration.None,
                                    textAlign = when (alignment) {
                                        EditorTextAlignment.LEFT -> TextAlign.Start
                                        EditorTextAlignment.CENTER -> TextAlign.Center
                                        EditorTextAlignment.RIGHT -> TextAlign.End
                                    }
                                ),
                                decorationBox = { inner ->
                                    if (draft.body.isBlank()) {
                                        Text(
                                            when (draft.format) {
                                                EditorDocumentFormat.PDF -> "Escribe o pega texto para crear una versión editable del PDF…"
                                                EditorDocumentFormat.WORD -> "Escribe tu documento…"
                                                EditorDocumentFormat.EXCEL -> "Escribe valores separados por tabulaciones y filas…"
                                                EditorDocumentFormat.POWERPOINT -> "Escribe el contenido de la diapositiva…"
                                                EditorDocumentFormat.TEXT -> "Escribe aquí…"
                                            },
                                            color = Color(0xFF9A9A9A),
                                            fontSize = draft.fontSize.sp
                                        )
                                    }
                                    inner()
                                }
                            )

                            if (draft.format == EditorDocumentFormat.PDF && draft.sourceUriText.isNotBlank()) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(8.dp)
                                        .background(Color(0xCC2B2B2B), RoundedCornerShape(8.dp))
                                        .clickable { showOriginalPdf = true }
                                        .padding(horizontal = 9.dp, vertical = 6.dp)
                                ) {
                                    Text("Ver original", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(8.dp)
                                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
                                    .clickable {
                                        zoom = 1f
                                        panX = 0f
                                        panY = 0f
                                    }
                                    .padding(horizontal = 7.dp, vertical = 4.dp)
                            ) {
                                Text("${(zoom * 100).roundToInt()}%", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            if (toolbarPanel != 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 64.dp)
                        .navigationBarsPadding()
                        .fillMaxWidth()
                ) {
                    when (toolbarPanel) {
                        1 -> EditorTextFormatPanel(
                            draft = draft,
                            editorValue = editorValue,
                            selectionFormat = selectionFormat,
                            onEditorValueChange = ::updateEditorValue,
                            onDecreaseSelection = { adjustSelectionScale(-0.12f) },
                            onIncreaseSelection = { adjustSelectionScale(0.12f) },
                            onToggleBold = ::toggleSelectionBold,
                            onToggleItalic = ::toggleSelectionItalic,
                            onToggleUnderline = ::toggleSelectionUnderline,
                            onToggleStrike = ::toggleSelectionStrike,
                            onApplyColor = ::applySelectionColor,
                            onApplyHighlight = ::applySelectionHighlight,
                            onChangeCase = ::changeSelectionCase,
                            onClearFormat = ::clearSelectionFormat,
                            onDraftChange = onDraftChange
                        )
                        2 -> EditorLayoutPanel(draft, paper, orientation, margin, onDraftChange, onExportPdf, processing)
                        3 -> EditorExportPanel(
                            format = draft.format,
                            processing = processing,
                            onExportPdf = onExportPdf,
                            onExportNative = onExportNative
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color(0xFF242424))
                    .navigationBarsPadding()
                    .height(64.dp)
                    .padding(horizontal = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                EditorToolbarButton("Aa", toolbarPanel == 1) { onToolbarPanelChange(if (toolbarPanel == 1) 0 else 1) }
                EditorToolbarButton("B", if (selectionFormat.hasSelection) selectionFormat.bold else draft.bold, FontWeight.Black) { toggleSelectionBold() }
                EditorToolbarButton("I", if (selectionFormat.hasSelection) selectionFormat.italic else draft.italic) { toggleSelectionItalic() }
                EditorToolbarButton("U̲", if (selectionFormat.hasSelection) selectionFormat.underline else draft.underline, FontWeight.Bold) { toggleSelectionUnderline() }
                EditorToolbarButton(
                    when (alignment) {
                        EditorTextAlignment.LEFT -> "≡←"
                        EditorTextAlignment.CENTER -> "≡↔"
                        EditorTextAlignment.RIGHT -> "→≡"
                    },
                    false
                ) {
                    val next = EditorTextAlignment.entries[(alignment.ordinal + 1) % EditorTextAlignment.entries.size]
                    onDraftChange(draft.copy(alignmentIndex = next.ordinal))
                }
                EditorToolbarButton("+", toolbarPanel == 2, FontWeight.Normal, 26.sp) { onToolbarPanelChange(if (toolbarPanel == 2) 0 else 2) }
                EditorToolbarButton("PDF", toolbarPanel == 3, FontWeight.Black) { onToolbarPanelChange(if (toolbarPanel == 3) 0 else 3) }
            }

            if (processing) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun SpreadsheetEditorWorkspace(
    draft: TextPdfDraft,
    processing: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    onDraftChange: (TextPdfDraft) -> Unit,
    onDone: () -> Unit,
    onSave: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onExportPdf: () -> Unit,
    onExportNative: () -> Unit
) {
    var grid by remember(draft.id) { mutableStateOf(editorGridFromBody(draft.body)) }
    var selectedRow by remember(draft.id) { mutableIntStateOf(0) }
    var selectedCol by remember(draft.id) { mutableIntStateOf(0) }
    val horizontal = rememberScrollState()
    val vertical = rememberScrollState()

    LaunchedEffect(draft.body) {
        if (editorGridToBody(grid) != draft.body) {
            grid = editorGridFromBody(draft.body)
            selectedRow = selectedRow.coerceIn(0, grid.lastIndex.coerceAtLeast(0))
            selectedCol = selectedCol.coerceIn(0, (grid.firstOrNull()?.lastIndex ?: 0).coerceAtLeast(0))
        }
    }

    fun commit(next: MutableList<MutableList<String>>) {
        grid = next
        onDraftChange(draft.copy(body = editorGridToBody(next), styleSpans = emptyList()))
    }

    fun updateCell(row: Int, col: Int, value: String) {
        val next = grid.map { it.toMutableList() }.toMutableList()
        while (row >= next.size) next.add(MutableList(next.firstOrNull()?.size ?: 8) { "" })
        while (col >= (next.firstOrNull()?.size ?: 0)) next.forEach { it.add("") }
        next[row][col] = value.take(5000)
        commit(next)
    }

    val safeRow = selectedRow.coerceIn(0, grid.lastIndex.coerceAtLeast(0))
    val safeCol = selectedCol.coerceIn(0, (grid.firstOrNull()?.lastIndex ?: 0).coerceAtLeast(0))
    val selectedRaw = grid.getOrNull(safeRow)?.getOrNull(safeCol).orEmpty()
    val selectedResult = editorEvaluateExcelFormula(selectedRaw, grid)
    val selectedRef = "${editorExcelColumnName(safeCol)}${safeRow + 1}"

    Column(Modifier.fillMaxSize().background(Color(0xFF0E0E0E)).statusBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(58.dp).background(Color(0xFF171717)).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Listo", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onDone).padding(8.dp))
            IconButton(onClick = onSave) { Icon(Icons.Rounded.Save, "Guardar", tint = Color(0xFFDADADA)) }
            IconButton(onClick = onUndo, enabled = canUndo) { Icon(Icons.Rounded.Undo, "Deshacer", tint = if (canUndo) Color.White else Color(0xFF555555)) }
            IconButton(onClick = onRedo, enabled = canRedo) { Icon(Icons.Rounded.Redo, "Rehacer", tint = if (canRedo) Color.White else Color(0xFF555555)) }
            Spacer(Modifier.weight(1f))
            Box(Modifier.background(Color(0xFF2E8B57), RoundedCornerShape(8.dp)).padding(horizontal = 9.dp, vertical = 5.dp)) {
                Text("XLSX", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = onDone) { Icon(Icons.Rounded.Close, "Cerrar", tint = Color.White) }
        }

        Row(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF242424)).padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(Modifier.width(58.dp).height(44.dp).background(Color(0xFF3A3A3A), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                Text(selectedRef, color = NeonGreen, fontWeight = FontWeight.Black)
            }
            OutlinedTextField(
                value = selectedRaw,
                onValueChange = { updateCell(safeRow, safeCol, it) },
                modifier = Modifier.weight(1f).height(52.dp),
                singleLine = true,
                placeholder = { Text("Valor o fórmula: =SUM(A1:A5)") },
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color.White)
            )
            if (selectedRaw.startsWith("=")) {
                Text("= $selectedResult", color = NeonGreen, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).background(Color(0xFF1B1B1B)).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            EditorPanelChip("+ Fila") {
                val next = grid.map { it.toMutableList() }.toMutableList()
                next.add(MutableList((next.firstOrNull()?.size ?: 8).coerceAtLeast(1)) { "" })
                grid = next
            }
            EditorPanelChip("+ Columna") {
                val next = grid.map { it.toMutableList() }.toMutableList()
                next.forEach { it.add("") }
                grid = next
            }
            EditorPanelChip("SUM") { updateCell(safeRow, safeCol, "=SUM(A1:A5)") }
            EditorPanelChip("PROMEDIO") { updateCell(safeRow, safeCol, "=AVERAGE(A1:A5)") }
            EditorPanelChip("MÍN") { updateCell(safeRow, safeCol, "=MIN(A1:A5)") }
            EditorPanelChip("MÁX") { updateCell(safeRow, safeCol, "=MAX(A1:A5)") }
            EditorPanelChip("CONTAR") { updateCell(safeRow, safeCol, "=COUNT(A1:A5)") }
        }

        Box(Modifier.fillMaxWidth().weight(1f).background(Color(0xFFF4F6F5))) {
            Row(Modifier.fillMaxSize().horizontalScroll(horizontal)) {
                Column(Modifier.verticalScroll(vertical)) {
                    Row {
                        Box(Modifier.width(46.dp).height(38.dp).background(Color(0xFFE0E5E2)))
                        val colCount = (grid.firstOrNull()?.size ?: 8).coerceAtLeast(8)
                        repeat(colCount) { col ->
                            Box(Modifier.width(104.dp).height(38.dp).background(Color(0xFFE7ECE9)), contentAlignment = Alignment.Center) {
                                Text(editorExcelColumnName(col), color = Color(0xFF34423A), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    grid.forEachIndexed { rowIndex, row ->
                        Row {
                            Box(Modifier.width(46.dp).height(42.dp).background(Color(0xFFE7ECE9)), contentAlignment = Alignment.Center) {
                                Text((rowIndex + 1).toString(), color = Color(0xFF526159), style = MaterialTheme.typography.bodySmall)
                            }
                            row.forEachIndexed { colIndex, value ->
                                val selected = rowIndex == safeRow && colIndex == safeCol
                                BasicTextField(
                                    value = value,
                                    onValueChange = { updateCell(rowIndex, colIndex, it) },
                                    modifier = Modifier
                                        .width(104.dp)
                                        .height(42.dp)
                                        .background(if (selected) Color(0xFFD6F3DF) else Color.White)
                                        .onFocusChanged {
                                            if (it.isFocused) {
                                                selectedRow = rowIndex
                                                selectedCol = colIndex
                                            }
                                        }
                                        .padding(horizontal = 6.dp, vertical = 10.dp),
                                    singleLine = true,
                                    textStyle = MaterialTheme.typography.bodySmall.copy(color = Color.Black),
                                    cursorBrush = SolidColor(Color(0xFF1D6F42))
                                )
                            }
                        }
                    }
                }
            }
            if (processing) LinearProgressIndicator(Modifier.align(Alignment.TopCenter).fillMaxWidth())
        }

        Row(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF242424)).navigationBarsPadding().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            EditorPanelChip("Guardar XLSX") { if (!processing) onExportNative() }
            EditorPanelChip("Exportar PDF") { if (!processing) onExportPdf() }
            Text("Fórmulas: SUM, AVERAGE, MIN, MAX, COUNT y operaciones A1+B1", color = Color(0xFFBDBDBD), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(10.dp))
        }
    }
}

@Composable
private fun PresentationEditorWorkspace(
    draft: TextPdfDraft,
    processing: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    onDraftChange: (TextPdfDraft) -> Unit,
    onDone: () -> Unit,
    onSave: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onExportPdf: () -> Unit,
    onExportNative: () -> Unit
) {
    var slides by remember(draft.id) { mutableStateOf(editorParseSlides(draft.body)) }
    var selectedIndex by remember(draft.id) { mutableIntStateOf(0) }

    LaunchedEffect(draft.body) {
        if (editorSerializeSlides(slides) != draft.body) {
            slides = editorParseSlides(draft.body)
            selectedIndex = selectedIndex.coerceIn(0, slides.lastIndex.coerceAtLeast(0))
        }
    }

    fun commit(next: List<EditorSlide>, select: Int = selectedIndex) {
        slides = next.ifEmpty { listOf(EditorSlide("Título", "")) }
        selectedIndex = select.coerceIn(0, slides.lastIndex)
        onDraftChange(draft.copy(body = editorSerializeSlides(slides), styleSpans = emptyList()))
    }

    val slide = slides.getOrElse(selectedIndex.coerceIn(0, slides.lastIndex.coerceAtLeast(0))) { EditorSlide("Título", "") }

    Column(Modifier.fillMaxSize().background(Color(0xFF0E0E0E)).statusBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(58.dp).background(Color(0xFF171717)).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Listo", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onDone).padding(8.dp))
            IconButton(onClick = onSave) { Icon(Icons.Rounded.Save, "Guardar", tint = Color.White) }
            IconButton(onClick = onUndo, enabled = canUndo) { Icon(Icons.Rounded.Undo, "Deshacer", tint = if (canUndo) Color.White else Color(0xFF555555)) }
            IconButton(onClick = onRedo, enabled = canRedo) { Icon(Icons.Rounded.Redo, "Rehacer", tint = if (canRedo) Color.White else Color(0xFF555555)) }
            Spacer(Modifier.weight(1f))
            Text("${selectedIndex + 1}/${slides.size}", color = Color(0xFFDADADA), fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Box(Modifier.background(Color(0xFFE36B39), RoundedCornerShape(8.dp)).padding(horizontal = 9.dp, vertical = 5.dp)) {
                Text("PPTX", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = onDone) { Icon(Icons.Rounded.Close, "Cerrar", tint = Color.White) }
        }

        Row(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF242424)).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            slides.forEachIndexed { index, item ->
                Box(
                    modifier = Modifier
                        .width(116.dp)
                        .height(70.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (index == selectedIndex) Color(0xFF5A3425) else Color.White)
                        .clickable { selectedIndex = index }
                        .padding(7.dp)
                ) {
                    Column {
                        Text("${index + 1}", color = if (index == selectedIndex) Color.White else Color.Gray, style = MaterialTheme.typography.labelSmall)
                        Text(item.title, color = if (index == selectedIndex) Color.White else Color.Black, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    }
                }
            }
        }

        BoxWithConstraints(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF101010)), contentAlignment = Alignment.Center) {
            val availableRatio = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
            val ratio = 16f / 9f
            val slideW = if (ratio >= availableRatio) maxWidth.value * 0.94f else maxHeight.value * 0.90f * ratio
            val slideH = slideW / ratio
            Column(
                modifier = Modifier.width(slideW.dp).height(slideH.dp).background(Color.White).padding(horizontal = 26.dp, vertical = 22.dp)
            ) {
                BasicTextField(
                    value = slide.title,
                    onValueChange = { value ->
                        val next = slides.toMutableList(); next[selectedIndex] = slide.copy(title = value.take(180)); commit(next)
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                    textStyle = MaterialTheme.typography.headlineMedium.copy(color = Color(0xFF202020), fontWeight = FontWeight.Bold),
                    cursorBrush = SolidColor(Color(0xFFE36B39)),
                    decorationBox = { inner -> if (slide.title.isBlank()) Text("Título de la diapositiva", color = Color.Gray, style = MaterialTheme.typography.headlineSmall); inner() }
                )
                Spacer(Modifier.height(16.dp))
                BasicTextField(
                    value = slide.body,
                    onValueChange = { value ->
                        val next = slides.toMutableList(); next[selectedIndex] = slide.copy(body = value.take(20_000)); commit(next)
                    },
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    textStyle = MaterialTheme.typography.titleMedium.copy(color = Color(0xFF333333), lineHeight = 26.sp),
                    cursorBrush = SolidColor(Color(0xFFE36B39)),
                    decorationBox = { inner -> if (slide.body.isBlank()) Text("Contenido · puedes usar varias líneas", color = Color.Gray); inner() }
                )
            }
            if (processing) LinearProgressIndicator(Modifier.align(Alignment.TopCenter).fillMaxWidth())
        }

        Row(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF242424)).navigationBarsPadding().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            EditorPanelChip("+ Diapositiva") {
                val next = slides.toMutableList(); next.add(selectedIndex + 1, EditorSlide("Nueva diapositiva", "")); commit(next, selectedIndex + 1)
            }
            EditorPanelChip("Duplicar") {
                val next = slides.toMutableList(); next.add(selectedIndex + 1, slide.copy()); commit(next, selectedIndex + 1)
            }
            EditorPanelChip("Borrar") {
                if (slides.size > 1) { val next = slides.toMutableList(); next.removeAt(selectedIndex); commit(next, (selectedIndex - 1).coerceAtLeast(0)) }
            }
            EditorPanelChip("←") {
                if (selectedIndex > 0) { val next = slides.toMutableList(); val item = next.removeAt(selectedIndex); next.add(selectedIndex - 1, item); commit(next, selectedIndex - 1) }
            }
            EditorPanelChip("→") {
                if (selectedIndex < slides.lastIndex) { val next = slides.toMutableList(); val item = next.removeAt(selectedIndex); next.add(selectedIndex + 1, item); commit(next, selectedIndex + 1) }
            }
            EditorPanelChip("• Viñetas") {
                val lines = slide.body.lines()
                val allBulleted = lines.filter(String::isNotBlank).all { it.trimStart().startsWith("• ") } && lines.any(String::isNotBlank)
                val nextBody = lines.joinToString("\n") { line -> if (line.isBlank()) line else if (allBulleted) line.replaceFirst(Regex("^\\s*•\\s+"), "") else "• ${line.trimStart()}" }
                val next = slides.toMutableList(); next[selectedIndex] = slide.copy(body = nextBody); commit(next)
            }
            EditorPanelChip("Guardar PPTX") { if (!processing) onExportNative() }
            EditorPanelChip("Exportar PDF") { if (!processing) onExportPdf() }
        }
    }
}

@Composable
private fun EditorToolbarButton(
    label: String,
    active: Boolean,
    weight: FontWeight = FontWeight.Normal,
    size: androidx.compose.ui.unit.TextUnit = 19.sp,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) Color(0xFF3C5A48) else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (active) NeonGreen else Color(0xFFD0D0D0), fontWeight = weight, fontSize = size)
    }
}

@Composable
private fun EditorTextFormatPanel(
    draft: TextPdfDraft,
    editorValue: TextFieldValue,
    selectionFormat: EditorSelectionFormatState,
    onEditorValueChange: (TextFieldValue) -> Unit,
    onDecreaseSelection: () -> Unit,
    onIncreaseSelection: () -> Unit,
    onToggleBold: () -> Unit,
    onToggleItalic: () -> Unit,
    onToggleUnderline: () -> Unit,
    onToggleStrike: () -> Unit,
    onApplyColor: (Int) -> Unit,
    onApplyHighlight: (Int) -> Unit,
    onChangeCase: (Int) -> Unit,
    onClearFormat: () -> Unit,
    onDraftChange: (TextPdfDraft) -> Unit
) {
    // Paletas cortas a propósito: en un móvil un selector de color completo
    // ocupa media pantalla y se usa menos que estos seis de siempre.
    val textColors = listOf(
        0xFF000000.toInt() to "Negro",
        0xFFC0392B.toInt() to "Rojo",
        0xFF1F6FB2.toInt() to "Azul",
        0xFF1E7A46.toInt() to "Verde",
        0xFF8E44AD.toInt() to "Morado",
        0xFFB8860B.toInt() to "Ámbar"
    )
    val highlightColors = listOf(
        0xFFFFF176.toInt() to "Amarillo",
        0xFF80DEEA.toInt() to "Celeste",
        0xFFA5D6A7.toInt() to "Verde",
        0xFFF48FB1.toInt() to "Rosa"
    )
    var colorMenu by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF303030))
            .imePadding()
    ) {
        if (colorMenu != 0) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    if (colorMenu == 1) "Color de letra" else "Resaltado",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )
                val palette = if (colorMenu == 1) textColors else highlightColors
                palette.forEach { (argb, name) ->
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .background(Color(argb), RoundedCornerShape(8.dp))
                            .clickable {
                                if (colorMenu == 1) onApplyColor(argb) else onApplyHighlight(argb)
                                colorMenu = 0
                            }
                    )
                    Text(name, color = Color(0xFFBDBDBD), style = MaterialTheme.typography.labelSmall)
                }
                EditorPanelChip("Quitar") {
                    if (colorMenu == 1) onApplyColor(0) else onApplyHighlight(0)
                    colorMenu = 0
                }
                EditorPanelChip("Cerrar") { colorMenu = 0 }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            EditorPanelChip("A−") { onDecreaseSelection() }
            Text(
                if (selectionFormat.hasSelection) "Solo selección" else "Todo el texto",
                color = if (selectionFormat.hasSelection) NeonGreen else Color.White,
                fontWeight = FontWeight.Bold
            )
            EditorPanelChip("A+") { onIncreaseSelection() }
            EditorPanelChip(if ((selectionFormat.hasSelection && selectionFormat.bold) || (!selectionFormat.hasSelection && draft.bold)) "Negrita ✓" else "Negrita") { onToggleBold() }
            EditorPanelChip(if ((selectionFormat.hasSelection && selectionFormat.italic) || (!selectionFormat.hasSelection && draft.italic)) "Cursiva ✓" else "Cursiva") { onToggleItalic() }
            EditorPanelChip(if ((selectionFormat.hasSelection && selectionFormat.underline) || (!selectionFormat.hasSelection && draft.underline)) "Subrayado ✓" else "Subrayado") { onToggleUnderline() }
            EditorPanelChip(if (selectionFormat.strike) "Tachado ✓" else "Tachado") { onToggleStrike() }
            EditorPanelChip("Color") { colorMenu = if (colorMenu == 1) 0 else 1 }
            EditorPanelChip("Resaltar") { colorMenu = if (colorMenu == 2) 0 else 2 }
            EditorPanelChip("MAYÚS") { onChangeCase(0) }
            EditorPanelChip("minús") { onChangeCase(1) }
            EditorPanelChip("Tipo Título") { onChangeCase(2) }
            EditorPanelChip("Interlineado ${String.format(java.util.Locale.US, "%.1f", draft.lineSpacing)}") {
                val steps = listOf(1f, 1.15f, 1.32f, 1.5f, 2f)
                val current = steps.indexOfFirst { kotlin.math.abs(it - draft.lineSpacing) < 0.02f }
                val next = steps[((if (current < 0) 2 else current) + 1) % steps.size]
                onDraftChange(draft.copy(lineSpacing = next))
            }
            EditorPanelChip("Borrar formato") { onClearFormat() }
            EditorPanelChip("• Viñetas") { onEditorValueChange(TextFieldValue(editorToggleBullets(draft.body))) }
            EditorPanelChip("1. Numeración") { onEditorValueChange(TextFieldValue(editorNumberLines(draft.body))) }
            EditorPanelChip(if (draft.columns == 2) "2 columnas ✓" else "2 columnas") {
                onDraftChange(draft.copy(columns = if (draft.columns == 2) 1 else 2))
            }
        }
    }
}

@Composable
private fun EditorLayoutPanel(
    draft: TextPdfDraft,
    paper: PdfPaperSize,
    orientation: PdfOrientation,
    margin: PdfMargin,
    onDraftChange: (TextPdfDraft) -> Unit,
    onExportPdf: () -> Unit,
    processing: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF303030))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        EditorPanelChip(paper.label.substringBefore(" ·")) {
            val allowed = listOf(PdfPaperSize.A4, PdfPaperSize.LETTER, PdfPaperSize.A3, PdfPaperSize.A5)
            val current = allowed.indexOf(paper).takeIf { it >= 0 } ?: 0
            onDraftChange(draft.copy(paperIndex = allowed[(current + 1) % allowed.size].ordinal))
        }
        EditorPanelChip(if (orientation == PdfOrientation.LANDSCAPE) "Horizontal" else "Vertical") {
            val next = if (orientation == PdfOrientation.LANDSCAPE) PdfOrientation.PORTRAIT else PdfOrientation.LANDSCAPE
            onDraftChange(draft.copy(orientationIndex = next.ordinal))
        }
        EditorPanelChip("Márgenes: ${margin.label}") {
            val next = PdfMargin.entries[(margin.ordinal + 1) % PdfMargin.entries.size]
            onDraftChange(draft.copy(marginIndex = next.ordinal))
        }
        EditorPanelChip(if (draft.pageNumbers) "Páginas ✓" else "Páginas") {
            onDraftChange(draft.copy(pageNumbers = !draft.pageNumbers))
        }
        EditorPanelChip(if (draft.pageColorArgb == 0) "Color de página" else "Color ✓") {
            // Tonos claros: en papel oscuro el texto negro deja de leerse.
            val tones = listOf(0, 0xFFFFF8E1.toInt(), 0xFFE8F5E9.toInt(), 0xFFE3F2FD.toInt(), 0xFFFCE4EC.toInt())
            val current = tones.indexOf(draft.pageColorArgb).takeIf { it >= 0 } ?: 0
            onDraftChange(draft.copy(pageColorArgb = tones[(current + 1) % tones.size]))
        }
        EditorPanelChip(if (draft.pageBorder) "Borde ✓" else "Borde de página") {
            onDraftChange(draft.copy(pageBorder = !draft.pageBorder))
        }
        EditorPanelChip(if (draft.watermark.isBlank()) "Marca de agua" else "Marca: ${draft.watermark}") {
            val marks = listOf("", "BORRADOR", "CONFIDENCIAL", "COPIA", "URGENTE")
            val current = marks.indexOf(draft.watermark).takeIf { it >= 0 } ?: 0
            onDraftChange(draft.copy(watermark = marks[(current + 1) % marks.size]))
        }
        EditorPanelChip(if (draft.header.isBlank()) "Encabezado" else "Encabezado ✓") {
            onDraftChange(draft.copy(header = if (draft.header.isBlank()) draft.name.take(60) else ""))
        }
        EditorPanelChip(if (draft.footer.isBlank()) "Pie de página" else "Pie ✓") {
            onDraftChange(draft.copy(footer = if (draft.footer.isBlank()) "Gana Geo" else ""))
        }
        EditorPanelChip(if (processing) "Exportando…" else "Exportar PDF") { if (!processing) onExportPdf() }
    }
}

@Composable
private fun EditorExportPanel(
    format: EditorDocumentFormat,
    processing: Boolean,
    onExportPdf: () -> Unit,
    onExportNative: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF303030))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Guardar / exportar", color = Color.White, fontWeight = FontWeight.Bold)
        Text(
            when (format) {
                EditorDocumentFormat.WORD -> "Guarda DOCX editable o una copia PDF lista para compartir."
                EditorDocumentFormat.EXCEL -> "Guarda XLSX editable o una vista de la hoja en PDF."
                EditorDocumentFormat.POWERPOINT -> "Guarda PPTX editable o la presentación completa en PDF."
                else -> "Guarda una copia PDF con los ajustes actuales."
            },
            color = Color(0xFFBDBDBD),
            style = MaterialTheme.typography.bodySmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (format == EditorDocumentFormat.WORD || format == EditorDocumentFormat.EXCEL || format == EditorDocumentFormat.POWERPOINT) {
                Button(
                    onClick = onExportNative,
                    enabled = !processing,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A5A46), contentColor = Color.White)
                ) {
                    Text(if (processing) "Guardando…" else "Guardar ${format.shortLabel}", fontWeight = FontWeight.Bold)
                }
            }
            Button(
                onClick = onExportPdf,
                enabled = !processing,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
                Icon(Icons.Rounded.Save, contentDescription = null)
                Text(if (processing) "  Guardando…" else "  PDF", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun EditorPanelChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .height(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF454545))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun PdfWatermarkSecurityScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var modeIndex by rememberSaveable { mutableIntStateOf(0) }
    var watermark by rememberSaveable { mutableStateOf("GANA GEO") }
    var positionIndex by rememberSaveable { mutableIntStateOf(AdvancedFileUtils.WatermarkPosition.DIAGONAL.ordinal) }
    var opacity by rememberSaveable { mutableFloatStateOf(25f) }
    var fontSize by rememberSaveable { mutableFloatStateOf(42f) }
    var pagesText by rememberSaveable { mutableStateOf("") }
    var pageNumbers by rememberSaveable { mutableStateOf(false) }
    var firstPageNumber by rememberSaveable { mutableStateOf("1") }
    var currentPassword by rememberSaveable { mutableStateOf("") }
    var newPassword by rememberSaveable { mutableStateOf("") }
    var allowPrinting by rememberSaveable { mutableStateOf(true) }
    var allowCopy by rememberSaveable { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    val modes = listOf("Marca y numeración", "Agregar/cambiar contraseña", "Quitar contraseña")
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { input = it }
    val save = rememberLauncherForActivityResult(TrackedCreateDocument("application/pdf")) { output ->
        val source = input ?: return@rememberLauncherForActivityResult
        if (output == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                when (modeIndex) {
                    0 -> {
                        val count = ToolFileUtils.pdfPageCount(context, source)
                        val pages = PageSelectionParser.parse(pagesText, count).toSet()
                        AdvancedFileUtils.watermarkPdf(context, source, output, AdvancedFileUtils.PdfWatermarkOptions(
                            text = watermark,
                            opacityPercent = opacity.toInt(),
                            fontSize = fontSize,
                            position = AdvancedFileUtils.WatermarkPosition.entries[positionIndex],
                            addPageNumbers = pageNumbers,
                            firstPageNumber = firstPageNumber.toIntOrNull()?.coerceIn(1, 9999) ?: 1,
                            pages = pages
                        ), currentPassword)
                    }
                    1 -> AdvancedFileUtils.changePdfProtection(context, source, output, currentPassword, newPassword, allowPrinting, allowCopy)
                    else -> AdvancedFileUtils.changePdfProtection(context, source, output, currentPassword, null)
                }
            }.onSuccess { onMessage(successMessage("PDF guardado", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar el PDF") }
            processing = false
        }
    }
    AdvancedToolPage(tool, onBack) {
        AdvancedSection("Archivo") {
            OutlinedButton(onClick = { pick.launch(arrayOf("application/pdf")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Folder, null); Text(" Seleccionar PDF") }
            input?.let { Text(ToolFileUtils.displayName(context, it), color = NeonGreen) }
            SimpleDropdown("Operación", modes, modeIndex) { modeIndex = it }
        }
        if (modeIndex == 0 && input != null) AdvancedSection("Vista previa") {
            PdfWatermarkLivePreview(
                uri = input!!,
                watermark = watermark,
                position = AdvancedFileUtils.WatermarkPosition.entries[positionIndex],
                opacityPercent = opacity,
                fontSizePt = fontSize,
                pageNumbers = pageNumbers,
                firstPageNumber = firstPageNumber.toIntOrNull() ?: 1
            )
            Text(
                "La vista es aproximada; el PDF exportado conserva la página original y aplica la marca con la configuración elegida.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (modeIndex == 0) AdvancedSection("Marca de agua y páginas") {
            OutlinedTextField(watermark, { watermark = it.take(120) }, label = { Text("Texto de la marca") }, modifier = Modifier.fillMaxWidth())
            SimpleDropdown("Posición", AdvancedFileUtils.WatermarkPosition.entries.map { it.label }, positionIndex) { positionIndex = it }
            Text("Opacidad: ${opacity.toInt()} %"); Slider(opacity, { opacity = it }, valueRange = 5f..80f)
            Text("Tamaño: ${fontSize.toInt()} pt"); Slider(fontSize, { fontSize = it }, valueRange = 12f..90f)
            OutlinedTextField(pagesText, { pagesText = it.filter { c -> c.isDigit() || c in ", -" }.take(120) }, label = { Text("Páginas (vacío = todas)") }, placeholder = { Text("1-3, 5, 8") }, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Agregar número de página", modifier = Modifier.weight(1f)); Switch(pageNumbers, { pageNumbers = it }) }
            if (pageNumbers) OutlinedTextField(firstPageNumber, { firstPageNumber = it.filter(Char::isDigit).take(4) }, label = { Text("Comenzar numeración en") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(currentPassword, { currentPassword = it.take(60) }, label = { Text("Contraseña actual, si tiene") }, modifier = Modifier.fillMaxWidth())
        } else AdvancedSection("Contraseña y permisos") {
            OutlinedTextField(currentPassword, { currentPassword = it.take(60) }, label = { Text("Contraseña actual, si tiene") }, modifier = Modifier.fillMaxWidth())
            if (modeIndex == 1) {
                OutlinedTextField(newPassword, { newPassword = it.take(60) }, label = { Text("Nueva contraseña") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Permitir impresión", modifier = Modifier.weight(1f)); Switch(allowPrinting, { allowPrinting = it }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Permitir copiar contenido", modifier = Modifier.weight(1f)); Switch(allowCopy, { allowCopy = it }) }
            } else Text("Solo funciona cuando el usuario conoce la contraseña actual.", color = Gold)
        }
        if (processing) {
            item { AdvancedProgress("Procesando PDF", null) }
        }
        item {
            Button(onClick = {
                if (input == null) onMessage("Selecciona un PDF")
                else if (modeIndex == 1 && newPassword.length < 4) onMessage("La nueva contraseña debe tener al menos 4 caracteres")
                else launchPaidExport(viewModel, tool, onMessage) { save.launch("pdf_procesado_gana_geo.pdf") }
            }, enabled = input != null && !processing, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                Text("Guardar PDF · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PdfWatermarkLivePreview(
    uri: Uri,
    watermark: String,
    position: AdvancedFileUtils.WatermarkPosition,
    opacityPercent: Float,
    fontSizePt: Float,
    pageNumbers: Boolean,
    firstPageNumber: Int
) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, uri) {
        value = runCatching { ToolFileUtils.renderPdfPage(context, uri, 0, maxWidth = 760) }.getOrNull()
    }
    DisposableEffect(bitmap) {
        val current = bitmap
        onDispose { if (current != null && !current.isRecycled) current.recycle() }
    }
    Box(
        modifier = Modifier.fillMaxWidth().height(380.dp).background(Color(0xFF121212), RoundedCornerShape(14.dp)).padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        val page = bitmap
        if (page == null) {
            CircularProgressIndicator(color = NeonGreen)
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Image(page.asImageBitmap(), "Vista previa PDF", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                val watermarkSize = (fontSizePt * 0.42f).coerceIn(10f, 40f).sp
                val alpha = (opacityPercent / 100f).coerceIn(0.05f, 0.8f)
                when (position) {
                    AdvancedFileUtils.WatermarkPosition.REPEAT -> {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(vertical = 42.dp),
                            verticalArrangement = Arrangement.SpaceEvenly,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            repeat(4) {
                                Text(
                                    watermark.ifBlank { "Marca de agua" },
                                    color = Color.Black.copy(alpha = alpha),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = watermarkSize,
                                    modifier = Modifier.graphicsLayer { rotationZ = -28f }
                                )
                            }
                        }
                    }
                    else -> {
                        val alignment = when (position) {
                            AdvancedFileUtils.WatermarkPosition.TOP -> Alignment.TopCenter
                            AdvancedFileUtils.WatermarkPosition.BOTTOM -> Alignment.BottomCenter
                            else -> Alignment.Center
                        }
                        Text(
                            watermark.ifBlank { "Marca de agua" },
                            color = Color.Black.copy(alpha = alpha),
                            fontWeight = FontWeight.Bold,
                            fontSize = watermarkSize,
                            modifier = Modifier
                                .align(alignment)
                                .padding(22.dp)
                                .graphicsLayer { rotationZ = if (position == AdvancedFileUtils.WatermarkPosition.DIAGONAL) -32f else 0f }
                        )
                    }
                }
                if (pageNumbers) {
                    Text(
                        firstPageNumber.toString(),
                        color = Color.Black.copy(alpha = 0.78f),
                        fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AdvancedToolPage(tool: ToolId, onBack: () -> Unit, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, tool.subtitle, onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF401415)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = Gold)
                        Column(Modifier.weight(1f)) {
                            Text("Operación profesional", fontWeight = FontWeight.Bold)
                            Text(
                                "Costo: ${tool.creditCost} créditos. Solo se confirma cuando el archivo se crea correctamente.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            content()
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.AdvancedSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    item {
        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                content()
            }
        }
    }
}

@Composable
private fun AdvancedProgress(title: String, progress: Float?) {
    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (progress == null) LinearProgressIndicator(Modifier.fillMaxWidth()) else LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        }
    }
}
