package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Rearma la hoja: de la foto ya sin texto (y sin los logos y fotos grandes, que
 * ya se sacaron como piezas) separa todo lo que queda en:
 *
 * - FORMAS que se vuelven a dibujar limpias: barras y recuadros de color lisos
 *   (con esquinas redondeadas si las tienen) y líneas (separadores, subrayados,
 *   marcos y cuadrículas de tablas).
 * - PIEZAS (imagen recortada): íconos, viñetas, degradados, fotos chicas, todo lo
 *   que no es liso. Las que están sobre una barra se recortan con la barra
 *   transparente, para que queden encima.
 * - RESTOS de letras que el borrador no sacó del todo: se descartan (están
 *   pegados a un renglón y son de su tamaño).
 *
 * Con esto la hoja nueva es papel blanco + formas + piezas + texto real.
 * Trabaja sobre un arreglo de colores ARGB (sin Android) para poder probarlo.
 */
object ScanShapes {
    const val RECT = 0
    const val LINE = 1

    /** Forma limpia en píxeles de la foto: [left, top, right, bottom) y su color. */
    class Shape(
        val kind: Int,
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int,
        val color: Int,
        /** Radio de las esquinas (0 = rectas). */
        val radius: Int = 0
    )

    /** Pieza a recortar: caja en píxeles de la foto y el color de fondo que queda transparente. */
    class Piece(val left: Int, val top: Int, val right: Int, val bottom: Int, val background: Int)

    class Result(val shapes: List<Shape>, val pieces: List<Piece>)

    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun dist(a: Int, b: Int) = abs(red(a) - red(b)) + abs(green(a) - green(b)) + abs(blue(a) - blue(b))
    private fun rgb(r: Int, g: Int, b: Int): Int =
        -0x1000000 or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    /** Distancia de color para "no es papel". */
    private const val CONTENT = 45

    /** Distancia de color para "es el mismo color de la barra". */
    private const val SAME = 55

    private class Comp(val id: Int) {
        var left = Int.MAX_VALUE
        var top = Int.MAX_VALUE
        var right = -1
        var bottom = -1
        var count = 0
        var r = 0L
        var g = 0L
        var b = 0L
        val width get() = right - left
        val height get() = bottom - top
    }

    /**
     * [textBoxes]: renglones leídos [l, t, r, b) en píxeles de la foto (para reconocer
     * los restos de letras). [figures]: zonas que la IA marcó como imagen; lo que
     * cae adentro se junta en una sola pieza.
     */
    fun find(
        pixels: IntArray,
        width: Int,
        height: Int,
        paper: Int,
        textBoxes: List<IntArray>,
        figures: List<IntArray> = emptyList()
    ): Result {
        if (width < 20 || height < 20) return Result(emptyList(), emptyList())
        // Se trabaja achicado (rápido); el resultado vuelve al tamaño real.
        val factor = max(1, (max(width, height) + 899) / 900)
        val w = width / factor
        val h = height / factor
        if (w < 10 || h < 10) return Result(emptyList(), emptyList())
        val small = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var r = 0
            var g = 0
            var b = 0
            for (dy in 0 until factor) for (dx in 0 until factor) {
                val c = pixels[(y * factor + dy) * width + x * factor + dx]
                r += red(c)
                g += green(c)
                b += blue(c)
            }
            val n = factor * factor
            small[y * w + x] = rgb(r / n, g / n, b / n)
        }
        val content = BooleanArray(w * h) { dist(small[it], paper) > CONTENT }

        // Manchas unidas (8 vecinos).
        val label = IntArray(w * h) { -1 }
        val comps = ArrayList<Comp>()
        val queue = IntArray(w * h)
        for (start in 0 until w * h) {
            if (!content[start] || label[start] >= 0) continue
            val comp = Comp(comps.size)
            var head = 0
            var tail = 0
            queue[tail++] = start
            label[start] = comp.id
            while (head < tail) {
                val i = queue[head++]
                val x = i % w
                val y = i / w
                comp.left = min(comp.left, x)
                comp.right = max(comp.right, x + 1)
                comp.top = min(comp.top, y)
                comp.bottom = max(comp.bottom, y + 1)
                comp.count++
                val c = small[i]
                comp.r += red(c)
                comp.g += green(c)
                comp.b += blue(c)
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx !in 0 until w || ny !in 0 until h) continue
                    val n = ny * w + nx
                    if (content[n] && label[n] < 0) {
                        label[n] = comp.id
                        queue[tail++] = n
                    }
                }
            }
            comps += comp
        }

        val texts = textBoxes.map {
            intArrayOf(it[0] / factor, it[1] / factor, (it[2] + factor - 1) / factor, (it[3] + factor - 1) / factor)
        }

        fun real(left: Int, top: Int, right: Int, bottom: Int) = intArrayOf(
            (left * factor).coerceIn(0, width),
            (top * factor).coerceIn(0, height),
            (right * factor).coerceIn(0, width),
            (bottom * factor).coerceIn(0, height)
        )

        /** Resto de letra: casi todo dentro de un renglón (un poco agrandado) y de su alto. */
        fun residue(left: Int, top: Int, right: Int, bottom: Int): Boolean {
            val area = (right - left).toFloat() * (bottom - top)
            if (area <= 0f) return true
            for (t in texts) {
                val lineHeight = (t[3] - t[1]).coerceAtLeast(1)
                if (bottom - top > lineHeight * 1.4f) continue
                val pad = lineHeight * 0.3f
                val overlapX = min(right.toFloat(), t[2] + pad) - max(left.toFloat(), t[0] - pad)
                val overlapY = min(bottom.toFloat(), t[3] + pad) - max(top.toFloat(), t[1] - pad)
                if (overlapX <= 0f || overlapY <= 0f) continue
                if (overlapX * overlapY >= area * 0.6f) return true
            }
            return false
        }

        val shapes = ArrayList<Shape>()
        val pieces = ArrayList<IntArray>() // caja chica + fondo en el índice 4
        val used = BooleanArray(comps.size)

        // 1) Lo que la IA marcó como imagen: una sola pieza por zona.
        for (figure in figures) {
            val fl = figure[0] / factor
            val ft = figure[1] / factor
            val fr = (figure[2] + factor - 1) / factor
            val fb = (figure[3] + factor - 1) / factor
            var ul = Int.MAX_VALUE
            var ut = Int.MAX_VALUE
            var ur = -1
            var ub = -1
            for (comp in comps) {
                if (used[comp.id]) continue
                val cx = (comp.left + comp.right) / 2
                val cy = (comp.top + comp.bottom) / 2
                if (cx !in fl until fr || cy !in ft until fb) continue
                used[comp.id] = true
                ul = min(ul, comp.left)
                ut = min(ut, comp.top)
                ur = max(ur, comp.right)
                ub = max(ub, comp.bottom)
            }
            if (ur > ul && ub > ut) pieces += intArrayOf(ul, ut, ur, ub, paper)
        }

        // 2) Cada mancha: línea, barra lisa o pieza. Si una mancha mezcla una barra
        //    con otra cosa pegada (una foto encima, un panel gris), se separa por color.
        val bars = ArrayList<Pair<IntArray, Int>>() // caja chica de cada barra y su color
        val work = ArrayDeque<Pair<Comp, Int>>()
        for (comp in comps) if (!used[comp.id]) work.addLast(comp to 0)
        var nextId = comps.size
        while (work.isNotEmpty()) {
            val (comp, depth) = work.removeFirst()
            if (comp.count < 3) continue
            val bw = comp.width
            val bh = comp.height
            // Borde oscuro del escaneo pegado al canto de la hoja: no es parte del documento.
            val touchesEdge = comp.left <= 0 || comp.top <= 0 || comp.right >= w || comp.bottom >= h
            if (touchesEdge && (bw <= max(2, w / 60) && bh > h / 3 || bh <= max(2, h / 60) && bw > w / 3)) continue
            if (residue(comp.left, comp.top, comp.right, comp.bottom)) continue

            // ¿Está sobre una barra? Entonces el "fondo" es la barra, no el papel.
            val cx = (comp.left + comp.right) / 2
            val cy = (comp.top + comp.bottom) / 2
            val under = bars.lastOrNull { (box, _) -> cx in box[0] until box[2] && cy in box[1] until box[3] }
            val background = under?.second ?: paper

            val fill = comp.count.toFloat() / (bw * bh)
            if (fill < 0.5f || min(bw, bh) <= 3) {
                val lines = lineStructure(comp, label, w, bw, bh)
                if (lines != null) {
                    for (line in lines) refineLine(line, pixels, width, height, background, factor)?.let { shapes += it }
                    continue
                }
            }
            val rect = solidRect(comp, small, label, w, factor, pixels, width, height)
            if (rect != null) {
                shapes += rect
                bars += intArrayOf(comp.left, comp.top, comp.right, comp.bottom) to rect.color
                // Lo que hay encima de la barra (íconos, dibujos): piezas con la barra transparente.
                innerPieces(comp, small, w, rect.color, paper) { l, t, r, b ->
                    if (!residue(l, t, r, b)) pieces += intArrayOf(l, t, r, b, rect.color)
                }
                continue
            }
            if (depth == 0) {
                val split = splitByColor(comp, small, label, w, factor, pixels, width, height, nextId)
                if (split != null) {
                    for ((box, shape) in split.first) {
                        shapes += shape
                        bars += box to shape.color
                    }
                    for (rest in split.second) work.addLast(rest to 1)
                    nextId += split.second.size + split.first.size
                    continue
                }
            }
            // Pieza: si está sobre una barra, la barra queda transparente.
            pieces += intArrayOf(comp.left, comp.top, comp.right, comp.bottom, background)
        }

        // Partes de un mismo ícono que se tocan: una sola pieza.
        var merged = true
        while (merged) {
            merged = false
            loop@ for (i in pieces.indices) for (j in i + 1 until pieces.size) {
                val a = pieces[i]
                val b = pieces[j]
                if (a[4] != b[4]) continue
                if (a[0] <= b[2] + 1 && b[0] <= a[2] + 1 && a[1] <= b[3] + 1 && b[1] <= a[3] + 1) {
                    pieces[i] = intArrayOf(min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]), a[4])
                    pieces.removeAt(j)
                    merged = true
                    break@loop
                }
            }
        }

        // Borde suave de una barra (la mezcla de la barra con el papel): no es una línea.
        val rects = shapes.filter { it.kind == RECT }
        val tolerance = 2 * factor + 1
        shapes.removeAll { line ->
            if (line.kind != LINE) return@removeAll false
            val vertical = line.bottom - line.top > line.right - line.left
            rects.any { rect ->
                val touching = if (vertical) {
                    (abs(line.left - rect.right) <= tolerance || abs(line.right - rect.left) <= tolerance) &&
                        min(line.bottom, rect.bottom) - max(line.top, rect.top) >= (line.bottom - line.top) * 0.8f
                } else {
                    (abs(line.top - rect.bottom) <= tolerance || abs(line.bottom - rect.top) <= tolerance) &&
                        min(line.right, rect.right) - max(line.left, rect.left) >= (line.right - line.left) * 0.8f
                }
                touching && dist(line.color, paper) + dist(line.color, rect.color) <= dist(paper, rect.color) * 1.3f
            }
        }

        val result = pieces.map { box ->
            // Un poco de margen para no cortar el borde suave.
            val r = real(box[0] - 1, box[1] - 1, box[2] + 1, box[3] + 1)
            Piece(r[0], r[1], r[2], r[3], box[4])
        }.filter { it.right - it.left >= 2 && it.bottom - it.top >= 2 }
        return Result(shapes, result)
    }

    /**
     * Mancha que mezcla una barra lisa con otras cosas pegadas: se busca su color
     * principal; cada zona grande y llena de ese color es una barra, y lo demás
     * se separa en manchas nuevas (que se vuelven a revisar).
     * Devuelve (barras con su caja chica, manchas que sobran) o null si no hay barra.
     */
    private fun splitByColor(
        comp: Comp,
        small: IntArray,
        label: IntArray,
        w: Int,
        factor: Int,
        pixels: IntArray,
        width: Int,
        height: Int,
        firstId: Int
    ): Pair<List<Pair<IntArray, Shape>>, List<Comp>>? {
        if (comp.count < 60) return null
        // Color más repetido (por grupos de colores parecidos).
        val buckets = HashMap<Int, Int>()
        for (y in comp.top until comp.bottom) for (x in comp.left until comp.right) {
            val i = y * w + x
            if (label[i] != comp.id) continue
            val c = small[i]
            val key = ((red(c) shr 4) shl 8) or ((green(c) shr 4) shl 4) or (blue(c) shr 4)
            buckets[key] = (buckets[key] ?: 0) + 1
        }
        val top = buckets.maxByOrNull { it.value } ?: return null
        if (top.value < max(30, comp.count / 5)) return null
        val key = top.key
        var dominant = rgb(((key shr 8) shl 4) + 8, (((key shr 4) and 15) shl 4) + 8, ((key and 15) shl 4) + 8)
        run {
            var r = 0L
            var g = 0L
            var b = 0L
            var n = 0
            for (y in comp.top until comp.bottom) for (x in comp.left until comp.right) {
                val i = y * w + x
                if (label[i] != comp.id) continue
                val c = small[i]
                if (dist(c, dominant) < SAME) {
                    r += red(c)
                    g += green(c)
                    b += blue(c)
                    n++
                }
            }
            if (n > 0) dominant = rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
        }
        // Zonas unidas del color principal.
        var id = firstId
        val bars = ArrayList<Pair<IntArray, Shape>>()
        val queue = IntArray(comp.width * comp.height)
        val seen = HashSet<Int>()
        for (y0 in comp.top until comp.bottom) for (x0 in comp.left until comp.right) {
            val start = y0 * w + x0
            if (label[start] != comp.id || start in seen || dist(small[start], dominant) >= SAME) continue
            val zone = Comp(id++)
            var head = 0
            var tail = 0
            queue[tail++] = start
            seen += start
            val members = ArrayList<Int>()
            while (head < tail) {
                val i = queue[head++]
                members += i
                val x = i % w
                val y = i / w
                zone.left = min(zone.left, x)
                zone.right = max(zone.right, x + 1)
                zone.top = min(zone.top, y)
                zone.bottom = max(zone.bottom, y + 1)
                zone.count++
                val c = small[i]
                zone.r += red(c)
                zone.g += green(c)
                zone.b += blue(c)
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx !in comp.left until comp.right || ny !in comp.top until comp.bottom) continue
                    val n = ny * w + nx
                    if (label[n] == comp.id && n !in seen && dist(small[n], dominant) < SAME) {
                        seen += n
                        queue[tail++] = n
                    }
                }
            }
            if (zone.count < 30 || zone.width < 4 || zone.height < 4) continue
            if (zone.count < zone.width * zone.height * 0.8f) continue
            // Se prueba como barra con su propia etiqueta.
            for (i in members) label[i] = zone.id
            val shape = solidRect(zone, small, label, w, factor, pixels, width, height)
            if (shape == null) {
                for (i in members) label[i] = comp.id
                continue
            }
            bars += intArrayOf(zone.left, zone.top, zone.right, zone.bottom) to shape
        }
        if (bars.isEmpty()) return null
        // Lo que sobra (fuera de las barras o encima de ellas): manchas nuevas.
        val rest = ArrayList<Comp>()
        for (y0 in comp.top until comp.bottom) for (x0 in comp.left until comp.right) {
            val start = y0 * w + x0
            if (label[start] != comp.id) continue
            val piece = Comp(id++)
            var head = 0
            var tail = 0
            queue[tail++] = start
            label[start] = piece.id
            while (head < tail) {
                val i = queue[head++]
                val x = i % w
                val y = i / w
                piece.left = min(piece.left, x)
                piece.right = max(piece.right, x + 1)
                piece.top = min(piece.top, y)
                piece.bottom = max(piece.bottom, y + 1)
                piece.count++
                val c = small[i]
                piece.r += red(c)
                piece.g += green(c)
                piece.b += blue(c)
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx !in comp.left until comp.right || ny !in comp.top until comp.bottom) continue
                    val n = ny * w + nx
                    if (label[n] == comp.id) {
                        label[n] = piece.id
                        queue[tail++] = n
                    }
                }
            }
            rest += piece
        }
        return bars to rest
    }

    /**
     * Si la mancha está hecha solo de trazos rectos (renglones o columnas casi
     * llenos), devuelve esas líneas (caja chica). Sirve para separadores,
     * subrayados, marcos y cuadrículas de tablas.
     */
    private fun lineStructure(comp: Comp, label: IntArray, w: Int, bw: Int, bh: Int): List<IntArray>? {
        val rowCount = IntArray(bh)
        val colCount = IntArray(bw)
        for (y in comp.top until comp.bottom) for (x in comp.left until comp.right) {
            if (label[y * w + x] != comp.id) continue
            rowCount[y - comp.top]++
            colCount[x - comp.left]++
        }
        val rowLine = BooleanArray(bh) { bw >= 6 && rowCount[it] >= max(6f, bw * 0.6f) }
        val colLine = BooleanArray(bw) { bh >= 6 && colCount[it] >= max(6f, bh * 0.6f) }
        if (rowLine.none { it } && colLine.none { it }) return null
        var covered = 0
        for (y in comp.top until comp.bottom) for (x in comp.left until comp.right) {
            if (label[y * w + x] != comp.id) continue
            if (rowLine[y - comp.top] || colLine[x - comp.left]) covered++
        }
        if (covered < comp.count * 0.9f) return null
        // Solo trazos finos: un bloque lleno (una foto) no es una línea.
        val thick = 4
        var run = 0
        for (y in 0 until bh) {
            run = if (rowLine[y]) run + 1 else 0
            if (run > thick) return null
        }
        run = 0
        for (x in 0 until bw) {
            run = if (colLine[x]) run + 1 else 0
            if (run > thick) return null
        }
        val lines = ArrayList<IntArray>()
        var y = 0
        while (y < bh) {
            if (!rowLine[y]) {
                y++
                continue
            }
            val start = y
            while (y < bh && rowLine[y]) y++
            var left = Int.MAX_VALUE
            var right = -1
            for (yy in start until y) for (x in comp.left until comp.right) {
                if (label[(comp.top + yy) * w + x] == comp.id) {
                    left = min(left, x)
                    right = max(right, x + 1)
                }
            }
            if (right > left) lines += intArrayOf(left, comp.top + start, right, comp.top + y)
        }
        var x = 0
        while (x < bw) {
            if (!colLine[x]) {
                x++
                continue
            }
            val start = x
            while (x < bw && colLine[x]) x++
            var top = Int.MAX_VALUE
            var bottom = -1
            for (xx in start until x) for (yy in comp.top until comp.bottom) {
                if (label[yy * w + comp.left + xx] == comp.id) {
                    top = min(top, yy)
                    bottom = max(bottom, yy + 1)
                }
            }
            if (bottom > top) lines += intArrayOf(comp.left + start, top, comp.left + x, bottom)
        }
        return lines.takeIf { it.isNotEmpty() }
    }

    /** Línea a tamaño real: grosor y color exactos medidos en la foto ([paper] = lo que tiene detrás). */
    private fun refineLine(box: IntArray, pixels: IntArray, width: Int, height: Int, paper: Int, factor: Int): Shape? {
        val left = (box[0] * factor).coerceIn(0, width - 1)
        val right = (box[2] * factor).coerceIn(left + 1, width)
        val top = ((box[1] - 1) * factor).coerceIn(0, height - 1)
        val bottom = ((box[3] + 1) * factor).coerceIn(top + 1, height)
        val horizontal = right - left >= bottom - top
        var r = 0L
        var g = 0L
        var b = 0L
        var n = 0
        if (horizontal) {
            var first = -1
            var last = -1
            val step = max(1, (right - left) / 200)
            for (y in top until bottom) {
                var on = 0
                var total = 0
                for (x in left until right step step) {
                    total++
                    val c = pixels[y * width + x]
                    if (dist(c, paper) > CONTENT) {
                        on++
                        r += red(c)
                        g += green(c)
                        b += blue(c)
                        n++
                    }
                }
                if (on * 2 >= total) {
                    if (first < 0) first = y
                    last = y
                }
            }
            if (first < 0 || n == 0) return null
            return Shape(LINE, left, first, right, last + 1, rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt()))
        }
        val vTop = (box[1] * factor).coerceIn(0, height - 1)
        val vBottom = (box[3] * factor).coerceIn(vTop + 1, height)
        val vLeft = ((box[0] - 1) * factor).coerceIn(0, width - 1)
        val vRight = ((box[2] + 1) * factor).coerceIn(vLeft + 1, width)
        var first = -1
        var last = -1
        val step = max(1, (vBottom - vTop) / 200)
        for (x in vLeft until vRight) {
            var on = 0
            var total = 0
            for (y in vTop until vBottom step step) {
                total++
                val c = pixels[y * width + x]
                if (dist(c, paper) > CONTENT) {
                    on++
                    r += red(c)
                    g += green(c)
                    b += blue(c)
                    n++
                }
            }
            if (on * 2 >= total) {
                if (first < 0) first = x
                last = x
            }
        }
        if (first < 0 || n == 0) return null
        return Shape(LINE, first, vTop, last + 1, vBottom, rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt()))
    }

    /**
     * Barra o recuadro lleno de un solo color: la mayor parte de su caja (y casi
     * todo su borde) es de ese color. Las esquinas redondeadas se miden.
     */
    private fun solidRect(
        comp: Comp,
        small: IntArray,
        label: IntArray,
        w: Int,
        factor: Int,
        pixels: IntArray,
        width: Int,
        height: Int
    ): Shape? {
        val bw = comp.width
        val bh = comp.height
        if (bw < 4 || bh < 4 || comp.count < 30) return null
        var mean = rgb((comp.r / comp.count).toInt(), (comp.g / comp.count).toInt(), (comp.b / comp.count).toInt())
        // Color dominante (sin lo que tiene encima).
        run {
            var r = 0L
            var g = 0L
            var b = 0L
            var n = 0
            for (y in comp.top until comp.bottom) for (x in comp.left until comp.right) {
                val i = y * w + x
                if (label[i] != comp.id) continue
                val c = small[i]
                if (dist(c, mean) < 80) {
                    r += red(c)
                    g += green(c)
                    b += blue(c)
                    n++
                }
            }
            if (n > 0) mean = rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
        }
        var same = 0
        for (y in comp.top until comp.bottom) for (x in comp.left until comp.right) {
            if (dist(small[y * w + x], mean) < SAME) same++
        }
        if (same < bw * bh * 0.55f) return null
        // Una foto oscura puede parecer de un solo color: las fotos tienen textura.
        var busy = 0
        var checked = 0
        for (y in comp.top until comp.bottom - 1) for (x in comp.left until comp.right - 1) {
            val i = y * w + x
            if (dist(small[i], mean) >= SAME) continue
            checked++
            if (dist(small[i], small[i + 1]) + dist(small[i], small[i + w]) > 36) busy++
        }
        if (checked > 0 && busy > checked * 0.08f) return null
        // Borde (sin las esquinas, que pueden ser redondas).
        val skip = max(1, (min(bw, bh) * 0.15f).toInt())
        var edge = 0
        var edgeSame = 0
        for (x in comp.left + skip until comp.right - skip) {
            edge += 2
            if (dist(small[comp.top * w + x], mean) < SAME) edgeSame++
            if (dist(small[(comp.bottom - 1) * w + x], mean) < SAME) edgeSame++
        }
        for (y in comp.top + skip until comp.bottom - skip) {
            edge += 2
            if (dist(small[y * w + comp.left], mean) < SAME) edgeSame++
            if (dist(small[y * w + comp.right - 1], mean) < SAME) edgeSame++
        }
        if (edge == 0 || edgeSame < edge * 0.8f) return null

        // Esquinas: se busca en diagonal dónde empieza el color (en las 4; vale la más chica,
        // así una esquina tapada por otra cosa no inventa curvas).
        val maxInset = min(bw, bh) / 2
        fun cornerInset(x0: Int, y0: Int, sx: Int, sy: Int): Int {
            var i = 0
            while (i < maxInset && dist(small[(y0 + sy * i) * w + x0 + sx * i], mean) >= SAME) i++
            return i
        }
        val inset = minOf(
            minOf(cornerInset(comp.left, comp.top, 1, 1), cornerInset(comp.right - 1, comp.top, -1, 1)),
            minOf(cornerInset(comp.left, comp.bottom - 1, 1, -1), cornerInset(comp.right - 1, comp.bottom - 1, -1, -1))
        )
        val radius = if (inset <= 0) 0 else ((inset + 0.5f) / 0.293f * factor).roundToInt()
            .coerceAtMost(min(bw, bh) * factor / 2)

        val left = (comp.left * factor).coerceIn(0, width)
        val top = (comp.top * factor).coerceIn(0, height)
        val right = (comp.right * factor).coerceIn(0, width)
        val bottom = (comp.bottom * factor).coerceIn(0, height)
        // Color exacto en la foto real.
        var r = 0L
        var g = 0L
        var b = 0L
        var n = 0
        val step = max(1, max(right - left, bottom - top) / 120)
        for (y in top until bottom step step) for (x in left until right step step) {
            val c = pixels[y * width + x]
            if (dist(c, mean) < 60) {
                r += red(c)
                g += green(c)
                b += blue(c)
                n++
            }
        }
        val color = if (n > 0) rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt()) else mean
        return Shape(RECT, left, top, right, bottom, color, radius)
    }

    /** Dibujos sobre una barra (lo que no es del color de la barra ni del papel). */
    private inline fun innerPieces(
        comp: Comp,
        small: IntArray,
        w: Int,
        barColor: Int,
        paper: Int,
        found: (Int, Int, Int, Int) -> Unit
    ) {
        val bw = comp.width
        val bh = comp.height
        val mask = BooleanArray(bw * bh)
        for (y in 0 until bh) for (x in 0 until bw) {
            val c = small[(comp.top + y) * w + comp.left + x]
            mask[y * bw + x] = dist(c, barColor) >= 60
        }
        val seen = BooleanArray(bw * bh)
        val queue = IntArray(bw * bh)
        for (start in 0 until bw * bh) {
            if (!mask[start] || seen[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            seen[start] = true
            var left = bw
            var top = bh
            var right = 0
            var bottom = 0
            var count = 0
            var paperLike = 0
            while (head < tail) {
                val i = queue[head++]
                val x = i % bw
                val y = i / bw
                left = min(left, x)
                right = max(right, x + 1)
                top = min(top, y)
                bottom = max(bottom, y + 1)
                count++
                if (dist(small[(comp.top + y) * w + comp.left + x], paper) <= CONTENT) paperLike++
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx !in 0 until bw || ny !in 0 until bh) continue
                    val n = ny * bw + nx
                    if (mask[n] && !seen[n]) {
                        seen[n] = true
                        queue[tail++] = n
                    }
                }
            }
            if (count < 3) continue
            // Rincones de papel (esquinas redondas) o huecos: no son dibujo.
            val touchesBorder = left == 0 || top == 0 || right == bw || bottom == bh
            if (touchesBorder && paperLike * 10 >= count * 7) continue
            found(comp.left + left, comp.top + top, comp.left + right, comp.top + bottom)
        }
    }
}
