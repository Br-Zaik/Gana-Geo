package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Barras y recuadros de color que tienen texto encima (títulos sobre una franja
 * azul, etiquetas, botones). En vez de borrar la letra de la foto (deja manchas),
 * se mide la figura y se dibuja de nuevo limpia, como en Word: rectángulo, con
 * esquinas redondas, con una punta inclinada, de un color o con degradado. La
 * letra va encima como texto. Lo que no es barra ni letra (un ícono al inicio)
 * se recorta aparte.
 *
 * Trabaja con colores ARGB en una ventana de la foto (sin Android) para probarlo.
 */
object ScanBars {
    class Bar(
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
        /** Cuánto entra cada esquina desde la caja: arriba-izq, arriba-der, abajo-der, abajo-izq. */
        val insets: FloatArray,
        val radius: Float,
        val color: Int,
        /** Color del otro extremo si tiene degradado (izquierda→derecha, o arriba→abajo si [vertical]). */
        val color2: Int?,
        val vertical: Boolean,
        /** Íconos sobre la barra: [izq, arriba, der, abajo). */
        val icons: List<IntArray>
    ) {
        val slanted: Boolean get() = insets.any { it > 0.5f }

        /** Color de la barra en un punto (sigue el degradado). */
        fun colorAt(x: Float, y: Float): Int {
            val end = color2 ?: return color
            val t = if (vertical) (y - top) / (bottom - top).coerceAtLeast(1f) else (x - left) / (right - left).coerceAtLeast(1f)
            return mix(color, end, t.coerceIn(0f, 1f))
        }

        /** Borde izquierdo y derecho de la barra a la altura [y]. */
        fun span(y: Float): Pair<Float, Float> {
            val t = ((y - top) / (bottom - top).coerceAtLeast(1f)).coerceIn(0f, 1f)
            val l = left + insets[0] * (1 - t) + insets[3] * t
            val r = right - insets[1] * (1 - t) - insets[2] * t
            return l to r
        }

        fun contains(x: Float, y: Float): Boolean {
            if (y < top || y >= bottom) return false
            val (l, r) = span(y)
            return x >= l && x < r
        }

        /** La misma barra corrida (para pasarla a la foto entera). */
        fun shifted(dx: Float, dy: Float, scale: Float = 1f): Bar = Bar(
            left * scale + dx, top * scale + dy, right * scale + dx, bottom * scale + dy,
            FloatArray(4) { insets[it] * scale }, radius * scale, color, color2, vertical,
            icons.map { intArrayOf((it[0] * scale + dx).toInt(), (it[1] * scale + dy).toInt(), (it[2] * scale + dx).roundToInt(), (it[3] * scale + dy).roundToInt()) }
        )
    }

    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun rgb(r: Int, g: Int, b: Int) = -0x1000000 or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
    fun dist(a: Int, b: Int) = abs(red(a) - red(b)) + abs(green(a) - green(b)) + abs(blue(a) - blue(b))

    fun mix(a: Int, b: Int, t: Float): Int = rgb(
        (red(a) + (red(b) - red(a)) * t).roundToInt(),
        (green(a) + (green(b) - green(a)) * t).roundToInt(),
        (blue(a) + (blue(b) - blue(a)) * t).roundToInt()
    )

    /**
     * Busca la barra que está debajo del renglón [text] = [izq, arriba, der, abajo)
     * dentro de la ventana [pixels] ([width] × [height]). [words]: cajas de las
     * palabras leídas; [ink]: color de la letra; [paper]: color del papel. El color de
     * la barra se mide aquí (lo más común bajo la letra que no es papel ni tinta). Devuelve null si no hay barra
     * (fondo = papel, foto con textura, o algo más grande que una franja).
     */
    fun find(
        pixels: IntArray,
        width: Int,
        height: Int,
        paper: Int,
        text: IntArray,
        words: List<IntArray>,
        ink: Int,
        /** Renglones leídos cerca (las letras están ahí, aunque una parte quede fuera de la barra). */
        letters: List<IntArray> = listOf(text)
    ): Bar? {
        if (width < 4 || height < 4 || pixels.size < width * height) return null
        // Fondo de verdad bajo la letra: el color más común que no es papel ni tinta.
        val background = dominant(pixels, width, height, text, paper, ink) ?: return null
        if (dist(background, paper) < 50) return null
        val textHeight = (text[3] - text[1]).coerceAtLeast(4)

        // 1) La barra: lo que se parece al fondo y está pegado (sigue un degradado suave).
        val region = BooleanArray(width * height)
        val queue = IntArray(width * height)
        var head = 0
        var tail = 0
        var seeds = 0
        var seedArea = 0
        for (y in text[1].coerceAtLeast(0) until text[3].coerceAtMost(height)) {
            for (x in text[0].coerceAtLeast(0) until text[2].coerceAtMost(width)) {
                seedArea++
                val i = y * width + x
                if (dist(pixels[i], background) < 45 && dist(pixels[i], paper) > 40) {
                    region[i] = true
                    queue[tail++] = i
                    seeds++
                }
            }
        }
        if (seedArea == 0 || seeds < seedArea * 0.15f) return null
        while (head < tail) {
            val i = queue[head++]
            val c = pixels[i]
            val x = i % width
            val y = i / width
            for (k in 0 until 4) {
                val nx = when (k) { 0 -> x - 1; 1 -> x + 1; else -> x }
                val ny = when (k) { 2 -> y - 1; 3 -> y + 1; else -> y }
                if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue
                val j = ny * width + nx
                if (region[j]) continue
                val q = pixels[j]
                if (dist(q, c) > 24) continue
                if (dist(q, paper) <= 40) continue
                val toBackground = dist(q, background)
                if (toBackground > 200 || toBackground >= dist(q, ink)) continue
                region[j] = true
                queue[tail++] = j
            }
        }
        // 2) Bordes de cada fila y su color.
        val rowMin = IntArray(height) { -1 }
        val rowMax = IntArray(height) { -1 }
        val rowColor = IntArray(height)
        for (y in 0 until height) {
            val row = y * width
            var r = 0L
            var g = 0L
            var b = 0L
            var n = 0
            for (x in 0 until width) {
                if (!region[row + x]) continue
                if (rowMin[y] < 0) rowMin[y] = x
                rowMax[y] = x
                val c = pixels[row + x]
                r += red(c); g += green(c); b += blue(c); n++
            }
            if (n > 0) rowColor[y] = rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
        }
        // La franja: desde el renglón hacia arriba y abajo mientras los bordes y el color
        // sigan parejos. Así no se mete en una foto o un panel pegado a la barra.
        val center = ((text[1] + text[3]) / 2).coerceIn(0, height - 1)
        var yc = -1
        for (d in 0..textHeight / 2) {
            if (center - d >= 0 && rowMin[center - d] >= 0) { yc = center - d; break }
            if (center + d < height && rowMin[center + d] >= 0) { yc = center + d; break }
        }
        if (yc < 0) return null
        val stepTol = max(3f, textHeight * 0.6f)
        fun continues(y: Int, prev: Int): Boolean {
            if (y < 0 || y >= height || rowMin[y] < 0) return false
            if (abs(rowMin[y] - rowMin[prev]) > stepTol || abs(rowMax[y] - rowMax[prev]) > stepTol) return false
            // Tolera el ruido de la foto (filas que alternan un poco de tono).
            return dist(rowColor[y], rowColor[prev]) <= 48
        }
        var ry0 = yc
        while (ry0 > 0 && yc - ry0 < textHeight * 1.7f && continues(ry0 - 1, ry0)) ry0--
        var ry1 = yc
        while (ry1 < height - 1 && ry1 - yc < textHeight * 1.7f && continues(ry1 + 1, ry1)) ry1++
        // El borde de la barra (filas con el ruido de la foto): se suma si los lados siguen.
        var bandR = 0L
        var bandG = 0L
        var bandB = 0L
        for (y in ry0..ry1) { bandR += red(rowColor[y]); bandG += green(rowColor[y]); bandB += blue(rowColor[y]) }
        val count = (ry1 - ry0 + 1)
        val bandColor = rgb((bandR / count).toInt(), (bandG / count).toInt(), (bandB / count).toInt())
        fun edgeRow(y: Int, prev: Int): Boolean =
            y in 0 until height && rowMin[y] >= 0 &&
                abs(rowMin[y] - rowMin[prev]) <= stepTol && abs(rowMax[y] - rowMax[prev]) <= stepTol &&
                dist(rowColor[y], bandColor) <= 110 && dist(rowColor[y], paper) > 90
        val edgeLimit = max(2, textHeight / 4)
        repeat(edgeLimit) { if (edgeRow(ry0 - 1, ry0)) ry0-- }
        repeat(edgeLimit) { if (edgeRow(ry1 + 1, ry1)) ry1++ }
        // Lo de fuera de la franja ya no es barra.
        for (y in 0 until height) {
            if (y in ry0..ry1) continue
            if (rowMin[y] < 0) continue
            val row = y * width
            for (x in rowMin[y]..rowMax[y]) region[row + x] = false
            rowMin[y] = -1
            rowMax[y] = -1
        }
        var rx0 = width
        var rx1 = -1
        for (y in ry0..ry1) {
            if (rowMin[y] < 0) continue
            rx0 = min(rx0, rowMin[y]); rx1 = max(rx1, rowMax[y])
        }
        if (rx1 < 0) return null
        // La franja sigue más allá de lo que se buscó: es un panel grande o una foto.
        if (yc - ry0 >= textHeight * 1.7f || ry1 - yc >= textHeight * 1.7f) return null
        if (ry0 <= 0 || ry1 >= height - 1) return null
        // Una franja es baja y ancha (un círculo con un ícono no es barra).
        if (ry1 + 1 - ry0 > textHeight * 3.2f) return null
        if (rx1 + 1 - rx0 < (ry1 + 1 - ry0) * 2f) return null
        // El texto tiene que quedar adentro.
        // (Puede salirse un poco por las puntas: ahí suele estar el ícono.)
        val slack = textHeight * 2.5f
        if (text[0] < rx0 - slack || text[2] > rx1 + 1 + slack) return null
        if ((text[1] + text[3]) / 2 !in ry0..ry1) return null
        val maxWidth = (ry0..ry1).maxOf { if (rowMin[it] >= 0) rowMax[it] - rowMin[it] + 1 else 0 }
        val core = (ry0..ry1).filter { rowMin[it] >= 0 && rowMax[it] - rowMin[it] + 1 >= maxWidth * 0.6f }
        if (core.size < 3) return null
        // Lleno: las filas de la barra están casi enteras (las letras son huecos pequeños).
        var inside = 0
        var filled = 0
        for (y in core) for (x in rowMin[y]..rowMax[y]) {
            inside++
            if (region[y * width + x]) filled++
        }
        if (filled < inside * 0.45f) return null

        // 3) Bordes izquierdo y derecho: rectos o inclinados (robusto a un ícono encima).
        fun edge(values: (Int) -> Int): Pair<Float, Float> {
            val ys = core
            val half = ys.size / 2
            val upper = ys.subList(0, max(1, half))
            val lower = ys.subList(half, ys.size)
            fun med(list: List<Int>) = list.map(values).sorted()[list.size / 2].toFloat()
            fun medY(list: List<Int>) = list.sorted()[list.size / 2].toFloat()
            val yU = medY(upper)
            val yL = medY(lower)
            val slope = if (yL - yU >= 2f) (med(lower) - med(upper)) / (yL - yU) else 0f
            // Recta que pasa por la mediana: x = a + slope * y.
            val a = ys.map { values(it) - slope * it }.sorted()[ys.size / 2]
            return a to slope
        }
        val top = ry0.toFloat()
        val bottom = (ry1 + 1).toFloat()
        val barHeight = bottom - top
        var (leftA, leftSlope) = edge { rowMin[it] }
        var (rightA, rightSlope) = edge { rowMax[it] + 1 }
        val straight = max(2.5f, barHeight * 0.15f)
        if (abs(leftSlope * barHeight) < straight) { leftA = core.map { rowMin[it] }.sorted()[core.size / 2].toFloat(); leftSlope = 0f }
        if (abs(rightSlope * barHeight) < straight) { rightA = core.map { rowMax[it] + 1 }.sorted()[core.size / 2].toFloat(); rightSlope = 0f }
        val xTL = leftA + leftSlope * top
        val xBL = leftA + leftSlope * bottom
        val xTR = rightA + rightSlope * top
        val xBR = rightA + rightSlope * bottom
        val left = min(xTL, xBL)
        val right = max(xTR, xBR)
        if (right - left < textHeight) return null
        val insets = floatArrayOf(xTL - left, right - xTR, right - xBR, xBL - left)

        // 4) Esquinas redondas (solo si los lados son rectos).
        var radius = 0f
        if (insets.all { it < 0.5f }) {
            fun corner(rows: IntProgression, side: (Int) -> Int, edgeX: Float, inward: Int): Int {
                var count = 0
                for (y in rows) {
                    val x = side(y)
                    if (x < 0) { count++; continue }
                    if ((x - edgeX) * inward > 1f) count++ else break
                }
                return count
            }
            val tl = corner(ry0..ry1, { rowMin[it] }, left, 1)
            val bl = corner(ry1 downTo ry0, { rowMin[it] }, left, 1)
            val tr = corner(ry0..ry1, { if (rowMax[it] < 0) -1 else rowMax[it] + 1 }, right, -1)
            val br = corner(ry1 downTo ry0, { if (rowMax[it] < 0) -1 else rowMax[it] + 1 }, right, -1)
            val r = minOf(minOf(tl, bl), minOf(tr, br))
            if (r >= 2) radius = min(r.toFloat() * 1.1f, barHeight / 2f)
        }

        // 5) Color: uno solo o degradado (izq→der o arriba→abajo). Con textura no es barra.
        val step = max(1, sqrt((filled / 2500f).toDouble()).toInt())
        val xs = ArrayList<Float>()
        val ys = ArrayList<Float>()
        val cs = ArrayList<Int>()
        for (y in ry0..ry1 step step) {
            val row = y * width
            var x = max(0, rowMin[y].coerceAtLeast(0))
            while (x <= rowMax[y]) {
                if (region[row + x]) {
                    xs += (x - left) / (right - left)
                    ys += (y - top) / barHeight
                    cs += pixels[row + x]
                }
                x += step
            }
        }
        if (cs.size < 20) return null
        class Fit(val a: FloatArray, val b: FloatArray, val error: Float)
        fun fit(us: List<Float>): Fit {
            val a = FloatArray(3)
            val b = FloatArray(3)
            var error = 0f
            val n = us.size
            val mu = us.average().toFloat()
            var suu = 0f
            for (u in us) suu += (u - mu) * (u - mu)
            for (ch in 0 until 3) {
                val v = cs.map { c -> when (ch) { 0 -> red(c); 1 -> green(c); else -> blue(c) }.toFloat() }
                val mv = v.average().toFloat()
                var suv = 0f
                for (k in 0 until n) suv += (us[k] - mu) * (v[k] - mv)
                val slope = if (suu > 1e-3f) suv / suu else 0f
                b[ch] = slope
                a[ch] = mv - slope * mu
                for (k in 0 until n) {
                    val d = v[k] - (a[ch] + slope * us[k])
                    error += d * d
                }
            }
            return Fit(a, b, error / (n * 3))
        }
        val flat = fit(List(cs.size) { 0f })
        val alongX = fit(xs)
        val alongY = fit(ys)
        val best = if (alongX.error <= alongY.error) alongX else alongY
        val vertical = best === alongY
        val amplitude = best.b.maxOf { abs(it) }
        val gradient = best.error < flat.error * 0.7f && amplitude >= 12f
        val chosen = if (gradient) best else flat
        if (sqrt(chosen.error.toDouble()) > 16.0) return null
        val color = rgb(chosen.a[0].roundToInt(), chosen.a[1].roundToInt(), chosen.a[2].roundToInt())
        val color2 = if (gradient) {
            rgb((chosen.a[0] + chosen.b[0]).roundToInt(), (chosen.a[1] + chosen.b[1]).roundToInt(), (chosen.a[2] + chosen.b[2]).roundToInt())
        } else {
            null
        }

        val bar = Bar(left, top, right, bottom, insets, radius, color, color2, vertical && gradient, emptyList())
        return Bar(left, top, right, bottom, insets, radius, color, color2, vertical && gradient, icons(pixels, width, height, paper, bar, region, letters, words, ink, textHeight))
    }

    /**
     * Color más común dentro de [box] que no es papel ni tinta (el fondo de color bajo
     * la letra), o null si casi todo es papel.
     */
    fun dominant(pixels: IntArray, width: Int, height: Int, box: IntArray, paper: Int, ink: Int): Int? {
        val counts = HashMap<Int, Int>()
        val sums = HashMap<Int, LongArray>()
        var total = 0
        val x0 = box[0].coerceAtLeast(0)
        val x1 = box[2].coerceAtMost(width)
        val y0 = box[1].coerceAtLeast(0)
        val y1 = box[3].coerceAtMost(height)
        val step = max(1, ((x1 - x0) * (y1 - y0) / 6000))
        var k = 0
        for (y in y0 until y1) for (x in x0 until x1) {
            if (k++ % step != 0) continue
            total++
            val c = pixels[y * width + x]
            if (dist(c, paper) <= 50 || dist(c, ink) < 80) continue
            val key = ((red(c) shr 4) shl 8) or ((green(c) shr 4) shl 4) or (blue(c) shr 4)
            counts[key] = (counts[key] ?: 0) + 1
            val sum = sums.getOrPut(key) { LongArray(3) }
            sum[0] += red(c).toLong(); sum[1] += green(c).toLong(); sum[2] += blue(c).toLong()
        }
        if (total == 0) return null
        // Juntar con los vecinos del color más común (los degradados reparten los puntos).
        val top = counts.maxByOrNull { it.value } ?: return null
        var n = 0
        var r = 0L
        var g = 0L
        var b = 0L
        for ((key, count) in counts) {
            val dr = abs(((key shr 8) and 0xF) - ((top.key shr 8) and 0xF))
            val dg = abs(((key shr 4) and 0xF) - ((top.key shr 4) and 0xF))
            val db = abs((key and 0xF) - (top.key and 0xF))
            if (dr <= 1 && dg <= 1 && db <= 1) {
                val sum = sums.getValue(key)
                r += sum[0]; g += sum[1]; b += sum[2]; n += count
            }
        }
        if (n < total * 0.2f) return null
        return rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
    }

    /**
     * Parte un renglón en tramos: palabras seguidas sobre el mismo fondo (papel o una
     * barra de un color). Así "EVENTO:" (en una etiqueta azul) y lo que sigue (en el
     * papel) quedan aparte. [backgrounds]: fondo de cada palabra (null = papel).
     * Devuelve los índices de cada tramo.
     */
    fun segments(backgrounds: List<Int?>, boxes: List<IntArray>): List<List<Int>> {
        val out = ArrayList<MutableList<Int>>()
        for (i in backgrounds.indices) {
            val last = out.lastOrNull()
            if (last != null) {
                val prev = last.last()
                val a = backgrounds[prev]
                val b = backgrounds[i]
                val same = (a == null && b == null) || (a != null && b != null && dist(a, b) < 70)
                val h = max(boxes[prev][3] - boxes[prev][1], boxes[i][3] - boxes[i][1]).coerceAtLeast(1)
                val near = boxes[i][0] - boxes[prev][2] < h * 2.5f
                if (same && near) {
                    last += i
                    continue
                }
            }
            out += mutableListOf(i)
        }
        return out
    }

    /**
     * Íconos sobre la barra: manchas que no son barra ni letra. Una mancha es letra si
     * cae dentro de una palabra, es del alto del texto y tiene el color de la tinta.
     * El ícono puede salirse de la barra (un cuadrito de color al inicio): se sigue
     * hasta el papel.
     */
    private fun icons(
        pixels: IntArray,
        width: Int,
        height: Int,
        paper: Int,
        bar: Bar,
        region: BooleanArray,
        lines: List<IntArray>,
        words: List<IntArray>,
        ink: Int,
        textHeight: Int
    ): List<IntArray> {
        val seen = BooleanArray(width * height)
        val queue = IntArray(width * height)
        val parts = ArrayList<IntArray>() // [izq, arriba, der, abajo, puntos]
        val y0 = bar.top.toInt().coerceAtLeast(0)
        val y1 = bar.bottom.roundToInt().coerceAtMost(height)
        val x0 = bar.left.toInt().coerceAtLeast(0)
        val x1 = bar.right.roundToInt().coerceAtMost(width)
        // Bien adentro de la barra (el borde suave de la barra no cuenta).
        val margin = 2.5f
        fun deepInside(x: Int, y: Int): Boolean {
            val cx = x + 0.5f
            val cy = y + 0.5f
            return bar.contains(cx - margin, cy - margin) && bar.contains(cx + margin, cy - margin) &&
                bar.contains(cx - margin, cy + margin) && bar.contains(cx + margin, cy + margin)
        }
        // Distinto de la barra de verdad (no el borde suave de una letra).
        fun foreign(i: Int, x: Int, y: Int): Boolean =
            !region[i] && deepInside(x, y) && dist(pixels[i], bar.colorAt(x.toFloat(), y.toFloat())) > 70
        for (y in y0 until y1) for (x in x0 until x1) {
            val start = y * width + x
            if (seen[start] || !foreign(start, x, y)) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            seen[start] = true
            var l = x
            var r = x
            var t = y
            var b = y
            var r0 = 0L
            var g0 = 0L
            var b0 = 0L
            var touchesEdge = false
            var nearInk = Int.MAX_VALUE
            while (head < tail) {
                val i = queue[head++]
                val cx = i % width
                val cy = i / width
                l = min(l, cx); r = max(r, cx); t = min(t, cy); b = max(b, cy)
                val c = pixels[i]
                r0 += red(c); g0 += green(c); b0 += blue(c)
                nearInk = min(nearInk, dist(c, ink))
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = cx + dx
                    val ny = cy + dy
                    if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue
                    val j = ny * width + nx
                    if (seen[j]) continue
                    if (!deepInside(nx, ny)) {
                        if (!region[j] && dist(pixels[j], paper) > 60) touchesEdge = true
                        continue
                    }
                    if (!foreign(j, nx, ny)) continue
                    seen[j] = true
                    queue[tail++] = j
                }
            }
            val count = tail
            if (count < 4) continue
            val mean = rgb((r0 / count).toInt(), (g0 / count).toInt(), (b0 / count).toInt())
            val partHeight = b - t + 1
            val pad = textHeight * 0.15f
            val padY = textHeight * 0.4f
            // Letras: dentro del renglón leído, de su alto y con puntos del color de la tinta
            // (las letras gruesas se tocan entre sí, por eso se mira el renglón y no cada palabra;
            // el borde suave de una letra fina cambia el promedio, por eso se mira el punto más parecido).
            val padX = textHeight * 1.5f
            val inLine = lines.any { line -> l >= line[0] - padX && r < line[2] + padX && t >= line[1] - padY && b < line[3] + padY }
            val inWord = inLine || words.any { w -> l >= w[0] - pad && r < w[2] + pad && t >= w[1] - padY && b < w[3] + padY }
            val letter = inWord && partHeight <= textHeight * 1.3f && nearInk < 75
            if (letter) continue
            var box = intArrayOf(l, t, r + 1, b + 1)
            // Un ícono que se sale de la barra (cuadrito de color): se sigue hasta el papel.
            if (touchesEdge) box = growOutside(pixels, width, height, paper, region, box, textHeight * 2)
            parts += intArrayOf(box[0], box[1], box[2], box[3], count)
        }
        // Ícono pegado a una punta de la barra (un cuadrito de color que tapa el inicio).
        for (side in 0..1) {
            val edgeX = if (side == 0) bar.left.toInt() - 1 else bar.right.roundToInt()
            val from = (bar.top - textHeight * 0.3f).toInt().coerceAtLeast(0)
            val to = (bar.bottom + textHeight * 0.3f).roundToInt().coerceAtMost(height)
            var touching = 0
            for (y in from until to) {
                for (k in 0 until 3) {
                    val x = if (side == 0) edgeX - k else edgeX + k
                    if (x < 0 || x >= width) continue
                    val i = y * width + x
                    if (!region[i] && dist(pixels[i], paper) > 60) { touching++; break }
                }
            }
            // Más de la mitad del alto de la barra pegado: es un ícono, no un borde suave.
            if (touching < (bar.bottom - bar.top) * 0.6f) continue
            val seedLeft = if (side == 0) edgeX - 2 else edgeX
            val seed = intArrayOf(seedLeft.coerceAtLeast(0), from, (seedLeft + 3).coerceAtMost(width), to)
            val box = growOutside(pixels, width, height, paper, region, seed, (textHeight * 2.5f).toInt())
            if (box[2] - box[0] >= textHeight * 0.6f && box[3] - box[1] >= textHeight * 0.6f) {
                parts += intArrayOf(box[0], box[1], box[2], box[3], (box[2] - box[0]) * (box[3] - box[1]))
            }
        }
        // Pedacitos sueltos (ruido) fuera; los que están cerca forman un solo ícono.
        val minSize = max(6f, textHeight * textHeight * 0.03f)
        val kept = parts.filter { it[4] >= minSize || (it[2] - it[0]) * (it[3] - it[1]) >= textHeight * textHeight / 4 }.toMutableList()
        val gap = textHeight * 0.25f
        var changed = true
        while (changed) {
            changed = false
            loop@ for (i in kept.indices) for (j in i + 1 until kept.size) {
                val a = kept[i]
                val c = kept[j]
                if (a[0] - gap <= c[2] && c[0] - gap <= a[2] && a[1] - gap <= c[3] && c[1] - gap <= a[3]) {
                    kept[i] = intArrayOf(min(a[0], c[0]), min(a[1], c[1]), max(a[2], c[2]), max(a[3], c[3]), a[4] + c[4])
                    kept.removeAt(j)
                    changed = true
                    break@loop
                }
            }
        }
        // Un ícono es algo con cuerpo (no una rayita de borde de la barra).
        return kept.filter { (it[2] - it[0]) >= textHeight * 0.35f && (it[3] - it[1]) >= textHeight * 0.35f }
            .map { intArrayOf(it[0], it[1], it[2], it[3]) }
    }

    /** Agranda la caja mientras al lado (afuera) haya algo que no es papel ni barra. */
    private fun growOutside(pixels: IntArray, width: Int, height: Int, paper: Int, region: BooleanArray, box: IntArray, limit: Int): IntArray {
        var (l, t, r, b) = box
        val l0 = l; val t0 = t; val r0 = r; val b0 = b
        fun busyRow(y: Int, from: Int, to: Int): Boolean {
            if (y < 0 || y >= height) return false
            var on = 0
            for (x in from.coerceAtLeast(0) until to.coerceAtMost(width)) {
                val i = y * width + x
                if (!region[i] && dist(pixels[i], paper) > 60) on++
            }
            return on >= max(2, (to - from) / 5)
        }
        fun busyColumn(x: Int, from: Int, to: Int): Boolean {
            if (x < 0 || x >= width) return false
            var on = 0
            for (y in from.coerceAtLeast(0) until to.coerceAtMost(height)) {
                val i = y * width + x
                if (!region[i] && dist(pixels[i], paper) > 60) on++
            }
            return on >= max(2, (to - from) / 5)
        }
        var grew = true
        while (grew) {
            grew = false
            if (t > t0 - limit && busyRow(t - 1, l, r)) { t--; grew = true }
            if (b < b0 + limit && busyRow(b, l, r)) { b++; grew = true }
            if (l > l0 - limit && busyColumn(l - 1, t, b)) { l--; grew = true }
            if (r < r0 + limit && busyColumn(r, t, b)) { r++; grew = true }
        }
        return intArrayOf(l, t, r, b)
    }

    /**
     * Quita del texto lo que en realidad era el ícono: una palabra encima del ícono se
     * va; una pegada ("AA)" donde la primera A es el ícono) pierde sus primeras letras.
     * [words]: (texto, [izq, arriba, der, abajo)). Devuelve las palabras que quedan.
     */
    fun trimWords(words: List<Pair<String, IntArray>>, icons: List<IntArray>): List<Pair<String, IntArray>> {
        if (icons.isEmpty()) return words
        val out = ArrayList<Pair<String, IntArray>>()
        for ((text, box) in words) {
            val icon = icons.firstOrNull { it[0] < box[2] && it[2] > box[0] && it[1] < box[3] && it[3] > box[1] }
            if (icon == null) {
                out += text to box
                continue
            }
            val center = (box[0] + box[2]) / 2f
            if (center >= icon[0] && center < icon[2]) {
                // La palabra está casi toda sobre el ícono.
                val beyond = box[2] - icon[2]
                if (beyond <= (box[2] - box[0]) * 0.34f) continue
            }
            if (icon[2] > box[0] && icon[0] <= box[0] + 1) {
                val wordWidth = (box[2] - box[0]).coerceAtLeast(1)
                // Hacia abajo: mejor dejar una letra de más que borrar una de verdad.
                val cut = (text.length * (icon[2] - box[0]).toFloat() / wordWidth).toInt().coerceIn(0, text.length)
                val rest = text.substring(cut).trimStart()
                if (rest.isEmpty()) continue
                out += rest to intArrayOf(icon[2], box[1], box[2], box[3])
                continue
            }
            out += text to box
        }
        return out
    }
}
