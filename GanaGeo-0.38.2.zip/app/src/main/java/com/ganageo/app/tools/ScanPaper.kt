package com.ganageo.app.tools

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * "Hoja limpia": deja el papel blanco parejo, como hecho en computadora.
 * Quita sombras, manchas de luz y el tono amarillento de la foto.
 *
 * 1. Se divide la foto en cuadritos y en cada uno se mira qué tan claro es el
 *    papel (solo donde hay papel: tonos grises o blancos, claros).
 * 2. Se aclara cada punto según la luz que tenía su papel (la sombra desaparece).
 * 3. Lo que ya queda casi blanco se vuelve blanco puro.
 *
 * Las barras de color, fotos y zonas oscuras no son papel: no se tocan.
 * Trabaja sobre un arreglo de colores ARGB (sin Android) para poder probarlo.
 */
object ScanPaper {
    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun rgb(r: Int, g: Int, b: Int): Int =
        -0x1000000 or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    fun whiten(pixels: IntArray, width: Int, height: Int) {
        if (width < 8 || height < 8 || pixels.size < width * height) return
        val cell = max(16, min(width, height) / 36)
        val columns = (width + cell - 1) / cell
        val rows = (height + cell - 1) / cell
        val light = FloatArray(columns * rows)
        val paper = FloatArray(columns * rows)
        val histogram = IntArray(256)
        for (row in 0 until rows) for (column in 0 until columns) {
            java.util.Arrays.fill(histogram, 0)
            var total = 0
            var gray = 0
            val y0 = row * cell
            val x0 = column * cell
            val y1 = min(height, y0 + cell)
            val x1 = min(width, x0 + cell)
            for (y in y0 until y1 step 2) for (x in x0 until x1 step 2) {
                val c = pixels[y * width + x]
                val r = red(c)
                val g = green(c)
                val b = blue(c)
                total++
                val high = max(r, max(g, b))
                val low = min(r, min(g, b))
                if (high - low <= 38 && high >= 110) {
                    histogram[(r * 299 + g * 587 + b * 114) / 1000]++
                    gray++
                }
            }
            val index = row * columns + column
            // Papel: la mayoría del cuadrito es gris/blanco claro.
            if (total > 0 && gray * 10 >= total * 5) {
                var seen = 0
                var value = 255
                val target = gray * 8 / 10 // brillo del 80 %: el papel, no la letra
                for (level in 0 until 256) {
                    seen += histogram[level]
                    if (seen >= target) {
                        value = level
                        break
                    }
                }
                if (value >= 120) {
                    light[index] = value.toFloat()
                    paper[index] = 1f
                }
            }
        }
        // Cuadritos sin papel: toman la luz de los vecinos (para pasar suave).
        val filled = light.copyOf()
        repeat(6) {
            val next = filled.copyOf()
            for (row in 0 until rows) for (column in 0 until columns) {
                val index = row * columns + column
                if (filled[index] > 0f) continue
                var sum = 0f
                var count = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val r = row + dy
                    val c = column + dx
                    if (r !in 0 until rows || c !in 0 until columns) continue
                    val v = filled[r * columns + c]
                    if (v > 0f) {
                        sum += v
                        count++
                    }
                }
                if (count > 0) next[index] = sum / count
            }
            System.arraycopy(next, 0, filled, 0, filled.size)
        }
        for (i in filled.indices) if (filled[i] <= 0f) filled[i] = 255f
        val smoothLight = blur(filled, columns, rows)
        val smoothPaper = blur(paper, columns, rows)

        for (y in 0 until height) {
            val gy = ((y + 0.5f) / cell - 0.5f).coerceIn(0f, (rows - 1).toFloat())
            val ry = gy.toInt()
            val ty = gy - ry
            val ry2 = min(rows - 1, ry + 1)
            for (x in 0 until width) {
                val gx = ((x + 0.5f) / cell - 0.5f).coerceIn(0f, (columns - 1).toFloat())
                val rx = gx.toInt()
                val tx = gx - rx
                val rx2 = min(columns - 1, rx + 1)
                fun sample(grid: FloatArray): Float {
                    val top = grid[ry * columns + rx] * (1 - tx) + grid[ry * columns + rx2] * tx
                    val bottom = grid[ry2 * columns + rx] * (1 - tx) + grid[ry2 * columns + rx2] * tx
                    return top * (1 - ty) + bottom * ty
                }
                val weight = sample(smoothPaper).coerceIn(0f, 1f)
                if (weight <= 0.02f) continue
                val level = sample(smoothLight).coerceAtLeast(100f)
                val gain = 1f + ((252f / level).coerceIn(1f, 1.9f) - 1f) * weight
                val offset = y * width + x
                val c = pixels[offset]
                var r = (red(c) * gain).roundToInt()
                var g = (green(c) * gain).roundToInt()
                var b = (blue(c) * gain).roundToInt()
                val high = max(r, max(g, b))
                val low = min(r, min(g, b))
                // Casi blanco y sin color: blanco puro (con paso suave para no hacer bordes).
                if (high - low <= 30 && low >= 214) {
                    val t = ((low - 214) / 22f).coerceIn(0f, 1f) * weight
                    r = (r + (255 - r) * t).roundToInt()
                    g = (g + (255 - g) * t).roundToInt()
                    b = (b + (255 - b) * t).roundToInt()
                }
                pixels[offset] = rgb(r, g, b)
            }
        }
    }

    private fun blur(grid: FloatArray, columns: Int, rows: Int): FloatArray {
        val result = FloatArray(grid.size)
        for (row in 0 until rows) for (column in 0 until columns) {
            var sum = 0f
            var count = 0
            for (dy in -1..1) for (dx in -1..1) {
                val r = row + dy
                val c = column + dx
                if (r !in 0 until rows || c !in 0 until columns) continue
                sum += grid[r * columns + c]
                count++
            }
            result[row * columns + column] = sum / count
        }
        return result
    }
}
