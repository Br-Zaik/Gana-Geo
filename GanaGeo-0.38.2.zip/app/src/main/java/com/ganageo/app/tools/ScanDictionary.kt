package com.ganageo.app.tools

/**
 * Corrector de palabras mal leídas, con una lista de palabras en español.
 *
 * Es prudente: solo cambia una palabra si NO está en la lista y hay UNA sola
 * corrección posible de las que suelen fallar al leer una foto (0↔o, 1↔l,
 * rn↔m, cl↔d, falta de tilde en -ción/-sión, mayúscula suelta en medio…).
 * Nombres, siglas con números y palabras correctas no se tocan.
 *
 * words: palabras en minúscula, ordenadas, separadas por salto de línea.
 */
class ScanDictionary(private val words: String) {
    private val starts: IntArray

    init {
        var count = 0
        for (char in words) if (char == '\n') count++
        if (words.isNotEmpty() && words.last() != '\n') count++
        val list = IntArray(count)
        var index = 0
        var start = 0
        for (i in words.indices) {
            if (words[i] == '\n') {
                if (i > start) list[index++] = start
                start = i + 1
            }
        }
        if (start < words.length) list[index++] = start
        starts = list.copyOf(index)
    }

    val size: Int get() = starts.size

    private fun compareAt(position: Int, word: String): Int {
        var i = 0
        while (true) {
            val p = position + i
            val atEnd = p >= words.length || words[p] == '\n'
            if (atEnd) return if (i == word.length) 0 else -1
            if (i == word.length) return 1
            val difference = words[p].compareTo(word[i])
            if (difference != 0) return difference
            i++
        }
    }

    /** ¿Está la palabra (en minúscula) en la lista? */
    fun contains(word: String): Boolean {
        if (word.isEmpty()) return false
        var low = 0
        var high = starts.size - 1
        while (low <= high) {
            val middle = (low + high) ushr 1
            val result = compareAt(starts[middle], word)
            when {
                result == 0 -> return true
                result < 0 -> low = middle + 1
                else -> high = middle - 1
            }
        }
        return false
    }

    /** Corrige una palabra suelta (sin signos alrededor). Devuelve la misma si no hay una corrección segura. */
    fun correct(word: String): String {
        if (word.length < 4 || word.any { !it.isLetterOrDigit() }) return word
        val letters = word.count { it.isLetter() }
        if (letters < word.length - 1) return word // números, códigos
        val lower = word.lowercase()
        val allUpper = word.all { !it.isLetter() || it.isUpperCase() }
        val capitalized = word.first().isUpperCase() && word.drop(1).all { !it.isLetter() || it.isLowerCase() }
        val mixed = !allUpper && !capitalized && word.drop(1).any { it.isUpperCase() } && word.first().isLowerCase()
        // Palabras con mayúsculas en medio tipo marca ("WebGen") se dejan.
        val brand = word.first().isUpperCase() && !allUpper && !capitalized
        if (brand) return word
        if (contains(lower) && !lower.any { it.isDigit() }) {
            val accented = accentEnding(lower)
            return if (accented != null && contains(accented)) restoreCase(word, accented, allUpper, capitalized || mixed) else word
        }
        val candidates = LinkedHashSet<String>()
        // Cambios de una letra por otra parecida (l↔i, c↔e, n↔u, h↔b) solo si la palabra
        // ya se ve mal leída (tiene números o mayúsculas sueltas): si no, son riesgosos
        // ("galio" no es "gallo").
        val suspicious = mixed || lower.any { it.isDigit() }
        for (variant in confusions(lower, suspicious)) {
            if (contains(variant)) candidates += variant
            accentEnding(variant)?.let { if (contains(it)) candidates += it }
        }
        accentEnding(lower)?.let { if (contains(it)) candidates += it }
        // Un nombre propio (con mayúscula) solo se corrige si tenía números o letras raras.
        if (capitalized && lower.none { it.isDigit() } && candidates.none { it.length == lower.length && differsOnlyByAccent(it, lower) }) {
            return word
        }
        val unique = candidates.singleOrNull() ?: return if (mixed) word.lowercase() else word
        return restoreCase(word, unique, allUpper, capitalized)
    }

    private fun differsOnlyByAccent(a: String, b: String): Boolean =
        ScanFontMatch.withoutMarks(a) == ScanFontMatch.withoutMarks(b)

    /** -cion → -ción, -sion → -sión (siempre llevan tilde en singular). */
    private fun accentEnding(word: String): String? = when {
        word.endsWith("cion") -> word.dropLast(4) + "ción"
        word.endsWith("sion") -> word.dropLast(4) + "sión"
        else -> null
    }

    /** Variantes por errores típicos de lectura (un solo cambio). */
    private fun confusions(word: String, risky: Boolean): List<String> {
        val result = ArrayList<String>()
        fun swap(at: Int, length: Int, replacement: String) {
            result += word.substring(0, at) + replacement + word.substring(at + length)
        }
        for (i in word.indices) {
            when (word[i]) {
                '0' -> swap(i, 1, "o")
                '1' -> { swap(i, 1, "l"); swap(i, 1, "i") }
                '5' -> swap(i, 1, "s")
                '8' -> swap(i, 1, "b")
                'n' -> swap(i, 1, "ñ")
            }
            if (risky) {
                when (word[i]) {
                    'l' -> swap(i, 1, "i")
                    'i' -> swap(i, 1, "l")
                    'c' -> swap(i, 1, "e")
                    'e' -> swap(i, 1, "c")
                    'n' -> swap(i, 1, "u")
                    'u' -> swap(i, 1, "n")
                    'h' -> swap(i, 1, "b")
                    'b' -> swap(i, 1, "h")
                }
            }
            if (word.startsWith("rn", i)) swap(i, 2, "m")
            if (word.startsWith("m", i)) swap(i, 1, "rn")
            if (word.startsWith("cl", i)) swap(i, 2, "d")
            if (word.startsWith("vv", i)) swap(i, 2, "w")
            if (word.startsWith("ii", i)) swap(i, 2, "ü")
        }
        return result
    }

    private fun restoreCase(original: String, fixed: String, allUpper: Boolean, capitalized: Boolean): String = when {
        allUpper -> fixed.uppercase()
        capitalized -> fixed.replaceFirstChar { it.uppercaseChar() }
        else -> fixed
    }

    /** Corrige todas las palabras de un texto, respetando signos y espacios. */
    fun fixText(text: String): String {
        val result = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            if (!text[i].isLetterOrDigit()) {
                result.append(text[i])
                i++
                continue
            }
            var end = i
            while (end < text.length && text[end].isLetterOrDigit()) end++
            result.append(correct(text.substring(i, end)))
            i = end
        }
        return result.toString()
    }
}
