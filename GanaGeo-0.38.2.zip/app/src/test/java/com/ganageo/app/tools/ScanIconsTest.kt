package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Test

class ScanIconsTest {
    private val navy = 0xFF0B2545.toInt()
    private val teal = 0xFF1BA3B5.toInt()

    @Test
    fun iconoDeOtroColorSeQuita() {
        val words = listOf(
            ScanIcons.Word("8", 100, 100, 130, 140, teal),
            ScanIcons.Word("PERFIL", 160, 105, 300, 135, navy)
        )
        assertEquals(1, ScanIcons.leadingIcons(words))
    }

    @Test
    fun iconoMasAltoSeQuita() {
        val words = listOf(
            ScanIcons.Word("6", 100, 90, 130, 150, null),
            ScanIcons.Word("CONTACTO", 160, 105, 320, 135, null)
        )
        assertEquals(1, ScanIcons.leadingIcons(words))
    }

    @Test
    fun numeroNormalDelTextoSeQueda() {
        // "4 preguntas": mismo color y altura → es texto.
        val words = listOf(
            ScanIcons.Word("4", 100, 105, 115, 135, navy),
            ScanIcons.Word("preguntas", 125, 105, 260, 135, navy)
        )
        assertEquals(0, ScanIcons.leadingIcons(words))
    }

    @Test
    fun vinetaNoSeQuita() {
        val words = listOf(
            ScanIcons.Word("•", 100, 112, 108, 122, teal),
            ScanIcons.Word("Trabajo", 130, 105, 230, 135, navy)
        )
        assertEquals(0, ScanIcons.leadingIcons(words))
    }

    @Test
    fun trazoPegadoSeQuita() {
        val known = setOf("conocimientos", "experiencia")
        assertEquals("CONOCIMIENTOS", ScanIcons.stripGlued("lCONOCIMIENTOS") { it in known })
        assertEquals("EXPERIENCIA", ScanIcons.stripGlued("IEXPERIENCIA") { it in known })
        // "IMPORTANCIA" es una palabra: no se toca.
        assertEquals("IMPORTANCIA", ScanIcons.stripGlued("IMPORTANCIA") { it == "importancia" || it == "mportancia" })
        assertEquals("Hola", ScanIcons.stripGlued("Hola") { true })
    }
}
