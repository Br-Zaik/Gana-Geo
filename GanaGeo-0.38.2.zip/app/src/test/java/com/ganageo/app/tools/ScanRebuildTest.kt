package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanRebuildTest {
    private val measure: (String) -> Float = { it.length * 10f }

    @Test
    fun uneRenglonesYPalabrasCortadas() {
        val text = ScanRebuild.joinLines(listOf("La voladura minera requiere una gestión", "preventiva que conside-", "re a las personas."))
        assertEquals("La voladura minera requiere una gestión preventiva que considere a las personas.", text)
    }

    @Test
    fun noQuitaGuionSiSigueMayuscula() {
        assertEquals("WebGen- 200", ScanRebuild.joinLines(listOf("WebGen-", "200")))
        assertEquals("Explotación- Minera", ScanRebuild.joinLines(listOf("Explotación-", "Minera")))
    }

    @Test
    fun cortaEnRenglonesQueEntran() {
        val lines = ScanRebuild.wrap("uno dos tres cuatro cinco", 95f, measure)
        assertEquals(listOf("uno dos", "tres", "cuatro", "cinco"), lines)
        lines.forEach { assertTrue(measure(it) <= 95f) }
    }

    @Test
    fun respetaSaltosYParteLaPalabraLarga() {
        assertEquals(listOf("hola", "chau"), ScanRebuild.wrap("hola\nchau", 200f, measure))
        assertEquals(listOf("abcde", "fghij", "k"), ScanRebuild.wrap("abcdefghijk", 50f, measure))
    }

    @Test
    fun cuantilTomaUnValorDelMedioBajo() {
        assertEquals(2f, ScanRebuild.quantile(listOf(5f, 1f, 2f, 9f, 3f), 0.3f))
        assertEquals(0f, ScanRebuild.quantile(emptyList(), 0.5f))
    }
}

class ScanRebuildMoreTest {
    @Test
    fun juntaPedazosDeUnRenglonYQuitaRepetidos() {
        val lines = listOf(
            OcrLine("integrarse con", 10, 100, 120, 120),
            OcrLine("personal competente", 130, 101, 300, 121),
            OcrLine("personal compe", 132, 102, 260, 120), // repetido encimado
            OcrLine("otro renglón", 10, 140, 200, 160)
        )
        val groups = ScanRebuild.mergeLines(lines)
        assertEquals(2, groups.size)
        assertEquals(listOf(0, 1), groups[0].toList())
        assertEquals(listOf(3), groups[1].toList())
    }

    @Test
    fun noJuntaColumnasSeparadas() {
        val lines = listOf(
            OcrLine("columna izquierda", 10, 100, 300, 120),
            OcrLine("columna derecha", 340, 100, 600, 120)
        )
        assertEquals(2, ScanRebuild.mergeLines(lines).size)
    }

    @Test
    fun puntuaTextoLimpioYTextoRaro() {
        assertTrue(ScanRebuild.textScore("El riesgo residual se estima después de verificar.") > 0.95f)
        assertTrue(ScanRebuild.textScore("cOimientos de emergencia Psaddeb") < 0.8f)
    }

    @Test
    fun reconoceTamanosDeHoja() {
        assertEquals(0, ScanRebuild.paperOf(2100, 2970)) // A4
        assertEquals(0, ScanRebuild.paperOf(2970, 2100)) // A4 horizontal
        assertEquals(1, ScanRebuild.paperOf(1102, 1427)) // Carta
        assertEquals(2, ScanRebuild.paperOf(1000, 1529)) // Oficio
        assertEquals(-1, ScanRebuild.paperOf(1000, 1000))
    }
}

class ScanRebuildListTest {
    private val measure: (String) -> Float = { it.length * 10f }

    @Test
    fun reconoceVinetasYNumeros() {
        assertEquals(2, ScanRebuild.listPrefix("• Seguridad minera"))
        assertEquals(3, ScanRebuild.listPrefix("1. Introducción"))
        assertEquals(4, ScanRebuild.listPrefix("3.- Explique"))
        assertEquals(3, ScanRebuild.listPrefix("a) Transición"))
        assertEquals(0, ScanRebuild.listPrefix("La voladura minera"))
        assertEquals(0, ScanRebuild.listPrefix("WebGen 200"))
    }

    @Test
    fun cortaConSangria() {
        val lines = ScanRebuild.wrap("• uno dos tres cuatro", 100f, 70f, measure)
        assertEquals(listOf("• uno dos", "tres", "cuatro"), lines)
    }
}
