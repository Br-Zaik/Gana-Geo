package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ScanPaperTest {
    private fun rgb(r: Int, g: Int, b: Int): Int = -0x1000000 or (r shl 16) or (g shl 8) or b
    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun blue(c: Int) = c and 0xFF

    @Test
    fun quitaLaSombraDelPapel() {
        val width = 300
        val height = 200
        // Papel con sombra: de 235 a la izquierda a 170 a la derecha.
        val pixels = IntArray(width * height) { index ->
            val x = index % width
            val v = 235 - x * 65 / width
            rgb(v, v, v - 6)
        }
        ScanPaper.whiten(pixels, width, height)
        for (y in 20 until 180 step 10) for (x in 20 until 280 step 10) {
            assertTrue(red(pixels[y * width + x]) >= 245)
        }
    }

    @Test
    fun noTocaUnaBarraDeColor() {
        val width = 300
        val height = 300
        val navy = rgb(20, 50, 90)
        val pixels = IntArray(width * height) { index -> if (index / width in 100 until 200) navy else rgb(240, 240, 236) }
        ScanPaper.whiten(pixels, width, height)
        val middle = pixels[150 * width + 150]
        assertTrue(abs(red(middle) - 20) <= 3)
        assertTrue(abs(blue(middle) - 90) <= 4)
        assertEquals(255, red(pixels[20 * width + 20]))
    }

    @Test
    fun laLetraSigueOscura() {
        val width = 200
        val height = 200
        val pixels = IntArray(width * height) { rgb(225, 222, 215) }
        for (y in 90 until 110) for (x in 50 until 150 step 4) pixels[y * width + x] = rgb(30, 30, 30)
        ScanPaper.whiten(pixels, width, height)
        assertTrue(red(pixels[100 * width + 50]) < 60)
    }
}
