package com.ganageo.app.tools

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanUpscaleTest {
    /** IA de mentira: agranda x4 repitiendo cada punto (para probar pedazos y bordes). */
    private val nearest = ScanUpscale.Model { chw, h, w ->
        val plane = h * w
        val outW = w * 4
        val outPlane = outW * h * 4
        val out = FloatArray(3 * outPlane)
        for (c in 0 until 3) for (y in 0 until h * 4) for (x in 0 until outW) {
            out[c * outPlane + y * outW + x] = chw[c * plane + (y / 4) * w + x / 4]
        }
        out
    }

    private fun sample(width: Int, height: Int) = IntArray(width * height) { i ->
        val x = i % width
        val y = i / width
        (0xFF shl 24) or ((x * 7 % 256) shl 16) or ((y * 11 % 256) shl 8) or ((x + y) * 3 % 256)
    }

    @Test
    fun originalQuedaIgualConUnaIaQueNoCambiaNada() {
        val pixels = sample(37, 23)
        val out = ScanUpscale.upscale(pixels, 37, 23, 1, 16, 4, nearest)!!
        assertArrayEquals(pixels, out)
    }

    @Test
    fun x2DuplicaYLosPedazosNoDejanCosturas() {
        val pixels = sample(50, 31)
        val a = ScanUpscale.upscale(pixels, 50, 31, 2, 16, 4, nearest)!!
        val b = ScanUpscale.upscale(pixels, 50, 31, 2, 200, 4, nearest)!!
        assertEquals(100 * 62, a.size)
        assertArrayEquals(b, a)
        assertEquals(pixels[5 * 50 + 7], a[(10) * 100 + 14])
        assertEquals(pixels[5 * 50 + 7], a[(11) * 100 + 15])
    }

    @Test
    fun loTransparenteSigueTransparente() {
        val pixels = IntArray(20 * 20) { i -> if (i % 20 in 5..14 && i / 20 in 5..14) 0xFF112233.toInt() else 0 }
        val out = ScanUpscale.upscale(pixels, 20, 20, 2, 16, 4, nearest)!!
        assertEquals(0, out[0] ushr 24)
        assertEquals(255, out[20 * 40 + 20] ushr 24)
        // Sin halo: el color de adentro no se oscurece ni aclara.
        assertEquals(0x112233, out[20 * 40 + 20] and 0xFFFFFF)
    }

    @Test
    fun seCancelaEntrePedazos() {
        var calls = 0
        val out = ScanUpscale.upscale(sample(64, 64), 64, 64, 2, 16, 4, nearest) { done, _ -> calls++; done < 3 }
        assertNull(out)
        assertTrue(calls <= 5)
    }

    @Test
    fun fotoODibujo() {
        assertTrue(ScanUpscale.isPhoto(sample(120, 90), 120, 90))
        val icon = IntArray(80 * 80) { i -> if ((i % 80 - 40) * (i % 80 - 40) + (i / 80 - 40) * (i / 80 - 40) < 900) 0xFF0B5563.toInt() else 0xFFE0F4F8.toInt() }
        assertFalse(ScanUpscale.isPhoto(icon, 80, 80))
    }

    @Test
    fun piezaMuyGrandeNoSeAgranda() {
        assertEquals(2, ScanUpscale.safeScale(400, 300, 2, 6_000_000L))
        assertEquals(1, ScanUpscale.safeScale(2000, 1500, 2, 6_000_000L))
    }

    @Test
    fun huellaCambiaConElContenido() {
        val a = sample(10, 10)
        val b = a.copyOf().also { it[55] = 0 }
        assertTrue(ScanUpscale.fingerprint(a, 10, 10) != ScanUpscale.fingerprint(b, 10, 10))
        assertEquals(ScanUpscale.fingerprint(a, 10, 10), ScanUpscale.fingerprint(a.copyOf(), 10, 10))
    }

    @Test
    fun realceNoCambiaUnColorParejoYMarcaBordes() {
        val flat = IntArray(20 * 20) { 0xFF808080.toInt() }
        assertArrayEquals(flat, ScanUpscale.sharpen(flat, 20, 20, 0.5f))
        val edge = IntArray(20 * 20) { i -> if (i % 20 < 10) 0xFF404040.toInt() else 0xFFC0C0C0.toInt() }
        val out = ScanUpscale.sharpen(edge, 20, 20, 0.5f)
        assertTrue((out[5 * 20 + 9] and 255) < 0x40)
        assertTrue((out[5 * 20 + 10] and 255) > 0xC0)
    }
}
