package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanGuidesTest {
    private val page = 1000f
    private val margins = ScanGuides.Margins(100f, 900f)

    @Test
    fun margenesIgnoranNumeroSuelto() {
        // Un número de página a la izquierda (x = 30) no es el margen.
        val lefts = listOf(30f, 120f, 121f, 119f, 160f, 300f)
        val rights = listOf(60f, 850f, 870f, 860f, 700f, 500f)
        val result = ScanGuides.margins(lefts, rights, page)
        assertEquals(119f, result.left, 0.01f)
        assertEquals(881f, result.right, 0.01f)
    }

    @Test
    fun margenDerechoCreceSiElTextoLlegaMasLejos() {
        val lefts = listOf(100f, 100f, 100f)
        val rights = listOf(950f, 950f, 940f)
        val result = ScanGuides.margins(lefts, rights, page)
        assertEquals(100f, result.left, 0.01f)
        assertTrue(result.right >= 940f)
    }

    @Test
    fun sePegaAlBordeIzquierdoDeLasOtrasPreguntas() {
        // Pregunta movida que quedó 6 px más a la derecha que las demás.
        val others = listOf(
            ScanGuides.Box(130f, 100f, 600f, 130f),
            ScanGuides.Box(130f, 300f, 700f, 330f)
        )
        val moving = ScanGuides.Box(130f, 500f, 450f, 530f)
        val snap = ScanGuides.snap(moving, 6f, -20f, others, page, 1400f, margins, threshold = 10f)
        assertEquals(0f, snap.dx, 0.01f)
        val vertical = snap.guides.first { it.vertical }
        assertEquals(130f, vertical.position, 0.01f)
        // La guía cruza las preguntas alineadas.
        assertTrue(vertical.start <= 100f)
        assertTrue(vertical.end >= 510f)
    }

    @Test
    fun sePegaAlCentroDeLaHoja() {
        val moving = ScanGuides.Box(300f, 50f, 680f, 90f) // centro en 490
        val snap = ScanGuides.snap(moving, 7f, 0f, emptyList(), page, 1400f, margins, threshold = 10f)
        assertEquals(10f, snap.dx, 0.01f) // centro final en 500
        val guide = snap.guides.first { it.vertical }
        assertEquals(500f, guide.position, 0.01f)
        assertEquals(0f, guide.start, 0.01f)
        assertEquals(1400f, guide.end, 0.01f)
    }

    @Test
    fun lejosNoSePega() {
        val others = listOf(ScanGuides.Box(130f, 100f, 600f, 130f))
        val moving = ScanGuides.Box(300f, 600f, 420f, 640f)
        val snap = ScanGuides.snap(moving, 33f, 41f, others, page, 1400f, margins, threshold = 8f)
        assertEquals(33f, snap.dx, 0.01f)
        assertEquals(41f, snap.dy, 0.01f)
        assertTrue(snap.guides.isEmpty())
    }

    @Test
    fun sePoneEnLaMismaFilaQueOtro() {
        val others = listOf(ScanGuides.Box(100f, 200f, 300f, 240f))
        val moving = ScanGuides.Box(500f, 300f, 700f, 340f)
        val snap = ScanGuides.snap(moving, 0f, -96f, others, page, 1400f, margins, threshold = 8f)
        assertEquals(-100f, snap.dy, 0.01f)
        val guide = snap.guides.first { !it.vertical }
        assertEquals(100f, guide.start, 0.01f)
        assertEquals(700f, guide.end, 0.01f)
    }
}
