package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ScanShapesTest {
    private val paper = 0xFFFFFFFF.toInt()
    private val navy = 0xFF0B2545.toInt()
    private val teal = 0xFF1BA3B5.toInt()
    private val gray = 0xFF555555.toInt()

    private fun page(width: Int, height: Int) = IntArray(width * height) { paper }

    private fun fill(p: IntArray, width: Int, l: Int, t: Int, r: Int, b: Int, color: Int) {
        for (y in t until b) for (x in l until r) p[y * width + x] = color
    }

    private fun near(a: Int, b: Int, tolerance: Int) = abs(a - b) <= tolerance

    private fun channelsClose(a: Int, b: Int): Boolean =
        abs(((a shr 16) and 0xFF) - ((b shr 16) and 0xFF)) < 12 &&
            abs(((a shr 8) and 0xFF) - ((b shr 8) and 0xFF)) < 12 &&
            abs((a and 0xFF) - (b and 0xFF)) < 12

    @Test
    fun barraLisaSeVuelveForma() {
        val w = 800
        val h = 1000
        val p = page(w, h)
        fill(p, w, 100, 200, 700, 260, navy)
        val result = ScanShapes.find(p, w, h, paper, emptyList())
        val rects = result.shapes.filter { it.kind == ScanShapes.RECT }
        assertEquals(1, rects.size)
        val bar = rects.first()
        assertTrue(near(bar.left, 100, 2) && near(bar.right, 700, 2) && near(bar.top, 200, 2) && near(bar.bottom, 260, 2))
        assertTrue(channelsClose(bar.color, navy))
        assertTrue(result.pieces.isEmpty())
    }

    @Test
    fun lineaFinaSeVuelveLinea() {
        val w = 800
        val h = 1000
        val p = page(w, h)
        fill(p, w, 120, 500, 680, 503, teal)
        val result = ScanShapes.find(p, w, h, paper, emptyList())
        val lines = result.shapes.filter { it.kind == ScanShapes.LINE }
        assertEquals(1, lines.size)
        val line = lines.first()
        assertTrue(line.bottom - line.top in 2..5)
        assertTrue(near(line.left, 120, 3) && near(line.right, 680, 3))
        assertTrue(channelsClose(line.color, teal))
    }

    @Test
    fun cuadriculaDeTablaSonLineas() {
        val w = 800
        val h = 1000
        val p = page(w, h)
        // Marco de 3 x 3 celdas con líneas de 2 px.
        for (i in 0..3) {
            fill(p, w, 100, 300 + i * 60, 700, 302 + i * 60, gray)
            fill(p, w, 100 + i * 200, 300, 102 + i * 200, 482, gray)
        }
        val result = ScanShapes.find(p, w, h, paper, emptyList())
        val lines = result.shapes.filter { it.kind == ScanShapes.LINE }
        assertEquals(8, lines.size)
        assertTrue(result.pieces.isEmpty())
    }

    @Test
    fun iconoSobreBarraEsPiezaTransparente() {
        val w = 800
        val h = 1000
        val p = page(w, h)
        fill(p, w, 0, 100, 300, 700, navy) // barra lateral
        // Ícono con dibujo (dos colores) encima de la barra.
        fill(p, w, 100, 300, 160, 360, teal)
        fill(p, w, 120, 320, 140, 340, paper)
        val result = ScanShapes.find(p, w, h, paper, emptyList())
        val rect = result.shapes.single { it.kind == ScanShapes.RECT }
        assertTrue(channelsClose(rect.color, navy))
        val icon = result.pieces.single()
        assertTrue(icon.left in 90..102 && icon.right in 158..172)
        assertEquals(rect.color, icon.background)
    }

    @Test
    fun restosDeLetraSeDescartan() {
        val w = 800
        val h = 1000
        val p = page(w, h)
        // Renglón leído en (200,400)-(600,430); quedó un trazo suelto de una letra.
        fill(p, w, 196, 404, 200, 428, gray)
        // Viñeta separada a la izquierda del renglón: sí es pieza.
        fill(p, w, 150, 410, 162, 422, teal)
        val result = ScanShapes.find(p, w, h, paper, listOf(intArrayOf(200, 400, 600, 430)))
        // Solo queda la viñeta (como pieza o como forma lisa); el resto de letra no.
        val lefts = result.pieces.map { it.left } + result.shapes.map { it.left }
        val rights = result.pieces.map { it.right } + result.shapes.map { it.right }
        assertEquals(1, lefts.size)
        assertTrue(lefts.first() in 140..152 && rights.first() in 160..170)
    }

    @Test
    fun fotoEsPieza() {
        val w = 800
        val h = 1000
        val p = page(w, h)
        // "Foto": colores que cambian.
        for (y in 600 until 800) for (x in 300 until 600) {
            val v = ((x * 7 + y * 13) % 200) + 20
            p[y * w + x] = (0xFF shl 24) or (v shl 16) or ((255 - v) shl 8) or (v / 2)
        }
        val result = ScanShapes.find(p, w, h, paper, emptyList())
        assertTrue(result.shapes.isEmpty())
        val photo = result.pieces.single()
        assertTrue(photo.left in 290..302 && photo.right in 598..610)
    }

    @Test
    fun recuadroConEsquinasRedondas() {
        val w = 800
        val h = 1000
        val p = page(w, h)
        val radius = 30
        for (y in 200 until 400) for (x in 100 until 500) {
            val cx = when {
                x < 100 + radius -> 100 + radius
                x >= 500 - radius -> 500 - radius - 1
                else -> x
            }
            val cy = when {
                y < 200 + radius -> 200 + radius
                y >= 400 - radius -> 400 - radius - 1
                else -> y
            }
            val dx = x - cx
            val dy = y - cy
            if (dx * dx + dy * dy <= radius * radius) p[y * w + x] = teal
        }
        val result = ScanShapes.find(p, w, h, paper, emptyList())
        val rect = result.shapes.single { it.kind == ScanShapes.RECT }
        assertTrue("radio ${rect.radius}", rect.radius in 15..45)
        assertTrue(result.pieces.isEmpty())
    }

    @Test
    fun zonaDeLaIaEsUnaSolaPieza() {
        val w = 800
        val h = 1000
        val p = page(w, h)
        // Dos manchas separadas dentro de la misma "imagen".
        fill(p, w, 100, 100, 180, 180, teal)
        for (y in 220 until 300) for (x in 100 until 300) p[y * w + x] = if ((x + y) % 7 < 3) navy else teal
        val result = ScanShapes.find(p, w, h, paper, emptyList(), listOf(intArrayOf(90, 90, 310, 310)))
        val piece = result.pieces.single()
        assertTrue(piece.top <= 102 && piece.bottom >= 298)
        assertTrue(result.shapes.isEmpty())
    }

    @Test
    fun barraPegadaAUnaFotoSeSepara() {
        val w = 800
        val h = 1000
        val p = page(w, h)
        // Foto arriba a la izquierda y, pegada debajo, la barra lateral oscura (como un CV).
        for (y in 0 until 300) for (x in 0 until 300) {
            val v = ((x * 7 + y * 13) % 200) + 20
            p[y * w + x] = (0xFF shl 24) or (v shl 16) or ((v / 2) shl 8) or (255 - v)
        }
        fill(p, w, 0, 300, 300, 1000, navy)
        fill(p, w, 100, 500, 140, 540, teal) // ícono (con dibujo) sobre la barra
        fill(p, w, 112, 512, 128, 528, paper)
        val result = ScanShapes.find(p, w, h, paper, emptyList())
        val bar = result.shapes.filter { it.kind == ScanShapes.RECT }.maxByOrNull { (it.right - it.left) * (it.bottom - it.top) }!!
        assertTrue(channelsClose(bar.color, navy))
        assertTrue("barra ${bar.top}", bar.top in 296..312 && bar.bottom >= 996)
        val photo = result.pieces.first { it.top < 10 }
        assertTrue(photo.bottom in 296..320)
        // El ícono sigue ahí (como forma o pieza encima de la barra).
        val iconParts = result.pieces.count { it.top in 480..540 } + result.shapes.count { it.top in 480..540 }
        assertTrue(iconParts >= 1)
    }
}
