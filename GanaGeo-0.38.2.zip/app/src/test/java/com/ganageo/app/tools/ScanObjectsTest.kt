package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanObjectsTest {
    private fun rgb(r: Int, g: Int, b: Int): Int = -0x1000000 or (r shl 16) or (g shl 8) or b

    @Test
    fun encuentraUnLogoYNoUnaBarraLisa() {
        val width = 400
        val height = 400
        val white = rgb(255, 255, 255)
        val pixels = IntArray(width * height) { white }
        // Barra lisa azul (no es pieza).
        for (y in 300 until 330) for (x in 20 until 380) pixels[y * width + x] = rgb(20, 50, 90)
        // "Logo": cuadros de colores con dibujo.
        for (y in 40 until 120) for (x in 40 until 120) {
            pixels[y * width + x] = if ((x / 6 + y / 6) % 2 == 0) rgb(200, 30, 30) else rgb(30, 150, 40)
        }
        val paper = ScanObjects.paperColor(pixels, width, height)
        assertTrue(paper != -1)
        val found = ScanObjects.find(pixels, width, height, paper)
        assertEquals(1, found.size)
        val box = found[0]
        assertTrue(box[0] <= 40 && box[1] <= 40 && box[2] >= 120 && box[3] >= 120)
        assertTrue(box[2] < 140 && box[3] < 140)
    }

    @Test
    fun laFormaDelLogoIncluyeSuDibujoYNoElPapel() {
        val width = 50
        val height = 50
        val white = rgb(255, 255, 255)
        val pixels = IntArray(width * height) { white }
        for (y in 20 until 30) for (x in 20 until 30) pixels[y * width + x] = rgb(0, 0, 0)
        val alpha = ScanObjects.alpha(pixels, width, intArrayOf(10, 10, 40, 40), white)
        assertEquals(0xFF.toByte(), alpha[15 * 30 + 15])
        assertEquals(0.toByte(), alpha[0])
    }
}
