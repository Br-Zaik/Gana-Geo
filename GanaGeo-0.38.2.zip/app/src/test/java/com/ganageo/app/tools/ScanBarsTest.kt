package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanBarsTest {
    private val white = -0x1
    private val navy = 0xFF0A5072.toInt()
    private val teal = 0xFF0E7C86.toInt()

    private fun page(w: Int, h: Int) = IntArray(w * h) { white }

    /** Barra de [x0] a [x1] (filas [y0], [y1]); con [slant] la punta derecha va inclinada. */
    private fun bar(px: IntArray, w: Int, x0: Int, y0: Int, x1: Int, y1: Int, color: (Int) -> Int, slant: Int = 0) {
        for (y in y0 until y1) {
            val right = x1 - slant * (y - y0) / (y1 - y0)
            for (x in x0 until right) px[y * w + x] = color(x)
        }
    }

    /** "Letras": bloques blancos de 6 px separados. */
    private fun letters(px: IntArray, w: Int, x0: Int, x1: Int, y0: Int, y1: Int) {
        var x = x0
        while (x + 6 <= x1) {
            for (y in y0 until y1) for (k in 0 until 6) px[y * w + x + k] = white
            x += 9
        }
    }

    @Test
    fun barraAzulConPuntaInclinada() {
        val w = 400; val h = 120
        val px = page(w, h)
        bar(px, w, 20, 40, 320, 72, { navy }, slant = 16)
        letters(px, w, 40, 200, 48, 64)
        val found = ScanBars.find(px, w, h, white, intArrayOf(38, 46, 202, 66), listOf(intArrayOf(38, 46, 202, 66)), white)
        assertNotNull(found)
        val b = found!!
        assertEquals(20f, b.left, 2f)
        assertEquals(40f, b.top, 2f)
        assertEquals(72f, b.bottom, 2f)
        assertEquals(320f, b.right, 3f)
        assertTrue("punta inclinada: ${b.insets.joinToString()}", b.insets[2] > 8f && b.insets[1] < 3f)
        assertTrue(ScanBars.dist(b.color, navy) < 20)
        assertNull(b.color2)
        assertTrue("sin íconos: ${b.icons.size}", b.icons.isEmpty())
    }

    @Test
    fun degradadoDeIzquierdaADerecha() {
        val w = 400; val h = 120
        val px = page(w, h)
        bar(px, w, 20, 40, 380, 70, { x ->
            val t = (x - 20) / 360f
            val r = (10 + (180 - 10) * t).toInt(); val g = (80 + (220 - 80) * t).toInt(); val bl = (114 + (230 - 114) * t).toInt()
            -0x1000000 or (r shl 16) or (g shl 8) or bl
        })
        letters(px, w, 40, 160, 47, 63)
        val found = ScanBars.find(px, w, h, white, intArrayOf(38, 45, 162, 65), listOf(intArrayOf(38, 45, 162, 65)), white)
        assertNotNull(found)
        assertNotNull(found!!.color2)
        assertTrue(ScanBars.dist(found.color, 0xFF0A5072.toInt()) < 40)
    }

    @Test
    fun iconoAlInicioSeRecortaYSaleDelTexto() {
        val w = 400; val h = 140
        val px = page(w, h)
        bar(px, w, 40, 50, 360, 80, { 0xFFB4DEE4.toInt() })
        // Cuadrito de color al inicio, más alto que la barra.
        for (y in 42 until 88) for (x in 30 until 72) px[y * w + x] = teal
        // Letras oscuras sobre la barra clara.
        for (k in 0 until 10) for (y in 57 until 73) for (x in 90 + k * 11 until 96 + k * 11) px[y * w + x] = 0xFF07192B.toInt()
        val text = intArrayOf(36, 55, 205, 75)
        val words = listOf(intArrayOf(36, 55, 100, 75), intArrayOf(110, 55, 205, 75))
        val found = ScanBars.find(px, w, h, white, text, words, 0xFF07192B.toInt())
        assertNotNull(found)
        assertTrue("icono: ${found!!.icons.size}", found.icons.isNotEmpty())
        val icon = found.icons.first()
        assertTrue(icon[0] <= 32 && icon[2] >= 70 && icon[1] <= 44 && icon[3] >= 86)
        val kept = ScanBars.trimWords(listOf("AA)" to intArrayOf(36, 55, 100, 75), "Transición" to intArrayOf(110, 55, 205, 75)), found.icons)
        assertEquals(listOf("A)", "Transición"), kept.map { it.first })
    }

    @Test
    fun textoEnPapelNoEsBarra() {
        val w = 300; val h = 100
        val px = page(w, h)
        for (k in 0 until 10) for (y in 40 until 56) for (x in 40 + k * 11 until 46 + k * 11) px[y * w + x] = 0xFF202020.toInt()
        assertNull(ScanBars.find(px, w, h, white, intArrayOf(38, 38, 152, 58), emptyList(), 0xFF202020.toInt()))
    }

    @Test
    fun fotoConTexturaNoEsBarra() {
        val w = 300; val h = 120
        val random = java.util.Random(3)
        val px = IntArray(w * h) { i ->
            val y = i / w
            if (y in 40 until 76) {
                val v = 60 + random.nextInt(120)
                -0x1000000 or (v shl 16) or ((v * 8 / 10) shl 8) or (v / 2)
            } else white
        }
        letters(px, w, 40, 160, 50, 66)
        assertNull(ScanBars.find(px, w, h, white, intArrayOf(38, 48, 162, 68), emptyList(), white))
    }

    @Test
    fun tramosPorFondo() {
        val boxes = listOf(intArrayOf(0, 0, 50, 20), intArrayOf(60, 0, 120, 20), intArrayOf(130, 0, 200, 20), intArrayOf(210, 0, 260, 20))
        val segments = ScanBars.segments(listOf(navy, navy, null, null), boxes)
        assertEquals(listOf(listOf(0, 1), listOf(2, 3)), segments)
    }
}
