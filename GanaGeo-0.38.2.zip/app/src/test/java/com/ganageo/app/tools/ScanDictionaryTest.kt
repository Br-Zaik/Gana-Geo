package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanDictionaryTest {
    private val dictionary = ScanDictionary(
        listOf("completo", "control", "controles", "iniciacion", "iniciación", "minera", "paco", "peligro", "voladura")
            .sorted().joinToString("\n") + "\n"
    )

    @Test
    fun buscaPalabras() {
        assertTrue(dictionary.contains("minera"))
        assertTrue(dictionary.contains("iniciación"))
        assertFalse(dictionary.contains("miner"))
        assertFalse(dictionary.contains("mineras"))
        assertEquals(9, dictionary.size)
    }

    @Test
    fun corrigeErroresTipicosDeLectura() {
        assertEquals("completo", dictionary.correct("cornpleto"))
        assertEquals("control", dictionary.correct("contro1"))
        assertEquals("peligro", dictionary.correct("pel1gro"))
        assertEquals("PELIGRO", dictionary.correct("PEL1GRO"))
        assertEquals("iniciación", dictionary.correct("iniciacion"))
    }

    @Test
    fun noTocaNombresNiCodigos() {
        assertEquals("Pacco", dictionary.correct("Pacco"))
        assertEquals("WebGen", dictionary.correct("WebGen"))
        assertEquals("2026", dictionary.correct("2026"))
        assertEquals("EPP", dictionary.correct("EPP"))
        assertEquals("huayhua", dictionary.correct("huayhua"))
    }

    @Test
    fun corrigeDentroDeUnTextoConSignos() {
        assertEquals("La voladura (minera) y el peligro.", dictionary.fixText("La vo1adura (minera) y el pel1gro."))
    }
}
