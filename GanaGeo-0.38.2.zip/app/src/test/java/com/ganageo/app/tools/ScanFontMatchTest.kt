package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanFontMatchTest {
    private fun rgb(r: Int, g: Int, b: Int): Int = -0x1000000 or (r shl 16) or (g shl 8) or b

    @Test
    fun encuentraElBordeDeLaTintaSinElRenglonVecino() {
        val width = 40
        val height = 30
        val white = rgb(255, 255, 255)
        val black = rgb(0, 0, 0)
        val pixels = IntArray(width * height) { white }
        for (y in 10 until 22) for (x in 5 until 35) pixels[y * width + x] = black // renglón
        for (x in 8 until 12) pixels[0 * width + x] = black // pedazo del renglón de arriba
        val map = ScanFontMatch.inkMap(pixels, width, height, white, black)
        val bounds = ScanFontMatch.inkBounds(map, width, height)!!
        assertEquals(listOf(5, 10, 35, 22), bounds.toList())
    }

    @Test
    fun formasIgualesSeParecenMasQueDistintas() {
        val a = FloatArray(16) { if (it % 2 == 0) 1f else 0f }
        val b = FloatArray(16) { if (it % 2 == 0) 1f else 0f }
        val c = FloatArray(16) { if (it % 2 == 1) 1f else 0f }
        assertEquals(1f, ScanFontMatch.similarity(a, b), 0.001f)
        assertEquals(0f, ScanFontMatch.similarity(a, c), 0.001f)
        assertTrue(ScanFontMatch.score(0.8f, 1f) > ScanFontMatch.score(0.8f, 1.4f))
    }

    @Test
    fun quitaTildesParaMedir() {
        assertEquals("Explotacion Mineria", ScanFontMatch.withoutMarks("Explotación Minería"))
    }
}
