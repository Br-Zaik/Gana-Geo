package com.ganageo.app.tools

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanDocxTest {
    private fun entries(bytes: ByteArray): Map<String, String> {
        val map = LinkedHashMap<String, String>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                map[entry.name] = String(zip.readBytes(), Charsets.UTF_8)
            }
        }
        return map
    }

    private fun sample(): Map<String, String> {
        val page = ScanDocx.Page(
            595f, 842f,
            listOf(ScanDocx.Shape(0f, 0f, 200f, 842f, 0xFF0B2545.toInt(), 0f), ScanDocx.Shape(220f, 100f, 300f, 40f, 0xFFEEEEEE.toInt(), 10f)),
            listOf(ScanDocx.Image(byteArrayOf(1, 2, 3), true, 10f, 10f, 50f, 50f)),
            listOf(
                ScanDocx.TextBox(220f, 60f, 300f, 30f, listOf("TÍTULO & <Más>"), "Arial", 24f, true, false, 0xFF222222.toInt(), "left", 28f, singleLine = true),
                ScanDocx.TextBox(220f, 160f, 300f, 60f, listOf("Uno", "Dos"), "Calibri", 11f, false, true, 0xFF000000.toInt(), "both", 14f, scalePercent = 90)
            )
        )
        val out = ByteArrayOutputStream()
        ScanDocx.write(out, listOf(page, page))
        return entries(out.toByteArray())
    }

    @Test
    fun archivoTieneLasPartesDeWord() {
        val files = sample()
        for (name in listOf("[Content_Types].xml", "_rels/.rels", "word/document.xml", "word/_rels/document.xml.rels")) {
            assertTrue("falta $name", files.containsKey(name))
        }
        assertEquals(2, files.keys.count { it.startsWith("word/media/") })
    }

    @Test
    fun textoEscapadoYUnSoloRenglon() {
        val doc = sample().getValue("word/document.xml")
        assertTrue(doc.contains("TÍTULO &amp; &lt;Más&gt;"))
        assertTrue(doc.contains("wrap=\"none\""))
        assertTrue(doc.contains("wrap=\"square\""))
        assertTrue(doc.contains("<w:w w:val=\"90\"/>"))
    }

    @Test
    fun tamanoDeHojaYFormas() {
        val doc = sample().getValue("word/document.xml")
        // 595 pt = 11900 twips
        assertTrue(doc.contains("w:w=\"11900\""))
        assertTrue(doc.contains("roundRect"))
        assertTrue(doc.contains("0B2545"))
    }

    @Test
    fun imagenGiradaLlevaSuGiro() {
        val page = ScanDocx.Page(
            595f, 842f, emptyList(),
            listOf(ScanDocx.Image(byteArrayOf(1, 2, 3), true, 10f, 10f, 50f, 20f, 90f), ScanDocx.Image(byteArrayOf(1), true, 0f, 0f, 5f, 5f, -30f)),
            emptyList()
        )
        val out = ByteArrayOutputStream()
        ScanDocx.write(out, listOf(page))
        val xml = entries(out.toByteArray())["word/document.xml"]!!
        assertTrue(xml.contains("rot=\"5400000\""))
        // -30° = 330°.
        assertTrue(xml.contains("rot=\"19800000\""))
    }

    @Test
    fun tablaConCeldaUnidaHaciaAbajo() {
        val table = ScanDocx.Table(
            0f, 0f, listOf(60f, 60f), listOf(18f, 18f, 18f),
            listOf(
                ScanDocx.TableCell(0, 0, 1, "8:00", false, false, 0, "left", null),
                ScanDocx.TableCell(0, 1, 1, "Software", false, false, 0, "center", null, rowSpan = 3),
                ScanDocx.TableCell(1, 0, 1, "8:45", false, false, 0, "left", null),
                ScanDocx.TableCell(2, 0, 1, "9:30", false, false, 0, "left", null)
            ),
            "Arial", 11f, 0, 1f, List(4) { List(2) { true } }, List(3) { List(3) { true } }
        )
        val xml = ScanDocx.tableXml(table, floating = false)
        assertEquals(1, Regex("w:vMerge w:val=\"restart\"").findAll(xml).count())
        assertEquals(2, Regex("<w:vMerge/>").findAll(xml).count())
        // Cada fila tiene sus 2 celdas.
        assertEquals(6, Regex("<w:tc>").findAll(xml).count())
    }
}
