package com.ganageo.app.ui.tools

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Bitmap
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyListItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CropFree
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.ganageo.app.GanaGeoViewModel
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.AdvancedFileUtils
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.PageSelectionParser
import com.ganageo.app.tools.PdfMargin
import com.ganageo.app.tools.PdfOrientation
import com.ganageo.app.tools.PdfPaperSize
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt
import java.io.File
import java.util.UUID
import org.json.JSONObject

@Composable
fun DocumentScannerScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var editorUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var galleryImages by remember { mutableStateOf<List<ScannerGalleryImage>>(emptyList()) }
    var galleryLoading by remember { mutableStateOf(false) }
    var galleryRefresh by remember { mutableIntStateOf(0) }
    val galleryGridState = rememberLazyGridState()
    var mode by remember { mutableIntStateOf(0) } // 0 = imagen, 1 = OCR, 2 = recrear
    var zoneMode by remember { mutableStateOf(false) }
    var selection by remember { mutableStateOf(ScannerSelection()) }
    var ocrText by remember { mutableStateOf("") }
    var ocrBusy by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var openingImage by remember { mutableStateOf(false) }
    var recreateDocument by remember { mutableStateOf<ScannerRecreateDocument?>(null) }
    var recreateLoading by remember { mutableStateOf(false) }
    var recreateError by remember { mutableStateOf<String?>(null) }
    var recreateRefresh by remember { mutableIntStateOf(0) }
    var recreateSelectedLineId by remember { mutableStateOf<Int?>(null) }
    var pendingRecreateSave by remember { mutableStateOf<ScannerRecreateDocument?>(null) }

    fun openScannerEditor(uri: Uri) {
        if (openingImage || saving || ocrBusy) return
        openingImage = true
        scope.launch {
            try {
                if (scannerUriReadable(context, uri)) {
                    editorUri = uri
                    mode = 0
                    zoneMode = false
                    selection = ScannerSelection()
                    ocrText = ""
                    recreateDocument = null
                    recreateError = null
                    recreateSelectedLineId = null
                } else {
                    onMessage("Ya no se puede acceder a esta imagen. Elige otra foto.")
                }
            } finally {
                openingImage = false
            }
        }
    }

    val systemPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            openScannerEditor(uri)
        }
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val captured = pendingCameraUri
        pendingCameraUri = null
        if (ok && captured != null) {
            openScannerEditor(captured)
        }
    }

    fun openCamera() {
        if (saving || ocrBusy) return
        runCatching {
            val uri = ToolFileUtils.createCameraImageUri(context)
            pendingCameraUri = uri
            camera.launch(uri)
        }.onFailure {
            pendingCameraUri = null
            onMessage(it.message ?: "No se pudo abrir la cámara")
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openCamera() else onMessage("Se necesita permiso de cámara")
    }

    val galleryPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        galleryRefresh++
    }

    val saveRecreatedImage = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { output ->
        val document = pendingRecreateSave
        pendingRecreateSave = null
        if (output == null || document == null) return@rememberLauncherForActivityResult
        saving = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                withContext(Dispatchers.IO) {
                    val recreated = renderScannerRecreateDocumentBitmap(document, SCANNER_RECREATE_OUTPUT_MAX_EDGE)
                    try {
                        context.contentResolver.openOutputStream(output, "w")?.use { stream ->
                            check(recreated.compress(Bitmap.CompressFormat.PNG, 100, stream)) { "No se pudo guardar la imagen" }
                        } ?: error("No se pudo crear el archivo")
                    } finally {
                        if (!recreated.isRecycled) recreated.recycle()
                    }
                }
            }.onSuccess {
                onMessage(successMessage("Imagen recreada guardada", it))
            }.onFailure {
                onMessage(it.message ?: "No se pudo guardar la imagen")
            }
            saving = false
        }
    }

    BackHandler(enabled = editorUri != null || mode != 0) {
        if (mode != 0) {
            mode = 0
            zoneMode = false
            ocrText = ""
        } else {
            editorUri = null
        }
    }

    val galleryGranted = scannerGalleryPermissionGranted(context)
    LaunchedEffect(galleryGranted, galleryRefresh) {
        if (galleryGranted) {
            galleryLoading = true
            galleryImages = try {
                loadScannerRecentImages(context, SCANNER_GALLERY_RECENT_LIMIT)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                onMessage("No se pudieron cargar las fotos recientes")
                emptyList()
            }
            galleryLoading = false
        } else {
            galleryImages = emptyList()
        }
    }

    LaunchedEffect(Unit) {
        if (!scannerGalleryPermissionGranted(context)) {
            galleryPermissionLauncher.launch(scannerGalleryPermissions())
        }
    }

    val currentUri = editorUri
    if (currentUri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Elige una foto para escanear o extraer texto", onBack)
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                openCamera()
                            } else {
                                cameraPermission.launch(Manifest.permission.CAMERA)
                            }
                        },
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) {
                        Icon(Icons.Rounded.AddAPhoto, null)
                        Text("  Cámara")
                    }
                    OutlinedButton(
                        onClick = { systemPicker.launch(arrayOf("image/*")) },
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) {
                        Icon(Icons.Rounded.Folder, null)
                        Text("  Archivos")
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Últimas 15 imágenes", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    if (galleryGranted) {
                        IconButton(onClick = { galleryRefresh++ }) {
                            Icon(Icons.Rounded.Refresh, "Actualizar")
                        }
                    }
                }
            }

            when {
                !galleryGranted -> {
                    Box(Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.TopCenter) {
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                            Column(
                                Modifier.fillMaxWidth().padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Rounded.PhotoLibrary, null, tint = NeonGreen)
                                Text("Permite acceso a tus fotos para mostrarlas aquí.", textAlign = TextAlign.Center)
                                Button(
                                    onClick = { galleryPermissionLauncher.launch(scannerGalleryPermissions()) },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                                ) { Text("Permitir fotos", fontWeight = FontWeight.Bold) }
                                Text("También puedes usar Archivos sin dar acceso permanente.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
                galleryLoading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NeonGreen)
                    }
                }
                galleryImages.isEmpty() -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No se encontraron imágenes", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                else -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        state = galleryGridState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 10.dp, end = 10.dp, bottom = 28.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(galleryImages, key = { it.uri.toString() }) { item ->
                            ScannerGalleryThumbnail(item) {
                                openScannerEditor(item.uri)
                            }
                        }
                    }
                }
            }
        }
        return
    }

    var sourceLoadFailed by remember(currentUri) { mutableStateOf(false) }
    val sourceBitmap by produceState<Bitmap?>(initialValue = null, currentUri, mode) {
        sourceLoadFailed = false
        if (mode == 2) {
            value = null
            return@produceState
        }
        value = try {
            ToolFileUtils.loadBitmap(context, currentUri, SCANNER_EDITOR_PREVIEW_MAX_EDGE)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Throwable) {
            sourceLoadFailed = true
            null
        }
    }

    LaunchedEffect(currentUri, mode, recreateRefresh) {
        if (mode == 2 && recreateDocument == null && !recreateLoading) {
            recreateLoading = true
            recreateError = null
            recreateSelectedLineId = null
            recreateDocument = try {
                scannerBuildRecreateDocument(context, currentUri, SCANNER_RECREATE_ANALYSIS_MAX_EDGE)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                recreateError = error.message ?: "No se pudo reconstruir la imagen"
                null
            }
            recreateLoading = false
        }
    }

    if (mode == 2) {
        ScannerRecreateEditorScreen(
            document = recreateDocument,
            loading = recreateLoading,
            error = recreateError,
            onDocumentChange = { recreateDocument = it },
            saving = saving,
            onBack = {
                mode = 0
                recreateSelectedLineId = null
            },
            onRetry = {
                recreateDocument = null
                recreateError = null
                recreateLoading = false
                recreateRefresh++
            },
            onSave = { document ->
                val base = runCatching { ToolFileUtils.displayName(context, currentUri) }.getOrDefault("escaneo")
                    .substringBeforeLast('.').replace(Regex("[\\/:*?\"<>|]"), "_").take(60)
                launchPaidExport(viewModel, tool, onMessage) {
                    pendingRecreateSave = document
                    saveRecreatedImage.launch("${base}_recreada.png")
                }
            }
        )
        return
    }

    val bitmapToShow = sourceBitmap
    val clipboard = context.getSystemService(android.content.ClipboardManager::class.java)

    Column(Modifier.fillMaxSize()) {
        ToolHeader(
            tool.title,
            when {
                mode == 1 && zoneMode -> "Ajusta el cuadro sobre el texto"
                mode == 1 -> "OCR: copia o edita el texto reconocido"
                else -> "Trabaja sobre la imagen seleccionada"
            }
        ) {
            if (mode != 0) {
                mode = 0
                zoneMode = false
                ocrText = ""
            } else {
                editorUri = null
            }
        }

        Box(
            modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF101412)),
            contentAlignment = Alignment.Center
        ) {
            if (bitmapToShow == null) {
                if (sourceLoadFailed) {
                    Text("No se pudo abrir o procesar esta imagen", color = Color.White)
                } else {
                    CircularProgressIndicator(color = NeonGreen)
                }
            } else {
                ScannerImageViewport(
                    bitmap = bitmapToShow!!,
                    selectionEnabled = mode == 1 && zoneMode,
                    selection = selection,
                    onSelectionChange = { selection = it },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = CardGreen),
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp, bottomEnd = 0.dp, bottomStart = 0.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                Modifier.fillMaxWidth().padding(14.dp).heightIn(max = 330.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            mode = 1
                            zoneMode = false
                            ocrText = ""
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (mode == 1) NeonGreen else Color(0xFF244A37),
                            contentColor = if (mode == 1) DeepGreen else Color.White
                        )
                    ) {
                        Icon(Icons.Rounded.TextFields, null)
                        Text("  Extraer texto")
                    }
                    Button(
                        onClick = {
                            mode = 2
                            zoneMode = false
                            ocrText = ""
                            recreateDocument = null
                            recreateError = null
                            recreateSelectedLineId = null
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (mode == 2) NeonGreen else Color(0xFF244A37),
                            contentColor = if (mode == 2) DeepGreen else Color.White
                        )
                    ) {
                        Icon(Icons.Rounded.AutoFixHigh, null)
                        Text("  Recrear imagen")
                    }
                }

                if (mode == 1) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                zoneMode = false
                                launchPaidExport(viewModel, tool, onMessage) {
                                    ocrBusy = true
                                    scope.launch {
                                        var recognized = ""
                                        runPaidTool(viewModel, tool) {
                                            recognized = scannerOcr(context, currentUri, null)
                                            require(recognized.isNotBlank()) { "No se detectó texto." }
                                        }.onSuccess { reward ->
                                            ocrText = recognized
                                            if (reward > 0) onMessage("Texto extraído. Ganaste $reward Geo Rewards.")
                                        }.onFailure { error ->
                                            if (recognized.isNotBlank()) ocrText = recognized
                                            onMessage(error.message ?: "No se pudo reconocer el texto")
                                        }
                                        ocrBusy = false
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            enabled = !ocrBusy
                        ) { Text("Toda la imagen · ${tool.creditCost}") }
                        OutlinedButton(
                            onClick = {
                                zoneMode = true
                                ocrText = ""
                            },
                            modifier = Modifier.weight(1f),
                            enabled = !ocrBusy
                        ) { Text("Seleccionar zona") }
                    }

                    if (zoneMode) {
                        Button(
                            onClick = {
                                launchPaidExport(viewModel, tool, onMessage) {
                                    ocrBusy = true
                                    scope.launch {
                                        var recognized = ""
                                        runPaidTool(viewModel, tool) {
                                            recognized = scannerOcr(context, currentUri, selection)
                                            require(recognized.isNotBlank()) { "No se detectó texto en la zona." }
                                        }.onSuccess { reward ->
                                            ocrText = recognized
                                            if (reward > 0) onMessage("Texto extraído. Ganaste $reward Geo Rewards.")
                                        }.onFailure { error ->
                                            if (recognized.isNotBlank()) ocrText = recognized
                                            onMessage(error.message ?: "No se pudo reconocer el texto")
                                        }
                                        ocrBusy = false
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !ocrBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) {
                            Icon(Icons.Rounded.CropFree, null)
                            Text("  Extraer zona · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
                        }
                    }

                    if (ocrBusy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

                    if (ocrText.isNotBlank()) {
                        OutlinedTextField(
                            value = ocrText,
                            onValueChange = { ocrText = it },
                            label = { Text("Texto reconocido · editable") },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 190.dp)
                        )
                        Button(
                            onClick = {
                                clipboard?.setPrimaryClip(android.content.ClipData.newPlainText("Texto escaneado", ocrText))
                                onMessage("Texto copiado")
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) {
                            Icon(Icons.Rounded.ContentCopy, null)
                            Text("  Copiar texto", fontWeight = FontWeight.Bold)
                        }
                    }
                }

            }
        }
    }
}

private const val SCANNER_GALLERY_RECENT_LIMIT = 15
private const val SCANNER_GALLERY_THUMBNAIL_SIZE = 256
private const val SCANNER_GALLERY_CACHE_BYTES = 6 * 1024 * 1024
private const val SCANNER_EDITOR_PREVIEW_MAX_EDGE = 1440
private const val SCANNER_OCR_MAX_EDGE = 2048
private const val SCANNER_RECREATE_ANALYSIS_MAX_EDGE = 1800
private const val SCANNER_RECREATE_OUTPUT_MAX_EDGE = 2400

private data class ScannerGalleryImage(val uri: Uri, val name: String)

private val scannerThumbnailSemaphore = Semaphore(3)
private val scannerThumbnailCache = object : android.util.LruCache<String, Bitmap>(SCANNER_GALLERY_CACHE_BYTES) {
    override fun sizeOf(key: String, value: Bitmap): Int = runCatching { value.allocationByteCount }.getOrDefault(value.byteCount)
}

private data class ScannerSelection(
    val left: Float = 0.10f,
    val top: Float = 0.20f,
    val right: Float = 0.90f,
    val bottom: Float = 0.62f
)

private enum class ScannerDragMode { MOVE, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }

private fun scannerGalleryPermissions(): Array<String> = when {
    android.os.Build.VERSION.SDK_INT >= 34 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
    )
    android.os.Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

private fun scannerGalleryPermissionGranted(context: android.content.Context): Boolean = when {
    android.os.Build.VERSION.SDK_INT >= 34 -> {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
    }
    android.os.Build.VERSION.SDK_INT >= 33 ->
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
    else -> ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
}

private suspend fun loadScannerRecentImages(
    context: android.content.Context,
    limit: Int
): List<ScannerGalleryImage> = withContext(Dispatchers.IO) {
    val safeLimit = limit.coerceIn(1, SCANNER_GALLERY_RECENT_LIMIT)
    val collection = if (android.os.Build.VERSION.SDK_INT >= 29) {
        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
    } else {
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    }
    val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
    val result = ArrayList<ScannerGalleryImage>(safeLimit)
    context.contentResolver.query(
        collection,
        projection,
        null,
        null,
        "${MediaStore.Images.Media.DATE_ADDED} DESC"
    )?.use { cursor ->
        val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        val nameColumn = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
        while (result.size < safeLimit && cursor.moveToNext()) {
            val id = cursor.getLong(idColumn)
            val uri = android.content.ContentUris.withAppendedId(collection, id)
            val name = if (nameColumn >= 0) cursor.getString(nameColumn).orEmpty() else ""
            result += ScannerGalleryImage(uri, name)
        }
    }
    result
}

private suspend fun loadScannerThumbnail(context: android.content.Context, uri: Uri): Bitmap = withContext(Dispatchers.IO) {
    val key = uri.toString()
    synchronized(scannerThumbnailCache) {
        scannerThumbnailCache.get(key)?.takeIf { !it.isRecycled }
    }?.let { return@withContext it }

    scannerThumbnailSemaphore.withPermit {
        synchronized(scannerThumbnailCache) {
            scannerThumbnailCache.get(key)?.takeIf { !it.isRecycled }
        }?.let { return@withPermit it }

        val decoded = if (android.os.Build.VERSION.SDK_INT >= 29) {
            context.contentResolver.loadThumbnail(
                uri,
                android.util.Size(SCANNER_GALLERY_THUMBNAIL_SIZE, SCANNER_GALLERY_THUMBNAIL_SIZE),
                null
            )
        } else {
            ToolFileUtils.loadBitmap(context, uri, SCANNER_GALLERY_THUMBNAIL_SIZE)
        }
        synchronized(scannerThumbnailCache) {
            scannerThumbnailCache.put(key, decoded)
        }
        decoded
    }
}

@Composable
private fun ScannerGalleryThumbnail(item: ScannerGalleryImage, onClick: () -> Unit) {
    val context = LocalContext.current
    var attempted by remember(item.uri) { mutableStateOf(false) }
    val bitmap by produceState<Bitmap?>(initialValue = null, item.uri) {
        value = runCatching { loadScannerThumbnail(context, item.uri) }.getOrNull()
        attempted = true
    }
    Box(
        modifier = Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp)).background(Color(0xFF163324)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap == null) {
            if (attempted) {
                Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, tint = Color.White.copy(alpha = 0.55f))
            } else {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = NeonGreen)
            }
        } else {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = item.name.ifBlank { "Foto" },
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
    }
}

@Composable
private fun ScannerImageViewport(
    bitmap: Bitmap,
    selectionEnabled: Boolean,
    selection: ScannerSelection,
    onSelectionChange: (ScannerSelection) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember(bitmap) { mutableFloatStateOf(1f) }
    var offsetX by remember(bitmap) { mutableFloatStateOf(0f) }
    var offsetY by remember(bitmap) { mutableFloatStateOf(0f) }
    val currentSelection by rememberUpdatedState(selection)
    val currentOnSelectionChange by rememberUpdatedState(onSelectionChange)
    LaunchedEffect(selectionEnabled) {
        if (selectionEnabled) {
            scale = 1f
            offsetX = 0f
            offsetY = 0f
        }
    }

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val maxW = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val maxH = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val fit = minOf(maxW / bitmap.width.toFloat(), maxH / bitmap.height.toFloat())
        val imageW = bitmap.width * fit
        val imageH = bitmap.height * fit
        val imageLeft = (maxW - imageW) / 2f
        val imageTop = (maxH - imageH) / 2f

        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Imagen seleccionada",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offsetX
                    translationY = offsetY
                }
                .then(
                    if (!selectionEnabled) {
                        Modifier.pointerInput(bitmap) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val newScale = (scale * zoom).coerceIn(1f, 5f)
                                scale = newScale
                                val limitX = ((maxW * newScale - maxW) / 2f).coerceAtLeast(0f)
                                val limitY = ((maxH * newScale - maxH) / 2f).coerceAtLeast(0f)
                                offsetX = (offsetX + pan.x).coerceIn(-limitX, limitX)
                                offsetY = (offsetY + pan.y).coerceIn(-limitY, limitY)
                            }
                        }
                    } else Modifier
                )
        )

        if (selectionEnabled) {
            var dragMode by remember { mutableStateOf<ScannerDragMode?>(null) }
            val handleRadius = 34f
            Canvas(
                modifier = Modifier.fillMaxSize().pointerInput(imageW, imageH, imageLeft, imageTop) {
                    detectDragGestures(
                        onDragStart = { p ->
                            fun pointX(v: Float) = imageLeft + v * imageW
                            fun pointY(v: Float) = imageTop + v * imageH
                            val s = currentSelection
                            val corners = listOf(
                                ScannerDragMode.TOP_LEFT to Offset(pointX(s.left), pointY(s.top)),
                                ScannerDragMode.TOP_RIGHT to Offset(pointX(s.right), pointY(s.top)),
                                ScannerDragMode.BOTTOM_LEFT to Offset(pointX(s.left), pointY(s.bottom)),
                                ScannerDragMode.BOTTOM_RIGHT to Offset(pointX(s.right), pointY(s.bottom))
                            )
                            dragMode = corners.minByOrNull { (_, c) -> (p - c).getDistance() }
                                ?.takeIf { (_, c) -> (p - c).getDistance() <= handleRadius * 1.5f }?.first
                                ?: if (
                                    p.x in pointX(s.left)..pointX(s.right) &&
                                    p.y in pointY(s.top)..pointY(s.bottom)
                                ) ScannerDragMode.MOVE else null
                        },
                        onDragEnd = { dragMode = null },
                        onDragCancel = { dragMode = null }
                    ) { _, drag ->
                        val dx = drag.x / imageW
                        val dy = drag.y / imageH
                        val s = currentSelection
                        val minSize = 0.06f
                        val next = when (dragMode) {
                            ScannerDragMode.MOVE -> {
                                val width = s.right - s.left
                                val height = s.bottom - s.top
                                val l = (s.left + dx).coerceIn(0f, 1f - width)
                                val t = (s.top + dy).coerceIn(0f, 1f - height)
                                ScannerSelection(l, t, l + width, t + height)
                            }
                            ScannerDragMode.TOP_LEFT -> s.copy(
                                left = (s.left + dx).coerceIn(0f, s.right - minSize),
                                top = (s.top + dy).coerceIn(0f, s.bottom - minSize)
                            )
                            ScannerDragMode.TOP_RIGHT -> s.copy(
                                right = (s.right + dx).coerceIn(s.left + minSize, 1f),
                                top = (s.top + dy).coerceIn(0f, s.bottom - minSize)
                            )
                            ScannerDragMode.BOTTOM_LEFT -> s.copy(
                                left = (s.left + dx).coerceIn(0f, s.right - minSize),
                                bottom = (s.bottom + dy).coerceIn(s.top + minSize, 1f)
                            )
                            ScannerDragMode.BOTTOM_RIGHT -> s.copy(
                                right = (s.right + dx).coerceIn(s.left + minSize, 1f),
                                bottom = (s.bottom + dy).coerceIn(s.top + minSize, 1f)
                            )
                            null -> s
                        }
                        if (next != s) currentOnSelectionChange(next)
                    }
                }
            ) {
                val s = selection
                val l = imageLeft + s.left * imageW
                val t = imageTop + s.top * imageH
                val r = imageLeft + s.right * imageW
                val b = imageTop + s.bottom * imageH
                val shade = Color.Black.copy(alpha = 0.48f)
                drawRect(shade, Offset(imageLeft, imageTop), androidx.compose.ui.geometry.Size(imageW, (t - imageTop).coerceAtLeast(0f)))
                drawRect(shade, Offset(imageLeft, b), androidx.compose.ui.geometry.Size(imageW, (imageTop + imageH - b).coerceAtLeast(0f)))
                drawRect(shade, Offset(imageLeft, t), androidx.compose.ui.geometry.Size((l - imageLeft).coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))
                drawRect(shade, Offset(r, t), androidx.compose.ui.geometry.Size((imageLeft + imageW - r).coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))
                drawRect(
                    color = NeonGreen,
                    topLeft = Offset(l, t),
                    size = androidx.compose.ui.geometry.Size((r - l).coerceAtLeast(1f), (b - t).coerceAtLeast(1f)),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                )
                listOf(Offset(l, t), Offset(r, t), Offset(l, b), Offset(r, b)).forEach {
                    drawCircle(Color.White, radius = 13f, center = it)
                    drawCircle(NeonGreen, radius = 9f, center = it)
                }
            }
        }
    }
}

private suspend fun scannerUriReadable(context: android.content.Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
    try {
        context.contentResolver.openInputStream(uri)?.use { true } ?: false
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (_: Throwable) {
        false
    }
}

private data class ScannerRecognizedLine(
    val text: String,
    val bounds: android.graphics.Rect
)

private data class ScannerRecreateLine(
    val id: Int,
    val text: String,
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
    val fontScale: Float = 1f,
    val bold: Boolean = false
)

private data class ScannerRecreateDocument(
    val aspectRatio: Float,
    val body: String,
    val fontSize: Float = 16f,
    val fontFamilyIndex: Int = 0,
    val bold: Boolean = false,
    val underlined: Boolean = false
)

private fun scannerComposeFontFamily(index: Int): FontFamily = when (index.mod(3)) {
    1 -> FontFamily.Serif
    2 -> FontFamily.Monospace
    else -> FontFamily.SansSerif
}

private fun scannerFontFamilyLabel(index: Int): String = when (index.mod(3)) {
    1 -> "Serif"
    2 -> "Mono"
    else -> "Sans"
}

private fun scannerTypeface(index: Int, bold: Boolean): android.graphics.Typeface {
    val family = when (index.mod(3)) {
        1 -> android.graphics.Typeface.SERIF
        2 -> android.graphics.Typeface.MONOSPACE
        else -> android.graphics.Typeface.SANS_SERIF
    }
    return android.graphics.Typeface.create(
        family,
        if (bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL
    )
}

@Composable
private fun ScannerRecreateEditorScreen(
    document: ScannerRecreateDocument?,
    loading: Boolean,
    error: String?,
    onDocumentChange: (ScannerRecreateDocument) -> Unit,
    saving: Boolean,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    onSave: (ScannerRecreateDocument) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        ToolHeader("Recrear imagen", "Corrige el texto en una hoja completa y guarda la imagen", onBack)

        when {
            loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(color = NeonGreen)
                    Text("Reconstruyendo el documento…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            document == null -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
                    Column(
                        Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(error ?: "No se pudo reconstruir la imagen", color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
                        OutlinedButton(onClick = onRetry) { Text("Reintentar") }
                    }
                }
            }
            else -> {
                val editorScroll = rememberScrollState()
                val fontFamily = scannerComposeFontFamily(document.fontFamilyIndex)
                BoxWithConstraints(
                    modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF101412)),
                    contentAlignment = Alignment.Center
                ) {
                    val availableRatio = (maxWidth.value / maxHeight.value.coerceAtLeast(1f)).coerceAtLeast(0.01f)
                    val pageRatio = document.aspectRatio.coerceIn(0.35f, 2.8f)
                    val pageWidth = if (pageRatio >= availableRatio) maxWidth.value * 0.95f else maxHeight.value * 0.95f * pageRatio
                    val pageHeight = pageWidth / pageRatio
                    Box(
                        modifier = Modifier
                            .width(pageWidth.dp)
                            .height(pageHeight.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.White)
                            .padding(18.dp)
                    ) {
                        BasicTextField(
                            value = document.body,
                            onValueChange = { value ->
                                onDocumentChange(document.copy(body = value.take(18_000)))
                            },
                            modifier = Modifier.fillMaxSize().verticalScroll(editorScroll),
                            textStyle = MaterialTheme.typography.bodyLarge.copy(
                                color = Color.Black,
                                fontSize = document.fontSize.sp,
                                lineHeight = (document.fontSize * 1.45f).sp,
                                fontWeight = if (document.bold) FontWeight.Bold else FontWeight.Normal,
                                fontFamily = fontFamily,
                                textDecoration = if (document.underlined) TextDecoration.Underline else TextDecoration.None
                            ),
                            decorationBox = { inner ->
                                if (document.body.isBlank()) {
                                    Text(
                                        "Corrige o escribe aquí…",
                                        color = Color.Gray,
                                        fontSize = document.fontSize.sp,
                                        fontFamily = fontFamily,
                                        textDecoration = if (document.underlined) TextDecoration.Underline else TextDecoration.None
                                    )
                                }
                                inner()
                            }
                        )
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = CardGreen),
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = { onDocumentChange(document.copy(fontSize = (document.fontSize - 1f).coerceAtLeast(10f))) },
                                modifier = Modifier.weight(1f)
                            ) { Text("A−") }
                            OutlinedButton(
                                onClick = { onDocumentChange(document.copy(fontSize = (document.fontSize + 1f).coerceAtMost(26f))) },
                                modifier = Modifier.weight(1f)
                            ) { Text("A+") }
                            OutlinedButton(
                                onClick = { onDocumentChange(document.copy(fontFamilyIndex = (document.fontFamilyIndex + 1) % 3)) },
                                modifier = Modifier.weight(1f)
                            ) { Text(scannerFontFamilyLabel(document.fontFamilyIndex)) }
                            OutlinedButton(
                                onClick = { onDocumentChange(document.copy(bold = !document.bold)) },
                                modifier = Modifier.weight(1f)
                            ) { Text(if (document.bold) "Negrita" else "Normal") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = { onDocumentChange(document.copy(underlined = !document.underlined)) },
                                modifier = Modifier.weight(1f)
                            ) { Text(if (document.underlined) "Subrayado" else "Sin subrayar") }
                            Text(
                                "${document.body.length} caracteres",
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.End
                            )
                        }
                        Button(
                            onClick = { onSave(document) },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !saving && document.body.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) {
                            Icon(Icons.Rounded.Save, null)
                            Text(if (saving) "  Guardando…" else "  Guardar imagen", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

private suspend fun scannerBuildRecreateDocument(
    context: android.content.Context,
    uri: Uri,
    maxEdge: Int
): ScannerRecreateDocument = withContext(Dispatchers.IO) {
    val source = ToolFileUtils.loadBitmap(context, uri, maxEdge)
    val sourceWidth = source.width
    val sourceHeight = source.height
    val croppedCandidate = runCatching { AdvancedFileUtils.autoDocumentCrop(source) }.getOrNull()
    val working = when {
        croppedCandidate == null -> source.copy(source.config ?: Bitmap.Config.ARGB_8888, false)
        croppedCandidate === source -> source.copy(source.config ?: Bitmap.Config.ARGB_8888, false)
        else -> croppedCandidate
    }
    val significantCrop = working.width < sourceWidth * 0.94f || working.height < sourceHeight * 0.94f
    if (working !== source && !source.isRecycled) source.recycle()

    try {
        val enhanced = runCatching {
            ToolFileUtils.applyImageAdjustments(
                working,
                DocumentImageFilter.ENHANCE,
                brightness = 3,
                contrast = 1.12f
            )
        }.getOrNull()
        try {
            val recognitionBitmap = enhanced ?: working
            var lines = scannerRecognizeLines(recognitionBitmap)
            if (lines.isEmpty() && recognitionBitmap !== working) {
                lines = scannerRecognizeLines(working)
            }
            lines = filterScannerRecreateLines(lines, working.width, working.height)
            require(lines.isNotEmpty()) { "No se detectó texto para recrear." }

            val textBounds = scannerUnionBounds(lines.map { it.bounds })
            val leftMargin = textBounds.left.toFloat() / working.width.coerceAtLeast(1)
            val topMargin = textBounds.top.toFloat() / working.height.coerceAtLeast(1)
            val rightMargin = (working.width - textBounds.right).toFloat() / working.width.coerceAtLeast(1)
            val bottomMargin = (working.height - textBounds.bottom).toFloat() / working.height.coerceAtLeast(1)
            val hasPageMargins = leftMargin > 0.035f && rightMargin > 0.035f && topMargin > 0.035f && bottomMargin > 0.035f
            val useWholePage = significantCrop && hasPageMargins

            val outputBounds = if (useWholePage) {
                android.graphics.Rect(0, 0, working.width, working.height)
            } else {
                val padX = (textBounds.width() * 0.055f).roundToInt().coerceAtLeast(12)
                val padY = (textBounds.height() * 0.065f).roundToInt().coerceAtLeast(12)
                android.graphics.Rect(
                    (textBounds.left - padX).coerceAtLeast(0),
                    (textBounds.top - padY).coerceAtLeast(0),
                    (textBounds.right + padX).coerceAtMost(working.width),
                    (textBounds.bottom + padY).coerceAtMost(working.height)
                )
            }

            val outputWidth = outputBounds.width().coerceAtLeast(1).toFloat()
            val outputHeight = outputBounds.height().coerceAtLeast(1).toFloat()
            val visibleLines = lines.mapIndexedNotNull { index, line ->
                val intersect = android.graphics.Rect(line.bounds)
                if (!intersect.intersect(outputBounds)) return@mapIndexedNotNull null
                val left = ((line.bounds.left - outputBounds.left) / outputWidth).coerceIn(0f, 0.99f)
                val top = ((line.bounds.top - outputBounds.top) / outputHeight).coerceIn(0f, 0.99f)
                val width = (line.bounds.width() / outputWidth).coerceIn(0.02f, 1f - left)
                val height = (line.bounds.height() / outputHeight).coerceIn(0.012f, 0.20f)
                ScannerRecreateLine(
                    id = index,
                    text = line.text,
                    left = left,
                    top = top,
                    width = width,
                    height = height,
                    bold = false
                )
            }
            val body = scannerBuildRecreateBody(visibleLines)
            require(body.isNotBlank()) { "No se pudo reconstruir el contenido." }
            ScannerRecreateDocument(
                aspectRatio = (outputBounds.width().toFloat() / outputBounds.height().coerceAtLeast(1).toFloat()).coerceIn(0.35f, 2.8f),
                body = body
            )
        } finally {
            if (enhanced != null && enhanced !== working && !enhanced.isRecycled) enhanced.recycle()
        }
    } finally {
        if (!working.isRecycled) working.recycle()
    }
}

private fun filterScannerRecreateLines(
    lines: List<ScannerRecognizedLine>,
    width: Int,
    height: Int
): List<ScannerRecognizedLine> {
    if (lines.isEmpty()) return emptyList()
    val systemLike = Regex("^(\\d{1,2}:\\d{2}|\\d{1,3}%|[0-9 ]+)$")
    val firstPass = lines.filterNot { line ->
        val normalizedTop = line.bounds.top.toFloat() / height.coerceAtLeast(1)
        normalizedTop < 0.10f && line.text.length <= 12 && systemLike.matches(line.text.trim())
    }
    val normalizedCounts = firstPass.groupingBy { it.text.trim().lowercase() }.eachCount()
    return firstPass.filter { line ->
        val key = line.text.trim().lowercase()
        val duplicate = (normalizedCounts[key] ?: 0) > 1
        val nearTop = line.bounds.top < height * 0.20f
        if (!duplicate || !nearTop) true
        else firstPass.filter { it.text.trim().lowercase() == key }.maxOfOrNull { it.bounds.top } == line.bounds.top
    }.filter { it.bounds.width() > width * 0.01f && it.bounds.height() > height * 0.006f }
}

private suspend fun scannerRecognizeLines(bitmap: Bitmap): List<ScannerRecognizedLine> {
    val result = recognizeScannerDocument(bitmap)
    return result.textBlocks
        .flatMap { block -> block.lines }
        .mapNotNull { line ->
            val bounds = line.boundingBox ?: return@mapNotNull null
            val text = line.text.replace("\n", " ").trim()
            if (text.isBlank()) null else ScannerRecognizedLine(text, android.graphics.Rect(bounds))
        }
        .sortedWith(compareBy<ScannerRecognizedLine> { it.bounds.top }.thenBy { it.bounds.left })
}

private fun scannerBuildRecreateBody(lines: List<ScannerRecreateLine>): String {
    if (lines.isEmpty()) return ""
    val sorted = lines.sortedWith(compareBy<ScannerRecreateLine> { it.top }.thenBy { it.left })
    val medianHeight = sorted.map { it.height }.sorted().let { values -> values[values.size / 2] }
    val builder = StringBuilder()
    var previous: ScannerRecreateLine? = null
    sorted.forEach { line ->
        val clean = line.text.replace(Regex("\\s+"), " ").trim()
        if (clean.isBlank()) return@forEach
        val prev = previous
        if (prev != null) {
            val gap = line.top - (prev.top + prev.height)
            if (gap > medianHeight * 0.9f) builder.append("\n\n") else builder.append("\n")
        }
        builder.append(clean)
        previous = line
    }
    return builder.toString().trim()
}

private fun renderScannerRecreateDocumentBitmap(document: ScannerRecreateDocument, maxEdge: Int): Bitmap {
    val ratio = document.aspectRatio.coerceIn(0.35f, 2.8f)
    val safeEdge = maxEdge.coerceIn(800, 3200)
    val width: Int
    val height: Int
    if (ratio >= 1f) {
        width = safeEdge
        height = (safeEdge / ratio).roundToInt().coerceAtLeast(320)
    } else {
        height = safeEdge
        width = (safeEdge * ratio).roundToInt().coerceAtLeast(320)
    }
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(output)
    canvas.drawColor(android.graphics.Color.WHITE)
    val padding = (minOf(width, height) * 0.07f).roundToInt().coerceAtLeast(28)
    val contentWidth = (width - padding * 2).coerceAtLeast(80)
    val contentHeight = (height - padding * 2).coerceAtLeast(80)
    val paint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.SUBPIXEL_TEXT_FLAG).apply {
        color = android.graphics.Color.BLACK
        textAlign = android.graphics.Paint.Align.LEFT
        isLinearText = true
        typeface = scannerTypeface(document.fontFamilyIndex, document.bold)
        isUnderlineText = document.underlined
    }
    var textSize = (document.fontSize * (minOf(width, height) / 900f)).coerceIn(20f, 80f)
    var layout: android.text.StaticLayout
    repeat(12) {
        paint.textSize = textSize
        layout = android.text.StaticLayout.Builder
            .obtain(document.body, 0, document.body.length, paint, contentWidth)
            .setAlignment(android.text.Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.25f)
            .build()
        if (layout.height <= contentHeight || textSize <= 14f) {
            canvas.save()
            canvas.translate(padding.toFloat(), padding.toFloat())
            layout.draw(canvas)
            canvas.restore()
            return output
        }
        textSize *= 0.92f
    }
    paint.textSize = textSize
    layout = android.text.StaticLayout.Builder
        .obtain(document.body, 0, document.body.length, paint, contentWidth)
        .setAlignment(android.text.Layout.Alignment.ALIGN_NORMAL)
        .setIncludePad(false)
        .setLineSpacing(0f, 1.25f)
        .build()
    canvas.save()
    canvas.translate(padding.toFloat(), padding.toFloat())
    layout.draw(canvas)
    canvas.restore()
    return output
}

private fun scannerUnionBounds(bounds: List<android.graphics.Rect>): android.graphics.Rect {
    val first = bounds.firstOrNull() ?: return android.graphics.Rect(0, 0, 1, 1)
    val union = android.graphics.Rect(first)
    bounds.drop(1).forEach { union.union(it) }
    return union
}

private suspend fun recognizeScannerDocument(bitmap: Bitmap): com.google.mlkit.vision.text.Text = suspendCancellableCoroutine { continuation ->
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    val task = recognizer.process(InputImage.fromBitmap(bitmap, 0))
    task.addOnSuccessListener { result ->
        if (continuation.isActive) continuation.resume(result)
    }
    task.addOnFailureListener { error ->
        if (continuation.isActive) continuation.resumeWithException(error)
    }
    task.addOnCanceledListener {
        if (continuation.isActive) continuation.cancel()
    }
    val closed = java.util.concurrent.atomic.AtomicBoolean(false)
    fun closeRecognizer() {
        if (closed.compareAndSet(false, true)) recognizer.close()
    }
    task.addOnCompleteListener { closeRecognizer() }
    continuation.invokeOnCancellation { closeRecognizer() }
}

private suspend fun scannerOcr(
    context: android.content.Context,
    uri: Uri,
    selection: ScannerSelection?
): String = withContext(Dispatchers.IO) {
    val source = ToolFileUtils.loadBitmap(context, uri, SCANNER_OCR_MAX_EDGE)
    if (selection == null) {
        try {
            return@withContext recognizeScannerText(source).trim()
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }

    val left = (selection.left * source.width).roundToInt().coerceIn(0, source.width - 2)
    val top = (selection.top * source.height).roundToInt().coerceIn(0, source.height - 2)
    val right = (selection.right * source.width).roundToInt().coerceIn(left + 2, source.width)
    val bottom = (selection.bottom * source.height).roundToInt().coerceIn(top + 2, source.height)
    val target = Bitmap.createBitmap(source, left, top, right - left, bottom - top)
    try {
        recognizeScannerText(target).trim()
    } finally {
        if (target !== source && !target.isRecycled) target.recycle()
        if (!source.isRecycled) source.recycle()
    }
}

private suspend fun recognizeScannerText(bitmap: Bitmap): String = recognizeScannerDocument(bitmap).text

private const val TEXT_PDF_DRAFT_LIMIT = 15
private const val TEXT_PDF_MAX_CHARS = 300_000

private data class TextPdfDraft(
    val id: String,
    val name: String,
    val body: String,
    val fontSize: Float = 12f,
    val paperIndex: Int = PdfPaperSize.A4.ordinal,
    val orientationIndex: Int = PdfOrientation.PORTRAIT.ordinal,
    val marginIndex: Int = PdfMargin.NORMAL.ordinal,
    val pageNumbers: Boolean = true,
    val modifiedAt: Long = System.currentTimeMillis()
)

private fun textPdfDraftDirectory(context: android.content.Context): File =
    File(context.filesDir, "text_pdf_drafts").apply { mkdirs() }

private fun textPdfDraftFile(context: android.content.Context, id: String): File =
    File(textPdfDraftDirectory(context), "${id.replace(Regex("[^A-Za-z0-9_-]"), "_")}.json")

private fun saveTextPdfDraft(context: android.content.Context, draft: TextPdfDraft) {
    val normalized = draft.copy(
        name = draft.name.trim().ifBlank { "Documento sin título" }.take(80),
        body = draft.body.take(TEXT_PDF_MAX_CHARS),
        fontSize = draft.fontSize.coerceIn(9f, 22f),
        paperIndex = draft.paperIndex.coerceIn(0, PdfPaperSize.entries.lastIndex),
        orientationIndex = draft.orientationIndex.coerceIn(0, PdfOrientation.entries.lastIndex),
        marginIndex = draft.marginIndex.coerceIn(0, PdfMargin.entries.lastIndex),
        modifiedAt = draft.modifiedAt.coerceAtLeast(1L)
    )
    val json = JSONObject().apply {
        put("version", 1)
        put("id", normalized.id)
        put("name", normalized.name)
        put("body", normalized.body)
        put("fontSize", normalized.fontSize.toDouble())
        put("paperIndex", normalized.paperIndex)
        put("orientationIndex", normalized.orientationIndex)
        put("marginIndex", normalized.marginIndex)
        put("pageNumbers", normalized.pageNumbers)
        put("modifiedAt", normalized.modifiedAt)
    }
    val target = textPdfDraftFile(context, normalized.id)
    val temp = File(target.parentFile, "${target.name}.tmp")
    temp.writeText(json.toString())
    if (!temp.renameTo(target)) {
        target.writeText(json.toString())
        temp.delete()
    }
    textPdfDraftDirectory(context).listFiles()
        .orEmpty()
        .filter { it.isFile && it.extension.equals("json", true) }
        .sortedByDescending { file -> readTextPdfDraft(file)?.modifiedAt ?: file.lastModified() }
        .drop(TEXT_PDF_DRAFT_LIMIT)
        .forEach { it.delete() }
}

private fun readTextPdfDraft(file: File): TextPdfDraft? = runCatching {
    val json = JSONObject(file.readText())
    if (json.optInt("version", 1) != 1) return@runCatching null
    TextPdfDraft(
        id = json.optString("id").ifBlank { file.nameWithoutExtension },
        name = json.optString("name", "Documento sin título"),
        body = json.optString("body", "").take(TEXT_PDF_MAX_CHARS),
        fontSize = json.optDouble("fontSize", 12.0).toFloat().coerceIn(9f, 22f),
        paperIndex = json.optInt("paperIndex", PdfPaperSize.A4.ordinal).coerceIn(0, PdfPaperSize.entries.lastIndex),
        orientationIndex = json.optInt("orientationIndex", PdfOrientation.PORTRAIT.ordinal).coerceIn(0, PdfOrientation.entries.lastIndex),
        marginIndex = json.optInt("marginIndex", PdfMargin.NORMAL.ordinal).coerceIn(0, PdfMargin.entries.lastIndex),
        pageNumbers = json.optBoolean("pageNumbers", true),
        modifiedAt = json.optLong("modifiedAt", file.lastModified().coerceAtLeast(1L))
    )
}.getOrNull()

private suspend fun loadTextPdfDrafts(context: android.content.Context): List<TextPdfDraft> = withContext(Dispatchers.IO) {
    textPdfDraftDirectory(context).listFiles()
        .orEmpty()
        .asSequence()
        .filter { it.isFile && it.extension.equals("json", true) }
        .mapNotNull(::readTextPdfDraft)
        .sortedByDescending { it.modifiedAt }
        .take(TEXT_PDF_DRAFT_LIMIT)
        .toList()
}

private fun newTextPdfDraft(body: String = "", name: String = ""): TextPdfDraft = TextPdfDraft(
    id = UUID.randomUUID().toString(),
    name = name.trim().ifBlank {
        "Documento " + android.text.format.DateFormat.format("dd-MM HH-mm", System.currentTimeMillis()).toString()
    }.take(80),
    body = body.take(TEXT_PDF_MAX_CHARS),
    modifiedAt = System.currentTimeMillis()
)

private fun textPdfOutputName(name: String): String {
    val safe = name.trim()
        .ifBlank { "documento" }
        .replace(Regex("[\\/:*?\"<>|]"), "_")
        .removeSuffix(".pdf")
        .take(72)
    return "$safe.pdf"
}

@Composable
fun TextToPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var drafts by remember { mutableStateOf<List<TextPdfDraft>>(emptyList()) }
    var activeDraft by remember { mutableStateOf<TextPdfDraft?>(null) }
    var loadingDrafts by remember { mutableStateOf(true) }
    var processing by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf<TextPdfDraft?>(null) }

    suspend fun refreshDrafts() {
        loadingDrafts = true
        drafts = loadTextPdfDrafts(context)
        loadingDrafts = false
    }

    LaunchedEffect(Unit) { refreshDrafts() }

    val openTextDraft = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val imported = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                        val out = StringBuilder()
                        val buffer = CharArray(8192)
                        while (out.length < TEXT_PDF_MAX_CHARS) {
                            val remaining = TEXT_PDF_MAX_CHARS - out.length
                            val count = reader.read(buffer, 0, minOf(buffer.size, remaining))
                            if (count <= 0) break
                            out.append(buffer, 0, count)
                        }
                        out.toString()
                    } ?: error("No se pudo leer el borrador")
                }.getOrNull()
            }
            if (imported == null) {
                onMessage("No se pudo abrir ese archivo de texto")
            } else {
                val display = runCatching { ToolFileUtils.displayName(context, uri) }.getOrDefault("Borrador")
                val draft = newTextPdfDraft(imported, display.substringBeforeLast('.').ifBlank { "Borrador" })
                withContext(Dispatchers.IO) { saveTextPdfDraft(context, draft) }
                activeDraft = draft
                refreshDrafts()
            }
        }
    }

    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val draft = pendingExport
        pendingExport = null
        if (output == null || draft == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                AdvancedFileUtils.createTextPdf(
                    context = context,
                    output = output,
                    text = draft.body,
                    options = AdvancedFileUtils.TextPdfOptions(
                        title = "",
                        author = "",
                        fontSize = draft.fontSize,
                        lineSpacing = 1.35f,
                        paperSize = PdfPaperSize.entries.getOrElse(draft.paperIndex) { PdfPaperSize.A4 },
                        orientation = PdfOrientation.entries.getOrElse(draft.orientationIndex) { PdfOrientation.PORTRAIT },
                        margin = PdfMargin.entries.getOrElse(draft.marginIndex) { PdfMargin.NORMAL },
                        pageNumbers = draft.pageNumbers,
                        header = ""
                    )
                )
            }.onSuccess { reward ->
                onMessage(successMessage("Documento PDF creado", reward))
            }.onFailure { error ->
                onMessage(error.message ?: "No se pudo crear el PDF")
            }
            processing = false
        }
    }

    BackHandler(enabled = activeDraft != null) {
        val draft = activeDraft ?: return@BackHandler
        val saved = draft.copy(modifiedAt = System.currentTimeMillis())
        activeDraft = null
        scope.launch {
            withContext(Dispatchers.IO) { saveTextPdfDraft(context, saved) }
            refreshDrafts()
        }
    }

    val draft = activeDraft
    if (draft == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(
                tool.title,
                "Crea un documento, guarda borradores y expórtalo a PDF",
                onBack
            )
            Column(
                Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            val created = newTextPdfDraft()
                            scope.launch { withContext(Dispatchers.IO) { saveTextPdfDraft(context, created) } }
                            activeDraft = created
                        },
                        modifier = Modifier.weight(1f).height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                    ) {
                        Icon(Icons.Rounded.TextFields, null)
                        Text("  Nuevo documento", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { openTextDraft.launch(arrayOf("text/*")) },
                        modifier = Modifier.weight(1f).height(54.dp)
                    ) {
                        Icon(Icons.Rounded.Folder, null)
                        Text("  Abrir borrador", fontWeight = FontWeight.Bold)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Últimos 15 documentos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = { scope.launch { refreshDrafts() } }) {
                        Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar")
                    }
                }

                when {
                    loadingDrafts -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NeonGreen)
                    }
                    drafts.isEmpty() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("Todavía no hay borradores", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    else -> LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 28.dp)
                    ) {
                        lazyListItems(drafts, key = { it.id }) { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { activeDraft = item },
                                colors = CardDefaults.cardColors(containerColor = CardGreen),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Row(
                                    Modifier.fillMaxWidth().padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(Color.White),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("D", color = DeepGreen, fontWeight = FontWeight.Black, fontSize = 22.sp)
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(item.name, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Text(
                                            "${item.body.length} caracteres · ${android.text.format.DateUtils.getRelativeTimeSpanString(item.modifiedAt)}",
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return
    }

    LaunchedEffect(draft) {
        delay(450)
        withContext(Dispatchers.IO) { saveTextPdfDraft(context, draft) }
    }

    val paper = PdfPaperSize.entries.getOrElse(draft.paperIndex) { PdfPaperSize.A4 }
    val orientation = PdfOrientation.entries.getOrElse(draft.orientationIndex) { PdfOrientation.PORTRAIT }
    val margin = PdfMargin.entries.getOrElse(draft.marginIndex) { PdfMargin.NORMAL }
    val pageRatio = run {
        val pw = paper.widthPoints.takeIf { it > 0 } ?: PdfPaperSize.A4.widthPoints
        val ph = paper.heightPoints.takeIf { it > 0 } ?: PdfPaperSize.A4.heightPoints
        if (orientation == PdfOrientation.LANDSCAPE) ph.toFloat() / pw.toFloat() else pw.toFloat() / ph.toFloat()
    }
    val pagePadding = when (margin) {
        PdfMargin.NONE -> 6.dp
        PdfMargin.SMALL -> 10.dp
        PdfMargin.NORMAL -> 18.dp
        PdfMargin.LARGE -> 28.dp
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Editor offline · borrador guardado automáticamente") {
            val saved = draft.copy(modifiedAt = System.currentTimeMillis())
            activeDraft = null
            scope.launch {
                withContext(Dispatchers.IO) { saveTextPdfDraft(context, saved) }
                refreshDrafts()
            }
        }

        Column(
            Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BoxWithConstraints(
                modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF101412)),
                contentAlignment = Alignment.Center
            ) {
                val safeRatio = pageRatio.coerceIn(0.45f, 2.1f)
                val availableRatio = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
                val editorPageWidth = if (safeRatio >= availableRatio) maxWidth.value * 0.94f else maxHeight.value * 0.96f * safeRatio
                val editorPageHeight = editorPageWidth / safeRatio
                Box(
                    modifier = Modifier
                        .width(editorPageWidth.dp)
                        .height(editorPageHeight.dp)
                        .background(Color.White)
                        .padding(pagePadding)
                ) {
                    BasicTextField(
                        value = draft.body,
                        onValueChange = { value ->
                            activeDraft = draft.copy(body = value.take(TEXT_PDF_MAX_CHARS), modifiedAt = System.currentTimeMillis())
                        },
                        modifier = Modifier.fillMaxSize(),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = Color.Black,
                            fontSize = draft.fontSize.sp,
                            lineHeight = (draft.fontSize * 1.35f).sp
                        ),
                        decorationBox = { inner ->
                            if (draft.body.isBlank()) {
                                Text("Toca aquí y escribe o pega…", color = Color.Gray, fontSize = draft.fontSize.sp)
                            }
                            inner()
                        }
                    )
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = {
                            activeDraft = draft.copy(fontSize = (draft.fontSize - 1f).coerceAtLeast(9f), modifiedAt = System.currentTimeMillis())
                        }) { Text("−") }
                        Text("${draft.fontSize.toInt()} pt", fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = {
                            activeDraft = draft.copy(fontSize = (draft.fontSize + 1f).coerceAtMost(22f), modifiedAt = System.currentTimeMillis())
                        }) { Text("+") }
                        Spacer(Modifier.weight(1f))
                        Text("${draft.body.length} caracteres", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = {
                            val allowed = listOf(PdfPaperSize.A4, PdfPaperSize.LETTER, PdfPaperSize.A3, PdfPaperSize.A5)
                            val next = allowed[(allowed.indexOf(paper).takeIf { it >= 0 } ?: 0).let { (it + 1) % allowed.size }]
                            activeDraft = draft.copy(paperIndex = next.ordinal, modifiedAt = System.currentTimeMillis())
                        }, modifier = Modifier.weight(1f)) { Text(paper.label.substringBefore(" ·")) }
                        OutlinedButton(onClick = {
                            val next = if (orientation == PdfOrientation.LANDSCAPE) PdfOrientation.PORTRAIT else PdfOrientation.LANDSCAPE
                            activeDraft = draft.copy(orientationIndex = next.ordinal, modifiedAt = System.currentTimeMillis())
                        }, modifier = Modifier.weight(1f)) { Text(if (orientation == PdfOrientation.LANDSCAPE) "Horizontal" else "Vertical") }
                        OutlinedButton(onClick = {
                            val next = PdfMargin.entries[(margin.ordinal + 1) % PdfMargin.entries.size]
                            activeDraft = draft.copy(marginIndex = next.ordinal, modifiedAt = System.currentTimeMillis())
                        }, modifier = Modifier.weight(1f)) { Text(margin.label) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Numerar páginas", modifier = Modifier.weight(1f))
                        Switch(
                            checked = draft.pageNumbers,
                            onCheckedChange = { activeDraft = draft.copy(pageNumbers = it, modifiedAt = System.currentTimeMillis()) }
                        )
                    }
                    Button(
                        onClick = {
                            if (draft.body.isBlank()) {
                                onMessage("Escribe o pega contenido primero")
                            } else {
                                val ready = draft.copy(modifiedAt = System.currentTimeMillis())
                                activeDraft = ready
                                scope.launch { withContext(Dispatchers.IO) { saveTextPdfDraft(context, ready) } }
                                launchPaidExport(viewModel, tool, onMessage) {
                                    pendingExport = ready
                                    savePdf.launch(textPdfOutputName(ready.name))
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = draft.body.isNotBlank() && !processing,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                    ) {
                        Icon(Icons.Rounded.Save, null)
                        Text(if (processing) "  Exportando…" else "  Exportar PDF · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
                    }
                    if (processing) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(
                        "Toca la hoja y escribe o pega. El borrador se guarda automáticamente.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
fun PdfWatermarkSecurityScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var modeIndex by rememberSaveable { mutableIntStateOf(0) }
    var watermark by rememberSaveable { mutableStateOf("GANA GEO") }
    var positionIndex by rememberSaveable { mutableIntStateOf(AdvancedFileUtils.WatermarkPosition.DIAGONAL.ordinal) }
    var opacity by rememberSaveable { mutableFloatStateOf(25f) }
    var fontSize by rememberSaveable { mutableFloatStateOf(42f) }
    var pagesText by rememberSaveable { mutableStateOf("") }
    var pageNumbers by rememberSaveable { mutableStateOf(false) }
    var firstPageNumber by rememberSaveable { mutableStateOf("1") }
    var currentPassword by rememberSaveable { mutableStateOf("") }
    var newPassword by rememberSaveable { mutableStateOf("") }
    var allowPrinting by rememberSaveable { mutableStateOf(true) }
    var allowCopy by rememberSaveable { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    val modes = listOf("Marca y numeración", "Agregar/cambiar contraseña", "Quitar contraseña")
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { input = it }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val source = input ?: return@rememberLauncherForActivityResult
        if (output == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                when (modeIndex) {
                    0 -> {
                        val count = ToolFileUtils.pdfPageCount(context, source)
                        val pages = PageSelectionParser.parse(pagesText, count).toSet()
                        AdvancedFileUtils.watermarkPdf(context, source, output, AdvancedFileUtils.PdfWatermarkOptions(
                            text = watermark,
                            opacityPercent = opacity.toInt(),
                            fontSize = fontSize,
                            position = AdvancedFileUtils.WatermarkPosition.entries[positionIndex],
                            addPageNumbers = pageNumbers,
                            firstPageNumber = firstPageNumber.toIntOrNull()?.coerceIn(1, 9999) ?: 1,
                            pages = pages
                        ), currentPassword)
                    }
                    1 -> AdvancedFileUtils.changePdfProtection(context, source, output, currentPassword, newPassword, allowPrinting, allowCopy)
                    else -> AdvancedFileUtils.changePdfProtection(context, source, output, currentPassword, null)
                }
            }.onSuccess { onMessage(successMessage("PDF guardado", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar el PDF") }
            processing = false
        }
    }
    AdvancedToolPage(tool, onBack) {
        AdvancedSection("Archivo") {
            OutlinedButton(onClick = { pick.launch(arrayOf("application/pdf")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Folder, null); Text(" Seleccionar PDF") }
            input?.let { Text(ToolFileUtils.displayName(context, it), color = NeonGreen) }
            SimpleDropdown("Operación", modes, modeIndex) { modeIndex = it }
        }
        if (modeIndex == 0) AdvancedSection("Marca de agua y páginas") {
            OutlinedTextField(watermark, { watermark = it.take(120) }, label = { Text("Texto de la marca") }, modifier = Modifier.fillMaxWidth())
            SimpleDropdown("Posición", AdvancedFileUtils.WatermarkPosition.entries.map { it.label }, positionIndex) { positionIndex = it }
            Text("Opacidad: ${opacity.toInt()} %"); Slider(opacity, { opacity = it }, valueRange = 5f..80f)
            Text("Tamaño: ${fontSize.toInt()} pt"); Slider(fontSize, { fontSize = it }, valueRange = 12f..90f)
            OutlinedTextField(pagesText, { pagesText = it.filter { c -> c.isDigit() || c in ", -" }.take(120) }, label = { Text("Páginas (vacío = todas)") }, placeholder = { Text("1-3, 5, 8") }, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Agregar número de página", modifier = Modifier.weight(1f)); Switch(pageNumbers, { pageNumbers = it }) }
            if (pageNumbers) OutlinedTextField(firstPageNumber, { firstPageNumber = it.filter(Char::isDigit).take(4) }, label = { Text("Comenzar numeración en") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(currentPassword, { currentPassword = it.take(60) }, label = { Text("Contraseña actual, si tiene") }, modifier = Modifier.fillMaxWidth())
        } else AdvancedSection("Contraseña y permisos") {
            OutlinedTextField(currentPassword, { currentPassword = it.take(60) }, label = { Text("Contraseña actual, si tiene") }, modifier = Modifier.fillMaxWidth())
            if (modeIndex == 1) {
                OutlinedTextField(newPassword, { newPassword = it.take(60) }, label = { Text("Nueva contraseña") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Permitir impresión", modifier = Modifier.weight(1f)); Switch(allowPrinting, { allowPrinting = it }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Permitir copiar contenido", modifier = Modifier.weight(1f)); Switch(allowCopy, { allowCopy = it }) }
            } else Text("Solo funciona cuando el usuario conoce la contraseña actual.", color = Gold)
        }
        if (processing) {
            item { AdvancedProgress("Procesando PDF", null) }
        }
        item {
            Button(onClick = {
                if (input == null) onMessage("Selecciona un PDF")
                else if (modeIndex == 1 && newPassword.length < 4) onMessage("La nueva contraseña debe tener al menos 4 caracteres")
                else launchPaidExport(viewModel, tool, onMessage) { save.launch("pdf_procesado_gana_geo.pdf") }
            }, enabled = input != null && !processing, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                Text("Guardar PDF · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AdvancedToolPage(tool: ToolId, onBack: () -> Unit, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, tool.subtitle, onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF401415)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = Gold)
                        Column(Modifier.weight(1f)) {
                            Text("Operación profesional", fontWeight = FontWeight.Bold)
                            Text(
                                "Costo: ${tool.creditCost} créditos. Solo se confirma cuando el archivo se crea correctamente.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            content()
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.AdvancedSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    item {
        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                content()
            }
        }
    }
}

@Composable
private fun AdvancedProgress(title: String, progress: Float?) {
    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (progress == null) LinearProgressIndicator(Modifier.fillMaxWidth()) else LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        }
    }
}
