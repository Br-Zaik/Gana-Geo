plugins {
    id("com.android.application")
}

android {
    namespace = "com.bph.geotopo"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    defaultConfig {
        applicationId = "com.bph.geotopo"
        minSdk = 23
        targetSdk = 35
        versionCode = 59
        versionName = "1.28.4"
    }
}

dependencies {
    implementation("org.maplibre.gl:android-sdk:11.8.0")
}
