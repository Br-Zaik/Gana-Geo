package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Un rectángulo en píxeles de la foto analizada (right y bottom no se incluyen). */
data class LayoutBox(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val area: Long get() = width.toLong() * height.toLong()
    fun contains(x: Int, y: Int): Boolean = x >= left && x < right && y >= top && y < bottom
}

/** Franja o recuadro de color que tiene texto encima (por ejemplo, una barra de título). */
data class LayoutBar(val box: LayoutBox, val color: Int)

/** Línea horizontal fina (por ejemplo, la raya para escribir el nombre). */
data class LayoutRule(val left: Int, val right: Int, val y: Int, val thickness: Int, val color: Int)

/** Lo que se encontró en la hoja además del texto. */
class PageLayout(
    /** Color del papel ya limpio (blanco si la hoja es clara). */
    val pageColor: Int,
    /** Por cada renglón de texto: color del fondo que tiene detrás. */
    val lineBackgrounds: IntArray,
    /** Por cada renglón de texto: color de la tinta ya limpio. */
    val lineInks: IntArray,
    /** Por cada renglón: grosor medio del trazo en píxeles (0 si no se pudo medir). */
    val lineStrokes: FloatArray,
    /** Por cada renglón: true si está dentro de un dibujo y se queda en la imagen. */
    val lineInFigure: BooleanArray,
    val bars: List<LayoutBar>,
    val rules: List<LayoutRule>,
    /** Dibujos, fotos y croquis: se recortan de la foto original tal como están. */
    val figures: List<LayoutBox>
)

/**
 * Separa una hoja escaneada en capas mirando solo sus píxeles:
 * papel, barras de color, rayas, dibujos y el color/grosor de cada renglón.
 *
 * No usa internet ni modelos: son reglas de color y de forma. Todo se hace
 * sobre un arreglo de colores ARGB para poder probarlo sin un celular.
 */
object PageLayoutAnalyzer {
    private const val WHITE = -1
    private const val BLACK = -0x1000000
    private const val MAX_FIGURES = 16
    private const val MAX_BARS = 100

    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun lum(c: Int) = (red(c) * 299 + green(c) * 587 + blue(c) * 114) / 1000
    private fun spread(c: Int): Int {
        val r = red(c)
        val g = green(c)
        val b = blue(c)
        return max(r, max(g, b)) - min(r, min(g, b))
    }
    private fun dist(a: Int, b: Int) =
        abs(red(a) - red(b)) + abs(green(a) - green(b)) + abs(blue(a) - blue(b))

    fun analyze(pixels: IntArray, width: Int, height: Int, lines: List<LayoutBox>): PageLayout {
        require(width > 0 && height > 0 && pixels.size >= width * height) { "Imagen no válida" }
        val count = lines.size
        val boxes = lines.map { clip(it, width, height) }

        val pageRaw = dominantColor(pixels, width, 0, 0, width, height, 3)
        val pageColor = cleanPaper(pageRaw)

        // ---- 1. Estilo de cada renglón -------------------------------------
        val backgrounds = IntArray(count)
        val inks = IntArray(count)
        val strokes = FloatArray(count)
        for (index in 0 until count) {
            val box = boxes[index]
            if (box.width < 2 || box.height < 2) {
                backgrounds[index] = pageRaw
                inks[index] = BLACK
                continue
            }
            measureLine(pixels, width, height, box, index, backgrounds, inks, strokes)
        }

        // ---- 2. Máscara: el texto ya está explicado ------------------------
        val mask = BooleanArray(width * height)
        for (box in boxes) {
            if (box.width < 2 || box.height < 2) continue
            val pad = max(2, box.height / 6)
            fillMask(mask, width, height, box.left - pad, box.top - pad, box.right + pad, box.bottom + pad)
        }

        // ---- 3. Barras de color con texto encima ---------------------------
        val pageArea = width.toLong() * height.toLong()
        val grownBars = ArrayList<LayoutBar>()
        for (index in 0 until count) {
            val box = boxes[index]
            if (box.width < 2 || box.height < 2) continue
            val background = backgrounds[index]
            if (!isDistinctBackground(background, pageRaw)) continue
            val grown = growRegion(pixels, width, height, box, background)
            if (grown.area > pageArea * 7 / 10) continue
            // Si adentro hay más cosas que texto (flechas, recuadros, fotos), no es
            // una barra: es un dibujo y se recorta completo más abajo.
            if (hasForeignContent(pixels, width, mask, grown, background)) continue
            grownBars.add(LayoutBar(grown, background))
        }
        grownBars.sortByDescending { it.box.area }
        val bars = ArrayList<LayoutBar>()
        for (candidate in grownBars) {
            if (bars.size >= MAX_BARS) break
            val duplicate = bars.any { kept ->
                dist(kept.color, candidate.color) <= 70 &&
                    intersectionArea(kept.box, candidate.box) >= candidate.box.area * 85 / 100
            }
            if (!duplicate) bars.add(candidate)
        }
        // Qué barra cubre cada píxel (0 = ninguna). Las más chicas mandan.
        val barAt = ByteArray(width * height)
        for (barIndex in bars.indices) {
            val box = bars[barIndex].box
            val mark = (barIndex + 1).toByte()
            for (y in box.top until box.bottom) {
                java.util.Arrays.fill(barAt, y * width + box.left, y * width + box.right, mark)
            }
        }

        // ---- 4. Brillo local del papel (para no confundir sombras) ---------
        val coarse = max(8, (width + 15) / 16)
        val coarseCols = (width + coarse - 1) / coarse
        val coarseRows = (height + coarse - 1) / coarse
        val localRaw = IntArray(coarseCols * coarseRows)
        val histogram = IntArray(256)
        for (cy in 0 until coarseRows) {
            for (cx in 0 until coarseCols) {
                java.util.Arrays.fill(histogram, 0)
                var samples = 0
                var y = cy * coarse
                val yEnd = min(height, y + coarse)
                while (y < yEnd) {
                    var x = cx * coarse
                    val xEnd = min(width, x + coarse)
                    while (x < xEnd) {
                        val offset = y * width + x
                        if (!mask[offset]) {
                            histogram[lum(pixels[offset])]++
                            samples++
                        }
                        x += 3
                    }
                    y += 3
                }
                localRaw[cy * coarseCols + cx] = if (samples < 8) -1 else percentile(histogram, samples, 90)
            }
        }
        val pageLum = lum(pageRaw)
        val localLum = IntArray(coarseCols * coarseRows)
        for (cy in 0 until coarseRows) {
            for (cx in 0 until coarseCols) {
                var best = -1
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val ny = cy + dy
                        val nx = cx + dx
                        if (ny < 0 || nx < 0 || ny >= coarseRows || nx >= coarseCols) continue
                        best = max(best, localRaw[ny * coarseCols + nx])
                    }
                }
                localLum[cy * coarseCols + cx] = if (best < 0) pageLum else best
            }
        }

        fun isContent(x: Int, y: Int): Boolean {
            val offset = y * width + x
            if (mask[offset]) return false
            val color = pixels[offset]
            val barMark = barAt[offset].toInt()
            // Dentro de una barra solo cuenta lo que no es del color de la barra (un logo, un ícono).
            if (barMark != 0) return dist(color, bars[barMark - 1].color) > 90
            if (spread(color) >= 45 && dist(color, pageRaw) >= 70) return true
            return lum(color) <= localLum[(y / coarse) * coarseCols + (x / coarse)] - 60
        }

        // ---- 5. Rejilla de celdas con "algo dibujado" -----------------------
        val cell = max(4, width / 110)
        val gridCols = (width + cell - 1) / cell
        val gridRows = (height + cell - 1) / cell
        val cellCounts = IntArray(gridCols * gridRows)
        for (y in 0 until height) {
            val rowBase = (y / cell) * gridCols
            for (x in 0 until width) {
                if (isContent(x, y)) cellCounts[rowBase + x / cell]++
            }
        }
        val needed = max(2, cell * cell / 20)
        val on = BooleanArray(gridCols * gridRows) { cellCounts[it] >= needed }

        // ---- 6. Grupos de celdas vecinas ------------------------------------
        val visited = BooleanArray(gridCols * gridRows)
        val queue = IntArray(gridCols * gridRows)
        val rules = ArrayList<LayoutRule>()
        var figures = ArrayList<LayoutBox>()
        val maxRuleThickness = max(3, height * 12 / 1000)
        for (start in on.indices) {
            if (!on[start] || visited[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = true
            var minCx = start % gridCols
            var maxCx = minCx
            var minCy = start / gridCols
            var maxCy = minCy
            var members = 0
            while (head < tail) {
                val current = queue[head++]
                members++
                val cx = current % gridCols
                val cy = current / gridCols
                minCx = min(minCx, cx)
                maxCx = max(maxCx, cx)
                minCy = min(minCy, cy)
                maxCy = max(maxCy, cy)
                for (dy in -2..2) {
                    for (dx in -2..2) {
                        val nx = cx + dx
                        val ny = cy + dy
                        if (nx < 0 || ny < 0 || nx >= gridCols || ny >= gridRows) continue
                        val next = ny * gridCols + nx
                        if (on[next] && !visited[next]) {
                            visited[next] = true
                            queue[tail++] = next
                        }
                    }
                }
            }
            if (members < 3) continue
            val widthCells = maxCx - minCx + 1
            val heightCells = maxCy - minCy + 1
            val x0 = minCx * cell
            val y0 = minCy * cell
            val x1 = min(width, (maxCx + 1) * cell)
            val y1 = min(height, (maxCy + 1) * cell)

            var handledAsRule = false
            if (heightCells <= 2 && widthCells >= 6) {
                val rule = refineRule(x0, y0, x1, y1, maxRuleThickness, pixels, width) { x, y -> isContent(x, y) }
                if (rule != null && rule.right - rule.left >= cell * 3) {
                    rules.add(rule)
                    handledAsRule = true
                }
            }
            if (handledAsRule) continue
            if (widthCells >= 2 && heightCells >= 2 && widthCells * heightCells >= 6) {
                figures.add(
                    clip(LayoutBox(x0 - cell, y0 - cell, x1 + cell, y1 + cell), width, height)
                )
            }
        }

        // Dibujos que se pisan son un solo dibujo.
        var merged = true
        while (merged) {
            merged = false
            var i = 0
            while (i < figures.size && !merged) {
                var j = i + 1
                while (j < figures.size) {
                    if (intersectionArea(figures[i], figures[j]) > 0) {
                        val a = figures[i]
                        val b = figures[j]
                        figures[i] = LayoutBox(
                            min(a.left, b.left), min(a.top, b.top), max(a.right, b.right), max(a.bottom, b.bottom)
                        )
                        figures.removeAt(j)
                        merged = true
                        break
                    }
                    j++
                }
                i++
            }
        }
        // Un "dibujo" que ocupa casi toda la hoja es el fondo de la foto, no un dibujo.
        figures = ArrayList(figures.filter { it.area <= pageArea * 6 / 10 })
        figures.sortByDescending { it.area }
        while (figures.size > MAX_FIGURES) figures.removeAt(figures.size - 1)

        // ---- 7. Texto que vive dentro de un dibujo --------------------------
        val inFigure = BooleanArray(count)
        var absorbed = 0
        for (index in 0 until count) {
            val box = boxes[index]
            val cx = (box.left + box.right) / 2
            val cy = (box.top + box.bottom) / 2
            if (figures.any { it.contains(cx, cy) }) {
                inFigure[index] = true
                absorbed++
            }
        }
        // Si casi todo el texto cae "dentro de dibujos", la detección falló
        // (foto oscura, sombras fuertes): se recrea solo con texto, como antes.
        if (count > 0 && absorbed * 100 > count * 85) {
            figures.clear()
            java.util.Arrays.fill(inFigure, false)
        }

        val keptBars = bars.filter { bar ->
            val cx = (bar.box.left + bar.box.right) / 2
            val cy = (bar.box.top + bar.box.bottom) / 2
            figures.none { it.contains(cx, cy) }
        }
        val keptRules = rules.filter { rule ->
            figures.none { it.contains((rule.left + rule.right) / 2, rule.y) }
        }

        return PageLayout(
            pageColor = pageColor,
            lineBackgrounds = backgrounds,
            lineInks = inks,
            lineStrokes = strokes,
            lineInFigure = inFigure,
            bars = keptBars,
            rules = keptRules,
            figures = figures
        )
    }

    // ----------------------------------------------------------------------

    private fun clip(box: LayoutBox, width: Int, height: Int): LayoutBox {
        val left = box.left.coerceIn(0, width)
        val top = box.top.coerceIn(0, height)
        return LayoutBox(left, top, box.right.coerceIn(left, width), box.bottom.coerceIn(top, height))
    }

    private fun intersectionArea(a: LayoutBox, b: LayoutBox): Long {
        val w = min(a.right, b.right) - max(a.left, b.left)
        val h = min(a.bottom, b.bottom) - max(a.top, b.top)
        return if (w <= 0 || h <= 0) 0L else w.toLong() * h.toLong()
    }

    private fun fillMask(mask: BooleanArray, width: Int, height: Int, l: Int, t: Int, r: Int, b: Int) {
        val left = l.coerceIn(0, width)
        val right = r.coerceIn(left, width)
        val top = t.coerceIn(0, height)
        val bottom = b.coerceIn(top, height)
        for (y in top until bottom) {
            java.util.Arrays.fill(mask, y * width + left, y * width + right, true)
        }
    }

    private fun percentile(histogram: IntArray, total: Int, percent: Int): Int {
        val target = total * percent / 100
        var seen = 0
        for (value in 0..255) {
            seen += histogram[value]
            if (seen > target) return value
        }
        return 255
    }

    /** Color que más se repite en una zona (promedio de su grupo de tonos). */
    private fun dominantColor(pixels: IntArray, width: Int, l: Int, t: Int, r: Int, b: Int, step: Int): Int {
        val counts = IntArray(4096)
        val sumR = IntArray(4096)
        val sumG = IntArray(4096)
        val sumB = IntArray(4096)
        var y = t
        while (y < b) {
            var x = l
            while (x < r) {
                val color = pixels[y * width + x]
                val bin = ((red(color) shr 4) shl 8) or ((green(color) shr 4) shl 4) or (blue(color) shr 4)
                counts[bin]++
                sumR[bin] += red(color)
                sumG[bin] += green(color)
                sumB[bin] += blue(color)
                x += step
            }
            y += step
        }
        var best = -1
        var bestCount = 0
        for (bin in 0 until 4096) {
            if (counts[bin] > bestCount) {
                bestCount = counts[bin]
                best = bin
            }
        }
        if (best < 0) return WHITE
        return rgb(sumR[best] / bestCount, sumG[best] / bestCount, sumB[best] / bestCount)
    }

    private fun rgb(r: Int, g: Int, b: Int): Int =
        BLACK or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    private fun cleanPaper(color: Int): Int = if (lum(color) >= 185 && spread(color) <= 45) WHITE else color

    private fun cleanInk(color: Int): Int = when {
        lum(color) < 110 && spread(color) < 50 -> BLACK
        lum(color) > 215 && spread(color) < 40 -> WHITE
        else -> color
    }

    private fun isDistinctBackground(background: Int, pageRaw: Int): Boolean {
        if (dist(background, pageRaw) < 60) return false
        if (spread(background) >= 45) return true
        return abs(lum(background) - lum(pageRaw)) >= 90
    }

    /** ¿Hay dentro del recuadro algo que no es ni su color ni texto? */
    private fun hasForeignContent(
        pixels: IntArray,
        width: Int,
        mask: BooleanArray,
        box: LayoutBox,
        color: Int
    ): Boolean {
        var foreign = 0
        var total = 0
        var y = box.top
        while (y < box.bottom) {
            var x = box.left
            while (x < box.right) {
                val offset = y * width + x
                if (!mask[offset]) {
                    total++
                    if (dist(pixels[offset], color) > 90) foreign++
                }
                x += 2
            }
            y += 2
        }
        return total > 0 && foreign * 100 > total * 3
    }

    /** Fondo, tinta y grosor de trazo de un renglón. */
    private fun measureLine(
        pixels: IntArray,
        width: Int,
        height: Int,
        box: LayoutBox,
        index: Int,
        backgrounds: IntArray,
        inks: IntArray,
        strokes: FloatArray
    ) {
        val left = max(0, box.left - 2)
        val top = max(0, box.top - 2)
        val right = min(width, box.right + 2)
        val bottom = min(height, box.bottom + 2)
        val background = dominantColor(pixels, width, left, top, right, bottom, 1)
        backgrounds[index] = background

        var maxDistance = 0
        for (y in top until bottom) {
            for (x in left until right) {
                val d = dist(pixels[y * width + x], background)
                if (d > maxDistance) maxDistance = d
            }
        }
        if (maxDistance < 90) {
            inks[index] = if (lum(background) > 140) BLACK else WHITE
            return
        }

        val inkThreshold = max(90, maxDistance * 6 / 10)
        var sumR = 0L
        var sumG = 0L
        var sumB = 0L
        var inkPixels = 0
        for (y in top until bottom) {
            for (x in left until right) {
                val color = pixels[y * width + x]
                if (dist(color, background) >= inkThreshold) {
                    sumR += red(color)
                    sumG += green(color)
                    sumB += blue(color)
                    inkPixels++
                }
            }
        }
        inks[index] = if (inkPixels == 0) {
            if (lum(background) > 140) BLACK else WHITE
        } else {
            cleanInk(rgb((sumR / inkPixels).toInt(), (sumG / inkPixels).toInt(), (sumB / inkPixels).toInt()))
        }

        // Grosor del trazo: largo medio de los tramos de tinta en cada fila.
        val strokeThreshold = max(70, maxDistance * 45 / 100)
        val maxRun = max(2, box.height * 35 / 100)
        var runTotal = 0L
        var runCount = 0
        for (y in box.top until box.bottom) {
            var run = 0
            for (x in box.left until box.right) {
                if (dist(pixels[y * width + x], background) >= strokeThreshold) {
                    run++
                } else if (run > 0) {
                    if (run <= maxRun) {
                        runTotal += run
                        runCount++
                    }
                    run = 0
                }
            }
            if (run in 1..maxRun) {
                runTotal += run
                runCount++
            }
        }
        strokes[index] = if (runCount < 6) 0f else runTotal.toFloat() / runCount
    }

    /** Agranda el recuadro mientras el borde siga siendo del mismo color. */
    private fun growRegion(pixels: IntArray, width: Int, height: Int, start: LayoutBox, color: Int): LayoutBox {
        var left = start.left
        var top = start.top
        var right = start.right
        var bottom = start.bottom
        val gap = max(3, start.height * 35 / 100)

        fun columnMatches(x: Int): Boolean {
            var matches = 0
            var total = 0
            var y = top
            while (y < bottom) {
                if (dist(pixels[y * width + x], color) <= 70) matches++
                total++
                y += 2
            }
            return total > 0 && matches * 100 >= total * 55
        }

        fun rowMatches(y: Int): Boolean {
            var matches = 0
            var total = 0
            var x = left
            while (x < right) {
                if (dist(pixels[y * width + x], color) <= 70) matches++
                total++
                x += 2
            }
            return total > 0 && matches * 100 >= total * 55
        }

        var rounds = 0
        var changed = true
        while (changed && rounds < 6) {
            rounds++
            changed = false

            var lastGood = left
            var x = left - 1
            while (x >= 0 && lastGood - x <= gap) {
                if (columnMatches(x)) lastGood = x
                x--
            }
            if (lastGood < left) {
                left = lastGood
                changed = true
            }

            lastGood = right - 1
            x = right
            while (x < width && x - lastGood <= gap) {
                if (columnMatches(x)) lastGood = x
                x++
            }
            if (lastGood + 1 > right) {
                right = lastGood + 1
                changed = true
            }

            var y = top - 1
            while (y >= 0 && rowMatches(y)) y--
            if (y + 1 < top) {
                top = y + 1
                changed = true
            }

            y = bottom
            while (y < height && rowMatches(y)) y++
            if (y > bottom) {
                bottom = y
                changed = true
            }
        }
        return LayoutBox(left, top, right, bottom)
    }

    /** Afina una raya horizontal: su altura exacta, de dónde a dónde va y su color. */
    private fun refineRule(
        x0: Int,
        y0: Int,
        x1: Int,
        y1: Int,
        maxThickness: Int,
        pixels: IntArray,
        width: Int,
        isContent: (Int, Int) -> Boolean
    ): LayoutRule? {
        val rows = y1 - y0
        if (rows <= 0 || x1 <= x0) return null
        val rowCounts = IntArray(rows)
        var bestRow = 0
        for (y in y0 until y1) {
            var total = 0
            for (x in x0 until x1) if (isContent(x, y)) total++
            rowCounts[y - y0] = total
            if (total > rowCounts[bestRow]) bestRow = y - y0
        }
        val peak = rowCounts[bestRow]
        if (peak * 2 < (x1 - x0)) return null
        val floor = peak * 6 / 10
        var first = bestRow
        var last = bestRow
        while (first > 0 && rowCounts[first - 1] >= floor) first--
        while (last < rows - 1 && rowCounts[last + 1] >= floor) last++
        val thickness = last - first + 1
        if (thickness > maxThickness) return null

        var minX = x1
        var maxX = x0
        var sumR = 0L
        var sumG = 0L
        var sumB = 0L
        var total = 0
        for (y in (y0 + first)..(y0 + last)) {
            for (x in x0 until x1) {
                if (!isContent(x, y)) continue
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                val color = pixels[y * width + x]
                sumR += red(color)
                sumG += green(color)
                sumB += blue(color)
                total++
            }
        }
        if (total == 0 || maxX <= minX) return null
        val color = cleanInk(rgb((sumR / total).toInt(), (sumG / total).toInt(), (sumB / total).toInt()))
        return LayoutRule(minX, maxX + 1, y0 + (first + last) / 2, thickness, color)
    }
}
