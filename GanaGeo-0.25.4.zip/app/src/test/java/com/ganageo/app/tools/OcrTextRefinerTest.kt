package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Test

class OcrTextRefinerTest {

    @Test
    fun corrigeCeroDentroDePalabra() {
        assertEquals("GEODESICO", OcrTextRefiner.fixToken("GEODESIC0"))
        assertEquals("2024", OcrTextRefiner.fixToken("2O24"))
    }

    @Test
    fun respetaCodigosYNumeros() {
        assertEquals("A1", OcrTextRefiner.fixToken("A1"))
        assertEquals("N240", OcrTextRefiner.fixToken("N240"))
        assertEquals("1:1000.", OcrTextRefiner.fixToken("1:1000."))
        assertEquals("Grupo1", OcrTextRefiner.fixToken("Grupo1"))
        assertEquals("Windows10", OcrTextRefiner.fixToken("Windows10"))
        assertEquals("MARCA?", OcrTextRefiner.fixToken("MARCA?"))
    }

    @Test
    fun uneTituloDeDosLineasYSeparaLoDemas() {
        val lines = listOf(
            // A propósito desordenadas, como a veces las entrega el OCR.
            OcrLine("1.- ¿QUE ES LA TOPOGRAFIA?", 50, 300, 400, 330),
            OcrLine("TOPOGRAFIA SUPERFICIAL", 400, 140, 600, 170),
            OcrLine("PRIMER EXAMEN DE LA UNIDAD DIDACTICA DE", 300, 100, 700, 130),
            OcrLine("NOMBRE Y APELLIDO:", 50, 220, 300, 250)
        )
        assertEquals(
            "PRIMER EXAMEN DE LA UNIDAD DIDACTICA DE TOPOGRAFIA SUPERFICIAL\n\n" +
                "NOMBRE Y APELLIDO:\n\n" +
                "1.- ¿QUE ES LA TOPOGRAFIA?",
            OcrTextRefiner.buildText(lines, 1000)
        )
    }
}
