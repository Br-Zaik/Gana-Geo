package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Hoja de prueba dibujada a mano: barra azul con título blanco, renglones negros
 * (uno en negrita), una raya para rellenar y un dibujo naranja con texto adentro.
 */
class PageLayoutAnalyzerTest {
    private val pageWidth = 440
    private val pageHeight = 600
    private val white = -1
    private val black = -0x1000000
    private val pixels = IntArray(pageWidth * pageHeight) { white }

    private fun rgb(r: Int, g: Int, b: Int): Int = black or (r shl 16) or (g shl 8) or b

    private fun rect(l: Int, t: Int, r: Int, b: Int, color: Int) {
        for (y in t until b) for (x in l until r) pixels[y * pageWidth + x] = color
    }

    private fun stripes(l: Int, t: Int, r: Int, b: Int, color: Int, stroke: Int, period: Int) {
        var x = l
        while (x + stroke <= r) {
            rect(x, t, x + stroke, b, color)
            x += period
        }
    }

    @Test
    fun separaBarraRayaDibujoYEstilos() {
        val blue = rgb(20, 100, 255)
        val orange = rgb(240, 170, 120)
        val redInk = rgb(220, 20, 20)
        rect(0, 0, pageWidth, 40, blue)
        stripes(20, 10, 300, 30, white, 3, 8)
        stripes(20, 80, 400, 96, black, 2, 7)
        stripes(20, 110, 400, 126, black, 4, 9)
        stripes(20, 140, 400, 156, black, 2, 7)
        stripes(20, 170, 300, 186, black, 2, 7)
        rect(150, 220, 400, 222, black)
        rect(60, 300, 380, 500, orange)
        stripes(200, 380, 240, 392, redInk, 2, 6)
        rect(120, 440, 300, 470, white)
        rect(100, 330, 104, 430, redInk)

        val lines = listOf(
            LayoutBox(20, 10, 300, 30),
            LayoutBox(20, 80, 400, 96),
            LayoutBox(20, 110, 400, 126),
            LayoutBox(20, 140, 400, 156),
            LayoutBox(20, 170, 300, 186),
            LayoutBox(200, 380, 240, 392)
        )
        val layout = PageLayoutAnalyzer.analyze(pixels, pageWidth, pageHeight, lines)

        assertEquals(white, layout.pageColor)
        assertEquals(white, layout.lineInks[0])
        assertEquals(black, layout.lineInks[1])
        assertEquals(redInk, layout.lineInks[5])
        assertTrue(layout.lineStrokes[2] > layout.lineStrokes[1] * 1.5f)

        assertEquals(1, layout.bars.size)
        assertEquals(LayoutBox(0, 0, 440, 40), layout.bars[0].box)
        assertEquals(blue, layout.bars[0].color)

        assertEquals(1, layout.rules.size)
        assertEquals(150, layout.rules[0].left)
        assertEquals(400, layout.rules[0].right)
        assertEquals(2, layout.rules[0].thickness)

        assertEquals(1, layout.figures.size)
        assertTrue(layout.figures[0].contains(220, 400))
        assertTrue(layout.figures[0].contains(61, 301))
        assertFalse(layout.figures[0].contains(220, 200))

        assertTrue(layout.lineInFigure[5])
        assertFalse(layout.lineInFigure[0])
        assertFalse(layout.lineInFigure[1])
    }
}
