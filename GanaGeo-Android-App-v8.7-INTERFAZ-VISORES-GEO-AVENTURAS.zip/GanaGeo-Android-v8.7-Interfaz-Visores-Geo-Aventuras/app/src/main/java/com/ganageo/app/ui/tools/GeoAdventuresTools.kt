package com.ganageo.app.ui.tools

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.GeoGameRunStart
import com.ganageo.app.model.GeoGameStatus
import com.ganageo.app.tools.AdventureLevel
import com.ganageo.app.tools.GeoAdventureLevelFactory
import com.ganageo.app.tools.GeoGameRules
import com.ganageo.app.tools.GeoLifePackage
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sign

@Composable
fun GeoAdventuresScreen(
    viewModel: GanaGeoViewModel,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<GeoGameStatus?>(null) }
    var loading by remember { mutableStateOf(true) }
    var localMode by remember { mutableStateOf(false) }
    var activeRun by remember { mutableStateOf<GeoGameRunStart?>(null) }
    var activeLevel by rememberSaveable { mutableIntStateOf(1) }
    var pendingPurchase by remember { mutableStateOf<GeoLifePackage?>(null) }
    var premiumLevelConfirmation by remember { mutableStateOf<Int?>(null) }
    var storyBeforeStart by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var pendingLifeType by remember { mutableStateOf("free") }
    var shownStories by remember { mutableStateOf(setOf<Int>()) }

    fun reload(preferLocal: Boolean = localMode) {
        scope.launch {
            loading = true
            viewModel.loadGeoGameStatus(preferLocal)
                .onSuccess {
                    status = it
                    localMode = it.isLocalTest
                    activeLevel = activeLevel.coerceAtMost(it.unlockedLevel.coerceAtLeast(1))
                }
                .onFailure { onMessage(it.message ?: "No se pudo cargar Geo Aventuras.") }
            loading = false
        }
    }

    fun startLevel(level: Int, lifeType: String) {
        val levelData = GeoAdventureLevelFactory.build(level)
        if (levelData.introStory != null && level !in shownStories) {
            pendingLifeType = lifeType
            storyBeforeStart = level to levelData.introStory
            shownStories = shownStories + level
            return
        }
        scope.launch {
            loading = true
            viewModel.startGeoGameRun(level, lifeType, localMode)
                .onSuccess {
                    activeLevel = level
                    activeRun = it
                }
                .onFailure { onMessage(it.message ?: "No se pudo iniciar el nivel.") }
            loading = false
        }
    }

    fun chooseLevel(level: Int) {
        val current = status ?: return
        if (level > current.unlockedLevel || loading) return
        when {
            current.freeLives > 0 -> startLevel(level, "free")
            current.premiumLives > 0 && current.premiumUsedToday < current.premiumDailyLimit -> premiumLevelConfirmation = level
            else -> onMessage("No tienes vidas disponibles. Las vidas rojas se recuperan cada día.")
        }
    }

    fun buyPackage(packageInfo: GeoLifePackage) {
        scope.launch {
            loading = true
            viewModel.buyGeoGameLives(packageInfo.code)
                .onSuccess { purchase ->
                    localMode = purchase.isLocalTest
                    onMessage("Recibiste ${purchase.livesAdded} vida(s) amarilla(s). Los Rewards se liberan al usarlas.")
                    status = viewModel.loadGeoGameStatus(localMode).getOrNull() ?: status
                }
                .onFailure { onMessage(it.message ?: "No se pudieron comprar vidas.") }
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload(false) }

    DisposableEffect(activeRun) {
        onImmersiveChanged(activeRun != null)
        onDispose { if (activeRun != null) onImmersiveChanged(false) }
    }

    storyBeforeStart?.let { (level, story) ->
        StoryDialog(
            title = "Capítulo ${((level - 1) / 4) + 1} · ${GeoAdventureLevelFactory.build(level).levelName}",
            story = story,
            onDismiss = { storyBeforeStart = null },
            onContinue = {
                storyBeforeStart = null
                startLevel(level, pendingLifeType)
            }
        )
    }

    premiumLevelConfirmation?.let { level ->
        AlertDialog(
            onDismissRequest = { premiumLevelConfirmation = null },
            title = { Text("Usar una vida amarilla") },
            text = { Text("Ya no tienes vidas rojas. ¿Deseas entrar al nivel $level con una vida amarilla? El progreso de Rewards se libera al usarla.") },
            confirmButton = {
                Button(onClick = {
                    premiumLevelConfirmation = null
                    startLevel(level, "premium")
                }) { Text("Usar vida amarilla") }
            },
            dismissButton = { TextButton(onClick = { premiumLevelConfirmation = null }) { Text("Cancelar") } }
        )
    }

    pendingPurchase?.let { pack ->
        AlertDialog(
            onDismissRequest = { if (!loading) pendingPurchase = null },
            title = { Text("Confirmar compra de vidas") },
            text = { Text("Comprarás ${pack.lives} vida(s) amarilla(s) por ${pack.creditCost} créditos.") },
            confirmButton = {
                Button(onClick = { pendingPurchase = null; buyPackage(pack) }, enabled = !loading) { Text("Comprar") }
            },
            dismissButton = { TextButton(onClick = { pendingPurchase = null }, enabled = !loading) { Text("Cancelar") } }
        )
    }

    activeRun?.let { run ->
        GeoAdventureGame(
            level = GeoAdventureLevelFactory.build(activeLevel),
            run = run,
            viewModel = viewModel,
            onMessage = onMessage,
            onExit = {
                activeRun = null
                onImmersiveChanged(false)
                reload(localMode)
            }
        )
        return
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Geo Aventuras", "Primer arco · La selva del impacto", onBack)
        if (loading && status == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = NeonGreen) }
            return@Column
        }
        val current = status ?: GeoGameStatus(isLocalTest = true)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF102E45)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("GEO cayó herido en un planeta desconocido", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Ayúdalo a recuperarse, confiar en nuevos habitantes y encontrar el rastro de su nave antes que el Acechante.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            LifeInfo("❤️", current.freeLives.toString(), "Gratis", Modifier.weight(1f))
                            LifeInfo("💛", current.premiumLives.toString(), "Premium", Modifier.weight(1f))
                            LifeInfo("⭐", current.totalStars.toString(), "Estrellas", Modifier.weight(1f))
                        }
                        Text("Toca un nivel y entrarás directamente. Se usará primero una vida roja.", color = NeonGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Mapa de la historia", style = MaterialTheme.typography.titleLarge)
                        Text("Nivel desbloqueado: ${current.unlockedLevel}/20", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { reload(localMode) }) { Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar", tint = NeonGreen) }
                }
            }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxWidth().height(430.dp),
                    userScrollEnabled = false,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items((1..20).toList()) { level ->
                        LevelButton(
                            level = level,
                            unlocked = level <= current.unlockedLevel,
                            importantStory = level in setOf(1, 4, 5, 8, 9, 12, 13, 16, 17, 20),
                            onClick = { chooseLevel(level) }
                        )
                    }
                }
            }
            item {
                Text("Vidas amarillas", style = MaterialTheme.typography.titleLarge)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LifePackCard("1 vida", "2 créditos", "life_1", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                    LifePackCard("5 vidas", "10 créditos", "life_5", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                    LifePackCard("15 vidas", "30 créditos", "life_15", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                }
            }
        }
    }
}

@Composable
private fun StoryDialog(title: String, story: String, onDismiss: () -> Unit, onContinue: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(story, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        confirmButton = { Button(onClick = onContinue) { Text("Continuar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Volver") } }
    )
}

@Composable
private fun LifeInfo(symbol: String, value: String, label: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(14.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(symbol)
        Spacer(Modifier.width(6.dp))
        Column { Text(value, fontWeight = FontWeight.Bold); Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun LifePackCard(title: String, cost: String, code: String, enabled: Boolean, modifier: Modifier, onBuy: (String) -> Unit) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = Gold)
            Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(cost, color = NeonGreen, textAlign = TextAlign.Center)
            FilledTonalButton(onClick = { onBuy(code) }, enabled = enabled, contentPadding = PaddingValues(horizontal = 9.dp)) { Text("Comprar") }
        }
    }
}

@Composable
private fun LevelButton(level: Int, unlocked: Boolean, importantStory: Boolean, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, enabled = unlocked, modifier = Modifier.height(64.dp), contentPadding = PaddingValues(4.dp)) {
        if (unlocked) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(level.toString(), fontWeight = FontWeight.Bold)
                if (importantStory) Text("• historia", style = MaterialTheme.typography.labelSmall, color = Gold)
            }
        } else Icon(Icons.Rounded.Lock, contentDescription = "Bloqueado", modifier = Modifier.size(18.dp))
    }
}

private enum class GameOutcome { WON, LOST }
private data class Bullet(val x: Float, val y: Float, val direction: Float)
private data class EnemyRuntime(val x: Float, val y: Float, val direction: Float, val health: Int)

@Composable
private fun GeoAdventureGame(
    level: AdventureLevel,
    run: GeoGameRunStart,
    viewModel: GanaGeoViewModel,
    onMessage: (String) -> Unit,
    onExit: () -> Unit
) {
    ImmersiveLandscapeEffect()
    val playerWidth = 46f
    val playerHeight = 58f
    var playerX by remember(level.number) { mutableFloatStateOf(70f) }
    var playerY by remember(level.number) { mutableFloatStateOf(520f) }
    var velocityY by remember(level.number) { mutableFloatStateOf(0f) }
    var moveDirection by remember { mutableFloatStateOf(0f) }
    var facing by remember { mutableFloatStateOf(1f) }
    var jumpQueued by remember { mutableStateOf(false) }
    var shootQueued by remember { mutableStateOf(false) }
    var interactQueued by remember { mutableStateOf(false) }
    var onGround by remember { mutableStateOf(false) }
    var elapsedMs by remember { mutableLongStateOf(0L) }
    var collected by remember { mutableStateOf(setOf<Int>()) }
    var activeSwitches by remember { mutableStateOf(setOf<Int>()) }
    var outcome by remember { mutableStateOf<GameOutcome?>(null) }
    var paused by remember { mutableStateOf(false) }
    var activated by remember(run.runId) { mutableStateOf(!run.needsActivation) }
    var activating by remember { mutableStateOf(false) }
    var activationRewards by remember { mutableLongStateOf(0L) }
    var reportingResult by remember { mutableStateOf(false) }
    var resultSaved by remember { mutableStateOf(false) }
    var resultError by remember { mutableStateOf<String?>(null) }
    var reportAttempt by remember { mutableIntStateOf(0) }
    var hearts by remember { mutableIntStateOf(3) }
    var invulnerableUntil by remember { mutableLongStateOf(0L) }
    var companionAttackAt by remember { mutableLongStateOf(0L) }
    var acechanteX by remember(level.number) { mutableFloatStateOf(-650f) }
    var outroDismissed by remember { mutableStateOf(false) }
    val bullets = remember(level.number) { mutableStateListOf<Bullet>() }
    val enemies = remember(level.number) {
        mutableStateListOf<EnemyRuntime>().apply {
            addAll(level.enemies.mapIndexed { index, enemy -> EnemyRuntime(enemy.x, enemy.y, if (index % 2 == 0) 1f else -1f, enemy.health) })
        }
    }

    fun endGame(result: GameOutcome) { if (outcome == null) outcome = result }
    fun takeDamage() {
        if (elapsedMs < invulnerableUntil || outcome != null) return
        hearts--
        invulnerableUntil = elapsedMs + 1_500L
        if (hearts <= 0) endGame(GameOutcome.LOST)
    }

    BackHandler {
        if (outcome == null) paused = !paused
        else if (resultSaved) onExit()
    }

    LaunchedEffect(level.number, outcome, paused) {
        if (outcome != null || paused) return@LaunchedEffect
        var previousNanos = withFrameNanos { it }
        while (outcome == null && !paused) {
            val now = withFrameNanos { it }
            val dt = ((now - previousNanos) / 1_000_000_000f).coerceIn(0f, 0.035f)
            previousNanos = now
            elapsedMs += (dt * 1000).toLong()

            val previousBottom = playerY + playerHeight
            val speed = if (level.injured) 165f + level.number * 4f else 255f + level.number * 3.2f
            if (moveDirection != 0f) facing = moveDirection.sign
            playerX = (playerX + moveDirection * speed * dt).coerceIn(0f, level.width - playerWidth)

            if (jumpQueued) {
                if (onGround) {
                    velocityY = if (level.injured) -455f else -625f
                    onGround = false
                }
                jumpQueued = false
            }
            velocityY += 1_330f * dt
            var nextY = playerY + velocityY * dt
            onGround = false
            val collisionPlatforms = buildList {
                addAll(level.platforms)
                activeSwitches.forEach { index ->
                    val switch = level.switches.getOrNull(index)
                    if (switch != null) add(com.ganageo.app.tools.GamePlatform(switch.opensAtX, 520f, 250f, 28f))
                }
            }
            val nextBottom = nextY + playerHeight
            collisionPlatforms.forEach { platform ->
                val overlapsX = playerX + playerWidth > platform.x && playerX < platform.x + platform.width
                if (overlapsX && velocityY >= 0f && previousBottom <= platform.y + 8f && nextBottom >= platform.y) {
                    nextY = platform.y - playerHeight
                    velocityY = 0f
                    onGround = true
                }
            }
            playerY = nextY
            val playerRect = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)

            level.crystals.forEachIndexed { index, crystal ->
                if (index !in collected && playerRect.overlaps(Rect(crystal.x - 24f, crystal.y - 24f, crystal.x + 24f, crystal.y + 24f))) collected = collected + index
                if (level.companion == "Luma" && index !in collected && abs(crystal.x - (playerX - 55f)) < 70f) collected = collected + index
            }

            if (interactQueued) {
                level.switches.forEachIndexed { index, switch ->
                    if (abs(playerX - switch.x) < 105f) activeSwitches = activeSwitches + index
                }
                interactQueued = false
            }

            if (shootQueued && level.weaponEnabled) {
                bullets += Bullet(playerX + playerWidth / 2f, playerY + 24f, facing)
                shootQueued = false
            }
            for (i in bullets.indices.reversed()) {
                val bullet = bullets[i]
                val moved = bullet.copy(x = bullet.x + bullet.direction * 720f * dt)
                var hit = false
                for (e in enemies.indices) {
                    val enemy = enemies[e]
                    if (enemy.health > 0 && Rect(moved.x - 8f, moved.y - 5f, moved.x + 8f, moved.y + 5f)
                            .overlaps(Rect(enemy.x, enemy.y, enemy.x + 48f, enemy.y + 52f))) {
                        enemies[e] = enemy.copy(health = enemy.health - 1)
                        hit = true
                        break
                    }
                }
                if (hit || moved.x < 0f || moved.x > level.width) bullets.removeAt(i) else bullets[i] = moved
            }

            for (i in enemies.indices) {
                val enemy = enemies[i]
                if (enemy.health <= 0) continue
                val model = level.enemies[i]
                val distance = playerX - enemy.x
                val chasing = abs(distance) < model.detectionRange
                var direction = if (chasing) distance.sign else enemy.direction
                var x = enemy.x + direction * (if (chasing) 115f else 58f) * dt
                if (!chasing && abs(x - model.x) > model.range) {
                    direction *= -1f
                    x = enemy.x + direction * 58f * dt
                }
                enemies[i] = enemy.copy(x = x, direction = direction)
                if (playerRect.overlaps(Rect(x, enemy.y, x + 48f, enemy.y + 52f))) takeDamage()
            }

            if (level.companion == "Taro" && elapsedMs >= companionAttackAt) {
                val companionX = playerX - 65f
                val index = enemies.indexOfFirst { it.health > 0 && abs(it.x - companionX) < 135f }
                if (index >= 0) {
                    enemies[index] = enemies[index].copy(health = enemies[index].health - 1)
                    companionAttackAt = elapsedMs + 1_100L
                }
            }

            if (level.acechantePresent) {
                val target = playerX - 170f
                val chaseSpeed = 78f + level.number * 2.5f
                acechanteX += (target - acechanteX).sign * chaseSpeed * dt
                if (abs(playerX - acechanteX) < 58f) takeDamage()
            }

            if (level.hazards.any { playerRect.overlaps(Rect(it.x, it.y, it.x + it.width, it.y + it.height)) }) takeDamage()
            if (playerY > 760f || elapsedMs > 240_000L) endGame(GameOutcome.LOST)
            else if (playerX + playerWidth >= level.goalX && collected.size >= 3) endGame(GameOutcome.WON)
        }
    }

    val elapsedSeconds = (elapsedMs / 1000L).toInt()
    LaunchedEffect(run.runId, elapsedSeconds, activated, outcome) {
        if (run.needsActivation && !activated && !activating && outcome == null && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            activating = true
            viewModel.activateGeoGameRun(run)
                .onSuccess {
                    activated = true
                    activationRewards = it.awardedPoints
                    onMessage(if (it.awardedPoints > 0) "Vida amarilla usada: ganaste ${it.awardedPoints} Geo Rewards." else "Vida amarilla usada: se actualizó tu progreso de Rewards.")
                }
                .onFailure { if (!it.message.orEmpty().contains("not ready", true)) onMessage(it.message ?: "No se pudo activar la vida amarilla.") }
            activating = false
        }
    }

    LaunchedEffect(outcome, reportAttempt) {
        val finalOutcome = outcome ?: return@LaunchedEffect
        if (resultSaved || reportingResult) return@LaunchedEffect
        reportingResult = true
        resultError = null
        var canFinish = activated
        if (run.needsActivation && !canFinish && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            viewModel.activateGeoGameRun(run).onSuccess { canFinish = true; activated = true; activationRewards = it.awardedPoints }
                .onFailure { resultError = it.message ?: "No se pudo confirmar la vida amarilla." }
        }
        if (run.needsActivation && !canFinish) {
            if (elapsedSeconds < GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
                runCatching { viewModel.cancelGeoGameRun(run) }
                    .onSuccess { onMessage("La partida terminó antes de activar la vida amarilla; la vida fue devuelta."); resultSaved = true }
                    .onFailure { resultError = it.message ?: "No se pudo devolver la vida todavía." }
            }
            reportingResult = false
            return@LaunchedEffect
        }
        val won = finalOutcome == GameOutcome.WON
        val stars = GeoGameRules.calculateStars(won, collected.size, elapsedSeconds, level.parSeconds)
        val score = (playerX / 4f).toLong() + collected.size * 700L + enemies.count { it.health <= 0 } * 250L + if (won) 1_500L else 0L
        viewModel.finishGeoGameRun(run, won, stars, score, elapsedMs)
            .onSuccess { resultSaved = true }
            .onFailure { resultError = it.message ?: "No se pudo guardar el resultado." }
        reportingResult = false
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF071A29))) {
        Canvas(Modifier.fillMaxSize()) {
            val viewportWidth = size.width
            val viewportHeight = size.height
            val gameTop = 54f
            val gameBottom = viewportHeight - 98f
            val scaleY = (gameBottom - gameTop) / 720f
            val cameraX = (playerX - viewportWidth * 0.30f).coerceIn(0f, max(level.width - viewportWidth, 0f))
            fun sy(value: Float) = gameTop + value * scaleY

            drawRect(Color(0xFF143F5C), size = size)
            drawCircle(Color(0xFFFFD166), 48f, Offset(size.width - 70f, gameTop + 48f))
            // Selva lejana simple y original.
            repeat(12) { i ->
                val treeX = ((i * 190f - cameraX * 0.18f) % (size.width + 220f)) - 60f
                drawRect(Color(0xFF123C2D), Offset(treeX, sy(290f)), Size(24f, sy(620f) - sy(290f)))
                drawCircle(Color(0xFF1E5B3B), 72f, Offset(treeX + 12f, sy(275f)))
            }

            val drawPlatforms = buildList {
                addAll(level.platforms)
                activeSwitches.forEach { index -> level.switches.getOrNull(index)?.let { add(com.ganageo.app.tools.GamePlatform(it.opensAtX, 520f, 250f, 28f)) } }
            }
            drawPlatforms.forEach { platform ->
                drawRoundRect(Color(0xFF2E7D32), Offset(platform.x - cameraX, sy(platform.y)), Size(platform.width, platform.height * scaleY))
                drawRect(Color(0xFF6D4C41), Offset(platform.x - cameraX, sy(platform.y + 16f)), Size(platform.width, max((platform.height - 16f) * scaleY, 5f)))
            }
            level.hazards.forEach { hazard ->
                val path = Path().apply {
                    moveTo(hazard.x - cameraX, sy(hazard.y + hazard.height))
                    lineTo(hazard.x + hazard.width / 2f - cameraX, sy(hazard.y))
                    lineTo(hazard.x + hazard.width - cameraX, sy(hazard.y + hazard.height))
                    close()
                }
                drawPath(path, Color(0xFFE53935))
            }
            level.crates.forEach { crate ->
                drawRect(Color(0xFF9A6A3A), Offset(crate.x - cameraX, sy(crate.y)), Size(54f, 54f * scaleY))
                drawLine(Color(0xFF5D3A22), Offset(crate.x - cameraX, sy(crate.y)), Offset(crate.x + 54f - cameraX, sy(crate.y + 54f)), 5f)
            }
            level.switches.forEachIndexed { index, switch ->
                drawRoundRect(if (index in activeSwitches) NeonGreen else Gold, Offset(switch.x - cameraX, sy(switch.y)), Size(32f, 50f * scaleY))
            }
            enemies.forEach { enemy ->
                if (enemy.health <= 0) return@forEach
                drawRoundRect(Color(0xFF6C2383), Offset(enemy.x - cameraX, sy(enemy.y)), Size(48f, 52f * scaleY), androidx.compose.ui.geometry.CornerRadius(13f))
                drawCircle(Color.White, 5f, Offset(enemy.x + 14f - cameraX, sy(enemy.y + 17f)))
                drawCircle(Color.White, 5f, Offset(enemy.x + 34f - cameraX, sy(enemy.y + 17f)))
            }
            level.crystals.forEachIndexed { index, crystal ->
                if (index !in collected) {
                    val path = Path().apply {
                        moveTo(crystal.x - cameraX, sy(crystal.y - 23f)); lineTo(crystal.x + 18f - cameraX, sy(crystal.y));
                        lineTo(crystal.x - cameraX, sy(crystal.y + 23f)); lineTo(crystal.x - 18f - cameraX, sy(crystal.y)); close()
                    }
                    drawPath(path, Color(0xFF00E5FF))
                }
            }
            bullets.forEach { bullet -> drawCircle(Gold, 7f, Offset(bullet.x - cameraX, sy(bullet.y))) }
            drawRoundRect(Gold, Offset(level.goalX - cameraX, sy(500f)), Size(28f, 120f * scaleY), androidx.compose.ui.geometry.CornerRadius(12f))
            drawCircle(NeonGreen, 38f, Offset(level.goalX + 14f - cameraX, sy(485f)))

            if (level.acechantePresent) {
                drawRoundRect(
                    Color(0xFF121018),
                    Offset(acechanteX - cameraX, sy(playerY - 20f)),
                    Size(38f, 92f * scaleY),
                    androidx.compose.ui.geometry.CornerRadius(18f)
                )
                drawCircle(Color(0xFFECEFF1), 3.5f, Offset(acechanteX + 11f - cameraX, sy(playerY + 4f)))
                drawCircle(Color(0xFFECEFF1), 3.5f, Offset(acechanteX + 26f - cameraX, sy(playerY + 4f)))
            }

            level.companion?.let { name ->
                val companionX = playerX - 62f
                val companionColor = if (name == "Luma") Color(0xFF62D9C7) else Color(0xFF7CB342)
                drawCircle(companionColor, 23f, Offset(companionX - cameraX, sy(playerY + 34f)))
                drawCircle(Color.White, 4f, Offset(companionX - 7f - cameraX, sy(playerY + 29f)))
                drawCircle(Color.White, 4f, Offset(companionX + 7f - cameraX, sy(playerY + 29f)))
            }

            val playerColor = when {
                elapsedMs < invulnerableUntil && (elapsedMs / 100L) % 2L == 0L -> Color.White
                run.lifeType == "premium" -> Gold
                else -> Color(0xFFE53935)
            }
            drawRoundRect(playerColor, Offset(playerX - cameraX, sy(playerY)), Size(playerWidth, playerHeight * scaleY), androidx.compose.ui.geometry.CornerRadius(12f))
            drawCircle(Color.White, 5f, Offset(playerX + 14f - cameraX, sy(playerY + 18f)))
            drawCircle(Color.White, 5f, Offset(playerX + 33f - cameraX, sy(playerY + 18f)))
            if (level.injured) drawLine(Color(0xFFB0BEC5), Offset(playerX + 5f - cameraX, sy(playerY + 42f)), Offset(playerX + 40f - cameraX, sy(playerY + 50f)), 5f)
        }

        Row(
            Modifier.fillMaxWidth().background(Color(0xCC061827)).padding(horizontal = 10.dp, vertical = 5.dp).align(Alignment.TopCenter),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Nivel ${level.number} · ${level.levelName}", fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(16.dp))
            Text("${"❤️".repeat(hearts.coerceAtLeast(0))}  💎 ${collected.size}/3  ·  ${elapsedSeconds}s", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            level.companion?.let { Text("Compañero: $it", color = NeonGreen); Spacer(Modifier.width(12.dp)) }
            if (activationRewards > 0) Text("+$activationRewards Rewards", color = Gold, fontWeight = FontWeight.Bold)
            IconButton(onClick = { paused = true }) { Icon(Icons.Rounded.Pause, contentDescription = "Pausa") }
        }

        Row(
            Modifier.fillMaxWidth().padding(14.dp).align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HoldButton(Icons.Rounded.ArrowBack, "Izquierda") { pressed -> moveDirection = if (pressed) -1f else if (moveDirection < 0f) 0f else moveDirection }
                HoldButton(Icons.Rounded.ArrowForward, "Derecha") { pressed -> moveDirection = if (pressed) 1f else if (moveDirection > 0f) 0f else moveDirection }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (level.weaponEnabled) HoldButton(Icons.Rounded.PlayArrow, "Disparar", accent = Gold) { if (it) shootQueued = true }
                HoldButton(Icons.Rounded.TouchApp, "Interactuar", accent = Color(0xFF62D9C7)) { if (it) interactQueued = true }
                HoldButton(Icons.Rounded.KeyboardArrowUp, "Saltar", accent = NeonGreen) { if (it) jumpQueued = true }
            }
        }

        if (paused) {
            OverlayCard(title = "Partida en pausa") {
                Button(onClick = { paused = false }, colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Continuar") }
                OutlinedButton(onClick = { paused = false; endGame(GameOutcome.LOST) }) { Text("Terminar nivel") }
                TextButton(onClick = onExit) { Text("Volver al mapa") }
            }
        }

        if (outcome != null && resultSaved && outcome == GameOutcome.WON && level.outroStory != null && !outroDismissed) {
            OverlayCard(title = "Historia · ${level.levelName}") {
                Text(level.outroStory, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { outroDismissed = true }, colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Continuar") }
            }
        } else if (outcome != null) {
            OverlayCard(title = if (outcome == GameOutcome.WON) "¡Nivel completado!" else "Fin de la partida") {
                Text("Cristales: ${collected.size}/3 · Tiempo: ${elapsedSeconds}s · Enemigos: ${enemies.count { it.health <= 0 }}")
                if (outcome == GameOutcome.LOST) Text(if (hearts <= 0) "GEO quedó sin energía." else "No lograste completar el recorrido.", color = Gold)
                resultError?.let { Text(it, color = Color(0xFFFFB4AB), textAlign = TextAlign.Center) }
                Button(
                    onClick = { if (resultSaved) onExit() else reportAttempt++ },
                    enabled = !reportingResult,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) {
                    if (reportingResult) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = DeepGreen)
                    else Icon(if (resultSaved) Icons.Rounded.ArrowBack else Icons.Rounded.Refresh, contentDescription = null)
                    Text(if (resultSaved) " Volver a niveles" else " Reintentar guardado")
                }
            }
        }
    }
}

@Composable
private fun OverlayCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.68f)), contentAlignment = Alignment.Center) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(0.55f)) {
            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                content()
            }
        }
    }
}

@Composable
private fun HoldButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    accent: Color = NeonGreen,
    onPressed: (Boolean) -> Unit
) {
    Box(
        modifier = Modifier.size(66.dp).background(accent.copy(alpha = 0.20f), CircleShape).pointerInput(Unit) {
            detectTapGestures(onPress = { onPressed(true); tryAwaitRelease(); onPressed(false) })
        },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = accent, modifier = Modifier.size(36.dp))
    }
}

@Composable
private fun ImmersiveLandscapeEffect() {
    val context = LocalContext.current
    DisposableEffect(Unit) {
        val activity = context.findActivity()
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
