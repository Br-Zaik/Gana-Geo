package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ImageToolScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var inputUriText by rememberSaveable { mutableStateOf<String?>(null) }
    val input = inputUriText?.let { Uri.parse(it) }
    var sourcePreview by remember { mutableStateOf<Bitmap?>(null) }
    var resultPreview by remember { mutableStateOf<Bitmap?>(null) }
    var showOriginal by rememberSaveable { mutableStateOf(false) }
    var previewLoading by remember { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }

    var qualityPreset by rememberSaveable { mutableStateOf(2) }
    var quality by rememberSaveable { mutableStateOf(82f) }
    var resizePreset by rememberSaveable { mutableStateOf(0) }
    var widthText by rememberSaveable { mutableStateOf("1080") }
    var heightText by rememberSaveable { mutableStateOf("1080") }
    var keepAspect by rememberSaveable { mutableStateOf(true) }
    var formatIndex by rememberSaveable { mutableStateOf(0) }
    var ratioIndex by rememberSaveable { mutableStateOf(0) }
    var rotationIndex by rememberSaveable { mutableStateOf(0) }
    var flipH by rememberSaveable { mutableStateOf(false) }
    var flipV by rememberSaveable { mutableStateOf(false) }
    var watermark by rememberSaveable { mutableStateOf("") }
    var opacity by rememberSaveable { mutableStateOf(55f) }
    var textSize by rememberSaveable { mutableStateOf(6f) }
    var positionIndex by rememberSaveable { mutableStateOf(8) }
    var repeatWatermark by rememberSaveable { mutableStateOf(false) }
    var darkText by rememberSaveable { mutableStateOf(false) }
    var brightness by rememberSaveable { mutableStateOf(0f) }
    var contrast by rememberSaveable { mutableStateOf(1f) }
    var filterIndex by rememberSaveable { mutableStateOf(DocumentImageFilter.ORIGINAL.ordinal) }

    val formats = listOf("JPG", "PNG", "WebP")
    val ratios = listOf("Original", "1:1", "4:5", "3:4", "16:9", "9:16")
    val rotations = listOf("0°", "90°", "180°", "270°")
    val watermarkPositions = listOf(
        "Arriba izquierda", "Arriba centro", "Arriba derecha",
        "Centro izquierda", "Centro", "Centro derecha",
        "Abajo izquierda", "Abajo centro", "Abajo derecha"
    )
    val resizePresets = listOf("Personalizado", "50 %", "75 %", "HD 1280×720", "Full HD 1920×1080")
    val qualityLabels = listOf("Máxima compresión", "Media", "Normal", "Calidad alta")
    val qualityValues = listOf(45f, 65f, 82f, 95f)

    fun outputSpec(): Triple<String, String, Bitmap.CompressFormat> {
        if (tool == ToolId.CONVERT_IMAGE) {
            return when (formats[formatIndex]) {
                "PNG" -> Triple("image/png", "imagen_convertida.png", Bitmap.CompressFormat.PNG)
                "WebP" -> Triple("image/webp", "imagen_convertida.webp", Bitmap.CompressFormat.WEBP)
                else -> Triple("image/jpeg", "imagen_convertida.jpg", Bitmap.CompressFormat.JPEG)
            }
        }
        return Triple("image/jpeg", defaultOutputName(tool), Bitmap.CompressFormat.JPEG)
    }

    fun currentTransform(source: Bitmap): Bitmap = transformImage(
        source = source,
        tool = tool,
        quality = quality.toInt(),
        resizePreset = resizePreset,
        widthText = widthText,
        heightText = heightText,
        keepAspect = keepAspect,
        ratio = ratios[ratioIndex],
        rotation = rotations[rotationIndex].removeSuffix("°").toFloatOrNull() ?: 0f,
        flipH = flipH,
        flipV = flipV,
        watermark = watermark,
        opacity = opacity.toInt(),
        textSize = textSize.toInt(),
        position = watermarkPositions[positionIndex],
        repeatWatermark = repeatWatermark,
        darkText = darkText,
        filter = DocumentImageFilter.entries[filterIndex],
        brightness = brightness.toInt(),
        contrast = contrast
    )

    val selectLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        inputUriText = uri?.toString()
        if (uri != null) runCatching {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val oldSource = sourcePreview
        val oldResult = resultPreview
        sourcePreview = null
        resultPreview = null
        oldSource?.takeIf { !it.isRecycled }?.recycle()
        oldResult?.takeIf { !it.isRecycled }?.recycle()
        if (uri != null) {
            scope.launch {
                runCatching { ToolFileUtils.loadBitmap(context, uri, maxEdge = 1200) }
                    .onSuccess { sourcePreview = it }
                    .onFailure { onMessage(it.message ?: "No se pudo abrir la imagen.") }
            }
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/*")) { output ->
        val sourceUri = input
        if (output == null || sourceUri == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                val source = ToolFileUtils.loadBitmap(context, sourceUri)
                var transformed: Bitmap = source
                try {
                    transformed = withContext(Dispatchers.Default) { currentTransform(source) }
                    val spec = outputSpec()
                    val outputQuality = when {
                        spec.third == Bitmap.CompressFormat.PNG -> 100
                        tool == ToolId.COMPRESS_IMAGE || tool == ToolId.CONVERT_IMAGE -> quality.toInt()
                        else -> 92
                    }
                    ToolFileUtils.writeBitmap(context, transformed, output, spec.third, outputQuality)
                } finally {
                    if (transformed !== source && !transformed.isRecycled) transformed.recycle()
                    if (!source.isRecycled) source.recycle()
                }
            }.onSuccess { onMessage(successMessage("Imagen guardada correctamente.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar la imagen.") }
            processing = false
        }
    }

    LaunchedEffect(
        sourcePreview,
        resizePreset,
        widthText,
        heightText,
        keepAspect,
        ratioIndex,
        rotationIndex,
        flipH,
        flipV,
        watermark,
        opacity,
        textSize,
        positionIndex,
        repeatWatermark,
        darkText,
        brightness,
        contrast,
        filterIndex
    ) {
        val source = sourcePreview ?: return@LaunchedEffect
        previewLoading = true
        runCatching { withContext(Dispatchers.Default) { currentTransform(source) } }
            .onSuccess { newResult ->
                val safeResult = if (newResult === source) source.copy(Bitmap.Config.ARGB_8888, false) else newResult
                val old = resultPreview
                resultPreview = safeResult
                if (old != null && old !== safeResult && !old.isRecycled) old.recycle()
            }
            .onFailure { resultPreview = null }
        previewLoading = false
    }

    DisposableEffect(Unit) {
        onDispose {
            sourcePreview?.takeIf { !it.isRecycled }?.recycle()
            resultPreview?.takeIf { !it.isRecycled }?.recycle()
        }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Costo por exportación: ${tool.creditCost} créditos", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Imagen de trabajo", style = MaterialTheme.typography.titleLarge)
                        Text(
                            input?.let {
                                "${ToolFileUtils.displayName(context, it)} · ${ToolFileUtils.readableSize(ToolFileUtils.fileSize(context, it))}"
                            } ?: "Selecciona una imagen para comenzar.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(
                            onClick = { selectLauncher.launch(arrayOf("image/*")) },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !processing
                        ) {
                            Icon(Icons.Rounded.Folder, contentDescription = null)
                            Text(" Elegir imagen")
                        }
                        val displayed = if (showOriginal) sourcePreview else resultPreview ?: sourcePreview
                        displayed?.let { bitmap ->
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Vista previa",
                                modifier = Modifier.fillMaxWidth().height(420.dp),
                                contentScale = ContentScale.Fit
                            )
                            Text("${bitmap.width} × ${bitmap.height} px", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(
                                    onClick = { showOriginal = true },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (showOriginal) NeonGreen else CardGreen,
                                        contentColor = if (showOriginal) DeepGreen else Color.White
                                    )
                                ) { Text("Original") }
                                FilledTonalButton(
                                    onClick = { showOriginal = false },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (!showOriginal) NeonGreen else CardGreen,
                                        contentColor = if (!showOriginal) DeepGreen else Color.White
                                    )
                                ) { Text("Resultado") }
                            }
                            if (previewLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }

            item {
                when (tool) {
                    ToolId.COMPRESS_IMAGE -> ImageSettingCard("Compresión") {
                        SimpleDropdown("Nivel rápido", qualityLabels, qualityPreset) {
                            qualityPreset = it
                            quality = qualityValues[it]
                        }
                        Text("Calidad: ${quality.toInt()} %")
                        Slider(value = quality, onValueChange = { quality = it }, valueRange = 30f..100f)
                        Text("Menor calidad reduce más el peso. El resultado exacto depende del contenido de la imagen.")
                    }
                    ToolId.RESIZE_IMAGE -> ImageSettingCard("Tamaño de salida") {
                        SimpleDropdown("Tamaño rápido", resizePresets, resizePreset) { resizePreset = it }
                        if (resizePreset == 0) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ImageNumberInput(widthText, { widthText = it }, "Ancho", Modifier.weight(1f))
                                ImageNumberInput(heightText, { heightText = it }, "Alto", Modifier.weight(1f))
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = keepAspect, onCheckedChange = { keepAspect = it })
                                Text("Mantener proporción sin deformar")
                            }
                        }
                        Text("Límite seguro: 8192 px por lado y 32 megapíxeles.")
                    }
                    ToolId.CONVERT_IMAGE -> ImageSettingCard("Formato de salida") {
                        SimpleDropdown("Formato", formats, formatIndex) { formatIndex = it }
                        if (formatIndex != 1) {
                            Text("Calidad: ${quality.toInt()} %")
                            Slider(value = quality, onValueChange = { quality = it }, valueRange = 40f..100f)
                        }
                        Text(if (formatIndex == 1) "PNG conserva transparencias." else "Las transparencias se reemplazan por fondo blanco al guardar JPG.")
                    }
                    ToolId.CROP_ROTATE_IMAGE -> ImageSettingCard("Recorte y orientación") {
                        SimpleDropdown("Proporción", ratios, ratioIndex) { ratioIndex = it }
                        SimpleDropdown("Rotación", rotations, rotationIndex) { rotationIndex = it }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ToggleButton("Voltear horizontal", flipH, { flipH = !flipH }, Modifier.weight(1f))
                            ToggleButton("Voltear vertical", flipV, { flipV = !flipV }, Modifier.weight(1f))
                        }
                        Text("El recorte usa el centro de la imagen para conservar la zona principal.")
                    }
                    ToolId.WATERMARK_IMAGE -> ImageSettingCard("Marca de agua") {
                        OutlinedTextField(
                            value = watermark,
                            onValueChange = { watermark = it.take(80) },
                            label = { Text("Texto") },
                            placeholder = { Text("Nombre, curso, fecha…") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        SimpleDropdown("Posición", watermarkPositions, positionIndex) { positionIndex = it }
                        Text("Opacidad: ${opacity.toInt()} %")
                        Slider(value = opacity, onValueChange = { opacity = it }, valueRange = 10f..100f)
                        Text("Tamaño: ${textSize.toInt()} %")
                        Slider(value = textSize, onValueChange = { textSize = it }, valueRange = 2f..15f)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = repeatWatermark, onCheckedChange = { repeatWatermark = it })
                            Text("Repetir por toda la imagen")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = darkText, onCheckedChange = { darkText = it })
                            Spacer(Modifier.width(8.dp))
                            Text(if (darkText) "Texto oscuro" else "Texto claro")
                        }
                    }
                    else -> Unit
                }
            }

            if (tool != ToolId.COMPRESS_IMAGE && tool != ToolId.CONVERT_IMAGE) {
                item {
                    ImageSettingCard("Ajustes finales") {
                        SimpleDropdown(
                            "Filtro",
                            DocumentImageFilter.entries.map { it.label },
                            filterIndex
                        ) { filterIndex = it }
                        Text("Brillo: ${brightness.toInt()}")
                        Slider(value = brightness, onValueChange = { brightness = it }, valueRange = -50f..50f)
                        Text("Contraste: ${String.format("%.2f", contrast)}")
                        Slider(value = contrast, onValueChange = { contrast = it }, valueRange = 0.7f..1.5f)
                    }
                }
            }

            item {
                if (processing) {
                    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.12f)), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Procesando imagen", fontWeight = FontWeight.Bold)
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Text("No cierres la aplicación.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (tool == ToolId.WATERMARK_IMAGE && watermark.isBlank()) {
                            onMessage("Escribe el texto de la marca de agua.")
                        } else {
                            launchPaidExport(viewModel, tool, onMessage) {
                                saveLauncher.launch(outputSpec().second)
                            }
                        }
                    },
                    enabled = input != null && !processing,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) {
                    Icon(Icons.Rounded.Save, contentDescription = null)
                    Text(" Procesar y guardar · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                ImageInfoText("La imagen original permanece intacta. La vista previa usa una copia reducida; el archivo final se procesa con mayor resolución.")
            }
        }
    }
}

private fun transformImage(
    source: Bitmap,
    tool: ToolId,
    quality: Int,
    resizePreset: Int,
    widthText: String,
    heightText: String,
    keepAspect: Boolean,
    ratio: String,
    rotation: Float,
    flipH: Boolean,
    flipV: Boolean,
    watermark: String,
    opacity: Int,
    textSize: Int,
    position: String,
    repeatWatermark: Boolean,
    darkText: Boolean,
    filter: DocumentImageFilter,
    brightness: Int,
    contrast: Float
): Bitmap {
    var current: Bitmap = source
    fun replace(next: Bitmap) {
        if (next !== current && current !== source && !current.isRecycled) current.recycle()
        current = next
    }

    when (tool) {
        ToolId.RESIZE_IMAGE -> {
            val resized = when (resizePreset) {
                1 -> ToolFileUtils.resizeByPercent(current, 50)
                2 -> ToolFileUtils.resizeByPercent(current, 75)
                3 -> ToolFileUtils.resize(current, 1280, 720, true)
                4 -> ToolFileUtils.resize(current, 1920, 1080, true)
                else -> ToolFileUtils.resize(
                    current,
                    widthText.toIntOrNull() ?: error("Ancho inválido."),
                    heightText.toIntOrNull() ?: error("Alto inválido."),
                    keepAspect
                )
            }
            replace(resized)
        }
        ToolId.CROP_ROTATE_IMAGE -> {
            if (ratio != "Original") {
                val (rw, rh) = when (ratio) {
                    "4:5" -> 4 to 5
                    "3:4" -> 3 to 4
                    "16:9" -> 16 to 9
                    "9:16" -> 9 to 16
                    else -> 1 to 1
                }
                replace(ToolFileUtils.centerCrop(current, rw, rh))
            }
            replace(ToolFileUtils.rotateFlip(current, rotation, flipH, flipV))
        }
        ToolId.WATERMARK_IMAGE -> replace(
            ToolFileUtils.addWatermark(
                current,
                watermark,
                opacity,
                textSize,
                position,
                repeatWatermark,
                darkText
            )
        )
        else -> Unit
    }

    if (tool != ToolId.COMPRESS_IMAGE && tool != ToolId.CONVERT_IMAGE) {
        replace(ToolFileUtils.applyImageAdjustments(current, filter, brightness, contrast))
    }
    return current
}

private fun defaultOutputName(tool: ToolId): String = when (tool) {
    ToolId.COMPRESS_IMAGE -> "imagen_comprimida.jpg"
    ToolId.RESIZE_IMAGE -> "imagen_redimensionada.jpg"
    ToolId.CROP_ROTATE_IMAGE -> "imagen_recortada.jpg"
    ToolId.WATERMARK_IMAGE -> "imagen_marca_agua.jpg"
    else -> "imagen_procesada.jpg"
}

@Composable
private fun ImageSettingCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            content()
        }
    }
}

@Composable
private fun ImageNumberInput(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(it.filter(Char::isDigit).take(5)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
        singleLine = true
    )
}

@Composable
private fun ToggleButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilledTonalButton(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = if (selected) NeonGreen else CardGreen,
            contentColor = if (selected) DeepGreen else Color.White
        )
    ) { Text(label) }
}

@Composable
private fun ImageInfoText(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
        Text(text, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
