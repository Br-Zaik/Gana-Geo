package com.ganageo.app.tools

import kotlin.math.min

data class GamePlatform(val x: Float, val y: Float, val width: Float, val height: Float = 34f)
data class GameHazard(val x: Float, val y: Float, val width: Float = 58f, val height: Float = 42f)
data class GameEnemy(
    val x: Float,
    val y: Float,
    val range: Float = 90f,
    val detectionRange: Float = 420f,
    val health: Int = 2
)
data class GameCrystal(val x: Float, val y: Float)
data class GameCrate(val x: Float, val y: Float)
data class GameSwitch(val x: Float, val y: Float, val opensAtX: Float)

data class AdventureLevel(
    val number: Int,
    val worldName: String,
    val levelName: String,
    val objective: String,
    val width: Float,
    val platforms: List<GamePlatform>,
    val hazards: List<GameHazard>,
    val enemies: List<GameEnemy>,
    val crystals: List<GameCrystal>,
    val crates: List<GameCrate>,
    val switches: List<GameSwitch>,
    val goalX: Float,
    val parSeconds: Int,
    val introStory: String? = null,
    val outroStory: String? = null,
    val companion: String? = null,
    val injured: Boolean = false,
    val weaponEnabled: Boolean = false,
    val acechantePresent: Boolean = false
)

object GeoAdventureLevelFactory {
    private val names = listOf(
        "Después del impacto", "La noche interminable", "Agua y medicina", "No estás solo",
        "Primeros impulsos", "El refugio de Luma", "Una deuda con el bosque", "Los cazadores",
        "El paso oculto", "La voz de la piedra", "El primer defensor", "La emboscada",
        "Recuperar la energía", "La torre olvidada", "Una luz en las montañas", "El precio de la señal",
        "Sin mirar atrás", "El bosque silencioso", "Los restos equivocados", "La nave sigue viva"
    )

    private val intros = mapOf(
        1 to "La cápsula cayó en una selva desconocida. GEO despierta dañado, con poca energía y recuerdos incompletos. Antes de buscar su nave deberá sobrevivir.",
        5 to "Luma ha decidido acompañar a GEO. Todavía no hablan el mismo idioma, pero ambos comprenden que solos no llegarán lejos.",
        9 to "Las ruinas reaccionan al objeto que GEO protege. Algunos habitantes quieren ayudarlo; otros creen que su llegada condenará al planeta.",
        13 to "GEO recupera parte de su energía. Taro, un guardián que antes desconfiaba de él, acepta guiarlos hacia una antigua torre.",
        17 to "La torre cayó y Taro quedó atrás para salvarlos. GEO continúa con Luma, cargando culpa, tristeza y una nueva determinación."
    )

    private val outros = mapOf(
        4 to "Luma cura las grietas del cuerpo de GEO y se queda a su lado durante la noche. En la oscuridad, algo deja marcas profundas en los árboles.",
        8 to "GEO muestra sin querer un recuerdo de la persecución. Luma comprende que no vino a conquistar su mundo: está escapando de algo mucho peor.",
        12 to "Taro observa a GEO ayudar a un habitante herido y empieza a confiar en él. Un sonido lejano confirma que el Acechante también sobrevivió.",
        16 to "Taro sostiene la compuerta para que GEO y Luma escapen. La torre se derrumba. No se sabe si sobrevivió. GEO quiere volver, pero ya es demasiado tarde.",
        20 to "Desde la montaña, GEO ve por fin su nave principal. Una luz débil confirma que sigue viva, pero una alerta aparece: acceso interno detectado. Algo ya está dentro. Continuará…"
    )

    fun build(number: Int): AdventureLevel {
        val safeLevel = number.coerceIn(1, GeoGameRules.LEVEL_COUNT)
        val worldIndex = (safeLevel - 1) / 5
        val width = 7_200f + safeLevel * 165f
        val platforms = mutableListOf<GamePlatform>()
        val hazards = mutableListOf<GameHazard>()
        val enemies = mutableListOf<GameEnemy>()
        val crates = mutableListOf<GameCrate>()
        val switches = mutableListOf<GameSwitch>()

        var x = 0f
        var segment = 0
        while (x < width - 600f) {
            val hardGap = segment > 1 && (segment + safeLevel) % 4 == 0
            val gap = if (hardGap) 145f + worldIndex * 22f else 38f
            val length = 430f + ((segment * 73 + safeLevel * 31) % 240)
            platforms += GamePlatform(x, 620f, min(length, width - x))

            if (segment > 0 && (segment + safeLevel) % 3 == 0) {
                platforms += GamePlatform(x + 120f, 485f - (segment % 3) * 28f, 180f)
            }
            if (segment > 1 && (segment + safeLevel) % 4 == 0) {
                hazards += GameHazard(x + length * 0.58f, 578f)
            }
            if (segment > 1 && (segment + safeLevel) % 5 == 0) {
                enemies += GameEnemy(
                    x = x + length * 0.35f,
                    y = 568f,
                    range = 60f + worldIndex * 20f,
                    detectionRange = 360f + safeLevel * 12f,
                    health = 1 + safeLevel / 7
                )
            }
            if (segment > 2 && segment % 7 == 0) crates += GameCrate(x + 95f, 566f)
            if (segment > 3 && segment % 9 == 0) switches += GameSwitch(x + 80f, 570f, x + length - 45f)
            x += length + gap
            segment++
        }
        platforms += GamePlatform((width - 700f).coerceAtLeast(0f), 620f, 700f)

        fun reachableCrystal(ratio: Float): GameCrystal {
            val targetX = width * ratio
            val platform = platforms.minByOrNull { candidate ->
                when {
                    targetX < candidate.x -> candidate.x - targetX
                    targetX > candidate.x + candidate.width -> targetX - (candidate.x + candidate.width)
                    else -> 0f
                }
            } ?: platforms.first()
            val crystalX = targetX.coerceIn(
                platform.x + 45f,
                (platform.x + platform.width - 45f).coerceAtLeast(platform.x + 45f)
            )
            return GameCrystal(crystalX, platform.y - 80f)
        }

        val companion = when (safeLevel) {
            in 5..10, in 17..20 -> "Luma"
            in 11..16 -> "Taro"
            else -> null
        }
        val objective = when (safeLevel) {
            in 1..4 -> "Encuentra refugio, energía y medicina sin alejarte demasiado del lugar del impacto."
            in 5..8 -> "Ayuda a Luma, repara el daño causado por la caída y escapa de los cazadores."
            in 9..12 -> "Cruza las ruinas, activa mecanismos y descubre por qué reaccionan al núcleo."
            in 13..16 -> "Recupera energía, activa la torre y protege a tus nuevos aliados."
            else -> "Sigue la señal, evita al Acechante y localiza los restos verdaderos de la nave."
        }

        return AdventureLevel(
            number = safeLevel,
            worldName = GeoGameRules.worldName(safeLevel),
            levelName = names[safeLevel - 1],
            objective = objective,
            width = width,
            platforms = platforms,
            hazards = hazards,
            enemies = enemies,
            crystals = listOf(reachableCrystal(0.24f), reachableCrystal(0.51f), reachableCrystal(0.79f)),
            crates = crates,
            switches = switches,
            goalX = width - 170f,
            parSeconds = 75 + safeLevel * 3,
            introStory = intros[safeLevel],
            outroStory = outros[safeLevel],
            companion = companion,
            injured = safeLevel <= 4,
            weaponEnabled = safeLevel >= 11,
            acechantePresent = safeLevel >= 18
        )
    }
}
