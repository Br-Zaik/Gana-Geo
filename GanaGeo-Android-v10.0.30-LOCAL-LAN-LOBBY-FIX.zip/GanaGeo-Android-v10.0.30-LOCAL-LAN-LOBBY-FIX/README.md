# Gana Geo Android v0.10.30

Version enfocada en **Multijugador Local estable de hasta 3 jugadores** sobre la misma Wi-Fi/hotspot. No modifica la logica existente de inicio de sesion.

## Modos por ahora

- **Solo:** Geo Aventuras normal.
- **Multijugador local:** activo, invitado o cuenta, sin Internet, hasta 3 telefonos.
- **Online:** aparece como **PROXIMAMENTE**. El codigo previo se conserva para una etapa posterior; Local no necesita servidor ni SQL 08.

## Multijugador local

- Un telefono crea la sala y actua como host.
- Los otros se conectan a la misma Wi-Fi/hotspot y entran desde Salas detectadas; IP manual queda como respaldo.
- Conexion TCP/handshake en `Dispatchers.IO`, fuera del hilo principal.
- Lobby con 3 plazas visibles: host + dos espacios vacios.
- 1/3: INICIAR PARTIDA deshabilitado.
- 2/3 o 3/3: el host puede iniciar.
- Clientes Local quedan Listos automaticamente.
- Todos entran al nivel elegido por el host.
- Se mantienen 15 vidas, skins/colores, espectador y regreso a la misma sala al terminar.

## Proteccion

Login, Google, Supabase, sesion y SQL protegidos 01..07 no se modifican.

## Validacion

- Typecheck Kotlin aislado de GeoLocalMultiplayerService: PASS.
- Contrato estatico de lobby/conexion Local: PASS.
- Parser de GeoMultiplayerUi.kt: sin errores sintacticos detectados.
- El build Android completo debe confirmarse en GitHub Actions porque este entorno no puede descargar Gradle 8.13 desde services.gradle.org.
