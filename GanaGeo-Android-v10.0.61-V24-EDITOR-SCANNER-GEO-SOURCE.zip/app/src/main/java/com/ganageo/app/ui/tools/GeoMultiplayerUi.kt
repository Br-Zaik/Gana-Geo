package com.ganageo.app.ui.tools

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.PersonSearch
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.GeoMultiplayerSession
import com.ganageo.app.model.GeoLocalRoomBeacon
import com.ganageo.app.model.GeoMultiplayerLobbyState
import com.ganageo.app.model.GeoMultiplayerMode
import com.ganageo.app.model.GeoPlayerLookup
import com.ganageo.app.model.GeoSkin
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class GeoAdventureHubPage { HOME, SOLO, LOCAL }

fun geoSkinColor(skin: GeoSkin): Color = when (skin) {
    GeoSkin.GREEN -> Color(0xFF66D54D)
    GeoSkin.BLUE -> Color(0xFF42A5F5)
    GeoSkin.RED -> Color(0xFFEF5350)
    GeoSkin.PURPLE -> Color(0xFFAB6CFF)
    GeoSkin.CYAN -> Color(0xFF33D6D0)
    GeoSkin.ORANGE -> Color(0xFFFF9F43)
    GeoSkin.GOLD -> Color(0xFFFFD54F)
    GeoSkin.YELLOW_ELECTRIC -> Color(0xFFDFFF00)
    GeoSkin.GOLD_METALLIC -> Color(0xFFE6B84B)
}

@Composable
fun GeoModeHome(
    onSolo: () -> Unit,
    onLocal: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Jugar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Button(onClick = onSolo, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("SOLO") }
        OutlinedButton(onClick = onLocal, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("MULTIJUGADOR LOCAL") }
        Text("Local funciona sin Internet en la misma Wi-Fi o hotspot.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun GeoOnlinePanel(session: GeoMultiplayerSession, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val state by session.state.collectAsState()
    val profile by session.onlineProfile.collectAsState()
    val friends by session.friends.collectAsState()
    val invites by session.invites.collectAsState()
    var query by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<GeoPlayerLookup?>(null) }
    var preparing by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        session.prepareOnline().onFailure { onMessage(it.message ?: "No se pudo preparar Online.") }
        val pending = session.consumePendingOnlineRoom()
        if (!pending.isNullOrBlank()) session.joinOnlineRoom(pending).onFailure { onMessage(it.message ?: "La invitación ya no está disponible.") }
        preparing = false
    }

    LaunchedEffect(state?.room?.roomId, preparing) {
        if (preparing || state != null) return@LaunchedEffect
        while (true) {
            delay(2_500L)
            session.refreshInvites()
        }
    }

    if (state?.mode == GeoMultiplayerMode.ONLINE) {
        GeoLobbyPanel(session, state!!, onMessage)
        return
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Online por Internet", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (preparing) Text("Conectando tu cuenta…", color = NeonGreen)
        profile?.let { p ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .06f))) {
                Column(Modifier.padding(12.dp)) {
                    Text("Tu Geo ID", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(p.publicId, fontWeight = FontWeight.Bold, color = NeonGreen)
                }
            }
        }
        Button(
            onClick = { scope.launch { session.createOnlineRoom(1).onFailure { onMessage(it.message ?: "No se pudo crear la sala.") } } },
            enabled = !preparing,
            modifier = Modifier.fillMaxWidth()
        ) { Text("CREAR SALA") }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it.uppercase() }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Buscar Geo ID") }, leadingIcon = { Icon(Icons.Rounded.PersonSearch, null) })
            IconButton(onClick = {
                scope.launch { session.searchPlayer(query).onSuccess { found = it }.onFailure { onMessage(it.message ?: "No se encontró el jugador.") } }
            }) { Icon(Icons.Rounded.PersonSearch, "Buscar") }
        }
        found?.let { p ->
            Card {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(p.displayName, fontWeight = FontWeight.Bold); Text(p.publicId, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    IconButton(onClick = { scope.launch { session.addFriend(p.publicId).onSuccess { found = null }.onFailure { onMessage(it.message ?: "No se pudo agregar.") } } }) { Icon(Icons.Rounded.Add, "Agregar") }
                }
            }
        }
        if (friends.isNotEmpty()) {
            Text("Jugadores agregados", fontWeight = FontWeight.Bold)
            friends.take(6).forEach { friend ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(friend.displayName); Text(friend.publicId, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Invitaciones", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { scope.launch { session.refreshInvites() } }) { Icon(Icons.Rounded.Refresh, "Actualizar") }
        }
        invites.take(5).forEach { invite ->
            Card {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(invite.fromName, fontWeight = FontWeight.Bold); Text(invite.fromPublicId, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Button(onClick = { scope.launch { session.acceptOnlineInvite(invite.inviteId).onFailure { onMessage(it.message ?: "No se pudo entrar.") } } }) { Text("Entrar") }
                }
            }
        }
    }
}

@Composable
fun GeoLocalPanel(session: GeoMultiplayerSession, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val state by session.state.collectAsState()
    val beacons by session.beacons.collectAsState()
    var name by remember { mutableStateOf("GEO") }
    var manualIp by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { session.startLocalDiscovery() }
    if (state?.mode == GeoMultiplayerMode.LOCAL) {
        GeoLobbyPanel(session, state!!, onMessage)
        return
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Multijugador local", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Todos deben estar en la misma Wi‑Fi o hotspot. No requiere Internet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(name, { name = it.take(20) }, modifier = Modifier.fillMaxWidth(), label = { Text("Nombre") }, singleLine = true)
        Button(onClick = { scope.launch { session.createLocalRoom(name).onFailure { onMessage(it.message ?: "No se pudo crear la sala local.") } } }, modifier = Modifier.fillMaxWidth()) { Text("CREAR SALA LOCAL") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(manualIp, { manualIp = it.filter { ch -> ch.isDigit() || ch == '.' }.take(15) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("IP del anfitrión") })
            Button(onClick = { scope.launch { session.joinLocalAddress(manualIp, name).onFailure { onMessage(it.message ?: "No se pudo conectar.") } } }, enabled = manualIp.isNotBlank()) { Text("Entrar") }
        }
        Text("Salas detectadas", fontWeight = FontWeight.Bold)
        if (beacons.isEmpty()) Text("Buscando en la red… Si no aparece, usa la IP del anfitrión.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        beacons.take(6).forEach { beacon: GeoLocalRoomBeacon ->
            Card {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(beacon.hostName, fontWeight = FontWeight.Bold); Text("${beacon.playerCount}/3 · Nivel ${beacon.selectedLevel}", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Button(onClick = { scope.launch { session.joinLocalRoom(beacon, name).onFailure { onMessage(it.message ?: "No se pudo entrar.") } } }) { Text("Entrar") }
                }
            }
        }
    }
}

@Composable
private fun GeoLobbyPanel(session: GeoMultiplayerSession, state: GeoMultiplayerLobbyState, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var inviteId by remember(state.room.roomId) { mutableStateOf("") }
    val friends by session.friends.collectAsState()
    val me = state.me
    val availableSkins = remember(state.premiumSkins) {
        GeoSkin.free + GeoSkin.entries.filter { it.premium && it.code in state.premiumSkins }
    }
    val canStart = state.isHost && state.players.size in 2..3 && (
        state.mode == GeoMultiplayerMode.LOCAL || state.players.filterNot { it.isHost }.all { it.isReady }
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(if (state.mode == GeoMultiplayerMode.ONLINE) "Sala Online" else "Sala local", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (!state.connected) Text(state.message ?: "Conexión interrumpida", color = MaterialTheme.colorScheme.error)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .06f))) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Sala ${state.room.roomCode}", fontWeight = FontWeight.Bold)
                Text("${state.players.size}/3 jugadores · Nivel ${state.room.selectedLevel}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (state.mode == GeoMultiplayerMode.LOCAL && state.isHost) {
                    session.localIpHints().firstOrNull()?.let { ip ->
                        Text("IP anfitrión: $ip", color = NeonGreen)
                    }
                }
            }
        }

        if (state.mode == GeoMultiplayerMode.ONLINE && state.isHost && state.room.status == "lobby") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(inviteId, { inviteId = it.uppercase() }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Geo ID") })
                IconButton(onClick = { scope.launch { session.inviteOnline(inviteId).onSuccess { inviteId = ""; onMessage("Invitación enviada.") }.onFailure { onMessage(it.message ?: "No se pudo invitar.") } } }) { Icon(Icons.Rounded.Add, "Invitar") }
                IconButton(onClick = {
                    val link = "ganageo://geo-room/${state.room.roomId}"
                    val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Únete a mi sala de Geo Aventuras: $link") }
                    context.startActivity(Intent.createChooser(intent, "Compartir invitación"))
                }) { Icon(Icons.Rounded.Share, "Compartir") }
            }
            friends.take(5).forEach { friend ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(friend.displayName, modifier = Modifier.weight(1f))
                    TextButton(onClick = { scope.launch { session.inviteOnline(friend.publicId).onFailure { onMessage(it.message ?: "No se pudo invitar.") } } }) { Text("+ Invitar") }
                }
            }
        }

        Text("Jugadores", fontWeight = FontWeight.Bold)
        repeat(3) { slotIndex ->
            val player = state.players.getOrNull(slotIndex)
            if (player == null) {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .035f))) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.size(34.dp).background(Color.White.copy(alpha = .10f), CircleShape))
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Esperando jugador", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Espacio ${slotIndex + 1} de 3", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .72f))
                        }
                    }
                }
            } else {
                val status = when {
                    player.isHost -> "ANFITRIÓN · Listo"
                    state.mode == GeoMultiplayerMode.LOCAL -> "Conectado · Listo"
                    player.isReady -> "Listo"
                    else -> "Esperando"
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .075f))) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.size(34.dp).background(geoSkinColor(player.skin), CircleShape))
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(player.displayName + if (player.isHost) "  👑" else "", fontWeight = FontWeight.Bold)
                            Text(
                                buildString {
                                    if (state.mode == GeoMultiplayerMode.ONLINE) append("${player.publicId} · ")
                                    append(status)
                                    if (player.skin.premium) append(" · Premium")
                                },
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text("❤️ ${player.lives}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Text("Tu GEO", fontWeight = FontWeight.Bold)
        availableSkins.chunked(5).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { skin ->
                    val selected = me?.skin == skin
                    FilledTonalButton(
                        onClick = { session.setSkin(skin) },
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(3.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = if (selected) geoSkinColor(skin).copy(alpha = .55f) else MaterialTheme.colorScheme.surfaceVariant)
                    ) { Text(if (skin.premium) "✦" else "●", color = geoSkinColor(skin), textAlign = TextAlign.Center) }
                }
                repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        if (GeoSkin.entries.any { it.premium && it.code !in state.premiumSkins }) Text("Los GEO amarillos/dorados premium son solo cosméticos; no cambian físicas ni ventajas.", color = Gold)

        if (state.isHost && state.room.status == "lobby") {
            Text("Elegir nivel", fontWeight = FontWeight.Bold)
            (1..20).chunked(5).forEach { levels ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    levels.forEach { level ->
                        val allowed = level in state.unlockedLevels
                        OutlinedButton(onClick = { session.setLevel(level) }, enabled = allowed, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) {
                            Text(level.toString(), color = if (level == state.room.selectedLevel) NeonGreen else Color.Unspecified)
                        }
                    }
                }
            }
            Text("Los demás pueden entrar aunque tengan ese nivel bloqueado. Si lo completan, se desbloquea para ellos.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (state.room.status == "lobby") {
            if (!state.isHost) {
                if (state.mode == GeoMultiplayerMode.ONLINE) {
                    Button(onClick = { session.setReady(!(me?.isReady ?: false)) }, modifier = Modifier.fillMaxWidth()) { Text(if (me?.isReady == true) "NO LISTO" else "LISTO") }
                } else {
                    Text("Listo · esperando que el anfitrión inicie la partida", color = NeonGreen, fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = { scope.launch { session.startMatch().onFailure { onMessage(it.message ?: "No se pudo iniciar.") } } },
                    enabled = canStart,
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) { Text("INICIAR PARTIDA") }
                if (state.players.size < 2) {
                    Text("Esperando al menos 1 jugador más…", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        } else if (state.room.status == "preparing") {
            val readyCount = state.players.count { it.isReady }
            Text("PREPARANDO PARTIDA · $readyCount/${state.players.size} listos", color = NeonGreen, fontWeight = FontWeight.Bold)
            Text("Todos entrarán cuando los dispositivos terminen de cargar el nivel.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else if (state.room.status == "finished") {
            Text(if (state.room.result == "won") "NIVEL SUPERADO · regresando a la sala…" else "PARTIDA TERMINADA · regresando a la sala…", color = if (state.room.result == "won") NeonGreen else Gold, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(onClick = { session.leaveRoom() }, modifier = Modifier.fillMaxWidth()) { Text("SALIR DE LA SALA") }
    }
}
