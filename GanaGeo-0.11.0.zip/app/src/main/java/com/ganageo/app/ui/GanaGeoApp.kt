package com.ganageo.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Gavel
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Policy
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.SupportAgent
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Handyman
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Redeem
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScaffoldDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ganageo.app.AuthPhase
import com.ganageo.app.GanaGeoUiState
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.R
import com.ganageo.app.model.DashboardData
import com.ganageo.app.model.LedgerEntry
import com.ganageo.app.model.ToolId
import com.ganageo.app.model.Withdrawal
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.tools.ToolsScreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.sin

private val penFormatter: NumberFormat = NumberFormat.getCurrencyInstance(Locale("es", "PE"))

@Composable
fun GanaGeoApp(
    viewModel: GanaGeoViewModel,
    onGoogleLogin: () -> Unit,
    onSignOut: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    val requestGoogleLogin: () -> Unit = {
        if (!uiState.isLoading) {
            onGoogleLogin()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (uiState.authPhase) {
            AuthPhase.ConfigurationMissing -> ConfigurationMissingScreen()
            AuthPhase.Initializing -> {
                if (uiState.dashboard != null) {
                    MainShell(
                        uiState = uiState,
                        viewModel = viewModel,
                        onRefresh = viewModel::refreshDashboard,
                        onWithdraw = viewModel::requestWithdrawal,
                        onCancelWithdrawal = viewModel::cancelWithdrawal,
                        onSignOut = onSignOut,
                        onNoticeShown = viewModel::clearNotice
                    )
                } else {
                    LoadingScreen("Preparando Gana Geo…")
                }
            }
            AuthPhase.CompletingSignIn -> LoadingScreen("Finalizando el acceso con Google…")
            AuthPhase.SignedOut -> {
                LaunchedEffect(Unit) { viewModel.enterGuestMode() }
                LoadingScreen("Abriendo como invitado…")
            }
            AuthPhase.Guest -> GuestToolsShell(
                uiState = uiState,
                viewModel = viewModel,
                onGoogleLogin = requestGoogleLogin,
                onNoticeShown = viewModel::clearNotice
            )
            AuthPhase.DeviceConflict -> DeviceConflictScreen(
                message = uiState.deviceConflictMessage
                    ?: "La instalación actual no tiene autorización para usar esta cuenta.",
                error = uiState.error,
                loading = uiState.isLoading,
                canReplace = uiState.canReplaceDevice,
                onReplace = viewModel::replacePreviousInstallation,
                onRetry = viewModel::refreshDashboard,
                onChangeAccount = onSignOut
            )
            AuthPhase.SignedIn -> MainShell(
                uiState = uiState,
                viewModel = viewModel,
                onRefresh = viewModel::refreshDashboard,
                onWithdraw = viewModel::requestWithdrawal,
                onCancelWithdrawal = viewModel::cancelWithdrawal,
                onSignOut = onSignOut,
                onNoticeShown = viewModel::clearNotice
            )
        }
    }
}

@Composable
private fun ConfigurationMissingScreen() {
    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.logo_gana_geo),
                contentDescription = "Logo Gana Geo",
                modifier = Modifier.size(142.dp)
            )
            Spacer(Modifier.height(24.dp))
            Text("Falta conectar Supabase", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text(
                "Copia local.properties.example como local.properties y pega la clave pública publishable/anon de tu proyecto. Nunca pegues service_role ni el Client Secret de Google dentro de la app.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun LoadingScreen(text: String) {
    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator(color = NeonGreen)
            Spacer(Modifier.height(16.dp))
            Text(text)
        }
    }
}

@Composable
private fun DeviceConflictScreen(
    message: String,
    error: String?,
    loading: Boolean,
    canReplace: Boolean,
    onReplace: () -> Unit,
    onRetry: () -> Unit,
    onChangeAccount: () -> Unit
) {
    var showConfirmation by rememberSaveable { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(Gold.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Lock,
                    contentDescription = null,
                    tint = Gold,
                    modifier = Modifier.size(38.dp)
                )
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "Instalación no autorizada",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            Text(
                message,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            if (!error.isNullOrBlank()) {
                Spacer(Modifier.height(16.dp))
                NoticeCard(error, isError = true)
            }

            Spacer(Modifier.height(26.dp))
            if (canReplace) {
                Button(
                    onClick = { showConfirmation = true },
                    enabled = !loading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonGreen,
                        contentColor = DeepGreen
                    )
                ) {
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                            color = DeepGreen
                        )
                    } else {
                        Text("Reemplazar instalación anterior", fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            OutlinedButton(
                onClick = onRetry,
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Reintentar")
            }
            TextButton(onClick = onChangeAccount, enabled = !loading) {
                Icon(Icons.Rounded.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Usar otra cuenta")
            }
        }
    }

    if (showConfirmation) {
        AlertDialog(
            onDismissRequest = { if (!loading) showConfirmation = false },
            title = { Text("¿Reemplazar la instalación anterior?") },
            text = {
                Text(
                    "La instalación anterior quedará desactivada y dejará de poder usar la cuenta. " +
                        "Hazlo solo si reinstalaste la app o cambiaste de teléfono."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmation = false
                        onReplace()
                    },
                    enabled = !loading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonGreen,
                        contentColor = DeepGreen
                    )
                ) {
                    Text("Sí, reemplazar")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showConfirmation = false },
                    enabled = !loading
                ) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
private fun LoginScreen(
    loading: Boolean,
    error: String?,
    onGoogleLogin: () -> Unit,
    onGuest: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.logo_gana_geo),
                contentDescription = "Logo Gana Geo",
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(180.dp)
            )
            Spacer(Modifier.height(24.dp))
            Text("Gana Geo", style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(8.dp))
            Text(
                "Encuestas, ofertas y recompensas verificadas en un solo lugar.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(28.dp))

            Button(
                onClick = onGoogleLogin,
                enabled = !loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonGreen,
                    contentColor = DeepGreen
                )
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = DeepGreen
                    )
                } else {
                    Text("Continuar con Google", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = onGuest,
                enabled = !loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Rounded.Person, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Entrar como invitado", fontWeight = FontWeight.Bold)
            }
            Text(
                "Acceso sin cuenta a herramientas gratuitas que funcionan localmente.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp)
            )

            if (!error.isNullOrBlank()) {
                Spacer(Modifier.height(16.dp))
                NoticeCard(error, isError = true)
            }

            Spacer(Modifier.height(22.dp))
            Text(
                "Las herramientas son lo principal. Geo Rewards es un beneficio adicional por usar créditos comprados.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun GuestToolsShell(
    uiState: GanaGeoUiState,
    viewModel: GanaGeoViewModel,
    onGoogleLogin: () -> Unit,
    onNoticeShown: () -> Unit
) {
    var immersiveContent by remember { mutableStateOf(false) }
    var showLegal by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    if (showLegal) LegalCenterDialog(onDismiss = { showLegal = false })

    LaunchedEffect(uiState.error, uiState.message) {
        val notice = uiState.error ?: uiState.message
        if (!notice.isNullOrBlank()) {
            snackbarHostState.showSnackbar(notice)
            onNoticeShown()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = if (immersiveContent) WindowInsets(0, 0, 0, 0) else ScaffoldDefaults.contentWindowInsets,
        topBar = {
            if (!immersiveContent) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding(),
                    color = Color(0xFF061D12),
                    shadowElevation = 0.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(NeonGreen.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Person, contentDescription = null, tint = NeonGreen)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Explorando como invitado", fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(
                                "Herramientas gratis y Geo Aventuras",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        IconButton(onClick = { showLegal = true }) {
                            Icon(Icons.Rounded.Info, contentDescription = "Legal y ayuda", tint = Color(0xFF9AB8A5))
                        }
                        Button(
                            onClick = onGoogleLogin,
                            enabled = !uiState.isLoading,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonGreen,
                                contentColor = DeepGreen
                            ),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text("Iniciar sesión", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(
            if (immersiveContent) Modifier.fillMaxSize()
            else Modifier.fillMaxSize().padding(padding)
        ) {
            ToolsScreen(
                uiState = uiState,
                viewModel = viewModel,
                guestMode = true,
                onImmersiveChanged = { immersiveContent = it }
            )
        }
    }
}

private data class TabItem(
    val label: String,
    val icon: ImageVector
)

@Composable
private fun MainShell(
    uiState: GanaGeoUiState,
    viewModel: GanaGeoViewModel,
    onRefresh: () -> Unit,
    onWithdraw: (String, String, String) -> Unit,
    onCancelWithdrawal: (String) -> Unit,
    onSignOut: () -> Unit,
    onNoticeShown: () -> Unit
) {
    var selectedTab by remember {
        mutableIntStateOf(viewModel.rememberedMainTab.coerceIn(0, GanaGeoViewModel.MAIN_TAB_COUNT - 1))
    }
    var immersiveContent by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.message, uiState.error, uiState.dashboard) {
        val notice = if (uiState.dashboard != null) uiState.error ?: uiState.message else uiState.message
        if (!notice.isNullOrBlank()) {
            snackbarHostState.showSnackbar(notice)
            onNoticeShown()
        }
    }

    // 4 pestañas, sin pantallas repetidas: Inicio (accesos), Herramientas,
    // Billetera (Rewards y retiros) y Perfil (cuenta, legal y ayuda).
    val tabs = remember {
        listOf(
            TabItem("Inicio", Icons.Rounded.Home),
            TabItem("Herramientas", Icons.Rounded.Handyman),
            TabItem("Billetera", Icons.Rounded.AccountBalanceWallet),
            TabItem("Perfil", Icons.Rounded.Person)
        )
    }

    val goToTab: (Int) -> Unit = { index ->
        immersiveContent = false
        selectedTab = index
        viewModel.rememberMainTab(index)
    }
    val openTool: (String) -> Unit = { toolName ->
        viewModel.rememberTool(toolName)
        goToTab(GanaGeoViewModel.TAB_TOOLS)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = if (immersiveContent) WindowInsets(0, 0, 0, 0) else ScaffoldDefaults.contentWindowInsets,
        bottomBar = {
            if (!immersiveContent) NavigationBar(containerColor = Color(0xFF061D12)) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { goToTab(index) },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepGreen,
                            selectedTextColor = NeonGreen,
                            indicatorColor = NeonGreen,
                            unselectedIconColor = Color(0xFF9AB8A5),
                            unselectedTextColor = Color(0xFF9AB8A5)
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = if (immersiveContent) Modifier.fillMaxSize()
            else Modifier.fillMaxSize().padding(padding)
        ) {
            val dashboard = uiState.dashboard
            if (dashboard == null) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(color = NeonGreen)
                        Spacer(Modifier.height(14.dp))
                        Text("Cargando tu cuenta…")
                    } else {
                        Icon(
                            Icons.Rounded.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(46.dp)
                        )
                        Spacer(Modifier.height(14.dp))
                        Text(
                            uiState.error ?: "No se pudo cargar tu cuenta.",
                            textAlign = TextAlign.Center
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    OutlinedButton(onClick = onRefresh, enabled = !uiState.isLoading) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Reintentar")
                    }
                    TextButton(onClick = onSignOut, enabled = !uiState.isLoading) {
                        Text("Cambiar de cuenta")
                    }
                }
            } else {
                when (selectedTab) {
                    GanaGeoViewModel.TAB_HOME -> HomeScreen(
                        dashboard = dashboard,
                        recentToolNames = uiState.recentToolNames,
                        onRefresh = onRefresh,
                        onOpenTool = openTool,
                        onBuyCredits = { goToTab(GanaGeoViewModel.TAB_TOOLS) },
                        onOpenWallet = { goToTab(GanaGeoViewModel.TAB_WALLET) }
                    )
                    GanaGeoViewModel.TAB_TOOLS -> ToolsScreen(
                        uiState,
                        viewModel,
                        onImmersiveChanged = { immersiveContent = it }
                    )
                    GanaGeoViewModel.TAB_WALLET -> WalletScreen(dashboard, onWithdraw, onCancelWithdrawal)
                    else -> ProfileScreen(
                        dashboard = dashboard,
                        onSignOut = onSignOut,
                        onDeleteAccount = viewModel::deleteAccount
                    )
                }
            }

            if (uiState.isLoading && dashboard != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = NeonGreen)
                }
            }
        }
    }
}

private fun firstName(displayName: String?): String =
    displayName?.trim()?.split(" ")?.firstOrNull()?.takeIf { it.isNotBlank() } ?: "Usuario"

@Composable
private fun HomeScreen(
    dashboard: DashboardData,
    recentToolNames: List<String>,
    onRefresh: () -> Unit,
    onOpenTool: (String) -> Unit,
    onBuyCredits: () -> Unit,
    onOpenWallet: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "home_header", contentType = "header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Hola, ${firstName(dashboard.profile.displayName)}",
                        style = MaterialTheme.typography.headlineMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "Geo ID ${dashboard.profile.geoId}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar")
                }
            }
        }

        item(key = "home_credits", contentType = "hero") {
            CreditsHero(dashboard, onBuyCredits = onBuyCredits, onOpenWallet = onOpenWallet)
        }

        dashboard.deviceNotice?.let { notice ->
            item(key = "home_notice", contentType = "notice") { NoticeCard(notice, isError = false) }
        }

        item(key = "home_game", contentType = "game") {
            HomeShortcutCard(
                title = "Geo Aventuras",
                subtitle = "20 niveles · Solo o multijugador local",
                icon = Icons.Rounded.SportsEsports,
                accent = NeonGreen,
                onClick = { onOpenTool("GEO_ADVENTURES") }
            )
        }

        val recentTools = recentToolNames
            .mapNotNull { name -> ToolId.entries.firstOrNull { it.name == name } }
            .filter { it != ToolId.GEO_ADVENTURES }
            .take(4)

        item(key = "home_recents_title", contentType = "section_title") {
            Text("Tus recientes", style = MaterialTheme.typography.titleLarge)
        }

        if (recentTools.isEmpty()) {
            item(key = "home_recents_empty", contentType = "empty") {
                EmptyCard("Aquí aparecerán las herramientas que uses.")
            }
        } else {
            items(recentTools, key = { "recent_${it.name}" }, contentType = { "recent" }) { tool ->
                HomeShortcutCard(
                    title = tool.title,
                    subtitle = if (tool.creditCost > 0) "${tool.creditCost} créditos" else "Gratis",
                    icon = Icons.Rounded.History,
                    accent = if (tool.creditCost > 0) Gold else NeonGreen,
                    onClick = { onOpenTool(tool.name) }
                )
            }
        }

        item(key = "home_all_tools", contentType = "action") {
            OutlinedButton(onClick = onBuyCredits, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Handyman, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Ver todas las herramientas")
            }
        }
    }
}

@Composable
private fun CreditsHero(
    dashboard: DashboardData,
    onBuyCredits: () -> Unit,
    onOpenWallet: () -> Unit
) {
    val credits = dashboard.toolCredits.availableCredits
    val progress = dashboard.toolCredits.rewardProgress.coerceIn(0, 10)
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
        shape = RoundedCornerShape(26.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = NeonGreen)
                Spacer(Modifier.width(8.dp))
                Text("Créditos disponibles", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                credits.toString(),
                style = MaterialTheme.typography.displaySmall,
                color = NeonGreen,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Redeem, contentDescription = null, tint = Gold, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "${dashboard.wallet.internalPoints} Geo Rewards",
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress / 10f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(6.dp)),
                color = Gold,
                trackColor = Color.White.copy(alpha = 0.10f)
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Próximos 50 Rewards: $progress/10 créditos comprados usados",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF9AB8A5)
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onBuyCredits,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) {
                    Text("Usar créditos", fontWeight = FontWeight.Bold, maxLines = 1)
                }
                OutlinedButton(onClick = onOpenWallet, modifier = Modifier.weight(1f)) {
                    Text("Billetera", maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun HomeShortcutCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF9AB8A5),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color(0xFF9AB8A5))
        }
    }
}

@Composable
private fun RewardsHero(dashboard: DashboardData) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
        shape = RoundedCornerShape(26.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Redeem, contentDescription = null, tint = Gold)
                Spacer(Modifier.width(8.dp))
                Text("Geo Rewards", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                dashboard.wallet.internalPoints.toString(),
                style = MaterialTheme.typography.displaySmall,
                color = Gold,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniBalance(
                    "Créditos",
                    dashboard.toolCredits.availableCredits.toString(),
                    Icons.Rounded.Bolt,
                    Modifier.weight(1f)
                )
                MiniBalance(
                    "Saldo S/",
                    penFormatter.format(dashboard.wallet.availableAmount),
                    Icons.Rounded.TrendingUp,
                    Modifier.weight(1f)
                )
                MiniBalance(
                    "Bloqueado",
                    penFormatter.format(dashboard.wallet.lockedAmount),
                    Icons.Rounded.Lock,
                    Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MiniBalance(label: String, value: String, icon: ImageVector, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .padding(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(8.dp))
        Text(value, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, style = MaterialTheme.typography.bodySmall, color = Color(0xFF9AB8A5), maxLines = 1)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WalletScreen(
    dashboard: DashboardData,
    onWithdraw: (String, String, String) -> Unit,
    onCancelWithdrawal: (String) -> Unit
) {
    var showWithdrawDialog by rememberSaveable { mutableStateOf(false) }
    var openDoc by remember { mutableStateOf<LegalDoc?>(null) }
    val features = dashboard.features
    val canWithdraw = features.withdrawalsEnabled &&
        dashboard.wallet.availableAmount >= features.minWithdrawal

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "wallet_title", contentType = "header") {
            Text("Billetera", style = MaterialTheme.typography.headlineMedium)
        }
        item(key = "wallet_hero", contentType = "hero") { RewardsHero(dashboard) }

        item(key = "wallet_how", contentType = "info") {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Cómo ganas Geo Rewards", fontWeight = FontWeight.Bold)
                    Text(
                        "• Herramientas de pago: 10 créditos comprados usados = 50 Rewards.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "• Vidas doradas: se suman al usarlas, ganes o pierdas (máx. 10 por día).",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "• Créditos de regalo y herramientas gratis no suman Rewards.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { openDoc = LegalDoc.REWARDS }) {
                        Text("Ver reglas completas", color = NeonGreen)
                    }
                }
            }
        }

        item(key = "wallet_withdraw", contentType = "action") {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = { showWithdrawDialog = true },
                    enabled = canWithdraw,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonGreen,
                        contentColor = DeepGreen
                    )
                ) {
                    Icon(Icons.Rounded.Payments, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Retirar por Yape")
                }
                Text(
                    if (features.withdrawalsEnabled) {
                        "Mínimo S/ ${"%.0f".format(features.minWithdrawal)}. Solo Yape. Cada retiro se revisa antes de pagar."
                    } else {
                        "El canje y los retiros por Yape todavía no están habilitados. Se avisará en la app."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (dashboard.withdrawals.isNotEmpty()) {
            item(key = "wallet_requests_title", contentType = "section_title") {
                Text("Solicitudes de retiro", style = MaterialTheme.typography.titleLarge)
            }
            items(dashboard.withdrawals, key = { "w_${it.id}" }, contentType = { "withdrawal" }) { withdrawal ->
                WithdrawalRow(withdrawal, onCancelWithdrawal)
            }
        }

        item(key = "wallet_history_title", contentType = "section_title") {
            Text("Movimientos", style = MaterialTheme.typography.titleLarge)
        }
        if (dashboard.ledger.isEmpty()) {
            item(key = "wallet_history_empty", contentType = "empty") {
                EmptyCard("Aún no tienes movimientos confirmados.")
            }
        } else {
            items(dashboard.ledger, key = { "l_${it.id}" }, contentType = { "ledger" }) { entry ->
                LedgerRow(entry)
            }
        }
    }

    if (showWithdrawDialog) {
        WithdrawalDialog(
            available = dashboard.wallet.availableAmount,
            minimum = features.minWithdrawal,
            onDismiss = { showWithdrawDialog = false },
            onSubmit = { amount, destination ->
                showWithdrawDialog = false
                onWithdraw(amount, "yape", destination)
            }
        )
    }

    openDoc?.let { doc -> LegalDialog(doc = doc, onDismiss = { openDoc = null }) }
}

@Composable
private fun WithdrawalDialog(
    available: Double,
    minimum: Double,
    onDismiss: () -> Unit,
    onSubmit: (String, String) -> Unit
) {
    var amount by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    val amountValue = amount.replace(',', '.').toDoubleOrNull()
    val phoneOk = GanaGeoViewModel.isValidYapePhone(phone)
    val amountOk = amountValue != null && amountValue >= minimum && amountValue <= available

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Retirar por Yape") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Disponible: ${penFormatter.format(available)} · mínimo ${penFormatter.format(minimum)}")
                OutlinedTextField(
                    value = amount,
                    onValueChange = { input -> amount = input.filter { it.isDigit() || it == '.' || it == ',' }.take(8) },
                    label = { Text("Monto en soles") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    isError = amount.isNotBlank() && !amountOk
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { input -> phone = input.filter { it.isDigit() || it == '+' || it == ' ' }.take(15) },
                    label = { Text("Número de Yape (9 dígitos)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    isError = phone.isNotBlank() && !phoneOk
                )
                Text(
                    "El número debe estar a tu nombre. El retiro queda en revisión y se paga manualmente por Yape. No hay pagos automáticos.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(amount, phone) },
                enabled = amountOk && phoneOk,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
                Text("Enviar solicitud")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun WithdrawalRow(withdrawal: Withdrawal, onCancel: (String) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(penFormatter.format(withdrawal.amount), fontWeight = FontWeight.Bold)
                    Text(
                        "${withdrawal.paymentMethod.replaceFirstChar { it.uppercase() }} · ${maskPhone(withdrawal.paymentDestination)}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                StatusChip(withdrawal.status)
            }
            if (!withdrawal.rejectionReason.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(withdrawal.rejectionReason, color = MaterialTheme.colorScheme.error)
            }
            if (withdrawal.status in setOf("pending", "under_review")) {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { onCancel(withdrawal.id) }) {
                    Icon(Icons.Rounded.Cancel, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Cancelar solicitud")
                }
            }
        }
    }
}

private fun maskPhone(raw: String): String {
    val digits = raw.filter(Char::isDigit)
    return if (digits.length >= 4) "••• ${digits.takeLast(3)}" else raw
}

@Composable
private fun StatusChip(status: String) {
    val (label, color) = when (status) {
        "paid" -> "Pagado" to NeonGreen
        "approved" -> "Aprobado" to Gold
        "rejected" -> "Rechazado" to MaterialTheme.colorScheme.error
        "cancelled" -> "Cancelado" to Color(0xFF9AB8A5)
        "under_review" -> "En revisión" to Gold
        else -> "Pendiente" to Color(0xFF74C7FF)
    }
    Text(
        label,
        color = color,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(100.dp))
            .background(color.copy(alpha = 0.13f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    )
}

private fun readableAccountStatus(status: String): String = when (status) {
    "active" -> "Cuenta activa"
    "inactive" -> "Cuenta inactiva"
    "under_review" -> "Cuenta en revisión"
    "suspended" -> "Cuenta suspendida"
    "deleted" -> "Cuenta eliminada"
    else -> "Cuenta"
}

@Composable
private fun ProfileScreen(
    dashboard: DashboardData,
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit
) {
    val context = LocalContext.current
    var openDoc by remember { mutableStateOf<LegalDoc?>(null) }
    var showSupport by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "profile_header", contentType = "header") {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(R.drawable.logo_gana_geo),
                    contentDescription = null,
                    modifier = Modifier.size(88.dp)
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    dashboard.profile.displayName ?: "Usuario",
                    style = MaterialTheme.typography.headlineSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    readableAccountStatus(dashboard.profile.accountStatus),
                    color = if (dashboard.profile.accountStatus == "active") NeonGreen
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item(key = "profile_geo_id", contentType = "card") {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Tu Geo ID", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            dashboard.profile.geoId.toString(),
                            style = MaterialTheme.typography.headlineMedium,
                            color = NeonGreen,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(
                                ClipData.newPlainText("Geo ID", dashboard.profile.geoId.toString())
                            )
                        }) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copiar Geo ID")
                        }
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Perú · Soles (PEN) · Identifica tu cuenta dentro de Gana Geo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item(key = "profile_legal_title", contentType = "section_title") {
            Text("Legal y ayuda", style = MaterialTheme.typography.titleMedium)
        }
        item(key = "profile_legal", contentType = "menu") {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column {
                    ProfileMenuRow(Icons.Rounded.Policy, "Política de privacidad") { openDoc = LegalDoc.PRIVACY }
                    ProfileMenuRow(Icons.Rounded.Gavel, "Términos y condiciones") { openDoc = LegalDoc.TERMS }
                    ProfileMenuRow(Icons.Rounded.Redeem, "Reglas de Geo Rewards") { openDoc = LegalDoc.REWARDS }
                    ProfileMenuRow(Icons.Rounded.SupportAgent, "Ayuda y soporte") { showSupport = true }
                }
            }
        }

        item(key = "profile_signout", contentType = "action") {
            OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Cerrar sesión")
            }
        }

        item(key = "profile_delete", contentType = "action") {
            TextButton(onClick = { showDelete = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(8.dp))
                Text("Eliminar cuenta", color = MaterialTheme.colorScheme.error)
            }
        }
    }

    openDoc?.let { doc -> LegalDialog(doc = doc, onDismiss = { openDoc = null }) }

    if (showSupport) {
        AlertDialog(
            onDismissRequest = { showSupport = false },
            title = { Text("Ayuda y soporte") },
            text = {
                Text(
                    "Escríbenos a ${LegalTexts.supportContact}. Indica tu Geo ID (${dashboard.profile.geoId}) y explica el problema. Nunca te pediremos contraseñas ni códigos.",
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            confirmButton = { TextButton(onClick = { showSupport = false }) { Text("Entendido") } }
        )
    }

    if (showDelete) {
        DeleteAccountDialog(
            rewards = dashboard.wallet.internalPoints,
            credits = dashboard.toolCredits.availableCredits,
            onDismiss = { showDelete = false },
            onConfirm = {
                showDelete = false
                onDeleteAccount()
            }
        )
    }
}

@Composable
private fun ProfileMenuRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, modifier = Modifier.weight(1f))
        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color(0xFF9AB8A5))
    }
}

@Composable
private fun DeleteAccountDialog(
    rewards: Long,
    credits: Long,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    var confirmText by rememberSaveable { mutableStateOf("") }
    val confirmed = confirmText.trim().equals("ELIMINAR", ignoreCase = true)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Eliminar cuenta") },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(LegalTexts.body(LegalDoc.DELETE), style = MaterialTheme.typography.bodyMedium)
                if (rewards > 0 || credits > 0) {
                    NoticeCard(
                        "Vas a perder $credits créditos y $rewards Geo Rewards.",
                        isError = true
                    )
                }
                OutlinedTextField(
                    value = confirmText,
                    onValueChange = { confirmText = it.take(12) },
                    label = { Text("Escribe ELIMINAR para confirmar") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = confirmed,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = Color.White
                )
            ) {
                Text("Eliminar")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun LegalDialog(doc: LegalDoc, onDismiss: () -> Unit) {
    val body = remember(doc) { LegalTexts.body(doc) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(doc.title) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(body, style = MaterialTheme.typography.bodyMedium)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
private fun LegalCenterDialog(onDismiss: () -> Unit) {
    var openDoc by remember { mutableStateOf<LegalDoc?>(null) }
    val current = openDoc
    if (current != null) {
        LegalDialog(doc = current, onDismiss = { openDoc = null })
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Legal y ayuda") },
        text = {
            Column {
                ProfileMenuRow(Icons.Rounded.Policy, "Política de privacidad") { openDoc = LegalDoc.PRIVACY }
                ProfileMenuRow(Icons.Rounded.Gavel, "Términos y condiciones") { openDoc = LegalDoc.TERMS }
                ProfileMenuRow(Icons.Rounded.Redeem, "Reglas de Geo Rewards") { openDoc = LegalDoc.REWARDS }
                ProfileMenuRow(Icons.Rounded.DeleteForever, "Cómo eliminar una cuenta") { openDoc = LegalDoc.DELETE }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
private fun LedgerRow(entry: LedgerEntry) {
    val positive = entry.pointsDelta > 0 || entry.cashDelta > 0
    val amountText = when {
        entry.pointsDelta != 0L -> "${if (entry.pointsDelta > 0) "+" else ""}${entry.pointsDelta} Rewards"
        entry.cashDelta != 0.0 -> "${if (entry.cashDelta > 0) "+" else ""}${penFormatter.format(entry.cashDelta)}"
        else -> "Sin cambio"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background((if (positive) NeonGreen else Gold).copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (positive) Icons.Rounded.CheckCircle else Icons.Rounded.Payments,
                    contentDescription = null,
                    tint = if (positive) NeonGreen else Gold
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(entry.description ?: entry.entryType.readableEntryType(), fontWeight = FontWeight.SemiBold)
                Text(
                    readableProvider(entry.provider),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text(
                amountText,
                color = if (positive) NeonGreen else Gold,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun readableProvider(provider: String?): String = when (provider) {
    "geo_adventures" -> "Geo Aventuras"
    "gana_geo_tools" -> "Herramientas"
    "gana_geo", "gana_geo_cancel", "gana_geo_paid", "gana_geo_reject" -> "Billetera"
    else -> "Gana Geo"
}

private fun String.readableEntryType(): String = when (this) {
    "game_reward" -> "Rewards por vida dorada"
    "referral_reward" -> "Recompensa por referido"
    "purchase_points" -> "Créditos comprados"
    "tool_reward" -> "Rewards por herramientas"
    "withdrawal" -> "Retiro solicitado"
    "reversal" -> "Devolución"
    else -> "Ajuste de saldo"
}

@Composable
private fun EmptyCard(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Info, contentDescription = null, tint = Gold)
            Spacer(Modifier.width(12.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun NoticeCard(text: String, isError: Boolean) {
    val color = if (isError) MaterialTheme.colorScheme.error else Gold
    Card(
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.10f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(
                if (isError) Icons.Rounded.ErrorOutline else Icons.Rounded.Info,
                contentDescription = null,
                tint = color
            )
            Spacer(Modifier.width(10.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
