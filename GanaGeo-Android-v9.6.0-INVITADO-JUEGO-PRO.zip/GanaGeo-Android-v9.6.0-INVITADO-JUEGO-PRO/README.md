# Gana Geo Android v9.6 — Invitado directo y Geo Aventuras mejorado

Esta versión toma como base la v9.5 y aplica únicamente el flujo de invitado, la presentación del catálogo y las mejoras acordadas para Geo Aventuras. No altera las reglas económicas de créditos, Geo Rewards, referidos o retiros, ni reemplaza el mecanismo de autenticación Google/Supabase.

## Flujo inicial

- Cuando no existe sesión autenticada, la app abre directamente como invitado.
- La opción **Iniciar sesión** permanece visible en una barra compacta superior.
- Cancelar o fallar el selector de Google devuelve al modo invitado.
- La pantalla completa de acceso ya no interrumpe la primera exploración.

## Herramientas para invitados

- Se muestra el catálogo completo.
- Las herramientas gratuitas funcionan normalmente.
- Las herramientas que requieren créditos permanecen visibles con candado y el texto **Inicia sesión**.
- Geo Aventuras está visible y jugable en modo invitado.

## Geo Aventuras

### Invitado

- Solo se muestran vidas rojas y estrellas.
- No aparecen vidas doradas, paquetes, compras ni Rewards.
- El progreso se conserva localmente en el dispositivo.

### Usuario autenticado

- La vida roja o dorada se selecciona en la zona superior y se conserva para el siguiente nivel.
- Si la vida dorada no está disponible, se usa automáticamente la roja.
- Se eliminó la ventana repetitiva de selección de vida al tocar cada nivel.
- Los paquetes de vidas doradas están ubicados arriba del mapa.

### Partida

- Cada partida comienza con **15 vidas internas**.
- Cada muerte consume exactamente una vida.
- El HUD muestra indicadores compactos para vidas, checkpoints, cristales, mecanismos, saltos, tiempo y Rewards.
- Se mantienen el menú de pausa, música, efectos, vibración y reinicio desde checkpoint.

### Apariencia

- Pinchos activos con mayor contraste frente al suelo y las paredes.
- Árboles trampa con tronco, ramas y copas verde claro.
- Manzanas rojas con forma, tallo, hoja, volumen y brillo.
- Se conserva la dificultad extrema y las rutas jugables de la v9.5.

## Compilación

El workflow de GitHub Actions ejecuta pruebas unitarias y genera el APK Debug usando Java 17, Android 36 y Gradle 8.13.

Secretos requeridos:

- `SUPABASE_ANON_KEY`
- `GOOGLE_WEB_CLIENT_ID`

La compilación local requiere los mismos valores mediante variables de entorno o `local.properties`.
