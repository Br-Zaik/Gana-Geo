package com.ganageo.app.data

import com.ganageo.app.model.CancelWithdrawalParams
import com.ganageo.app.model.DashboardData
import com.ganageo.app.model.LedgerEntry
import com.ganageo.app.model.Profile
import com.ganageo.app.model.RegisterDeviceParams
import com.ganageo.app.model.Wallet
import com.ganageo.app.model.Withdrawal
import com.ganageo.app.model.WithdrawalParams
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.Google
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest

class GanaGeoRepository(
    private val client: SupabaseClient
) {
    suspend fun signInWithGoogle() {
        client.auth.signInWith(Google)
    }

    suspend fun signOut() {
        client.auth.signOut()
    }

    fun currentUserId(): String? = client.auth.currentSessionOrNull()?.user?.id

    suspend fun loadDashboard(installationId: String): DashboardData {
        val userId = currentUserId() ?: error("No hay una sesión activa.")

        val profile = client.from("profiles")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeSingle<Profile>()

        val wallet = client.from("wallets")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeSingle<Wallet>()

        val ledger = client.from("ledger_entries")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeList<LedgerEntry>()
            .sortedByDescending { it.createdAt.orEmpty() }
            .take(50)

        val withdrawals = client.from("withdrawals")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeList<Withdrawal>()
            .sortedByDescending { it.requestedAt.orEmpty() }
            .take(50)

        val deviceNotice = try {
            client.postgrest.rpc(
                function = "register_my_device",
                parameters = RegisterDeviceParams(installationId)
            )
            null
        } catch (error: Throwable) {
            val raw = error.message.orEmpty()
            val functionMissing = raw.contains("PGRST202", ignoreCase = true) ||
                raw.contains("Could not find the function", ignoreCase = true) ||
                (raw.contains("register_my_device", ignoreCase = true) &&
                    raw.contains("not found", ignoreCase = true))

            if (functionMissing) {
                "El control de instalación aún no está activado en Supabase. Ejecuta el SQL seguro incluido."
            } else {
                throw error
            }
        }

        return DashboardData(
            profile = profile,
            wallet = wallet,
            ledger = ledger,
            withdrawals = withdrawals,
            deviceNotice = deviceNotice
        )
    }

    suspend fun requestWithdrawal(
        amount: Double,
        paymentMethod: String,
        destination: String
    ) {
        client.postgrest.rpc(
            function = "request_withdrawal",
            parameters = WithdrawalParams(
                amount = amount,
                paymentMethod = paymentMethod,
                paymentDestination = destination.trim()
            )
        )
    }

    suspend fun cancelWithdrawal(withdrawalId: String) {
        client.postgrest.rpc(
            function = "cancel_my_withdrawal",
            parameters = CancelWithdrawalParams(withdrawalId)
        )
    }

    private fun Throwable.cleanMessage(): String =
        message
            ?.replace("PostgrestRestException", "Error de Supabase")
            ?.take(180)
            ?: "error desconocido"
}
