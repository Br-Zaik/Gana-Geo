package com.ganageo.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ganageo.app.data.DeviceIdentityStore
import com.ganageo.app.data.GanaGeoRepository
import com.ganageo.app.data.SupabaseProvider
import com.ganageo.app.model.DashboardData
import io.github.jan.supabase.auth.status.SessionStatus
import io.github.jan.supabase.auth.auth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface AuthPhase {
    data object ConfigurationMissing : AuthPhase
    data object Initializing : AuthPhase
    data object SignedOut : AuthPhase
    data object SignedIn : AuthPhase
}

data class GanaGeoUiState(
    val authPhase: AuthPhase = AuthPhase.Initializing,
    val dashboard: DashboardData? = null,
    val isLoading: Boolean = false,
    val message: String? = null,
    val error: String? = null
)

class GanaGeoViewModel(application: Application) : AndroidViewModel(application) {
    private val client = SupabaseProvider.client
    private val repository = client?.let(::GanaGeoRepository)
    private val deviceStore = DeviceIdentityStore(application)

    private val _uiState = MutableStateFlow(
        GanaGeoUiState(
            authPhase = if (SupabaseProvider.isConfigured) {
                AuthPhase.Initializing
            } else {
                AuthPhase.ConfigurationMissing
            }
        )
    )
    val uiState: StateFlow<GanaGeoUiState> = _uiState.asStateFlow()

    init {
        if (client != null && repository != null) {
            viewModelScope.launch {
                client.auth.sessionStatus.collect { status ->
                    when (status) {
                        SessionStatus.Initializing -> {
                            _uiState.update { it.copy(authPhase = AuthPhase.Initializing) }
                        }

                        is SessionStatus.Authenticated -> {
                            _uiState.update { it.copy(authPhase = AuthPhase.SignedIn) }
                            refreshDashboard()
                        }

                        is SessionStatus.NotAuthenticated -> {
                            _uiState.value = GanaGeoUiState(authPhase = AuthPhase.SignedOut)
                        }

                        is SessionStatus.RefreshFailure -> {
                            _uiState.update {
                                it.copy(
                                    authPhase = AuthPhase.SignedOut,
                                    error = "La sesión venció. Inicia sesión nuevamente."
                                )
                            }
                        }

                        else -> Unit
                    }
                }
            }
        }
    }

    fun signInWithGoogle() {
        val repo = repository ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching { repo.signInWithGoogle() }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = error.userMessage("No se pudo abrir el inicio de sesión con Google.")
                        )
                    }
                }
                .onSuccess {
                    _uiState.update { it.copy(isLoading = false) }
                }
        }
    }

    fun refreshDashboard() {
        val repo = repository ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.loadDashboard(installationId)
            }.onSuccess { dashboard ->
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedIn,
                        dashboard = dashboard,
                        isLoading = false,
                        error = null
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedIn,
                        isLoading = false,
                        error = error.userMessage("No se pudieron cargar tus datos.")
                    )
                }
            }
        }
    }

    fun requestWithdrawal(amountText: String, method: String, destination: String) {
        val repo = repository ?: return
        val amount = amountText.replace(',', '.').toDoubleOrNull()
        val available = _uiState.value.dashboard?.wallet?.availableAmount ?: 0.0

        when {
            amount == null || amount <= 0.0 -> {
                _uiState.update { it.copy(error = "Escribe un monto válido.") }
                return
            }

            amount > available -> {
                _uiState.update { it.copy(error = "No tienes saldo disponible suficiente.") }
                return
            }

            destination.trim().length < 5 -> {
                _uiState.update { it.copy(error = "Escribe un número o correo válido para el pago.") }
                return
            }
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching {
                repo.requestWithdrawal(amount, method, destination)
            }.onSuccess {
                _uiState.update {
                    it.copy(
                        message = "Solicitud registrada. El saldo quedó bloqueado hasta su revisión.",
                        isLoading = false
                    )
                }
                refreshDashboard()
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = error.userMessage(
                            "No se pudo registrar el retiro. Ejecuta primero el SQL seguro incluido en el repositorio."
                        )
                    )
                }
            }
        }
    }

    fun cancelWithdrawal(withdrawalId: String) {
        val repo = repository ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching { repo.cancelWithdrawal(withdrawalId) }
                .onSuccess {
                    _uiState.update {
                        it.copy(message = "Solicitud cancelada y saldo liberado.", isLoading = false)
                    }
                    refreshDashboard()
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = error.userMessage("No se pudo cancelar la solicitud.")
                        )
                    }
                }
        }
    }

    fun signOut() {
        val repo = repository ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching { repo.signOut() }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = error.userMessage("No se pudo cerrar la sesión.")
                        )
                    }
                }
        }
    }

    fun clearNotice() {
        _uiState.update { it.copy(message = null, error = null) }
    }

    private fun Throwable.userMessage(fallback: String): String {
        val raw = message.orEmpty()
        return when {
            raw.contains("device", ignoreCase = true) && raw.contains("active", ignoreCase = true) ->
                "Esta cuenta o este dispositivo ya está vinculado a otra instalación."
            raw.contains("account is not active", ignoreCase = true) ->
                "Tu cuenta no está activa. Comunícate con soporte antes de continuar."
            raw.contains("insufficient", ignoreCase = true) ->
                "No tienes saldo disponible suficiente."
            raw.contains("function", ignoreCase = true) && raw.contains("not", ignoreCase = true) ->
                "$fallback Función de servidor no encontrada."
            raw.isNotBlank() -> "$fallback ${raw.take(180)}"
            else -> fallback
        }
    }
}
