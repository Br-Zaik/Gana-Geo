package com.ganageo.app.tools

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Restos de letras: el lector de texto a veces da una caja un poco más angosta que
 * la tinta (se come el palito de la "P" o la mitad de la primera "E"). Ese pedacito
 * no se borraba y aparecía como una "I" de más o una mancha en la hoja.
 *
 * Aquí: (1) la caja de borrado se estira hasta donde llega la tinta pegada al
 * renglón; (2) lo que igual quede pegado a un renglón, con el color de su letra y
 * de su alto, se reconoce como resto (se borra, no se vuelve pieza).
 *
 * Trabaja sobre colores ARGB (sin Android) para poder probarlo.
 */
object ScanResidue {

    private fun dist(a: Int, b: Int) = ScanBars.dist(a, b)

    /** ¿Este color es tinta de la letra (más cerca de la tinta que del papel)? */
    private fun isInk(color: Int, ink: Int, background: Int): Boolean {
        val toPaper = dist(color, background)
        return toPaper > 60 && dist(color, ink) < toPaper
    }

    /**
     * Caja de borrado estirada hasta el borde real de la tinta pegada al renglón
     * [box] (izq, arriba, der, abajo). A los lados llega hasta 0.7 del alto; arriba y
     * abajo hasta 0.3 (tildes, colas de la "g"). Se detiene en el primer hueco limpio
     * (así no se come un ícono o una viñeta que estén separados) y no se estira si lo
     * de al lado es una línea larga (un borde, un subrayado).
     */
    fun widen(pixels: IntArray, width: Int, height: Int, box: IntArray, ink: Int, background: Int): IntArray {
        val left = box[0].coerceIn(0, width)
        val top = box[1].coerceIn(0, height)
        val right = box[2].coerceIn(left, width)
        val bottom = box[3].coerceIn(top, height)
        val lineHeight = bottom - top
        if (lineHeight < 4 || right - left < 2 || dist(ink, background) < 80) return box.copyOf()
        val gapStop = max(2, (lineHeight * 0.12f).roundToInt())
        val sideReach = max(3, (lineHeight * 0.7f).roundToInt())
        val upReach = max(2, (lineHeight * 0.3f).roundToInt())

        fun columnHasInk(x: Int, y0: Int, y1: Int): Boolean {
            if (x < 0 || x >= width) return false
            var count = 0
            for (y in y0 until y1) if (isInk(pixels[y * width + x], ink, background)) count++
            return count >= 1
        }

        fun rowInk(y: Int, x0: Int, x1: Int): Int {
            if (y < 0 || y >= height) return 0
            var count = 0
            for (x in x0 until x1) if (isInk(pixels[y * width + x], ink, background)) count++
            return count
        }

        // Hacia un lado: hasta el último palito pegado (sin hueco). Si la tinta sigue
        // hasta el límite, es otra cosa (un borde): no se estira.
        fun reach(start: Int, step: Int): Int {
            var last = Int.MIN_VALUE
            var gap = 0
            var x = start
            var travelled = 0
            while (travelled < sideReach) {
                if (columnHasInk(x, top, bottom)) {
                    last = x
                    gap = 0
                } else {
                    gap++
                    if (gap >= gapStop) break
                }
                x += step
                travelled++
            }
            if (travelled >= sideReach && gap == 0) return Int.MIN_VALUE
            return last
        }

        val leftInk = reach(left - 1, -1)
        val rightInk = reach(right, 1)
        val newLeft = if (leftInk == Int.MIN_VALUE) left else min(left, leftInk)
        val newRight = if (rightInk == Int.MIN_VALUE) right else max(right, rightInk + 1)

        // Arriba y abajo: filas con tinta pegadas, pero no una línea casi entera.
        val span = (newRight - newLeft).coerceAtLeast(1)
        fun reachRows(start: Int, step: Int): Int {
            var last = Int.MIN_VALUE
            var gap = 0
            var y = start
            var travelled = 0
            val stopGap = max(1, gapStop / 2)
            while (travelled < upReach) {
                val count = rowInk(y, newLeft, newRight)
                if (count > span * 0.6f) return Int.MIN_VALUE
                if (count > 0) {
                    last = y
                    gap = 0
                } else {
                    gap++
                    if (gap >= stopGap) break
                }
                y += step
                travelled++
            }
            return last
        }
        val topInk = reachRows(top - 1, -1)
        val bottomInk = reachRows(bottom, 1)
        val newTop = if (topInk == Int.MIN_VALUE) top else min(top, topInk)
        val newBottom = if (bottomInk == Int.MIN_VALUE) bottom else max(bottom, bottomInk + 1)
        return intArrayOf(newLeft, newTop, newRight, newBottom)
    }

    /**
     * ¿La pieza [piece] (izq, arriba, der, abajo) es un resto de letra? Sí si está
     * pegada a un renglón (a menos de 0.2 de su alto, o encima de él), no es más alta
     * que el renglón ni más ancha que una letra, y su color es el de la letra.
     * [lines]: cajas de renglón; [inks]: color de la letra de cada renglón;
     * [color]: color principal de la pieza (null = no se sabe, solo cuenta el lugar).
     */
    fun isResidue(piece: IntArray, color: Int?, lines: List<IntArray>, inks: List<Int?>): Boolean {
        val pieceWidth = piece[2] - piece[0]
        val pieceHeight = piece[3] - piece[1]
        if (pieceWidth <= 0 || pieceHeight <= 0) return false
        for ((index, line) in lines.withIndex()) {
            val lineHeight = (line[3] - line[1]).toFloat()
            if (lineHeight < 4f) continue
            if (pieceHeight > lineHeight * 1.3f || pieceWidth > lineHeight * 0.9f) continue
            val overlapY = min(piece[3], line[3]) - max(piece[1], line[1])
            if (overlapY < pieceHeight * 0.5f) continue
            val gap = when {
                piece[2] <= line[0] -> line[0] - piece[2]
                piece[0] >= line[2] -> piece[0] - line[2]
                else -> 0
            }
            if (gap > max(2f, lineHeight * 0.2f)) continue
            val ink = inks.getOrNull(index)
            if (color != null && ink != null && dist(color, ink) > 110) continue
            return true
        }
        return false
    }

    /** Color principal de una zona: el promedio de lo que no es [background]. */
    fun mainColor(pixels: IntArray, width: Int, box: IntArray, background: Int): Int? {
        var red = 0L
        var green = 0L
        var blue = 0L
        var count = 0
        var best = 0
        var darkest = 0
        for (y in box[1] until box[3]) for (x in box[0] until box[2]) {
            val c = pixels[y * width + x]
            val d = dist(c, background)
            if (d > best) {
                best = d
                darkest = c
            }
            if (d > 90) {
                red += (c shr 16) and 0xFF
                green += (c shr 8) and 0xFF
                blue += c and 0xFF
                count++
            }
        }
        if (count == 0) return if (best > 40) darkest else null
        return (0xFF shl 24) or ((red / count).toInt() shl 16) or ((green / count).toInt() shl 8) or (blue / count).toInt()
    }
}
