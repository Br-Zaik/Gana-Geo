package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class GeoGameRulesTest {
    @Test
    fun lifePackagesKeepTwoCreditsPerPremiumLife() {
        GeoGameRules.lifePackages.forEach { pack ->
            assertEquals(pack.lives * GeoGameRules.PREMIUM_LIFE_CREDIT_COST, pack.creditCost)
        }
        assertNull(GeoGameRules.packageByCode("unknown"))
    }

    @Test
    fun starsNeverDependOnRewardsOrLifeType() {
        assertEquals(0, GeoGameRules.calculateStars(false, 3, 10, 60))
        assertEquals(1, GeoGameRules.calculateStars(true, 0, 80, 60))
        assertEquals(2, GeoGameRules.calculateStars(true, 3, 80, 60))
        assertEquals(3, GeoGameRules.calculateStars(true, 3, 50, 60))
    }

    @Test
    fun twentyLevelsAreSplitIntoFourWorlds() {
        assertEquals("Selva del impacto", GeoGameRules.worldName(1))
        assertEquals("Refugios del bosque", GeoGameRules.worldName(6))
        assertEquals("Ruinas del núcleo", GeoGameRules.worldName(11))
        assertEquals("Montañas de la señal", GeoGameRules.worldName(20))
    }
}
