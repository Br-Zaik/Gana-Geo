# Gana Geo Android v8.8 — Juego profesional y navegación estable

> Esta versión corrige el cobro de las herramientas profesionales, registra sus códigos en Supabase y añade **Geo Aventuras**, un minijuego original de plataformas con 20 niveles. No cambia el acceso con Google, nonce, firma, reemplazo de instalación, referidos, billetera ni retiros.

## Antes de instalar el APK

Esta versión **sí necesita una actualización de Supabase**. Ejecuta primero, completo y una sola vez:

```text
supabase/06_paid_tools_geo_adventures.sql
```

El archivo:

- registra las 13 herramientas pagadas, incluidas las cuatro incorporadas en v8.5;
- reemplaza las reservas que podían expirar por operaciones cobradas e idempotentes;
- permite confirmar Rewards después si el archivo ya fue creado y se perdió la conexión;
- crea las tablas y RPC de Geo Aventuras;
- conserva las reglas actuales de créditos y Rewards.

No borra usuarios, perfiles, saldos, retiros ni movimientos anteriores.

## Base heredada de v8.7

### Interfaz y navegación v8.7

- Herramientas conserva la posición de desplazamiento al entrar y volver.
- Se amplió el espacio inferior para que la navegación no cubra tarjetas o botones.
- Geo Aventuras aparece como acceso destacado y abre el nivel con un toque.
- El selector de archivos conserva el destino activo mediante estado guardable y permisos persistentes.

### Imágenes y visores

- Vista grande y completa en Imágenes a PDF.
- Ajustes en vivo y aplicación a una imagen o a todas.
- Visores gratuitos locales para PDF, DOCX, XLSX y PPTX, sin edición.

### Geo Aventuras

- Pantalla completa horizontal, controles superpuestos y pausa.
- Primer arco narrativo de 20 niveles, con recuperación de GEO, Luma, Taro y el Acechante.
- Niveles más largos, saltos, corazones, enemigos con persecución, interacción y disparos posteriores.


### Corrección de herramientas con créditos

- `document_scanner`, `text_to_pdf`, `pdf_watermark_security` e `image_batch_studio` ya son reconocidas por Supabase.
- Las 13 herramientas pagadas validan su precio nuevamente en el servidor.
- El comienzo de una operación usa un UUID único para impedir cobros duplicados por reintentos.
- Los créditos se descuentan al iniciar el procesamiento.
- Si el procesamiento falla antes de crear el resultado, la app solicita la devolución.
- Si el archivo se creó pero no pudo confirmarse por falta de conexión, la operación queda guardada y los Rewards se confirman al volver a Herramientas.
- `complete_tool_operation` es idempotente: una operación no puede entregar Rewards dos veces.

### Geo Aventuras

Juego 2D original dentro de **Herramientas → Geo Aventuras**:

- 20 niveles distribuidos en cuatro mundos.
- Movimiento, salto, plataformas, obstáculos, enemigos, cristales y portal de salida.
- Tres vidas rojas gratuitas al día, según la fecha del servidor en Perú.
- Las vidas rojas no generan Rewards.
- Vidas amarillas premium:
  - 1 vida = 2 créditos.
  - 5 vidas = 10 créditos.
  - 15 vidas = 30 créditos.
- Comprar vidas no entrega Rewards inmediatamente.
- Una vida amarilla se considera utilizada después de 20 segundos de partida válida.
- Cada vida amarilla utilizada suma sus 2 créditos comprados al progreso normal de Rewards.
- Cada 10 créditos comprados y utilizados liberan 50 Geo Rewards.
- Ganar o perder no cambia la cantidad de Rewards.
- Máximo de 10 vidas amarillas utilizadas por día.
- El progreso permite desbloquear niveles y obtener hasta tres estrellas por nivel.
- No incluye apuestas, ruletas, cofres monetarios ni premios retirables según puntaje o suerte.

Las compras de vidas y el inicio de partidas también usan identificadores idempotentes para evitar duplicados durante reintentos de red.

## Reglas económicas conservadas

```text
S/5  = 50 créditos
S/10 = 100 créditos
Cada crédito comprado y realmente utilizado = 5 Geo Rewards
100 Geo Rewards = S/1
500 Geo Rewards = S/5
Retiro mínimo = S/5
```

Los créditos promocionales pueden usarse, pero no generan Rewards retirables. Las reglas de referidos y retiros no fueron modificadas.

## Herramientas profesionales incluidas

### Documentos y PDF

- Escáner multipágina con cámara o galería.
- Imágenes a PDF con orden, edición, filtros, papel, orientación, márgenes, compresión y contraseña.
- Texto a PDF.
- Marca de agua, numeración y protección de PDF.
- Organizar, unir, dividir, reordenar, girar, extraer y comprimir PDF.
- PDF a JPG o PNG.
- Firma dibujada sobre PDF.

### Imágenes

- Procesamiento por lote.
- Comprimir, redimensionar, convertir, recortar, girar y voltear.
- Collage, hoja de fotos carnet, unión vertical/horizontal, fondo sólido, marcos y ZIP.
- Texto y marca de agua.

### Matemática, ciencia y estudio

- Calculadora científica, geometría y conversiones.
- Ecuaciones, matrices, sistema 3×3, vectores, sucesiones, derivadas e integrales polinómicas.
- Graficador, estadística, física, química y tabla periódica.
- Exámenes, flashcards, referencias, agenda, Pomodoro, horario y finanzas educativas.
- QR, códigos de barras, texto, cronómetro y temporizador.

## Configuración local o en GitHub

La URL actual de Supabase es:

```text
https://pnbpeehcbqkdhjueyldn.supabase.co
```

Para compilar localmente, copia `local.properties.example` como `local.properties` y completa:

```properties
SUPABASE_URL=https://pnbpeehcbqkdhjueyldn.supabase.co
SUPABASE_ANON_KEY=TU_CLAVE_PUBLICA
GOOGLE_WEB_CLIENT_ID=TU_CLIENT_ID_WEB.apps.googleusercontent.com
```

En GitHub configura:

```text
Settings → Secrets and variables → Actions
```

```text
SUPABASE_ANON_KEY
GOOGLE_WEB_CLIENT_ID
```

No subas `service_role`, contraseña de PostgreSQL, Client Secret de Google ni archivos keystore.

## Google y firma

Se mantienen sin cambios:

- paquete `com.ganageo.app`;
- Credential Manager;
- nonce criptográfico;
- cliente OAuth web de Supabase;
- cliente OAuth Android y su SHA-1;
- control de una instalación activa por cuenta.

El workflow conserva una firma Debug estable mediante caché y muestra su SHA-1. Para Play Store deberá prepararse posteriormente una compilación Release/AAB y Play App Signing.

## Orden de instalación

1. Abre Supabase SQL Editor.
2. Ejecuta completo `supabase/06_paid_tools_geo_adventures.sql`.
3. Sube el proyecto v8.8 a GitHub.
4. Ejecuta **Actions → Compilar Gana Geo v8.8 Juego Pro y Navegación → Run workflow**.
5. Comprueba que las pruebas y `assembleDebug` terminen en verde.
6. Descarga el artefacto:

```text
Gana-Geo-v8.8-Juego-Pro-Navegacion
```

7. Instala el APK y prueba herramientas, vidas y niveles.

## SQL para proyectos nuevos

En una base completamente nueva ejecuta en este orden:

```text
supabase/01_schema.sql
supabase/02_secure_app_functions.sql
supabase/03_tool_credits.sql
supabase/04_native_login_device_replacement.sql
supabase/05_device_login_permanent_fix.sql
supabase/06_paid_tools_geo_adventures.sql
```

## Alcance de seguridad

- RLS limita las lecturas a cada usuario.
- El servidor vuelve a validar herramienta, costo, instalación y saldo.
- Operaciones, compras de vidas y comienzo de partidas son idempotentes.
- Los Rewards de herramientas y vidas premium se conceden una sola vez.
- La hora diaria de vidas se calcula en el servidor con zona `America/Lima`.

El juego y las herramientas se procesan en el teléfono. Un cliente Android modificado nunca puede considerarse una prueba antifraude absoluta; antes de producción conviene integrar Play Integrity, Google Play Billing y verificación de compras en backend.

Consulta `CAMBIOS_V8_6_GEO_AVENTURAS_SEGURO.txt` y `docs/PRUEBAS_V8_6_GEO_AVENTURAS_SEGURO.md`.

## Versión 0.8.8

- Geo Aventuras incorpora doble salto real con margen de salto y respuesta inmediata.
- Nuevos enemigos: caminantes, saltadores, voladores, tiradores y guardianes.
- Más objetos interactivos: cajas destructibles, interruptores, plataformas móviles, energía, escudos y potenciadores.
- Fondos 2D por capas con paralaje, neblina, montañas, vegetación, ruinas y partículas.
- Música ambiental y efectos locales para saltos, disparos, impactos, cristales, mecanismos, victoria y derrota.
- Corrección de navegación al volver de galería, cámara o selector de archivos: conserva pestaña, herramienta, posición y estado.
