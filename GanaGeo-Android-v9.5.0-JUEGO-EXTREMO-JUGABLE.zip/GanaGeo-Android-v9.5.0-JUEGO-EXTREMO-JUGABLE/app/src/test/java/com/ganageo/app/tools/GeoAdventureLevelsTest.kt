package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class GeoAdventureLevelsTest {
    @Test
    fun createsTwentyExtremeLevelDefinitions() {
        val levels = (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build)
        assertEquals(20, levels.size)
        levels.forEach { level ->
            assertTrue(level.width >= 6_300f)
            assertEquals(3, level.crystals.size)
            assertTrue(level.enemies.isNotEmpty())
            assertTrue(level.hazards.size >= 12)
            assertTrue(level.checkpoints.size in 4..8)
            assertTrue(level.fans.isNotEmpty())
            assertTrue(level.fallingObjects.isNotEmpty())
            level.crystals.forEach { crystal ->
                assertTrue(level.platforms.any { platform ->
                    crystal.x in platform.x..(platform.x + platform.width) &&
                        crystal.y == platform.y - 92f
                })
            }
            assertTrue(level.platforms.any { it.x <= 70f && it.x + it.width > 70f })
            assertTrue(level.platforms.any { it.x <= level.goalX && it.x + it.width >= level.goalX })
            assertTrue(level.parSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS)
        }
    }

    @Test
    fun levelsContainTheRequestedTrapFamilies() {
        val levels = (1..20).map(GeoAdventureLevelFactory::build)
        val allPlatforms = levels.flatMap { it.platforms }
        val allHazards = levels.flatMap { it.hazards }
        val allCheckpoints = levels.flatMap { it.checkpoints }
        assertTrue(allPlatforms.any { it.kind == PlatformKind.FALLING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.DISAPPEARING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.REVEALING })
        assertTrue(allHazards.any { it.kind == HazardKind.HIDDEN_SPIKES })
        assertTrue(allHazards.any { it.kind == HazardKind.SAW })
        assertTrue(allHazards.any { it.kind == HazardKind.FIRE })
        assertTrue(allCheckpoints.any { it.kind == CheckpointKind.POPUP })
        assertTrue(allCheckpoints.any { it.kind == CheckpointKind.DECOY })
    }

    @Test
    fun firstFourLevelsUseTenLivesAndHandcraftedTrollMechanics() {
        val extreme = (1..4).map(GeoAdventureLevelFactory::build)
        extreme.forEach { level ->
            assertEquals(GeoGameRules.GAME_LIVES_PER_RUN, GeoGameRules.attemptsForLevel(level.number))
            assertTrue(level.hazards.count { it.kind == HazardKind.HIDDEN_SPIKES } >= 10)
            assertTrue(level.hazards.any { it.camouflaged })
            assertTrue(level.platforms.any { it.kind == PlatformKind.PROXIMITY_DISAPPEARING })
            assertTrue(level.fallingObjects.any { it.behavior != FallingBehavior.DROP })
            assertTrue(level.chasingHoles.isNotEmpty())
            assertTrue(level.crushers.isNotEmpty())
            assertTrue(level.checkpoints.any { it.kind == CheckpointKind.DECOY })
            assertTrue(level.checkpoints.count { it.kind == CheckpointKind.POPUP } >= 2)
            assertTrue(level.enemies.all { it.health == 2 })
        }
    }

    @Test
    fun realCheckpointsDoNotSitOnLethalObjects() {
        (1..4).map(GeoAdventureLevelFactory::build).forEach { level ->
            level.checkpoints.filter { it.kind != CheckpointKind.DECOY }.forEach { checkpoint ->
                assertTrue(level.hazards.none { hazard ->
                    abs((hazard.x + hazard.width / 2f) - checkpoint.x) < 85f &&
                        hazard.y + hazard.height > checkpoint.y - 15f
                })
                assertTrue(level.chasingHoles.none { hole ->
                    checkpoint.x in (hole.startX - 40f)..(hole.startX + hole.width + 40f)
                })
                assertTrue(level.fallingObjects.none { falling ->
                    abs(falling.x - checkpoint.x) < 95f
                })
            }
        }
    }

    @Test
    fun handcraftedGroundRouteNeverHasAnImpossibleStaticGap() {
        (1..4).map(GeoAdventureLevelFactory::build).forEach { level ->
            val ground = level.platforms.filter { it.y == 620f }.sortedBy { it.x }
            ground.zipWithNext().forEach { (left, right) ->
                val gap = right.x - (left.x + left.width)
                assertTrue("Nivel ${level.number}: hueco estático de $gap", gap <= 160f)
            }
        }
    }

    @Test
    fun laterLevelsGrowLongerAndMoreDangerous() {
        val first = GeoAdventureLevelFactory.build(1)
        val middle = GeoAdventureLevelFactory.build(10)
        val last = GeoAdventureLevelFactory.build(20)
        assertTrue(last.width > first.width)
        assertTrue(last.hazards.size > first.hazards.size)
        assertTrue(last.checkpoints.size > first.checkpoints.size)
        assertTrue(middle.movingPlatforms.isNotEmpty())
        assertTrue(last.switches.size >= first.switches.size)
        assertTrue(last.acechantePresent)
    }
}
