# Gana Geo Android v0.10.28

Esta version mantiene Geo Aventuras FULL TROLL de v0.10.27 y agrega **multijugador de hasta 3 jugadores** sin modificar la logica existente de inicio de sesion.

## Modos

- **Solo:** conserva la aventura individual, vidas, compras y progreso anteriores.
- **Online:** solo para cuentas iniciadas, por Internet entre lugares distintos.
- **Multijugador local:** invitado o cuenta, por la misma Wi-Fi/hotspot, sin depender de Internet durante la partida.

## Online

- Reutiliza el **Geo ID permanente existente** de la cuenta.
- Buscar/agregar jugadores por Geo ID.
- Crear sala, invitar con `+` y compartir invitacion mediante Android/WhatsApp.
- Hasta 3 jugadores.
- El host selecciona cualquiera de SUS niveles desbloqueados; los otros pueden entrar aunque ese nivel este bloqueado para ellos.
- Al completar el nivel se desbloquea **ese nivel exacto** para los participantes que lo tenian bloqueado.
- Al terminar, todos vuelven a la misma sala y pueden jugar otro nivel sin recrearla.

## Local

- LAN directa con host autoritativo.
- Descubrimiento por UDP y conexion TCP.
- Fallback manual por IP si el hotspot/router bloquea el descubrimiento.
- Invitado vs invitado, invitado vs cuenta o cuenta vs cuenta.
- El progreso local se guarda de forma dispersa. Las cuentas intentan sincronizar sus desbloqueos locales cuando vuelven a tener Online.

## Espectador

Cada jugador comienza con 15 vidas. Al llegar a 0 queda eliminado y pasa a espectador. Mientras exista un superviviente no vuelve al lobby: observa automaticamente su camara, sin controles ni cambio manual de jugador. Cuando alguien completa el nivel o todos son eliminados, el grupo regresa unido a la sala.

## Apariencia

Colores gratuitos: verde, azul, rojo, morado, cian y naranja. Hay soporte para apariencias doradas/amarillas premium, siempre cosmeticas: no cambian hitbox, fisica, velocidad, salto ni vidas. No se agrego un precio nuevo en esta version.

## Instalacion Online: SQL obligatorio

Antes de probar Online, ejecutar `supabase/08_geo_adventures_multiplayer.sql` **despues** de los SQL 01..07 existentes. Es una migracion aditiva con tablas/RPC `geo_mp_*`.

## Validacion

- 43/43 pruebas de Geo Aventuras PASS.
- 23/23 comprobaciones de contrato multijugador PASS.
- Typecheck Kotlin aislado PASS para Local, Online, Session y DataStore de progreso.
- 12/12 archivos protegidos SHA-256 OK.

El build Android completo no pudo ejecutarse en este entorno porque el script `gradlew` necesita descargar Gradle 8.13 desde `services.gradle.org`. Compilar el APK con GitHub Actions y probar Online con cuentas/dispositivos reales.
