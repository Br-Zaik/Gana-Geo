package com.ganageo.app.ui.tools

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import com.ganageo.app.R

internal enum class GameSound {
    JUMP,
    DOUBLE_JUMP,
    SHOOT,
    ENEMY_SHOT,
    HIT,
    CRYSTAL,
    SWITCH,
    PICKUP,
    CHECKPOINT,
    TRAP,
    BUTTON,
    LAND,
    SPIKE,
    HOLE,
    CRUSHER,
    FRUIT_DROP,
    EXPLOSION,
    ENEMY_STOMP,
    DECOY,
    DEATH_RED,
    DEATH_GOLD,
    VICTORY,
    DEFEAT
}

internal class GameAudioController(context: Context, levelNumber: Int) {
    private val appContext = context.applicationContext
    private val soundPool = SoundPool.Builder()
        .setMaxStreams(10)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val soundIds = mapOf(
        GameSound.JUMP to soundPool.load(appContext, R.raw.geo_jump, 1),
        GameSound.DOUBLE_JUMP to soundPool.load(appContext, R.raw.geo_double_jump, 1),
        GameSound.SHOOT to soundPool.load(appContext, R.raw.geo_shoot, 1),
        GameSound.ENEMY_SHOT to soundPool.load(appContext, R.raw.geo_enemy_shot, 1),
        GameSound.HIT to soundPool.load(appContext, R.raw.geo_hit, 1),
        GameSound.CRYSTAL to soundPool.load(appContext, R.raw.geo_crystal, 1),
        GameSound.SWITCH to soundPool.load(appContext, R.raw.geo_switch, 1),
        GameSound.PICKUP to soundPool.load(appContext, R.raw.geo_pickup, 1),
        GameSound.CHECKPOINT to soundPool.load(appContext, R.raw.geo_checkpoint, 1),
        GameSound.TRAP to soundPool.load(appContext, R.raw.geo_trap, 1),
        GameSound.BUTTON to soundPool.load(appContext, R.raw.geo_button, 1),
        GameSound.LAND to soundPool.load(appContext, R.raw.geo_land, 1),
        GameSound.SPIKE to soundPool.load(appContext, R.raw.geo_spike, 1),
        GameSound.HOLE to soundPool.load(appContext, R.raw.geo_hole, 1),
        GameSound.CRUSHER to soundPool.load(appContext, R.raw.geo_crusher, 1),
        GameSound.FRUIT_DROP to soundPool.load(appContext, R.raw.geo_fruit_drop, 1),
        GameSound.EXPLOSION to soundPool.load(appContext, R.raw.geo_explosion, 1),
        GameSound.ENEMY_STOMP to soundPool.load(appContext, R.raw.geo_enemy_stomp, 1),
        GameSound.DECOY to soundPool.load(appContext, R.raw.geo_decoy, 1),
        GameSound.DEATH_RED to soundPool.load(appContext, R.raw.geo_death_red, 1),
        GameSound.DEATH_GOLD to soundPool.load(appContext, R.raw.geo_death_gold, 1),
        GameSound.VICTORY to soundPool.load(appContext, R.raw.geo_victory, 1),
        GameSound.DEFEAT to soundPool.load(appContext, R.raw.geo_defeat, 1)
    )

    private val musicResource = when (levelNumber.coerceIn(1, 20)) {
        1 -> R.raw.geo_level_01
        2 -> R.raw.geo_level_02
        3 -> R.raw.geo_level_03
        4 -> R.raw.geo_level_04
        5 -> R.raw.geo_level_05
        6 -> R.raw.geo_level_06
        7 -> R.raw.geo_level_07
        8 -> R.raw.geo_level_08
        9 -> R.raw.geo_level_09
        10 -> R.raw.geo_level_10
        11 -> R.raw.geo_level_11
        12 -> R.raw.geo_level_12
        13 -> R.raw.geo_level_13
        14 -> R.raw.geo_level_14
        15 -> R.raw.geo_level_15
        16 -> R.raw.geo_level_16
        17 -> R.raw.geo_level_17
        18 -> R.raw.geo_level_18
        19 -> R.raw.geo_level_19
        else -> R.raw.geo_level_20
    }

    private var musicPlayer: MediaPlayer? = MediaPlayer.create(appContext, musicResource)?.apply {
        isLooping = true
        setVolume(0.20f, 0.20f)
    }

    var musicEnabled: Boolean = true
        private set
    var effectsEnabled: Boolean = true
        private set

    fun startMusic() {
        if (!musicEnabled) return
        runCatching { musicPlayer?.takeIf { !it.isPlaying }?.start() }
    }

    fun pauseMusic() {
        runCatching { musicPlayer?.takeIf { it.isPlaying }?.pause() }
    }

    fun setMusicEnabled(enabled: Boolean) {
        musicEnabled = enabled
        if (enabled) startMusic() else pauseMusic()
    }

    fun setEffectsEnabled(enabled: Boolean) {
        effectsEnabled = enabled
    }

    fun play(sound: GameSound, volume: Float = 1f, rate: Float = 1f) {
        if (!effectsEnabled) return
        val id = soundIds[sound] ?: return
        val safeVolume = volume.coerceIn(0f, 1f)
        soundPool.play(id, safeVolume, safeVolume, 1, 0, rate.coerceIn(0.5f, 2f))
    }

    fun release() {
        runCatching {
            musicPlayer?.stop()
            musicPlayer?.release()
        }
        musicPlayer = null
        soundPool.release()
    }
}
