# Gana Geo Android v0.10.23

Corrección integral de **Geo Aventuras** sobre la base v0.10.22, centrada en eliminar bloqueos reales de ruta y comportamientos inconsistentes observados en el APK compilado y en los videos de prueba.

## Cambios principales de Geo Aventuras

- Los 20 niveles conservan la dificultad troll, pero ahora tienen una **ruta estructural permanente de respaldo**: las plataformas móviles, switches, rocas que se convierten en plataforma y otros elementos dinámicos ya no son el único punto de paso para completar un nivel.
- Se rehizo `SURPRISE_CORRIDOR` del nivel 2 y las familias `TRAP_LIFT`, `TRICK_ASCENT`, `ROCK_BRIDGE`, `MOVING_GAP` y `SHAFT_UP` para evitar geometría cerrada o saltos físicamente bloqueados.
- La validación de rutas ahora considera el **hitbox real de GEO (44 x 58 px)**, techo, colisión lateral con muros y continuidad de pisos.
- Se eliminó un cuello de solo 15 px detectado en `SHAFT_UP`, que era físicamente imposible para GEO.
- Las plataformas móviles transportan a GEO usando su desplazamiento real por frame.
- WALKER/JUMPER/GUARDIAN calculan soporte con terreno local al enemigo, detectan bordes y no deben suicidarse al salir de la zona de colisión del jugador.
- Proyectiles de GEO y de enemigos chocan contra terreno y barreras.
- Objetos `CHASE` respetan terreno y barreras; las frutas `ROLL` fijan dirección al impactar, chocan con paredes y caen por huecos en vez de flotar.
- Checkpoint: la zona de gracia solo corresponde al checkpoint activo y dura un intervalo corto; checkpoints futuros ya no dan invulnerabilidad invisible.
- Cajas: interacción exige cercanía horizontal y vertical.
- Barreras participan también en colisión vertical.
- Triggers `JUMP_NEAR` y `LAND_NEAR` tienen un fallback determinista por corredor y altura para evitar activaciones tardías o inconsistentes.
- Rocas y bolas de pinchos no controladas por switch usan retrasos cortos (máximo 220 ms en la validación actual).
- Los pinchos ocultos solo son letales después de terminar su animación de aparición.
- En plataformas estrechas, los pinchos sorpresa se recolocan/reducen si no dejan una zona real de aterrizaje.
- Se eliminaron estructuras WALL/ROOF duplicadas o anidadas.
- Se retiró el retraso artificial de entrada del conducto de llegada.

## Validación local

- 26/26 pruebas de `GeoAdventureLevelsTest` ejecutadas correctamente con un runner local.
- 20/20 niveles pasan la auditoría conservadora de ruta.
- 20/20 niveles pasan una auditoría adicional usando solo plataformas permanentes, con colisión lateral y ancho real del personaje.
- 0 enemigos terrestres nacen sin soporte permanente.
- 0 pinchos ocultos detectados ocupando casi toda una plataforma estrecha.
- Archivos protegidos de login, Google, Supabase, sesión y backend se verifican por SHA-256 antes del empaquetado final.

## Limitación del entorno

El build Android completo no puede ejecutarse aquí porque Gradle 8.13 necesita descargarse desde `services.gradle.org` y el entorno no tiene resolución de red para ese host. La fábrica de niveles y sus tests Kotlin sí se compilan y ejecutan localmente. La prueba final en dispositivo debe hacerse con el APK compilado desde este ZIP.

No se modificaron inicio de sesión, Google, Supabase, créditos, Geo Rewards, referidos, retiros ni otras herramientas de Gana Geo.
