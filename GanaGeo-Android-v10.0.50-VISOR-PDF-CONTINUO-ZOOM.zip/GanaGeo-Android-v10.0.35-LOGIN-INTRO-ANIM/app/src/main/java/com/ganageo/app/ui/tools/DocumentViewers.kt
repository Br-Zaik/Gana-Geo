package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.net.Uri
import android.util.Xml
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

@Composable
fun PdfViewerScreen(tool: ToolId, onBack: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val horizontalScrollState = rememberScrollState()
    var uriText by rememberSaveable { mutableStateOf<String?>(null) }
    val uri = uriText?.let(Uri::parse)
    var pageCount by rememberSaveable { mutableIntStateOf(0) }
    var loadingDocument by remember { mutableStateOf(false) }
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selected,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            uriText = selected.toString()
            pageCount = 0
            zoom = 1f
            scope.launch {
                listState.scrollToItem(0)
                horizontalScrollState.scrollTo(0)
                loadingDocument = true
                runCatching { ToolFileUtils.pdfPageCount(context, selected) }
                    .onSuccess { pageCount = it }
                    .onFailure { onMessage(it.message ?: "No se pudo abrir el PDF.") }
                loadingDocument = false
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Visor gratuito · el archivo no se modifica", onBack)

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val viewerWidth = maxWidth * zoom
            val renderWidth = when {
                zoom >= 2.25f -> 2000
                zoom >= 1.4f -> 1600
                else -> 1200
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(uriText) {
                        awaitEachGesture {
                            do {
                                val event = awaitPointerEvent()
                                if (event.changes.count { it.pressed } >= 2) {
                                    val gestureZoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    val pressed = event.changes.filter { it.pressed }
                                    val centroid = if (pressed.isEmpty()) {
                                        androidx.compose.ui.geometry.Offset.Zero
                                    } else {
                                        androidx.compose.ui.geometry.Offset(
                                            pressed.sumOf { it.position.x.toDouble() }.toFloat() / pressed.size,
                                            pressed.sumOf { it.position.y.toDouble() }.toFloat() / pressed.size
                                        )
                                    }
                                    val oldZoom = zoom
                                    val newZoom = (oldZoom * gestureZoom).coerceIn(1f, 3.2f)

                                    if (newZoom != oldZoom) {
                                        val scaleChange = newZoom / oldZoom
                                        val targetScroll =
                                            ((horizontalScrollState.value + centroid.x) * scaleChange - centroid.x - pan.x)
                                                .coerceAtLeast(0f)
                                        zoom = newZoom
                                        horizontalScrollState.dispatchRawDelta(
                                            targetScroll - horizontalScrollState.value
                                        )
                                    } else if (zoom > 1f && pan.x != 0f) {
                                        horizontalScrollState.dispatchRawDelta(-pan.x)
                                    }

                                    if (pan.y != 0f) {
                                        listState.dispatchRawDelta(-pan.y)
                                    }

                                    event.changes.forEach { it.consume() }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }
                    .horizontalScroll(horizontalScrollState)
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .width(viewerWidth)
                        .fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = 12.dp,
                        end = 12.dp,
                        top = 8.dp,
                        bottom = 120.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item(key = "pdf_picker") {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CardGreen),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(
                                Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    uri?.let { ToolFileUtils.displayName(context, it) }
                                        ?: "Ningún PDF seleccionado",
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedButton(
                                    onClick = { launcher.launch(arrayOf("application/pdf")) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                                    Text(if (uri == null) " Abrir PDF" else " Cambiar PDF")
                                }
                                if (uri != null && pageCount > 0) {
                                    Text(
                                        "$pageCount páginas · desliza hacia abajo · pellizca con dos dedos para ampliar",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    if (loadingDocument) {
                        item(key = "pdf_loading") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = NeonGreen)
                            }
                        }
                    }

                    if (uri != null && pageCount > 0) {
                        items(
                            count = pageCount,
                            key = { index -> "pdf_page_$index" },
                            contentType = { "pdf_page" }
                        ) { index ->
                            ContinuousPdfPage(
                                uri = uri,
                                pageIndex = index,
                                renderWidth = renderWidth,
                                onMessage = onMessage
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ContinuousPdfPage(
    uri: Uri,
    pageIndex: Int,
    renderWidth: Int,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var bitmap by remember(uri, pageIndex, renderWidth) { mutableStateOf<Bitmap?>(null) }
    var loading by remember(uri, pageIndex, renderWidth) { mutableStateOf(true) }

    LaunchedEffect(uri, pageIndex, renderWidth) {
        loading = true
        runCatching {
            ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = renderWidth)
        }.onSuccess { fresh ->
            val previous = bitmap
            bitmap = fresh
            previous?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure {
            onMessage(it.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
        }
        loading = false
    }

    DisposableEffect(uri, pageIndex, renderWidth) {
        onDispose {
            bitmap?.takeIf { !it.isRecycled }?.recycle()
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            "Página ${pageIndex + 1}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF07170F)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                val current = bitmap
                if (current != null) {
                    Image(
                        bitmap = current.asImageBitmap(),
                        contentDescription = "Página ${pageIndex + 1}",
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(420.dp)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        if (loading) CircularProgressIndicator(color = NeonGreen)
                    }
                }
            }
        }
    }
}

enum class OfficeViewerType(val label: String, val extensions: String, val mimeTypes: Array<String>) {
    WORD("Word", "DOCX", arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")),
    EXCEL("Excel", "XLSX", arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")),
    POWERPOINT("PowerPoint", "PPTX", arrayOf("application/vnd.openxmlformats-officedocument.presentationml.presentation"))
}

@Composable
fun OfficeViewerScreen(
    tool: ToolId,
    type: OfficeViewerType,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var uriText by rememberSaveable { mutableStateOf<String?>(null) }
    val uri = uriText?.let { Uri.parse(it) }
    var sections by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selected,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            uriText = selected.toString()
            scope.launch {
                loading = true
                runCatching {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(selected)?.use { stream ->
                            val bytes = stream.readBytes()
                            when (type) {
                                OfficeViewerType.WORD -> parseDocx(bytes)
                                OfficeViewerType.EXCEL -> parseXlsx(bytes)
                                OfficeViewerType.POWERPOINT -> parsePptx(bytes)
                            }
                        } ?: error("No se pudo leer el archivo.")
                    }
                }.onSuccess { sections = it }
                    .onFailure { onMessage(it.message ?: "No se pudo abrir el archivo ${type.extensions}.") }
                loading = false
            }
        }
    }

    val filtered = remember(sections, query) {
        if (query.isBlank()) sections
        else sections.mapNotNull { (title, body) ->
            val lines = body.lineSequence().filter { it.contains(query, ignoreCase = true) }.toList()
            if (lines.isEmpty() && !title.contains(query, ignoreCase = true)) null
            else title to (if (lines.isEmpty()) body else lines.joinToString("\n"))
        }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Visor gratuito ${type.extensions} · sin edición", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            uri?.let { ToolFileUtils.displayName(context, it) } ?: "Ningún archivo seleccionado",
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedButton(onClick = { launcher.launch(type.mimeTypes) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                            Text(" Abrir ${type.label}")
                        }
                        Text(
                            "Vista básica local. Conserva el contenido y la estructura principal; diseños complejos pueden verse simplificados.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (loading) item { Box(Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = NeonGreen) } }
            if (sections.isNotEmpty()) {
                item {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it.take(80) },
                        label = { Text("Buscar dentro del archivo") },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                itemsIndexed(filtered) { index, item ->
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(item.first.ifBlank { "Sección ${index + 1}" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(item.second.ifBlank { "Sin texto visible" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

private fun unzipEntries(bytes: ByteArray): Map<String, ByteArray> {
    val result = linkedMapOf<String, ByteArray>()
    ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
        while (true) {
            val entry = zip.nextEntry ?: break
            if (!entry.isDirectory) {
                val out = ByteArrayOutputStream()
                zip.copyTo(out)
                result[entry.name] = out.toByteArray()
            }
            zip.closeEntry()
        }
    }
    return result
}

private fun extractXmlText(bytes: ByteArray, lineBreakTags: Set<String>): String {
    val parser = Xml.newPullParser().apply {
        setInput(ByteArrayInputStream(bytes), "UTF-8")
    }
    val out = StringBuilder()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.TEXT -> {
                val text = parser.text.orEmpty()
                if (text.isNotBlank()) out.append(text)
            }
            XmlPullParser.END_TAG -> if (parser.name in lineBreakTags) {
                if (out.isNotEmpty() && out.last() != '\n') out.append('\n')
            }
        }
        event = parser.next()
    }
    return out.toString().replace(Regex("[ \\t]+\n"), "\n").replace(Regex("\n{3,}"), "\n\n").trim()
}

private fun parseDocx(bytes: ByteArray): List<Pair<String, String>> {
    val entries = unzipEntries(bytes)
    val document = entries["word/document.xml"] ?: error("El DOCX no contiene un documento legible.")
    val text = extractXmlText(document, setOf("p", "tr", "tc"))
    return listOf("Documento" to text)
}

private fun parsePptx(bytes: ByteArray): List<Pair<String, String>> {
    val entries = unzipEntries(bytes)
    val slides = entries.filterKeys { it.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
        .toList()
        .sortedBy { it.first.filter(Char::isDigit).toIntOrNull() ?: 0 }
    if (slides.isEmpty()) error("El PPTX no contiene diapositivas legibles.")
    return slides.mapIndexed { index, (_, data) ->
        "Diapositiva ${index + 1}" to extractXmlText(data, setOf("p", "br"))
    }
}

private fun parseXlsx(bytes: ByteArray): List<Pair<String, String>> {
    val entries = unzipEntries(bytes)
    val shared = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) }.orEmpty()
    val sheets = entries.filterKeys { it.matches(Regex("xl/worksheets/sheet\\d+\\.xml")) }
        .toList()
        .sortedBy { it.first.filter(Char::isDigit).toIntOrNull() ?: 0 }
    if (sheets.isEmpty()) error("El XLSX no contiene hojas legibles.")
    return sheets.mapIndexed { index, (_, data) ->
        "Hoja ${index + 1}" to parseWorksheet(data, shared)
    }
}

private fun parseSharedStrings(bytes: ByteArray): List<String> {
    val parser = Xml.newPullParser().apply { setInput(ByteArrayInputStream(bytes), "UTF-8") }
    val values = mutableListOf<String>()
    var insideSi = false
    var current = StringBuilder()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> if (parser.name == "si") { insideSi = true; current = StringBuilder() }
            XmlPullParser.TEXT -> if (insideSi) current.append(parser.text.orEmpty())
            XmlPullParser.END_TAG -> if (parser.name == "si") { values += current.toString(); insideSi = false }
        }
        event = parser.next()
    }
    return values
}

private fun parseWorksheet(bytes: ByteArray, shared: List<String>): String {
    val parser = Xml.newPullParser().apply { setInput(ByteArrayInputStream(bytes), "UTF-8") }
    val out = StringBuilder()
    var cellType: String? = null
    var cellRef = ""
    var inValue = false
    var value = ""
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> when (parser.name) {
                "row" -> if (out.isNotEmpty() && out.last() != '\n') out.append('\n')
                "c" -> {
                    cellType = parser.getAttributeValue(null, "t")
                    cellRef = parser.getAttributeValue(null, "r").orEmpty()
                    value = ""
                }
                "v", "t" -> inValue = true
            }
            XmlPullParser.TEXT -> if (inValue) value += parser.text.orEmpty()
            XmlPullParser.END_TAG -> when (parser.name) {
                "v", "t" -> inValue = false
                "c" -> {
                    val shown = if (cellType == "s") shared.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value
                    if (shown.isNotBlank()) out.append(if (cellRef.isBlank()) "" else "$cellRef: ").append(shown).append("    ")
                }
            }
        }
        event = parser.next()
    }
    return out.toString().trim()
}
