package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class PlatformKind { SOLID, FALLING, DISAPPEARING, PROXIMITY_DISAPPEARING, REVEALING, BOUNCE }
enum class HazardKind { SPIKES, HIDDEN_SPIKES, SAW, FIRE, CEILING_SPIKES }
enum class HazardOrientation { UP, DOWN, LEFT, RIGHT }
enum class CheckpointKind { SAFE, POPUP, DECOY }
enum class FallingObjectKind { ROCK, FRUIT, CRATE, SPIKE_BALL }
enum class FallingBehavior { DROP, EXPLODE, ROLL, CHASE, CHAIN }
enum class CrusherAxis { HORIZONTAL, VERTICAL }
enum class GameEnemyKind { WALKER, JUMPER, FLYER, SHOOTER, GUARDIAN }
enum class GamePickupKind { ENERGY, SHIELD, POWER }

data class GamePlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float = 34f,
    val kind: PlatformKind = PlatformKind.SOLID,
    val triggerX: Float = x - 90f,
    val delayMs: Long = 320L,
    val cycleMs: Long = 2_200L,
    val phaseMs: Long = 0L
)

data class GameHazard(
    val x: Float,
    val y: Float,
    val width: Float = 58f,
    val height: Float = 42f,
    val kind: HazardKind = HazardKind.SPIKES,
    val triggerX: Float = x - 105f,
    val cycleMs: Long = 0L,
    val phaseMs: Long = 0L,
    val orientation: HazardOrientation = HazardOrientation.UP,
    val camouflaged: Boolean = false
)

data class GameBarrier(
    val x: Float,
    val y: Float = 270f,
    val width: Float = 46f,
    val height: Float = 350f,
    val switchIndex: Int
)

data class GameEnemy(
    val x: Float,
    val y: Float,
    val range: Float = 120f,
    val detectionRange: Float = 480f,
    val health: Int = 2,
    val kind: GameEnemyKind = GameEnemyKind.WALKER,
    val speed: Float = 72f
)

data class GameCrystal(val x: Float, val y: Float)
data class GameCrate(val x: Float, val y: Float)
data class GameSwitch(val x: Float, val y: Float, val opensAtX: Float, val reversesFans: Boolean = false)

data class GamePickup(val x: Float, val y: Float, val kind: GamePickupKind)

data class GameMovingPlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val travel: Float,
    val vertical: Boolean,
    val periodSeconds: Float = 3.4f
)

data class GameCheckpoint(
    val x: Float,
    val y: Float = 535f,
    val kind: CheckpointKind = CheckpointKind.SAFE,
    val appearTriggerX: Float = x - 180f
)

data class GameFan(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val forceX: Float,
    val forceY: Float,
    val cycleMs: Long = 0L,
    val phaseMs: Long = 0L,
    val switchIndex: Int? = null
)

data class GameFallingObject(
    val x: Float,
    val startY: Float,
    val targetY: Float,
    val size: Float,
    val triggerX: Float,
    val kind: FallingObjectKind,
    val delayMs: Long = 180L,
    val behavior: FallingBehavior = FallingBehavior.DROP,
    val rollDirection: Float = 1f,
    val explosionRadius: Float = 130f,
    val chainCount: Int = 1,
    val chainSpacing: Float = 74f
)

data class GameChasingHole(
    val startX: Float,
    val y: Float = 592f,
    val width: Float = 145f,
    val height: Float = 48f,
    val triggerX: Float,
    val speed: Float = 170f,
    val maxTravel: Float = 720f,
    val direction: Float = 1f
)

data class GameCrusher(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val triggerX: Float,
    val axis: CrusherAxis,
    val travel: Float,
    val speed: Float = 540f,
    val delayMs: Long = 100L,
    val reverseAfterMs: Long = 850L
)

data class AdventureLevel(
    val number: Int,
    val worldName: String,
    val levelName: String,
    val objective: String,
    val difficultyLabel: String,
    val width: Float,
    val platforms: List<GamePlatform>,
    val movingPlatforms: List<GameMovingPlatform>,
    val hazards: List<GameHazard>,
    val barriers: List<GameBarrier>,
    val enemies: List<GameEnemy>,
    val crystals: List<GameCrystal>,
    val crates: List<GameCrate>,
    val switches: List<GameSwitch>,
    val checkpoints: List<GameCheckpoint>,
    val fans: List<GameFan>,
    val fallingObjects: List<GameFallingObject>,
    val chasingHoles: List<GameChasingHole>,
    val crushers: List<GameCrusher>,
    val requiredMechanisms: Int,
    val pickups: List<GamePickup>,
    val goalX: Float,
    val parSeconds: Int,
    val introStory: String? = null,
    val outroStory: String? = null,
    val companion: String? = null,
    val injured: Boolean = false,
    val weaponEnabled: Boolean = false,
    val acechantePresent: Boolean = false
)

object GeoAdventureLevelFactory {
    private val names = listOf(
        "La primera mentira", "El suelo te persigue", "El bosque te quiere muerto", "El checkpoint asesino",
        "Bosque de botones", "La ruta que desaparece", "Frutas del cielo", "Puertas con memoria",
        "Ruinas invisibles", "El ventilador doble", "La torre que respira", "No mires atrás",
        "Interruptores cruzados", "El pasillo imposible", "La lluvia de metal", "El defensor falso",
        "El bosque te observa", "La persecución del Acechante", "Todo estaba preparado", "La nave sigue viva"
    )

    private val intros = mapOf(
        1 to "GEO despierta en un planeta donde el escenario parece ayudarlo, pero cada objeto puede esconder una trampa.",
        5 to "Luma descubre que los mecanismos del bosque responden a botones antiguos. Algunos abren caminos; otros despiertan peligros.",
        9 to "Las ruinas ocultan bloques, corrientes de aire y checkpoints que solo aparecen cuando GEO ya está en peligro.",
        13 to "Taro guía a GEO por la torre. Cada interruptor modifica varias partes del nivel y ninguna ruta permanece igual.",
        17 to "El Acechante entra al bosque. Ya no basta memorizar trampas: ahora también hay que avanzar bajo presión."
    )

    private val outros = mapOf(
        4 to "El último checkpoint era real, pero activó una nueva trampa. GEO comprende que incluso la seguridad tiene un precio.",
        8 to "Luma aprende a leer las corrientes del bosque y señala las partículas que delatan a los ventiladores ocultos.",
        12 to "Taro bloquea una compuerta mientras la torre cambia de forma. El camino a la señal ya no puede cerrarse.",
        16 to "Una plataforma se derrumba detrás de ellos. La única salida está delante, donde el Acechante ya los espera.",
        20 to "GEO alcanza la nave, pero las luces interiores se encienden solas. Algo llegó antes. Continuará…"
    )

    fun build(number: Int): AdventureLevel {
        val level = number.coerceIn(1, GeoGameRules.LEVEL_COUNT)
        val world = (level - 1) / 5
        val width = 10_800f + level * 520f
        val platforms = mutableListOf<GamePlatform>()
        val moving = mutableListOf<GameMovingPlatform>()
        val hazards = mutableListOf<GameHazard>()
        val barriers = mutableListOf<GameBarrier>()
        val enemies = mutableListOf<GameEnemy>()
        val crates = mutableListOf<GameCrate>()
        val switches = mutableListOf<GameSwitch>()
        val pickups = mutableListOf<GamePickup>()
        val fans = mutableListOf<GameFan>()
        val fallingObjects = mutableListOf<GameFallingObject>()
        val chasingHoles = mutableListOf<GameChasingHole>()
        val crushers = mutableListOf<GameCrusher>()

        val requiredMechanisms = (2 + (level - 1) / 5).coerceAtMost(5)
        var x = 0f
        var segment = 0
        while (x < width - 900f) {
            val length = (570f - level * 5f + ((segment * 79 + level * 43) % 230)).coerceIn(330f, 690f)
            val gap = (92f + level * 3.4f + (segment % 4) * 22f).coerceAtMost(280f)
            val kind = when {
                segment == 0 -> PlatformKind.SOLID
                level <= 4 && segment % 5 == 1 -> PlatformKind.PROXIMITY_DISAPPEARING
                level <= 4 && segment % 5 == 2 -> PlatformKind.FALLING
                level <= 4 && segment % 7 == 3 -> PlatformKind.DISAPPEARING
                (segment + level) % 11 == 0 -> PlatformKind.REVEALING
                (segment * 2 + level) % 9 == 0 -> PlatformKind.FALLING
                level >= 4 && (segment + level * 2) % 13 == 0 -> PlatformKind.DISAPPEARING
                level >= 7 && (segment + level) % 17 == 0 -> PlatformKind.BOUNCE
                else -> PlatformKind.SOLID
            }
            platforms += GamePlatform(
                x = x,
                y = 620f,
                width = min(length, width - x),
                kind = kind,
                triggerX = if (level <= 4) x - 38f else x - 120f,
                delayMs = if (level <= 4) (185L - level * 15L).coerceAtLeast(110L) else (460L - level * 11L).coerceAtLeast(150L),
                cycleMs = (2_700L - level * 45L).coerceAtLeast(1_450L),
                phaseMs = (segment * 310L) % 1_400L
            )

            if (segment > 0) {
                val upperY = 505f - ((segment + level) % 3) * 56f
                val upperKind = when {
                    level <= 4 && segment % 4 == 1 -> PlatformKind.PROXIMITY_DISAPPEARING
                    (segment + level) % 8 == 0 -> PlatformKind.FALLING
                    level >= 5 && (segment + level) % 10 == 0 -> PlatformKind.REVEALING
                    else -> PlatformKind.SOLID
                }
                platforms += GamePlatform(
                    x = x + 92f + (segment % 2) * 65f,
                    y = upperY,
                    width = (180f + (segment % 4) * 34f).coerceAtMost(length - 100f),
                    height = 27f,
                    kind = upperKind,
                    triggerX = x + 10f,
                    delayMs = 260L
                )
            }

            if (segment > 1 && (if (level <= 4) segment % 3 == 0 else (segment + level) % (7 - level / 6).coerceAtLeast(3) == 0)) {
                moving += GameMovingPlatform(
                    x = x + length + 18f,
                    y = 495f - (segment % 2) * 100f,
                    width = (178f - level * 1.7f).coerceAtLeast(118f),
                    travel = 90f + level * 5f,
                    vertical = (segment + level) % 2 == 0,
                    periodSeconds = (4.0f - level * 0.075f).coerceAtLeast(2.15f)
                )
            }

            val trapCount = if (level <= 4) 3 else 1 + level / 6
            repeat(trapCount) { trap ->
                val hx = x + 125f + trap * 125f + ((segment * 31 + trap * 19) % 70)
                if (hx < x + length - 55f) {
                    val kindHazard = when {
                        level <= 4 && (segment + trap) % 3 != 1 -> HazardKind.HIDDEN_SPIKES
                        else -> when ((segment + trap + level) % 5) {
                            0 -> HazardKind.HIDDEN_SPIKES
                            1 -> HazardKind.SAW
                            2 -> HazardKind.FIRE
                            3 -> if (level >= 6) HazardKind.CEILING_SPIKES else HazardKind.SPIKES
                            else -> HazardKind.SPIKES
                        }
                    }
                    val orientation = if (level <= 4) {
                        when ((segment + trap + level) % 4) {
                            0 -> HazardOrientation.UP
                            1 -> HazardOrientation.DOWN
                            2 -> HazardOrientation.LEFT
                            else -> HazardOrientation.RIGHT
                        }
                    } else if (kindHazard == HazardKind.CEILING_SPIKES) HazardOrientation.DOWN else HazardOrientation.UP
                    val hazardY = when (orientation) {
                        HazardOrientation.UP -> 576f
                        HazardOrientation.DOWN -> 285f + (segment % 2) * 45f
                        HazardOrientation.LEFT, HazardOrientation.RIGHT -> 455f - (trap % 2) * 105f
                    }
                    hazards += GameHazard(
                        x = hx,
                        y = hazardY,
                        width = if (orientation == HazardOrientation.LEFT || orientation == HazardOrientation.RIGHT) 46f else (58f + level * 1.7f).coerceAtMost(94f),
                        height = if (orientation == HazardOrientation.LEFT || orientation == HazardOrientation.RIGHT) 115f else if (orientation == HazardOrientation.DOWN) 100f else 44f,
                        kind = kindHazard,
                        triggerX = if (level <= 4) hx - 42f else hx - (95f + level * 2f),
                        cycleMs = if (kindHazard == HazardKind.SAW || kindHazard == HazardKind.FIRE) (2_300L - level * 38L).coerceAtLeast(1_350L) else 0L,
                        phaseMs = (segment * 240L + trap * 370L) % 1_200L,
                        orientation = orientation,
                        camouflaged = level <= 4
                    )
                }
            }

            if (segment > 1 && (if (level <= 4) segment % 3 == 1 else (segment + level) % (6 - level / 7).coerceAtLeast(3) == 0)) {
                val kindEnemy = when {
                    level >= 16 && segment % 6 == 0 -> GameEnemyKind.GUARDIAN
                    level >= 9 && segment % 5 == 0 -> GameEnemyKind.SHOOTER
                    level >= 6 && segment % 4 == 0 -> GameEnemyKind.FLYER
                    level >= 3 && segment % 3 == 0 -> GameEnemyKind.JUMPER
                    else -> GameEnemyKind.WALKER
                }
                enemies += GameEnemy(
                    x = x + length * 0.62f,
                    y = if (kindEnemy == GameEnemyKind.FLYER) 390f else 566f,
                    range = 95f + level * 6f,
                    detectionRange = 430f + level * 18f,
                    health = when {
                        level <= 4 -> 2
                        kindEnemy == GameEnemyKind.GUARDIAN -> 5 + world
                        kindEnemy == GameEnemyKind.SHOOTER -> 3 + world
                        else -> 2 + level / 10
                    },
                    kind = kindEnemy,
                    speed = if (level <= 4) 96f + level * 5f else 78f + level * 3.1f
                )
            }

            if (segment > 2 && (segment + level) % 6 == 0) {
                val vertical = (segment + level) % 2 == 0
                val fanX = x + length * 0.25f
                fans += GameFan(
                    x = fanX,
                    y = if (vertical) 365f else 455f,
                    width = if (vertical) 150f else 420f,
                    height = if (vertical) 250f else 145f,
                    forceX = if (vertical) 0f else if (segment % 4 == 0) -520f else 520f,
                    forceY = if (vertical) -(520f + level * 8f) else 0f,
                    cycleMs = (2_900L - level * 45L).coerceAtLeast(1_700L),
                    phaseMs = segment * 240L,
                    switchIndex = if (switches.isNotEmpty() && segment % 3 == 0) switches.lastIndex else null
                )
            }

            if (segment > 1 && (if (level <= 4) segment % 2 == 0 else (segment + level) % 5 == 0)) {
                val objectKind = when ((segment + level) % 4) {
                    0 -> FallingObjectKind.FRUIT
                    1 -> FallingObjectKind.ROCK
                    2 -> FallingObjectKind.CRATE
                    else -> FallingObjectKind.SPIKE_BALL
                }
                val behavior = if (level <= 4) {
                    when ((segment / 2 + level) % 4) {
                        0 -> FallingBehavior.EXPLODE
                        1 -> FallingBehavior.ROLL
                        2 -> FallingBehavior.CHAIN
                        else -> FallingBehavior.CHASE
                    }
                } else FallingBehavior.DROP
                fallingObjects += GameFallingObject(
                    x = x + length * 0.72f,
                    startY = if (level <= 4) 255f + (segment % 2) * 48f else 90f - (segment % 2) * 70f,
                    targetY = 570f,
                    size = if (level <= 4) 74f + level * 2f else 62f + level * 1.6f,
                    triggerX = if (level <= 4) x + length * 0.48f else x + length * 0.52f,
                    kind = if (level <= 4) FallingObjectKind.FRUIT else objectKind,
                    delayMs = if (level <= 4) 90L + (segment % 3) * 35L else (320L - level * 7L).coerceAtLeast(110L),
                    behavior = behavior,
                    rollDirection = if (segment % 2 == 0) -1f else 1f,
                    explosionRadius = 125f + level * 12f,
                    chainCount = if (behavior == FallingBehavior.CHAIN) 3 + level else 1,
                    chainSpacing = 82f
                )
            }

            if (level <= 4 && segment > 1 && segment % 4 == 0) {
                chasingHoles += GameChasingHole(
                    startX = x + 35f,
                    triggerX = x - 45f,
                    width = 120f + level * 12f,
                    speed = 155f + level * 28f,
                    maxTravel = length + gap + 340f,
                    direction = 1f
                )
            }

            if (level <= 4 && segment > 2 && segment % 5 == 0) {
                val horizontal = segment % 10 == 0
                crushers += GameCrusher(
                    x = if (horizontal) x + length - 58f else x + length * 0.45f,
                    y = if (horizontal) 390f else 220f,
                    width = if (horizontal) 62f else 165f,
                    height = if (horizontal) 220f else 80f,
                    triggerX = x + length * 0.28f,
                    axis = if (horizontal) CrusherAxis.HORIZONTAL else CrusherAxis.VERTICAL,
                    travel = if (horizontal) -260f else 315f,
                    speed = 610f + level * 35f,
                    delayMs = 70L + level * 15L,
                    reverseAfterMs = 720L
                )
            }

            if (switches.size < requiredMechanisms && segment > 3 && (segment + level) % 5 == 0 && length > 430f) {
                val index = switches.size
                val barrierX = x + length - 52f
                switches += GameSwitch(
                    x = x + 72f,
                    y = 566f,
                    opensAtX = barrierX + 70f,
                    reversesFans = (index + level) % 2 == 0
                )
                barriers += GameBarrier(x = barrierX, switchIndex = index)
            }

            if (segment > 2 && segment % 7 == 0) crates += GameCrate(x + 80f, 566f)
            if (segment > 2 && (segment + level) % 9 == 0) {
                pickups += GamePickup(
                    x + length * 0.82f,
                    530f,
                    when ((segment + level) % 3) {
                        0 -> GamePickupKind.SHIELD
                        1 -> GamePickupKind.POWER
                        else -> GamePickupKind.ENERGY
                    }
                )
            }

            x += length + gap
            segment++
        }
        platforms += GamePlatform(width - 900f, 620f, 900f)

        while (switches.size < requiredMechanisms) {
            val base = platforms.filter { it.y >= 600f && it.kind == PlatformKind.SOLID }
                .getOrNull((switches.size + 1) * platforms.size / (requiredMechanisms + 2))
                ?: platforms.first()
            val index = switches.size
            val sx = base.x + 72f
            if (switches.none { abs(it.x - sx) < 80f }) {
                switches += GameSwitch(sx, 566f, base.x + base.width - 40f, index % 2 == 0)
                barriers += GameBarrier(base.x + base.width - 48f, switchIndex = index)
            } else break
        }

        val checkpointCount = (4 + (level - 1) / 4).coerceAtMost(8)
        val checkpoints = mutableListOf<GameCheckpoint>()
        for (i in 1..checkpointCount) {
            val ratio = i.toFloat() / (checkpointCount + 1)
            val target = width * ratio
            val platform = platforms
                .filter { it.y >= 600f && it.width > 280f && it.kind in setOf(PlatformKind.SOLID, PlatformKind.BOUNCE) }
                .minByOrNull { abs((it.x + it.width * 0.5f) - target) }
                ?: platforms.first()
            val cx = (platform.x + platform.width * 0.25f).coerceIn(platform.x + 45f, platform.x + platform.width - 45f)
            val kind = when {
                level <= 4 && i % 2 == 1 -> CheckpointKind.DECOY
                level <= 4 && i == checkpointCount && level % 2 == 0 -> CheckpointKind.SAFE
                level <= 4 -> CheckpointKind.POPUP
                i == checkpointCount && level >= 4 -> CheckpointKind.POPUP
                level >= 2 && i == 2 && level % 3 == 0 -> CheckpointKind.DECOY
                (i + level) % 3 == 0 -> CheckpointKind.POPUP
                else -> CheckpointKind.SAFE
            }
            val revealAt = if (level <= 4 && kind == CheckpointKind.POPUP) cx - 28f else cx - 210f
            checkpoints += GameCheckpoint(cx, platform.y - 85f, kind, revealAt)
        }
        if (level <= 4) {
            hazards.removeAll { hazard ->
                checkpoints.any { checkpoint ->
                    abs((hazard.x + hazard.width / 2f) - checkpoint.x) < 105f &&
                        hazard.y + hazard.height > checkpoint.y - 20f
                }
            }
        }

        fun reachableCrystal(ratio: Float): GameCrystal {
            val target = width * ratio
            val platform = platforms
                .filter { it.kind in setOf(PlatformKind.SOLID, PlatformKind.BOUNCE, PlatformKind.REVEALING) }
                .minByOrNull { candidate ->
                    when {
                        target < candidate.x -> candidate.x - target
                        target > candidate.x + candidate.width -> target - candidate.x - candidate.width
                        else -> 0f
                    }
                } ?: platforms.first()
            val cx = target.coerceIn(platform.x + 45f, max(platform.x + 45f, platform.x + platform.width - 45f))
            return GameCrystal(cx, platform.y - 92f)
        }

        val objective = when (level) {
            in 1..4 -> "Sobrevive al troleo extremo: cada paso puede abrir un hueco, lanzar pinchos, activar frutas explosivas o convertir un checkpoint en una emboscada."
            in 5..8 -> "Combina botones, pisos falsos, objetos que caen y rutas que desaparecen."
            in 9..12 -> "Domina ventiladores, bloques invisibles, plataformas móviles y puertas encadenadas."
            in 13..16 -> "Resuelve interruptores cruzados mientras sobrevives a trampas simultáneas."
            in 17..19 -> "Avanza bajo persecución, con checkpoints sorpresa y secciones de precisión extrema."
            else -> "Supera el nivel final: todas las mecánicas aparecen combinadas y sin descanso."
        }
        val difficulty = when (level) {
            1 -> "Troleo extremo"
            2 -> "Troleo brutal"
            3 -> "Troleo pesadilla"
            4 -> "Troleo imposible"
            in 5..8 -> "Brutal"
            in 9..12 -> "Implacable"
            in 13..16 -> "Pesadilla"
            in 17..19 -> "Inhumano"
            else -> "Final imposible"
        }
        val companion = when (level) {
            in 5..10, in 17..20 -> "Luma"
            in 11..16 -> "Taro"
            else -> null
        }

        return AdventureLevel(
            number = level,
            worldName = GeoGameRules.worldName(level),
            levelName = names[level - 1],
            objective = objective,
            difficultyLabel = difficulty,
            width = width,
            platforms = platforms,
            movingPlatforms = moving,
            hazards = hazards,
            barriers = barriers,
            enemies = enemies,
            crystals = listOf(reachableCrystal(0.19f), reachableCrystal(0.51f), reachableCrystal(0.82f)),
            crates = crates,
            switches = switches,
            checkpoints = checkpoints,
            fans = fans,
            fallingObjects = fallingObjects,
            chasingHoles = chasingHoles,
            crushers = crushers,
            requiredMechanisms = min(requiredMechanisms, switches.size),
            pickups = pickups,
            goalX = width - 205f,
            parSeconds = 190 + level * 14,
            introStory = intros[level],
            outroStory = outros[level],
            companion = companion,
            injured = level == 1,
            weaponEnabled = level >= 5,
            acechantePresent = level >= 17
        )
    }
}
