package com.ganageo.app.ui.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.BorderOuter
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Collections
import androidx.compose.material.icons.rounded.CropLandscape
import androidx.compose.material.icons.rounded.CropPortrait
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.PosterTiles
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import com.ganageo.app.tools.PosterTutorial
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------
// Papelote en hojas: una imagen grande repartida en varias hojas para imprimir
// en casa, cortar y pegar (para exposiciones). Gratis y sin internet.
// ---------------------------------------------------------------------------

/** Lado mayor con que se abre la imagen (nítida en papelotes grandes, sin gastar memoria de más). */
private const val POSTER_EDGE = 4000

/** Puntos por pulgada máximos que se guardan en el PDF (más no se nota al imprimir). */
private const val POSTER_MAX_DPI = 220f

private val SHEET_CHOICES = listOf(2, 3, 4, 6, 8, 9, 12, 16)

/** Abre la imagen (o la 1.ª página de un PDF) con su lado mayor ≤ [edge]. */
private suspend fun posterLoad(context: Context, uri: Uri, edge: Int): Bitmap {
    val type = runCatching { context.contentResolver.getType(uri) }.getOrNull().orEmpty()
    if (type == "application/pdf" || uri.toString().lowercase().endsWith(".pdf")) {
        val descriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: error("No se pudo abrir el PDF.")
        descriptor.use { fd ->
            PdfRenderer(fd).use { renderer ->
                if (renderer.pageCount == 0) error("El PDF no tiene páginas.")
                renderer.openPage(0).use { page ->
                    val scale = edge / max(page.width, page.height).toFloat()
                    val w = (page.width * scale).roundToInt().coerceAtLeast(1)
                    val h = (page.height * scale).roundToInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    return bitmap
                }
            }
        }
    }
    return ToolFileUtils.loadBitmap(context, uri, edge)
}

/** Hoja guía (va al final): el papelote armado con el número de cada hoja y los pasos. */
private fun drawGuide(canvas: android.graphics.Canvas, bitmap: Bitmap, options: PosterTiles.Options, tiles: List<PosterTiles.Tile>) {
    val sheetW = options.sheetWidth
    val sheetH = options.sheetHeight
    val placement = PosterTiles.place(bitmap.width, bitmap.height, options)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    val text = Paint(Paint.ANTI_ALIAS_FLAG)
    val (cmW, cmH) = PosterTiles.sizeCm(options)
    canvas.drawColor(android.graphics.Color.WHITE)
    val m = 36f
    text.textSize = 18f
    text.isFakeBoldText = true
    text.color = android.graphics.Color.rgb(20, 20, 20)
    canvas.drawText("Cómo armar tu papelote", m, m + 14f, text)
    text.isFakeBoldText = false
    text.textSize = 11f
    text.color = android.graphics.Color.rgb(70, 70, 70)
    canvas.drawText("${tiles.size} hojas · armado mide ${"%.0f".format(cmW)} × ${"%.0f".format(cmH)} cm", m, m + 32f, text)
    val boxTop = m + 48f
    val boxH = sheetH * 0.5f
    val k = min((sheetW - 2 * m) / options.posterWidth, boxH / options.posterHeight)
    val ox = (sheetW - options.posterWidth * k) / 2f
    val oy = boxTop
    canvas.save()
    canvas.clipRect(ox, oy, ox + options.posterWidth * k, oy + options.posterHeight * k)
    canvas.drawBitmap(bitmap, null, RectF(ox + placement.x * k, oy + placement.y * k, ox + (placement.x + placement.width) * k, oy + (placement.y + placement.height) * k), paint)
    canvas.restore()
    val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = android.graphics.Color.rgb(230, 40, 60)
    }
    val tag = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 20f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
        color = android.graphics.Color.rgb(200, 20, 40)
    }
    val tagBack = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.argb(220, 255, 255, 255) }
    for (tile in tiles) {
        val l = ox + tile.left * k
        val t = oy + tile.top * k
        canvas.drawRect(l, t, l + tile.width * k, t + tile.height * k, grid)
        val cx = l + tile.width * k / 2f
        val cy = t + tile.height * k / 2f
        canvas.drawCircle(cx, cy - 6f, 15f, tagBack)
        canvas.drawText(tile.label, cx, cy + 1f, tag)
    }
    var y = oy + options.posterHeight * k + 30f
    text.textSize = 13f
    text.isFakeBoldText = true
    text.color = android.graphics.Color.rgb(20, 20, 20)
    canvas.drawText("Pasos", m, y, text)
    text.isFakeBoldText = false
    text.textSize = 10f
    val steps = buildList {
        add("1. Imprime en \"Tamaño real\" o al 100 %. No uses \"Ajustar a la página\".")
        if (options.glue > 0f) {
            add("2. Las hojas de la derecha y de abajo tienen una franja blanca que dice \"pega aquí\"")
            add("    y el número de la hoja que va encima. Pon pegamento en la franja.")
            add("3. Pon encima esa hoja, juntando bien la imagen con la línea roja, y presiona.")
        } else {
            add("2. Junta las hojas borde con borde y pégalas por detrás con cinta.")
        }
        add("${if (options.glue > 0f) 4 else 3}. Orden: 1, 2, 3… de izquierda a derecha y de arriba abajo, como en el dibujo.")
        if (options.border > 0f) add("    Si queda una rayita blanca en el borde donde se juntan, córtala.")
    }
    for (line in steps) {
        y += 17f
        if (y > sheetH - m) break
        canvas.drawText(line, m, y, text)
    }
}

/**
 * Una hoja (medidas en puntos): su pedazo de imagen hasta el borde, y si recibe a
 * otra hoja (izquierda o arriba), la franja blanca para pegar con el número de la
 * hoja que va encima y una línea roja donde se junta la imagen. Los bordes de afuera
 * del papelote y los lados que van encima de otra hoja no llevan nada.
 */
private fun drawSheet(canvas: android.graphics.Canvas, bitmap: Bitmap, options: PosterTiles.Options, tile: PosterTiles.Tile) {
    val sheetW = options.sheetWidth
    val sheetH = options.sheetHeight
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    canvas.drawColor(android.graphics.Color.WHITE)
    val originX = options.leftOf(tile.col)
    val originY = options.topOf(tile.row)
    val source = tile.source
    val target = tile.target
    if (source != null && target != null) {
        val src = android.graphics.Rect(
            source[0].toInt().coerceIn(0, bitmap.width - 1), source[1].toInt().coerceIn(0, bitmap.height - 1),
            source[2].roundToInt().coerceIn(1, bitmap.width), source[3].roundToInt().coerceIn(1, bitmap.height)
        )
        if (src.width() > 0 && src.height() > 0) {
            val dst = RectF(originX + target[0], originY + target[1], originX + target[2], originY + target[3])
            // El pedazo, a lo más ~220 puntos por pulgada (el archivo no pesa de más).
            val maxW = (dst.width() / 72f * POSTER_MAX_DPI).roundToInt().coerceAtLeast(1)
            val maxH = (dst.height() / 72f * POSTER_MAX_DPI).roundToInt().coerceAtLeast(1)
            var piece = Bitmap.createBitmap(bitmap, src.left, src.top, src.width(), src.height())
            if (piece.width > maxW * 1.15f || piece.height > maxH * 1.15f) {
                val scaled = Bitmap.createScaledBitmap(piece, min(piece.width, maxW), min(piece.height, maxH), true)
                if (piece !== bitmap) piece.recycle()
                piece = scaled
            }
            canvas.drawBitmap(piece, null, dst, paint)
            if (piece !== bitmap) piece.recycle()
        }
    }
    val glue = options.glue
    if (glue > 0f) {
        val hatch = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.6f
            color = android.graphics.Color.rgb(235, 200, 205)
        }
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1f
            color = android.graphics.Color.rgb(220, 30, 50)
            pathEffect = DashPathEffect(floatArrayOf(4f, 3f), 0f)
        }
        val name = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
            color = android.graphics.Color.rgb(200, 20, 40)
        }
        /** Franja blanca rayada: "pega aquí" y el número de la hoja que va encima. */
        fun tab(l: Float, t: Float, r: Float, b: Float, neighbor: Int, vertical: Boolean) {
            canvas.save()
            canvas.clipRect(l, t, r, b)
            var d = -(b - t)
            while (d < (r - l) + (b - t)) {
                canvas.drawLine(l + d, b, l + d + (b - t), t, hatch)
                d += 8f
            }
            canvas.restore()
            val thick = if (vertical) r - l else b - t
            name.textSize = (thick * 0.38f).coerceIn(6f, 14f)
            val words = "pega aquí la hoja $neighbor"
            val along = if (vertical) b - t else r - l
            for (frac in floatArrayOf(0.25f, 0.75f)) {
                canvas.save()
                if (vertical) {
                    val cx = (l + r) / 2f
                    val cy = t + along * frac
                    canvas.rotate(-90f, cx, cy)
                    canvas.drawText(words, cx, cy + name.textSize * 0.35f, name)
                } else {
                    val cx = l + along * frac
                    val cy = (t + b) / 2f
                    canvas.drawText(words, cx, cy + name.textSize * 0.35f, name)
                }
                canvas.restore()
            }
        }
        val imageRight = sheetW - options.border
        val imageBottom = sheetH - options.border
        if (tile.col > 0) {
            // Franja a la izquierda: aquí va encima la hoja de la izquierda.
            tab(0f, if (tile.row > 0) glue else 0f, glue, imageBottom, tile.number - 1, vertical = true)
            canvas.drawLine(glue, originY, glue, imageBottom, edge)
        }
        if (tile.row > 0) {
            // Franja arriba: aquí va encima la hoja de arriba.
            tab(if (tile.col > 0) glue else 0f, 0f, imageRight, glue, tile.number - options.cols, vertical = false)
            canvas.drawLine(originX, glue, imageRight, glue, edge)
        }
        if (tile.col > 0 && tile.row > 0) {
            // Esquina: va debajo de las dos (solo rayada).
            canvas.save()
            canvas.clipRect(0f, 0f, glue, glue)
            var d = -glue
            while (d < glue * 2) { canvas.drawLine(d, glue, d + glue, 0f, hatch); d += 8f }
            canvas.restore()
        }
    }
    // Su número, chiquito, en una esquina que queda tapada o al borde.
    val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 9f
        isFakeBoldText = true
        color = android.graphics.Color.rgb(200, 20, 40)
    }
    val mark = "${tile.number}"
    if (glue > 0f && (tile.col > 0 || tile.row > 0)) {
        canvas.drawText(mark, 3f, 11f, text)
    } else {
        // Hoja 1 (o sin franja): el número va muy chico atrás de la esquina, casi no se ve.
        text.textSize = 7f
        text.color = android.graphics.Color.argb(150, 255, 255, 255)
        canvas.drawText(mark, sheetW - options.border - 8f, sheetH - options.border - 3f, text)
    }
}

/** El PDF: una hoja por pedazo (hoja 1 = página 1) y al final la guía. */
private fun posterWritePdf(bitmap: Bitmap, options: PosterTiles.Options, output: OutputStream, onProgress: (Float) -> Unit) {
    val document = PdfDocument()
    try {
        val w = options.sheetWidth.roundToInt()
        val h = options.sheetHeight.roundToInt()
        val tiles = PosterTiles.tiles(bitmap.width, bitmap.height, options)
        tiles.forEachIndexed { index, tile ->
            val page = document.startPage(PdfDocument.PageInfo.Builder(w, h, index + 1).create())
            drawSheet(page.canvas, bitmap, options, tile)
            document.finishPage(page)
            onProgress((index + 1) / tiles.size.toFloat())
        }
        document.startPage(PdfDocument.PageInfo.Builder(w, h, tiles.size + 1).create()).also { page ->
            drawGuide(page.canvas, bitmap, options, tiles)
            document.finishPage(page)
        }
        document.writeTo(output)
    } finally {
        document.close()
    }
}

/** Las mismas hojas como imágenes JPG (200 ppp), una por archivo, en la carpeta elegida. */
private fun posterWriteImages(context: Context, tree: Uri, bitmap: Bitmap, options: PosterTiles.Options, onProgress: (Float) -> Unit): Int {
    val folder = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, tree) ?: error("No se pudo abrir la carpeta.")
    val k = 200f / 72f
    val w = (options.sheetWidth * k).roundToInt()
    val h = (options.sheetHeight * k).roundToInt()
    val tiles = PosterTiles.tiles(bitmap.width, bitmap.height, options)
    val total = tiles.size + 1
    val stamp = java.text.SimpleDateFormat("HHmmss", java.util.Locale.ROOT).format(java.util.Date())
    var saved = 0
    for (index in 0 until total) {
        val sheet = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        try {
            val canvas = android.graphics.Canvas(sheet)
            canvas.scale(k, k)
            val name = if (index == tiles.size) {
                drawGuide(canvas, bitmap, options, tiles)
                "papelote_${stamp}_guia.jpg"
            } else {
                val tile = tiles[index]
                drawSheet(canvas, bitmap, options, tile)
                "papelote_${stamp}_hoja_${tile.number}.jpg"
            }
            val file = folder.createFile("image/jpeg", name) ?: error("No se pudo crear $name.")
            context.contentResolver.openOutputStream(file.uri)?.use { sheet.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                ?: error("No se pudo guardar $name.")
            saved++
        } finally {
            sheet.recycle()
        }
        onProgress((index + 1) / total.toFloat())
    }
    return saved
}

/** Imagen lista para guardar, mejorada si se pidió (si la IA no está, la normal). */
private suspend fun posterPrepare(
    context: Context,
    uri: Uri,
    enhance: Int,
    onStep: (String, Float?) -> Unit
): Bitmap {
    suspend fun load(edge: Int): Bitmap = try {
        posterLoad(context, uri, edge)
    } catch (error: OutOfMemoryError) {
        System.gc()
        posterLoad(context, uri, min(edge, 2500))
    }
    if (enhance == DocScanEnhance.OFF) return load(POSTER_EDGE)
    // Tamaño de entrada para que el resultado no pase de ~12 millones de puntos.
    val limit = if (enhance == DocScanEnhance.X2) POSTER_X2_PIXELS / 4 else POSTER_CLEAN_PIXELS
    val probe = load(1000)
    val ratio = max(probe.width, probe.height) / min(probe.width, probe.height).coerceAtLeast(1).toFloat()
    probe.recycle()
    val edge = kotlin.math.sqrt(limit * ratio.toDouble()).toInt().coerceIn(600, POSTER_EDGE)
    val base = load(edge)
    onStep("Mejorando", 0f)
    val better = DocScanEnhance.enhanceImage(context, base, enhance, POSTER_X2_PIXELS) { done, total ->
        onStep("Mejorando", done / total.coerceAtLeast(1).toFloat())
    }
    return if (better != null) {
        base.recycle()
        better
    } else {
        base
    }
}

/** Puntos máximos de la imagen mejorada x2 (memoria del celular). */
private const val POSTER_X2_PIXELS = 12_000_000L

/** Puntos máximos al solo mejorar (sin agrandar): tarda menos. */
private const val POSTER_CLEAN_PIXELS = 6_000_000L

/** El tutorial en PDF: portada, un paso por página (con flechas) y el final. */
private fun posterWriteTutorial(image: Bitmap, options: PosterTiles.Options, output: OutputStream) {
    // Copia chica para los dibujos (el archivo no pesa de más).
    val edge = max(image.width, image.height)
    val small = if (edge > 1100) {
        val s = 1100f / edge
        Bitmap.createScaledBitmap(image, (image.width * s).roundToInt().coerceAtLeast(1), (image.height * s).roundToInt().coerceAtLeast(1), true)
    } else image
    val regular = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = android.graphics.Typeface.DEFAULT }
    val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = android.graphics.Typeface.DEFAULT_BOLD }
    val measure = PosterTutorial.Measure { text, size, isBold ->
        val paint = if (isBold) bold else regular
        paint.textSize = size
        paint.measureText(text)
    }
    val pages = PosterTutorial.pages(small.width, small.height, options, measure)
    val document = PdfDocument()
    try {
        pages.forEachIndexed { index, ops ->
            val page = document.startPage(
                PdfDocument.PageInfo.Builder(PosterTutorial.PAGE_W.roundToInt(), PosterTutorial.PAGE_H.roundToInt(), index + 1).create()
            )
            posterDrawOps(page.canvas, small, ops)
            document.finishPage(page)
        }
        document.writeTo(output)
    } finally {
        document.close()
        if (small !== image) small.recycle()
    }
}

/** Dibuja la lista del tutorial en un lienzo de Android. */
private fun posterDrawOps(canvas: android.graphics.Canvas, image: Bitmap, ops: List<PosterTutorial.Op>) {
    canvas.drawColor(android.graphics.Color.WHITE)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    val text = Paint(Paint.ANTI_ALIAS_FLAG)
    val picture = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    val path = android.graphics.Path()
    for (op in ops) when (op) {
        is PosterTutorial.Box -> {
            val rect = RectF(op.l, op.t, op.r, op.b)
            op.fill?.let {
                fill.color = it
                if (op.radius > 0f) canvas.drawRoundRect(rect, op.radius, op.radius, fill) else canvas.drawRect(rect, fill)
            }
            op.stroke?.let {
                stroke.color = it
                stroke.strokeWidth = op.width
                stroke.strokeCap = Paint.Cap.BUTT
                stroke.pathEffect = if (op.dash) DashPathEffect(floatArrayOf(5f, 4f), 0f) else null
                if (op.radius > 0f) canvas.drawRoundRect(rect, op.radius, op.radius, stroke) else canvas.drawRect(rect, stroke)
                stroke.pathEffect = null
            }
        }
        is PosterTutorial.Line -> {
            stroke.color = op.color
            stroke.strokeWidth = op.width
            stroke.strokeCap = Paint.Cap.ROUND
            stroke.pathEffect = if (op.dash) DashPathEffect(floatArrayOf(5f, 4f), 0f) else null
            canvas.drawLine(op.x0, op.y0, op.x1, op.y1, stroke)
            stroke.pathEffect = null
        }
        is PosterTutorial.Text -> {
            text.color = op.color
            text.textSize = op.size
            text.typeface = if (op.bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
            text.textAlign = when (op.align) {
                1 -> Paint.Align.CENTER
                2 -> Paint.Align.RIGHT
                else -> Paint.Align.LEFT
            }
            canvas.drawText(op.text, op.x, op.y, text)
        }
        is PosterTutorial.Picture -> {
            val src = android.graphics.Rect(
                op.src[0].toInt().coerceIn(0, image.width - 1), op.src[1].toInt().coerceIn(0, image.height - 1),
                op.src[2].roundToInt().coerceIn(1, image.width), op.src[3].roundToInt().coerceIn(1, image.height)
            )
            if (src.width() > 0 && src.height() > 0) canvas.drawBitmap(image, src, RectF(op.l, op.t, op.r, op.b), picture)
        }
        is PosterTutorial.Dot -> {
            fill.color = op.fill
            canvas.drawCircle(op.x, op.y, op.radius, fill)
            op.stroke?.let {
                stroke.color = it
                stroke.strokeWidth = op.width
                canvas.drawCircle(op.x, op.y, op.radius, stroke)
            }
        }
        is PosterTutorial.Poly -> {
            path.reset()
            path.moveTo(op.points[0], op.points[1])
            var i = 2
            while (i + 1 < op.points.size) {
                path.lineTo(op.points[i], op.points[i + 1])
                i += 2
            }
            path.close()
            fill.color = op.fill
            canvas.drawPath(path, fill)
        }
        is PosterTutorial.Hatch -> {
            canvas.save()
            canvas.clipRect(op.l, op.t, op.r, op.b)
            stroke.color = op.color
            stroke.strokeWidth = 0.5f
            stroke.strokeCap = Paint.Cap.BUTT
            var d = -(op.b - op.t)
            while (d < op.r - op.l) {
                canvas.drawLine(op.l + d, op.b, op.l + d + (op.b - op.t), op.t, stroke)
                d += op.step
            }
            canvas.restore()
        }
    }
}

// ---------------------------------------------------------------------------
// Pantalla
// ---------------------------------------------------------------------------

private val PosterGlass = Color(0x10FFFFFF)
private val PosterEdge = Color(0x1FFFFFFF)
private val PosterSoft = Color(0xFF9DB3A7)
private val PosterInk = Color(0xFFEAF5EE)

/** Panel de vidrio con ícono, título y (opcional) su valor a la derecha. */
@Composable
private fun PosterPanel(icon: ImageVector, title: String, value: String? = null, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(PosterGlass)
            .border(1.dp, PosterEdge, RoundedCornerShape(22.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(NeonGreen.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(17.dp))
            }
            Spacer(Modifier.width(10.dp))
            Text(title, color = PosterInk, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.weight(1f))
            if (value != null) {
                Text(
                    value,
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(NeonGreen.copy(alpha = 0.10f))
                        .padding(horizontal = 9.dp, vertical = 3.dp)
                )
            }
        }
        content()
    }
}

/** Una opción de un grupo (ícono y/o palabra). */
private class PosterOption(val icon: ImageVector?, val label: String?, val selected: Boolean)

/** Botones juntos en una barra (el elegido en verde). */
@Composable
private fun PosterSegment(options: List<PosterOption>, modifier: Modifier = Modifier, onPick: (Int) -> Unit) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x33000000))
            .border(1.dp, Color(0x14FFFFFF), RoundedCornerShape(16.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { index, option ->
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (option.selected) NeonGreen else Color.Transparent)
                    .clickable { onPick(index) }
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (option.icon != null) {
                    Icon(
                        option.icon, contentDescription = option.label,
                        tint = if (option.selected) DeepGreen else PosterSoft,
                        modifier = Modifier.size(19.dp)
                    )
                }
                if (option.icon != null && option.label != null) Spacer(Modifier.width(6.dp))
                if (option.label != null) {
                    Text(
                        option.label,
                        color = if (option.selected) DeepGreen else PosterInk,
                        fontWeight = if (option.selected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/** Forma del papelote (filas × columnas) dibujada con hojitas. */
@Composable
private fun PosterShape(rows: Int, cols: Int, landscape: Boolean, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) NeonGreen.copy(alpha = 0.16f) else Color(0x22000000))
            .border(if (selected) 1.5.dp else 1.dp, if (selected) NeonGreen else Color(0x14FFFFFF), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(Modifier.size(width = 46.dp, height = 34.dp)) {
            val gap = 2.dp.toPx()
            val cellRatio = if (landscape) 1.414f else 0.707f
            // Tamaño de cada hojita para que entre todo.
            val cellW = min((size.width - gap * (cols - 1)) / cols, (size.height - gap * (rows - 1)) / rows * cellRatio)
            val cellH = cellW / cellRatio
            val totalW = cellW * cols + gap * (cols - 1)
            val totalH = cellH * rows + gap * (rows - 1)
            val ox = (size.width - totalW) / 2f
            val oy = (size.height - totalH) / 2f
            for (r in 0 until rows) for (c in 0 until cols) {
                drawRoundRect(
                    color = if (selected) NeonGreen else PosterSoft.copy(alpha = 0.7f),
                    topLeft = Offset(ox + c * (cellW + gap), oy + r * (cellH + gap)),
                    size = Size(cellW, cellH),
                    cornerRadius = CornerRadius(1.5.dp.toPx(), 1.5.dp.toPx())
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text("$cols×$rows", color = if (selected) NeonGreen else PosterSoft, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Etiqueta chica encima de la vista previa. */
@Composable
private fun PosterTag(icon: ImageVector, text: String, tint: Color, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xCC07140E))
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(12.dp))
            .padding(horizontal = 9.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(5.dp))
        Text(text, color = PosterInk, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Botón grande de abajo: ícono, título y una línea chica. */
@Composable
private fun PosterAction(
    icon: ImageVector, title: String, detail: String, primary: Boolean, enabled: Boolean,
    modifier: Modifier = Modifier, onClick: () -> Unit
) {
    val content = if (primary) DeepGreen else PosterInk
    Row(
        modifier = modifier
            .height(58.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(
                when {
                    !enabled -> Color(0x14FFFFFF)
                    primary -> NeonGreen
                    else -> Color(0x1FFFFFFF)
                }
            )
            .border(1.dp, if (primary && enabled) NeonGreen else Color(0x26FFFFFF), RoundedCornerShape(18.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (enabled) content else PosterSoft.copy(alpha = 0.5f), modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(9.dp))
        Column {
            Text(title, color = if (enabled) content else PosterSoft.copy(alpha = 0.6f), fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
            Text(detail, color = (if (enabled) content else PosterSoft).copy(alpha = 0.7f), fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
fun PosterTilesScreen(tool: ToolId, onBack: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf<Uri?>(null) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(false) }
    var sheets by rememberSaveable { mutableStateOf(4) }
    var landscape by rememberSaveable { mutableStateOf(false) }
    // A4 de siempre (en Perú casi todos usan A4); también Oficio.
    var paperIndex by rememberSaveable { mutableStateOf(0) }
    var fill by rememberSaveable { mutableStateOf(true) }
    var overlapMm by rememberSaveable { mutableStateOf(10f) }
    var borderMm by rememberSaveable { mutableStateOf(0f) }
    var enhance by rememberSaveable { mutableStateOf(DocScanEnhance.OFF) }
    // Forma elegida (filas × columnas) entre las que dan esa cantidad de hojas.
    var gridChoice by rememberSaveable { mutableStateOf(-1) }
    var working by remember { mutableStateOf<Pair<String, Float?>?>(null) }
    // Lado mayor de la imagen original (hasta 4000 px), para saber qué tan nítida sale.
    var fullLong by remember { mutableStateOf(POSTER_EDGE) }

    val paper = PosterTiles.PAPERS.getOrElse(paperIndex) { PosterTiles.PAPERS[0] }
    val image = preview
    val grids = remember(sheets) { (1..sheets).filter { sheets % it == 0 }.map { it to sheets / it } }
    val auto = if (image != null) PosterTiles.bestGrid(sheets, image.width, image.height, paper, landscape) else grids.first()
    val grid = grids.getOrNull(gridChoice) ?: auto
    val options = PosterTiles.Options(grid.first, grid.second, paper, landscape, borderMm, overlapMm, fill)

    // Nitidez del papelote con la imagen que se usará (x2 la duplica, hasta su límite).
    val dpi = if (image == null) 0 else {
        val ratio = max(image.width, image.height) / min(image.width, image.height).coerceAtLeast(1).toFloat()
        val x2Long = kotlin.math.sqrt(POSTER_X2_PIXELS * ratio.toDouble()).toInt()
        val long = when (enhance) {
            DocScanEnhance.X2 -> min(fullLong * 2, x2Long)
            else -> fullLong
        }
        val grow = long / max(image.width, image.height).coerceAtLeast(1).toFloat()
        PosterTiles.dpi((image.width * grow).roundToInt(), (image.height * grow).roundToInt(), options)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        source = uri
        loading = true
        scope.launch {
            val opened = runCatching { withContext(Dispatchers.IO) { posterLoad(context, uri, 1400) } }
            fullLong = runCatching {
                withContext(Dispatchers.IO) {
                    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
                    val long = max(bounds.outWidth, bounds.outHeight)
                    if (long > 0) min(long, POSTER_EDGE) else POSTER_EDGE
                }
            }.getOrDefault(POSTER_EDGE)
            loading = false
            opened.onSuccess { preview = it; gridChoice = -1 }
                .onFailure { onMessage(it.message ?: "No se pudo abrir esa imagen.") }
        }
    }
    fun pick() = runCatching { picker.launch(arrayOf("image/*", "application/pdf")) }
        .onFailure { onMessage("No se pudieron abrir tus archivos.") }

    // Guardar (PDF o imágenes): prepara la imagen (y la mejora si se pidió) y arma las hojas.
    fun save(write: suspend (Bitmap, PosterTiles.Options) -> String) {
        val input = source ?: return
        val chosen = options
        val quality = enhance
        working = "Preparando" to null
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val full = posterPrepare(context, input, quality) { step, progress -> scope.launch { working = step to progress } }
                    try {
                        write(full, chosen)
                    } finally {
                        full.recycle()
                    }
                }
            }
            working = null
            result.onSuccess { onMessage(it) }.onFailure { onMessage(it.message ?: "No se pudo guardar.") }
        }
    }
    val pdfSaver = rememberLauncherForActivityResult(TrackedCreateDocument("application/pdf")) { target ->
        if (target == null) return@rememberLauncherForActivityResult
        save { full, chosen ->
            scope.launch { working = "Armando el PDF" to 0f }
            val stream = context.contentResolver.openOutputStream(target, "w") ?: error("No se pudo guardar.")
            stream.use { out -> posterWritePdf(full, chosen, out) { p -> scope.launch { working = "Armando el PDF" to p } } }
            "PDF listo: ${chosen.rows * chosen.cols} hojas y al final la guía."
        }
    }
    // Tutorial: con la vista previa basta (son dibujos chicos): sale rápido.
    val tutorialSaver = rememberLauncherForActivityResult(TrackedCreateDocument("application/pdf")) { target ->
        if (target == null) return@rememberLauncherForActivityResult
        val picture = preview ?: return@rememberLauncherForActivityResult
        val chosen = options
        working = "Armando el tutorial" to null
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val stream = context.contentResolver.openOutputStream(target, "w") ?: error("No se pudo guardar.")
                    stream.use { out -> posterWriteTutorial(picture, chosen, out) }
                }
            }
            working = null
            result.onSuccess { onMessage("Tutorial listo: ${PosterTiles.steps(chosen.rows, chosen.cols).size} pasos con flechas.") }
                .onFailure { onMessage(it.message ?: "No se pudo guardar el tutorial.") }
        }
    }
    val imageSaver = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if (tree == null) return@rememberLauncherForActivityResult
        save { full, chosen ->
            scope.launch { working = "Guardando imágenes" to 0f }
            val count = posterWriteImages(context, tree, full, chosen) { p -> scope.launch { working = "Guardando imágenes" to p } }
            "$count imágenes guardadas (una por hoja y la guía)."
        }
    }
    fun stamp() = java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.ROOT).format(java.util.Date())

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF030D08), Color(0xFF06170F), Color(0xFF0A2018))))
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            ToolHeader(tool.title, "Gratis · tu imagen en varias hojas para pegar", onBack)

            // ---------------- Vista previa (siempre a la vista) ----------------
            Box(
                Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .height(290.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF0C281C), Color(0xFF061209))))
                    .border(1.dp, NeonGreen.copy(alpha = 0.22f), RoundedCornerShape(26.dp))
            ) {
                if (image == null) {
                    // Fondo de plano y el botón grande para elegir.
                    Canvas(Modifier.fillMaxSize()) {
                        drawIntoCanvas { c -> posterBlueprint(c.nativeCanvas, size.width, size.height, 18.dp.toPx()) }
                    }
                    Column(
                        Modifier
                            .fillMaxSize()
                            .clickable(enabled = !loading) { pick() },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        if (loading) {
                            LinearProgressIndicator(modifier = Modifier.padding(horizontal = 48.dp).fillMaxWidth(), color = NeonGreen)
                        } else {
                            Box(
                                Modifier
                                    .size(84.dp)
                                    .clip(CircleShape)
                                    .background(NeonGreen.copy(alpha = 0.12f))
                                    .border(1.5.dp, NeonGreen.copy(alpha = 0.6f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(42.dp))
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("Elegir imagen", color = PosterInk, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("foto · dibujo · PDF", color = PosterSoft, fontSize = 13.sp)
                        }
                    }
                } else {
                    PosterPreview(image, options)
                    val (cmW, cmH) = PosterTiles.sizeCm(options)
                    PosterTag(
                        Icons.Rounded.Straighten, "${"%.0f".format(cmW)} × ${"%.0f".format(cmH)} cm", NeonGreen,
                        Modifier.align(Alignment.TopStart).padding(10.dp)
                    )
                    val (sharpColor, sharpText) = when {
                        dpi >= 120 -> Color(0xFF7CF3A6) to "Nítida"
                        dpi >= 60 -> Gold to "Algo borrosa"
                        else -> Color(0xFFFF7D7D) to "Borrosa"
                    }
                    PosterTag(
                        if (dpi >= 120) Icons.Rounded.CheckCircle else Icons.Rounded.Warning, sharpText, sharpColor,
                        Modifier.align(Alignment.TopEnd).padding(10.dp)
                    )
                    PosterTag(
                        Icons.Rounded.GridView, "${options.cols * options.rows} hojas ${paper.name}", PosterSoft,
                        Modifier.align(Alignment.BottomStart).padding(10.dp)
                    )
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xCC07140E))
                            .border(1.dp, NeonGreen.copy(alpha = 0.5f), CircleShape)
                            .clickable { pick() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.SwapHoriz, contentDescription = "Cambiar imagen", tint = NeonGreen, modifier = Modifier.size(22.dp))
                    }
                }
            }

            // ---------------- Opciones ----------------
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (image != null && dpi < 120) {
                    // Consejo cuando no sale nítida.
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Gold.copy(alpha = 0.10f))
                            .clickable { enhance = DocScanEnhance.X2 }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.ZoomIn, contentDescription = null, tint = Gold, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(
                            if (enhance == DocScanEnhance.X2) "Con x2 ya sale lo más nítida posible. Menos hojas = más nítida."
                            else "Toca aquí para usar x2 (más nítida), o usa menos hojas.",
                            color = PosterInk, fontSize = 12.sp
                        )
                    }
                }
                PosterPanel(Icons.Rounded.GridView, "Hojas", "${options.cols * options.rows}") {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SHEET_CHOICES.forEach { n ->
                            val selected = sheets == n
                            Box(
                                Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(if (selected) NeonGreen else Color(0x22000000))
                                    .border(1.dp, if (selected) NeonGreen else Color(0x1FFFFFFF), CircleShape)
                                    .clickable { sheets = n; gridChoice = -1 },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("$n", color = if (selected) DeepGreen else PosterInk, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                    if (grids.size > 1) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            grids.forEachIndexed { index, (rows, cols) ->
                                PosterShape(rows, cols, landscape, grid == (rows to cols), Modifier.weight(1f)) { gridChoice = index }
                            }
                        }
                    }
                }
                PosterPanel(Icons.Rounded.Description, "Papel", paper.name) {
                    PosterSegment(
                        listOf(
                            PosterOption(Icons.Rounded.CropPortrait, "Parada", !landscape),
                            PosterOption(Icons.Rounded.CropLandscape, "Echada", landscape)
                        ),
                        Modifier.fillMaxWidth()
                    ) { landscape = it == 1; gridChoice = -1 }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PosterSegment(
                            PosterTiles.PAPERS.mapIndexed { index, p -> PosterOption(null, p.name, paperIndex == index) },
                            Modifier.weight(1f)
                        ) { paperIndex = it }
                        PosterSegment(
                            listOf(
                                PosterOption(Icons.Rounded.Fullscreen, null, fill),
                                PosterOption(Icons.Rounded.FitScreen, null, !fill)
                            ),
                            Modifier.weight(1f)
                        ) { fill = it == 0 }
                    }
                    Text(
                        if (fill) "Llenar: la imagen cubre todo (se corta un poco)." else "Completa: se ve toda la imagen (puede quedar blanco).",
                        color = PosterSoft, fontSize = 12.sp
                    )
                }
                PosterPanel(Icons.Rounded.Layers, "Franja para pegar", if (overlapMm < 0.5f) "sin" else "${overlapMm.roundToInt()} mm") {
                    PosterSegment(
                        listOf(0f to "Sin", 5f to "Chica", 10f to "Normal", 20f to "Grande").map { (mm, name) ->
                            PosterOption(null, name, overlapMm.roundToInt() == mm.roundToInt())
                        },
                        Modifier.fillMaxWidth()
                    ) { overlapMm = listOf(0f, 5f, 10f, 20f)[it] }
                    Slider(value = overlapMm, onValueChange = { overlapMm = it.roundToInt().toFloat() }, valueRange = 0f..30f)
                }
                PosterPanel(Icons.Rounded.BorderOuter, "Borde", if (borderMm < 0.5f) "sin borde" else "${borderMm.roundToInt()} mm") {
                    Slider(value = borderMm, onValueChange = { borderMm = it.roundToInt().toFloat() }, valueRange = 0f..15f)
                    Text("Súbelo solo si tu impresora corta la imagen.", color = PosterSoft, fontSize = 12.sp)
                }
                PosterPanel(Icons.Rounded.AutoAwesome, "Calidad") {
                    PosterSegment(
                        listOf(
                            PosterOption(Icons.Rounded.Image, "Normal", enhance == DocScanEnhance.OFF),
                            PosterOption(Icons.Rounded.AutoFixHigh, "Mejorar", enhance == DocScanEnhance.ORIGINAL),
                            PosterOption(Icons.Rounded.ZoomIn, "x2", enhance == DocScanEnhance.X2)
                        ),
                        Modifier.fillMaxWidth()
                    ) { enhance = listOf(DocScanEnhance.OFF, DocScanEnhance.ORIGINAL, DocScanEnhance.X2)[it] }
                    if (enhance != DocScanEnhance.OFF) {
                        Text("Con IA, en tu celular. Tarda un poco más al guardar.", color = PosterSoft, fontSize = 12.sp)
                    }
                }
            }

            // ---------------- Descargas (abajo, siempre a la mano) ----------------
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xF2040E09))
                    .navigationBarsPadding()
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 12.dp)
            ) {
                val now = working
                if (now != null) {
                    Text("${now.first}…", color = PosterInk, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    val p = now.second
                    if (p == null) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = NeonGreen)
                    else LinearProgressIndicator(progress = { p.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = NeonGreen)
                    Spacer(Modifier.height(18.dp))
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        PosterAction(
                            Icons.Rounded.Print, "Imprimir", "PDF de las hojas", primary = true, enabled = image != null,
                            modifier = Modifier.weight(1.15f)
                        ) { pdfSaver.launch("Papelote_${stamp()}.pdf") }
                        PosterAction(
                            Icons.Rounded.MenuBook, "Tutorial", "Cómo pegarlas", primary = false, enabled = image != null,
                            modifier = Modifier.weight(1f)
                        ) { tutorialSaver.launch("Papelote_tutorial_${stamp()}.pdf") }
                        Box(
                            Modifier
                                .size(58.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color(0x1FFFFFFF))
                                .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(18.dp))
                                .clickable(enabled = image != null) { imageSaver.launch(null) },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Rounded.Collections, contentDescription = "Guardar como imágenes",
                                tint = if (image != null) PosterInk else PosterSoft.copy(alpha = 0.5f), modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Cuadrícula tenue de fondo (como un plano). */
private fun posterBlueprint(canvas: android.graphics.Canvas, width: Float, height: Float, step: Float) {
    val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f
        color = android.graphics.Color.argb(18, 0x39, 0xFF, 0x88)
    }
    var x = 0f
    while (x < width) { canvas.drawLine(x, 0f, x, height, grid); x += step }
    var y = 0f
    while (y < height) { canvas.drawLine(0f, y, width, y, grid); y += step }
}

/** Dibujo del papelote armado: la imagen, dónde se junta cada hoja y su número. */
@Composable
private fun PosterPreview(image: Bitmap, options: PosterTiles.Options) {
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG) }
    val line = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE } }
    val shadow = remember { Paint(Paint.ANTI_ALIAS_FLAG) }
    val tag = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD } }
    val tagBack = remember { Paint(Paint.ANTI_ALIAS_FLAG) }
    Canvas(Modifier.fillMaxSize()) {
        drawIntoCanvas { c ->
            val canvas = c.nativeCanvas
            // Fondo de plano: rayitas tenues.
            posterBlueprint(canvas, size.width, size.height, 18.dp.toPx())

            val padX = 18.dp.toPx()
            val padY = 44.dp.toPx()
            val boxW = size.width - padX * 2
            val boxH = size.height - padY * 2
            val k = min(boxW / options.posterWidth, boxH / options.posterHeight)
            val ox = (size.width - options.posterWidth * k) / 2f
            val oy = (size.height - options.posterHeight * k) / 2f
            val right = ox + options.posterWidth * k
            val bottom = oy + options.posterHeight * k
            // Sombra suave del papelote.
            shadow.color = android.graphics.Color.argb(90, 0, 0, 0)
            canvas.drawRoundRect(ox + 3.dp.toPx(), oy + 5.dp.toPx(), right + 3.dp.toPx(), bottom + 5.dp.toPx(), 4.dp.toPx(), 4.dp.toPx(), shadow)
            val placement = PosterTiles.place(image.width, image.height, options)
            canvas.save()
            canvas.clipRect(ox, oy, right, bottom)
            canvas.drawColor(android.graphics.Color.WHITE)
            canvas.drawBitmap(
                image, null,
                RectF(ox + placement.x * k, oy + placement.y * k, ox + (placement.x + placement.width) * k, oy + (placement.y + placement.height) * k),
                paint
            )
            canvas.restore()
            // Uniones: línea brillante (verde con borde oscuro) y número de cada hoja.
            tag.textSize = 12.dp.toPx()
            val tiles = PosterTiles.tiles(image.width, image.height, options)
            for (tile in tiles) {
                val l = ox + tile.left * k
                val t = oy + tile.top * k
                val r = l + tile.width * k
                val b = t + tile.height * k
                line.strokeWidth = 3.dp.toPx()
                line.color = android.graphics.Color.argb(110, 0, 0, 0)
                canvas.drawRect(l, t, r, b, line)
                line.strokeWidth = 1.3.dp.toPx()
                line.color = android.graphics.Color.rgb(0x39, 0xFF, 0x88)
                canvas.drawRect(l, t, r, b, line)
                val cx = (l + r) / 2f
                val cy = (t + b) / 2f
                val radius = 11.dp.toPx()
                tagBack.color = android.graphics.Color.argb(215, 4, 16, 10)
                canvas.drawCircle(cx, cy, radius, tagBack)
                line.strokeWidth = 1.dp.toPx()
                canvas.drawCircle(cx, cy, radius, line)
                tag.color = android.graphics.Color.WHITE
                canvas.drawText(tile.label, cx, cy + tag.textSize * 0.36f, tag)
            }
        }
    }
}
