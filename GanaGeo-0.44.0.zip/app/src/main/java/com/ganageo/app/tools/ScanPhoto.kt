package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Foto de una hoja tomada con el celular → hoja derecha, como escaneada.
 *
 * 1. [findPaper]: busca el papel (lo claro y sin color más grande, sin tocar el borde
 *    de la foto) y le ajusta 4 lados rectos → sus 4 esquinas.
 * 2. Si el papel no se ve entero (la hoja llena la foto), [findByLines]: usa las rayas
 *    largas de la hoja (bordes de tablas, subrayados) que en el papel son paralelas.
 * 3. [warp]: endereza (perspectiva) con esas 4 esquinas.
 * 4. [evenLight]: papel blanco parejo por canal (quita sombra y tono azul o amarillo),
 *    sin tocar los colores de las celdas.
 *
 * Todo se mide en una copia chica (rápido) y solo el enderezado final usa la foto
 * entera. Trabaja con colores ARGB (sin Android) para poder probarlo.
 */
object ScanPhoto {

    /** 4 esquinas (arriba-izq, arriba-der, abajo-der, abajo-izq) en píxeles de la foto. */
    class Quad(val points: FloatArray, val method: String) {
        fun x(i: Int) = points[i * 2]
        fun y(i: Int) = points[i * 2 + 1]
        /** Ancho y alto de la hoja enderezada (promedio de los lados opuestos). */
        fun size(): Pair<Int, Int> {
            val top = hypot(x(1) - x(0), y(1) - y(0))
            val bottom = hypot(x(2) - x(3), y(2) - y(3))
            val left = hypot(x(3) - x(0), y(3) - y(0))
            val right = hypot(x(2) - x(1), y(2) - y(1))
            return ((top + bottom) / 2f).roundToInt().coerceAtLeast(8) to ((left + right) / 2f).roundToInt().coerceAtLeast(8)
        }
    }

    private fun lum(c: Int) = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
    private fun sat(c: Int): Int {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return max(r, max(g, b)) - min(r, min(g, b))
    }

    /** Copia chica (promedio por cajitas) con lado mayor [side]. Devuelve (píxeles, ancho, alto, escala). */
    fun shrink(pixels: IntArray, width: Int, height: Int, side: Int): Triple<IntArray, Int, Float> {
        val scale = min(1f, side / max(width, height).toFloat())
        val w = max(1, (width * scale).roundToInt())
        val h = max(1, (height * scale).roundToInt())
        if (w == width && h == height) return Triple(pixels.copyOf(width * height), w, 1f)
        val out = IntArray(w * h)
        for (y in 0 until h) {
            val y0 = y * height / h
            val y1 = max(y0 + 1, (y + 1) * height / h)
            for (x in 0 until w) {
                val x0 = x * width / w
                val x1 = max(x0 + 1, (x + 1) * width / w)
                var r = 0
                var g = 0
                var b = 0
                var n = 0
                var outside = 0
                var yy = y0
                while (yy < y1) {
                    var xx = x0
                    val row = yy * width
                    while (xx < x1) {
                        val c = pixels[row + xx]
                        if ((c ushr 24) == 0) outside++
                        r += (c shr 16) and 255
                        g += (c shr 8) and 255
                        b += c and 255
                        n++
                        xx += 1
                    }
                    yy += 1
                }
                val alpha = if (outside * 2 > n) 0 else 0xFF
                out[y * w + x] = (alpha shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
            }
        }
        return Triple(out, w, w / width.toFloat())
    }

    // ------------------------------------------------------------------ papel

    /**
     * Esquinas del papel en una foto chica ([width]×[height]); null si el papel no se
     * ve entero (toca el borde) o no tiene forma de hoja.
     */
    fun findPaper(pixels: IntArray, width: Int, height: Int): Quad? {
        val count = width * height
        if (width < 32 || height < 32) return null
        val l = IntArray(count) { lum(pixels[it]) }
        val s = IntArray(count) { sat(pixels[it]) }
        val sorted = l.copyOf().also { it.sort() }
        val otsu = otsu(l)
        val p92 = sorted[(count * 0.92f).toInt().coerceAtMost(count - 1)]
        var best: Quad? = null
        var bestScore = 0f
        // Se prueban varios cortes de claridad: el que da la hoja más "rectangular" gana.
        var t = otsu
        val top = p92 - 8
        if (t > top) t = top - 24
        while (t <= top) {
            val mask = BooleanArray(count) { l[it] >= t && s[it] < 70 }
            val quad = quadFromMask(mask, width, height)
            if (quad != null) {
                val score = quad.second
                if (score > bestScore) {
                    bestScore = score
                    best = quad.first
                }
            }
            t += 6
        }
        return best
    }

    private fun otsu(values: IntArray): Int {
        val histogram = IntArray(256)
        for (v in values) histogram[v.coerceIn(0, 255)]++
        val total = values.size.toDouble()
        var sum = 0.0
        for (i in 0 until 256) sum += i * histogram[i].toDouble()
        var weight = 0.0
        var sumBack = 0.0
        var best = 0.0
        var threshold = 128
        for (i in 0 until 256) {
            weight += histogram[i]
            if (weight == 0.0) continue
            val front = total - weight
            if (front == 0.0) break
            sumBack += i * histogram[i].toDouble()
            val meanBack = sumBack / weight
            val meanFront = (sum - sumBack) / front
            val between = weight * front * (meanBack - meanFront) * (meanBack - meanFront)
            if (between > best) {
                best = between
                threshold = i
            }
        }
        return threshold
    }

    /** La mancha clara más grande, con sus huecos (el texto) rellenos → 4 lados rectos. */
    private fun quadFromMask(mask: BooleanArray, width: Int, height: Int): Pair<Quad, Float>? {
        val count = width * height
        val label = IntArray(count)
        var current = 0
        var bestLabel = 0
        var bestSize = 0
        val queue = IntArray(count)
        for (start in 0 until count) {
            if (!mask[start] || label[start] != 0) continue
            current++
            var head = 0
            var tail = 0
            queue[tail++] = start
            label[start] = current
            while (head < tail) {
                val i = queue[head++]
                val x = i % width
                val y = i / width
                if (x > 0 && mask[i - 1] && label[i - 1] == 0) { label[i - 1] = current; queue[tail++] = i - 1 }
                if (x < width - 1 && mask[i + 1] && label[i + 1] == 0) { label[i + 1] = current; queue[tail++] = i + 1 }
                if (y > 0 && mask[i - width] && label[i - width] == 0) { label[i - width] = current; queue[tail++] = i - width }
                if (y < height - 1 && mask[i + width] && label[i + width] == 0) { label[i + width] = current; queue[tail++] = i + width }
            }
            if (tail > bestSize) {
                bestSize = tail
                bestLabel = current
            }
        }
        if (bestSize < count * 0.12f) return null
        // Toca el borde de la foto: la hoja no se ve entera.
        var border = 0
        for (x in 0 until width) {
            if (label[x] == bestLabel) border++
            if (label[(height - 1) * width + x] == bestLabel) border++
        }
        for (y in 0 until height) {
            if (label[y * width] == bestLabel) border++
            if (label[y * width + width - 1] == bestLabel) border++
        }
        if (border > (width + height) * 2 * 0.01f) return null
        // Huecos rellenos: todo lo que no se alcanza desde el borde sin pasar por la mancha.
        val outside = BooleanArray(count)
        var head = 0
        var tail = 0
        fun push(i: Int) {
            if (!outside[i] && label[i] != bestLabel) {
                outside[i] = true
                queue[tail++] = i
            }
        }
        for (x in 0 until width) { push(x); push((height - 1) * width + x) }
        for (y in 0 until height) { push(y * width); push(y * width + width - 1) }
        while (head < tail) {
            val i = queue[head++]
            val x = i % width
            val y = i / width
            if (x > 0) push(i - 1)
            if (x < width - 1) push(i + 1)
            if (y > 0) push(i - width)
            if (y < height - 1) push(i + width)
        }
        var area = 0
        val edgeX = ArrayList<Float>()
        val edgeY = ArrayList<Float>()
        for (y in 0 until height) for (x in 0 until width) {
            val i = y * width + x
            if (outside[i]) continue
            area++
            val edge = x == 0 || y == 0 || x == width - 1 || y == height - 1 ||
                outside[i - 1] || outside[i + 1] || outside[i - width] || outside[i + width]
            if (edge) {
                edgeX += x + 0.5f
                edgeY += y + 0.5f
            }
        }
        if (edgeX.size < 40) return null
        val quad = fitQuad(edgeX, edgeY) ?: return null
        val quadArea = polygonArea(quad)
        if (quadArea < count * 0.12f) return null
        val fill = area / quadArea
        if (fill < 0.88f || fill > 1.08f) return null
        if (!reasonable(quad, width, height)) return null
        return Quad(quad, "papel") to (min(fill, 1f / fill) * sqrt(area.toFloat()))
    }

    /** 4 lados rectos ajustados al borde de la mancha → 4 esquinas. */
    private fun fitQuad(xs: List<Float>, ys: List<Float>): FloatArray? {
        val n = xs.size
        var tl = 0
        var br = 0
        var tr = 0
        var bl = 0
        for (i in 0 until n) {
            if (xs[i] + ys[i] < xs[tl] + ys[tl]) tl = i
            if (xs[i] + ys[i] > xs[br] + ys[br]) br = i
            if (xs[i] - ys[i] > xs[tr] - ys[tr]) tr = i
            if (xs[i] - ys[i] < xs[bl] - ys[bl]) bl = i
        }
        val corners = floatArrayOf(xs[tl], ys[tl], xs[tr], ys[tr], xs[br], ys[br], xs[bl], ys[bl])
        // Cada punto del borde va al lado más cercano.
        val sides = Array(4) { ArrayList<Int>() }
        for (i in 0 until n) {
            var bestSide = 0
            var bestDistance = Float.MAX_VALUE
            for (k in 0 until 4) {
                val d = segmentDistance(xs[i], ys[i], corners[k * 2], corners[k * 2 + 1], corners[(k + 1) % 4 * 2], corners[(k + 1) % 4 * 2 + 1])
                if (d < bestDistance) {
                    bestDistance = d
                    bestSide = k
                }
            }
            sides[bestSide] += i
        }
        val lines = Array(4) { FloatArray(3) }
        for (k in 0 until 4) {
            val line = fitLine(sides[k].map { xs[it] }, sides[k].map { ys[it] }) ?: return null
            lines[k] = line
        }
        val out = FloatArray(8)
        for (k in 0 until 4) {
            val p = intersect(lines[(k + 3) % 4], lines[k]) ?: return null
            out[k * 2] = p.first
            out[k * 2 + 1] = p.second
        }
        return out
    }

    private fun segmentDistance(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax
        val dy = by - ay
        val len = dx * dx + dy * dy
        val t = if (len <= 0f) 0f else (((px - ax) * dx + (py - ay) * dy) / len).coerceIn(0f, 1f)
        return hypot(px - (ax + t * dx), py - (ay + t * dy))
    }

    /** Recta a·x + b·y = c (a² + b² = 1) por mínimos cuadrados totales, sin los puntos raros. */
    private fun fitLine(xs: List<Float>, ys: List<Float>): FloatArray? {
        var keep = xs.indices.toList()
        var line: FloatArray? = null
        repeat(3) {
            if (keep.size < 4) return line
            var mx = 0.0
            var my = 0.0
            for (i in keep) { mx += xs[i]; my += ys[i] }
            mx /= keep.size
            my /= keep.size
            var sxx = 0.0
            var syy = 0.0
            var sxy = 0.0
            for (i in keep) {
                val dx = xs[i] - mx
                val dy = ys[i] - my
                sxx += dx * dx
                syy += dy * dy
                sxy += dx * dy
            }
            val angle = 0.5 * atan2(2 * sxy, sxx - syy) // dirección de la recta
            val a = -sin(angle)
            val b = cos(angle)
            val c = a * mx + b * my
            line = floatArrayOf(a.toFloat(), b.toFloat(), c.toFloat())
            val residuals = keep.map { abs(a * xs[it] + b * ys[it] - c) }
            val sortedResiduals = residuals.sorted()
            val limit = max(1.5, sortedResiduals[sortedResiduals.size / 2] * 2.5)
            keep = keep.filterIndexed { index, _ -> residuals[index] <= limit }
        }
        return line
    }

    private fun intersect(p: FloatArray, q: FloatArray): Pair<Float, Float>? {
        val det = p[0] * q[1] - p[1] * q[0]
        if (abs(det) < 1e-6f) return null
        return ((p[2] * q[1] - p[1] * q[2]) / det) to ((p[0] * q[2] - p[2] * q[0]) / det)
    }

    private fun polygonArea(q: FloatArray): Float {
        var sum = 0f
        for (k in 0 until 4) {
            val j = (k + 1) % 4
            sum += q[k * 2] * q[j * 2 + 1] - q[j * 2] * q[k * 2 + 1]
        }
        return abs(sum) / 2f
    }

    /** Convexa, ángulos de hoja (50°-130°) y esquinas cerca de la foto. */
    private fun reasonable(q: FloatArray, width: Int, height: Int): Boolean {
        var sign = 0
        for (k in 0 until 4) {
            val ax = q[k * 2]
            val ay = q[k * 2 + 1]
            val bx = q[(k + 1) % 4 * 2]
            val by = q[(k + 1) % 4 * 2 + 1]
            val cx = q[(k + 2) % 4 * 2]
            val cy = q[(k + 2) % 4 * 2 + 1]
            val cross = (bx - ax) * (cy - by) - (by - ay) * (cx - bx)
            val s = if (cross > 0) 1 else -1
            if (sign == 0) sign = s else if (s != sign) return false
            val v1x = ax - bx
            val v1y = ay - by
            val v2x = cx - bx
            val v2y = cy - by
            val cosAngle = (v1x * v2x + v1y * v2y) / (hypot(v1x, v1y) * hypot(v2x, v2y)).coerceAtLeast(1e-3f)
            if (abs(cosAngle) > 0.643f) return false // fuera de 50°..130°
        }
        for (k in 0 until 4) {
            if (q[k * 2] < -width * 0.1f || q[k * 2] > width * 1.1f) return false
            if (q[k * 2 + 1] < -height * 0.1f || q[k * 2 + 1] > height * 1.1f) return false
        }
        return true
    }

    // ------------------------------------------------------------------ rayas

    /**
     * Cuando la hoja llena la foto: las rayas largas (bordes de tablas, subrayados) son
     * paralelas en el papel. Con la de más arriba y la de más abajo, y la de más a la
     * izquierda y más a la derecha, se arma un rectángulo del papel → 4 esquinas.
     * null si no hay rayas suficientes.
     */
    fun findByLines(pixels: IntArray, width: Int, height: Int): Quad? {
        val (alongX, alongY) = thinLines(pixels, width, height)
        // Primero solo rayas largas (40 % del lado); si no alcanzan, también las medianas.
        var horizontal = consistent(houghLines(alongX, width, height, vertical = false, share = 0.4f))
        if (horizontal.size < 2) horizontal = consistent(houghLines(alongX, width, height, vertical = false, share = 0.25f))
        var vertical = consistent(houghLines(alongY, width, height, vertical = true, share = 0.4f))
        if (vertical.size < 2) vertical = consistent(houghLines(alongY, width, height, vertical = true, share = 0.25f))
        if (System.getProperty("scan.debug") != null) {
            println("H " + horizontal.joinToString { "%.2f°/%.0f/%.0f".format(Math.toDegrees(it[0].toDouble()), it[1], it[2]) })
            println("V " + vertical.joinToString { "%.2f°/%.0f/%.0f".format(Math.toDegrees(it[0].toDouble()), it[1], it[2]) })
        }
        if (horizontal.size < 2 || vertical.size < 2) return null
        // Rayas: (ángulo, distancia, largo). Las de los extremos, separadas.
        val topLine = horizontal.minBy { it[1] }
        val bottomLine = horizontal.maxBy { it[1] }
        val leftLine = vertical.minBy { it[1] }
        val rightLine = vertical.maxBy { it[1] }
        if (bottomLine[1] - topLine[1] < height * 0.25f) return null
        if (rightLine[1] - leftLine[1] < width * 0.25f) return null
        val lines = listOf(topLine, rightLine, bottomLine, leftLine).map { toLine(it) }
        val out = FloatArray(8)
        for (k in 0 until 4) {
            val p = intersect(lines[(k + 3) % 4], lines[k]) ?: return null
            out[k * 2] = p.first
            out[k * 2 + 1] = p.second
        }
        if (!reasonable(out, width, height)) return null
        return Quad(out, "rayas")
    }

    /**
     * En una foto con perspectiva, la inclinación de las rayas paralelas del papel cambia
     * de a pocos según dónde están (en línea). Se quitan las que no siguen esa regla
     * (sombras, bordes de otras cosas, dobleces): así no tuercen el enderezado.
     */
    internal fun consistent(lines: List<FloatArray>, toleranceDegrees: Double = 1.2): List<FloatArray> {
        if (lines.size < 4) return lines
        val keep = lines.toMutableList()
        val tolerance = Math.toRadians(toleranceDegrees)
        while (keep.size >= 4) {
            // Recta ángulo = a + b·ρ por mínimos cuadrados pesados por el largo.
            var sw = 0.0; var sx = 0.0; var sy = 0.0; var sxx = 0.0; var sxy = 0.0
            for (l in keep) {
                val wt = l[2].toDouble()
                val x = l[1].toDouble()
                val y = l[0].toDouble()
                sw += wt; sx += wt * x; sy += wt * y; sxx += wt * x * x; sxy += wt * x * y
            }
            val den = sw * sxx - sx * sx
            val b = if (abs(den) < 1e-9) 0.0 else (sw * sxy - sx * sy) / den
            val a = (sy - b * sx) / sw
            val worst = keep.maxBy { abs(it[0] - (a + b * it[1])) }
            if (abs(worst[0] - (a + b * worst[1])) <= tolerance) break
            keep.remove(worst)
        }
        return keep
    }

    /** Recta a·x + b·y = c desde (ángulo θ, ρ): horizontal y·cosθ − x·sinθ = ρ; vertical x·cosθ + y·sinθ = ρ. */
    private fun toLine(line: FloatArray): FloatArray {
        val theta = line[0].toDouble()
        return if (line[3] == 0f) {
            floatArrayOf((-sin(theta)).toFloat(), cos(theta).toFloat(), line[1])
        } else {
            floatArrayOf(cos(theta).toFloat(), sin(theta).toFloat(), line[1])
        }
    }

    /**
     * Rayas finas: puntos oscuros con papel claro a los dos lados (arriba y abajo para
     * las rayas que van de lado; izquierda y derecha para las que bajan). Así no cuentan
     * los bordes de la pared, la mesa o la sombra (claro de un solo lado).
     */
    private fun thinLines(pixels: IntArray, width: Int, height: Int): Pair<BooleanArray, BooleanArray> {
        val dark = darkLines(pixels, width, height)
        val l = IntArray(width * height) { lum(pixels[it]) }
        val alongX = BooleanArray(dark.size)
        val alongY = BooleanArray(dark.size)
        val reach = intArrayOf(2, 3, 5)
        for (y in 0 until height) for (x in 0 until width) {
            val i = y * width + x
            if (!dark[i]) continue
            val v = l[i] + 18
            for (k in reach) {
                if (y - k >= 0 && y + k < height && l[i - k * width] >= v && l[i + k * width] >= v) { alongX[i] = true; break }
            }
            for (k in reach) {
                if (x - k >= 0 && x + k < width && l[i - k] >= v && l[i + k] >= v) { alongY[i] = true; break }
            }
        }
        return alongX to alongY
    }

    /** Puntos de raya oscura: más oscuro que el papel de alrededor (no los bordes de color). */
    private fun darkLines(pixels: IntArray, width: Int, height: Int): BooleanArray {
        val count = width * height
        val l = IntArray(count) { lum(pixels[it]) }
        // Promedio del barrio (caja de 2·r+1) con sumas acumuladas.
        val r = max(4, min(width, height) / 40)
        val integral = LongArray((width + 1) * (height + 1))
        for (y in 0 until height) {
            var rowSum = 0L
            for (x in 0 until width) {
                rowSum += l[y * width + x]
                integral[(y + 1) * (width + 1) + x + 1] = integral[y * (width + 1) + x + 1] + rowSum
            }
        }
        val out = BooleanArray(count)
        for (y in 0 until height) {
            val y0 = max(0, y - r)
            val y1 = min(height, y + r + 1)
            for (x in 0 until width) {
                val x0 = max(0, x - r)
                val x1 = min(width, x + r + 1)
                val sum = integral[y1 * (width + 1) + x1] - integral[y0 * (width + 1) + x1] - integral[y1 * (width + 1) + x0] + integral[y0 * (width + 1) + x0]
                val mean = sum / ((y1 - y0) * (x1 - x0)).toFloat()
                out[y * width + x] = l[y * width + x] < mean - 28
            }
        }
        return out
    }

    /**
     * Rayas largas casi horizontales (o verticales) por votación (Hough), ±20°.
     * Devuelve [θ, ρ, votos, 0 = horizontal / 1 = vertical] con votos ≥ 40 % del lado.
     */
    private fun houghLines(dark: BooleanArray, width: Int, height: Int, vertical: Boolean, share: Float = 0.4f): List<FloatArray> {
        val steps = 161 // -20°..20° cada 0.25°
        val span = if (vertical) height else width
        val other = if (vertical) width else height
        val diagonal = (hypot(width.toFloat(), height.toFloat()) + 2).toInt()
        val bins = diagonal * 2
        val votes = IntArray(steps * bins)
        val sines = FloatArray(steps) { sin(Math.toRadians(-20.0 + it * 0.25)).toFloat() }
        val cosines = FloatArray(steps) { cos(Math.toRadians(-20.0 + it * 0.25)).toFloat() }
        for (y in 0 until height) for (x in 0 until width) {
            if (!dark[y * width + x]) continue
            for (k in 0 until steps) {
                val rho = if (vertical) x * cosines[k] + y * sines[k] else y * cosines[k] - x * sines[k]
                val bin = (rho + diagonal).roundToInt()
                if (bin in 0 until bins) votes[k * bins + bin]++
            }
        }
        val need = (span * share).toInt()
        val found = ArrayList<FloatArray>()
        // Picos (máximo en su vecindad) con suficientes votos.
        val order = votes.indices.filter { votes[it] >= need }.sortedByDescending { votes[it] }
        val taken = BooleanArray(votes.size)
        for (index in order) {
            if (taken[index]) continue
            val k = index / bins
            val bin = index % bins
            for (dk in -12..12) for (db in -4..4) {
                val kk = k + dk
                val bb = bin + db
                if (kk in 0 until steps && bb in 0 until bins) taken[kk * bins + bb] = true
            }
            val theta = Math.toRadians(-20.0 + k * 0.25).toFloat()
            val rho = (bin - diagonal).toFloat()
            // Que caiga dentro de la foto.
            if (rho < -other * 0.05f || rho > other * 1.05f) continue
            found += floatArrayOf(theta, rho, votes[index].toFloat(), if (vertical) 1f else 0f)
        }
        // Todas casi con la misma inclinación que la más fuerte (las rayas del papel).
        val main = found.maxByOrNull { it[2] } ?: return emptyList()
        return found.filter { abs(it[0] - main[0]) < Math.toRadians(8.0) }
    }

    // ------------------------------------------------------------------ enderezar

    /**
     * Matriz (3×3, por filas) que lleva el rectángulo (0,0)-(w,h) a las 4 esquinas
     * [quad] (para tomar cada punto de la hoja derecha desde la foto).
     */
    fun homography(quad: FloatArray, w: Float, h: Float): DoubleArray? {
        val src = doubleArrayOf(0.0, 0.0, w.toDouble(), 0.0, w.toDouble(), h.toDouble(), 0.0, h.toDouble())
        val a = Array(8) { DoubleArray(9) }
        for (i in 0 until 4) {
            val x = src[i * 2]
            val y = src[i * 2 + 1]
            val u = quad[i * 2].toDouble()
            val v = quad[i * 2 + 1].toDouble()
            a[i * 2] = doubleArrayOf(x, y, 1.0, 0.0, 0.0, 0.0, -u * x, -u * y, u)
            a[i * 2 + 1] = doubleArrayOf(0.0, 0.0, 0.0, x, y, 1.0, -v * x, -v * y, v)
        }
        // Gauss con pivote.
        for (col in 0 until 8) {
            var pivot = col
            for (row in col + 1 until 8) if (abs(a[row][col]) > abs(a[pivot][col])) pivot = row
            if (abs(a[pivot][col]) < 1e-12) return null
            val swap = a[col]; a[col] = a[pivot]; a[pivot] = swap
            for (row in 0 until 8) {
                if (row == col) continue
                val f = a[row][col] / a[col][col]
                if (f == 0.0) continue
                for (k in col until 9) a[row][k] -= f * a[col][k]
            }
        }
        val m = DoubleArray(9)
        for (i in 0 until 8) m[i] = a[i][8] / a[i][i]
        m[8] = 1.0
        return m
    }

    /** Hoja derecha de [outWidth]×[outHeight] tomada de la foto (bilineal). */
    fun warp(pixels: IntArray, width: Int, height: Int, quad: FloatArray, outWidth: Int, outHeight: Int): IntArray {
        val m = homography(quad, outWidth.toFloat(), outHeight.toFloat()) ?: return pixels.copyOf()
        val out = IntArray(outWidth * outHeight)
        for (y in 0 until outHeight) {
            val fy = y + 0.5
            for (x in 0 until outWidth) {
                val fx = x + 0.5
                val w = m[6] * fx + m[7] * fy + m[8]
                val u = ((m[0] * fx + m[1] * fy + m[2]) / w - 0.5).toFloat()
                val v = ((m[3] * fx + m[4] * fy + m[5]) / w - 0.5).toFloat()
                out[y * outWidth + x] = sample(pixels, width, height, u, v)
            }
        }
        return out
    }

    private fun sample(pixels: IntArray, width: Int, height: Int, u: Float, v: Float): Int {
        // Fuera de la foto: marcado transparente (al final queda blanco).
        if (u < -1f || v < -1f || u > width || v > height) return 0x00FFFFFF
        val x0 = kotlin.math.floor(u).toInt()
        val y0 = kotlin.math.floor(v).toInt()
        val tx = u - x0
        val ty = v - y0
        val xa = x0.coerceIn(0, width - 1)
        val xb = (x0 + 1).coerceIn(0, width - 1)
        val ya = y0.coerceIn(0, height - 1) * width
        val yb = (y0 + 1).coerceIn(0, height - 1) * width
        val c00 = pixels[ya + xa]
        val c01 = pixels[ya + xb]
        val c10 = pixels[yb + xa]
        val c11 = pixels[yb + xb]
        fun ch(shift: Int): Int {
            val top = ((c00 shr shift) and 255) * (1 - tx) + ((c01 shr shift) and 255) * tx
            val bottom = ((c10 shr shift) and 255) * (1 - tx) + ((c11 shr shift) and 255) * tx
            return (top * (1 - ty) + bottom * ty).roundToInt().coerceIn(0, 255)
        }
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /**
     * Con [findByLines] solo se conoce el marco de las tablas: la hoja enderezada se
     * agranda hacia afuera hasta cubrir toda la foto (máximo [grow] veces el marco por lado)
     * para no perder el título, los nombres y el sello.
     */
    fun expandQuad(quad: Quad, width: Int, height: Int, grow: Float = 2.5f): Quad {
        val (w, h) = quad.size()
        val m = homography(quad.points, w.toFloat(), h.toFloat()) ?: return quad
        // Inversa de la matriz: foto → hoja derecha.
        val inv = invert(m) ?: return quad
        var minX = 0.0
        var minY = 0.0
        var maxX = w.toDouble()
        var maxY = h.toDouble()
        for ((px, py) in listOf(0.0 to 0.0, width.toDouble() to 0.0, width.toDouble() to height.toDouble(), 0.0 to height.toDouble())) {
            val d = inv[6] * px + inv[7] * py + inv[8]
            if (d <= 1e-9) continue
            val x = (inv[0] * px + inv[1] * py + inv[2]) / d
            val y = (inv[3] * px + inv[4] * py + inv[5]) / d
            minX = min(minX, x); maxX = max(maxX, x)
            minY = min(minY, y); maxY = max(maxY, y)
        }
        minX = max(minX, -w * grow.toDouble()); maxX = min(maxX, w * (1 + grow).toDouble())
        minY = max(minY, -h * grow.toDouble()); maxY = min(maxY, h * (1 + grow).toDouble())
        val corners = listOf(minX to minY, maxX to minY, maxX to maxY, minX to maxY)
        val out = FloatArray(8)
        corners.forEachIndexed { k, (x, y) ->
            val d = m[6] * x + m[7] * y + m[8]
            out[k * 2] = ((m[0] * x + m[1] * y + m[2]) / d).toFloat()
            out[k * 2 + 1] = ((m[3] * x + m[4] * y + m[5]) / d).toFloat()
        }
        return Quad(out, quad.method)
    }

    private fun invert(m: DoubleArray): DoubleArray? {
        val det = m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) + m[2] * (m[3] * m[7] - m[4] * m[6])
        if (abs(det) < 1e-12) return null
        return doubleArrayOf(
            (m[4] * m[8] - m[5] * m[7]) / det, (m[2] * m[7] - m[1] * m[8]) / det, (m[1] * m[5] - m[2] * m[4]) / det,
            (m[5] * m[6] - m[3] * m[8]) / det, (m[0] * m[8] - m[2] * m[6]) / det, (m[2] * m[3] - m[0] * m[5]) / det,
            (m[3] * m[7] - m[4] * m[6]) / det, (m[1] * m[6] - m[0] * m[7]) / det, (m[0] * m[4] - m[1] * m[3]) / det
        )
    }

    /**
     * Quita las franjas del borde que no son papel (pared, mesa) de una hoja ya derecha:
     * cada lado se corre hacia adentro mientras su fila o columna tenga poco papel.
     * Devuelve [izq, arriba, der, abajo].
     */
    fun paperBounds(pixels: IntArray, width: Int, height: Int): IntArray {
        val (small, w, scale) = shrink(pixels, width, height, 400)
        val h = small.size / w
        val paper = BooleanArray(small.size) { val c = small[it]; (c ushr 24) != 0 && lum(c) >= 120 && sat(c) < 60 }
        fun rowShare(y: Int, x0: Int, x1: Int): Float { var n = 0; for (x in x0 until x1) if (paper[y * w + x]) n++; return n / (x1 - x0).coerceAtLeast(1).toFloat() }
        fun colShare(x: Int, y0: Int, y1: Int): Float { var n = 0; for (y in y0 until y1) if (paper[y * w + x]) n++; return n / (y1 - y0).coerceAtLeast(1).toFloat() }
        var left = 0
        var top = 0
        var right = w
        var bottom = h
        val need = 0.7f
        repeat(3) {
            while (top < bottom - h / 3 && rowShare(top, left, right) < need) top++
            while (bottom > top + h / 3 && rowShare(bottom - 1, left, right) < need) bottom--
            while (left < right - w / 3 && colShare(left, top, bottom) < need) left++
            while (right > left + w / 3 && colShare(right - 1, top, bottom) < need) right--
        }
        return intArrayOf(
            (left / scale).toInt().coerceIn(0, width), (top / scale).toInt().coerceIn(0, height),
            (right / scale).roundToInt().coerceIn(0, width), (bottom / scale).roundToInt().coerceIn(0, height)
        )
    }

    /**
     * Caja de lo escrito sobre el papel (letras, rayas, celdas) en una hoja ya derecha,
     * con un margen. Lo oscuro que no está rodeado de papel (pared, mesa) no cuenta.
     * Devuelve [izq, arriba, der, abajo].
     */
    fun contentBounds(pixels: IntArray, width: Int, height: Int): IntArray {
        val (small, w, scale) = shrink(pixels, width, height, 500)
        val h = small.size / w
        val count = w * h
        val paper = IntArray((w + 1) * (h + 1)) // sumas acumuladas de "es papel"
        for (y in 0 until h) {
            var row = 0
            for (x in 0 until w) {
                val c = small[y * w + x]
                // Papel o celda de color claro (no la pared ni la mesa).
                if ((c ushr 24) != 0 && ((lum(c) >= 110 && sat(c) < 60) || (lum(c) >= 150 && sat(c) < 150))) row++
                paper[(y + 1) * (w + 1) + x + 1] = paper[y * (w + 1) + x + 1] + row
            }
        }
        val ink = darkLines(small, w, h)
        val r = max(3, min(w, h) / 30)
        val xs = ArrayList<Int>()
        val ys = ArrayList<Int>()
        for (y in 0 until h) for (x in 0 until w) {
            val c = small[y * w + x]
            // Lo escrito: raya o letra oscura, o celda de color suave.
            if ((c ushr 24) == 0) continue
            val colored = sat(c) in 25..140 && lum(c) > 110
            if (!ink[y * w + x] && !colored) continue
            val x0 = max(0, x - r); val x1 = min(w, x + r + 1)
            val y0 = max(0, y - r); val y1 = min(h, y + r + 1)
            val around = paper[y1 * (w + 1) + x1] - paper[y0 * (w + 1) + x1] - paper[y1 * (w + 1) + x0] + paper[y0 * (w + 1) + x0]
            if (around < (x1 - x0) * (y1 - y0) * 0.75f) continue
            xs += x
            ys += y
        }
        if (xs.size < count / 400) return intArrayOf(0, 0, width, height)
        xs.sort()
        ys.sort()
        val cut = (xs.size * 0.002f).toInt()
        val pad = max(w, h) * 0.03f
        val left = (xs[cut] - pad).coerceAtLeast(0f)
        val right = (xs[xs.size - 1 - cut] + 1 + pad).coerceAtMost(w.toFloat())
        val top = (ys[cut] - pad).coerceAtLeast(0f)
        val bottom = (ys[ys.size - 1 - cut] + 1 + pad).coerceAtMost(h.toFloat())
        return intArrayOf(
            (left / scale).toInt().coerceIn(0, width), (top / scale).toInt().coerceIn(0, height),
            (right / scale).roundToInt().coerceIn(0, width), (bottom / scale).roundToInt().coerceIn(0, height)
        )
    }

    /**
     * Lo que no es papel y entra desde el borde de la hoja derecha (pared, mesa) se
     * vuelve transparente (después, blanco). Las rayas finas no dejan pasar (se miran
     * "adelgazadas"): así no se borra una tabla aunque toque el borde con una raya.
     */
    fun clearOutside(pixels: IntArray, width: Int, height: Int, minLum: Int = 135, maxSat: Int = 60) {
        val (small, w, scale) = shrink(pixels, width, height, 500)
        val h = small.size / w
        val count = w * h
        val notPaper = BooleanArray(count) { val c = small[it]; (c ushr 24) == 0 || !(lum(c) >= minLum && sat(c) < maxSat) }
        // Adelgazar: se queda solo lo "grueso" (2 px chicos de cada lado).
        fun erode(src: BooleanArray): BooleanArray = BooleanArray(count) { i ->
            val x = i % w
            val y = i / w
            src[i] && (x == 0 || src[i - 1]) && (x == w - 1 || src[i + 1]) && (y == 0 || src[i - w]) && (y == h - 1 || src[i + w])
        }
        var thick = notPaper
        repeat(2) { thick = erode(thick) }
        val outside = BooleanArray(count)
        val queue = IntArray(count)
        var head = 0
        var tail = 0
        fun push(i: Int) {
            if (thick[i] && !outside[i]) {
                outside[i] = true
                queue[tail++] = i
            }
        }
        for (x in 0 until w) { push(x); push((h - 1) * w + x) }
        for (y in 0 until h) { push(y * w); push(y * w + w - 1) }
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            if (x > 0) push(i - 1)
            if (x < w - 1) push(i + 1)
            if (y > 0) push(i - w)
            if (y < h - 1) push(i + w)
        }
        // Se devuelve lo adelgazado (3 px chicos), solo sobre lo que no es papel.
        var grown = outside
        repeat(3) {
            val prev = grown
            grown = BooleanArray(count) { i ->
                if (prev[i]) true else if (!notPaper[i]) false else {
                    val x = i % w
                    val y = i / w
                    (x > 0 && prev[i - 1]) || (x < w - 1 && prev[i + 1]) || (y > 0 && prev[i - w]) || (y < h - 1 && prev[i + w])
                }
            }
        }
        if (grown.none { it }) return
        for (y in 0 until height) {
            val sy = (y * scale).toInt().coerceIn(0, h - 1)
            for (x in 0 until width) {
                val sx = (x * scale).toInt().coerceIn(0, w - 1)
                if (grown[sy * w + sx]) pixels[y * width + x] = 0x00FFFFFF
            }
        }
    }


    // ------------------------------------------------------------------ hoja doblada

    /**
     * Hoja doblada o un poco chueca (pegada en la pared, curvada): las rayas largas
     * (de tablas y subrayados) se siguen de punta a punta y se mide cuánto se tuercen.
     * Con eso se arma un "mapa de corrimiento" suave y se corre cada punto para que
     * todas las rayas queden rectas (horizontales y verticales). Sin rayas, no cambia.
     * Devuelve la hoja corregida o null si ya estaba recta.
     */
    /**
     * Cuánto se ven dobladas las rayas largas de la hoja (px de una copia de 1100 px;
     * 0 = derechas o sin rayas para medir). Sirve para saber si aplanar ayudó.
     */
    fun bend(pixels: IntArray, width: Int, height: Int): Float {
        if (width < 64 || height < 64) return 0f
        val (small, w, _) = shrink(pixels, width, height, 1100)
        val h = small.size / w
        val l = IntArray(small.size) { lum(small[it]) }
        val k = 3
        val ridgeH = BooleanArray(small.size)
        val ridgeV = BooleanArray(small.size)
        for (y in k until h - k) for (x in k until w - k) {
            val i = y * w + x
            val v = l[i]
            ridgeH[i] = l[i - k * w] - v >= 22 && l[i + k * w] - v >= 22
            ridgeV[i] = l[i - k] - v >= 22 && l[i + k] - v >= 22
        }
        val step = 8
        val gw = w / step + 2
        val gh = h / step + 2
        val dy = field(tracks(ridgeH, w, h, vertical = false), gw, gh, step, w, h, vertical = false)
        val dx = field(tracks(ridgeV, w, h, vertical = true), gw, gh, step, w, h, vertical = true)
        var biggest = 0f
        dy?.forEach { biggest = max(biggest, abs(it)) }
        dx?.forEach { biggest = max(biggest, abs(it)) }
        return biggest
    }

    fun dewarp(pixels: IntArray, width: Int, height: Int): IntArray? {
        if (width < 64 || height < 64) return null
        val (small, w, scale) = shrink(pixels, width, height, 1100)
        val h = small.size / w
        val l = IntArray(small.size) { lum(small[it]) }
        val k = 3
        val ridgeH = BooleanArray(small.size)
        val ridgeV = BooleanArray(small.size)
        for (y in k until h - k) for (x in k until w - k) {
            val i = y * w + x
            val v = l[i]
            ridgeH[i] = l[i - k * w] - v >= 22 && l[i + k * w] - v >= 22
            ridgeV[i] = l[i - k] - v >= 22 && l[i + k] - v >= 22
        }
        val horizontal = tracks(ridgeH, w, h, vertical = false)
        val vertical = tracks(ridgeV, w, h, vertical = true)
        val step = 8
        val gw = w / step + 2
        val gh = h / step + 2
        val dy = field(horizontal, gw, gh, step, w, h, vertical = false)
        val dx = field(vertical, gw, gh, step, w, h, vertical = true)
        if (dy == null && dx == null) return null
        var biggest = 0f
        dy?.forEach { biggest = max(biggest, abs(it)) }
        dx?.forEach { biggest = max(biggest, abs(it)) }
        if (biggest < 0.6f) return null
        val out = IntArray(width * height)
        val inv = 1f / scale
        for (y in 0 until height) {
            val gy = (y * scale / step).coerceIn(0f, (gh - 1).toFloat())
            val y0 = gy.toInt().coerceAtMost(gh - 2)
            val ty = gy - y0
            for (x in 0 until width) {
                val gx = (x * scale / step).coerceIn(0f, (gw - 1).toFloat())
                val x0 = gx.toInt().coerceAtMost(gw - 2)
                val tx = gx - x0
                fun at(grid: FloatArray?): Float {
                    if (grid == null) return 0f
                    val a = grid[y0 * gw + x0] * (1 - tx) + grid[y0 * gw + x0 + 1] * tx
                    val b = grid[(y0 + 1) * gw + x0] * (1 - tx) + grid[(y0 + 1) * gw + x0 + 1] * tx
                    return a * (1 - ty) + b * ty
                }
                val u = x + at(dx) * inv
                val v = y + at(dy) * inv
                out[y * width + x] = sample(pixels, width, height, u, v).let { if ((it ushr 24) == 0) -1 else it }
            }
        }
        return out
    }

    /**
     * Rayas largas seguidas punto a punto (se permiten huecos chicos). Cada una: lista
     * de (posición a lo largo, posición de costado) cada 1 px. Solo las de más del 20 %
     * del lado.
     */
    private fun tracks(ridge: BooleanArray, w: Int, h: Int, vertical: Boolean): List<FloatArray> {
        val along = if (vertical) h else w
        val across = if (vertical) w else h
        fun on(a: Int, c: Int): Boolean = if (a !in 0 until along || c !in 0 until across) false else
            if (vertical) ridge[a * w + c] else ridge[c * w + a]
        val taken = BooleanArray(w * h)
        fun take(a: Int, c: Int) { for (d in -2..2) { val cc = c + d; if (cc in 0 until across) { if (vertical) taken[a * w + cc] = true else taken[cc * w + a] = true } } }
        fun isTaken(a: Int, c: Int) = if (vertical) taken[a * w + c] else taken[c * w + a]
        val result = ArrayList<FloatArray>()
        val seeds = floatArrayOf(0.2f, 0.35f, 0.5f, 0.65f, 0.8f)
        val maxGap = max(8, along / 80)
        for (seedShare in seeds) {
            val seed = (along * seedShare).toInt()
            for (c in 0 until across) {
                if (!on(seed, c) || isTaken(seed, c)) continue
                val positions = FloatArray(along) { Float.NaN }
                var hits = 0
                for (dir in intArrayOf(1, -1)) {
                    var cur = c
                    var gap = 0
                    var a = if (dir == 1) seed else seed - 1
                    while (a in 0 until along) {
                        val next = when {
                            on(a, cur) -> cur
                            on(a, cur - 1) -> cur - 1
                            on(a, cur + 1) -> cur + 1
                            else -> -1
                        }
                        if (next >= 0) {
                            cur = next
                            positions[a] = cur.toFloat()
                            hits++
                            gap = 0
                        } else {
                            gap++
                            if (gap > maxGap) break
                        }
                        a += dir
                    }
                }
                var first = -1
                var last = -1
                for (a in 0 until along) if (!positions[a].isNaN()) { if (first < 0) first = a; last = a }
                if (first < 0) continue
                val span = last - first + 1
                if (span < along * 0.2f || hits < span * 0.6f) continue
                // Marcar para no seguirla de nuevo; rellenar huecos y suavizar.
                for (a in first..last) if (!positions[a].isNaN()) take(a, positions[a].toInt())
                var lastValue = positions[first]
                for (a in first..last) if (positions[a].isNaN()) positions[a] = lastValue else lastValue = positions[a]
                val smooth = FloatArray(along) { Float.NaN }
                val r = 6
                for (a in first..last) {
                    var sum = 0f
                    var n = 0
                    for (b in max(first, a - r)..min(last, a + r)) { sum += positions[b]; n++ }
                    smooth[a] = sum / n
                }
                result += smooth
            }
        }
        return result
    }

    /**
     * Mapa de corrimiento (en una cuadrícula cada [step] px) que endereza las rayas: cada
     * raya queda en su posición promedio. Entre rayas se reparte en línea; afuera, igual
     * que la raya más cercana. null si no hay rayas.
     */
    private fun field(lines: List<FloatArray>, gw: Int, gh: Int, step: Int, w: Int, h: Int, vertical: Boolean): FloatArray? {
        if (lines.isEmpty()) return null
        val targets = lines.map { line ->
            var sum = 0.0
            var n = 0
            for (v in line) if (!v.isNaN()) { sum += v; n++ }
            (sum / max(1, n)).toFloat()
        }
        // Para cada punto de la cuadrícula a lo largo: (posición de costado, corrimiento) de las rayas que pasan.
        val alongCount = if (vertical) gh else gw
        val acrossCount = if (vertical) gw else gh
        val grid = FloatArray(gw * gh)
        val known = BooleanArray(alongCount)
        val values = Array(alongCount) { FloatArray(acrossCount) }
        for (ga in 0 until alongCount) {
            val a = (ga * step).coerceAtMost((if (vertical) h else w) - 1)
            val points = ArrayList<Pair<Float, Float>>()
            for ((index, line) in lines.withIndex()) {
                val c = line[a]
                if (c.isNaN()) continue
                points += c to (c - targets[index])
            }
            if (points.isEmpty()) continue
            points.sortBy { it.first }
            known[ga] = true
            for (gc in 0 until acrossCount) {
                val c = gc * step.toFloat()
                val value = when {
                    c <= points.first().first -> points.first().second
                    c >= points.last().first -> points.last().second
                    else -> {
                        var j = 1
                        while (points[j].first < c) j++
                        val (c0, d0) = points[j - 1]
                        val (c1, d1) = points[j]
                        val t = if (c1 - c0 < 1e-3f) 0f else (c - c0) / (c1 - c0)
                        d0 + (d1 - d0) * t
                    }
                }
                values[ga][gc] = value
            }
        }
        if (known.none { it }) return null
        // A lo largo, donde no pasa ninguna raya: igual que lo más cercano.
        for (ga in 0 until alongCount) {
            if (known[ga]) continue
            var best = -1
            for (d in 1 until alongCount) {
                if (ga - d >= 0 && known[ga - d]) { best = ga - d; break }
                if (ga + d < alongCount && known[ga + d]) { best = ga + d; break }
            }
            if (best >= 0) values[ga] = values[best].copyOf()
        }
        for (ga in 0 until alongCount) for (gc in 0 until acrossCount) {
            if (vertical) grid[ga * gw + gc] = values[ga][gc] else grid[gc * gw + ga] = values[ga][gc]
        }
        // Suave y con tope (un error no puede torcer la hoja).
        val limit = max(w, h) * 0.03f
        var current = grid
        repeat(3) {
            val next = FloatArray(current.size)
            for (y in 0 until gh) for (x in 0 until gw) {
                var sum = 0f
                var n = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val yy = y + dy
                    val xx = x + dx
                    if (yy in 0 until gh && xx in 0 until gw) { sum += current[yy * gw + xx]; n++ }
                }
                next[y * gw + x] = (sum / n).coerceIn(-limit, limit)
            }
            current = next
        }
        return current
    }

    // ------------------------------------------------------------------ luz

    /**
     * Papel blanco parejo: en cuadritos se mide el color del papel (lo claro y gris) por
     * canal, se suaviza y cada punto se divide por él. Quita la sombra y el tono de la
     * luz (azul, amarillo) sin lavar los colores de las celdas.
     */
    fun evenLight(pixels: IntArray, width: Int, height: Int) {
        if (width < 16 || height < 16) return
        val cell = (max(width, height) / 24).coerceIn(12, 120)
        val columns = (width + cell - 1) / cell
        val rows = (height + cell - 1) / cell
        val grid = Array(3) { FloatArray(columns * rows) }
        val known = BooleanArray(columns * rows)
        val lums = IntArray(cell * cell)
        for (row in 0 until rows) for (column in 0 until columns) {
            val y0 = row * cell
            val x0 = column * cell
            val y1 = min(height, y0 + cell)
            val x1 = min(width, x0 + cell)
            var n = 0
            var y = y0
            while (y < y1) {
                var x = x0
                while (x < x1) {
                    val c = pixels[y * width + x]
                    if ((c ushr 24) != 0 && sat(c) < 70) lums[n++] = (lum(c) shl 14) or ((y - y0) shl 7) or (x - x0) // brillo + lugar
                    x += 2
                }
                y += 2
            }
            if (n < 6) continue
            java.util.Arrays.sort(lums, 0, n)
            // El papel: entre el 55 % y el 85 % (lo típico del papel, no un brillo suelto).
            val from = (n * 0.55f).toInt()
            val to = max(from + 1, (n * 0.85f).toInt())
            var r = 0f
            var g = 0f
            var b = 0f
            for (k in from until to) {
                val code = lums[k]
                val yy = y0 + ((code shr 7) and 127)
                val xx = x0 + (code and 127)
                val c = pixels[yy * width + xx]
                r += (c shr 16) and 255
                g += (c shr 8) and 255
                b += c and 255
            }
            val count = (to - from).toFloat()
            val index = row * columns + column
            val level = (r + g + b) / (3 * count)
            if (level < 70f) continue
            grid[0][index] = r / count
            grid[1][index] = g / count
            grid[2][index] = b / count
            known[index] = true
        }
        if (known.none { it }) return
        // Cuadritos sin papel (una celda de color grande): toman de los vecinos.
        repeat(columns + rows) {
            var changed = false
            val next = known.copyOf()
            for (row in 0 until rows) for (column in 0 until columns) {
                val index = row * columns + column
                if (known[index]) continue
                var n = 0
                val sums = FloatArray(3)
                for (dy in -1..1) for (dx in -1..1) {
                    val rr = row + dy
                    val cc = column + dx
                    if (rr !in 0 until rows || cc !in 0 until columns) continue
                    val j = rr * columns + cc
                    if (!known[j]) continue
                    for (ch in 0 until 3) sums[ch] += grid[ch][j]
                    n++
                }
                if (n > 0) {
                    for (ch in 0 until 3) grid[ch][index] = sums[ch] / n
                    next[index] = true
                    changed = true
                }
            }
            System.arraycopy(next, 0, known, 0, known.size)
            if (!changed) return@repeat
        }
        // Un poco más claro de lo medido (el papel puede ser más claro que la mezcla) y suave.
        val smooth = Array(3) { ch -> blurGrid(grid[ch], columns, rows) }
        for (y in 0 until height) {
            val gy = ((y + 0.5f) / cell - 0.5f).coerceIn(0f, (rows - 1).toFloat())
            val ry = gy.toInt()
            val ty = gy - ry
            val ry2 = min(rows - 1, ry + 1)
            for (x in 0 until width) {
                val gx = ((x + 0.5f) / cell - 0.5f).coerceIn(0f, (columns - 1).toFloat())
                val rx = gx.toInt()
                val tx = gx - rx
                val rx2 = min(columns - 1, rx + 1)
                val c = pixels[y * width + x]
                if ((c ushr 24) == 0) continue
                var out = 0xFF shl 24
                for (ch in 0 until 3) {
                    val g = smooth[ch]
                    val top = g[ry * columns + rx] * (1 - tx) + g[ry * columns + rx2] * tx
                    val bottom = g[ry2 * columns + rx] * (1 - tx) + g[ry2 * columns + rx2] * tx
                    val paper = (top * (1 - ty) + bottom * ty).coerceAtLeast(60f)
                    val shift = 16 - ch * 8
                    val value = ((c shr shift) and 255) * (250f / paper)
                    out = out or (value.roundToInt().coerceIn(0, 255) shl shift)
                }
                pixels[y * width + x] = out
            }
        }
    }

    private fun blurGrid(grid: FloatArray, columns: Int, rows: Int): FloatArray {
        var current = grid
        repeat(2) {
            val next = FloatArray(current.size)
            for (row in 0 until rows) for (column in 0 until columns) {
                var sum = 0f
                var weight = 0f
                for (dy in -1..1) for (dx in -1..1) {
                    val r = row + dy
                    val c = column + dx
                    if (r !in 0 until rows || c !in 0 until columns) continue
                    val w = if (dx == 0 && dy == 0) 2f else 1f
                    sum += current[r * columns + c] * w
                    weight += w
                }
                next[row * columns + column] = sum / weight
            }
            current = next
        }
        return current
    }

    // ------------------------------------------------------------------ todo junto

    /** El cuadro ocupa casi toda la imagen (≥ 90 %): es la misma hoja, no un papel sobre la mesa. */
    private fun covers(q: FloatArray, width: Int, height: Int): Boolean {
        var area = 0f
        for (k in 0 until 4) {
            val j = (k + 1) % 4
            area += q[k * 2] * q[j * 2 + 1] - q[j * 2] * q[k * 2 + 1]
        }
        return abs(area) / 2f >= width.toFloat() * height * 0.9f
    }

    /** Cuánto se inclina (grados) el lado más chueco de [q] respecto a lo derecho. */
    internal fun sideTilt(q: FloatArray): Float {
        var worst = 0f
        for (k in 0 until 4) {
            val dx = q[(k + 1) % 4 * 2] - q[k * 2]
            val dy = q[(k + 1) % 4 * 2 + 1] - q[k * 2 + 1]
            val angle = if (k % 2 == 0) kotlin.math.atan2(dy, dx) else kotlin.math.atan2(-dx, dy)
            val a = abs(Math.toDegrees(angle.toDouble()).toFloat())
            worst = max(worst, min(a, abs(180f - a)))
        }
        return worst
    }

    /** ¿Es una imagen ya limpia? Más del 10 % de blanco puro (una foto de papel casi nunca lo tiene). */
    fun isClean(pixels: IntArray): Boolean {
        var white = 0
        for (c in pixels) {
            if (((c shr 16) and 255) >= 246 && ((c shr 8) and 255) >= 246 && (c and 255) >= 246) white++
        }
        return white > pixels.size * 0.10f
    }

    /** Copia con el lado mayor ≤ [maxSide] (o la misma si ya cabe). */
    private fun fitSide(pixels: IntArray, width: Int, height: Int, maxSide: Int): Triple<IntArray, Int, Int> {
        val edge = max(width, height)
        if (edge <= maxSide) return Triple(pixels.copyOf(width * height), width, height)
        val s = maxSide / edge.toFloat()
        val w = max(8, (width * s).roundToInt())
        val h = max(8, (height * s).roundToInt())
        return Triple(warp(pixels, width, height, floatArrayOf(0f, 0f, width.toFloat(), 0f, width.toFloat(), height.toFloat(), 0f, height.toFloat()), w, h), w, h)
    }

    /**
     * Inclinación (grados) de la hoja según sus rayas finas: promedio de las que van de
     * lado y de las que bajan (deben estar de acuerdo). null si no hay rayas para medir.
     */
    fun skew(pixels: IntArray, width: Int, height: Int): Float? {
        if (width < 64 || height < 64) return null
        val (small, sw, _) = shrink(pixels, width, height, 900)
        val sh = small.size / sw
        val (alongX, alongY) = thinLines(small, sw, sh)
        val horizontal = consistent(houghLines(alongX, sw, sh, vertical = false, share = 0.25f))
        val vertical = consistent(houghLines(alongY, sw, sh, vertical = true, share = 0.25f))
        fun middle(lines: List<FloatArray>): Float? {
            if (lines.isEmpty()) return null
            val sorted = lines.sortedBy { it[0] }
            val total = sorted.sumOf { it[2].toDouble() }
            var run = 0.0
            for (l in sorted) {
                run += l[2]
                if (run >= total / 2) return Math.toDegrees(l[0].toDouble()).toFloat()
            }
            return Math.toDegrees(sorted.last()[0].toDouble()).toFloat()
        }
        val h = middle(horizontal)
        val v = middle(vertical)
        if (System.getProperty("scan.debug") != null) println("skew h=$h (${horizontal.size}) v=$v (${vertical.size})")
        return when {
            h != null && v != null -> if (abs(h - v) <= 0.75f) (h * horizontal.size + v * vertical.size) / (horizontal.size + vertical.size) else null
            h != null && horizontal.size >= 3 -> h
            v != null && vertical.size >= 3 -> v
            else -> null
        }
    }

    /**
     * Si la hoja ([pixels]) quedó un poco girada (sus rayas no van derechas), la gira lo
     * justo. null si ya estaba derecha o no hay rayas para medir.
     */
    fun straighten(pixels: IntArray, width: Int, height: Int): Triple<IntArray, Int, Int>? {
        val angle = skew(pixels, width, height) ?: return null
        if (abs(angle) < 0.3f || abs(angle) > 10f) return null
        val r = Math.toRadians(angle.toDouble())
        val c = cos(r).toFloat()
        val sn = sin(r).toFloat()
        val outW = (width * abs(c) + height * abs(sn)).roundToInt().coerceAtLeast(8)
        val outH = (width * abs(sn) + height * abs(c)).roundToInt().coerceAtLeast(8)
        val corners = floatArrayOf(0f, 0f, outW.toFloat(), 0f, outW.toFloat(), outH.toFloat(), 0f, outH.toFloat())
        val points = FloatArray(8)
        for (k in 0 until 4) {
            val x = corners[k * 2] - outW / 2f
            val y = corners[k * 2 + 1] - outH / 2f
            points[k * 2] = width / 2f + x * c - y * sn
            points[k * 2 + 1] = height / 2f + x * sn + y * c
        }
        return Triple(warp(pixels, width, height, points, outW, outH), outW, outH)
    }

    /** Resultado: hoja derecha y pareja ([pixels] de [width]×[height]); [method] cómo se halló. */
    class Result(val pixels: IntArray, val width: Int, val height: Int, val quad: Quad?, val method: String, val plain: IntArray? = null)

    /**
     * Foto del celular → hoja derecha, recortada al papel y con la luz pareja.
     * [maxSide]: lado mayor de la hoja final. Si no se halla la hoja, solo se empareja la luz.
     */
    fun flatten(pixels: IntArray, width: Int, height: Int, maxSide: Int = 2400, light: Boolean = true): Result {
        val found = detect(pixels, width, height)
        if (found.clean) return Result(pixels.copyOf(width * height), width, height, null, "ya limpia")
        return flattenWith(pixels, width, height, found.quad, found.method, maxSide, light)
    }

    /** Lo que se halló en la foto: esquinas del papel (en píxeles de la foto) o nada. */
    class Found(val quad: Quad?, val method: String, val clean: Boolean)

    /**
     * Solo busca la hoja (rápido: trabaja en una copia chica). Sirve para mostrar las
     * esquinas en la pantalla de recorte antes de enderezar.
     */
    fun detect(pixels: IntArray, width: Int, height: Int): Found {
        val (small, w, scale) = shrink(pixels, width, height, 640)
        val h = small.size / w
        // Imagen ya limpia (hecha en la compu, captura, escaneo): mucho blanco puro.
        // No se toca (enderezar o emparejar la luz solo la estropearía). Pero una foto
        // con mucha luz también tiene blanco puro: si se ve el papel sobre otra cosa o
        // sus rayas están chuecas, es foto.
        val clean = isClean(small)
        val paper = findPaper(small, w, h)
        if (paper != null && !(clean && covers(paper.points, w, h))) {
            return Found(Quad(FloatArray(8) { paper.points[it] / scale }, "papel"), "papel", false)
        }
        // La hoja llena la foto: con las rayas de las tablas. Se prueba en dos tamaños
        // (las rayas finas se ven mejor en el más grande).
        for (side in intArrayOf(900, 1300)) {
            val (lines, lw, lscale) = shrink(pixels, width, height, side)
            val lh = lines.size / lw
            val byLines = findByLines(lines, lw, lh) ?: continue
            if (clean && sideTilt(byLines.points) < 0.6f) break
            val grown = expandQuad(byLines, lw, lh)
            return Found(Quad(FloatArray(8) { grown.points[it] / lscale }, "rayas"), "rayas", false)
        }
        // Limpia pero girada (escaneo o foto con mucha luz): se endereza sin recortar.
        if (clean && abs(skew(pixels, width, height) ?: 0f) < 0.6f) return Found(null, "ya limpia", true)
        return Found(null, "sin cambio", false)
    }

    /**
     * Endereza con esas esquinas ([quad] en píxeles de la foto). [method] "rayas" recorta
     * además lo de afuera del papel; "manual" (esquinas puestas por la persona) respeta
     * el recorte tal cual. Sin [quad]: solo empareja la luz.
     */
    fun flattenWith(
        pixels: IntArray, width: Int, height: Int, quad: Quad?, method: String,
        maxSide: Int = 2400, light: Boolean = true, keepPlain: Boolean = false
    ): Result {
        var out: IntArray
        var outW: Int
        var outH: Int
        var how = method
        if (quad == null) {
            // Sin esquinas: igual se intenta enderezar con las rayas de la hoja.
            val fitted = fitSide(pixels, width, height, maxSide)
            val straight = straighten(fitted.first, fitted.second, fitted.third)
            if (straight == null) {
                val copy = fitted.first
                val plain = if (keepPlain) copy.copyOf() else null
                if (light) evenLight(copy, fitted.second, fitted.third)
                return Result(copy, fitted.second, fitted.third, null, "sin cambio", plain)
            }
            out = straight.first
            outW = straight.second
            outH = straight.third
            how = "rayas"
        } else {
            val size = quad.size()
            val fit = min(1f, maxSide / max(size.first, size.second).toFloat())
            outW = max(8, (size.first * fit).roundToInt())
            outH = max(8, (size.second * fit).roundToInt())
            out = warp(pixels, width, height, quad.points, outW, outH)
            // Revisión: si las rayas de la hoja siguen giradas (esquinas puestas a mano o
            // halladas con las rayas), se gira lo justo. Con los bordes del papel no hace
            // falta: el papel ya manda.
            if (how != "papel") straighten(out, outW, outH)?.let {
                out = it.first
                outW = it.second
                outH = it.third
            }
        }
        if (how == "rayas") {
            // Lo de afuera del papel (pared, mesa) se recorta, sin cortar nada escrito.
            val paper = paperBounds(out, outW, outH)
            val written = contentBounds(out, outW, outH)
            val b = intArrayOf(min(paper[0], written[0]), min(paper[1], written[1]), max(paper[2], written[2]), max(paper[3], written[3]))
            if (System.getProperty("scan.debug") != null) println("papel=${paper.joinToString()} escrito=${written.joinToString()}")
            if (b[2] - b[0] < outW || b[3] - b[1] < outH) {
                val cw = b[2] - b[0]
                val ch = b[3] - b[1]
                val cropped = IntArray(cw * ch)
                for (y in 0 until ch) System.arraycopy(out, (b[1] + y) * outW + b[0], cropped, y * cw, cw)
                out = cropped
                outW = cw
                outH = ch
            }
        }
        // Hoja doblada o apenas chueca: rayas rectas.
        dewarp(out, outW, outH)?.let { out = it }
        // Pared, mesa o dedo que se ven en el borde: blanco (no son parte de la hoja).
        if (how != "manual") clearOutside(out, outW, outH)
        // Copia sin emparejar la luz (filtro Original), sin enderezar dos veces.
        val plain = if (keepPlain) out.copyOf() else null
        if (light) {
            evenLight(out, outW, outH)
            // Con la luz pareja: el borde sombreado del papel, chinches y otras hojas que
            // entran por el borde también quedan blancos (la hoja nueva es blanca).
            if (how != "manual") clearOutside(out, outW, outH, minLum = 205, maxSat = 45)
        }
        // Lo que quedó fuera de la foto: papel blanco.
        for (i in out.indices) if ((out[i] ushr 24) == 0) out[i] = -1
        if (plain != null) for (i in plain.indices) if ((plain[i] ushr 24) == 0) plain[i] = -1
        return Result(out, outW, outH, quad, how, plain)
    }
}
