package com.ganageo.app.tools

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Tutorial del papelote (PDF aparte): portada con el papelote armado, un paso por
 * página (qué hoja llega, dónde va el pegamento y hacia dónde se mueve, con flecha) y
 * una página final. Aquí solo se arma la lista de cosas a dibujar (sin Android), así
 * se puede probar y dibujar igual en la app y en pruebas.
 * Medidas en puntos de PDF. Hoja del tutorial: A4 parada.
 */
object PosterTutorial {
    const val PAGE_W = 595.28f
    const val PAGE_H = 841.89f
    private const val M = 40f

    // Colores para papel (se ven bien impresos y en el celular).
    const val INK = 0xFF1B1F1D.toInt()
    const val MUTED = 0xFF5F6B65.toInt()
    const val GREEN = 0xFF12A150.toInt()
    const val DARK_GREEN = 0xFF0B5D33.toInt()
    const val RED = 0xFFE0283A.toInt()
    const val BLUE = 0xFF1E7BE0.toInt()
    const val GLUE = 0xFFFFD54F.toInt()
    const val GLUE_EDGE = 0xFFF2A900.toInt()
    const val PANEL = 0xFFF2F5F3.toInt()
    const val LINE = 0xFFC9D1CC.toInt()
    const val WHITE = -1
    const val SHADOW = 0x33000000

    /** Lo que se dibuja. */
    sealed class Op
    /** Rectángulo (relleno y/o borde), con esquinas redondas y borde a rayas si [dash]. */
    class Box(
        val l: Float, val t: Float, val r: Float, val b: Float,
        val fill: Int? = null, val stroke: Int? = null, val width: Float = 1f,
        val radius: Float = 0f, val dash: Boolean = false
    ) : Op()
    class Line(val x0: Float, val y0: Float, val x1: Float, val y1: Float, val color: Int, val width: Float, val dash: Boolean = false) : Op()
    /** Texto en una línea. [align]: 0 izquierda, 1 centro, 2 derecha. [y] = línea base. */
    class Text(val text: String, val x: Float, val y: Float, val size: Float, val color: Int, val bold: Boolean = false, val align: Int = 0) : Op()
    /** Pedazo [src] (px de la imagen: izq, arriba, der, abajo) dibujado en el rectángulo. */
    class Picture(val src: FloatArray, val l: Float, val t: Float, val r: Float, val b: Float) : Op()
    class Dot(val x: Float, val y: Float, val radius: Float, val fill: Int, val stroke: Int? = null, val width: Float = 1f) : Op()
    /** Polígono relleno (puntas de flecha). */
    class Poly(val points: FloatArray, val fill: Int) : Op()
    /** Rayitas en diagonal dentro del rectángulo. */
    class Hatch(val l: Float, val t: Float, val r: Float, val b: Float, val color: Int, val step: Float) : Op()

    /** Mide el ancho de un texto (lo da quien dibuja, con su letra). */
    fun interface Measure {
        fun width(text: String, size: Float, bold: Boolean): Float
    }

    // ----------------------------------------------------------------- hojas

    /** Hoja entera (con su franja y borde) en el papelote armado (pt). */
    fun sheetRect(options: PosterTiles.Options, tile: PosterTiles.Tile): FloatArray = floatArrayOf(
        tile.left - options.leftOf(tile.col),
        tile.top - options.topOf(tile.row),
        tile.left + tile.width + options.border,
        tile.top + tile.height + options.border
    )

    /**
     * Franjas para pegar de una hoja, en el papelote armado: (izq, arriba, der, abajo,
     * 0 = la de la izquierda / 1 = la de arriba).
     */
    fun tabs(options: PosterTiles.Options, tile: PosterTiles.Tile): List<FloatArray> {
        val glue = options.glue
        if (glue <= 0f) return emptyList()
        val s = sheetRect(options, tile)
        val out = ArrayList<FloatArray>()
        if (tile.col > 0) out += floatArrayOf(s[0], s[1], s[0] + glue, s[3], 0f)
        if (tile.row > 0) out += floatArrayOf(s[0], s[1], s[2], s[1] + glue, 1f)
        return out
    }

    /** Transformación papelote → página: x = ox + px·k. */
    private class Fit(val k: Float, val ox: Float, val oy: Float) {
        fun x(v: Float) = ox + v * k
        fun y(v: Float) = oy + v * k
    }

    private fun fit(bounds: FloatArray, l: Float, t: Float, r: Float, b: Float): Fit {
        val w = (bounds[2] - bounds[0]).coerceAtLeast(1f)
        val h = (bounds[3] - bounds[1]).coerceAtLeast(1f)
        val k = min((r - l) / w, (b - t) / h)
        val ox = l + ((r - l) - w * k) / 2f - bounds[0] * k
        val oy = t + ((b - t) - h * k) / 2f - bounds[1] * k
        return Fit(k, ox, oy)
    }

    /**
     * Dibuja una hoja (papel, su pedazo de imagen, franjas y número), corrida [dx], [dy]
     * (pt del papelote). [glueSide] = franja en amarillo (aquí va el pegamento): 0 la de
     * la izquierda, 1 la de arriba, -1 ninguna.
     */
    private fun sheet(
        ops: MutableList<Op>, options: PosterTiles.Options, tile: PosterTiles.Tile, f: Fit,
        dx: Float, dy: Float, glueSide: Int, badge: Int
    ) {
        val s = sheetRect(options, tile)
        val l = f.x(s[0] + dx); val t = f.y(s[1] + dy); val r = f.x(s[2] + dx); val b = f.y(s[3] + dy)
        ops += Box(l + 1.5f, t + 2.5f, r + 1.5f, b + 2.5f, fill = SHADOW)
        ops += Box(l, t, r, b, fill = WHITE, stroke = LINE, width = 0.6f)
        val source = tile.source
        val target = tile.target
        if (source != null && target != null) {
            ops += Picture(
                source,
                f.x(tile.left + target[0] + dx), f.y(tile.top + target[1] + dy),
                f.x(tile.left + target[2] + dx), f.y(tile.top + target[3] + dy)
            )
        }
        for (tab in tabs(options, tile)) {
            val tl = f.x(tab[0] + dx); val tt = f.y(tab[1] + dy); val tr = f.x(tab[2] + dx); val tb = f.y(tab[3] + dy)
            if (tab[4].toInt() == glueSide) {
                ops += Box(tl, tt, tr, tb, fill = GLUE, stroke = GLUE_EDGE, width = 0.8f)
            } else {
                ops += Box(tl, tt, tr, tb, fill = WHITE)
                ops += Hatch(tl, tt, tr, tb, 0xFFEBC8CD.toInt(), 4f)
            }
        }
        // Número de la hoja en el centro de su imagen.
        val cx = f.x(tile.left + tile.width / 2f + dx)
        val cy = f.y(tile.top + tile.height / 2f + dy)
        val radius = (min(r - l, b - t) * 0.16f).coerceIn(7f, 15f)
        ops += Dot(cx, cy, radius + 1.2f, WHITE)
        ops += Dot(cx, cy, radius, badge)
        ops += Text("${tile.number}", cx, cy + radius * 0.38f, radius * 1.05f, WHITE, bold = true, align = 1)
    }

    /** Flecha gruesa de [x0],[y0] a [x1],[y1] (con borde blanco para que se vea encima de todo). */
    private fun arrow(ops: MutableList<Op>, x0: Float, y0: Float, x1: Float, y1: Float, width: Float) {
        val len = hypot(x1 - x0, y1 - y0).coerceAtLeast(1f)
        val ux = (x1 - x0) / len
        val uy = (y1 - y0) / len
        val head = width * 2.6f
        val bx = x1 - ux * head
        val by = y1 - uy * head
        fun headPoints(grow: Float) = floatArrayOf(
            x1 + ux * grow, y1 + uy * grow,
            bx - uy * (head * 0.75f + grow), by + ux * (head * 0.75f + grow),
            bx + uy * (head * 0.75f + grow), by - ux * (head * 0.75f + grow)
        )
        ops += Line(x0, y0, bx, by, WHITE, width + 4f)
        ops += Poly(headPoints(2.2f), WHITE)
        ops += Line(x0, y0, bx, by, BLUE, width)
        ops += Poly(headPoints(0f), BLUE)
    }

    /** Parte un texto en renglones de ancho ≤ [width]. */
    fun wrap(text: String, size: Float, bold: Boolean, width: Float, measure: Measure): List<String> {
        val lines = ArrayList<String>()
        var current = ""
        for (word in text.split(' ')) {
            if (word.isEmpty()) continue
            val tryLine = if (current.isEmpty()) word else "$current $word"
            if (current.isNotEmpty() && measure.width(tryLine, size, bold) > width) {
                lines += current
                current = word
            } else {
                current = tryLine
            }
        }
        if (current.isNotEmpty()) lines += current
        return lines
    }

    /** Pasos numerados (círculo con número y texto partido en renglones). Devuelve dónde terminó. */
    private fun numbered(ops: MutableList<Op>, items: List<String>, top: Float, measure: Measure, size: Float = 13f): Float {
        var y = top
        items.forEachIndexed { index, item ->
            val lines = wrap(item, size, false, PAGE_W - M * 2 - 34f, measure)
            ops += Dot(M + 11f, y - size * 0.35f, 11f, GREEN)
            ops += Text("${index + 1}", M + 11f, y + 0.5f, 12f, WHITE, bold = true, align = 1)
            for (line in lines) {
                ops += Text(line, M + 34f, y, size, INK)
                y += size * 1.45f
            }
            y += size * 0.75f
        }
        return y
    }

    /** El papelote armado (vista de la guía) dentro del rectángulo dado. */
    private fun finished(
        ops: MutableList<Op>, imageWidth: Int, imageHeight: Int, options: PosterTiles.Options,
        tiles: List<PosterTiles.Tile>, l: Float, t: Float, r: Float, b: Float, numbers: Boolean
    ) {
        val f = fit(floatArrayOf(0f, 0f, options.posterWidth, options.posterHeight), l, t, r, b)
        ops += Box(f.x(0f) + 2f, f.y(0f) + 3f, f.x(options.posterWidth) + 2f, f.y(options.posterHeight) + 3f, fill = SHADOW)
        ops += Box(f.x(0f), f.y(0f), f.x(options.posterWidth), f.y(options.posterHeight), fill = WHITE)
        for (tile in tiles) {
            val source = tile.source ?: continue
            val target = tile.target ?: continue
            ops += Picture(
                source,
                f.x(tile.left + target[0]), f.y(tile.top + target[1]),
                f.x(tile.left + target[2]), f.y(tile.top + target[3])
            )
        }
        if (!numbers) return
        for (tile in tiles) {
            ops += Box(f.x(tile.left), f.y(tile.top), f.x(tile.left + tile.width), f.y(tile.top + tile.height), stroke = RED, width = 1f)
            val cx = f.x(tile.left + tile.width / 2f)
            val cy = f.y(tile.top + tile.height / 2f)
            val radius = (min(tile.width, tile.height) * f.k * 0.12f).coerceIn(8f, 15f)
            ops += Dot(cx, cy, radius + 1.2f, WHITE)
            ops += Dot(cx, cy, radius, RED)
            ops += Text("${tile.number}", cx, cy + radius * 0.38f, radius * 1.05f, WHITE, bold = true, align = 1)
        }
    }

    private fun header(ops: MutableList<Op>, chip: String, title: String, measure: Measure) {
        ops += Box(0f, 0f, PAGE_W, 6f, fill = GREEN)
        val chipW = measure.width(chip, 10f, true) + 20f
        ops += Box(M, 26f, M + chipW, 46f, fill = DARK_GREEN, radius = 10f)
        ops += Text(chip, M + chipW / 2f, 39.5f, 10f, WHITE, bold = true, align = 1)
        ops += Text("Tutorial del papelote", PAGE_W - M, 40f, 10f, MUTED, align = 2)
        ops += Text(title, M, 84f, 22f, INK, bold = true)
    }

    private fun footer(ops: MutableList<Op>, page: Int, pages: Int) {
        ops += Line(M, PAGE_H - 46f, PAGE_W - M, PAGE_H - 46f, LINE, 0.6f)
        ops += Text("Imprime las hojas al 100 % (tamaño real), sin \"Ajustar a la página\".", M, PAGE_H - 30f, 9f, MUTED)
        ops += Text("$page / $pages", PAGE_W - M, PAGE_H - 30f, 9f, MUTED, align = 2)
    }

    /** Todas las páginas del tutorial. */
    fun pages(imageWidth: Int, imageHeight: Int, options: PosterTiles.Options, measure: Measure): List<List<Op>> {
        val tiles = PosterTiles.tiles(imageWidth, imageHeight, options)
        val byNumber = tiles.associateBy { it.number }
        val steps = PosterTiles.steps(options.rows, options.cols)
        val total = steps.size + 2
        val glue = options.glue > 0f
        val (cmW, cmH) = PosterTiles.sizeCm(options)
        val out = ArrayList<List<Op>>()

        // Portada.
        run {
            val ops = ArrayList<Op>()
            header(ops, "ANTES DE EMPEZAR", "Cómo armar tu papelote", measure)
            ops += Text(
                "${tiles.size} hojas ${options.paper.name} · armado mide ${"%.0f".format(cmW)} × ${"%.0f".format(cmH)} cm · ${steps.size} pasos",
                M, 106f, 12f, MUTED
            )
            ops += Box(M, 122f, PAGE_W - M, 470f, fill = PANEL, radius = 16f)
            finished(ops, imageWidth, imageHeight, options, tiles, M + 24f, 140f, PAGE_W - M - 24f, 452f, numbers = true)
            ops += Text("Necesitas", M, 510f, 15f, INK, bold = true)
            var y = numbered(
                ops,
                listOf(
                    "Las ${tiles.size} hojas impresas al 100 % (tamaño real).",
                    if (glue) "Pegamento en barra (o cinta doble contacto)." else "Cinta para pegar por detrás.",
                    "Una mesa limpia y plana."
                ),
                540f, measure
            )
            y += 6f
            ops += Text("Cómo funciona", M, y, 15f, INK, bold = true)
            y += 24f
            val how = if (glue) {
                "Las hojas de la derecha y de abajo tienen una franja blanca rayada. Ahí va el pegamento, " +
                    "y la hoja de al lado se pone encima, juntando la imagen con la línea roja. " +
                    "Primero se arma cada fila y después se juntan las filas."
            } else {
                "Las hojas se juntan borde con borde y se pegan por detrás con cinta. " +
                    "Primero se arma cada fila y después se juntan las filas."
            }
            for (line in wrap(how, 12f, false, PAGE_W - M * 2, measure)) {
                ops += Text(line, M, y, 12f, INK)
                y += 17f
            }
            footer(ops, 1, total)
            out += ops
        }

        // Un paso por página.
        steps.forEachIndexed { index, step ->
            val ops = ArrayList<Op>()
            val incoming = step.incoming.mapNotNull { byNumber[it] }
            val placed = step.placed.mapNotNull { byNumber[it] }
            val single = step.incoming.size == 1
            val title = if (single) "Une la hoja ${step.incoming.first()}" else {
                val row = (step.incoming.first() - 1) / options.cols + 1
                "Une la fila $row (hojas ${step.incoming.first()} a ${step.incoming.last()})"
            }
            header(ops, "PASO ${index + 1} DE ${steps.size}", title, measure)
            // Corrimiento de lo que llega: a la derecha o abajo.
            val dx = if (step.fromRight) options.sheetWidth * 0.5f else 0f
            val dy = if (step.fromRight) 0f else options.sheetHeight * 0.55f
            val rects = placed.map { sheetRect(options, it) } + incoming.map { sheetRect(options, it).let { s -> floatArrayOf(s[0] + dx, s[1] + dy, s[2] + dx, s[3] + dy) } }
            val bounds = floatArrayOf(rects.minOf { it[0] }, rects.minOf { it[1] }, rects.maxOf { it[2] }, rects.maxOf { it[3] })
            val boxTop = 104f
            val boxBottom = 540f
            ops += Box(M, boxTop, PAGE_W - M, boxBottom, fill = PANEL, radius = 16f)
            val f = fit(bounds, M + 28f, boxTop + 26f, PAGE_W - M - 28f, boxBottom - 52f)
            // Lo que llega (corrido), con su franja en amarillo.
            // (Una fila que llega ya viene armada: sus franjas de adentro quedan tapadas.)
            val side = if (step.fromRight) 0 else 1
            for (tile in incoming.sortedByDescending { it.number }) sheet(ops, options, tile, f, dx, dy, glueSide = side, badge = GREEN)
            // Lo ya armado: la de número menor queda encima (tapa la franja de la siguiente).
            for (tile in placed.sortedByDescending { it.number }) sheet(ops, options, tile, f, 0f, 0f, glueSide = -1, badge = 0xFF37474F.toInt())
            // Dónde va (contorno a rayas) y hacia dónde se mueve (flecha).
            // Un solo contorno alrededor de todo lo que llega (una hoja o una fila).
            incoming.map { sheetRect(options, it) }.let { list ->
                ops += Box(
                    f.x(list.minOf { it[0] }), f.y(list.minOf { it[1] }), f.x(list.maxOf { it[2] }), f.y(list.maxOf { it[3] }),
                    stroke = GREEN, width = 1.8f, dash = true
                )
            }
            val gx = incoming.map { sheetRect(options, it) }.let { list -> (list.minOf { it[0] } + list.maxOf { it[2] }) / 2f }
            val gy = incoming.map { sheetRect(options, it) }.let { list -> (list.minOf { it[1] } + list.maxOf { it[3] }) / 2f }
            val from = if (step.fromRight) floatArrayOf(gx + dx, gy - options.sheetHeight * 0.22f) else floatArrayOf(gx + options.sheetWidth * 0.3f, gy + dy)
            val to = if (step.fromRight) floatArrayOf(gx + dx * 0.18f, gy - options.sheetHeight * 0.22f) else floatArrayOf(gx + options.sheetWidth * 0.3f, gy + dy * 0.18f)
            arrow(ops, f.x(from[0]), f.y(from[1]), f.x(to[0]), f.y(to[1]), 5f)
            // Leyenda.
            var lx = M + 22f
            val ly = boxBottom - 22f
            if (glue) {
                ops += Box(lx, ly - 9f, lx + 16f, ly + 3f, fill = GLUE, stroke = GLUE_EDGE, width = 0.8f, radius = 2f)
                ops += Text("Pegamento", lx + 22f, ly, 10f, INK)
                lx += 22f + measure.width("Pegamento", 10f, false) + 18f
            }
            ops += Box(lx, ly - 9f, lx + 16f, ly + 3f, stroke = GREEN, width = 1.4f, dash = true, radius = 2f)
            ops += Text("Aquí va", lx + 22f, ly, 10f, INK)
            lx += 22f + measure.width("Aquí va", 10f, false) + 18f
            ops += Line(lx, ly - 3f, lx + 12f, ly - 3f, BLUE, 3f)
            ops += Poly(floatArrayOf(lx + 18f, ly - 3f, lx + 11f, ly - 8f, lx + 11f, ly + 2f), BLUE)
            ops += Text("Muévela así", lx + 24f, ly, 10f, INK)
            // Qué hacer.
            val items = if (step.fromRight) {
                val n = step.incoming.first()
                val left = n - 1
                val withRest = if (step.placed.size > 1) " (ya unida a las anteriores)" else ""
                if (glue) listOf(
                    "Pon la hoja $n a la derecha de lo que ya armaste.",
                    "Pon pegamento en su franja de la izquierda (la amarilla, dice \"pega aquí la hoja $left\").",
                    "Pon encima la hoja $left$withRest, juntando la imagen con la línea roja, y presiona."
                ) else listOf(
                    "Pon la hoja $n a la derecha de lo que ya armaste.",
                    "Junta los bordes para que la imagen siga sin cortes.",
                    "Pega por detrás con cinta."
                )
            } else {
                val first = step.incoming.first()
                val last = step.incoming.last()
                val what = if (single) "la hoja $first" else "la fila armada ($first a $last)"
                if (glue) listOf(
                    "Pon $what debajo de lo que ya tienes.",
                    if (single) "Pon pegamento en su franja de arriba (la amarilla)." else "Pon pegamento en las franjas de arriba (las amarillas).",
                    "Pon encima la parte de arriba, juntando la imagen con ${if (single) "la línea roja" else "las líneas rojas"}, y presiona."
                ) else listOf(
                    "Pon $what debajo de lo que ya tienes.",
                    "Junta los bordes para que la imagen siga sin cortes.",
                    "Pega por detrás con cinta."
                )
            }
            numbered(ops, items, 580f, measure)
            footer(ops, index + 2, total)
            out += ops
        }

        // Final.
        run {
            val ops = ArrayList<Op>()
            header(ops, "LISTO", "¡Tu papelote está armado!", measure)
            ops += Box(M, 104f, PAGE_W - M, 520f, fill = PANEL, radius = 16f)
            finished(ops, imageWidth, imageHeight, options, tiles, M + 24f, 124f, PAGE_W - M - 24f, 500f, numbers = false)
            ops += Text("Para que quede mejor", M, 562f, 15f, INK, bold = true)
            numbered(
                ops,
                listOf(
                    "Deja secar unos minutos antes de levantarlo.",
                    "Pon cinta por detrás en las uniones para que no se despegue al colgarlo.",
                    if (options.border > 0f) "Si queda una rayita blanca en el borde, recórtala con tijera."
                    else "Si alguna unión no calza, despega con cuidado y vuelve a juntar con la línea roja."
                ),
                592f, measure
            )
            footer(ops, total, total)
            out += ops
        }
        return out
    }

    /** Lo que ocupa un dibujo (para pruebas): todo dentro de la página. */
    fun bounds(ops: List<Op>): FloatArray {
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        fun add(x: Float, y: Float) { l = min(l, x); t = min(t, y); r = max(r, x); b = max(b, y) }
        for (op in ops) when (op) {
            is Box -> { add(op.l, op.t); add(op.r, op.b) }
            is Line -> { add(op.x0, op.y0); add(op.x1, op.y1) }
            is Text -> add(op.x, op.y)
            is Picture -> { add(op.l, op.t); add(op.r, op.b) }
            is Dot -> { add(op.x - op.radius, op.y - op.radius); add(op.x + op.radius, op.y + op.radius) }
            is Poly -> for (i in op.points.indices step 2) add(op.points[i], op.points[i + 1])
            is Hatch -> { add(op.l, op.t); add(op.r, op.b) }
        }
        return floatArrayOf(l, t, r, b)
    }
}
