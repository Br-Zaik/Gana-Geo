package com.ganageo.app.tools

import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanPhotoTest {
    private val desk = 0xFF6E6E70.toInt()
    private val paper = 0xFFE6E8F0.toInt()
    private val ink = 0xFF202020.toInt()

    /** Hoja inclinada (cuadrilátero) sobre una mesa gris, con renglones de "letra". */
    private fun photo(width: Int, height: Int, quad: FloatArray): IntArray {
        val px = IntArray(width * height) { desk }
        fun inside(x: Float, y: Float): Boolean {
            var sign = 0
            for (k in 0 until 4) {
                val ax = quad[k * 2]; val ay = quad[k * 2 + 1]
                val bx = quad[(k + 1) % 4 * 2]; val by = quad[(k + 1) % 4 * 2 + 1]
                val cross = (bx - ax) * (y - ay) - (by - ay) * (x - ax)
                val s = if (cross >= 0) 1 else -1
                if (sign == 0) sign = s else if (s != sign) return false
            }
            return true
        }
        for (y in 0 until height) for (x in 0 until width) if (inside(x + 0.5f, y + 0.5f)) px[y * width + x] = paper
        // Renglones de "texto" adentro.
        for (row in 0 until 8) {
            val y = (quad[1] + 40 + row * 30).toInt()
            for (x in (quad[0] + 40).toInt() until (quad[2] - 60).toInt()) if ((x / 5) % 3 != 0 && px[y * width + x] == paper) {
                px[y * width + x] = ink
                px[(y + 1) * width + x] = ink
            }
        }
        return px
    }

    @Test
    fun hallaLasEsquinasDelPapel() {
        val quad = floatArrayOf(80f, 60f, 330f, 75f, 345f, 420f, 60f, 400f)
        val px = photo(420, 480, quad)
        val found = ScanPhoto.findPaper(px, 420, 480)
        assertNotNull(found)
        for (k in 0 until 8) assertTrue("esquina $k: ${found!!.points[k]} vs ${quad[k]}", abs(found.points[k] - quad[k]) < 6f)
    }

    @Test
    fun papelQueTocaElBordeNoSeTomaComoHoja() {
        val quad = floatArrayOf(-20f, -20f, 440f, -20f, 440f, 500f, -20f, 500f)
        val px = photo(420, 480, quad)
        assertNull(ScanPhoto.findPaper(px, 420, 480))
    }

    @Test
    fun enderezarDejaLaHojaDerecha() {
        val quad = floatArrayOf(80f, 60f, 330f, 75f, 345f, 420f, 60f, 400f)
        val px = photo(420, 480, quad)
        val result = ScanPhoto.flatten(px, 420, 480, maxSide = 600, light = false)
        assertEquals("papel", result.method)
        // Sin mesa en las esquinas: todo papel claro.
        for ((x, y) in listOf(3 to 3, result.width - 4 to 3, 3 to result.height - 4, result.width - 4 to result.height - 4)) {
            val c = result.pixels[y * result.width + x]
            assertTrue("esquina ($x,$y) = ${Integer.toHexString(c)}", ((c shr 8) and 255) > 180)
        }
        // Proporción de la hoja (≈ 270 × 345).
        val ratio = result.height / result.width.toFloat()
        assertTrue("proporción $ratio", ratio in 1.15f..1.45f)
    }

    @Test
    fun luzParejaYSinTonoAzul() {
        val w = 300; val h = 400
        // Papel azulado y con sombra hacia abajo.
        val px = IntArray(w * h) { i ->
            val y = i / w
            val shade = 1f - y / h.toFloat() * 0.25f
            (0xFF shl 24) or ((200 * shade).toInt() shl 16) or ((205 * shade).toInt() shl 8) or (235 * shade).toInt()
        }
        ScanPhoto.evenLight(px, w, h)
        for (y in listOf(20, 200, 380)) {
            val c = px[y * w + 150]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            assertTrue("fila $y: $r,$g,$b", r > 238 && g > 238 && b > 238 && b - r < 8)
        }
    }

    @Test
    fun matrizDeEnderezarLlevaLasEsquinas() {
        val quad = floatArrayOf(10f, 20f, 210f, 5f, 230f, 300f, 0f, 280f)
        val m = ScanPhoto.homography(quad, 100f, 150f)!!
        fun map(x: Double, y: Double): Pair<Double, Double> {
            val d = m[6] * x + m[7] * y + m[8]
            return (m[0] * x + m[1] * y + m[2]) / d to (m[3] * x + m[4] * y + m[5]) / d
        }
        val (x2, y2) = map(100.0, 150.0)
        assertEquals(230.0, x2, 0.01)
        assertEquals(300.0, y2, 0.01)
    }

    @Test
    fun hojaDobladaQuedaConRayasRectas() {
        val w = 500; val h = 400
        val px = IntArray(w * h) { -1 }
        // Rayas de tabla que se curvan (hoja doblada): bajan 6 px en el medio.
        for (row in 0 until 6) {
            val base = 60 + row * 50
            for (x in 20 until 480) {
                val bend = (6 * kotlin.math.sin(Math.PI * (x - 20) / 460)).toInt()
                px[(base + bend) * w + x] = ink
                px[(base + bend + 1) * w + x] = ink
            }
        }
        val out = ScanPhoto.dewarp(px, w, h)
        assertNotNull(out)
        // La raya del medio: en el centro ya no está 6 px más abajo que en la punta.
        fun rowOf(x: Int, near: Int): Int = (near - 10..near + 10).minByOrNull { y -> (out!![y * w + x] shr 8) and 255 }!!
        val left = rowOf(40, 160)
        val center = rowOf(250, 163)
        assertTrue("izq $left centro $center", abs(center - left) <= 2)
    }

    @Test
    fun imagenYaLimpiaNoSeToca() {
        // Hoja hecha en la compu: fondo blanco puro.
        val w = 200; val h = 260
        val px = IntArray(w * h) { -1 }
        for (y in 40 until 60) for (x in 20 until 180) px[y * w + x] = ink
        val result = ScanPhoto.flatten(px, w, h)
        assertEquals("ya limpia", result.method)
        assertTrue(result.pixels.contentEquals(px))
    }

    /** Hoja blanca con una tabla de rayas finas, girada [degrees] grados. */
    private fun table(width: Int, height: Int, degrees: Double): IntArray {
        val px = IntArray(width * height) { -1 }
        val r = Math.toRadians(degrees)
        val c = kotlin.math.cos(r); val s = kotlin.math.sin(r)
        val cx = width / 2.0; val cy = height / 2.0
        for (y in 0 until height) for (x in 0 until width) {
            // Punto en la hoja derecha (se gira al revés).
            val u = (x - cx) * c + (y - cy) * s + cx
            val v = -(x - cx) * s + (y - cy) * c + cy
            val inTable = u in 40.0..(width - 40.0) && v in 50.0..(height - 50.0)
            val onRow = ((v - 50.0) % 40.0).let { it in 0.0..1.6 } || kotlin.math.abs(v - (height - 50.0)) < 1.6
            val onCol = ((u - 40.0) % 90.0).let { it in 0.0..1.6 } || kotlin.math.abs(u - (width - 40.0)) < 1.6
            if (inTable && (onRow || onCol)) px[y * width + x] = 0xFF202020.toInt()
        }
        return px
    }

    @Test
    fun hojaGiradaSeEnderezaConSusRayas() {
        val w = 500; val h = 640
        val px = table(w, h, 3.0)
        val before = ScanPhoto.skew(px, w, h)
        assertNotNull(before)
        assertTrue("inclinación medida $before", abs(abs(before!!) - 3f) < 0.6f)
        val straight = ScanPhoto.straighten(px, w, h)
        assertNotNull(straight)
        val after = ScanPhoto.skew(straight!!.first, straight.second, straight.third)
        assertTrue("después $after", after == null || abs(after) < 0.4f)
    }

    @Test
    fun hojaDerechaNoSeGira() {
        val w = 500; val h = 640
        assertNull(ScanPhoto.straighten(table(w, h, 0.0), w, h))
    }

    @Test
    fun rayaQueNoSigueLaPerspectivaSeQuita() {
        // Ángulo que cambia de a pocos con la posición (perspectiva) y una raya rara (sombra).
        val lines = listOf(
            floatArrayOf(Math.toRadians(-2.0).toFloat(), 100f, 400f, 0f),
            floatArrayOf(Math.toRadians(-1.0).toFloat(), 300f, 420f, 0f),
            floatArrayOf(Math.toRadians(0.0).toFloat(), 500f, 410f, 0f),
            floatArrayOf(Math.toRadians(1.0).toFloat(), 700f, 380f, 0f),
            floatArrayOf(Math.toRadians(6.0).toFloat(), 820f, 390f, 0f)
        )
        val kept = ScanPhoto.consistent(lines)
        assertEquals(4, kept.size)
        assertTrue(kept.none { it[1] == 820f })
    }

    @Test
    fun fotoConMuchaLuzIgualSeEndereza() {
        // Papel blanco puro (foto quemada) sobre una mesa oscura, con perspectiva.
        val w = 600; val h = 800
        val q = floatArrayOf(110f, 90f, 520f, 120f, 560f, 720f, 60f, 690f)
        fun inside(x: Float, y: Float): Boolean {
            var sign = 0
            for (k in 0 until 4) {
                val ax = q[k * 2]; val ay = q[k * 2 + 1]
                val bx = q[(k + 1) % 4 * 2]; val by = q[(k + 1) % 4 * 2 + 1]
                val cross = (bx - ax) * (y - ay) - (by - ay) * (x - ax)
                val sgn = if (cross > 0) 1 else -1
                if (sign == 0) sign = sgn else if (sgn != sign) return false
            }
            return true
        }
        val px = IntArray(w * h) { i ->
            val x = (i % w).toFloat(); val y = (i / w).toFloat()
            if (inside(x, y)) -1 else 0xFF3C3A38.toInt()
        }
        val found = ScanPhoto.detect(px, w, h)
        assertEquals("papel", found.method)
        assertTrue(!found.clean)
    }
}
