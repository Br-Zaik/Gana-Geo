package com.ganageo.app.ui.tools

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Bitmap
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CropFree
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.ganageo.app.GanaGeoViewModel
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.AdvancedFileUtils
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.PageSelectionParser
import com.ganageo.app.tools.PdfMargin
import com.ganageo.app.tools.PdfOrientation
import com.ganageo.app.tools.PdfPaperSize
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt

@Composable
fun DocumentScannerScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var editorUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var galleryImages by remember { mutableStateOf<List<ScannerGalleryImage>>(emptyList()) }
    var galleryLoading by remember { mutableStateOf(false) }
    var galleryRefresh by remember { mutableIntStateOf(0) }
    val galleryGridState = rememberLazyGridState()
    var mode by remember { mutableIntStateOf(0) } // 0 = elegir, 1 = OCR, 2 = limpiar
    var zoneMode by remember { mutableStateOf(false) }
    var selection by remember { mutableStateOf(ScannerSelection()) }
    var ocrText by remember { mutableStateOf("") }
    var ocrBusy by remember { mutableStateOf(false) }
    var showClean by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var openingImage by remember { mutableStateOf(false) }

    fun openScannerEditor(uri: Uri) {
        if (openingImage || saving || ocrBusy) return
        openingImage = true
        scope.launch {
            try {
                if (scannerUriReadable(context, uri)) {
                    editorUri = uri
                    mode = 0
                    zoneMode = false
                    selection = ScannerSelection()
                    ocrText = ""
                } else {
                    onMessage("Ya no se puede acceder a esta imagen. Elige otra foto.")
                }
            } finally {
                openingImage = false
            }
        }
    }

    val systemPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            openScannerEditor(uri)
        }
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val captured = pendingCameraUri
        pendingCameraUri = null
        if (ok && captured != null) {
            openScannerEditor(captured)
        }
    }

    fun openCamera() {
        if (saving || ocrBusy) return
        runCatching {
            val uri = ToolFileUtils.createCameraImageUri(context)
            pendingCameraUri = uri
            camera.launch(uri)
        }.onFailure {
            pendingCameraUri = null
            onMessage(it.message ?: "No se pudo abrir la cámara")
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openCamera() else onMessage("Se necesita permiso de cámara")
    }

    val galleryPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        galleryRefresh++
    }

    val saveCleanImage = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { output ->
        val input = editorUri
        if (output == null || input == null) return@rememberLauncherForActivityResult
        saving = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                withContext(Dispatchers.IO) {
                    val clean = scannerCleanBitmap(context, input, SCANNER_CLEAN_OUTPUT_MAX_EDGE)
                    try {
                        context.contentResolver.openOutputStream(output, "w")?.use { stream ->
                            check(clean.compress(Bitmap.CompressFormat.PNG, 100, stream)) { "No se pudo guardar la imagen" }
                        } ?: error("No se pudo crear el archivo")
                    } finally {
                        if (!clean.isRecycled) clean.recycle()
                    }
                }
            }.onSuccess {
                onMessage(successMessage("Imagen escaneada guardada", it))
            }.onFailure {
                onMessage(it.message ?: "No se pudo guardar la imagen")
            }
            saving = false
        }
    }

    BackHandler(enabled = editorUri != null || mode != 0) {
        if (mode != 0) {
            mode = 0
            zoneMode = false
            ocrText = ""
        } else {
            editorUri = null
        }
    }

    val galleryGranted = scannerGalleryPermissionGranted(context)
    LaunchedEffect(galleryGranted, galleryRefresh) {
        if (galleryGranted) {
            galleryLoading = true
            galleryImages = try {
                loadScannerRecentImages(context, SCANNER_GALLERY_RECENT_LIMIT)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                onMessage("No se pudieron cargar las fotos recientes")
                emptyList()
            }
            galleryLoading = false
        } else {
            galleryImages = emptyList()
        }
    }

    LaunchedEffect(Unit) {
        if (!scannerGalleryPermissionGranted(context)) {
            galleryPermissionLauncher.launch(scannerGalleryPermissions())
        }
    }

    val currentUri = editorUri
    if (currentUri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Elige una foto para escanear o extraer texto", onBack)
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                openCamera()
                            } else {
                                cameraPermission.launch(Manifest.permission.CAMERA)
                            }
                        },
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) {
                        Icon(Icons.Rounded.AddAPhoto, null)
                        Text("  Cámara")
                    }
                    OutlinedButton(
                        onClick = { systemPicker.launch(arrayOf("image/*")) },
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) {
                        Icon(Icons.Rounded.Folder, null)
                        Text("  Buscar en archivos")
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Últimas 15 imágenes", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    if (galleryGranted) {
                        IconButton(onClick = { galleryRefresh++ }) {
                            Icon(Icons.Rounded.Refresh, "Actualizar")
                        }
                    }
                }
            }

            when {
                !galleryGranted -> {
                    Box(Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.TopCenter) {
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                            Column(
                                Modifier.fillMaxWidth().padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Rounded.PhotoLibrary, null, tint = NeonGreen)
                                Text("Permite acceso a tus fotos para mostrarlas aquí.", textAlign = TextAlign.Center)
                                Button(
                                    onClick = { galleryPermissionLauncher.launch(scannerGalleryPermissions()) },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                                ) { Text("Permitir fotos", fontWeight = FontWeight.Bold) }
                                Text("También puedes usar Buscar en archivos sin dar acceso permanente.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
                galleryLoading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NeonGreen)
                    }
                }
                galleryImages.isEmpty() -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No se encontraron imágenes", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                else -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        state = galleryGridState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 10.dp, end = 10.dp, bottom = 28.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(galleryImages, key = { it.uri.toString() }) { item ->
                            ScannerGalleryThumbnail(item) {
                                openScannerEditor(item.uri)
                            }
                        }
                    }
                }
            }
        }
        return
    }

    var sourceLoadFailed by remember(currentUri) { mutableStateOf(false) }
    val sourceBitmap by produceState<Bitmap?>(initialValue = null, currentUri) {
        sourceLoadFailed = false
        value = try {
            ToolFileUtils.loadBitmap(context, currentUri, SCANNER_EDITOR_PREVIEW_MAX_EDGE)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Throwable) {
            sourceLoadFailed = true
            null
        }
    }

    var cleanLoadFailed by remember(currentUri) { mutableStateOf(false) }
    val cleanPreview by produceState<Bitmap?>(initialValue = null, currentUri, mode) {
        if (mode == 2) {
            cleanLoadFailed = false
            value = try {
                scannerCleanBitmap(context, currentUri, SCANNER_CLEAN_PREVIEW_MAX_EDGE)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                cleanLoadFailed = true
                null
            }
        }
    }

    val bitmapToShow = if (mode == 2 && showClean && cleanPreview != null) cleanPreview else sourceBitmap
    val clipboard = context.getSystemService(android.content.ClipboardManager::class.java)

    Column(Modifier.fillMaxSize()) {
        ToolHeader(
            tool.title,
            when {
                mode == 1 && zoneMode -> "Ajusta el cuadro sobre el texto"
                mode == 1 -> "OCR: copia o edita el texto reconocido"
                mode == 2 -> "Limpia la foto sin reconstruir el documento"
                else -> "Trabaja sobre la imagen seleccionada"
            }
        ) {
            if (mode != 0) {
                mode = 0
                zoneMode = false
                ocrText = ""
            } else {
                editorUri = null
            }
        }

        Box(
            modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF101412)),
            contentAlignment = Alignment.Center
        ) {
            if (bitmapToShow == null) {
                if (sourceLoadFailed || (mode == 2 && cleanLoadFailed)) {
                    Text("No se pudo abrir o procesar esta imagen", color = Color.White)
                } else {
                    CircularProgressIndicator(color = NeonGreen)
                }
            } else {
                ScannerImageViewport(
                    bitmap = bitmapToShow!!,
                    selectionEnabled = mode == 1 && zoneMode,
                    selection = selection,
                    onSelectionChange = { selection = it },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = CardGreen),
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp, bottomEnd = 0.dp, bottomStart = 0.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                Modifier.fillMaxWidth().padding(14.dp).heightIn(max = 330.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            mode = 1
                            zoneMode = false
                            ocrText = ""
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (mode == 1) NeonGreen else Color(0xFF244A37),
                            contentColor = if (mode == 1) DeepGreen else Color.White
                        )
                    ) {
                        Icon(Icons.Rounded.TextFields, null)
                        Text("  Extraer texto")
                    }
                    Button(
                        onClick = {
                            mode = 2
                            zoneMode = false
                            ocrText = ""
                            cleanLoadFailed = false
                            showClean = true
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (mode == 2) NeonGreen else Color(0xFF244A37),
                            contentColor = if (mode == 2) DeepGreen else Color.White
                        )
                    ) {
                        Icon(Icons.Rounded.AutoFixHigh, null)
                        Text("  Limpiar imagen")
                    }
                }

                if (mode == 1) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                zoneMode = false
                                launchPaidExport(viewModel, tool, onMessage) {
                                    ocrBusy = true
                                    scope.launch {
                                        var recognized = ""
                                        runPaidTool(viewModel, tool) {
                                            recognized = scannerOcr(context, currentUri, null)
                                            require(recognized.isNotBlank()) { "No se detectó texto." }
                                        }.onSuccess { reward ->
                                            ocrText = recognized
                                            if (reward > 0) onMessage("Texto extraído. Ganaste $reward Geo Rewards.")
                                        }.onFailure { error ->
                                            if (recognized.isNotBlank()) ocrText = recognized
                                            onMessage(error.message ?: "No se pudo reconocer el texto")
                                        }
                                        ocrBusy = false
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            enabled = !ocrBusy
                        ) { Text("Toda la imagen · ${tool.creditCost}") }
                        OutlinedButton(
                            onClick = {
                                zoneMode = true
                                ocrText = ""
                            },
                            modifier = Modifier.weight(1f),
                            enabled = !ocrBusy
                        ) { Text("Seleccionar zona") }
                    }

                    if (zoneMode) {
                        Button(
                            onClick = {
                                launchPaidExport(viewModel, tool, onMessage) {
                                    ocrBusy = true
                                    scope.launch {
                                        var recognized = ""
                                        runPaidTool(viewModel, tool) {
                                            recognized = scannerOcr(context, currentUri, selection)
                                            require(recognized.isNotBlank()) { "No se detectó texto en la zona." }
                                        }.onSuccess { reward ->
                                            ocrText = recognized
                                            if (reward > 0) onMessage("Texto extraído. Ganaste $reward Geo Rewards.")
                                        }.onFailure { error ->
                                            if (recognized.isNotBlank()) ocrText = recognized
                                            onMessage(error.message ?: "No se pudo reconocer el texto")
                                        }
                                        ocrBusy = false
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !ocrBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) {
                            Icon(Icons.Rounded.CropFree, null)
                            Text("  Extraer zona · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
                        }
                    }

                    if (ocrBusy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

                    if (ocrText.isNotBlank()) {
                        OutlinedTextField(
                            value = ocrText,
                            onValueChange = { ocrText = it },
                            label = { Text("Texto reconocido · editable") },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 190.dp)
                        )
                        Button(
                            onClick = {
                                clipboard?.setPrimaryClip(android.content.ClipData.newPlainText("Texto escaneado", ocrText))
                                onMessage("Texto copiado")
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) {
                            Icon(Icons.Rounded.ContentCopy, null)
                            Text("  Copiar texto", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (mode == 2) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { showClean = false },
                            modifier = Modifier.weight(1f),
                            enabled = cleanPreview != null
                        ) { Text("Original") }
                        OutlinedButton(
                            onClick = { showClean = true },
                            modifier = Modifier.weight(1f),
                            enabled = cleanPreview != null
                        ) { Text("Limpia") }
                    }
                    if (cleanPreview == null) {
                        if (cleanLoadFailed) {
                            Text("No se pudo generar la imagen limpia.", color = MaterialTheme.colorScheme.error)
                        } else {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Text("Limpiando bordes, iluminación y contraste...", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        Text(
                            "Conserva la distribución original; solo recorta el documento y mejora la imagen.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = {
                                val base = runCatching { ToolFileUtils.displayName(context, currentUri) }.getOrDefault("escaneo")
                                    .substringBeforeLast('.').replace(Regex("[\\/:*?\"<>|]"), "_").take(60)
                                launchPaidExport(viewModel, tool, onMessage) {
                                    saveCleanImage.launch("${base}_limpia.png")
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !saving,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) {
                            Icon(Icons.Rounded.Save, null)
                            Text(if (saving) "  Guardando..." else "  Guardar imagen · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

private const val SCANNER_GALLERY_RECENT_LIMIT = 15
private const val SCANNER_GALLERY_THUMBNAIL_SIZE = 256
private const val SCANNER_GALLERY_CACHE_BYTES = 6 * 1024 * 1024
private const val SCANNER_EDITOR_PREVIEW_MAX_EDGE = 1440
private const val SCANNER_CLEAN_PREVIEW_MAX_EDGE = 1440
private const val SCANNER_OCR_MAX_EDGE = 2048
private const val SCANNER_CLEAN_OUTPUT_MAX_EDGE = 2400

private data class ScannerGalleryImage(val uri: Uri, val name: String)

private val scannerThumbnailSemaphore = Semaphore(3)
private val scannerThumbnailCache = object : android.util.LruCache<String, Bitmap>(SCANNER_GALLERY_CACHE_BYTES) {
    override fun sizeOf(key: String, value: Bitmap): Int = runCatching { value.allocationByteCount }.getOrDefault(value.byteCount)
}

private data class ScannerSelection(
    val left: Float = 0.10f,
    val top: Float = 0.20f,
    val right: Float = 0.90f,
    val bottom: Float = 0.62f
)

private enum class ScannerDragMode { MOVE, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }

private fun scannerGalleryPermissions(): Array<String> = when {
    android.os.Build.VERSION.SDK_INT >= 34 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
    )
    android.os.Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

private fun scannerGalleryPermissionGranted(context: android.content.Context): Boolean = when {
    android.os.Build.VERSION.SDK_INT >= 34 -> {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
    }
    android.os.Build.VERSION.SDK_INT >= 33 ->
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
    else -> ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
}

private suspend fun loadScannerRecentImages(
    context: android.content.Context,
    limit: Int
): List<ScannerGalleryImage> = withContext(Dispatchers.IO) {
    val safeLimit = limit.coerceIn(1, SCANNER_GALLERY_RECENT_LIMIT)
    val collection = if (android.os.Build.VERSION.SDK_INT >= 29) {
        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
    } else {
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    }
    val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
    val result = ArrayList<ScannerGalleryImage>(safeLimit)
    context.contentResolver.query(
        collection,
        projection,
        null,
        null,
        "${MediaStore.Images.Media.DATE_ADDED} DESC"
    )?.use { cursor ->
        val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        val nameColumn = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
        while (result.size < safeLimit && cursor.moveToNext()) {
            val id = cursor.getLong(idColumn)
            val uri = android.content.ContentUris.withAppendedId(collection, id)
            val name = if (nameColumn >= 0) cursor.getString(nameColumn).orEmpty() else ""
            result += ScannerGalleryImage(uri, name)
        }
    }
    result
}

private suspend fun loadScannerThumbnail(context: android.content.Context, uri: Uri): Bitmap = withContext(Dispatchers.IO) {
    val key = uri.toString()
    synchronized(scannerThumbnailCache) {
        scannerThumbnailCache.get(key)?.takeIf { !it.isRecycled }
    }?.let { return@withContext it }

    scannerThumbnailSemaphore.withPermit {
        synchronized(scannerThumbnailCache) {
            scannerThumbnailCache.get(key)?.takeIf { !it.isRecycled }
        }?.let { return@withPermit it }

        val decoded = if (android.os.Build.VERSION.SDK_INT >= 29) {
            context.contentResolver.loadThumbnail(
                uri,
                android.util.Size(SCANNER_GALLERY_THUMBNAIL_SIZE, SCANNER_GALLERY_THUMBNAIL_SIZE),
                null
            )
        } else {
            ToolFileUtils.loadBitmap(context, uri, SCANNER_GALLERY_THUMBNAIL_SIZE)
        }
        synchronized(scannerThumbnailCache) {
            scannerThumbnailCache.put(key, decoded)
        }
        decoded
    }
}

@Composable
private fun ScannerGalleryThumbnail(item: ScannerGalleryImage, onClick: () -> Unit) {
    val context = LocalContext.current
    var attempted by remember(item.uri) { mutableStateOf(false) }
    val bitmap by produceState<Bitmap?>(initialValue = null, item.uri) {
        value = runCatching { loadScannerThumbnail(context, item.uri) }.getOrNull()
        attempted = true
    }
    Box(
        modifier = Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp)).background(Color(0xFF163324)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap == null) {
            if (attempted) {
                Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, tint = Color.White.copy(alpha = 0.55f))
            } else {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = NeonGreen)
            }
        } else {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = item.name.ifBlank { "Foto" },
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
    }
}

@Composable
private fun ScannerImageViewport(
    bitmap: Bitmap,
    selectionEnabled: Boolean,
    selection: ScannerSelection,
    onSelectionChange: (ScannerSelection) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember(bitmap) { mutableFloatStateOf(1f) }
    var offsetX by remember(bitmap) { mutableFloatStateOf(0f) }
    var offsetY by remember(bitmap) { mutableFloatStateOf(0f) }
    val currentSelection by rememberUpdatedState(selection)
    val currentOnSelectionChange by rememberUpdatedState(onSelectionChange)
    LaunchedEffect(selectionEnabled) {
        if (selectionEnabled) {
            scale = 1f
            offsetX = 0f
            offsetY = 0f
        }
    }

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val maxW = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val maxH = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val fit = minOf(maxW / bitmap.width.toFloat(), maxH / bitmap.height.toFloat())
        val imageW = bitmap.width * fit
        val imageH = bitmap.height * fit
        val imageLeft = (maxW - imageW) / 2f
        val imageTop = (maxH - imageH) / 2f

        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Imagen seleccionada",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offsetX
                    translationY = offsetY
                }
                .then(
                    if (!selectionEnabled) {
                        Modifier.pointerInput(bitmap) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val newScale = (scale * zoom).coerceIn(1f, 5f)
                                scale = newScale
                                val limitX = ((maxW * newScale - maxW) / 2f).coerceAtLeast(0f)
                                val limitY = ((maxH * newScale - maxH) / 2f).coerceAtLeast(0f)
                                offsetX = (offsetX + pan.x).coerceIn(-limitX, limitX)
                                offsetY = (offsetY + pan.y).coerceIn(-limitY, limitY)
                            }
                        }
                    } else Modifier
                )
        )

        if (selectionEnabled) {
            var dragMode by remember { mutableStateOf<ScannerDragMode?>(null) }
            val handleRadius = 34f
            Canvas(
                modifier = Modifier.fillMaxSize().pointerInput(imageW, imageH, imageLeft, imageTop) {
                    detectDragGestures(
                        onDragStart = { p ->
                            fun pointX(v: Float) = imageLeft + v * imageW
                            fun pointY(v: Float) = imageTop + v * imageH
                            val s = currentSelection
                            val corners = listOf(
                                ScannerDragMode.TOP_LEFT to Offset(pointX(s.left), pointY(s.top)),
                                ScannerDragMode.TOP_RIGHT to Offset(pointX(s.right), pointY(s.top)),
                                ScannerDragMode.BOTTOM_LEFT to Offset(pointX(s.left), pointY(s.bottom)),
                                ScannerDragMode.BOTTOM_RIGHT to Offset(pointX(s.right), pointY(s.bottom))
                            )
                            dragMode = corners.minByOrNull { (_, c) -> (p - c).getDistance() }
                                ?.takeIf { (_, c) -> (p - c).getDistance() <= handleRadius * 1.5f }?.first
                                ?: if (
                                    p.x in pointX(s.left)..pointX(s.right) &&
                                    p.y in pointY(s.top)..pointY(s.bottom)
                                ) ScannerDragMode.MOVE else null
                        },
                        onDragEnd = { dragMode = null },
                        onDragCancel = { dragMode = null }
                    ) { _, drag ->
                        val dx = drag.x / imageW
                        val dy = drag.y / imageH
                        val s = currentSelection
                        val minSize = 0.06f
                        val next = when (dragMode) {
                            ScannerDragMode.MOVE -> {
                                val width = s.right - s.left
                                val height = s.bottom - s.top
                                val l = (s.left + dx).coerceIn(0f, 1f - width)
                                val t = (s.top + dy).coerceIn(0f, 1f - height)
                                ScannerSelection(l, t, l + width, t + height)
                            }
                            ScannerDragMode.TOP_LEFT -> s.copy(
                                left = (s.left + dx).coerceIn(0f, s.right - minSize),
                                top = (s.top + dy).coerceIn(0f, s.bottom - minSize)
                            )
                            ScannerDragMode.TOP_RIGHT -> s.copy(
                                right = (s.right + dx).coerceIn(s.left + minSize, 1f),
                                top = (s.top + dy).coerceIn(0f, s.bottom - minSize)
                            )
                            ScannerDragMode.BOTTOM_LEFT -> s.copy(
                                left = (s.left + dx).coerceIn(0f, s.right - minSize),
                                bottom = (s.bottom + dy).coerceIn(s.top + minSize, 1f)
                            )
                            ScannerDragMode.BOTTOM_RIGHT -> s.copy(
                                right = (s.right + dx).coerceIn(s.left + minSize, 1f),
                                bottom = (s.bottom + dy).coerceIn(s.top + minSize, 1f)
                            )
                            null -> s
                        }
                        if (next != s) currentOnSelectionChange(next)
                    }
                }
            ) {
                val s = selection
                val l = imageLeft + s.left * imageW
                val t = imageTop + s.top * imageH
                val r = imageLeft + s.right * imageW
                val b = imageTop + s.bottom * imageH
                val shade = Color.Black.copy(alpha = 0.48f)
                drawRect(shade, Offset(imageLeft, imageTop), androidx.compose.ui.geometry.Size(imageW, (t - imageTop).coerceAtLeast(0f)))
                drawRect(shade, Offset(imageLeft, b), androidx.compose.ui.geometry.Size(imageW, (imageTop + imageH - b).coerceAtLeast(0f)))
                drawRect(shade, Offset(imageLeft, t), androidx.compose.ui.geometry.Size((l - imageLeft).coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))
                drawRect(shade, Offset(r, t), androidx.compose.ui.geometry.Size((imageLeft + imageW - r).coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))
                drawRect(
                    color = NeonGreen,
                    topLeft = Offset(l, t),
                    size = androidx.compose.ui.geometry.Size((r - l).coerceAtLeast(1f), (b - t).coerceAtLeast(1f)),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                )
                listOf(Offset(l, t), Offset(r, t), Offset(l, b), Offset(r, b)).forEach {
                    drawCircle(Color.White, radius = 13f, center = it)
                    drawCircle(NeonGreen, radius = 9f, center = it)
                }
            }
        }
    }
}

private suspend fun scannerUriReadable(context: android.content.Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
    try {
        context.contentResolver.openInputStream(uri)?.use { true } ?: false
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (_: Throwable) {
        false
    }
}

private suspend fun scannerCleanBitmap(context: android.content.Context, uri: Uri, maxEdge: Int): Bitmap = withContext(Dispatchers.IO) {
    val source = ToolFileUtils.loadBitmap(context, uri, maxEdge)
    val rawCropped = try {
        AdvancedFileUtils.autoDocumentCrop(source)
    } catch (error: Throwable) {
        if (!source.isRecycled) source.recycle()
        throw error
    }
    val cropped = if (rawCropped === source) {
        source.copy(source.config ?: Bitmap.Config.ARGB_8888, false)
    } else {
        rawCropped
    }
    if (cropped !== source && !source.isRecycled) source.recycle()

    try {
        val cleaned = ToolFileUtils.applyImageAdjustments(
            cropped,
            DocumentImageFilter.ENHANCE,
            brightness = 3,
            contrast = 1.12f
        )
        if (cleaned !== cropped && !cropped.isRecycled) cropped.recycle()
        cleaned
    } catch (error: Throwable) {
        if (!cropped.isRecycled) cropped.recycle()
        throw error
    }
}

private suspend fun scannerOcr(
    context: android.content.Context,
    uri: Uri,
    selection: ScannerSelection?
): String = withContext(Dispatchers.IO) {
    val source = ToolFileUtils.loadBitmap(context, uri, SCANNER_OCR_MAX_EDGE)
    if (selection == null) {
        try {
            return@withContext recognizeScannerText(source).trim()
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }

    val left = (selection.left * source.width).roundToInt().coerceIn(0, source.width - 2)
    val top = (selection.top * source.height).roundToInt().coerceIn(0, source.height - 2)
    val right = (selection.right * source.width).roundToInt().coerceIn(left + 2, source.width)
    val bottom = (selection.bottom * source.height).roundToInt().coerceIn(top + 2, source.height)
    val target = Bitmap.createBitmap(source, left, top, right - left, bottom - top)
    try {
        recognizeScannerText(target).trim()
    } finally {
        if (target !== source && !target.isRecycled) target.recycle()
        if (!source.isRecycled) source.recycle()
    }
}

private suspend fun recognizeScannerText(bitmap: Bitmap): String = suspendCancellableCoroutine { continuation ->
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    val task = recognizer.process(InputImage.fromBitmap(bitmap, 0))
    task.addOnSuccessListener { result ->
        if (continuation.isActive) continuation.resume(result.text)
    }
    task.addOnFailureListener { error ->
        if (continuation.isActive) continuation.resumeWithException(error)
    }
    task.addOnCanceledListener {
        if (continuation.isActive) continuation.cancel()
    }
    val closed = java.util.concurrent.atomic.AtomicBoolean(false)
    fun closeRecognizer() {
        if (closed.compareAndSet(false, true)) recognizer.close()
    }
    task.addOnCompleteListener { closeRecognizer() }
    continuation.invokeOnCancellation { closeRecognizer() }
}

@Composable
fun TextToPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by rememberSaveable { mutableStateOf("") }
    var author by rememberSaveable { mutableStateOf("") }
    var body by rememberSaveable { mutableStateOf("") }
    var header by rememberSaveable { mutableStateOf("") }
    var paperIndex by rememberSaveable { mutableIntStateOf(PdfPaperSize.A4.ordinal) }
    var orientationIndex by rememberSaveable { mutableIntStateOf(PdfOrientation.PORTRAIT.ordinal) }
    var marginIndex by rememberSaveable { mutableIntStateOf(PdfMargin.NORMAL.ordinal) }
    var fontSize by rememberSaveable { mutableFloatStateOf(12f) }
    var pageNumbers by rememberSaveable { mutableStateOf(true) }
    var name by rememberSaveable { mutableStateOf("documento_texto.pdf") }
    var processing by remember { mutableStateOf(false) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        if (output == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                AdvancedFileUtils.createTextPdf(context, output, body, AdvancedFileUtils.TextPdfOptions(
                    title, author, fontSize, 1.35f, PdfPaperSize.entries[paperIndex], PdfOrientation.entries[orientationIndex], PdfMargin.entries[marginIndex], pageNumbers, header
                ))
            }.onSuccess { onMessage(successMessage("Documento PDF creado", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo crear el PDF") }
            processing = false
        }
    }
    AdvancedToolPage(tool, onBack) {
        AdvancedSection("Contenido") {
            OutlinedTextField(title, { title = it.take(180) }, label = { Text("Título (opcional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(author, { author = it.take(160) }, label = { Text("Autor (opcional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(header, { header = it.take(180) }, label = { Text("Encabezado (opcional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(body, { body = it.take(300_000) }, label = { Text("Texto") }, placeholder = { Text("Escribe o pega tu trabajo...") }, modifier = Modifier.fillMaxWidth().height(260.dp))
            Text("${body.length} caracteres", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        AdvancedSection("Formato") {
            SimpleDropdown("Papel", PdfPaperSize.entries.map { it.label }, paperIndex) { paperIndex = it }
            SimpleDropdown("Orientación", PdfOrientation.entries.map { it.label }, orientationIndex) { orientationIndex = it }
            SimpleDropdown("Márgenes", PdfMargin.entries.map { it.label }, marginIndex) { marginIndex = it }
            Text("Tamaño de letra: ${fontSize.toInt()} pt")
            Slider(fontSize, { fontSize = it }, valueRange = 9f..22f, steps = 12)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Numerar páginas", modifier = Modifier.weight(1f)); Switch(pageNumbers, { pageNumbers = it }) }
            OutlinedTextField(name, { name = it.replace(Regex("[\\/:*?\"<>|]"), "_").take(80) }, label = { Text("Nombre del archivo") }, modifier = Modifier.fillMaxWidth())
        }
        if (processing) {
            item { AdvancedProgress("Creando documento", null) }
        }
        item {
            Button(onClick = {
                if (body.isBlank()) onMessage("Escribe el contenido") else launchPaidExport(viewModel, tool, onMessage) {
                    val clean = name.trim().ifBlank { "documento_texto.pdf" }
                    save.launch(if (clean.endsWith(".pdf", true)) clean else "$clean.pdf")
                }
            }, enabled = body.isNotBlank() && !processing, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                Text("Crear PDF · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PdfWatermarkSecurityScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var modeIndex by rememberSaveable { mutableIntStateOf(0) }
    var watermark by rememberSaveable { mutableStateOf("GANA GEO") }
    var positionIndex by rememberSaveable { mutableIntStateOf(AdvancedFileUtils.WatermarkPosition.DIAGONAL.ordinal) }
    var opacity by rememberSaveable { mutableFloatStateOf(25f) }
    var fontSize by rememberSaveable { mutableFloatStateOf(42f) }
    var pagesText by rememberSaveable { mutableStateOf("") }
    var pageNumbers by rememberSaveable { mutableStateOf(false) }
    var firstPageNumber by rememberSaveable { mutableStateOf("1") }
    var currentPassword by rememberSaveable { mutableStateOf("") }
    var newPassword by rememberSaveable { mutableStateOf("") }
    var allowPrinting by rememberSaveable { mutableStateOf(true) }
    var allowCopy by rememberSaveable { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    val modes = listOf("Marca y numeración", "Agregar/cambiar contraseña", "Quitar contraseña")
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { input = it }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val source = input ?: return@rememberLauncherForActivityResult
        if (output == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                when (modeIndex) {
                    0 -> {
                        val count = ToolFileUtils.pdfPageCount(context, source)
                        val pages = PageSelectionParser.parse(pagesText, count).toSet()
                        AdvancedFileUtils.watermarkPdf(context, source, output, AdvancedFileUtils.PdfWatermarkOptions(
                            text = watermark,
                            opacityPercent = opacity.toInt(),
                            fontSize = fontSize,
                            position = AdvancedFileUtils.WatermarkPosition.entries[positionIndex],
                            addPageNumbers = pageNumbers,
                            firstPageNumber = firstPageNumber.toIntOrNull()?.coerceIn(1, 9999) ?: 1,
                            pages = pages
                        ), currentPassword)
                    }
                    1 -> AdvancedFileUtils.changePdfProtection(context, source, output, currentPassword, newPassword, allowPrinting, allowCopy)
                    else -> AdvancedFileUtils.changePdfProtection(context, source, output, currentPassword, null)
                }
            }.onSuccess { onMessage(successMessage("PDF guardado", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar el PDF") }
            processing = false
        }
    }
    AdvancedToolPage(tool, onBack) {
        AdvancedSection("Archivo") {
            OutlinedButton(onClick = { pick.launch(arrayOf("application/pdf")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Folder, null); Text(" Seleccionar PDF") }
            input?.let { Text(ToolFileUtils.displayName(context, it), color = NeonGreen) }
            SimpleDropdown("Operación", modes, modeIndex) { modeIndex = it }
        }
        if (modeIndex == 0) AdvancedSection("Marca de agua y páginas") {
            OutlinedTextField(watermark, { watermark = it.take(120) }, label = { Text("Texto de la marca") }, modifier = Modifier.fillMaxWidth())
            SimpleDropdown("Posición", AdvancedFileUtils.WatermarkPosition.entries.map { it.label }, positionIndex) { positionIndex = it }
            Text("Opacidad: ${opacity.toInt()} %"); Slider(opacity, { opacity = it }, valueRange = 5f..80f)
            Text("Tamaño: ${fontSize.toInt()} pt"); Slider(fontSize, { fontSize = it }, valueRange = 12f..90f)
            OutlinedTextField(pagesText, { pagesText = it.filter { c -> c.isDigit() || c in ", -" }.take(120) }, label = { Text("Páginas (vacío = todas)") }, placeholder = { Text("1-3, 5, 8") }, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Agregar número de página", modifier = Modifier.weight(1f)); Switch(pageNumbers, { pageNumbers = it }) }
            if (pageNumbers) OutlinedTextField(firstPageNumber, { firstPageNumber = it.filter(Char::isDigit).take(4) }, label = { Text("Comenzar numeración en") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(currentPassword, { currentPassword = it.take(60) }, label = { Text("Contraseña actual, si tiene") }, modifier = Modifier.fillMaxWidth())
        } else AdvancedSection("Contraseña y permisos") {
            OutlinedTextField(currentPassword, { currentPassword = it.take(60) }, label = { Text("Contraseña actual, si tiene") }, modifier = Modifier.fillMaxWidth())
            if (modeIndex == 1) {
                OutlinedTextField(newPassword, { newPassword = it.take(60) }, label = { Text("Nueva contraseña") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Permitir impresión", modifier = Modifier.weight(1f)); Switch(allowPrinting, { allowPrinting = it }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Permitir copiar contenido", modifier = Modifier.weight(1f)); Switch(allowCopy, { allowCopy = it }) }
            } else Text("Solo funciona cuando el usuario conoce la contraseña actual.", color = Gold)
        }
        if (processing) {
            item { AdvancedProgress("Procesando PDF", null) }
        }
        item {
            Button(onClick = {
                if (input == null) onMessage("Selecciona un PDF")
                else if (modeIndex == 1 && newPassword.length < 4) onMessage("La nueva contraseña debe tener al menos 4 caracteres")
                else launchPaidExport(viewModel, tool, onMessage) { save.launch("pdf_procesado_gana_geo.pdf") }
            }, enabled = input != null && !processing, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                Text("Guardar PDF · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AdvancedToolPage(tool: ToolId, onBack: () -> Unit, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, tool.subtitle, onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF401415)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = Gold)
                        Column(Modifier.weight(1f)) {
                            Text("Operación profesional", fontWeight = FontWeight.Bold)
                            Text(
                                "Costo: ${tool.creditCost} créditos. Solo se confirma cuando el archivo se crea correctamente.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            content()
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.AdvancedSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    item {
        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                content()
            }
        }
    }
}

@Composable
private fun AdvancedProgress(title: String, progress: Float?) {
    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (progress == null) LinearProgressIndicator(Modifier.fillMaxWidth()) else LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        }
    }
}
