# Gana Geo Android v10.0.11

Corrección puntual del corredor obligatorio del nivel 2 para que mantenga dificultad, pero tenga una ruta real. Consulta `CAMBIOS_V10_0_11_TRAMO_LIMPIO_NIVEL2.txt` y `VALIDACION_V10_0_11.txt`.
