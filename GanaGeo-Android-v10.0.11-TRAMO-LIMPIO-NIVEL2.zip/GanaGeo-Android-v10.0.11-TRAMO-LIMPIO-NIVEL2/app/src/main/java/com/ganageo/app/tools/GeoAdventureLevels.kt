package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class PlatformKind { SOLID, FALLING, DISAPPEARING, PROXIMITY_DISAPPEARING, REVEALING, BOUNCE }
enum class HazardKind { SPIKES, HIDDEN_SPIKES, SAW, FIRE, CEILING_SPIKES }
enum class HazardOrientation { UP, DOWN, LEFT, RIGHT }
enum class CheckpointKind { SAFE, POPUP, DECOY }
enum class FallingObjectKind { ROCK, FRUIT, CRATE, SPIKE_BALL }
enum class FallingBehavior { DROP, EXPLODE, ROLL, CHASE, CHAIN }
enum class CrusherAxis { HORIZONTAL, VERTICAL }
enum class GameEnemyKind { WALKER, JUMPER, FLYER, SHOOTER, GUARDIAN }
enum class GamePickupKind { ENERGY, SHIELD, POWER }

data class GamePlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float = 34f,
    val kind: PlatformKind = PlatformKind.SOLID,
    val triggerX: Float = x - 90f,
    val delayMs: Long = 320L,
    val cycleMs: Long = 2_200L,
    val phaseMs: Long = 0L
)

data class GameHazard(
    val x: Float,
    val y: Float,
    val width: Float = 58f,
    val height: Float = 42f,
    val kind: HazardKind = HazardKind.SPIKES,
    val triggerX: Float = x - 105f,
    val cycleMs: Long = 0L,
    val phaseMs: Long = 0L,
    val orientation: HazardOrientation = HazardOrientation.UP,
    val camouflaged: Boolean = false
)

data class GameBarrier(
    val x: Float,
    val y: Float = 270f,
    val width: Float = 46f,
    val height: Float = 350f,
    val switchIndex: Int
)

data class GameEnemy(
    val x: Float,
    val y: Float,
    val range: Float = 120f,
    val detectionRange: Float = 480f,
    val health: Int = 2,
    val kind: GameEnemyKind = GameEnemyKind.WALKER,
    val speed: Float = 72f
)

data class GameCrystal(val x: Float, val y: Float)
data class GameCrate(val x: Float, val y: Float)
data class GameSwitch(val x: Float, val y: Float, val opensAtX: Float, val reversesFans: Boolean = false)

data class GamePickup(val x: Float, val y: Float, val kind: GamePickupKind)

data class GameMovingPlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val travel: Float,
    val vertical: Boolean,
    val periodSeconds: Float = 3.4f
)

data class GameCheckpoint(
    val x: Float,
    val y: Float = 535f,
    val kind: CheckpointKind = CheckpointKind.SAFE,
    val appearTriggerX: Float = x - 180f
)

data class GameFan(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val forceX: Float,
    val forceY: Float,
    val cycleMs: Long = 0L,
    val phaseMs: Long = 0L,
    val switchIndex: Int? = null
)

data class GameFallingObject(
    val x: Float,
    val startY: Float,
    val targetY: Float,
    val size: Float,
    val triggerX: Float,
    val kind: FallingObjectKind,
    val delayMs: Long = 180L,
    val behavior: FallingBehavior = FallingBehavior.DROP,
    val rollDirection: Float = 1f,
    val explosionRadius: Float = 130f,
    val chainCount: Int = 1,
    val chainSpacing: Float = 74f,
    val chaseDurationMs: Long = 8_000L,
    val chaseMaxTravel: Float = 1_250f,
    val treeFallsAfterTrap: Boolean = false,
    val explosionDelayMs: Long = 120L
)

data class GameChasingHole(
    val startX: Float,
    val y: Float = 592f,
    val width: Float = 145f,
    val height: Float = 48f,
    val triggerX: Float,
    val speed: Float = 170f,
    val maxTravel: Float = 720f,
    val direction: Float = 1f,
    val surfaceStartX: Float = startX,
    val surfaceEndX: Float = startX + maxTravel + width
)

data class GameCrusher(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val triggerX: Float,
    val axis: CrusherAxis,
    val travel: Float,
    val speed: Float = 540f,
    val delayMs: Long = 100L,
    val reverseAfterMs: Long = 850L
)

data class AdventureLevel(
    val number: Int,
    val worldName: String,
    val levelName: String,
    val objective: String,
    val difficultyLabel: String,
    val width: Float,
    val platforms: List<GamePlatform>,
    val movingPlatforms: List<GameMovingPlatform>,
    val hazards: List<GameHazard>,
    val barriers: List<GameBarrier>,
    val enemies: List<GameEnemy>,
    val crystals: List<GameCrystal>,
    val crates: List<GameCrate>,
    val switches: List<GameSwitch>,
    val checkpoints: List<GameCheckpoint>,
    val fans: List<GameFan>,
    val fallingObjects: List<GameFallingObject>,
    val chasingHoles: List<GameChasingHole>,
    val crushers: List<GameCrusher>,
    val requiredMechanisms: Int,
    val pickups: List<GamePickup>,
    val goalX: Float,
    val parSeconds: Int,
    val introStory: String? = null,
    val outroStory: String? = null,
    val companion: String? = null,
    val injured: Boolean = false,
    val weaponEnabled: Boolean = false,
    val acechantePresent: Boolean = false
)

object GeoAdventureLevelFactory {
    private val names = listOf(
        "La primera mentira", "El suelo te persigue", "El bosque te quiere muerto", "El checkpoint asesino",
        "Bosque de botones", "La ruta que desaparece", "Frutas del cielo", "Puertas con memoria",
        "Ruinas invisibles", "El ventilador doble", "La torre que respira", "No mires atrás",
        "Interruptores cruzados", "El pasillo imposible", "La lluvia de metal", "El defensor falso",
        "El bosque te observa", "La persecución del Acechante", "Todo estaba preparado", "La nave sigue viva"
    )

    private val intros = mapOf(
        1 to "GEO despierta en un planeta donde el escenario parece ayudarlo, pero cada objeto puede esconder una trampa.",
        5 to "Luma descubre que los mecanismos del bosque responden a botones antiguos. Algunos abren caminos; otros despiertan peligros.",
        9 to "Las ruinas ocultan bloques, corrientes de aire y checkpoints que solo aparecen cuando GEO ya está en peligro.",
        13 to "Taro guía a GEO por la torre. Cada interruptor modifica varias partes del nivel y ninguna ruta permanece igual.",
        17 to "El Acechante entra al bosque. Ya no basta memorizar trampas: ahora también hay que avanzar bajo presión."
    )

    private val outros = mapOf(
        4 to "El último checkpoint era real, pero activó una nueva trampa. GEO comprende que incluso la seguridad tiene un precio.",
        8 to "Luma aprende a leer las corrientes del bosque y señala las partículas que delatan a los ventiladores ocultos.",
        12 to "Taro bloquea una compuerta mientras la torre cambia de forma. El camino a la señal ya no puede cerrarse.",
        16 to "Una plataforma se derrumba detrás de ellos. La única salida está delante, donde el Acechante ya los espera.",
        20 to "GEO alcanza la nave, pero las luces interiores se encienden solas. Algo llegó antes. Continuará…"
    )

    private fun hiddenSpike(
        x: Float,
        triggerX: Float,
        width: Float = 66f,
        y: Float = 576f,
        height: Float = 44f,
        orientation: HazardOrientation = HazardOrientation.UP,
        cycleMs: Long = 0L,
        phaseMs: Long = 0L
    ) = GameHazard(
        x = x,
        y = y,
        width = width,
        height = height,
        kind = HazardKind.HIDDEN_SPIKES,
        triggerX = triggerX,
        cycleMs = cycleMs,
        phaseMs = phaseMs,
        orientation = orientation,
        camouflaged = true
    )

    private fun floorFire(x: Float, width: Float = 72f, phaseMs: Long = 0L) = GameHazard(
        x = x,
        y = 576f,
        width = width,
        height = 44f,
        kind = HazardKind.FIRE,
        cycleMs = 2_050L,
        phaseMs = phaseMs,
        orientation = HazardOrientation.UP,
        camouflaged = true
    )

    private fun popupCheckpoint(x: Float, platformY: Float = 620f, revealOffset: Float = 55f) =
        GameCheckpoint(x = x, y = platformY - 85f, kind = CheckpointKind.POPUP, appearTriggerX = x - revealOffset)

    private fun decoyCheckpoint(x: Float, platformY: Float = 620f) =
        GameCheckpoint(x = x, y = platformY - 85f, kind = CheckpointKind.DECOY, appearTriggerX = x - 180f)

    private fun stabilizeLevel(level: AdventureLevel): AdventureLevel {
        val groundPlatforms = level.platforms
            .filter { it.y >= 590f && it.width >= 170f }
            .sortedBy { it.x }

        val targetRealCheckpointCount = when {
            level.width <= 6_800f -> 2
            level.width <= 9_000f -> 3
            level.width <= 13_500f -> 3
            level.width <= 17_500f -> 4
            else -> 5
        }

        val balancedCheckpoints = level.checkpoints.toMutableList()
        fun realCount() = balancedCheckpoints.count { it.kind != CheckpointKind.DECOY }
        if (realCount() < targetRealCheckpointCount) {
            balancedCheckpoints.indices
                .filter { balancedCheckpoints[it].kind == CheckpointKind.DECOY }
                .forEach { index ->
                    if (realCount() >= targetRealCheckpointCount) return@forEach
                    balancedCheckpoints[index] = balancedCheckpoints[index].copy(kind = CheckpointKind.POPUP)
                }
        }
        var checkpointSlot = 1
        while (realCount() < targetRealCheckpointCount && groundPlatforms.isNotEmpty()) {
            val ratio = checkpointSlot.toFloat() / (targetRealCheckpointCount + 1)
            val targetX = level.width * ratio
            val platform = groundPlatforms.minByOrNull { abs((it.x + it.width / 2f) - targetX) } ?: break
            val checkpointX = (platform.x + platform.width * 0.55f)
                .coerceIn(platform.x + 75f, platform.x + platform.width - 75f)
            if (balancedCheckpoints.none { abs(it.x - checkpointX) < 260f }) {
                balancedCheckpoints += GameCheckpoint(
                    x = checkpointX,
                    y = platform.y - 85f,
                    kind = CheckpointKind.SAFE,
                    appearTriggerX = checkpointX - 220f
                )
            }
            checkpointSlot++
            if (checkpointSlot > targetRealCheckpointCount + 4) break
        }

        val realCheckpoints = balancedCheckpoints.filter { it.kind != CheckpointKind.DECOY }
        val checkpointPlatforms = realCheckpoints.map { checkpoint ->
            val width = 250f
            val x = (checkpoint.x - 100f).coerceIn(0f, (level.width - width).coerceAtLeast(0f))
            GamePlatform(x = x, y = checkpoint.y + 85f, width = width, height = 30f, kind = PlatformKind.SOLID)
        }

        val bridgePlatforms = buildList {
            groundPlatforms.zipWithNext().forEach { (left, right) ->
                val gapStart = left.x + left.width
                val gap = right.x - gapStart
                if (gap > 245f) {
                    val bridgeWidth = (gap - 85f).coerceIn(115f, 185f)
                    val bridgeX = gapStart + (gap - bridgeWidth) / 2f
                    add(GamePlatform(bridgeX, 620f, bridgeWidth, 27f, PlatformKind.SOLID))
                }
            }
        }

        fun nearRealCheckpoint(x: Float, halfWidth: Float): Boolean = realCheckpoints.any { checkpoint ->
            x + halfWidth >= checkpoint.x - 135f && x - halfWidth <= checkpoint.x + 175f
        }
        fun holeCanReachCheckpoint(hole: GameChasingHole): Boolean {
            val minX = minOf(hole.surfaceStartX, hole.surfaceEndX) - 90f
            val maxX = maxOf(hole.surfaceStartX, hole.surfaceEndX) + 90f
            return realCheckpoints.any { it.x in minX..maxX }
        }
        fun crusherCanReachCheckpoint(crusher: GameCrusher): Boolean {
            val minX = if (crusher.axis == CrusherAxis.HORIZONTAL) minOf(crusher.x, crusher.x + crusher.travel) else crusher.x
            val maxX = if (crusher.axis == CrusherAxis.HORIZONTAL) maxOf(crusher.x + crusher.width, crusher.x + crusher.travel + crusher.width) else crusher.x + crusher.width
            return realCheckpoints.any { checkpoint -> checkpoint.x in (minX - 120f)..(maxX + 120f) }
        }

        val routeLandingPockets = groundPlatforms.flatMap { platform ->
            val pocket = minOf(105f, platform.width * 0.24f)
            listOf(
                (platform.x + 14f)..(platform.x + pocket),
                (platform.x + platform.width - pocket)..(platform.x + platform.width - 14f)
            )
        }

        val safeHoles = level.chasingHoles.filter { hole ->
            !holeCanReachCheckpoint(hole) &&
                hole.maxTravel <= (hole.surfaceEndX - hole.surfaceStartX).coerceAtLeast(0f) &&
                hole.surfaceEndX - hole.surfaceStartX >= hole.width + 125f &&
                groundPlatforms.any { platform ->
                    abs(platform.y - (hole.y + 28f)) <= 14f &&
                        hole.surfaceStartX >= platform.x &&
                        hole.surfaceEndX <= platform.x + platform.width
                }
        }

        fun overlapsHoleZone(startX: Float, endX: Float, padding: Float = 70f): Boolean = safeHoles.any { hole ->
            val zoneStart = minOf(hole.surfaceStartX, hole.surfaceEndX) - padding
            val zoneEnd = maxOf(hole.surfaceStartX, hole.surfaceEndX) + padding
            endX >= zoneStart && startX <= zoneEnd
        }

        val safeHazards = level.hazards.filterNot { hazard ->
            val center = hazard.x + hazard.width / 2f
            val checkpointConflict = nearRealCheckpoint(center, hazard.width / 2f)
            val blocksLandingPocket = hazard.orientation == HazardOrientation.UP && routeLandingPockets.any { center in it }
            val crowdsHole = overlapsHoleZone(hazard.x, hazard.x + hazard.width, 90f)
            checkpointConflict || blocksLandingPocket || crowdsHole
        }.mapIndexed { index, hazard ->
            if (hazard.kind != HazardKind.HIDDEN_SPIKES) return@mapIndexed hazard
            when (hazard.orientation) {
                HazardOrientation.LEFT, HazardOrientation.RIGHT, HazardOrientation.DOWN -> hazard.copy(
                    height = minOf(hazard.height, 82f),
                    cycleMs = if (hazard.cycleMs > 0L) hazard.cycleMs else 2_650L,
                    phaseMs = (index * 310L) % 1_100L
                )
                HazardOrientation.UP -> if (index % 3 == 0) hazard.copy(
                    cycleMs = if (hazard.cycleMs > 0L) hazard.cycleMs else 2_450L,
                    phaseMs = (index * 240L) % 900L
                ) else hazard
            }
        }
        val safeFallingObjects = level.fallingObjects.filterNot { falling ->
            nearRealCheckpoint(falling.x + falling.size / 2f, falling.size / 2f) ||
                overlapsHoleZone(
                    minOf(falling.x, falling.triggerX),
                    maxOf(falling.x + falling.size, falling.triggerX + falling.size),
                    125f
                )
        }.mapIndexed { index, falling ->
            if (falling.kind != FallingObjectKind.FRUIT) return@mapIndexed falling
            falling.copy(
                chaseDurationMs = if (falling.behavior == FallingBehavior.CHASE) 8_500L else falling.chaseDurationMs,
                chaseMaxTravel = if (falling.behavior == FallingBehavior.CHASE) 1_350f else falling.chaseMaxTravel,
                treeFallsAfterTrap = (level.number + index) % 3 == 0
            )
        }
        val safeCrushers = level.crushers.filterNot { crusher ->
            crusherCanReachCheckpoint(crusher) || overlapsHoleZone(
                minOf(crusher.x, crusher.x + if (crusher.axis == CrusherAxis.HORIZONTAL) crusher.travel else 0f),
                maxOf(crusher.x + crusher.width, crusher.x + crusher.width + if (crusher.axis == CrusherAxis.HORIZONTAL) crusher.travel else 0f),
                105f
            )
        }
        val safeFans = level.fans.filterNot { fan ->
            nearRealCheckpoint(fan.x + fan.width / 2f, fan.width / 2f)
        }.map { fan ->
            val nearOpening = overlapsHoleZone(fan.x, fan.x + fan.width, 25f)
            fan.copy(
                forceX = fan.forceX.coerceIn(if (nearOpening) -240f else -310f, if (nearOpening) 240f else 310f),
                forceY = fan.forceY.coerceIn(if (nearOpening) -330f else -410f, if (nearOpening) 330f else 410f),
                cycleMs = if (fan.cycleMs <= 0L) 2_600L else maxOf(fan.cycleMs, if (nearOpening) 2_650L else 2_200L)
            )
        }
        val safeEnemies = level.enemies.filterNot { enemy ->
            nearRealCheckpoint(enemy.x, enemy.range / 2f) || overlapsHoleZone(enemy.x - enemy.range, enemy.x + enemy.range, 50f)
        }
        val balancedFans = if (safeFans.isNotEmpty()) safeFans else {
            val platform = groundPlatforms
                .filterNot { nearRealCheckpoint(it.x + it.width / 2f, minOf(140f, it.width / 3f)) }
                .maxByOrNull { it.width }
            if (platform == null) emptyList() else listOf(
                GameFan(
                    x = platform.x + platform.width * 0.35f,
                    y = 350f,
                    width = minOf(280f, platform.width * 0.52f),
                    height = 245f,
                    forceX = if (level.number % 2 == 0) 220f else -220f,
                    forceY = 0f,
                    cycleMs = 2_800L,
                    phaseMs = (level.number * 170L) % 900L
                )
            )
        }

        val reactivePlatforms = level.platforms.map { platform ->
            if (platform.kind == PlatformKind.DISAPPEARING) {
                platform.copy(
                    kind = PlatformKind.PROXIMITY_DISAPPEARING,
                    triggerX = platform.x - 45f,
                    delayMs = maxOf(platform.delayMs, 700L),
                    cycleMs = 0L,
                    phaseMs = 0L
                )
            } else if (platform.kind == PlatformKind.PROXIMITY_DISAPPEARING) {
                platform.copy(delayMs = maxOf(platform.delayMs, 560L))
            } else platform
        }

        return level.copy(
            platforms = (reactivePlatforms + checkpointPlatforms + bridgePlatforms).distinctBy { listOf(it.x, it.y, it.width, it.kind) },
            hazards = safeHazards,
            fallingObjects = safeFallingObjects,
            chasingHoles = safeHoles,
            crushers = safeCrushers,
            fans = balancedFans,
            enemies = safeEnemies,
            checkpoints = balancedCheckpoints.sortedBy { it.x }
        )
    }

    private fun extremeLevel(
        number: Int,
        width: Float,
        platforms: List<GamePlatform>,
        movingPlatforms: List<GameMovingPlatform>,
        hazards: List<GameHazard>,
        barriers: List<GameBarrier>,
        enemies: List<GameEnemy>,
        crystals: List<GameCrystal>,
        crates: List<GameCrate>,
        switches: List<GameSwitch>,
        checkpoints: List<GameCheckpoint>,
        fans: List<GameFan>,
        fallingObjects: List<GameFallingObject>,
        chasingHoles: List<GameChasingHole>,
        crushers: List<GameCrusher>,
        pickups: List<GamePickup>,
        parSeconds: Int
    ) = AdventureLevel(
        number = number,
        worldName = GeoGameRules.worldName(number),
        levelName = names[number - 1],
        objective = "Sobrevive al troleo extremo. Cada trampa tiene una ruta real: memoriza, retrocede, espera, usa el doble salto y rebota sobre enemigos.",
        difficultyLabel = when (number) {
            1 -> "Troleo extremo"
            2 -> "Troleo brutal"
            3 -> "Troleo pesadilla"
            else -> "Troleo imposible"
        },
        width = width,
        platforms = platforms,
        movingPlatforms = movingPlatforms,
        hazards = hazards,
        barriers = barriers,
        enemies = enemies,
        crystals = crystals,
        crates = crates,
        switches = switches,
        checkpoints = checkpoints,
        fans = fans,
        fallingObjects = fallingObjects,
        chasingHoles = chasingHoles,
        crushers = crushers,
        requiredMechanisms = switches.size,
        pickups = pickups,
        goalX = width - 170f,
        parSeconds = parSeconds,
        introStory = intros[number],
        outroStory = outros[number],
        companion = null,
        injured = number == 1,
        weaponEnabled = false,
        acechantePresent = false
    )

    private fun buildExtremeLevel(number: Int): AdventureLevel = when (number) {
        1 -> extremeLevel(
            number = 1,
            width = 6_300f,
            platforms = listOf(
                GamePlatform(0f, 620f, 780f),
                GamePlatform(920f, 620f, 530f),
                GamePlatform(1_560f, 620f, 640f, kind = PlatformKind.PROXIMITY_DISAPPEARING, triggerX = 1_505f, delayMs = 520L),
                GamePlatform(2_320f, 620f, 460f),
                GamePlatform(2_900f, 620f, 590f, kind = PlatformKind.FALLING, delayMs = 470L),
                GamePlatform(3_610f, 620f, 650f),
                GamePlatform(4_390f, 620f, 550f),
                GamePlatform(5_070f, 620f, 530f, kind = PlatformKind.PROXIMITY_DISAPPEARING, triggerX = 5_015f, delayMs = 520L),
                GamePlatform(5_720f, 620f, 580f),
                GamePlatform(585f, 470f, 190f),
                GamePlatform(1_080f, 470f, 230f),
                GamePlatform(1_815f, 430f, 225f, kind = PlatformKind.PROXIMITY_DISAPPEARING, triggerX = 1_740f, delayMs = 500L),
                GamePlatform(2_455f, 480f, 190f),
                GamePlatform(3_255f, 390f, 235f),
                GamePlatform(4_655f, 420f, 240f),
                GamePlatform(5_345f, 470f, 205f)
            ),
            movingPlatforms = listOf(
                GameMovingPlatform(775f, 505f, 150f, 52f, vertical = false, periodSeconds = 3.2f),
                GameMovingPlatform(4_210f, 470f, 180f, 58f, vertical = true, periodSeconds = 3.0f)
            ),
            hazards = listOf(
                hiddenSpike(505f, 455f),
                hiddenSpike(1_010f, 960f),
                hiddenSpike(1_315f, 1_255f, y = 350f, height = 105f, orientation = HazardOrientation.DOWN),
                hiddenSpike(1_705f, 1_650f),
                floorFire(2_050f, phaseMs = 480L),
                hiddenSpike(2_450f, 2_395f),
                hiddenSpike(2_735f, 2_680f, y = 410f, height = 110f, orientation = HazardOrientation.LEFT),
                hiddenSpike(3_035f, 2_980f),
                hiddenSpike(3_390f, 3_335f),
                hiddenSpike(3_745f, 3_690f),
                floorFire(4_095f, phaseMs = 1_050L),
                hiddenSpike(4_545f, 4_490f),
                hiddenSpike(4_850f, 4_790f, y = 350f, height = 105f, orientation = HazardOrientation.DOWN),
                hiddenSpike(5_245f, 5_190f),
                hiddenSpike(5_485f, 5_430f),
                hiddenSpike(5_935f, 5_875f)
            ),
            barriers = listOf(
                GameBarrier(x = 2_745f, switchIndex = 0),
                GameBarrier(x = 5_565f, switchIndex = 1)
            ),
            enemies = listOf(
                GameEnemy(x = 3_120f, y = 566f, range = 105f, health = 2, kind = GameEnemyKind.WALKER, speed = 92f),
                GameEnemy(x = 5_250f, y = 566f, range = 120f, health = 2, kind = GameEnemyKind.JUMPER, speed = 98f)
            ),
            crystals = listOf(
                GameCrystal(1_170f, 378f),
                GameCrystal(3_360f, 298f),
                GameCrystal(5_930f, 528f)
            ),
            crates = listOf(GameCrate(2_525f, 426f), GameCrate(4_735f, 366f)),
            switches = listOf(
                GameSwitch(2_405f, 566f, 2_815f, reversesFans = false),
                GameSwitch(5_185f, 566f, 5_640f, reversesFans = true)
            ),
            checkpoints = listOf(
                decoyCheckpoint(690f, 470f),
                popupCheckpoint(1_585f),
                decoyCheckpoint(3_690f),
                popupCheckpoint(5_105f)
            ),
            fans = listOf(
                GameFan(3_135f, 330f, 440f, 285f, forceX = -305f, forceY = 0f, cycleMs = 2_700L, phaseMs = 350L),
                GameFan(5_005f, 350f, 180f, 265f, forceX = 0f, forceY = -430f, cycleMs = 2_500L, phaseMs = 900L, switchIndex = 1)
            ),
            fallingObjects = listOf(
                GameFallingObject(1_245f, 235f, 570f, 74f, 1_085f, FallingObjectKind.FRUIT, delayMs = 175L, behavior = FallingBehavior.EXPLODE, explosionRadius = 135f),
                GameFallingObject(2_650f, 250f, 570f, 68f, 2_470f, FallingObjectKind.FRUIT, delayMs = 160L, behavior = FallingBehavior.CHAIN, chainCount = 3, chainSpacing = 78f),
                GameFallingObject(4_080f, 230f, 570f, 76f, 3_900f, FallingObjectKind.FRUIT, delayMs = 180L, behavior = FallingBehavior.ROLL, rollDirection = -1f),
                GameFallingObject(5_405f, 245f, 570f, 72f, 5_220f, FallingObjectKind.FRUIT, delayMs = 150L, behavior = FallingBehavior.CHASE)
            ),
            chasingHoles = emptyList(),
            crushers = listOf(
                GameCrusher(1_985f, 210f, 155f, 82f, 1_770f, CrusherAxis.VERTICAL, 300f, speed = 570f, delayMs = 220L, reverseAfterMs = 940L),
                GameCrusher(4_565f, 385f, 65f, 235f, 4_330f, CrusherAxis.HORIZONTAL, -225f, speed = 590f, delayMs = 180L, reverseAfterMs = 870L)
            ),
            pickups = listOf(
                GamePickup(2_570f, 390f, GamePickupKind.SHIELD),
                GamePickup(4_770f, 330f, GamePickupKind.ENERGY)
            ),
            parSeconds = 240
        )

        2 -> extremeLevel(
            number = 2,
            width = 6_800f,
            platforms = listOf(
                GamePlatform(0f, 620f, 650f),
                GamePlatform(760f, 620f, 215f, kind = PlatformKind.SOLID),
                GamePlatform(975f, 620f, 205f, kind = PlatformKind.PROXIMITY_DISAPPEARING, triggerX = 930f, delayMs = 620L),
                GamePlatform(1_300f, 620f, 470f),
                GamePlatform(1_900f, 620f, 450f, kind = PlatformKind.SOLID),
                GamePlatform(2_480f, 620f, 520f),
                GamePlatform(3_120f, 620f, 480f, kind = PlatformKind.SOLID),
                GamePlatform(3_750f, 620f, 500f),
                GamePlatform(4_380f, 620f, 480f, kind = PlatformKind.PROXIMITY_DISAPPEARING, triggerX = 4_320f, delayMs = 500L),
                GamePlatform(5_000f, 620f, 500f),
                GamePlatform(5_630f, 620f, 520f, kind = PlatformKind.FALLING, delayMs = 460L),
                GamePlatform(6_270f, 620f, 530f),
                GamePlatform(530f, 445f, 190f),
                GamePlatform(1_050f, 470f, 210f),
                GamePlatform(1_620f, 410f, 220f),
                GamePlatform(2_180f, 470f, 180f),
                GamePlatform(2_720f, 400f, 225f),
                GamePlatform(3_320f, 455f, 195f),
                GamePlatform(4_030f, 410f, 220f),
                GamePlatform(4_115f, 505f, 225f, kind = PlatformKind.SOLID),
                GamePlatform(4_650f, 470f, 190f),
                GamePlatform(5_250f, 395f, 230f),
                GamePlatform(5_900f, 465f, 190f),
                GamePlatform(6_450f, 420f, 210f)
            ),
            movingPlatforms = listOf(
                GameMovingPlatform(1_180f, 505f, 145f, 55f, vertical = false, periodSeconds = 2.9f),
                GameMovingPlatform(2_990f, 475f, 160f, 65f, vertical = true, periodSeconds = 2.8f),
                GameMovingPlatform(6_100f, 500f, 165f, 58f, vertical = false, periodSeconds = 2.7f)
            ),
            hazards = listOf(
                hiddenSpike(390f, 335f),
                hiddenSpike(1_095f, 1_040f, y = 345f, height = 105f, orientation = HazardOrientation.DOWN),
                hiddenSpike(1_440f, 1_385f),
                floorFire(1_700f, phaseMs = 300L),
                hiddenSpike(
                    x = 2_020f,
                    triggerX = 1_965f,
                    width = 58f,
                    cycleMs = 2_300L,
                    phaseMs = 0L
                ),
                hiddenSpike(2_590f, 2_535f),
                hiddenSpike(2_900f, 2_845f),
                hiddenSpike(3_255f, 3_200f, width = 54f, cycleMs = 3_100L, phaseMs = 350L),
                hiddenSpike(4_510f, 4_455f),
                hiddenSpike(4_720f, 4_665f),
                hiddenSpike(4_790f, 4_735f),
                hiddenSpike(5_135f, 5_080f),
                hiddenSpike(5_455f, 5_400f, y = 420f, height = 115f, orientation = HazardOrientation.LEFT),
                hiddenSpike(5_780f, 5_725f),
                hiddenSpike(5_930f, 5_850f, y = 335f, height = 70f, orientation = HazardOrientation.DOWN),
                floorFire(6_050f, phaseMs = 1_260L),
                hiddenSpike(6_420f, 6_365f),
                hiddenSpike(6_560f, 6_480f, y = 330f, height = 70f, orientation = HazardOrientation.DOWN),
                hiddenSpike(2_760f, 2_705f, y = 320f, height = 100f, orientation = HazardOrientation.DOWN)
            ),
            barriers = listOf(
                GameBarrier(2_345f, switchIndex = 0),
                GameBarrier(5_500f, switchIndex = 1)
            ),
            enemies = listOf(
                GameEnemy(1_560f, 566f, range = 95f, health = 2, kind = GameEnemyKind.WALKER, speed = 96f),
                GameEnemy(2_760f, 566f, range = 105f, health = 2, kind = GameEnemyKind.JUMPER, speed = 102f),
                GameEnemy(5_220f, 566f, range = 115f, health = 2, kind = GameEnemyKind.WALKER, speed = 108f)
            ),
            crystals = listOf(
                GameCrystal(1_700f, 318f),
                GameCrystal(4_120f, 318f),
                GameCrystal(6_505f, 328f)
            ),
            crates = listOf(GameCrate(2_780f, 346f), GameCrate(5_300f, 341f)),
            switches = listOf(
                GameSwitch(2_125f, 566f, 2_335f, reversesFans = true),
                GameSwitch(5_170f, 566f, 5_570f, reversesFans = false)
            ),
            checkpoints = listOf(
                decoyCheckpoint(585f, 445f),
                popupCheckpoint(1_335f),
                popupCheckpoint(4_320f),
                popupCheckpoint(6_300f)
            ),
            fans = listOf(
                GameFan(5_710f, 335f, 175f, 280f, 0f, -390f, cycleMs = 2_750L, phaseMs = 780L)
            ),
            fallingObjects = listOf(
                GameFallingObject(1_085f, 230f, 570f, 70f, 945f, FallingObjectKind.FRUIT, 230L, FallingBehavior.ROLL, rollDirection = 1f),
                GameFallingObject(
                    2_280f, 250f, 570f, 74f, 2_105f,
                    FallingObjectKind.FRUIT,
                    delayMs = 260L,
                    behavior = FallingBehavior.EXPLODE,
                    explosionRadius = 92f,
                    explosionDelayMs = 650L
                ),
                GameFallingObject(3_470f, 235f, 570f, 68f, 3_285f, FallingObjectKind.FRUIT, 145L, FallingBehavior.CHAIN, chainCount = 4, chainSpacing = 74f),
                GameFallingObject(4_730f, 245f, 570f, 72f, 4_555f, FallingObjectKind.FRUIT, 155L, FallingBehavior.CHASE),
                GameFallingObject(6_020f, 225f, 570f, 78f, 5_835f, FallingObjectKind.FRUIT, 170L, FallingBehavior.EXPLODE, explosionRadius = 150f)
            ),
            chasingHoles = listOf(
                GameChasingHole(
                    startX = 2_525f,
                    triggerX = 2_445f,
                    width = 92f,
                    speed = 145f,
                    maxTravel = 245f,
                    surfaceStartX = 2_480f,
                    surfaceEndX = 3_000f
                ),
                GameChasingHole(
                    startX = 5_035f,
                    triggerX = 4_965f,
                    width = 105f,
                    speed = 155f,
                    maxTravel = 285f,
                    surfaceStartX = 5_000f,
                    surfaceEndX = 5_500f
                )
            ),
            crushers = listOf(
                GameCrusher(1_660f, 205f, 160f, 85f, 1_445f, CrusherAxis.VERTICAL, 305f, 600f, 180L, 900L),
                GameCrusher(4_020f, 400f, 58f, 220f, 3_720f, CrusherAxis.HORIZONTAL, -150f, 285f, 350L, 1_650L),
                GameCrusher(6_370f, 220f, 155f, 80f, 6_150f, CrusherAxis.VERTICAL, 295f, 640f, 170L, 830L)
            ),
            pickups = listOf(
                GamePickup(1_700f, 300f, GamePickupKind.ENERGY),
                GamePickup(4_115f, 300f, GamePickupKind.SHIELD)
            ),
            parSeconds = 270
        )

        3 -> extremeLevel(
            number = 3,
            width = 7_200f,
            platforms = listOf(
                GamePlatform(0f, 620f, 700f),
                GamePlatform(820f, 620f, 520f),
                GamePlatform(1_470f, 620f, 480f, kind = PlatformKind.PROXIMITY_DISAPPEARING, triggerX = 1_410f, delayMs = 500L),
                GamePlatform(2_080f, 620f, 500f),
                GamePlatform(2_720f, 620f, 520f, kind = PlatformKind.FALLING, delayMs = 470L),
                GamePlatform(3_370f, 620f, 500f),
                GamePlatform(4_000f, 620f, 520f, kind = PlatformKind.DISAPPEARING, cycleMs = 2_350L, phaseMs = 900L),
                GamePlatform(4_650f, 620f, 500f),
                GamePlatform(5_280f, 620f, 500f, kind = PlatformKind.PROXIMITY_DISAPPEARING, triggerX = 5_220f, delayMs = 380L),
                GamePlatform(5_910f, 620f, 500f),
                GamePlatform(6_540f, 620f, 660f),
                GamePlatform(540f, 455f, 190f),
                GamePlatform(1_080f, 405f, 225f),
                GamePlatform(1_720f, 470f, 190f),
                GamePlatform(2_330f, 390f, 235f),
                GamePlatform(2_980f, 465f, 190f),
                GamePlatform(3_590f, 400f, 225f),
                GamePlatform(4_250f, 470f, 190f),
                GamePlatform(4_880f, 390f, 235f),
                GamePlatform(5_520f, 465f, 190f),
                GamePlatform(6_150f, 400f, 225f),
                GamePlatform(6_770f, 465f, 200f)
            ),
            movingPlatforms = listOf(
                GameMovingPlatform(700f, 500f, 145f, 60f, false, 2.8f),
                GameMovingPlatform(1_950f, 470f, 160f, 62f, true, 2.7f),
                GameMovingPlatform(3_860f, 480f, 160f, 65f, false, 2.6f),
                GameMovingPlatform(5_770f, 475f, 165f, 65f, true, 2.6f)
            ),
            hazards = listOf(
                hiddenSpike(425f, 370f),
                hiddenSpike(875f, 820f),
                hiddenSpike(1_210f, 1_155f, y = 340f, height = 110f, orientation = HazardOrientation.DOWN),
                hiddenSpike(1_565f, 1_510f),
                floorFire(1_850f, phaseMs = 420L),
                hiddenSpike(2_170f, 2_115f),
                hiddenSpike(2_510f, 2_455f, y = 410f, height = 120f, orientation = HazardOrientation.RIGHT),
                hiddenSpike(2_840f, 2_785f),
                hiddenSpike(3_165f, 3_110f),
                floorFire(3_510f, phaseMs = 960L),
                hiddenSpike(3_780f, 3_725f, y = 340f, height = 110f, orientation = HazardOrientation.DOWN),
                hiddenSpike(4_120f, 4_065f),
                hiddenSpike(4_470f, 4_415f),
                hiddenSpike(4_810f, 4_755f, y = 410f, height = 120f, orientation = HazardOrientation.LEFT),
                floorFire(5_060f, phaseMs = 1_300L),
                hiddenSpike(5_405f, 5_350f),
                hiddenSpike(5_760f, 5_705f),
                hiddenSpike(6_080f, 6_025f, y = 340f, height = 110f, orientation = HazardOrientation.DOWN),
                hiddenSpike(6_420f, 6_365f),
                floorFire(6_830f, phaseMs = 720L)
            ),
            barriers = listOf(
                GameBarrier(2_570f, switchIndex = 0),
                GameBarrier(5_880f, switchIndex = 1)
            ),
            enemies = listOf(
                GameEnemy(1_120f, 566f, range = 110f, health = 2, kind = GameEnemyKind.JUMPER, speed = 104f),
                GameEnemy(2_420f, 566f, range = 105f, health = 2, kind = GameEnemyKind.WALKER, speed = 108f),
                GameEnemy(3_650f, 566f, range = 115f, health = 2, kind = GameEnemyKind.JUMPER, speed = 112f),
                GameEnemy(4_940f, 566f, range = 120f, health = 2, kind = GameEnemyKind.WALKER, speed = 116f),
                GameEnemy(6_220f, 566f, range = 120f, health = 2, kind = GameEnemyKind.JUMPER, speed = 120f)
            ),
            crystals = listOf(
                GameCrystal(1_170f, 313f),
                GameCrystal(3_675f, 308f),
                GameCrystal(6_255f, 308f)
            ),
            crates = listOf(GameCrate(2_415f, 336f), GameCrate(4_960f, 336f), GameCrate(6_240f, 346f)),
            switches = listOf(
                GameSwitch(2_280f, 566f, 2_640f, reversesFans = false),
                GameSwitch(5_565f, 566f, 5_950f, reversesFans = true)
            ),
            checkpoints = listOf(
                decoyCheckpoint(610f, 455f),
                popupCheckpoint(1_505f),
                decoyCheckpoint(3_430f),
                popupCheckpoint(4_680f),
                decoyCheckpoint(5_545f, 465f),
                popupCheckpoint(6_575f)
            ),
            fans = listOf(
                GameFan(2_170f, 325f, 430f, 290f, -345f, 0f, 2_250L, 250L),
                GameFan(4_730f, 325f, 430f, 290f, 350f, 0f, 2_200L, 850L),
                GameFan(6_000f, 330f, 180f, 280f, 0f, -500f, 2_150L, 1_100L, switchIndex = 1)
            ),
            fallingObjects = listOf(
                GameFallingObject(920f, 225f, 570f, 72f, 760f, FallingObjectKind.FRUIT, 150L, FallingBehavior.EXPLODE, explosionRadius = 145f),
                GameFallingObject(1_760f, 245f, 570f, 68f, 1_590f, FallingObjectKind.FRUIT, 145L, FallingBehavior.ROLL, rollDirection = -1f),
                GameFallingObject(2_520f, 230f, 570f, 72f, 2_335f, FallingObjectKind.FRUIT, 140L, FallingBehavior.CHAIN, chainCount = 4, chainSpacing = 72f),
                GameFallingObject(3_550f, 240f, 570f, 76f, 3_370f, FallingObjectKind.FRUIT, 145L, FallingBehavior.CHASE),
                GameFallingObject(4_430f, 225f, 570f, 74f, 4_250f, FallingObjectKind.FRUIT, 140L, FallingBehavior.EXPLODE, explosionRadius = 155f),
                GameFallingObject(5_380f, 245f, 570f, 70f, 5_195f, FallingObjectKind.FRUIT, 135L, FallingBehavior.CHAIN, chainCount = 5, chainSpacing = 70f),
                GameFallingObject(6_430f, 230f, 570f, 78f, 6_240f, FallingObjectKind.FRUIT, 145L, FallingBehavior.CHASE)
            ),
            chasingHoles = emptyList(),
            crushers = listOf(
                GameCrusher(1_720f, 205f, 160f, 85f, 1_490f, CrusherAxis.VERTICAL, 305f, 620f, 170L, 870L),
                GameCrusher(3_820f, 380f, 70f, 240f, 3_590f, CrusherAxis.HORIZONTAL, -240f, 645f, 160L, 820L),
                GameCrusher(5_420f, 210f, 160f, 85f, 5_190f, CrusherAxis.VERTICAL, 300f, 660f, 155L, 800L),
                GameCrusher(6_800f, 380f, 68f, 240f, 6_575f, CrusherAxis.HORIZONTAL, -230f, 675f, 150L, 790L)
            ),
            pickups = listOf(
                GamePickup(2_420f, 295f, GamePickupKind.SHIELD),
                GamePickup(4_970f, 295f, GamePickupKind.ENERGY),
                GamePickup(6_250f, 300f, GamePickupKind.SHIELD)
            ),
            parSeconds = 300
        )

        4 -> extremeLevel(
            number = 4,
            width = 7_600f,
            platforms = listOf(
                GamePlatform(0f, 620f, 690f),
                GamePlatform(810f, 620f, 500f, kind = PlatformKind.PROXIMITY_DISAPPEARING, triggerX = 750f, delayMs = 330L),
                GamePlatform(1_440f, 620f, 500f),
                GamePlatform(2_070f, 620f, 500f, kind = PlatformKind.FALLING, delayMs = 440L),
                GamePlatform(2_700f, 620f, 520f),
                GamePlatform(3_350f, 620f, 500f, kind = PlatformKind.DISAPPEARING, cycleMs = 2_250L, phaseMs = 450L),
                GamePlatform(3_980f, 620f, 510f),
                GamePlatform(4_620f, 620f, 500f, kind = PlatformKind.PROXIMITY_DISAPPEARING, triggerX = 4_560f, delayMs = 350L),
                GamePlatform(5_250f, 620f, 500f),
                GamePlatform(5_880f, 620f, 500f, kind = PlatformKind.FALLING, delayMs = 450L),
                GamePlatform(6_510f, 620f, 500f),
                GamePlatform(7_140f, 620f, 460f),
                GamePlatform(520f, 450f, 195f),
                GamePlatform(1_060f, 395f, 230f),
                GamePlatform(1_720f, 470f, 190f),
                GamePlatform(2_330f, 390f, 235f),
                GamePlatform(2_980f, 465f, 190f),
                GamePlatform(3_610f, 390f, 235f),
                GamePlatform(4_260f, 465f, 190f),
                GamePlatform(4_880f, 390f, 235f),
                GamePlatform(5_520f, 465f, 190f),
                GamePlatform(6_150f, 390f, 235f),
                GamePlatform(6_790f, 465f, 190f),
                GamePlatform(7_300f, 405f, 215f)
            ),
            movingPlatforms = listOf(
                GameMovingPlatform(690f, 500f, 145f, 60f, false, 2.7f),
                GameMovingPlatform(1_930f, 475f, 160f, 65f, true, 2.6f),
                GameMovingPlatform(3_830f, 480f, 160f, 65f, false, 2.5f),
                GameMovingPlatform(5_730f, 475f, 165f, 68f, true, 2.5f),
                GameMovingPlatform(7_010f, 490f, 155f, 58f, false, 2.4f)
            ),
            hazards = listOf(
                hiddenSpike(410f, 355f),
                hiddenSpike(860f, 805f),
                hiddenSpike(1_200f, 1_145f, y = 335f, height = 115f, orientation = HazardOrientation.DOWN),
                hiddenSpike(1_560f, 1_505f),
                floorFire(1_860f, phaseMs = 320L),
                hiddenSpike(2_180f, 2_125f),
                hiddenSpike(2_500f, 2_445f, y = 405f, height = 125f, orientation = HazardOrientation.RIGHT),
                hiddenSpike(2_830f, 2_775f),
                hiddenSpike(3_170f, 3_115f),
                floorFire(3_510f, phaseMs = 810L),
                hiddenSpike(3_770f, 3_715f, y = 335f, height = 115f, orientation = HazardOrientation.DOWN),
                hiddenSpike(4_110f, 4_055f),
                hiddenSpike(4_450f, 4_395f),
                hiddenSpike(4_790f, 4_735f, y = 405f, height = 125f, orientation = HazardOrientation.LEFT),
                floorFire(5_060f, phaseMs = 1_160L),
                hiddenSpike(5_400f, 5_345f),
                hiddenSpike(5_740f, 5_685f),
                hiddenSpike(6_080f, 6_025f, y = 335f, height = 115f, orientation = HazardOrientation.DOWN),
                hiddenSpike(6_420f, 6_365f),
                floorFire(6_760f, phaseMs = 540L),
                hiddenSpike(7_100f, 7_045f),
                hiddenSpike(7_420f, 7_365f)
            ),
            barriers = listOf(
                GameBarrier(2_555f, switchIndex = 0),
                GameBarrier(5_730f, switchIndex = 1)
            ),
            enemies = listOf(
                GameEnemy(1_120f, 566f, range = 110f, health = 2, kind = GameEnemyKind.JUMPER, speed = 108f),
                GameEnemy(2_390f, 566f, range = 110f, health = 2, kind = GameEnemyKind.WALKER, speed = 112f),
                GameEnemy(3_660f, 566f, range = 120f, health = 2, kind = GameEnemyKind.JUMPER, speed = 116f),
                GameEnemy(4_940f, 566f, range = 120f, health = 2, kind = GameEnemyKind.WALKER, speed = 120f),
                GameEnemy(6_220f, 566f, range = 125f, health = 2, kind = GameEnemyKind.JUMPER, speed = 124f),
                GameEnemy(7_300f, 566f, range = 105f, health = 2, kind = GameEnemyKind.WALKER, speed = 128f)
            ),
            crystals = listOf(
                GameCrystal(1_165f, 303f),
                GameCrystal(3_700f, 298f),
                GameCrystal(6_240f, 298f)
            ),
            crates = listOf(GameCrate(2_415f, 336f), GameCrate(4_970f, 336f), GameCrate(6_235f, 336f)),
            switches = listOf(
                GameSwitch(2_280f, 566f, 2_625f, reversesFans = true),
                GameSwitch(5_535f, 566f, 5_800f, reversesFans = false)
            ),
            checkpoints = listOf(
                decoyCheckpoint(585f, 450f),
                popupCheckpoint(1_475f),
                decoyCheckpoint(2_940f, 465f),
                popupCheckpoint(4_010f),
                decoyCheckpoint(5_555f, 465f),
                popupCheckpoint(6_660f)
            ),
            fans = listOf(
                GameFan(2_150f, 320f, 440f, 295f, -365f, 0f, 2_150L, 250L, switchIndex = 0),
                GameFan(4_700f, 320f, 440f, 295f, 370f, 0f, 2_100L, 780L),
                GameFan(6_050f, 325f, 180f, 290f, 0f, -520f, 2_050L, 1_120L)
            ),
            fallingObjects = listOf(
                GameFallingObject(920f, 225f, 570f, 72f, 760f, FallingObjectKind.FRUIT, 145L, FallingBehavior.EXPLODE, explosionRadius = 150f),
                GameFallingObject(1_760f, 245f, 570f, 70f, 1_585f, FallingObjectKind.FRUIT, 140L, FallingBehavior.ROLL, rollDirection = -1f),
                GameFallingObject(2_510f, 225f, 570f, 72f, 2_330f, FallingObjectKind.FRUIT, 135L, FallingBehavior.CHAIN, chainCount = 5, chainSpacing = 70f),
                GameFallingObject(3_540f, 240f, 570f, 78f, 3_355f, FallingObjectKind.FRUIT, 135L, FallingBehavior.CHASE),
                GameFallingObject(4_430f, 225f, 570f, 76f, 4_245f, FallingObjectKind.FRUIT, 135L, FallingBehavior.EXPLODE, explosionRadius = 160f),
                GameFallingObject(5_370f, 245f, 570f, 72f, 5_185f, FallingObjectKind.FRUIT, 130L, FallingBehavior.CHAIN, chainCount = 5, chainSpacing = 70f),
                GameFallingObject(6_420f, 225f, 570f, 80f, 6_230f, FallingObjectKind.FRUIT, 130L, FallingBehavior.CHASE),
                GameFallingObject(7_270f, 235f, 570f, 78f, 7_080f, FallingObjectKind.FRUIT, 130L, FallingBehavior.EXPLODE, explosionRadius = 165f)
            ),
            chasingHoles = listOf(
                GameChasingHole(
                    startX = 2_710f,
                    triggerX = 2_635f,
                    width = 120f,
                    speed = 180f,
                    maxTravel = 370f,
                    surfaceStartX = 2_700f,
                    surfaceEndX = 3_220f
                )
            ),
            crushers = listOf(
                GameCrusher(1_700f, 200f, 165f, 88f, 1_465f, CrusherAxis.VERTICAL, 310f, 650f, 160L, 830L),
                GameCrusher(3_800f, 375f, 72f, 245f, 3_565f, CrusherAxis.HORIZONTAL, -245f, 675f, 150L, 790L),
                GameCrusher(5_410f, 205f, 165f, 88f, 5_175f, CrusherAxis.VERTICAL, 305f, 700f, 145L, 760L),
                GameCrusher(6_790f, 375f, 72f, 245f, 6_555f, CrusherAxis.HORIZONTAL, -240f, 720f, 140L, 740L),
                GameCrusher(7_330f, 205f, 160f, 85f, 7_105f, CrusherAxis.VERTICAL, 300f, 735f, 135L, 720L)
            ),
            pickups = listOf(
                GamePickup(2_415f, 295f, GamePickupKind.SHIELD),
                GamePickup(4_970f, 295f, GamePickupKind.ENERGY),
                GamePickup(6_240f, 295f, GamePickupKind.SHIELD)
            ),
            parSeconds = 330
        )

        else -> error("Los niveles extremos hechos a mano solo existen del 1 al 4")
    }

    fun build(number: Int): AdventureLevel {
        val level = number.coerceIn(1, GeoGameRules.LEVEL_COUNT)
        if (level in 1..4) return stabilizeLevel(buildExtremeLevel(level))
        val world = (level - 1) / 5
        val width = 10_800f + level * 520f
        val platforms = mutableListOf<GamePlatform>()
        val moving = mutableListOf<GameMovingPlatform>()
        val hazards = mutableListOf<GameHazard>()
        val barriers = mutableListOf<GameBarrier>()
        val enemies = mutableListOf<GameEnemy>()
        val crates = mutableListOf<GameCrate>()
        val switches = mutableListOf<GameSwitch>()
        val pickups = mutableListOf<GamePickup>()
        val fans = mutableListOf<GameFan>()
        val fallingObjects = mutableListOf<GameFallingObject>()
        val chasingHoles = mutableListOf<GameChasingHole>()
        val crushers = mutableListOf<GameCrusher>()

        val requiredMechanisms = (2 + (level - 1) / 5).coerceAtMost(5)
        var x = 0f
        var segment = 0
        while (x < width - 900f) {
            val length = (570f - level * 5f + ((segment * 79 + level * 43) % 230)).coerceIn(330f, 690f)
            val gap = (92f + level * 3.4f + (segment % 4) * 22f).coerceAtMost(280f)
            val kind = when {
                segment == 0 -> PlatformKind.SOLID
                level <= 4 && segment % 5 == 1 -> PlatformKind.PROXIMITY_DISAPPEARING
                level <= 4 && segment % 5 == 2 -> PlatformKind.FALLING
                level <= 4 && segment % 7 == 3 -> PlatformKind.DISAPPEARING
                (segment + level) % 11 == 0 -> PlatformKind.REVEALING
                (segment * 2 + level) % 9 == 0 -> PlatformKind.FALLING
                level >= 4 && (segment + level * 2) % 13 == 0 -> PlatformKind.DISAPPEARING
                level >= 7 && (segment + level) % 17 == 0 -> PlatformKind.BOUNCE
                else -> PlatformKind.SOLID
            }
            platforms += GamePlatform(
                x = x,
                y = 620f,
                width = min(length, width - x),
                kind = kind,
                triggerX = if (level <= 4) x - 38f else x - 120f,
                delayMs = if (level <= 4) (185L - level * 15L).coerceAtLeast(110L) else (460L - level * 11L).coerceAtLeast(150L),
                cycleMs = (2_700L - level * 45L).coerceAtLeast(1_450L),
                phaseMs = (segment * 310L) % 1_400L
            )

            if (segment > 0) {
                val upperY = 505f - ((segment + level) % 3) * 56f
                val upperKind = when {
                    level <= 4 && segment % 4 == 1 -> PlatformKind.PROXIMITY_DISAPPEARING
                    (segment + level) % 8 == 0 -> PlatformKind.FALLING
                    level >= 5 && (segment + level) % 10 == 0 -> PlatformKind.REVEALING
                    else -> PlatformKind.SOLID
                }
                platforms += GamePlatform(
                    x = x + 92f + (segment % 2) * 65f,
                    y = upperY,
                    width = (180f + (segment % 4) * 34f).coerceAtMost(length - 100f),
                    height = 27f,
                    kind = upperKind,
                    triggerX = x + 10f,
                    delayMs = 260L
                )
            }

            if (segment > 1 && (if (level <= 4) segment % 3 == 0 else (segment + level) % (7 - level / 6).coerceAtLeast(3) == 0)) {
                moving += GameMovingPlatform(
                    x = x + length + 18f,
                    y = 495f - (segment % 2) * 100f,
                    width = (178f - level * 1.7f).coerceAtLeast(118f),
                    travel = 90f + level * 5f,
                    vertical = (segment + level) % 2 == 0,
                    periodSeconds = (4.0f - level * 0.075f).coerceAtLeast(2.15f)
                )
            }

            val trapCount = if (level <= 4) 3 else 1 + level / 6
            repeat(trapCount) { trap ->
                val hx = x + 125f + trap * 125f + ((segment * 31 + trap * 19) % 70)
                if (hx < x + length - 55f) {
                    val kindHazard = when {
                        level <= 4 && (segment + trap) % 3 != 1 -> HazardKind.HIDDEN_SPIKES
                        else -> when ((segment + trap + level) % 5) {
                            0 -> HazardKind.HIDDEN_SPIKES
                            1 -> HazardKind.SAW
                            2 -> HazardKind.FIRE
                            3 -> if (level >= 6) HazardKind.CEILING_SPIKES else HazardKind.SPIKES
                            else -> HazardKind.SPIKES
                        }
                    }
                    val orientation = if (level <= 4) {
                        when ((segment + trap + level) % 4) {
                            0 -> HazardOrientation.UP
                            1 -> HazardOrientation.DOWN
                            2 -> HazardOrientation.LEFT
                            else -> HazardOrientation.RIGHT
                        }
                    } else if (kindHazard == HazardKind.CEILING_SPIKES) HazardOrientation.DOWN else HazardOrientation.UP
                    val hazardY = when (orientation) {
                        HazardOrientation.UP -> 576f
                        HazardOrientation.DOWN -> 285f + (segment % 2) * 45f
                        HazardOrientation.LEFT, HazardOrientation.RIGHT -> 455f - (trap % 2) * 105f
                    }
                    hazards += GameHazard(
                        x = hx,
                        y = hazardY,
                        width = if (orientation == HazardOrientation.LEFT || orientation == HazardOrientation.RIGHT) 46f else (58f + level * 1.7f).coerceAtMost(94f),
                        height = if (orientation == HazardOrientation.LEFT || orientation == HazardOrientation.RIGHT) 115f else if (orientation == HazardOrientation.DOWN) 100f else 44f,
                        kind = kindHazard,
                        triggerX = if (level <= 4) hx - 42f else hx - (95f + level * 2f),
                        cycleMs = if (kindHazard == HazardKind.SAW || kindHazard == HazardKind.FIRE) (2_300L - level * 38L).coerceAtLeast(1_350L) else 0L,
                        phaseMs = (segment * 240L + trap * 370L) % 1_200L,
                        orientation = orientation,
                        camouflaged = level <= 4
                    )
                }
            }

            if (segment > 1 && (if (level <= 4) segment % 3 == 1 else (segment + level) % (6 - level / 7).coerceAtLeast(3) == 0)) {
                val kindEnemy = when {
                    level >= 16 && segment % 6 == 0 -> GameEnemyKind.GUARDIAN
                    level >= 9 && segment % 5 == 0 -> GameEnemyKind.SHOOTER
                    level >= 6 && segment % 4 == 0 -> GameEnemyKind.FLYER
                    level >= 3 && segment % 3 == 0 -> GameEnemyKind.JUMPER
                    else -> GameEnemyKind.WALKER
                }
                enemies += GameEnemy(
                    x = x + length * 0.62f,
                    y = if (kindEnemy == GameEnemyKind.FLYER) 390f else 566f,
                    range = 95f + level * 6f,
                    detectionRange = 430f + level * 18f,
                    health = when {
                        level <= 4 -> 2
                        kindEnemy == GameEnemyKind.GUARDIAN -> 5 + world
                        kindEnemy == GameEnemyKind.SHOOTER -> 3 + world
                        else -> 2 + level / 10
                    },
                    kind = kindEnemy,
                    speed = if (level <= 4) 96f + level * 5f else 78f + level * 3.1f
                )
            }

            if (segment > 2 && (segment + level) % 6 == 0) {
                val vertical = (segment + level) % 2 == 0
                val fanX = x + length * 0.25f
                fans += GameFan(
                    x = fanX,
                    y = if (vertical) 365f else 455f,
                    width = if (vertical) 150f else 420f,
                    height = if (vertical) 250f else 145f,
                    forceX = if (vertical) 0f else if (segment % 4 == 0) -520f else 520f,
                    forceY = if (vertical) -(520f + level * 8f) else 0f,
                    cycleMs = (2_900L - level * 45L).coerceAtLeast(1_700L),
                    phaseMs = segment * 240L,
                    switchIndex = if (switches.isNotEmpty() && segment % 3 == 0) switches.lastIndex else null
                )
            }

            if (segment > 1 && (if (level <= 4) segment % 2 == 0 else (segment + level) % 5 == 0)) {
                val objectKind = when ((segment + level) % 4) {
                    0 -> FallingObjectKind.FRUIT
                    1 -> FallingObjectKind.ROCK
                    2 -> FallingObjectKind.CRATE
                    else -> FallingObjectKind.SPIKE_BALL
                }
                val behavior = if (level <= 4) {
                    when ((segment / 2 + level) % 4) {
                        0 -> FallingBehavior.EXPLODE
                        1 -> FallingBehavior.ROLL
                        2 -> FallingBehavior.CHAIN
                        else -> FallingBehavior.CHASE
                    }
                } else FallingBehavior.DROP
                fallingObjects += GameFallingObject(
                    x = x + length * 0.72f,
                    startY = if (level <= 4) 255f + (segment % 2) * 48f else 90f - (segment % 2) * 70f,
                    targetY = 570f,
                    size = if (level <= 4) 74f + level * 2f else 62f + level * 1.6f,
                    triggerX = if (level <= 4) x + length * 0.48f else x + length * 0.52f,
                    kind = if (level <= 4) FallingObjectKind.FRUIT else objectKind,
                    delayMs = if (level <= 4) 90L + (segment % 3) * 35L else (320L - level * 7L).coerceAtLeast(110L),
                    behavior = behavior,
                    rollDirection = if (segment % 2 == 0) -1f else 1f,
                    explosionRadius = 125f + level * 12f,
                    chainCount = if (behavior == FallingBehavior.CHAIN) 3 + level else 1,
                    chainSpacing = 82f
                )
            }

            if (level <= 4 && segment > 1 && segment % 4 == 0) {
                chasingHoles += GameChasingHole(
                    startX = x + 35f,
                    triggerX = x - 45f,
                    width = 120f + level * 12f,
                    speed = 155f + level * 28f,
                    maxTravel = length + gap + 340f,
                    direction = 1f
                )
            }

            if (level <= 4 && segment > 2 && segment % 5 == 0) {
                val horizontal = segment % 10 == 0
                crushers += GameCrusher(
                    x = if (horizontal) x + length - 58f else x + length * 0.45f,
                    y = if (horizontal) 390f else 220f,
                    width = if (horizontal) 62f else 165f,
                    height = if (horizontal) 220f else 80f,
                    triggerX = x + length * 0.28f,
                    axis = if (horizontal) CrusherAxis.HORIZONTAL else CrusherAxis.VERTICAL,
                    travel = if (horizontal) -260f else 315f,
                    speed = 610f + level * 35f,
                    delayMs = 70L + level * 15L,
                    reverseAfterMs = 720L
                )
            }

            if (switches.size < requiredMechanisms && segment > 3 && (segment + level) % 5 == 0 && length > 430f) {
                val index = switches.size
                val barrierX = x + length - 52f
                switches += GameSwitch(
                    x = x + 72f,
                    y = 566f,
                    opensAtX = barrierX + 70f,
                    reversesFans = (index + level) % 2 == 0
                )
                barriers += GameBarrier(x = barrierX, switchIndex = index)
            }

            if (segment > 2 && segment % 7 == 0) crates += GameCrate(x + 80f, 566f)
            if (segment > 2 && (segment + level) % 9 == 0) {
                pickups += GamePickup(
                    x + length * 0.82f,
                    530f,
                    when ((segment + level) % 3) {
                        0 -> GamePickupKind.SHIELD
                        1 -> GamePickupKind.POWER
                        else -> GamePickupKind.ENERGY
                    }
                )
            }

            x += length + gap
            segment++
        }
        platforms += GamePlatform(width - 900f, 620f, 900f)

        while (switches.size < requiredMechanisms) {
            val base = platforms.filter { it.y >= 600f && it.kind == PlatformKind.SOLID }
                .getOrNull((switches.size + 1) * platforms.size / (requiredMechanisms + 2))
                ?: platforms.first()
            val index = switches.size
            val sx = base.x + 72f
            if (switches.none { abs(it.x - sx) < 80f }) {
                switches += GameSwitch(sx, 566f, base.x + base.width - 40f, index % 2 == 0)
                barriers += GameBarrier(base.x + base.width - 48f, switchIndex = index)
            } else break
        }

        val checkpointCount = (4 + (level - 1) / 4).coerceAtMost(8)
        val checkpoints = mutableListOf<GameCheckpoint>()
        for (i in 1..checkpointCount) {
            val ratio = i.toFloat() / (checkpointCount + 1)
            val target = width * ratio
            val platform = platforms
                .filter { it.y >= 600f && it.width > 280f && it.kind in setOf(PlatformKind.SOLID, PlatformKind.BOUNCE) }
                .minByOrNull { abs((it.x + it.width * 0.5f) - target) }
                ?: platforms.first()
            val cx = (platform.x + platform.width * 0.25f).coerceIn(platform.x + 45f, platform.x + platform.width - 45f)
            val kind = when {
                level <= 4 && i % 2 == 1 -> CheckpointKind.DECOY
                level <= 4 && i == checkpointCount && level % 2 == 0 -> CheckpointKind.SAFE
                level <= 4 -> CheckpointKind.POPUP
                i == checkpointCount && level >= 4 -> CheckpointKind.POPUP
                level >= 2 && i == 2 && level % 3 == 0 -> CheckpointKind.DECOY
                (i + level) % 3 == 0 -> CheckpointKind.POPUP
                else -> CheckpointKind.SAFE
            }
            val revealAt = if (level <= 4 && kind == CheckpointKind.POPUP) cx - 28f else cx - 210f
            checkpoints += GameCheckpoint(cx, platform.y - 85f, kind, revealAt)
        }
        if (level <= 4) {
            hazards.removeAll { hazard ->
                checkpoints.any { checkpoint ->
                    abs((hazard.x + hazard.width / 2f) - checkpoint.x) < 105f &&
                        hazard.y + hazard.height > checkpoint.y - 20f
                }
            }
        }

        fun reachableCrystal(ratio: Float): GameCrystal {
            val target = width * ratio
            val platform = platforms
                .filter { it.kind in setOf(PlatformKind.SOLID, PlatformKind.BOUNCE, PlatformKind.REVEALING) }
                .minByOrNull { candidate ->
                    when {
                        target < candidate.x -> candidate.x - target
                        target > candidate.x + candidate.width -> target - candidate.x - candidate.width
                        else -> 0f
                    }
                } ?: platforms.first()
            val cx = target.coerceIn(platform.x + 45f, max(platform.x + 45f, platform.x + platform.width - 45f))
            return GameCrystal(cx, platform.y - 92f)
        }

        val objective = when (level) {
            in 1..4 -> "Sobrevive al troleo extremo: cada paso puede abrir un hueco, lanzar pinchos, activar frutas explosivas o convertir un checkpoint en una emboscada."
            in 5..8 -> "Combina botones, pisos falsos, objetos que caen y rutas que desaparecen."
            in 9..12 -> "Domina ventiladores, bloques invisibles, plataformas móviles y puertas encadenadas."
            in 13..16 -> "Resuelve interruptores cruzados mientras sobrevives a trampas simultáneas."
            in 17..19 -> "Avanza bajo persecución, con checkpoints sorpresa y secciones de precisión extrema."
            else -> "Supera el nivel final: todas las mecánicas aparecen combinadas y sin descanso."
        }
        val difficulty = when (level) {
            1 -> "Troleo extremo"
            2 -> "Troleo brutal"
            3 -> "Troleo pesadilla"
            4 -> "Troleo imposible"
            in 5..8 -> "Brutal"
            in 9..12 -> "Implacable"
            in 13..16 -> "Pesadilla"
            in 17..19 -> "Inhumano"
            else -> "Final imposible"
        }
        val companion = when (level) {
            in 5..10, in 17..20 -> "Luma"
            in 11..16 -> "Taro"
            else -> null
        }

        return stabilizeLevel(AdventureLevel(
            number = level,
            worldName = GeoGameRules.worldName(level),
            levelName = names[level - 1],
            objective = objective,
            difficultyLabel = difficulty,
            width = width,
            platforms = platforms,
            movingPlatforms = moving,
            hazards = hazards,
            barriers = barriers,
            enemies = enemies,
            crystals = listOf(reachableCrystal(0.19f), reachableCrystal(0.51f), reachableCrystal(0.82f)),
            crates = crates,
            switches = switches,
            checkpoints = checkpoints,
            fans = fans,
            fallingObjects = fallingObjects,
            chasingHoles = chasingHoles,
            crushers = crushers,
            requiredMechanisms = min(requiredMechanisms, switches.size),
            pickups = pickups,
            goalX = width - 205f,
            parSeconds = 190 + level * 14,
            introStory = intros[level],
            outroStory = outros[level],
            companion = companion,
            injured = level == 1,
            weaponEnabled = level >= 5,
            acechantePresent = level >= 17
        ))
    }
}
