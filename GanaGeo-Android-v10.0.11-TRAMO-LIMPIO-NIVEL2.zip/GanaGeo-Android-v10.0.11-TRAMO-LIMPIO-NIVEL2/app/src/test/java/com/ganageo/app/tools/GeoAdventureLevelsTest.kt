package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class GeoAdventureLevelsTest {
    @Test
    fun createsTwentyExtremeLevelDefinitions() {
        val levels = (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build)
        assertEquals(20, levels.size)
        levels.forEach { level ->
            assertTrue(level.width >= 6_300f)
            assertEquals(3, level.crystals.size)
            assertTrue(level.enemies.isNotEmpty())
            assertTrue(level.hazards.size >= if (level.number == 2) 8 else 10)
            assertTrue(level.checkpoints.size in 4..8)
            assertTrue(level.fans.isNotEmpty())
            assertTrue(level.fallingObjects.isNotEmpty())
            level.crystals.forEach { crystal ->
                assertTrue(level.platforms.any { platform ->
                    crystal.x in platform.x..(platform.x + platform.width) &&
                        crystal.y == platform.y - 92f
                })
            }
            assertTrue(level.platforms.any { it.x <= 70f && it.x + it.width > 70f })
            assertTrue(level.platforms.any { it.x <= level.goalX && it.x + it.width >= level.goalX })
            assertTrue(level.parSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS)
        }
    }

    @Test
    fun levelsContainTheRequestedTrapFamilies() {
        val levels = (1..20).map(GeoAdventureLevelFactory::build)
        val allPlatforms = levels.flatMap { it.platforms }
        val allHazards = levels.flatMap { it.hazards }
        val allCheckpoints = levels.flatMap { it.checkpoints }
        assertTrue(allPlatforms.any { it.kind == PlatformKind.FALLING })
        assertTrue(allPlatforms.none { it.kind == PlatformKind.DISAPPEARING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.PROXIMITY_DISAPPEARING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.REVEALING })
        assertTrue(allHazards.any { it.kind == HazardKind.HIDDEN_SPIKES })
        assertTrue(allHazards.any { it.kind == HazardKind.SAW })
        assertTrue(allHazards.any { it.kind == HazardKind.FIRE })
        assertTrue(allCheckpoints.any { it.kind == CheckpointKind.POPUP })
        assertTrue(allCheckpoints.any { it.kind == CheckpointKind.DECOY })
    }

    @Test
    fun firstFourLevelsUseFifteenLivesAndHandcraftedTrollMechanics() {
        val extreme = (1..4).map(GeoAdventureLevelFactory::build)
        extreme.forEach { level ->
            assertEquals(GeoGameRules.GAME_LIVES_PER_RUN, GeoGameRules.attemptsForLevel(level.number))
            assertTrue(level.hazards.count { it.kind == HazardKind.HIDDEN_SPIKES } >= 9)
            assertTrue(level.hazards.any { it.camouflaged })
            assertTrue(level.platforms.any { it.kind == PlatformKind.PROXIMITY_DISAPPEARING })
            assertTrue(level.fallingObjects.any { it.behavior != FallingBehavior.DROP })
            assertTrue(level.crushers.isNotEmpty())
            assertTrue(level.checkpoints.any { it.kind == CheckpointKind.DECOY })
            assertTrue(level.checkpoints.count { it.kind == CheckpointKind.POPUP } >= 2)
            assertTrue(level.enemies.all { it.health == 2 })
        }
        assertEquals(2, extreme.count { it.chasingHoles.isNotEmpty() })
        assertTrue(extreme[0].chasingHoles.isEmpty())
        assertTrue(extreme[2].chasingHoles.isEmpty())
    }

    @Test
    fun realCheckpointsDoNotSitOnLethalObjects() {
        (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build).forEach { level ->
            level.checkpoints.filter { it.kind != CheckpointKind.DECOY }.forEach { checkpoint ->
                assertTrue(level.hazards.none { hazard ->
                    abs((hazard.x + hazard.width / 2f) - checkpoint.x) < 85f &&
                        hazard.y + hazard.height > checkpoint.y - 15f
                })
                assertTrue(level.chasingHoles.none { hole ->
                    checkpoint.x in (minOf(hole.surfaceStartX, hole.surfaceEndX) - 40f)..(maxOf(hole.surfaceStartX, hole.surfaceEndX) + 40f)
                })
                assertTrue(level.fallingObjects.none { falling ->
                    abs(falling.x - checkpoint.x) < 95f
                })
            }
        }
    }

    @Test
    fun handcraftedGroundRouteNeverHasAnImpossibleStaticGap() {
        (1..4).map(GeoAdventureLevelFactory::build).forEach { level ->
            val ground = level.platforms.filter { it.y == 620f }.sortedBy { it.x }
            val merged = mutableListOf<Pair<Float, Float>>()
            ground.forEach { platform ->
                val start = platform.x
                val end = platform.x + platform.width
                val previous = merged.lastOrNull()
                if (previous == null || start > previous.second) {
                    merged += start to end
                } else {
                    merged[merged.lastIndex] = previous.first to maxOf(previous.second, end)
                }
            }
            merged.zipWithNext().forEach { (left, right) ->
                val gap = right.first - left.second
                assertTrue("Nivel ${level.number}: hueco estático de $gap", gap <= 160f)
            }
        }
    }

    @Test
    fun everyRealCheckpointHasAPermanentSolidPlatform() {
        (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build).forEach { level ->
            level.checkpoints.filter { it.kind != CheckpointKind.DECOY }.forEach { checkpoint ->
                assertTrue("Nivel ${level.number}: checkpoint real sin plataforma segura", level.platforms.any { platform ->
                    platform.kind == PlatformKind.SOLID &&
                        checkpoint.x in platform.x..(platform.x + platform.width) &&
                        abs(platform.y - (checkpoint.y + 85f)) < 0.1f
                })
            }
        }
    }

    @Test
    fun firstFourLevelsKeepSafeLandingPocketsWithoutMakingThemEasy() {
        (1..4).map(GeoAdventureLevelFactory::build).forEach { level ->
            val ground = level.platforms.filter { it.y == 620f }.sortedBy { it.x }
            ground.forEach { platform ->
                val firstPocket = (platform.x + 12f)..(platform.x + minOf(platform.width - 12f, 105f))
                val lastPocket = (platform.x + maxOf(12f, platform.width - 105f))..(platform.x + platform.width - 12f)
                assertTrue(level.hazards.none { hazard ->
                    hazard.orientation == HazardOrientation.UP &&
                        (hazard.x + hazard.width / 2f in firstPocket || hazard.x + hazard.width / 2f in lastPocket)
                })
            }
            assertTrue(level.hazards.size >= if (level.number == 2) 8 else 10)
            assertTrue(level.crushers.isNotEmpty())
        }
    }

    @Test
    fun chasingHolesAreOccasionalSurfaceBoundAndNotCrowdedByOtherTraps() {
        val levels = (1..4).map(GeoAdventureLevelFactory::build)
        val holes = levels.flatMap { level -> level.chasingHoles.map { level to it } }
        assertEquals(3, holes.size)
        assertEquals(2, levels[1].chasingHoles.size)
        holes.forEach { (level, hole) ->
            assertTrue(hole.surfaceEndX > hole.surfaceStartX + hole.width)
            assertTrue(level.platforms.any { platform ->
                platform.kind == PlatformKind.SOLID &&
                    hole.surfaceStartX >= platform.x &&
                    hole.surfaceEndX <= platform.x + platform.width &&
                    abs(platform.y - (hole.y + 28f)) <= 12f
            })
            assertTrue(level.hazards.none { hazard ->
                hazard.x + hazard.width >= hole.surfaceStartX - 85f &&
                    hazard.x <= hole.surfaceEndX + 85f
            })
            assertTrue(level.crushers.none { crusher ->
                crusher.x + crusher.width >= hole.surfaceStartX - 100f &&
                    crusher.x <= hole.surfaceEndX + 100f
            })
            assertTrue(level.fallingObjects.none { falling ->
                falling.x + falling.size >= hole.surfaceStartX - 120f &&
                    falling.x <= hole.surfaceEndX + 120f
            })
        }
    }

    @Test
    fun everyLevelHasEnoughRealCheckpointsForItsLength() {
        (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build).forEach { level ->
            val expectedMinimum = when {
                level.width <= 6_800f -> 2
                level.width <= 13_500f -> 3
                level.width <= 17_500f -> 4
                else -> 5
            }
            assertTrue("Nivel ${level.number}: pocos checkpoints reales", level.checkpoints.count { it.kind != CheckpointKind.DECOY } >= expectedMinimum)
        }
    }

    @Test
    fun allLevelsKeepAUsableLandingPocketAtEachGroundSection() {
        (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build).forEach { level ->
            level.platforms.filter { it.y >= 590f && it.width >= 170f }.forEach { platform ->
                val pocket = minOf(105f, platform.width * 0.24f)
                val firstPocket = (platform.x + 14f)..(platform.x + pocket)
                val lastPocket = (platform.x + platform.width - pocket)..(platform.x + platform.width - 14f)
                assertTrue("Nivel ${level.number}: aterrizaje totalmente bloqueado", level.hazards.none { hazard ->
                    hazard.orientation == HazardOrientation.UP &&
                        (hazard.x + hazard.width / 2f in firstPocket || hazard.x + hazard.width / 2f in lastPocket)
                })
            }
        }
    }

    @Test
    fun laterLevelsGrowLongerAndMoreDangerous() {
        val first = GeoAdventureLevelFactory.build(1)
        val middle = GeoAdventureLevelFactory.build(10)
        val last = GeoAdventureLevelFactory.build(20)
        assertTrue(last.width > first.width)
        assertTrue(last.hazards.size > first.hazards.size)
        assertTrue(last.checkpoints.size > first.checkpoints.size)
        assertTrue(middle.movingPlatforms.isNotEmpty())
        assertTrue(last.switches.size >= first.switches.size)
        assertTrue(last.acechantePresent)
    }
    @Test
    fun trollMechanicsRemainReactiveAndEscapable() {
        val levels = (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build)
        assertTrue(levels.all { it.fans.isNotEmpty() })
        assertTrue(levels.flatMap { it.hazards }.any {
            it.kind == HazardKind.HIDDEN_SPIKES && it.cycleMs > 0L
        })
        val fruits = levels.flatMap { it.fallingObjects }.filter { it.kind == FallingObjectKind.FRUIT }
        assertTrue(fruits.any {
            it.behavior == FallingBehavior.CHASE &&
                it.chaseDurationMs in 8_000L..9_000L &&
                it.chaseMaxTravel <= 1_350f
        })
        assertTrue(fruits.any { it.treeFallsAfterTrap })
    }

    @Test
    fun levelTwoAirSpikesRetractAndDoNotSealTheOnlyRoute() {
        val level = GeoAdventureLevelFactory.build(2)
        assertTrue(level.chasingHoles.size >= 2)
        assertTrue(level.hazards.filter {
            it.kind == HazardKind.HIDDEN_SPIKES && it.orientation != HazardOrientation.UP
        }.all { it.height <= 82f && it.cycleMs > 0L })
        assertTrue(level.platforms.filter { it.kind == PlatformKind.PROXIMITY_DISAPPEARING }.all { it.delayMs >= 560L })

        val repairedStart = 3_300f
        val repairedEnd = 3_600f
        assertTrue(level.hazards.none { hazard ->
            hazard.x < repairedEnd && hazard.x + hazard.width > repairedStart &&
                (hazard.kind == HazardKind.SAW || hazard.orientation == HazardOrientation.DOWN)
        })
        assertTrue(level.platforms.any { platform ->
            platform.kind == PlatformKind.SOLID && platform.x <= repairedStart && platform.x + platform.width >= repairedEnd
        })
        assertTrue("Nivel 2: el corredor obligatorio no debe tener ventiladores", level.fans.none { fan ->
            fan.x < 4_350f && fan.x + fan.width > 2_400f
        })
    }

    @Test
    fun generatedFloorsNeverDisappearOnlyBecauseTheClockAdvanced() {
        (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build).forEach { level ->
            assertTrue("Nivel ${level.number}: todavía tiene piso temporizado", level.platforms.none {
                it.kind == PlatformKind.DISAPPEARING
            })
            assertTrue(level.platforms.filter { it.kind == PlatformKind.PROXIMITY_DISAPPEARING }.all {
                it.delayMs >= 560L
            })
        }
    }

    @Test
    fun levelTwoCheckpointRouteHasARealEscapeWindow() {
        val level = GeoAdventureLevelFactory.build(2)

        val crowdedStart = 2_100f
        val crowdedEnd = 2_410f
        assertTrue("Nivel 2: todavía hay pinchos aéreos/laterales cerrando la ruta", level.hazards.none { hazard ->
            hazard.x < crowdedEnd && hazard.x + hazard.width > crowdedStart &&
                hazard.orientation != HazardOrientation.UP
        })

        val retractable = level.hazards.firstOrNull { hazard ->
            hazard.x in 1_980f..2_080f && hazard.orientation == HazardOrientation.UP
        }
        assertTrue("Nivel 2: falta el pincho retráctil aprendible", retractable != null && retractable.cycleMs >= 2_200L)

        assertTrue("Nivel 2: el piso de aterrizaje debe ser permanente", level.platforms.any { platform ->
            platform.kind == PlatformKind.SOLID && platform.x <= 1_900f && platform.x + platform.width >= 2_350f
        })

        val explosiveFruit = level.fallingObjects.firstOrNull { falling ->
            falling.kind == FallingObjectKind.FRUIT && falling.behavior == FallingBehavior.EXPLODE &&
                falling.x in 2_200f..2_350f
        }
        assertTrue("Nivel 2: la manzana explosiva sigue sin margen de escape", explosiveFruit != null &&
            explosiveFruit.explosionRadius <= 100f && explosiveFruit.explosionDelayMs >= 600L)

        assertTrue("Nivel 2: el interruptor no crea una zona de aterrizaje útil", level.switches.any { sw ->
            sw.x in 2_050f..2_180f && sw.opensAtX <= 2_350f
        })

        assertTrue("Nivel 2: sigue existiendo un checkpoint falso bajo la ruta obligatoria", level.checkpoints.none { checkpoint ->
            checkpoint.kind == CheckpointKind.DECOY && checkpoint.x in 3_400f..4_300f
        })

        assertTrue("Nivel 2: sigue existiendo fuego junto a la pared móvil", level.hazards.none { hazard ->
            hazard.kind == HazardKind.FIRE && hazard.x in 3_600f..4_250f
        })

        assertTrue("Nivel 2: el corredor obligatorio todavía tiene ventiladores", level.fans.none { fan ->
            fan.x < 4_350f && fan.x + fan.width > 2_400f
        })

        val wall = level.crushers.firstOrNull { crusher ->
            crusher.axis == CrusherAxis.HORIZONTAL && crusher.x in 3_850f..4_150f
        }
        assertTrue("Nivel 2: la pared móvil sigue demasiado rápida o larga", wall != null &&
            wall.speed <= 320f && kotlin.math.abs(wall.travel) <= 170f && wall.reverseAfterMs >= 1_500L)

        assertTrue("Nivel 2: falta plataforma estable después de la pared", level.platforms.any { platform ->
            platform.kind == PlatformKind.SOLID && platform.x <= 4_150f &&
                platform.x + platform.width >= 4_300f && platform.y in 490f..520f
        })

        assertTrue("Nivel 2: falta checkpoint real después de la sección", level.checkpoints.any { checkpoint ->
            checkpoint.kind != CheckpointKind.DECOY && checkpoint.x in 4_250f..4_450f
        })
    }

}
