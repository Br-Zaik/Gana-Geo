package com.ganageo.app.ui.tools

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import com.ganageo.app.R

internal enum class GameSound {
    JUMP,
    DOUBLE_JUMP,
    SHOOT,
    ENEMY_SHOT,
    HIT,
    CRYSTAL,
    SWITCH,
    PICKUP,
    CHECKPOINT,
    TRAP,
    FAN,
    BUTTON,
    VICTORY,
    DEFEAT
}

internal class GameAudioController(context: Context, worldIndex: Int) {
    private val appContext = context.applicationContext
    private val soundPool = SoundPool.Builder()
        .setMaxStreams(10)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val soundIds = mapOf(
        GameSound.JUMP to soundPool.load(appContext, R.raw.geo_jump, 1),
        GameSound.DOUBLE_JUMP to soundPool.load(appContext, R.raw.geo_double_jump, 1),
        GameSound.SHOOT to soundPool.load(appContext, R.raw.geo_shoot, 1),
        GameSound.ENEMY_SHOT to soundPool.load(appContext, R.raw.geo_enemy_shot, 1),
        GameSound.HIT to soundPool.load(appContext, R.raw.geo_hit, 1),
        GameSound.CRYSTAL to soundPool.load(appContext, R.raw.geo_crystal, 1),
        GameSound.SWITCH to soundPool.load(appContext, R.raw.geo_switch, 1),
        GameSound.PICKUP to soundPool.load(appContext, R.raw.geo_pickup, 1),
        GameSound.CHECKPOINT to soundPool.load(appContext, R.raw.geo_checkpoint, 1),
        GameSound.TRAP to soundPool.load(appContext, R.raw.geo_trap, 1),
        GameSound.FAN to soundPool.load(appContext, R.raw.geo_fan, 1),
        GameSound.BUTTON to soundPool.load(appContext, R.raw.geo_button, 1),
        GameSound.VICTORY to soundPool.load(appContext, R.raw.geo_victory, 1),
        GameSound.DEFEAT to soundPool.load(appContext, R.raw.geo_defeat, 1)
    )

    private val musicResource = when (worldIndex.coerceIn(0, 3)) {
        0 -> R.raw.geo_ambient_world1
        1 -> R.raw.geo_ambient_world2
        2 -> R.raw.geo_ambient_world3
        else -> R.raw.geo_ambient_world4
    }

    private var musicPlayer: MediaPlayer? = MediaPlayer.create(appContext, musicResource)?.apply {
        isLooping = true
        setVolume(0.24f, 0.24f)
    }

    var musicEnabled: Boolean = true
        private set
    var effectsEnabled: Boolean = true
        private set

    fun startMusic() {
        if (!musicEnabled) return
        runCatching { musicPlayer?.takeIf { !it.isPlaying }?.start() }
    }

    fun pauseMusic() {
        runCatching { musicPlayer?.takeIf { it.isPlaying }?.pause() }
    }

    fun setMusicEnabled(enabled: Boolean) {
        musicEnabled = enabled
        if (enabled) startMusic() else pauseMusic()
    }

    fun setEffectsEnabled(enabled: Boolean) {
        effectsEnabled = enabled
    }

    fun play(sound: GameSound, volume: Float = 1f, rate: Float = 1f) {
        if (!effectsEnabled) return
        val id = soundIds[sound] ?: return
        val safeVolume = volume.coerceIn(0f, 1f)
        soundPool.play(id, safeVolume, safeVolume, 1, 0, rate.coerceIn(0.5f, 2f))
    }

    fun release() {
        runCatching {
            musicPlayer?.stop()
            musicPlayer?.release()
        }
        musicPlayer = null
        soundPool.release()
    }
}
