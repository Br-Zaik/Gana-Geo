package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class GeoGameRulesTest {
    @Test
    fun freeLivesUseFiveSlotsAndRecoverEveryThirtyMinutes() {
        assertEquals(5, GeoGameRules.MAX_FREE_LIVES)
        assertEquals(30, GeoGameRules.FREE_LIFE_RECOVERY_MINUTES)
        assertEquals(10, GeoGameRules.ATTEMPTS_PER_LIFE)
    }

    @Test
    fun lifePackagesKeepTwoCreditsPerPremiumLife() {
        GeoGameRules.lifePackages.forEach { pack ->
            assertEquals(pack.lives * GeoGameRules.PREMIUM_LIFE_CREDIT_COST, pack.creditCost)
        }
        assertNull(GeoGameRules.packageByCode("unknown"))
    }

    @Test
    fun premiumRewardsStillActivateAfterTwentySeconds() {
        assertEquals(20, GeoGameRules.PREMIUM_ACTIVATION_SECONDS)
    }

    @Test
    fun starsNeverDependOnRewardsOrLifeType() {
        assertEquals(0, GeoGameRules.calculateStars(false, 3, 10, 60))
        assertEquals(1, GeoGameRules.calculateStars(true, 0, 80, 60))
        assertEquals(2, GeoGameRules.calculateStars(true, 3, 80, 60))
        assertEquals(3, GeoGameRules.calculateStars(true, 3, 50, 60))
    }

    @Test
    fun twentyLevelsAreSplitIntoFourWorlds() {
        assertEquals("Selva de las trampas", GeoGameRules.worldName(1))
        assertEquals("Bosque de los engaños", GeoGameRules.worldName(6))
        assertEquals("Ruinas del viento", GeoGameRules.worldName(11))
        assertEquals("Montañas imposibles", GeoGameRules.worldName(20))
    }
}
