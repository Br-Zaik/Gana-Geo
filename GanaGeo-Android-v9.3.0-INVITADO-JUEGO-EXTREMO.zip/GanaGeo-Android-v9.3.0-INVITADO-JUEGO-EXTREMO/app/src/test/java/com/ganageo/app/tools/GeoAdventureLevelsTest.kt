package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeoAdventureLevelsTest {
    @Test
    fun createsTwentyLongExtremeLevelDefinitions() {
        val levels = (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build)
        assertEquals(20, levels.size)
        levels.forEach { level ->
            assertTrue(level.width >= 11_000f)
            assertEquals(3, level.crystals.size)
            assertTrue(level.enemies.isNotEmpty())
            assertTrue(level.hazards.size >= 12)
            assertTrue(level.checkpoints.size in 4..8)
            assertTrue(level.fans.isNotEmpty())
            assertTrue(level.fallingObjects.isNotEmpty())
            level.crystals.forEach { crystal ->
                assertTrue(level.platforms.any { platform ->
                    crystal.x in platform.x..(platform.x + platform.width) &&
                        crystal.y == platform.y - 92f
                })
            }
            assertTrue(level.platforms.any { it.x <= 70f && it.x + it.width > 70f })
            assertTrue(level.platforms.any { it.x <= level.goalX && it.x + it.width >= level.goalX })
            assertTrue(level.parSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS)
        }
    }

    @Test
    fun levelsContainTheRequestedTrapFamilies() {
        val levels = (1..20).map(GeoAdventureLevelFactory::build)
        val allPlatforms = levels.flatMap { it.platforms }
        val allHazards = levels.flatMap { it.hazards }
        val allCheckpoints = levels.flatMap { it.checkpoints }
        assertTrue(allPlatforms.any { it.kind == PlatformKind.FALLING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.DISAPPEARING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.REVEALING })
        assertTrue(allHazards.any { it.kind == HazardKind.HIDDEN_SPIKES })
        assertTrue(allHazards.any { it.kind == HazardKind.SAW })
        assertTrue(allHazards.any { it.kind == HazardKind.FIRE })
        assertTrue(allCheckpoints.any { it.kind == CheckpointKind.POPUP })
        assertTrue(allCheckpoints.any { it.kind == CheckpointKind.DECOY })
    }

    @Test
    fun laterLevelsGrowLongerAndMoreDangerous() {
        val first = GeoAdventureLevelFactory.build(1)
        val middle = GeoAdventureLevelFactory.build(10)
        val last = GeoAdventureLevelFactory.build(20)
        assertTrue(last.width > first.width)
        assertTrue(last.hazards.size > first.hazards.size)
        assertTrue(last.checkpoints.size > first.checkpoints.size)
        assertTrue(middle.movingPlatforms.isNotEmpty())
        assertTrue(last.switches.size >= first.switches.size)
        assertTrue(last.acechantePresent)
    }
}
