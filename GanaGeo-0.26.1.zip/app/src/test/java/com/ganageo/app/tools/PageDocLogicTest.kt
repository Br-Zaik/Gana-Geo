package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Test

class PageDocLogicTest {

    @Test
    fun hojaIgualNoCambiaNada() {
        val frame = PageFrame(1.4f, 1.4f)
        assertEquals(1f, frame.scale, 0.0001f)
        assertEquals(0.3f, frame.x(0.3f), 0.0001f)
        assertEquals(0.7f, frame.y(0.7f), 0.0001f)
        assertEquals(0.25f, frame.w(0.25f), 0.0001f)
    }

    @Test
    fun hojaCuadradaDentroDeUnaAngostaSeAchicaYSeCentra() {
        val frame = PageFrame(1f, 0.5f)
        assertEquals(0.5f, frame.scale, 0.0001f)
        assertEquals(0.4f, frame.x(0.4f), 0.0001f)
        assertEquals(0.45f, frame.y(0.4f), 0.0001f)
        assertEquals(0.2f, frame.w(0.2f), 0.0001f)
        assertEquals(0.1f, frame.h(0.2f), 0.0001f)
        assertEquals(0.2f, frame.dyToSource(0.1f), 0.0001f)
        assertEquals(0.1f, frame.dxToSource(0.1f), 0.0001f)
    }

    @Test
    fun juntaElTituloDeDosLineasEnUnParrafo() {
        val lines = listOf(
            OcrLine("1.- ¿QUE ES LA TOPOGRAFIA?", 50, 300, 400, 330),
            OcrLine("TOPOGRAFIA SUPERFICIAL", 400, 140, 600, 170),
            OcrLine("PRIMER EXAMEN DE LA UNIDAD DIDACTICA DE", 300, 100, 700, 130),
            OcrLine("NOMBRE Y APELLIDO:", 50, 220, 300, 250)
        )
        val groups = OcrTextRefiner.paragraphs(lines, 1000) { _, _ -> true }.map { it.toList() }
        assertEquals(listOf(listOf(2, 1), listOf(3), listOf(0)), groups)
    }

    @Test
    fun estiloDistintoSeparaLosRenglones() {
        val lines = listOf(
            OcrLine("PRIMER EXAMEN DE LA UNIDAD DIDACTICA DE", 300, 100, 700, 130),
            OcrLine("TOPOGRAFIA SUPERFICIAL", 400, 140, 600, 170)
        )
        val groups = OcrTextRefiner.paragraphs(lines, 1000) { _, _ -> false }.map { it.toList() }
        assertEquals(listOf(listOf(0), listOf(1)), groups)
    }

    @Test
    fun reconoceJustificadoYCentrado() {
        val justified = listOf(
            OcrLine("uno", 100, 100, 900, 130),
            OcrLine("dos", 100, 140, 900, 170),
            OcrLine("tres", 100, 180, 600, 210)
        )
        assertEquals(OcrTextRefiner.ALIGN_JUSTIFY, OcrTextRefiner.alignmentOf(justified, 1000))
        val centered = listOf(
            OcrLine("uno", 300, 100, 700, 130),
            OcrLine("dos", 400, 140, 600, 170)
        )
        assertEquals(OcrTextRefiner.ALIGN_CENTER, OcrTextRefiner.alignmentOf(centered, 1000))
    }
}
