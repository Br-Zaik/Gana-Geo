package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Test

class TextRunsTest {
    private val base = CharStyle()
    private val bold = CharStyle(bold = true)

    @Test
    fun negritaEnUnaPalabra() {
        // "hola mundo": se pone en negrita "mundo" (letras 5 a 10).
        val runs = TextRuns.apply(10, base, emptyList(), 5, 10) { it.copy(bold = true) }
        assertEquals(listOf(StyleRun(5, 10, bold)), runs)
        // Quitarla deja el párrafo sin tramos.
        val cleared = TextRuns.apply(10, base, runs, 5, 10) { it.copy(bold = false) }
        assertEquals(emptyList<StyleRun>(), cleared)
    }

    @Test
    fun tramosCubrenTodoElTexto() {
        val runs = listOf(StyleRun(5, 10, bold))
        assertEquals(
            listOf(StyleRun(0, 5, base), StyleRun(5, 10, bold)),
            TextRuns.segments(10, base, runs)
        )
    }

    @Test
    fun alEscribirLoNuevoHeredaElEstiloDeAlLado() {
        val runs = listOf(StyleRun(5, 10, bold))
        // Se escribe "s" al final: "hola mundo" -> "hola mundos". Sigue en negrita.
        assertEquals(listOf(StyleRun(5, 11, bold)), TextRuns.remap("hola mundo", "hola mundos", base, runs))
        // Se escribe "X" al inicio: todo se corre una letra.
        assertEquals(listOf(StyleRun(6, 11, bold)), TextRuns.remap("hola mundo", "Xhola mundo", base, runs))
        // Se borra "mundo": no queda nada en negrita.
        assertEquals(emptyList<StyleRun>(), TextRuns.remap("hola mundo", "hola ", base, runs))
    }
}
