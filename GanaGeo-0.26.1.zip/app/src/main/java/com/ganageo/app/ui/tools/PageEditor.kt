package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.net.Uri
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Redo
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.ganageo.app.tools.CharStyle
import com.ganageo.app.tools.PageFrame
import com.ganageo.app.tools.StyleRun
import com.ganageo.app.tools.TextRuns
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

// Colores propios del editor.
private val EditorBackground = Color(0xFF0A120E)
private val EditorBar = Color(0xFF101D16)
private val EditorChipIdle = Color(0xFF1A2B22)
private val EditorChipOn = Color(0xFF2A4A1A)
private val EditorInk = Color(0xFFE6EFE9)
private val EditorMuted = Color(0xFF8FA398)
private val EditorFocus = Color(0xFF3D8BFF)
private val EditorDanger = Color(0xFFFF8A80)
private const val EditorSignatureInk = 0xFF10233F.toInt()

private const val EDITOR_UNDO_LIMIT = 60
private const val EDITOR_TYPING_PAUSE_MS = 1500L
private const val EDITOR_IMAGE_MAX_EDGE = 1400

private val EditorPalette = listOf(
    0xFF000000.toInt(),
    0xFF4A4A4A.toInt(),
    0xFFFFFFFF.toInt(),
    0xFFC62828.toInt(),
    0xFF1565C0.toInt(),
    0xFF1B2A41.toInt(),
    0xFF2E7D32.toInt(),
    0xFFEF6C00.toInt(),
    0xFF6A1B9A.toInt()
)

private class EditorPagePreset(val label: String, val ratio: Float?)

private val EditorPagePresets = listOf(
    EditorPagePreset("Original", null),
    EditorPagePreset("A4", 210f / 297f),
    EditorPagePreset("A4 echada", 297f / 210f),
    EditorPagePreset("Carta", 8.5f / 11f),
    EditorPagePreset("Oficio", 8.5f / 13f)
)

/**
 * Editor de documentos del escáner, hecho desde cero.
 *
 * - El texto se dibuja como texto real: nítido con cualquier zoom.
 * - Cada bloque es un párrafo: al escribir, el texto baja solo al otro renglón.
 * - Se toca y aparece el cursor ahí mismo. Con una palabra seleccionada, el
 *   estilo (negrita, color, tamaño) se aplica solo a esa palabra.
 * - Modo "Mover": se arrastra cualquier bloque y se cambia su tamaño.
 * - Se puede agregar texto, una imagen de la galería y una firma.
 * - Lo que se ve es el mismo documento que se guarda en PDF, Word o imagen.
 */
@Composable
internal fun PageEditor(
    doc: PageDoc,
    saving: Boolean,
    onDocChange: (PageDoc) -> Unit,
    onBack: () -> Unit,
    onSave: (PageDoc) -> Unit
) {
    var current by remember { mutableStateOf(doc) }
    var undoStack by remember { mutableStateOf<List<PageDoc>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<PageDoc>>(emptyList()) }
    var viewZoom by remember { mutableFloatStateOf(1f) }

    // Texto que se está escribiendo y qué parte está seleccionada.
    var focusedId by remember { mutableIntStateOf(-1) }
    var focusedSelection by remember { mutableStateOf(TextRange.Zero) }
    var showColors by remember { mutableStateOf(false) }
    var showPage by remember { mutableStateOf(false) }

    // Modo mover: bloque elegido y lo que se lleva arrastrado (en píxeles de pantalla).
    var moveMode by remember { mutableStateOf(false) }
    var selectedId by remember { mutableIntStateOf(-1) }
    var dragDelta by remember { mutableStateOf(Offset.Zero) }
    var resizeDelta by remember { mutableStateOf(Offset.Zero) }

    var showSignature by remember { mutableStateOf(false) }
    var busyMessage by remember { mutableStateOf<String?>(null) }

    // Para no guardar un "deshacer" por cada letra: uno por pausa al escribir.
    var typingBlockId by remember { mutableIntStateOf(-1) }
    var typingAt by remember { mutableLongStateOf(0L) }

    val focusManager = LocalFocusManager.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val verticalScroll = rememberScrollState()
    val horizontalScroll = rememberScrollState()
    // Medidas de la hoja en pantalla: [ancho, alto, alto visible]. Se actualizan al dibujar.
    val pageMetrics = remember { FloatArray(3) { 1f } }
    val frame = remember(current.sourceAspect, current.aspect) {
        PageFrame(current.sourceAspect, current.aspect)
    }

    fun commit(next: PageDoc, typingIn: Int = -1) {
        if (next == current) return
        val now = SystemClock.elapsedRealtime()
        val sameTyping = typingIn >= 0 && typingIn == typingBlockId && now - typingAt < EDITOR_TYPING_PAUSE_MS
        if (!sameTyping) {
            undoStack = (undoStack + current).takeLast(EDITOR_UNDO_LIMIT)
        }
        redoStack = emptyList()
        typingBlockId = typingIn
        typingAt = now
        current = next
        onDocChange(next)
    }

    fun undo() {
        val previous = undoStack.lastOrNull() ?: return
        undoStack = undoStack.dropLast(1)
        redoStack = (redoStack + current).takeLast(EDITOR_UNDO_LIMIT)
        typingBlockId = -1
        current = previous
        onDocChange(previous)
    }

    fun redo() {
        val next = redoStack.lastOrNull() ?: return
        redoStack = redoStack.dropLast(1)
        undoStack = (undoStack + current).takeLast(EDITOR_UNDO_LIMIT)
        typingBlockId = -1
        current = next
        onDocChange(next)
    }

    fun replaceBlock(id: Int, change: (PageBlock) -> PageBlock, typingIn: Int = -1) {
        commit(current.copy(blocks = current.blocks.map { if (it.id == id) change(it) else it }), typingIn)
    }

    fun nextId(): Int = (current.blocks.maxOfOrNull { it.id } ?: 0) + 1

    val focusedText = current.blocks.firstOrNull { it.id == focusedId } as? PageText
    val selectedBlock = if (moveMode) current.blocks.firstOrNull { it.id == selectedId } else null

    // ---------------- Estilo del texto ----------------

    // Rango al que se aplica el estilo: la selección, o todo el párrafo si no hay.
    fun styleRange(target: PageText): Pair<Int, Int> {
        val length = target.text.length
        val first = min(focusedSelection.start, focusedSelection.end).coerceIn(0, length)
        val last = max(focusedSelection.start, focusedSelection.end).coerceIn(0, length)
        return if (first == last) Pair(0, length) else Pair(first, last)
    }

    fun styleFocused(change: (CharStyle) -> CharStyle) {
        val target = focusedText ?: return
        val length = target.text.length
        val (from, to) = styleRange(target)
        val base = target.baseStyle()
        val updated = if (from == 0 && to == length) {
            // Todo el párrafo: cambia también el estilo base (lo que se escriba después).
            val newBase = change(base)
            val styles = TextRuns.resolve(length, base, target.runs)
            for (index in styles.indices) styles[index] = change(styles[index])
            target.withBase(newBase).copy(runs = TextRuns.compress(styles, newBase))
        } else {
            target.copy(runs = TextRuns.apply(length, base, target.runs, from, to, change))
        }
        replaceBlock(target.id, { updated })
    }

    fun resizeFocused(factor: Float) {
        val target = focusedText ?: return
        val length = target.text.length
        val (from, to) = styleRange(target)
        if (from == 0 && to == length) {
            replaceBlock(target.id, { target.copy(size = (target.size * factor).coerceIn(0.004f, 0.4f)) })
        } else {
            styleFocused { it.copy(scale = (it.scale * factor).coerceIn(0.4f, 4f)) }
        }
    }

    // ---------------- Bloques ----------------

    fun exitMoveMode() {
        dragDelta = Offset.Zero
        resizeDelta = Offset.Zero
        moveMode = false
        selectedId = -1
    }

    fun enterMoveMode(select: Int = -1) {
        focusManager.clearFocus()
        focusedId = -1
        showColors = false
        showPage = false
        dragDelta = Offset.Zero
        resizeDelta = Offset.Zero
        selectedId = select
        moveMode = true
    }

    fun finishDrag() {
        val moved = dragDelta
        dragDelta = Offset.Zero
        if (abs(moved.x) < 1f && abs(moved.y) < 1f) return
        val dx = frame.dxToSource(moved.x / pageMetrics[0].coerceAtLeast(1f))
        val dy = frame.dyToSource(moved.y / pageMetrics[1].coerceAtLeast(1f))
        replaceBlock(selectedId, { it.movedBy(dx, dy) })
    }

    fun finishResize() {
        val grown = resizeDelta
        resizeDelta = Offset.Zero
        if (abs(grown.x) < 1f && abs(grown.y) < 1f) return
        val dw = frame.dxToSource(grown.x / pageMetrics[0].coerceAtLeast(1f))
        val dh = frame.dyToSource(grown.y / pageMetrics[1].coerceAtLeast(1f))
        replaceBlock(selectedId, { it.resizedBy(dw, dh) })
    }

    fun deleteBlock(id: Int) {
        if (id < 0) return
        focusManager.clearFocus()
        if (focusedId == id) focusedId = -1
        if (selectedId == id) selectedId = -1
        commit(current.copy(blocks = current.blocks.filterNot { it.id == id }))
    }

    fun duplicateSelected() {
        val source = selectedBlock ?: return
        val id = nextId()
        commit(current.copy(blocks = current.blocks + source.copyWithId(id, 0.02f, 0.02f)))
        selectedId = id
    }

    // Centro de lo que se ve ahora en pantalla, en medidas de la hoja original.
    fun visibleCenter(): Offset {
        val pageHeightPx = pageMetrics[1].coerceAtLeast(1f)
        val centerY = ((verticalScroll.value + pageMetrics[2] / 2f) / pageHeightPx).coerceIn(0.06f, 0.94f)
        return Offset(
            frame.sourceX(0.5f).coerceIn(0.05f, 0.95f),
            frame.sourceY(centerY).coerceIn(0.05f, 0.95f)
        )
    }

    fun addText() {
        val sizes = current.blocks.filterIsInstance<PageText>().map { it.size }.sorted()
        val size = if (sizes.isEmpty()) 0.018f else sizes[sizes.size / 2]
        val family = current.blocks.filterIsInstance<PageText>().firstOrNull()?.family ?: 0
        val center = visibleCenter()
        val width = 0.42f
        val id = nextId()
        commit(
            current.copy(
                blocks = current.blocks + PageText(
                    id = id,
                    x = (center.x - width / 2f).coerceIn(0f, 1f - width),
                    y = center.y.coerceIn(0f, 0.95f),
                    w = width,
                    h = size * 1.4f,
                    text = "Texto nuevo",
                    size = size,
                    family = family
                )
            )
        )
        enterMoveMode(id)
    }

    fun addImage(bitmap: Bitmap) {
        if (bitmap.width < 2 || bitmap.height < 2) return
        val imageAspect = bitmap.width.toFloat() / bitmap.height.toFloat()
        var width = 0.4f
        var height = width * current.sourceAspect / imageAspect
        if (height > 0.45f) {
            val shrink = 0.45f / height
            width *= shrink
            height *= shrink
        }
        val center = visibleCenter()
        val id = nextId()
        commit(
            current.copy(
                blocks = current.blocks + PageImage(
                    id = id,
                    x = (center.x - width / 2f).coerceIn(0f, (1f - width).coerceAtLeast(0f)),
                    y = (center.y - height / 2f).coerceIn(0f, (1f - height).coerceAtLeast(0f)),
                    w = width,
                    h = height,
                    bitmap = bitmap
                )
            )
        )
        enterMoveMode(id)
    }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            busyMessage = "Abriendo la imagen…"
            scope.launch {
                val loaded = runCatching {
                    ToolFileUtils.loadBitmap(context, uri, maxEdge = EDITOR_IMAGE_MAX_EDGE)
                }.getOrNull()
                busyMessage = null
                if (loaded != null) addImage(loaded)
            }
        }
    }

    fun leave() {
        focusManager.clearFocus()
        onDocChange(current)
        onBack()
    }

    // Formas debajo, imágenes en medio y textos encima (igual que al guardar).
    val orderedBlocks = remember(current.blocks) {
        current.blocks.sortedBy {
            when (it) {
                is PageShape -> 0
                is PageImage -> 1
                is PageText -> 2
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(EditorBackground)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .imePadding()
        ) {
            // ---------------- Barra de arriba ----------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .background(EditorBar)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { leave() }) {
                    Icon(Icons.Rounded.ArrowBack, "Volver", tint = EditorInk)
                }
                Text("Editor", color = EditorInk, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.weight(1f))
                if (viewZoom > 1.01f) {
                    Text(
                        "${(viewZoom * 100).roundToInt()}%",
                        color = EditorMuted,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { viewZoom = 1f }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
                IconButton(onClick = { undo() }, enabled = undoStack.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Undo,
                        "Deshacer",
                        tint = if (undoStack.isNotEmpty()) EditorInk else Color(0xFF4A5A51)
                    )
                }
                IconButton(onClick = { redo() }, enabled = redoStack.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Redo,
                        "Rehacer",
                        tint = if (redoStack.isNotEmpty()) EditorInk else Color(0xFF4A5A51)
                    )
                }
                Box(
                    modifier = Modifier
                        .padding(start = 4.dp, end = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (saving) Color(0xFF5E7F1A) else NeonGreen)
                        .clickable(enabled = !saving) {
                            focusManager.clearFocus()
                            exitMoveMode()
                            onDocChange(current)
                            onSave(current)
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        if (saving) "Guardando…" else "Guardar",
                        color = DeepGreen,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            }
            if (saving || busyMessage != null) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

            // ---------------- Hoja ----------------
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clipToBounds()
            ) {
                val density = LocalDensity.current
                val aspect = current.aspect.coerceIn(0.35f, 2.8f)
                val basePageWidth = (maxWidth - 16.dp).coerceAtLeast(180.dp)
                val pageWidth = basePageWidth * viewZoom
                val pageHeight = pageWidth / aspect
                val pageWidthPx = with(density) { pageWidth.toPx() }
                val pageHeightPx = with(density) { pageHeight.toPx() }
                val contentWidth = maxOf(maxWidth, pageWidth + 16.dp)
                pageMetrics[0] = pageWidthPx
                pageMetrics[1] = pageHeightPx
                pageMetrics[2] = with(density) { maxHeight.toPx() }

                // Dos dedos: zoom. Un dedo: desplazar y escribir, como siempre.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                do {
                                    val event = awaitPointerEvent(PointerEventPass.Initial)
                                    val pressed = event.changes.count { it.pressed }
                                    if (pressed >= 2) {
                                        val next = (viewZoom * event.calculateZoom()).coerceIn(1f, 5f)
                                        if (abs(next - viewZoom) > 0.0005f) viewZoom = next
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(verticalScroll)
                            .horizontalScroll(horizontalScroll)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(contentWidth)
                                .height(pageHeight + 220.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = 8.dp)
                                    .width(pageWidth)
                                    .height(pageHeight)
                                    .background(Color(current.pageColor))
                                    .pointerInput(Unit) {
                                        // Tocar el papel vacío suelta lo que estaba elegido.
                                        detectTapGestures {
                                            focusManager.clearFocus()
                                            focusedId = -1
                                            showColors = false
                                            selectedId = -1
                                        }
                                    }
                            ) {
                                orderedBlocks.forEach { block ->
                                    key(block.id) {
                                        val selected = moveMode && block.id == selectedId
                                        val moveX = if (selected) dragDelta.x else 0f
                                        val moveY = if (selected) dragDelta.y else 0f
                                        val growX = if (selected) resizeDelta.x else 0f
                                        val growY = if (selected) resizeDelta.y else 0f
                                        val baseWidthPx = frame.w(block.w) * pageWidthPx
                                        val baseHeightPx = frame.h(block.h) * pageHeightPx
                                        val leftDp = with(density) { (frame.x(block.x) * pageWidthPx + moveX).toDp() }
                                        val topDp = with(density) { (frame.y(block.y) * pageHeightPx + moveY).toDp() }

                                        when (block) {
                                            is PageShape -> {
                                                val widthDp = with(density) { (baseWidthPx + growX).coerceAtLeast(4f).toDp() }
                                                val heightDp = with(density) { (baseHeightPx + growY).coerceAtLeast(1.5f).toDp() }
                                                Box(
                                                    Modifier
                                                        .offset(x = leftDp, y = topDp)
                                                        .width(widthDp)
                                                        // En modo mover, una raya fina necesita espacio para tocarla.
                                                        .height(if (moveMode) maxOf(heightDp, 14.dp) else heightDp)
                                                ) {
                                                    Box(
                                                        Modifier
                                                            .fillMaxWidth()
                                                            .height(heightDp)
                                                            .background(Color(block.color))
                                                    )
                                                    if (moveMode) {
                                                        EditorMoveOverlay(
                                                            selected = selected,
                                                            onSelect = { selectedId = block.id },
                                                            onDrag = { dragDelta += it },
                                                            onDragEnd = { finishDrag() },
                                                            onResize = { resizeDelta += it },
                                                            onResizeEnd = { finishResize() }
                                                        )
                                                    }
                                                }
                                            }
                                            is PageImage -> {
                                                // La imagen crece pareja: el alto sigue al ancho.
                                                val factor = ((baseWidthPx + growX) / baseWidthPx.coerceAtLeast(1f)).coerceIn(0.1f, 8f)
                                                val widthDp = with(density) { (baseWidthPx * factor).toDp() }
                                                val heightDp = with(density) { (baseHeightPx * factor).toDp() }
                                                val picture = remember(block.bitmap) { block.bitmap.asImageBitmap() }
                                                Box(
                                                    Modifier
                                                        .offset(x = leftDp, y = topDp)
                                                        .width(widthDp)
                                                        .height(heightDp)
                                                ) {
                                                    Image(
                                                        bitmap = picture,
                                                        contentDescription = null,
                                                        modifier = Modifier.fillMaxSize(),
                                                        contentScale = ContentScale.FillBounds,
                                                        filterQuality = FilterQuality.High
                                                    )
                                                    if (moveMode) {
                                                        EditorMoveOverlay(
                                                            selected = selected,
                                                            onSelect = { selectedId = block.id },
                                                            onDrag = { dragDelta += it },
                                                            onDragEnd = { finishDrag() },
                                                            onResize = { resizeDelta += it },
                                                            onResizeEnd = { finishResize() }
                                                        )
                                                    }
                                                }
                                            }
                                            is PageText -> {
                                                val widthDp = with(density) { (baseWidthPx + growX).coerceAtLeast(24f).toDp() }
                                                val fontPx = (block.size * frame.scale * pageHeightPx).coerceAtLeast(2f)
                                                Box(
                                                    Modifier
                                                        .offset(x = leftDp, y = topDp)
                                                        .width(widthDp)
                                                ) {
                                                    EditorTextBlock(
                                                        block = block,
                                                        fontPx = fontPx,
                                                        enabled = !moveMode,
                                                        focused = block.id == focusedId,
                                                        onFocused = { selection ->
                                                            focusedId = block.id
                                                            focusedSelection = selection
                                                            showPage = false
                                                        },
                                                        onSelection = { selection ->
                                                            if (focusedId == block.id) focusedSelection = selection
                                                        },
                                                        onText = { text ->
                                                            replaceBlock(
                                                                block.id,
                                                                {
                                                                    if (it is PageText) {
                                                                        it.copy(
                                                                            text = text,
                                                                            runs = TextRuns.remap(it.text, text, it.baseStyle(), it.runs)
                                                                        )
                                                                    } else it
                                                                },
                                                                typingIn = block.id
                                                            )
                                                        }
                                                    )
                                                    if (moveMode) {
                                                        EditorMoveOverlay(
                                                            selected = selected,
                                                            onSelect = { selectedId = block.id },
                                                            onDrag = { dragDelta += it },
                                                            onDragEnd = { finishDrag() },
                                                            onResize = { resizeDelta += it },
                                                            onResizeEnd = { finishResize() }
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ---------------- Barra de abajo ----------------
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(EditorBar)
                    .navigationBarsPadding()
                    .padding(vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val text = focusedText
                when {
                    moveMode -> {
                        Text(
                            if (selectedBlock == null) "Toca un bloque para elegirlo"
                            else "Arrastra para mover · el punto azul cambia el tamaño",
                            color = EditorMuted,
                            fontSize = 12.sp,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                        )
                        EditorRow {
                            EditorChip(active = false, enabled = selectedBlock != null, onClick = { duplicateSelected() }) {
                                EditorLabel("Duplicar")
                            }
                            EditorChip(active = false, enabled = selectedBlock != null, onClick = { deleteBlock(selectedId) }) {
                                Text("Borrar", color = EditorDanger, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            EditorDivider()
                            EditorChip(active = false, onClick = { exitMoveMode() }) {
                                Text("Listo", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }

                    text == null -> {
                        EditorRow {
                            EditorChip(active = false, onClick = { enterMoveMode() }) { EditorLabel("Mover") }
                            EditorChip(active = false, onClick = { addText() }) { EditorLabel("+ Texto") }
                            EditorChip(active = false, onClick = { pickImage.launch("image/*") }) { EditorLabel("+ Imagen") }
                            EditorChip(active = false, onClick = { showSignature = true }) { EditorLabel("+ Firma") }
                            EditorDivider()
                            EditorChip(active = showPage, onClick = { showPage = !showPage }) { EditorLabel("Hoja") }
                        }
                        if (showPage) {
                            EditorRow {
                                EditorPagePresets.forEach { preset ->
                                    val ratio = (preset.ratio ?: current.sourceAspect).coerceIn(0.35f, 2.8f)
                                    val active = abs(current.aspect - ratio) < 0.01f &&
                                        (preset.ratio != null || abs(current.aspect - current.sourceAspect) < 0.0005f)
                                    EditorChip(active = active, onClick = { commit(current.copy(aspect = ratio)) }) {
                                        EditorLabel(preset.label)
                                    }
                                }
                            }
                            EditorRow {
                                Text("Letra de toda la hoja", color = EditorMuted, fontSize = 12.sp)
                                EditorFamilyChips(selected = -1) { family ->
                                    commit(
                                        current.copy(
                                            blocks = current.blocks.map { if (it is PageText) it.copy(family = family) else it }
                                        )
                                    )
                                }
                            }
                        } else {
                            Text(
                                "Toca un texto para escribir. Selecciona una palabra para cambiarle el estilo.",
                                color = EditorMuted,
                                fontSize = 12.sp,
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                            )
                        }
                    }

                    else -> {
                        // Estado del rango elegido, para marcar los botones.
                        val (from, to) = styleRange(text)
                        val base = text.baseStyle()
                        val styles = remember(text.text.length, base, text.runs) {
                            TextRuns.resolve(text.text.length, base, text.runs)
                        }
                        fun all(check: (CharStyle) -> Boolean): Boolean {
                            if (styles.isEmpty() || from >= to) return check(base)
                            for (index in from until min(to, styles.size)) if (!check(styles[index])) return false
                            return true
                        }
                        val isBold = all { it.bold }
                        val isItalic = all { it.italic }
                        val isUnderline = all { it.underline }
                        val isStrike = all { it.strike }
                        val shownColor = if (styles.isNotEmpty() && from < styles.size) styles[from].color else base.color
                        val partial = !(from == 0 && to == text.text.length)

                        EditorRow {
                            EditorChip(active = isBold, onClick = { styleFocused { it.copy(bold = !isBold) } }) {
                                Text("B", color = EditorInk, fontWeight = FontWeight.Black, fontSize = 17.sp)
                            }
                            EditorChip(active = isItalic, onClick = { styleFocused { it.copy(italic = !isItalic) } }) {
                                Text("I", color = EditorInk, fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                            EditorChip(active = isUnderline, onClick = { styleFocused { it.copy(underline = !isUnderline) } }) {
                                Text("U", color = EditorInk, textDecoration = TextDecoration.Underline, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                            EditorChip(active = isStrike, onClick = { styleFocused { it.copy(strike = !isStrike) } }) {
                                Text("S", color = EditorInk, textDecoration = TextDecoration.LineThrough, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                            EditorDivider()
                            EditorChip(active = false, onClick = { resizeFocused(0.93f) }) {
                                Text("A−", color = EditorInk, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                            EditorChip(active = false, onClick = { resizeFocused(1.075f) }) {
                                Text("A+", color = EditorInk, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                            EditorChip(active = showColors, onClick = { showColors = !showColors }) {
                                Box(
                                    Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(Color(shownColor))
                                        .border(1.dp, EditorMuted, CircleShape)
                                )
                            }
                            EditorDivider()
                            PageAlign.entries.forEach { align ->
                                EditorChip(
                                    active = text.align == align,
                                    onClick = { replaceBlock(text.id, { if (it is PageText) it.copy(align = align) else it }) }
                                ) {
                                    EditorAlignGlyph(align)
                                }
                            }
                        }
                        if (showColors) {
                            EditorRow {
                                EditorPalette.forEach { swatch ->
                                    Box(
                                        modifier = Modifier
                                            .size(30.dp)
                                            .clip(CircleShape)
                                            .background(Color(swatch))
                                            .border(
                                                width = if (shownColor == swatch) 2.dp else 1.dp,
                                                color = if (shownColor == swatch) NeonGreen else EditorMuted,
                                                shape = CircleShape
                                            )
                                            .clickable { styleFocused { it.copy(color = swatch) } }
                                    )
                                }
                            }
                        }
                        EditorRow {
                            Text(
                                if (partial) "Solo lo seleccionado" else "Todo el párrafo",
                                color = if (partial) NeonGreen else EditorMuted,
                                fontSize = 12.sp
                            )
                            EditorDivider()
                            EditorFamilyChips(selected = text.family.mod(3)) { family ->
                                replaceBlock(text.id, { if (it is PageText) it.copy(family = family) else it })
                            }
                            EditorDivider()
                            EditorLabel("Renglones", muted = true)
                            EditorChip(active = false, onClick = {
                                replaceBlock(text.id, {
                                    if (it is PageText) it.copy(leading = (it.leading - 0.08f).coerceIn(0.9f, 2.6f)) else it
                                })
                            }) {
                                Text("−", color = EditorInk, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                            EditorChip(active = false, onClick = {
                                replaceBlock(text.id, {
                                    if (it is PageText) it.copy(leading = (it.leading + 0.08f).coerceIn(0.9f, 2.6f)) else it
                                })
                            }) {
                                Text("+", color = EditorInk, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                            EditorDivider()
                            EditorChip(active = false, onClick = { enterMoveMode(text.id) }) { EditorLabel("Mover") }
                            EditorChip(active = false, onClick = { deleteBlock(text.id) }) {
                                Text("Borrar", color = EditorDanger, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            EditorChip(active = false, onClick = {
                                focusManager.clearFocus()
                                focusedId = -1
                                showColors = false
                            }) {
                                Text("Listo", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        if (showSignature) {
            EditorSignaturePad(
                onCancel = { showSignature = false },
                onDone = { signature ->
                    showSignature = false
                    addImage(signature)
                }
            )
        }
    }
}

/** Un párrafo editable. Las palabras con estilo propio se pintan encima del estilo del párrafo. */
@Composable
private fun EditorTextBlock(
    block: PageText,
    fontPx: Float,
    enabled: Boolean,
    focused: Boolean,
    onFocused: (TextRange) -> Unit,
    onSelection: (TextRange) -> Unit,
    onText: (String) -> Unit
) {
    val density = LocalDensity.current
    var value by remember(block.id) { mutableStateOf(TextFieldValue(block.text)) }
    // Si el texto cambió por fuera (deshacer, rehacer), se muestra el del documento.
    val shown = if (value.text == block.text) {
        value
    } else {
        TextFieldValue(block.text, TextRange(block.text.length))
    }
    val textColor = Color(block.color)
    val light = (0.299f * textColor.red + 0.587f * textColor.green + 0.114f * textColor.blue) > 0.6f
    val decoration = TextDecoration.combine(
        listOfNotNull(
            if (block.underline) TextDecoration.Underline else null,
            if (block.strike) TextDecoration.LineThrough else null
        )
    )
    val runs = block.runs
    val transformation = remember(runs) {
        if (runs.isEmpty()) {
            VisualTransformation.None
        } else {
            VisualTransformation { original -> TransformedText(editorStyledText(original.text, runs), OffsetMapping.Identity) }
        }
    }
    BasicTextField(
        value = shown,
        onValueChange = { next ->
            value = next
            onSelection(next.selection)
            if (next.text != block.text) onText(next.text)
        },
        enabled = enabled,
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (focused && enabled) {
                    Modifier
                        .background(EditorFocus.copy(alpha = 0.08f))
                        .border(1.dp, EditorFocus.copy(alpha = 0.7f))
                } else Modifier
            )
            .onFocusChanged { state -> if (state.isFocused) onFocused(shown.selection) },
        textStyle = TextStyle(
            color = textColor,
            fontSize = with(density) { fontPx.toSp() },
            lineHeight = with(density) { (fontPx * block.leading.coerceIn(0.8f, 3f)).toSp() },
            fontFamily = when (block.family.mod(3)) {
                1 -> FontFamily.Serif
                2 -> FontFamily.Monospace
                else -> FontFamily.SansSerif
            },
            fontWeight = if (block.bold) FontWeight.Bold else FontWeight.Normal,
            fontStyle = if (block.italic) FontStyle.Italic else FontStyle.Normal,
            textDecoration = decoration,
            textAlign = when (block.align) {
                PageAlign.CENTER -> TextAlign.Center
                PageAlign.RIGHT -> TextAlign.Right
                PageAlign.JUSTIFY -> TextAlign.Justify
                PageAlign.LEFT -> TextAlign.Left
            },
            lineHeightStyle = LineHeightStyle(
                alignment = LineHeightStyle.Alignment.Center,
                trim = LineHeightStyle.Trim.None
            )
        ),
        visualTransformation = transformation,
        cursorBrush = SolidColor(if (light) Color.White else EditorFocus)
    )
}

private fun editorStyledText(text: String, runs: List<StyleRun>): AnnotatedString {
    val builder = AnnotatedString.Builder(text)
    for (run in runs) {
        val from = run.start.coerceIn(0, text.length)
        val to = run.end.coerceIn(from, text.length)
        if (to <= from) continue
        val style = run.style
        builder.addStyle(
            SpanStyle(
                color = Color(style.color),
                fontWeight = if (style.bold) FontWeight.Bold else FontWeight.Normal,
                fontStyle = if (style.italic) FontStyle.Italic else FontStyle.Normal,
                fontSize = style.scale.coerceIn(0.3f, 4f).em,
                textDecoration = TextDecoration.combine(
                    listOfNotNull(
                        if (style.underline) TextDecoration.Underline else null,
                        if (style.strike) TextDecoration.LineThrough else null
                    )
                )
            ),
            from,
            to
        )
    }
    return builder.toAnnotatedString()
}

/**
 * Capa del modo mover: cubre el bloque, lo marca, y deja arrastrarlo.
 * El punto azul de la esquina cambia el tamaño.
 */
@Composable
private fun BoxScope.EditorMoveOverlay(
    selected: Boolean,
    onSelect: () -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onResize: (Offset) -> Unit,
    onResizeEnd: () -> Unit
) {
    val select by rememberUpdatedState(onSelect)
    val drag by rememberUpdatedState(onDrag)
    val dragEnd by rememberUpdatedState(onDragEnd)
    val resize by rememberUpdatedState(onResize)
    val resizeEnd by rememberUpdatedState(onResizeEnd)
    Box(
        modifier = Modifier
            .matchParentSize()
            .then(
                if (selected) {
                    Modifier
                        .background(EditorFocus.copy(alpha = 0.12f))
                        .border(1.5.dp, EditorFocus)
                } else {
                    Modifier.border(1.dp, EditorFocus.copy(alpha = 0.28f))
                }
            )
            .pointerInput(Unit) {
                detectTapGestures { select() }
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { select() },
                    onDrag = { change, amount ->
                        change.consume()
                        drag(amount)
                    },
                    onDragEnd = { dragEnd() },
                    onDragCancel = { dragEnd() }
                )
            }
    )
    if (selected) {
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(20.dp)
                .clip(CircleShape)
                .background(EditorFocus)
                .border(2.dp, Color.White, CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDrag = { change, amount ->
                            change.consume()
                            resize(amount)
                        },
                        onDragEnd = { resizeEnd() },
                        onDragCancel = { resizeEnd() }
                    )
                }
        )
    }
}

/** Cuadro para firmar con el dedo. Devuelve la firma como imagen con fondo transparente. */
@Composable
private fun EditorSignaturePad(onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    val live = remember { mutableStateListOf<Offset>() }
    val strokeWidthPx = with(LocalDensity.current) { 3.dp.toPx() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xE6000000))
            // Tapa los toques para que no lleguen a la hoja de atrás.
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 18.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(EditorBar)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Firma con el dedo", color = EditorInk, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { start ->
                                live.clear()
                                live.add(start)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                live.add(change.position)
                            },
                            onDragEnd = {
                                if (live.size > 1) strokes.add(live.toList())
                                live.clear()
                            },
                            onDragCancel = { live.clear() }
                        )
                    }
            ) {
                Canvas(Modifier.matchParentSize()) {
                    val ink = Color(EditorSignatureInk)
                    fun line(points: List<Offset>) {
                        for (index in 1 until points.size) {
                            drawLine(
                                color = ink,
                                start = points[index - 1],
                                end = points[index],
                                strokeWidth = strokeWidthPx,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                    strokes.forEach { line(it) }
                    line(live.toList())
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                EditorChip(active = false, onClick = {
                    strokes.clear()
                    live.clear()
                }) { EditorLabel("Limpiar") }
                Spacer(Modifier.weight(1f))
                EditorChip(active = false, onClick = onCancel) { EditorLabel("Cancelar") }
                EditorChip(active = true, enabled = strokes.isNotEmpty(), onClick = {
                    val bitmap = editorSignatureBitmap(strokes.toList(), strokeWidthPx)
                    if (bitmap != null) onDone(bitmap) else onCancel()
                }) {
                    Text("Usar", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

/** Pasa los trazos a una imagen recortada justo al tamaño de la firma. */
private fun editorSignatureBitmap(strokes: List<List<Offset>>, strokeWidthPx: Float): Bitmap? {
    val points = strokes.flatten()
    if (points.size < 2) return null
    val margin = strokeWidthPx * 2f + 4f
    val left = points.minOf { it.x } - margin
    val top = points.minOf { it.y } - margin
    val width = (points.maxOf { it.x } + margin - left).roundToInt().coerceIn(8, 4000)
    val height = (points.maxOf { it.y } + margin - top).roundToInt().coerceIn(8, 4000)
    return runCatching {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = EditorSignatureInk
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = strokeWidthPx
            strokeCap = android.graphics.Paint.Cap.ROUND
            strokeJoin = android.graphics.Paint.Join.ROUND
        }
        strokes.forEach { stroke ->
            if (stroke.size < 2) return@forEach
            val path = android.graphics.Path()
            path.moveTo(stroke[0].x - left, stroke[0].y - top)
            for (index in 1 until stroke.size) path.lineTo(stroke[index].x - left, stroke[index].y - top)
            canvas.drawPath(path, paint)
        }
        bitmap
    }.getOrNull()
}

@Composable
private fun EditorRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        content()
    }
}

@Composable
private fun EditorChip(
    active: Boolean,
    onClick: () -> Unit,
    enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .height(40.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(if (active) EditorChipOn else EditorChipIdle)
            .border(
                width = 1.dp,
                color = if (active) NeonGreen.copy(alpha = 0.7f) else Color.Transparent,
                shape = RoundedCornerShape(11.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 13.dp),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
private fun EditorLabel(text: String, muted: Boolean = false) {
    Text(
        text,
        color = if (muted) EditorMuted else EditorInk,
        fontWeight = if (muted) FontWeight.Normal else FontWeight.Bold,
        fontSize = if (muted) 12.sp else 13.sp
    )
}

@Composable
private fun EditorDivider() {
    Box(
        Modifier
            .width(1.dp)
            .height(24.dp)
            .background(Color(0xFF2A3B31))
    )
}

@Composable
private fun EditorFamilyChips(selected: Int, onPick: (Int) -> Unit) {
    EditorChip(active = selected == 0, onClick = { onPick(0) }) {
        Text("Arial", color = EditorInk, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
    EditorChip(active = selected == 1, onClick = { onPick(1) }) {
        Text("Times", color = EditorInk, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
    EditorChip(active = selected == 2, onClick = { onPick(2) }) {
        Text("Máquina", color = EditorInk, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

/** Dibujito de alineación: cuatro rayas, como en cualquier editor de texto. */
@Composable
private fun EditorAlignGlyph(align: PageAlign) {
    Canvas(Modifier.size(20.dp)) {
        val lengths = when (align) {
            PageAlign.JUSTIFY -> floatArrayOf(1f, 1f, 1f, 1f)
            else -> floatArrayOf(1f, 0.6f, 0.85f, 0.5f)
        }
        val stroke = size.height * 0.1f
        for (index in 0 until 4) {
            val lineWidth = size.width * lengths[index]
            val y = size.height * (0.14f + index * 0.24f)
            val start = when (align) {
                PageAlign.CENTER -> (size.width - lineWidth) / 2f
                PageAlign.RIGHT -> size.width - lineWidth
                else -> 0f
            }
            drawLine(
                color = EditorInk,
                start = Offset(start, y),
                end = Offset(start + lineWidth, y),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
        }
    }
}
