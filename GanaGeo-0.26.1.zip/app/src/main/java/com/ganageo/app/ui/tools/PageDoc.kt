package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableString
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import com.ganageo.app.tools.CharStyle
import com.ganageo.app.tools.PageFrame
import com.ganageo.app.tools.StyleRun
import com.ganageo.app.tools.TextRuns
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Documento editable del escáner. Es la única "verdad" de la hoja:
 * el editor lo muestra y lo cambia, y de aquí salen el PDF, el Word y la imagen.
 *
 * Las medidas van de 0 a 1 sobre la hoja ORIGINAL (x y w sobre el ancho; y h
 * sobre el alto). Al elegir A4, Carta u Oficio la hoja original se acomoda
 * dentro del formato nuevo con [PageFrame], sin perder las medidas originales.
 */
internal data class PageDoc(
    /** Forma de la hoja original (ancho / alto). */
    val sourceAspect: Float,
    /** Forma de la hoja que se muestra y se guarda. */
    val aspect: Float,
    val pageColor: Int,
    /** En orden de dibujo: primero formas, luego imágenes y encima los textos. */
    val blocks: List<PageBlock>
)

internal sealed interface PageBlock {
    val id: Int
    val x: Float
    val y: Float
    val w: Float
    val h: Float
}

internal enum class PageAlign { LEFT, CENTER, RIGHT, JUSTIFY }

/** Un párrafo de texto: se escribe y el texto baja solo al siguiente renglón. */
internal data class PageText(
    override val id: Int,
    override val x: Float,
    override val y: Float,
    override val w: Float,
    override val h: Float,
    val text: String,
    /** Tamaño de la letra como fracción del alto de la hoja original. */
    val size: Float,
    /** Distancia entre renglones, en "tamaños de letra" (1,17 es lo normal). */
    val leading: Float = PAGE_NATURAL_LEADING,
    val color: Int = android.graphics.Color.BLACK,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val strike: Boolean = false,
    val align: PageAlign = PageAlign.LEFT,
    /** 0 = sin remates (tipo Arial), 1 = con remates (tipo Times), 2 = máquina de escribir. */
    val family: Int = 0,
    /** Palabras con estilo propio (negrita, color o tamaño distinto al del párrafo). */
    val runs: List<StyleRun> = emptyList()
) : PageBlock

/** Estilo del párrafo completo, como estilo de letra. */
internal fun PageText.baseStyle(): CharStyle =
    CharStyle(bold = bold, italic = italic, underline = underline, strike = strike, color = color, scale = 1f)

internal fun PageText.withBase(style: CharStyle): PageText =
    copy(bold = style.bold, italic = style.italic, underline = style.underline, strike = style.strike, color = style.color)

/** Mueve un bloque (medidas de la hoja original). */
internal fun PageBlock.movedBy(dx: Float, dy: Float): PageBlock {
    val newX = (x + dx).coerceIn(0f, 0.98f)
    val newY = (y + dy).coerceIn(0f, 0.98f)
    return when (this) {
        is PageText -> copy(x = newX, y = newY)
        is PageShape -> copy(x = newX, y = newY)
        is PageImage -> PageImage(id, newX, newY, w, h, bitmap)
    }
}

/**
 * Cambia el tamaño de un bloque. En un texto cambia el ancho (el texto se
 * reacomoda solo); en una imagen crece parejo; en una forma, ancho y alto.
 */
internal fun PageBlock.resizedBy(dw: Float, dh: Float): PageBlock = when (this) {
    is PageText -> copy(w = (w + dw).coerceIn(0.03f, 1.2f))
    is PageShape -> copy(w = (w + dw).coerceIn(0.004f, 1.2f), h = (h + dh).coerceIn(0.001f, 1.2f))
    is PageImage -> {
        val factor = ((w + dw) / w.coerceAtLeast(0.001f)).coerceIn(0.1f, 8f)
        val newWidth = (w * factor).coerceIn(0.02f, 1.5f)
        val applied = newWidth / w.coerceAtLeast(0.001f)
        PageImage(id, x, y, newWidth, (h * applied).coerceAtLeast(0.005f), bitmap)
    }
}

internal fun PageBlock.copyWithId(newId: Int, dx: Float, dy: Float): PageBlock {
    val newX = (x + dx).coerceIn(0f, 0.98f)
    val newY = (y + dy).coerceIn(0f, 0.98f)
    return when (this) {
        is PageText -> copy(id = newId, x = newX, y = newY)
        is PageShape -> copy(id = newId, x = newX, y = newY)
        is PageImage -> PageImage(newId, newX, newY, w, h, bitmap)
    }
}

/** Rectángulo de color o raya. */
internal data class PageShape(
    override val id: Int,
    override val x: Float,
    override val y: Float,
    override val w: Float,
    override val h: Float,
    val color: Int
) : PageBlock

/** Dibujo, foto o croquis. No es "data": dos imágenes son iguales solo si son la misma. */
internal class PageImage(
    override val id: Int,
    override val x: Float,
    override val y: Float,
    override val w: Float,
    override val h: Float,
    val bitmap: Bitmap
) : PageBlock

internal const val PAGE_NATURAL_LEADING = 1.17f

internal fun pageTypeface(family: Int, bold: Boolean, italic: Boolean): Typeface {
    val base = when (family.mod(3)) {
        1 -> Typeface.SERIF
        2 -> Typeface.MONOSPACE
        else -> Typeface.SANS_SERIF
    }
    val style = when {
        bold && italic -> Typeface.BOLD_ITALIC
        bold -> Typeface.BOLD
        italic -> Typeface.ITALIC
        else -> Typeface.NORMAL
    }
    return Typeface.create(base, style)
}

/** Tamaño en píxeles del lienzo de una hoja, según su forma y el lado más largo pedido. */
internal fun pageCanvasSize(doc: PageDoc, maxEdge: Int): Pair<Int, Int> {
    val ratio = doc.aspect.coerceIn(0.35f, 2.8f)
    val edge = maxEdge.coerceIn(800, 3200)
    return if (ratio >= 1f) {
        edge to (edge / ratio).roundToInt().coerceAtLeast(320)
    } else {
        (edge * ratio).roundToInt().coerceAtLeast(320) to edge
    }
}

/**
 * Dibuja la hoja en cualquier lienzo: una imagen o una página de PDF (ahí el
 * texto queda como texto real). Con drawText = false dibuja solo el fondo
 * (papel, formas e imágenes); lo usa la exportación a Word.
 */
internal fun drawPageDoc(canvas: Canvas, doc: PageDoc, width: Int, height: Int, drawText: Boolean = true) {
    canvas.drawColor(doc.pageColor)
    val frame = PageFrame(doc.sourceAspect, doc.aspect)
    val fill = Paint().apply { style = Paint.Style.FILL }
    val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    val target = RectF()

    doc.blocks.forEach { block ->
        if (block is PageShape) {
            fill.color = block.color
            val top = frame.y(block.y) * height
            val bottom = maxOf(frame.y(block.y + block.h) * height, top + 1.5f)
            canvas.drawRect(
                frame.x(block.x) * width,
                top,
                frame.x(block.x + block.w) * width,
                bottom,
                fill
            )
        }
    }
    doc.blocks.forEach { block ->
        if (block is PageImage && !block.bitmap.isRecycled) {
            target.set(
                frame.x(block.x) * width,
                frame.y(block.y) * height,
                frame.x(block.x + block.w) * width,
                frame.y(block.y + block.h) * height
            )
            canvas.drawBitmap(block.bitmap, null, target, imagePaint)
        }
    }
    if (!drawText) return

    doc.blocks.forEach { block ->
        if (block !is PageText || block.text.isBlank()) return@forEach
        val left = frame.x(block.x) * width
        val top = frame.y(block.y) * height
        val boxWidth = ceil(frame.w(block.w) * width).toInt().coerceAtLeast(8)
        val fontPx = (block.size * frame.scale * height).coerceAtLeast(2f)
        // El estilo va por tramos (una palabra puede tener negrita o color propio).
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            color = block.color
            typeface = pageTypeface(block.family, bold = false, italic = false)
            textSize = fontPx
            isLinearText = true
        }
        val styled = SpannableString(block.text)
        TextRuns.segments(block.text.length, block.baseStyle(), block.runs).forEach { segment ->
            val style = segment.style
            val flags = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            if (style.bold || style.italic) {
                val typefaceStyle = when {
                    style.bold && style.italic -> Typeface.BOLD_ITALIC
                    style.bold -> Typeface.BOLD
                    else -> Typeface.ITALIC
                }
                styled.setSpan(StyleSpan(typefaceStyle), segment.start, segment.end, flags)
            }
            if (style.underline) styled.setSpan(UnderlineSpan(), segment.start, segment.end, flags)
            if (style.strike) styled.setSpan(StrikethroughSpan(), segment.start, segment.end, flags)
            styled.setSpan(ForegroundColorSpan(style.color), segment.start, segment.end, flags)
            if (kotlin.math.abs(style.scale - 1f) > 0.01f) {
                styled.setSpan(RelativeSizeSpan(style.scale.coerceIn(0.3f, 4f)), segment.start, segment.end, flags)
            }
        }
        val metrics = paint.fontMetrics
        val natural = (metrics.descent - metrics.ascent).coerceAtLeast(1f)
        val pitch = fontPx * block.leading.coerceIn(0.8f, 3f)
        val layout = StaticLayout.Builder
            .obtain(styled, 0, styled.length, paint, boxWidth)
            .setIncludePad(false)
            .setAlignment(
                when (block.align) {
                    PageAlign.CENTER -> Layout.Alignment.ALIGN_CENTER
                    PageAlign.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
                    else -> Layout.Alignment.ALIGN_NORMAL
                }
            )
            .setLineSpacing(0f, pitch / natural)
            .setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE)
            .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
            .setJustificationMode(
                if (block.align == PageAlign.JUSTIFY) Layout.JUSTIFICATION_MODE_INTER_WORD
                else Layout.JUSTIFICATION_MODE_NONE
            )
            .build()
        canvas.save()
        // El editor reparte el espacio entre renglones mitad arriba y mitad abajo.
        canvas.translate(left, top + (pitch - natural) / 2f)
        layout.draw(canvas)
        canvas.restore()
    }
}

internal fun renderPageDocBitmap(doc: PageDoc, maxEdge: Int): Bitmap {
    val (width, height) = pageCanvasSize(doc, maxEdge)
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    drawPageDoc(Canvas(output), doc, width, height)
    return output
}

/** PDF de una página con texto real: se puede buscar, seleccionar y copiar. */
internal fun writePageDocPdf(doc: PageDoc, output: OutputStream) {
    val ratio = doc.aspect.coerceIn(0.35f, 2.8f)
    // Medidas en puntos; el lado largo es el de una hoja A4 (842 pt).
    val pageWidth: Int
    val pageHeight: Int
    if (ratio >= 1f) {
        pageWidth = 842
        pageHeight = (842f / ratio).roundToInt().coerceAtLeast(120)
    } else {
        pageHeight = 842
        pageWidth = (842f * ratio).roundToInt().coerceAtLeast(120)
    }
    // Se dibuja en un lienzo más grande y se reduce: el texto se acomoda igual que en el editor.
    val detail = 2.5f
    val pdf = android.graphics.pdf.PdfDocument()
    try {
        val page = pdf.startPage(
            android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        )
        val canvas = page.canvas
        canvas.save()
        canvas.scale(1f / detail, 1f / detail)
        drawPageDoc(canvas, doc, (pageWidth * detail).roundToInt(), (pageHeight * detail).roundToInt())
        canvas.restore()
        pdf.finishPage(page)
        pdf.writeTo(output)
    } finally {
        pdf.close()
    }
}

private fun pageXmlEscape(value: String): String = value
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")

private fun pageHexColor(argb: Int): String =
    String.format(java.util.Locale.US, "%06X", argb and 0xFFFFFF)

private fun pageZipText(zip: ZipOutputStream, name: String, text: String) {
    zip.putNextEntry(ZipEntry(name))
    zip.write(text.toByteArray(Charsets.UTF_8))
    zip.closeEntry()
}

/**
 * Word (.docx) armado a mano, sin librerías. Cada párrafo va en su lugar como
 * un cuadro de texto con párrafo real (se puede escribir y el texto baja solo).
 * El fondo (formas e imágenes) va como una imagen detrás del texto.
 */
internal fun writePageDocDocx(doc: PageDoc, output: OutputStream, backgroundMaxEdge: Int) {
    val ratio = doc.aspect.coerceIn(0.35f, 2.8f)
    // Medidas de Word en "twips" (1 punto = 20). Lado largo = A4 (297 mm).
    val pageWidth: Int
    val pageHeight: Int
    if (ratio >= 1f) {
        pageWidth = 16838
        pageHeight = (16838f / ratio).roundToInt().coerceAtLeast(2400)
    } else {
        pageHeight = 16838
        pageWidth = (16838f * ratio).roundToInt().coerceAtLeast(2400)
    }
    val frame = PageFrame(doc.sourceAspect, doc.aspect)

    // ---- Fondo como imagen ----
    val hasImages = doc.blocks.any { it is PageImage }
    val needsBackground = hasImages || doc.blocks.any { it is PageShape } ||
        doc.pageColor != android.graphics.Color.WHITE
    var backgroundBytes: ByteArray? = null
    var backgroundExtension = "png"
    if (needsBackground) {
        val (backWidth, backHeight) = pageCanvasSize(doc, backgroundMaxEdge)
        val background = Bitmap.createBitmap(backWidth, backHeight, Bitmap.Config.ARGB_8888)
        try {
            drawPageDoc(Canvas(background), doc, backWidth, backHeight, drawText = false)
            val bytes = ByteArrayOutputStream()
            val saved = background.compress(
                if (hasImages) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG,
                90,
                bytes
            )
            if (saved) {
                backgroundBytes = bytes.toByteArray()
                backgroundExtension = if (hasImages) "jpeg" else "png"
            }
        } finally {
            if (!background.isRecycled) background.recycle()
        }
    }

    val body = StringBuilder()
    if (backgroundBytes != null) {
        // 1 twip = 635 EMU (la medida que usan las imágenes de Word).
        val cx = pageWidth.toLong() * 635L
        val cy = pageHeight.toLong() * 635L
        body.append(
            "<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"20\" w:lineRule=\"exact\"/></w:pPr>" +
                "<w:r><w:drawing><wp:anchor distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" " +
                "relativeHeight=\"0\" behindDoc=\"1\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\">" +
                "<wp:simplePos x=\"0\" y=\"0\"/>" +
                "<wp:positionH relativeFrom=\"page\"><wp:posOffset>0</wp:posOffset></wp:positionH>" +
                "<wp:positionV relativeFrom=\"page\"><wp:posOffset>0</wp:posOffset></wp:positionV>" +
                "<wp:extent cx=\"$cx\" cy=\"$cy\"/><wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/><wp:wrapNone/>" +
                "<wp:docPr id=\"1\" name=\"Fondo\"/><wp:cNvGraphicFramePr/>" +
                "<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">" +
                "<a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                "<pic:pic xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                "<pic:nvPicPr><pic:cNvPr id=\"1\" name=\"Fondo\"/><pic:cNvPicPr/></pic:nvPicPr>" +
                "<pic:blipFill><a:blip r:embed=\"rId1\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
                "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm>" +
                "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>" +
                "</a:graphicData></a:graphic></wp:anchor></w:drawing></w:r></w:p>"
        )
    }

    // ---- Párrafos en su lugar ----
    val pagePoints = pageHeight / 20f
    doc.blocks.forEach { block ->
        if (block !is PageText || block.text.isBlank()) return@forEach
        // Un poco más chico que en pantalla: las letras de Word son algo más anchas.
        val sizePoints = block.size * frame.scale * pagePoints * 0.96f
        val halfPoints = (sizePoints * 2f).roundToInt().coerceIn(4, 400)
        val lineTwips = (sizePoints * 20f * block.leading.coerceIn(0.8f, 3f) / 0.96f)
            .roundToInt().coerceAtLeast(40)
        val frameX = (frame.x(block.x) * pageWidth).roundToInt().coerceAtLeast(0)
        val frameY = (frame.y(block.y) * pageHeight).roundToInt().coerceAtLeast(0)
        val frameWidth = (frame.w(block.w) * pageWidth).roundToInt()
            .coerceAtLeast(200)
            .coerceAtMost((pageWidth - frameX).coerceAtLeast(200))
        val fontName = when (block.family.mod(3)) {
            1 -> "Times New Roman"
            2 -> "Courier New"
            else -> "Arial"
        }
        val justify = when (block.align) {
            PageAlign.CENTER -> "center"
            PageAlign.RIGHT -> "right"
            PageAlign.JUSTIFY -> "both"
            PageAlign.LEFT -> "left"
        }
        fun runProperties(style: CharStyle): String = buildString {
            val runSize = (halfPoints * style.scale.coerceIn(0.3f, 4f)).roundToInt().coerceIn(4, 400)
            append("<w:rPr>")
            append("<w:rFonts w:ascii=\"$fontName\" w:hAnsi=\"$fontName\" w:cs=\"$fontName\"/>")
            if (style.bold) append("<w:b/>")
            if (style.italic) append("<w:i/>")
            if (style.strike) append("<w:strike/>")
            append("<w:color w:val=\"${pageHexColor(style.color)}\"/>")
            append("<w:sz w:val=\"$runSize\"/><w:szCs w:val=\"$runSize\"/>")
            if (style.underline) append("<w:u w:val=\"single\"/>")
            append("</w:rPr>")
        }
        val segments = TextRuns.segments(block.text.length, block.baseStyle(), block.runs)
        // Cada salto de línea escrito por el usuario es un párrafo dentro del mismo cuadro.
        var paragraphStart = 0
        block.text.split('\n').forEach { paragraph ->
            val paragraphEnd = paragraphStart + paragraph.length
            body.append("<w:p><w:pPr>")
            body.append(
                "<w:framePr w:w=\"$frameWidth\" w:hRule=\"auto\" w:wrap=\"none\" " +
                    "w:vAnchor=\"page\" w:hAnchor=\"page\" w:x=\"$frameX\" w:y=\"$frameY\"/>"
            )
            body.append("<w:spacing w:before=\"0\" w:after=\"0\" w:line=\"$lineTwips\" w:lineRule=\"exact\"/>")
            body.append("<w:jc w:val=\"$justify\"/>")
            body.append("</w:pPr>")
            segments.forEach { segment ->
                val from = maxOf(segment.start, paragraphStart)
                val to = minOf(segment.end, paragraphEnd)
                if (to > from) {
                    body.append("<w:r>").append(runProperties(segment.style))
                    body.append("<w:t xml:space=\"preserve\">")
                    body.append(pageXmlEscape(block.text.substring(from, to)))
                    body.append("</w:t></w:r>")
                }
            }
            body.append("</w:p>")
            // +1 por el salto de línea que separa los párrafos.
            paragraphStart = paragraphEnd + 1
        }
    }

    val documentXml =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
            "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\">" +
            "<w:body>" + body +
            "<w:sectPr><w:pgSz w:w=\"$pageWidth\" w:h=\"$pageHeight\"" +
            (if (ratio >= 1f) " w:orient=\"landscape\"" else "") + "/>" +
            "<w:pgMar w:top=\"0\" w:right=\"0\" w:bottom=\"0\" w:left=\"0\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/>" +
            "</w:sectPr></w:body></w:document>"
    val types =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Default Extension=\"png\" ContentType=\"image/png\"/>" +
            "<Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"
    val rootRels =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"
    val documentRels =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            (if (backgroundBytes != null) {
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/fondo.$backgroundExtension\"/>"
            } else "") +
            "</Relationships>"

    ZipOutputStream(output).use { zip ->
        pageZipText(zip, "[Content_Types].xml", types)
        pageZipText(zip, "_rels/.rels", rootRels)
        pageZipText(zip, "word/document.xml", documentXml)
        pageZipText(zip, "word/_rels/document.xml.rels", documentRels)
        val bytes = backgroundBytes
        if (bytes != null) {
            zip.putNextEntry(ZipEntry("word/media/fondo.$backgroundExtension"))
            zip.write(bytes)
            zip.closeEntry()
        }
    }
}
