package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.min

/**
 * Acomoda la hoja original dentro del formato elegido (A4, Carta, Oficio…)
 * sin deformarla: todo se achica parejo y queda centrado.
 *
 * Las medidas van de 0 a 1: las horizontales sobre el ancho de la hoja y las
 * verticales sobre su alto. "aspect" es ancho dividido entre alto.
 */
class PageFrame(sourceAspect: Float, targetAspect: Float) {
    val source: Float = sourceAspect.coerceIn(0.35f, 2.8f)
    val target: Float = targetAspect.coerceIn(0.35f, 2.8f)
    private val same: Boolean = abs(source - target) < 0.0005f

    /** Cuánto se achica el contenido (1 = queda igual). */
    val scale: Float = if (same) 1f else min(target / source, 1f)
    private val offsetX: Float = if (same) 0f else (target - source * scale) / 2f
    private val offsetY: Float = if (same) 0f else (1f - scale) / 2f

    fun x(value: Float): Float = if (same) value else (offsetX + value * source * scale) / target
    fun y(value: Float): Float = if (same) value else offsetY + value * scale
    fun w(value: Float): Float = if (same) value else value * source * scale / target
    fun h(value: Float): Float = value * scale

    /** Un punto de la hoja mostrada (fracción) llevado a la hoja original. */
    fun sourceX(pageFraction: Float): Float =
        if (same) pageFraction else (pageFraction * target - offsetX) / (source * scale)
    fun sourceY(pageFraction: Float): Float =
        if (same) pageFraction else (pageFraction - offsetY) / scale

    /** Un movimiento en pantalla (fracción de la hoja mostrada) llevado a la hoja original. */
    fun dxToSource(fraction: Float): Float = if (same) fraction else fraction * target / (source * scale)
    fun dyToSource(fraction: Float): Float = fraction / scale
}
