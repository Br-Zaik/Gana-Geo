package com.ganageo.app.tools

import kotlin.math.min

/** Estilo de una letra. El color va como ARGB; scale es el tamaño relativo al del párrafo. */
data class CharStyle(
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val strike: Boolean = false,
    val color: Int = -0x1000000,
    val scale: Float = 1f
)

/** Tramo de texto [start, end) con un estilo propio. */
data class StyleRun(val start: Int, val end: Int, val style: CharStyle)

/**
 * Estilos por palabra dentro de un párrafo. El párrafo tiene un estilo base y
 * una lista de tramos que se salen de esa base (una palabra en negrita, etc.).
 */
object TextRuns {

    /** El estilo de cada letra. */
    fun resolve(length: Int, base: CharStyle, runs: List<StyleRun>): Array<CharStyle> {
        val styles = Array(length.coerceAtLeast(0)) { base }
        for (run in runs) {
            val from = run.start.coerceIn(0, styles.size)
            val to = run.end.coerceIn(from, styles.size)
            for (index in from until to) styles[index] = run.style
        }
        return styles
    }

    /** Junta letras seguidas con el mismo estilo y guarda solo lo distinto a la base. */
    fun compress(styles: Array<CharStyle>, base: CharStyle): List<StyleRun> {
        val runs = ArrayList<StyleRun>()
        var index = 0
        while (index < styles.size) {
            val style = styles[index]
            var next = index + 1
            while (next < styles.size && styles[next] == style) next++
            if (style != base) runs.add(StyleRun(index, next, style))
            index = next
        }
        return runs
    }

    /** Tramos que cubren TODO el texto, con su estilo final (para dibujar y exportar). */
    fun segments(length: Int, base: CharStyle, runs: List<StyleRun>): List<StyleRun> {
        val styles = resolve(length, base, runs)
        val all = ArrayList<StyleRun>()
        var index = 0
        while (index < styles.size) {
            val style = styles[index]
            var next = index + 1
            while (next < styles.size && styles[next] == style) next++
            all.add(StyleRun(index, next, style))
            index = next
        }
        return all
    }

    /** Cambia el estilo de las letras entre from y to. */
    fun apply(
        length: Int,
        base: CharStyle,
        runs: List<StyleRun>,
        from: Int,
        to: Int,
        change: (CharStyle) -> CharStyle
    ): List<StyleRun> {
        val styles = resolve(length, base, runs)
        val start = from.coerceIn(0, styles.size)
        val end = to.coerceIn(start, styles.size)
        for (index in start until end) styles[index] = change(styles[index])
        return compress(styles, base)
    }

    /**
     * Acomoda los tramos cuando el texto cambia (se escribe o se borra).
     * Lo que se escribe hereda el estilo de la letra de al lado.
     */
    fun remap(oldText: String, newText: String, base: CharStyle, runs: List<StyleRun>): List<StyleRun> {
        if (runs.isEmpty()) return runs
        val old = resolve(oldText.length, base, runs)
        var prefix = 0
        val maxPrefix = min(oldText.length, newText.length)
        while (prefix < maxPrefix && oldText[prefix] == newText[prefix]) prefix++
        var suffix = 0
        while (
            suffix < oldText.length - prefix &&
            suffix < newText.length - prefix &&
            oldText[oldText.length - 1 - suffix] == newText[newText.length - 1 - suffix]
        ) {
            suffix++
        }
        val inherited = when {
            prefix > 0 -> old[prefix - 1]
            prefix < old.size -> old[prefix]
            else -> base
        }
        val tailStart = newText.length - suffix
        val result = Array(newText.length) { index ->
            when {
                index < prefix -> old[index]
                index >= tailStart -> old[index - newText.length + oldText.length]
                else -> inherited
            }
        }
        return compress(result, base)
    }
}
