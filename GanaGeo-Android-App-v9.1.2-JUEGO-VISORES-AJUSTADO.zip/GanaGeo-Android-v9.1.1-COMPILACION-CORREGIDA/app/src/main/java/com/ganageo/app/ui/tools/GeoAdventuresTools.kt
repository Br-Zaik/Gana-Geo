package com.ganageo.app.ui.tools

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.GeoGameRunStart
import com.ganageo.app.model.GeoGameStatus
import com.ganageo.app.tools.AdventureLevel
import com.ganageo.app.tools.GeoAdventureLevelFactory
import com.ganageo.app.tools.GeoGameRules
import com.ganageo.app.tools.GeoLifePackage
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sign

@Composable
fun GeoAdventuresScreen(
    viewModel: GanaGeoViewModel,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<GeoGameStatus?>(null) }
    var loading by remember { mutableStateOf(true) }
    var localMode by remember { mutableStateOf(false) }
    var activeRun by remember { mutableStateOf<GeoGameRunStart?>(null) }
    var activeLevel by rememberSaveable { mutableIntStateOf(1) }
    var pendingPurchase by remember { mutableStateOf<GeoLifePackage?>(null) }
    var premiumLevelConfirmation by remember { mutableStateOf<Int?>(null) }
    var storyBeforeStart by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var pendingLifeType by remember { mutableStateOf("free") }
    var shownStories by remember { mutableStateOf(setOf<Int>()) }

    fun reload(preferLocal: Boolean = localMode) {
        scope.launch {
            loading = true
            viewModel.loadGeoGameStatus(preferLocal)
                .onSuccess {
                    status = it
                    localMode = it.isLocalTest
                    activeLevel = activeLevel.coerceAtMost(it.unlockedLevel.coerceAtLeast(1))
                }
                .onFailure { onMessage(it.message ?: "No se pudo cargar Geo Aventuras.") }
            loading = false
        }
    }

    fun startLevel(level: Int, lifeType: String) {
        val levelData = GeoAdventureLevelFactory.build(level)
        if (levelData.introStory != null && level !in shownStories) {
            pendingLifeType = lifeType
            storyBeforeStart = level to levelData.introStory
            shownStories = shownStories + level
            return
        }
        scope.launch {
            loading = true
            viewModel.startGeoGameRun(level, lifeType, localMode)
                .onSuccess {
                    activeLevel = level
                    activeRun = it
                }
                .onFailure { onMessage(it.message ?: "No se pudo iniciar el nivel.") }
            loading = false
        }
    }

    fun chooseLevel(level: Int) {
        val current = status ?: return
        if (level > current.unlockedLevel || loading) return
        when {
            current.freeLives > 0 -> startLevel(level, "free")
            current.premiumLives > 0 && current.premiumUsedToday < current.premiumDailyLimit -> premiumLevelConfirmation = level
            current.premiumLives > 0 -> onMessage("Tienes vidas amarillas disponibles, pero ya alcanzaste el límite diario de uso. Intenta nuevamente mañana.")
            else -> onMessage("No tienes vidas disponibles. Las vidas rojas se recuperan cada día.")
        }
    }

    fun buyPackage(packageInfo: GeoLifePackage) {
        scope.launch {
            loading = true
            viewModel.buyGeoGameLives(packageInfo.code)
                .onSuccess { purchase ->
                    localMode = purchase.isLocalTest
                    onMessage("Recibiste ${purchase.livesAdded} vida(s) amarilla(s). Los Rewards se liberan al usarlas.")
                    status = viewModel.loadGeoGameStatus(localMode).getOrNull() ?: status
                }
                .onFailure { onMessage(it.message ?: "No se pudieron comprar vidas.") }
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload(false) }

    DisposableEffect(activeRun) {
        onImmersiveChanged(activeRun != null)
        onDispose { if (activeRun != null) onImmersiveChanged(false) }
    }

    storyBeforeStart?.let { (level, story) ->
        StoryDialog(
            title = "Capítulo ${((level - 1) / 4) + 1} · ${GeoAdventureLevelFactory.build(level).levelName}",
            story = story,
            onDismiss = { storyBeforeStart = null },
            onContinue = {
                storyBeforeStart = null
                startLevel(level, pendingLifeType)
            }
        )
    }

    premiumLevelConfirmation?.let { level ->
        AlertDialog(
            onDismissRequest = { premiumLevelConfirmation = null },
            title = { Text("Usar una vida amarilla") },
            text = { Text("Ya no tienes vidas rojas. ¿Deseas entrar al nivel $level con una vida amarilla? El progreso de Rewards se libera al usarla.") },
            confirmButton = {
                Button(onClick = {
                    premiumLevelConfirmation = null
                    startLevel(level, "premium")
                }) { Text("Usar vida amarilla") }
            },
            dismissButton = { TextButton(onClick = { premiumLevelConfirmation = null }) { Text("Cancelar") } }
        )
    }

    pendingPurchase?.let { pack ->
        AlertDialog(
            onDismissRequest = { if (!loading) pendingPurchase = null },
            title = { Text("Confirmar compra de vidas") },
            text = { Text("Comprarás ${pack.lives} vida(s) amarilla(s) por ${pack.creditCost} créditos.") },
            confirmButton = {
                Button(onClick = { pendingPurchase = null; buyPackage(pack) }, enabled = !loading) { Text("Comprar") }
            },
            dismissButton = { TextButton(onClick = { pendingPurchase = null }, enabled = !loading) { Text("Cancelar") } }
        )
    }

    activeRun?.let { run ->
        GeoAdventureGame(
            level = GeoAdventureLevelFactory.build(activeLevel),
            run = run,
            viewModel = viewModel,
            onMessage = onMessage,
            onExit = {
                activeRun = null
                onImmersiveChanged(false)
                reload(localMode)
            }
        )
        return
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Geo Aventuras", "Primer arco · La selva del impacto", onBack)
        if (loading && status == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = NeonGreen) }
            return@Column
        }
        val current = status ?: GeoGameStatus(isLocalTest = true)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF102E45)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("GEO cayó herido en un planeta desconocido", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Ayúdalo a recuperarse, confiar en nuevos habitantes y encontrar el rastro de su nave antes que el Acechante.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            LifeInfo("❤️", current.freeLives.toString(), "Gratis", Modifier.weight(1f))
                            LifeInfo("💛", current.premiumLives.toString(), "Premium", Modifier.weight(1f))
                            LifeInfo("⭐", current.totalStars.toString(), "Estrellas", Modifier.weight(1f))
                        }
                        Text("Toca un nivel y entrarás directamente. Se usará primero una vida roja.", color = NeonGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Mapa de la historia", style = MaterialTheme.typography.titleLarge)
                        Text("Nivel desbloqueado: ${current.unlockedLevel}/20", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { reload(localMode) }) { Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar", tint = NeonGreen) }
                }
            }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxWidth().height(430.dp),
                    userScrollEnabled = false,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items((1..20).toList()) { level ->
                        LevelButton(
                            level = level,
                            unlocked = level <= current.unlockedLevel,
                            importantStory = level in setOf(1, 4, 5, 8, 9, 12, 13, 16, 17, 20),
                            onClick = { chooseLevel(level) }
                        )
                    }
                }
            }
            item {
                Text("Vidas amarillas", style = MaterialTheme.typography.titleLarge)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LifePackCard("1 vida", "2 créditos", "life_1", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                    LifePackCard("5 vidas", "10 créditos", "life_5", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                    LifePackCard("15 vidas", "30 créditos", "life_15", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                }
            }
        }
    }
}

@Composable
private fun StoryDialog(title: String, story: String, onDismiss: () -> Unit, onContinue: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(story, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        confirmButton = { Button(onClick = onContinue) { Text("Continuar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Volver") } }
    )
}

@Composable
private fun LifeInfo(symbol: String, value: String, label: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(14.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(symbol)
        Spacer(Modifier.width(6.dp))
        Column { Text(value, fontWeight = FontWeight.Bold); Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun LifePackCard(title: String, cost: String, code: String, enabled: Boolean, modifier: Modifier, onBuy: (String) -> Unit) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = Gold)
            Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(cost, color = NeonGreen, textAlign = TextAlign.Center)
            FilledTonalButton(onClick = { onBuy(code) }, enabled = enabled, contentPadding = PaddingValues(horizontal = 9.dp)) { Text("Comprar") }
        }
    }
}

@Composable
private fun LevelButton(level: Int, unlocked: Boolean, importantStory: Boolean, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, enabled = unlocked, modifier = Modifier.height(64.dp), contentPadding = PaddingValues(4.dp)) {
        if (unlocked) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(level.toString(), fontWeight = FontWeight.Bold)
                if (importantStory) Text("• historia", style = MaterialTheme.typography.labelSmall, color = Gold)
            }
        } else Icon(Icons.Rounded.Lock, contentDescription = "Bloqueado", modifier = Modifier.size(18.dp))
    }
}

private enum class GameOutcome { WON, LOST }
private data class Bullet(val x: Float, val y: Float, val direction: Float)
private data class EnemyBullet(val x: Float, val y: Float, val velocityX: Float, val velocityY: Float)
private data class EnemyRuntime(
    val x: Float,
    val y: Float,
    val direction: Float,
    val health: Int,
    val lastActionAt: Long = 0L,
    val alertedUntil: Long = 0L,
    val velocityY: Float = 0f
)

@Composable
private fun GeoAdventureGame(
    level: AdventureLevel,
    run: GeoGameRunStart,
    viewModel: GanaGeoViewModel,
    onMessage: (String) -> Unit,
    onExit: () -> Unit
) {
    ImmersiveLandscapeEffect()
    val context = LocalContext.current
    val audio = remember(level.number) { GameAudioController(context) }
    var musicEnabled by rememberSaveable { mutableStateOf(true) }
    var effectsEnabled by rememberSaveable { mutableStateOf(true) }

    DisposableEffect(audio) {
        audio.setMusicEnabled(musicEnabled)
        audio.setEffectsEnabled(effectsEnabled)
        audio.startMusic()
        onDispose { audio.release() }
    }
    LaunchedEffect(musicEnabled, effectsEnabled) {
        audio.setMusicEnabled(musicEnabled)
        audio.setEffectsEnabled(effectsEnabled)
    }

    val playerWidth = 46f
    val playerHeight = 58f
    var playerX by remember(level.number) { mutableFloatStateOf(70f) }
    var playerY by remember(level.number) { mutableFloatStateOf(520f) }
    var velocityY by remember(level.number) { mutableFloatStateOf(0f) }
    var moveDirection by remember { mutableFloatStateOf(0f) }
    var facing by remember { mutableFloatStateOf(1f) }
    var jumpQueued by remember { mutableStateOf(false) }
    var shootQueued by remember { mutableStateOf(false) }
    var interactQueued by remember { mutableStateOf(false) }
    var onGround by remember { mutableStateOf(false) }
    var jumpsRemaining by remember(level.number) { mutableIntStateOf(2) }
    var groundJumpAvailable by remember(level.number) { mutableStateOf(true) }
    var jumpBufferUntil by remember { mutableLongStateOf(0L) }
    var lastGroundedAt by remember { mutableLongStateOf(0L) }
    var lastPlayerShotAt by remember { mutableLongStateOf(0L) }
    var elapsedMs by remember { mutableLongStateOf(0L) }
    var collected by remember { mutableStateOf(setOf<Int>()) }
    var activeSwitches by remember { mutableStateOf(setOf<Int>()) }
    var destroyedCrates by remember { mutableStateOf(setOf<Int>()) }
    var collectedPickups by remember { mutableStateOf(setOf<Int>()) }
    var outcome by remember { mutableStateOf<GameOutcome?>(null) }
    var paused by remember { mutableStateOf(false) }
    var activated by remember(run.runId) { mutableStateOf(!run.needsActivation) }
    var activating by remember { mutableStateOf(false) }
    var activationRewards by remember { mutableLongStateOf(0L) }
    var reportingResult by remember { mutableStateOf(false) }
    var resultSaved by remember { mutableStateOf(false) }
    var resultError by remember { mutableStateOf<String?>(null) }
    var reportAttempt by remember { mutableIntStateOf(0) }
    var hearts by remember { mutableIntStateOf(3) }
    var shieldHits by remember { mutableIntStateOf(0) }
    var weaponPowerUntil by remember { mutableLongStateOf(0L) }
    var invulnerableUntil by remember { mutableLongStateOf(0L) }
    var companionAttackAt by remember { mutableLongStateOf(0L) }
    var acechanteX by remember(level.number) { mutableFloatStateOf(-650f) }
    var outroDismissed by remember { mutableStateOf(false) }
    var objectiveHint by remember(level.number) {
        mutableStateOf<String?>(
            "Objetivo: recoge 3 cristales. Puedes derrotar enemigos saltando sobre ellos o disparando. Luego activa el mecanismo brillante con la mano para abrir la salida."
        )
    }
    var objectiveHintUntil by remember(level.number) { mutableLongStateOf(6_000L) }
    val bullets = remember(level.number) { mutableStateListOf<Bullet>() }
    val enemyBullets = remember(level.number) { mutableStateListOf<EnemyBullet>() }
    val enemies = remember(level.number) {
        mutableStateListOf<EnemyRuntime>().apply {
            addAll(level.enemies.mapIndexed { index, enemy ->
                EnemyRuntime(enemy.x, enemy.y, if (index % 2 == 0) 1f else -1f, enemy.health)
            })
        }
    }

    fun endGame(result: GameOutcome) {
        if (outcome != null) return
        outcome = result
        if (result == GameOutcome.WON) audio.play(GameSound.VICTORY, 0.9f) else audio.play(GameSound.DEFEAT, 1f, 0.92f)
        audio.pauseMusic()
    }

    fun takeDamage() {
        if (elapsedMs < invulnerableUntil || outcome != null) return
        if (shieldHits > 0) {
            shieldHits--
            invulnerableUntil = elapsedMs + 900L
            audio.play(GameSound.HIT, 0.82f)
            return
        }
        hearts--
        invulnerableUntil = elapsedMs + 1_450L
        if (hearts <= 0) {
            endGame(GameOutcome.LOST)
        } else {
            audio.play(GameSound.HIT, 0.85f)
        }
    }

    BackHandler {
        if (outcome == null) paused = !paused
        else if (resultSaved) onExit()
    }

    LaunchedEffect(paused, outcome, musicEnabled) {
        if (paused || outcome != null || !musicEnabled) audio.pauseMusic() else audio.startMusic()
    }

    LaunchedEffect(level.number, outcome, paused) {
        if (outcome != null || paused) return@LaunchedEffect
        var previousNanos = withFrameNanos { it }
        while (outcome == null && !paused) {
            val now = withFrameNanos { it }
            val dt = ((now - previousNanos) / 1_000_000_000f).coerceIn(0f, 0.035f)
            previousNanos = now
            elapsedMs += (dt * 1000).toLong()

            val wasOnGround = onGround
            if (wasOnGround) lastGroundedAt = elapsedMs
            val previousBottom = playerY + playerHeight
            val speed = if (level.injured) 190f + level.number * 4f else 272f + level.number * 3.7f
            if (moveDirection != 0f) facing = moveDirection.sign
            playerX = (playerX + moveDirection * speed * dt).coerceIn(0f, level.width - playerWidth)

            if (jumpQueued) {
                jumpBufferUntil = elapsedMs + 170L
                jumpQueued = false
            }
            val canUseGroundJump = groundJumpAvailable && (wasOnGround || elapsedMs - lastGroundedAt <= 130L)
            if (jumpBufferUntil >= elapsedMs && (canUseGroundJump || jumpsRemaining > 0)) {
                val isDoubleJump = !canUseGroundJump
                velocityY = if (level.injured) {
                    if (isDoubleJump) -495f else -535f
                } else {
                    if (isDoubleJump) -610f else -655f
                }
                if (isDoubleJump) {
                    jumpsRemaining = (jumpsRemaining - 1).coerceAtLeast(0)
                } else {
                    groundJumpAvailable = false
                    jumpsRemaining = 1
                }
                onGround = false
                jumpBufferUntil = 0L
                audio.play(if (isDoubleJump) GameSound.DOUBLE_JUMP else GameSound.JUMP, 0.82f)
            }

            velocityY += 1_420f * dt
            var nextY = playerY + velocityY * dt
            onGround = false

            val movingPlatforms = level.movingPlatforms.mapIndexed { index, moving ->
                val phase = (elapsedMs / 1000f) / moving.periodSeconds * (Math.PI * 2.0) + index * 0.72
                val offset = kotlin.math.sin(phase).toFloat() * moving.travel
                com.ganageo.app.tools.GamePlatform(
                    x = if (moving.vertical) moving.x else moving.x + offset,
                    y = if (moving.vertical) moving.y + offset else moving.y,
                    width = moving.width,
                    height = 26f
                )
            }
            val collisionPlatforms = buildList {
                addAll(level.platforms)
                addAll(movingPlatforms)
                activeSwitches.forEach { index ->
                    val switch = level.switches.getOrNull(index)
                    if (switch != null) add(com.ganageo.app.tools.GamePlatform(switch.opensAtX, 520f, 245f, 28f))
                }
            }
            val nextBottom = nextY + playerHeight
            collisionPlatforms.forEach { platform ->
                val overlapsX = playerX + playerWidth > platform.x && playerX < platform.x + platform.width
                if (overlapsX && velocityY >= 0f && previousBottom <= platform.y + 10f && nextBottom >= platform.y) {
                    nextY = platform.y - playerHeight
                    velocityY = 0f
                    onGround = true
                    jumpsRemaining = 2
                    groundJumpAvailable = true
                    lastGroundedAt = elapsedMs
                }
            }
            playerY = nextY
            val playerRect = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)

            level.crystals.forEachIndexed { index, crystal ->
                val closeToPlayer = playerRect.overlaps(Rect(crystal.x - 24f, crystal.y - 24f, crystal.x + 24f, crystal.y + 24f))
                val lumaCollected = level.companion == "Luma" && abs(crystal.x - (playerX - 55f)) < 65f
                if (index !in collected && (closeToPlayer || lumaCollected)) {
                    collected = collected + index
                    audio.play(GameSound.CRYSTAL, 0.75f, 1f + index * 0.08f)
                }
            }

            level.pickups.forEachIndexed { index, pickup ->
                if (index !in collectedPickups && playerRect.overlaps(Rect(pickup.x - 28f, pickup.y - 28f, pickup.x + 28f, pickup.y + 28f))) {
                    collectedPickups = collectedPickups + index
                    when (pickup.kind) {
                        com.ganageo.app.tools.GamePickupKind.ENERGY -> hearts = (hearts + 1).coerceAtMost(3)
                        com.ganageo.app.tools.GamePickupKind.SHIELD -> shieldHits = (shieldHits + 1).coerceAtMost(2)
                        com.ganageo.app.tools.GamePickupKind.POWER -> weaponPowerUntil = elapsedMs + 20_000L
                    }
                    audio.play(GameSound.PICKUP, 0.8f)
                }
            }

            if (interactQueued) {
                var activatedSomething = false
                var activatedMechanism = false
                level.switches.forEachIndexed { index, switch ->
                    if (index !in activeSwitches && abs(playerX - switch.x) < 118f && abs(playerY - switch.y) < 125f) {
                        activeSwitches = activeSwitches + index
                        activatedSomething = true
                        activatedMechanism = true
                    }
                }
                val crateIndex = level.crates.indexOfFirst { crate ->
                    val idx = level.crates.indexOf(crate)
                    idx !in destroyedCrates && abs(playerX - crate.x) < 92f
                }
                if (crateIndex >= 0) {
                    destroyedCrates = destroyedCrates + crateIndex
                    activatedSomething = true
                }
                if (activatedSomething) audio.play(GameSound.SWITCH, 0.78f)
                if (activatedMechanism) {
                    val required = level.switches.size.coerceAtMost(if (level.number >= 9) 2 else 1)
                    val remaining = (required - activeSwitches.size).coerceAtLeast(0)
                    objectiveHint = if (remaining == 0) {
                        "Mecanismo activado. La salida ya está desbloqueada."
                    } else {
                        "Mecanismo activado. Falta $remaining para abrir la salida."
                    }
                    objectiveHintUntil = elapsedMs + 2_800L
                }
                interactQueued = false
            }

            val nearestPendingSwitch = level.switches.withIndex()
                .filter { it.index !in activeSwitches }
                .minByOrNull { abs(playerX - it.value.x) }
            if (nearestPendingSwitch != null && abs(playerX - nearestPendingSwitch.value.x) < 145f && abs(playerY - nearestPendingSwitch.value.y) < 145f) {
                objectiveHint = "Toca el botón de la mano para activar el mecanismo."
                objectiveHintUntil = elapsedMs + 450L
            } else if (objectiveHint != null && objectiveHintUntil > 0L && elapsedMs > objectiveHintUntil && playerX < level.goalX - 180f) {
                objectiveHint = null
                objectiveHintUntil = 0L
            }

            val weaponAvailable = level.weaponEnabled || weaponPowerUntil > elapsedMs
            if (shootQueued && weaponAvailable && elapsedMs - lastPlayerShotAt >= if (weaponPowerUntil > elapsedMs) 130L else 240L) {
                bullets += Bullet(playerX + playerWidth / 2f, playerY + 24f, facing)
                lastPlayerShotAt = elapsedMs
                audio.play(GameSound.SHOOT, 0.58f, if (weaponPowerUntil > elapsedMs) 1.2f else 1f)
                shootQueued = false
            } else if (shootQueued) {
                shootQueued = false
            }

            for (i in bullets.indices.reversed()) {
                val bullet = bullets[i]
                val moved = bullet.copy(x = bullet.x + bullet.direction * 760f * dt)
                var hit = false
                val crateIndex = level.crates.indexOfFirst { crate ->
                    val idx = level.crates.indexOf(crate)
                    idx !in destroyedCrates && Rect(moved.x - 8f, moved.y - 5f, moved.x + 8f, moved.y + 5f)
                        .overlaps(Rect(crate.x, crate.y, crate.x + 54f, crate.y + 54f))
                }
                if (crateIndex >= 0) {
                    destroyedCrates = destroyedCrates + crateIndex
                    hit = true
                    audio.play(GameSound.SWITCH, 0.55f)
                }
                if (!hit) {
                    for (e in enemies.indices) {
                        val enemy = enemies[e]
                        if (enemy.health > 0 && Rect(moved.x - 8f, moved.y - 5f, moved.x + 8f, moved.y + 5f)
                                .overlaps(Rect(enemy.x, enemy.y, enemy.x + 52f, enemy.y + 56f))) {
                            val damage = if (weaponPowerUntil > elapsedMs) 2 else 1
                            enemies[e] = enemy.copy(health = enemy.health - damage)
                            hit = true
                            break
                        }
                    }
                }
                if (hit || moved.x < 0f || moved.x > level.width) bullets.removeAt(i) else bullets[i] = moved
            }

            for (i in enemies.indices) {
                val enemy = enemies[i]
                if (enemy.health <= 0) continue
                val model = level.enemies[i]
                val enemyWidth = 52f
                val enemyHeight = 56f
                val distance = playerX - enemy.x
                val verticalDistance = abs((playerY + playerHeight / 2f) - (enemy.y + enemyHeight / 2f))
                val detectedNow = abs(distance) < model.detectionRange && verticalDistance < 260f
                val alertedUntil = if (detectedNow) elapsedMs + if (model.kind == com.ganageo.app.tools.GameEnemyKind.GUARDIAN) 3_400L else 2_800L else enemy.alertedUntil
                val chasing = elapsedMs < alertedUntil
                var direction = enemy.direction.takeIf { it != 0f } ?: 1f
                var x = enemy.x
                var y = enemy.y
                var velocityEnemyY = enemy.velocityY
                var lastAction = enemy.lastActionAt

                fun hasSupportAhead(candidateX: Float, candidateY: Float, facingDir: Float): Boolean {
                    val probeX = if (facingDir >= 0f) candidateX + enemyWidth + 10f else candidateX - 10f
                    val footY = candidateY + enemyHeight
                    return collisionPlatforms.any { platform ->
                        probeX >= platform.x + 8f && probeX <= platform.x + platform.width - 8f &&
                            kotlin.math.abs(platform.y - footY) <= 30f
                    }
                }

                if (model.kind == com.ganageo.app.tools.GameEnemyKind.FLYER) {
                    direction = if (chasing) {
                        distance.sign.takeIf { it != 0f } ?: direction
                    } else {
                        val leftBound = (model.x - model.range).coerceAtLeast(0f)
                        val rightBound = (model.x + model.range).coerceAtMost(level.width - 60f)
                        when {
                            x <= leftBound + 6f -> 1f
                            x >= rightBound - 6f -> -1f
                            else -> direction
                        }
                    }
                    val speedFactor = if (chasing) 1.24f else 0.82f
                    x = (x + direction * model.speed * speedFactor * dt).coerceIn(0f, level.width - 60f)
                    val waveDivisor = if (chasing) 310.0 else 520.0
                    val waveAmplitude = if (chasing) 82f else 55f
                    y = model.y + kotlin.math.sin((elapsedMs / waveDivisor) + i).toFloat() * waveAmplitude
                } else {
                    var desiredDirection = direction
                    val movementFactor = when (model.kind) {
                        com.ganageo.app.tools.GameEnemyKind.JUMPER -> if (chasing) 1.46f else 0.88f
                        com.ganageo.app.tools.GameEnemyKind.SHOOTER -> if (chasing) 0.92f else 0.52f
                        com.ganageo.app.tools.GameEnemyKind.GUARDIAN -> if (chasing) 2.28f else 0.62f
                        com.ganageo.app.tools.GameEnemyKind.WALKER -> if (chasing) 1.62f else 0.76f
                        else -> 1f
                    }

                    if (chasing) {
                        desiredDirection = when (model.kind) {
                            com.ganageo.app.tools.GameEnemyKind.SHOOTER -> when {
                                abs(distance) < 210f -> -distance.sign
                                abs(distance) > 390f -> distance.sign
                                else -> 0f
                            }
                            com.ganageo.app.tools.GameEnemyKind.WALKER,
                            com.ganageo.app.tools.GameEnemyKind.GUARDIAN,
                            com.ganageo.app.tools.GameEnemyKind.JUMPER -> when {
                                abs(distance) < 86f -> -(distance.sign.takeIf { it != 0f } ?: direction)
                                else -> distance.sign.takeIf { it != 0f } ?: direction
                            }
                            else -> distance.sign.takeIf { it != 0f } ?: direction
                        }
                    } else {
                        val leftBound = (model.x - model.range).coerceAtLeast(0f)
                        val rightBound = (model.x + model.range).coerceAtMost(level.width - 60f)
                        if (x <= leftBound + 6f) desiredDirection = 1f
                        if (x >= rightBound - 6f) desiredDirection = -1f
                    }

                    if (desiredDirection != 0f) {
                        val candidateX = (x + desiredDirection * model.speed * movementFactor * dt).coerceIn(0f, level.width - 60f)
                        val supportAhead = hasSupportAhead(candidateX, y, desiredDirection)
                        val allowRiskyFall = chasing && abs(distance) < 140f && (
                            model.kind == com.ganageo.app.tools.GameEnemyKind.WALKER ||
                                model.kind == com.ganageo.app.tools.GameEnemyKind.GUARDIAN ||
                                model.kind == com.ganageo.app.tools.GameEnemyKind.JUMPER
                            )
                        if (supportAhead || allowRiskyFall) {
                            x = candidateX
                        } else if (model.kind == com.ganageo.app.tools.GameEnemyKind.JUMPER && chasing && velocityEnemyY == 0f && abs(distance) in 95f..260f) {
                            x = candidateX
                            velocityEnemyY = -(560f + level.number * 4f)
                            lastAction = elapsedMs
                        } else {
                            desiredDirection *= -1f
                        }
                    }
                    direction = desiredDirection.takeIf { it != 0f } ?: direction

                    if (model.kind == com.ganageo.app.tools.GameEnemyKind.SHOOTER && chasing && abs(distance) < 520f && elapsedMs - lastAction >= 950L) {
                        val dx = playerX - x
                        val dy = (playerY + 24f) - (y + 22f)
                        val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                        enemyBullets += EnemyBullet(x + 24f, y + 22f, dx / len * 410f, dy / len * 410f)
                        lastAction = elapsedMs
                        audio.play(GameSound.ENEMY_SHOT, 0.48f)
                    }

                    if (model.kind == com.ganageo.app.tools.GameEnemyKind.GUARDIAN && chasing && velocityEnemyY == 0f && abs(distance) in 130f..220f && elapsedMs - lastAction >= 900L) {
                        velocityEnemyY = -(520f + level.number * 2f)
                        lastAction = elapsedMs
                    }
                    if ((model.kind == com.ganageo.app.tools.GameEnemyKind.GUARDIAN || model.kind == com.ganageo.app.tools.GameEnemyKind.JUMPER) &&
                        chasing && velocityEnemyY == 0f && abs(distance) < 100f && elapsedMs - lastAction >= 650L
                    ) {
                        velocityEnemyY = -(460f + level.number * 4f)
                        lastAction = elapsedMs
                    }

                    val previousBottom = y + enemyHeight
                    velocityEnemyY += 1_360f * dt
                    var nextY = y + velocityEnemyY * dt
                    var landed = false
                    val nextBottom = nextY + enemyHeight
                    collisionPlatforms.forEach { platform ->
                        val overlapsX = x + enemyWidth > platform.x + 4f && x < platform.x + platform.width - 4f
                        if (overlapsX && velocityEnemyY >= 0f && previousBottom <= platform.y + 18f && nextBottom >= platform.y) {
                            nextY = platform.y - enemyHeight
                            velocityEnemyY = 0f
                            landed = true
                        }
                    }
                    y = nextY
                    if (!landed && y > 800f) {
                        enemies[i] = enemy.copy(health = 0, x = x, y = y, direction = direction, lastActionAt = lastAction, alertedUntil = alertedUntil, velocityY = velocityEnemyY)
                        continue
                    }
                }

                val enemyRect = Rect(x, y, x + enemyWidth, y + enemyHeight)
                if (playerRect.overlaps(enemyRect)) {
                    val stomping = velocityY > 120f && previousBottom <= enemy.y + 18f &&
                        playerY + playerHeight >= enemy.y &&
                        playerX + playerWidth > x + 6f && playerX < x + enemyWidth - 6f
                    if (stomping) {
                        val stompDamage = when (model.kind) {
                            com.ganageo.app.tools.GameEnemyKind.GUARDIAN -> 1
                            com.ganageo.app.tools.GameEnemyKind.FLYER -> 2
                            else -> 2
                        }
                        val newHealth = (enemy.health - stompDamage).coerceAtLeast(0)
                        velocityY = if (model.kind == com.ganageo.app.tools.GameEnemyKind.GUARDIAN) -420f else -500f
                        playerY = (enemy.y - playerHeight - 2f).coerceAtLeast(0f)
                        onGround = false
                        groundJumpAvailable = false
                        jumpsRemaining = 1
                        invulnerableUntil = elapsedMs + 280L
                        if (newHealth <= 0) {
                            audio.play(GameSound.SWITCH, 0.7f, 1.18f)
                            x = x.coerceIn(0f, level.width - 60f)
                        } else {
                            audio.play(GameSound.HIT, 0.72f, 1.15f)
                        }
                        enemies[i] = enemy.copy(
                            x = x,
                            y = y,
                            direction = direction,
                            health = newHealth,
                            lastActionAt = lastAction,
                            alertedUntil = alertedUntil,
                            velocityY = velocityEnemyY
                        )
                        continue
                    } else {
                        takeDamage()
                        x = (x - direction * 56f).coerceIn(0f, level.width - 60f)
                        direction *= -1f
                    }
                }
                enemies[i] = enemy.copy(
                    x = x,
                    y = y,
                    direction = direction,
                    lastActionAt = lastAction,
                    alertedUntil = alertedUntil,
                    velocityY = velocityEnemyY
                )
            }

            for (i in enemyBullets.indices.reversed()) {
                val bullet = enemyBullets[i]
                val moved = bullet.copy(x = bullet.x + bullet.velocityX * dt, y = bullet.y + bullet.velocityY * dt)
                if (playerRect.overlaps(Rect(moved.x - 7f, moved.y - 7f, moved.x + 7f, moved.y + 7f))) {
                    enemyBullets.removeAt(i)
                    takeDamage()
                } else if (moved.x < 0f || moved.x > level.width || moved.y < 0f || moved.y > 760f) {
                    enemyBullets.removeAt(i)
                } else enemyBullets[i] = moved
            }

            if (level.companion == "Taro" && elapsedMs >= companionAttackAt) {
                val companionX = playerX - 65f
                val index = enemies.indexOfFirst { it.health > 0 && abs(it.x - companionX) < 150f }
                if (index >= 0) {
                    enemies[index] = enemies[index].copy(health = enemies[index].health - 1)
                    companionAttackAt = elapsedMs + 950L
                }
            }

            if (level.acechantePresent) {
                val target = playerX - 150f
                val chaseSpeed = 92f + level.number * 3.4f
                acechanteX += (target - acechanteX).sign * chaseSpeed * dt
                if (abs(playerX - acechanteX) < 62f) takeDamage()
            }

            if (level.hazards.any { playerRect.overlaps(Rect(it.x, it.y, it.x + it.width, it.y + it.height)) }) takeDamage()
            val requiredSwitches = level.switches.size.coerceAtMost(if (level.number >= 9) 2 else 1)
            if (playerY > 760f || elapsedMs > 360_000L) {
                endGame(GameOutcome.LOST)
            } else if (playerX + playerWidth >= level.goalX) {
                when {
                    collected.size < 3 -> {
                        objectiveHint = "La salida sigue cerrada: faltan ${3 - collected.size} cristales."
                        objectiveHintUntil = elapsedMs + 2_500L
                    }
                    activeSwitches.size < requiredSwitches -> {
                        val pending = requiredSwitches - activeSwitches.size
                        val nearest = level.switches.withIndex()
                            .filter { it.index !in activeSwitches }
                            .minByOrNull { abs(playerX - it.value.x) }
                        val directionText = when {
                            nearest == null -> ""
                            nearest.value.x < playerX -> " Regresa hacia la izquierda."
                            else -> " Sigue hacia la derecha."
                        }
                        val mechanismText = if (pending == 1) "1 mecanismo" else "$pending mecanismos"
                        objectiveHint = "La salida sigue cerrada: activa $mechanismText.$directionText"
                        objectiveHintUntil = elapsedMs + 3_200L
                    }
                    else -> endGame(GameOutcome.WON)
                }
            } else if (objectiveHint != null && objectiveHintUntil > 0L && elapsedMs > objectiveHintUntil) {
                objectiveHint = null
                objectiveHintUntil = 0L
            }
        }
    }

    val elapsedSeconds = (elapsedMs / 1000L).toInt()
    val requiredMechanisms = level.switches.size.coerceAtMost(if (level.number >= 9) 2 else 1)
    LaunchedEffect(run.runId, elapsedSeconds, activated, outcome) {
        if (run.needsActivation && !activated && !activating && outcome == null && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            activating = true
            viewModel.activateGeoGameRun(run)
                .onSuccess {
                    activated = true
                    activationRewards = it.awardedPoints
                    onMessage(if (it.awardedPoints > 0) "Vida amarilla usada: ganaste ${it.awardedPoints} Geo Rewards." else "Vida amarilla usada: se actualizó tu progreso de Rewards.")
                }
                .onFailure { if (!it.message.orEmpty().contains("not ready", true)) onMessage(it.message ?: "No se pudo activar la vida amarilla.") }
            activating = false
        }
    }

    LaunchedEffect(outcome, reportAttempt) {
        val finalOutcome = outcome ?: return@LaunchedEffect
        if (resultSaved || reportingResult) return@LaunchedEffect
        reportingResult = true
        resultError = null
        var canFinish = activated
        if (run.needsActivation && !canFinish && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            viewModel.activateGeoGameRun(run).onSuccess { canFinish = true; activated = true; activationRewards = it.awardedPoints }
                .onFailure { resultError = it.message ?: "No se pudo confirmar la vida amarilla." }
        }
        if (run.needsActivation && !canFinish) {
            if (elapsedSeconds < GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
                runCatching { viewModel.cancelGeoGameRun(run) }
                    .onSuccess { onMessage("La partida terminó antes de activar la vida amarilla; la vida fue devuelta."); resultSaved = true }
                    .onFailure { resultError = it.message ?: "No se pudo devolver la vida todavía." }
            }
            reportingResult = false
            return@LaunchedEffect
        }
        val won = finalOutcome == GameOutcome.WON
        val stars = GeoGameRules.calculateStars(won, collected.size, elapsedSeconds, level.parSeconds)
        val score = (playerX / 3f).toLong() + collected.size * 700L + enemies.count { it.health <= 0 } * 300L + activeSwitches.size * 220L + if (won) 1_800L else 0L
        viewModel.finishGeoGameRun(run, won, stars, score, elapsedMs)
            .onSuccess { resultSaved = true }
            .onFailure { resultError = it.message ?: "No se pudo guardar el resultado." }
        reportingResult = false
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF040D13))) {
        Canvas(Modifier.fillMaxSize()) {
            val viewportWidth = size.width
            val viewportHeight = size.height
            val gameTop = 48f
            val gameBottom = viewportHeight - 88f
            val scaleY = (gameBottom - gameTop) / 720f
            val cameraX = (playerX - viewportWidth * 0.30f).coerceIn(0f, max(level.width - viewportWidth, 0f))
            fun sy(value: Float) = gameTop + value * scaleY
            val worldIndex = (level.number - 1) / 5
            val skyTop = listOf(Color(0xFF071B2C), Color(0xFF10253D), Color(0xFF151B36), Color(0xFF07151F))[worldIndex]
            val skyBottom = listOf(Color(0xFF164F5C), Color(0xFF31573E), Color(0xFF4B315B), Color(0xFF26384A))[worldIndex]
            val farColor = listOf(Color(0xFF123E3B), Color(0xFF284C38), Color(0xFF302A4B), Color(0xFF233746))[worldIndex]
            val nearColor = listOf(Color(0xFF0B2F25), Color(0xFF173D2A), Color(0xFF201C37), Color(0xFF142B32))[worldIndex]

            drawRect(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(skyTop, skyBottom)), size = size)
            repeat(18) { i ->
                val px = ((i * 137f - cameraX * 0.035f) % (viewportWidth + 160f)) - 50f
                val py = gameTop + 25f + (i * 67 % 210)
                drawCircle(Color.White.copy(alpha = 0.22f + (i % 3) * 0.08f), 1.5f + (i % 2), Offset(px, py))
            }
            val planetX = viewportWidth - 92f - (cameraX * 0.015f % 70f)
            drawCircle(Color(0xFFFFD27A).copy(alpha = 0.92f), 52f, Offset(planetX, gameTop + 64f))
            drawOval(Color(0xFF9CC9D8).copy(alpha = 0.26f), Offset(planetX - 76f, gameTop + 55f), Size(152f, 22f))

            fun mountainLayer(parallax: Float, baseY: Float, amplitude: Float, color: Color, spacing: Float) {
                val path = Path().apply {
                    moveTo(0f, viewportHeight)
                    lineTo(0f, sy(baseY))
                    var px = -((cameraX * parallax) % spacing) - spacing
                    var peak = 0
                    while (px < viewportWidth + spacing) {
                        lineTo(px + spacing * 0.5f, sy(baseY - amplitude - (peak % 3) * 18f))
                        lineTo(px + spacing, sy(baseY))
                        px += spacing
                        peak++
                    }
                    lineTo(viewportWidth, viewportHeight)
                    close()
                }
                drawPath(path, color)
            }
            mountainLayer(0.08f, 430f, 150f, farColor.copy(alpha = 0.72f), 310f)
            mountainLayer(0.16f, 510f, 105f, nearColor.copy(alpha = 0.86f), 230f)

            repeat(16) { i ->
                val treeX = ((i * 175f - cameraX * 0.24f) % (viewportWidth + 260f)) - 80f
                val trunkTop = sy(245f + (i % 4) * 26f)
                drawRect(Color(0xFF132A24).copy(alpha = 0.88f), Offset(treeX, trunkTop), Size(20f + (i % 3) * 5f, sy(620f) - trunkTop))
                drawCircle(Color(0xFF194A35).copy(alpha = 0.82f), 62f + (i % 3) * 11f, Offset(treeX + 10f, trunkTop - 12f))
                if (i % 3 == 0) {
                    drawLine(Color(0xFF72A86D).copy(alpha = 0.45f), Offset(treeX + 8f, trunkTop - 20f), Offset(treeX + 32f, sy(420f)), 4f)
                }
            }

            repeat(9) { i ->
                val fogY = sy(330f + i * 34f)
                val fogX = ((i * 215f - cameraX * 0.12f + elapsedMs * (0.006f + i * 0.0004f)) % (viewportWidth + 340f)) - 140f
                drawOval(Color(0xFFD7F7EB).copy(alpha = 0.045f), Offset(fogX, fogY), Size(340f, 64f))
            }

            // Luces, hojas y vegetación animada para que el mundo no se sienta estático.
            repeat(24) { i ->
                val drift = elapsedMs * (0.010f + (i % 4) * 0.002f)
                val fireflyX = ((i * 151f - cameraX * 0.33f + drift) % (viewportWidth + 180f)) - 60f
                val fireflyY = sy(250f + (i * 73 % 315)) + kotlin.math.sin(elapsedMs / 360.0 + i).toFloat() * 16f
                val glow = (0.18f + 0.16f * (1f + kotlin.math.sin(elapsedMs / 220.0 + i).toFloat())).coerceIn(0.08f, 0.48f)
                val glowColor = when (worldIndex) {
                    0 -> Color(0xFFA8FF78)
                    1 -> Color(0xFF7CE7D2)
                    2 -> Color(0xFFE0A9FF)
                    else -> Color(0xFF8ED8FF)
                }
                drawCircle(glowColor.copy(alpha = glow * 0.28f), 10f, Offset(fireflyX, fireflyY))
                drawCircle(glowColor.copy(alpha = glow), 2.6f, Offset(fireflyX, fireflyY))
            }

            repeat(14) { i ->
                val baseX = ((i * 132f - cameraX * 0.58f) % (viewportWidth + 190f)) - 55f
                val baseY = sy(610f)
                val sway = kotlin.math.sin(elapsedMs / 520.0 + i * 0.8).toFloat() * 13f
                val stemTop = sy(515f - (i % 4) * 18f)
                drawLine(Color(0xFF245D3A).copy(alpha = 0.85f), Offset(baseX, baseY), Offset(baseX + sway, stemTop), 7f)
                drawOval(Color(0xFF3D8B4F).copy(alpha = 0.72f), Offset(baseX + sway - 28f, stemTop - 12f), Size(42f, 18f))
                drawOval(Color(0xFF2E7041).copy(alpha = 0.78f), Offset(baseX + sway + 2f, stemTop + 8f), Size(48f, 19f))
            }

            if (level.number <= 4) {
                val wreckX = 330f - cameraX * 0.48f
                drawRoundRect(Color(0xFF39464F).copy(alpha = 0.70f), Offset(wreckX, sy(505f)), Size(132f, 64f * scaleY), androidx.compose.ui.geometry.CornerRadius(18f))
                drawLine(Color(0xFFFF6B35).copy(alpha = 0.72f), Offset(wreckX + 22f, sy(520f)), Offset(wreckX + 102f, sy(550f)), 5f)
                repeat(4) { smoke ->
                    val smokeY = sy(492f - smoke * 35f) - (elapsedMs * (0.008f + smoke * 0.002f) % 42f)
                    drawCircle(Color(0xFFB0BEC5).copy(alpha = 0.11f - smoke * 0.015f), 26f + smoke * 7f, Offset(wreckX + 76f + smoke * 8f, smokeY))
                }
            }

            if (worldIndex >= 2) {
                repeat(7) { i ->
                    val ruinX = ((i * 430f - cameraX * 0.38f) % (viewportWidth + 520f)) - 120f
                    drawRect(Color(0xFF53606B).copy(alpha = 0.52f), Offset(ruinX, sy(390f)), Size(45f, sy(620f) - sy(390f)))
                    drawLine(Color(0xFF7CE7D2).copy(alpha = 0.32f), Offset(ruinX + 7f, sy(440f)), Offset(ruinX + 37f, sy(440f)), 3f)
                }
            }

            if (level.number == 2 || level.number in 17..18) {
                repeat(30) { i ->
                    val rainX = ((i * 83f + elapsedMs * 0.09f - cameraX * 0.18f) % (viewportWidth + 80f)) - 40f
                    val rainY = gameTop + ((i * 61f + elapsedMs * 0.17f) % (gameBottom - gameTop + 90f))
                    drawLine(Color(0xFFA8D8FF).copy(alpha = 0.17f), Offset(rainX, rainY), Offset(rainX - 9f, rainY + 28f), 1.6f)
                }
            }

            val movingPlatforms = level.movingPlatforms.mapIndexed { index, moving ->
                val phase = (elapsedMs / 1000f) / moving.periodSeconds * (Math.PI * 2.0) + index * 0.72
                val offset = kotlin.math.sin(phase).toFloat() * moving.travel
                com.ganageo.app.tools.GamePlatform(
                    x = if (moving.vertical) moving.x else moving.x + offset,
                    y = if (moving.vertical) moving.y + offset else moving.y,
                    width = moving.width,
                    height = 26f
                )
            }
            val drawPlatforms = buildList {
                addAll(level.platforms)
                addAll(movingPlatforms)
                activeSwitches.forEach { index -> level.switches.getOrNull(index)?.let { add(com.ganageo.app.tools.GamePlatform(it.opensAtX, 520f, 245f, 28f)) } }
            }
            drawPlatforms.forEach { platform ->
                val isMoving = movingPlatforms.any { it.x == platform.x && it.y == platform.y }
                drawRoundRect(
                    if (isMoving) Color(0xFF2B7A78) else Color(0xFF2C6E3F),
                    Offset(platform.x - cameraX, sy(platform.y)),
                    Size(platform.width, platform.height * scaleY),
                    androidx.compose.ui.geometry.CornerRadius(8f)
                )
                drawRect(Color(0xFF5B3C2B), Offset(platform.x - cameraX, sy(platform.y + 14f)), Size(platform.width, max((platform.height - 14f) * scaleY, 5f)))
                repeat((platform.width / 48f).toInt()) { j ->
                    drawCircle(Color(0xFF6DBB5A).copy(alpha = 0.45f), 4f, Offset(platform.x + 18f + j * 48f - cameraX, sy(platform.y + 7f)))
                }
            }

            level.hazards.forEach { hazard ->
                val path = Path().apply {
                    moveTo(hazard.x - cameraX, sy(hazard.y + hazard.height))
                    lineTo(hazard.x + hazard.width / 2f - cameraX, sy(hazard.y))
                    lineTo(hazard.x + hazard.width - cameraX, sy(hazard.y + hazard.height))
                    close()
                }
                drawPath(path, Color(0xFFFF4D4D))
                drawPath(path, Color(0xFFFFA726), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5f))
            }
            level.crates.forEachIndexed { index, crate ->
                if (index in destroyedCrates) return@forEachIndexed
                drawRoundRect(Color(0xFF9A6A3A), Offset(crate.x - cameraX, sy(crate.y)), Size(54f, 54f * scaleY), androidx.compose.ui.geometry.CornerRadius(5f))
                drawLine(Color(0xFF4F311E), Offset(crate.x - cameraX, sy(crate.y)), Offset(crate.x + 54f - cameraX, sy(crate.y + 54f)), 5f)
                drawLine(Color(0xFF4F311E), Offset(crate.x + 54f - cameraX, sy(crate.y)), Offset(crate.x - cameraX, sy(crate.y + 54f)), 5f)
            }
            level.switches.forEachIndexed { index, switch ->
                val active = index in activeSwitches
                val pulse = 1f + kotlin.math.sin(elapsedMs / 170.0 + index).toFloat() * 0.16f
                if (!active) {
                    drawCircle(Gold.copy(alpha = 0.16f), 34f * pulse, Offset(switch.x + 17f - cameraX, sy(switch.y + 22f)))
                    val arrowY = sy(switch.y - 46f - kotlin.math.sin(elapsedMs / 210.0 + index).toFloat() * 9f)
                    val arrow = Path().apply {
                        moveTo(switch.x + 17f - cameraX, arrowY + 18f)
                        lineTo(switch.x + 2f - cameraX, arrowY)
                        lineTo(switch.x + 32f - cameraX, arrowY)
                        close()
                    }
                    drawPath(arrow, Gold)
                }
                drawRoundRect(if (active) NeonGreen else Gold, Offset(switch.x - cameraX, sy(switch.y)), Size(34f, 50f * scaleY), androidx.compose.ui.geometry.CornerRadius(8f))
                drawCircle(Color.White.copy(alpha = 0.82f), 5f, Offset(switch.x + 17f - cameraX, sy(switch.y + 13f)))
                if (active) drawCircle(Color.White.copy(alpha = 0.18f), 25f, Offset(switch.x + 17f - cameraX, sy(switch.y + 22f)))
            }

            enemies.forEachIndexed { index, enemy ->
                if (enemy.health <= 0) return@forEachIndexed
                val kind = level.enemies[index].kind
                val bodyColor = when (kind) {
                    com.ganageo.app.tools.GameEnemyKind.WALKER -> Color(0xFF7B2CBF)
                    com.ganageo.app.tools.GameEnemyKind.JUMPER -> Color(0xFFE76F51)
                    com.ganageo.app.tools.GameEnemyKind.FLYER -> Color(0xFF00A6A6)
                    com.ganageo.app.tools.GameEnemyKind.SHOOTER -> Color(0xFFB5179E)
                    com.ganageo.app.tools.GameEnemyKind.GUARDIAN -> Color(0xFF5A189A)
                }
                val w = if (kind == com.ganageo.app.tools.GameEnemyKind.GUARDIAN) 66f else 50f
                val h = if (kind == com.ganageo.app.tools.GameEnemyKind.GUARDIAN) 70f else 54f
                val alerted = enemy.alertedUntil > elapsedMs
                val breathe = kotlin.math.sin(elapsedMs / 180.0 + index).toFloat() * 2.2f
                if (alerted) {
                    drawCircle(Color(0xFFFF5A5F).copy(alpha = 0.16f), 38f + breathe, Offset(enemy.x + w / 2f - cameraX, sy(enemy.y + h / 2f)))
                    drawCircle(Color(0xFFFFD166), 4f, Offset(enemy.x + w / 2f - cameraX, sy(enemy.y - 18f - breathe)))
                }
                drawRoundRect(bodyColor, Offset(enemy.x - cameraX, sy(enemy.y - breathe)), Size(w, (h + breathe) * scaleY), androidx.compose.ui.geometry.CornerRadius(14f))
                if (kind == com.ganageo.app.tools.GameEnemyKind.FLYER) {
                    drawOval(bodyColor.copy(alpha = 0.58f), Offset(enemy.x - 18f - cameraX, sy(enemy.y + 15f)), Size(24f, 14f))
                    drawOval(bodyColor.copy(alpha = 0.58f), Offset(enemy.x + 44f - cameraX, sy(enemy.y + 15f)), Size(24f, 14f))
                }
                drawCircle(Color.White, 5f, Offset(enemy.x + 15f - cameraX, sy(enemy.y + 17f)))
                drawCircle(Color.White, 5f, Offset(enemy.x + 35f - cameraX, sy(enemy.y + 17f)))
                val maxHealth = level.enemies[index].health.coerceAtLeast(1)
                drawRect(Color.Black.copy(alpha = 0.45f), Offset(enemy.x - cameraX, sy(enemy.y - 11f)), Size(w, 5f))
                drawRect(Color(0xFFFF5A5F), Offset(enemy.x - cameraX, sy(enemy.y - 11f)), Size(w * enemy.health.coerceAtLeast(0) / maxHealth, 5f))
            }

            level.crystals.forEachIndexed { index, crystal ->
                if (index !in collected) {
                    val path = Path().apply {
                        moveTo(crystal.x - cameraX, sy(crystal.y - 24f)); lineTo(crystal.x + 18f - cameraX, sy(crystal.y))
                        lineTo(crystal.x - cameraX, sy(crystal.y + 24f)); lineTo(crystal.x - 18f - cameraX, sy(crystal.y)); close()
                    }
                    drawPath(path, androidx.compose.ui.graphics.Brush.radialGradient(listOf(Color.White, Color(0xFF00E5FF), Color(0xFF0077B6))))
                }
            }
            level.pickups.forEachIndexed { index, pickup ->
                if (index in collectedPickups) return@forEachIndexed
                val color = when (pickup.kind) {
                    com.ganageo.app.tools.GamePickupKind.ENERGY -> Color(0xFFFF5A5F)
                    com.ganageo.app.tools.GamePickupKind.SHIELD -> Color(0xFF56CFE1)
                    com.ganageo.app.tools.GamePickupKind.POWER -> Gold
                }
                drawCircle(color.copy(alpha = 0.28f), 24f, Offset(pickup.x - cameraX, sy(pickup.y)))
                drawCircle(color, 13f, Offset(pickup.x - cameraX, sy(pickup.y)))
                drawCircle(Color.White.copy(alpha = 0.8f), 4f, Offset(pickup.x - 4f - cameraX, sy(pickup.y - 4f)))
            }

            bullets.forEach { bullet ->
                drawCircle(Gold.copy(alpha = 0.30f), 13f, Offset(bullet.x - cameraX, sy(bullet.y)))
                drawCircle(Gold, 6f, Offset(bullet.x - cameraX, sy(bullet.y)))
            }
            enemyBullets.forEach { bullet ->
                drawCircle(Color(0xFFFF4D8D).copy(alpha = 0.30f), 12f, Offset(bullet.x - cameraX, sy(bullet.y)))
                drawCircle(Color(0xFFFF4D8D), 6f, Offset(bullet.x - cameraX, sy(bullet.y)))
            }

            val requiredSwitches = level.switches.size.coerceAtMost(if (level.number >= 9) 2 else 1)
            val portalReady = collected.size >= 3 && activeSwitches.size >= requiredSwitches
            drawRoundRect(if (portalReady) Gold else Color(0xFF607D8B), Offset(level.goalX - cameraX, sy(485f)), Size(34f, 135f * scaleY), androidx.compose.ui.geometry.CornerRadius(14f))
            drawCircle(if (portalReady) NeonGreen else Color(0xFF455A64), 42f, Offset(level.goalX + 17f - cameraX, sy(472f)))
            drawCircle(Color.White.copy(alpha = if (portalReady) 0.45f else 0.12f), 22f, Offset(level.goalX + 17f - cameraX, sy(472f)))

            if (level.acechantePresent) {
                drawRoundRect(Color(0xFF0A0710), Offset(acechanteX - cameraX, sy(playerY - 25f)), Size(42f, 98f * scaleY), androidx.compose.ui.geometry.CornerRadius(19f))
                drawLine(Color(0xFF31253A), Offset(acechanteX + 8f - cameraX, sy(playerY + 5f)), Offset(acechanteX - 20f - cameraX, sy(playerY + 60f)), 8f)
                drawCircle(Color(0xFFECEFF1), 3.5f, Offset(acechanteX + 12f - cameraX, sy(playerY + 2f)))
                drawCircle(Color(0xFFECEFF1), 3.5f, Offset(acechanteX + 29f - cameraX, sy(playerY + 2f)))
            }

            level.companion?.let { name ->
                val companionX = playerX - 62f
                val companionColor = if (name == "Luma") Color(0xFF62D9C7) else Color(0xFF7CB342)
                drawCircle(companionColor.copy(alpha = 0.24f), 31f, Offset(companionX - cameraX, sy(playerY + 34f)))
                drawCircle(companionColor, 23f, Offset(companionX - cameraX, sy(playerY + 34f)))
                drawCircle(Color.White, 4f, Offset(companionX - 7f - cameraX, sy(playerY + 29f)))
                drawCircle(Color.White, 4f, Offset(companionX + 7f - cameraX, sy(playerY + 29f)))
            }

            val playerColor = when {
                elapsedMs < invulnerableUntil && (elapsedMs / 100L) % 2L == 0L -> Color.White
                run.lifeType == "premium" -> Gold
                else -> Color(0xFFE53935)
            }
            if (!onGround && jumpsRemaining == 0) {
                drawCircle(Color(0xFF8EF6E4).copy(alpha = 0.24f), 38f, Offset(playerX + playerWidth / 2f - cameraX, sy(playerY + playerHeight / 2f)))
            }
            drawRoundRect(playerColor, Offset(playerX - cameraX, sy(playerY)), Size(playerWidth, playerHeight * scaleY), androidx.compose.ui.geometry.CornerRadius(12f))
            drawCircle(Color.White, 5f, Offset(playerX + 14f - cameraX, sy(playerY + 18f)))
            drawCircle(Color.White, 5f, Offset(playerX + 33f - cameraX, sy(playerY + 18f)))
            if (level.injured) drawLine(Color(0xFFB0BEC5), Offset(playerX + 5f - cameraX, sy(playerY + 42f)), Offset(playerX + 40f - cameraX, sy(playerY + 50f)), 5f)

            repeat(22) { i ->
                val leafX = ((i * 167f - cameraX * 0.72f) % (viewportWidth + 260f)) - 90f
                val leafY = sy(210f + (i * 83 % 420))
                drawOval(Color(0xFF7CB342).copy(alpha = 0.18f), Offset(leafX, leafY), Size(18f, 7f))
            }
        }

        Row(
            Modifier.fillMaxWidth().background(Color(0xD9061827)).padding(horizontal = 10.dp, vertical = 4.dp).align(Alignment.TopCenter),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Nivel ${level.number} · ${level.levelName}", fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(14.dp))
            Text(
                "Vida ${hearts.coerceAtLeast(0)}/3  ${if (shieldHits > 0) "🛡️$shieldHits  " else ""}💎 ${collected.size}/3  ⚙ ${activeSwitches.size}/$requiredMechanisms  ↑x$jumpsRemaining  ${elapsedSeconds}s",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.weight(1f))
            level.companion?.let { Text("$it", color = NeonGreen); Spacer(Modifier.width(10.dp)) }
            if (activationRewards > 0) Text("+$activationRewards Rewards", color = Gold, fontWeight = FontWeight.Bold)
            IconButton(onClick = { paused = true }) { Icon(Icons.Rounded.Pause, contentDescription = "Pausa") }
        }

        objectiveHint?.let { hint ->
            Card(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 50.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xDD0B321E)),
                shape = RoundedCornerShape(16.dp)
            ) { Text(hint, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp), color = Gold, fontWeight = FontWeight.Bold) }
        }

        Row(
            Modifier.fillMaxWidth().padding(12.dp).align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                HoldButton(Icons.Rounded.ArrowBack, "Izquierda") { pressed -> moveDirection = if (pressed) -1f else if (moveDirection < 0f) 0f else moveDirection }
                HoldButton(Icons.Rounded.ArrowForward, "Derecha") { pressed -> moveDirection = if (pressed) 1f else if (moveDirection > 0f) 0f else moveDirection }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                if (level.weaponEnabled || weaponPowerUntil > elapsedMs) HoldButton(Icons.Rounded.PlayArrow, "Disparar", accent = Gold) { if (it) shootQueued = true }
                HoldButton(Icons.Rounded.TouchApp, "Interactuar", accent = Color(0xFF62D9C7)) { if (it) interactQueued = true }
                HoldButton(Icons.Rounded.KeyboardArrowUp, "Doble salto", accent = NeonGreen) { if (it) jumpQueued = true }
            }
        }

        if (paused) {
            OverlayCard(title = "Partida en pausa") {
                Text("Doble salto activo · enemigos inteligentes · objetos interactivos", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                Button(onClick = { paused = false }, colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Continuar") }
                OutlinedButton(onClick = { musicEnabled = !musicEnabled }) { Text(if (musicEnabled) "Música: activada" else "Música: desactivada") }
                OutlinedButton(onClick = { effectsEnabled = !effectsEnabled }) { Text(if (effectsEnabled) "Efectos: activados" else "Efectos: desactivados") }
                OutlinedButton(onClick = { paused = false; endGame(GameOutcome.LOST) }) { Text("Reiniciar desde el mapa") }
                TextButton(onClick = onExit) { Text("Volver a niveles") }
            }
        }

        if (outcome != null && resultSaved && outcome == GameOutcome.WON && level.outroStory != null && !outroDismissed) {
            OverlayCard(title = "Historia · ${level.levelName}") {
                Text(level.outroStory, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { outroDismissed = true }, colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Continuar") }
            }
        } else if (outcome != null) {
            OverlayCard(title = if (outcome == GameOutcome.WON) "¡Nivel completado!" else "Fin de la partida") {
                Text("Cristales: ${collected.size}/3 · Tiempo: ${elapsedSeconds}s · Enemigos: ${enemies.count { it.health <= 0 }} · Mecanismos: ${activeSwitches.size}")
                if (outcome == GameOutcome.LOST) Text(if (hearts <= 0) "GEO quedó sin energía." else "El recorrido superó a GEO. Usa el doble salto, los objetos y los puntos seguros.", color = Gold, textAlign = TextAlign.Center)
                resultError?.let { Text(it, color = Color(0xFFFFB4AB), textAlign = TextAlign.Center) }
                Button(
                    onClick = { if (resultSaved) onExit() else reportAttempt++ },
                    enabled = !reportingResult,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) {
                    if (reportingResult) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = DeepGreen)
                    else Icon(if (resultSaved) Icons.Rounded.ArrowBack else Icons.Rounded.Refresh, contentDescription = null)
                    Text(if (resultSaved) " Volver a niveles" else " Reintentar guardado")
                }
            }
        }
    }
}

@Composable
private fun OverlayCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.74f)), contentAlignment = Alignment.Center) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(0.60f)) {
            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                content()
            }
        }
    }
}

@Composable
private fun HoldButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    accent: Color = NeonGreen,
    onPressed: (Boolean) -> Unit
) {
    Box(
        modifier = Modifier.size(66.dp).background(accent.copy(alpha = 0.20f), CircleShape).pointerInput(Unit) {
            detectTapGestures(onPress = { onPressed(true); tryAwaitRelease(); onPressed(false) })
        },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = accent, modifier = Modifier.size(36.dp))
    }
}


@Composable
private fun ImmersiveLandscapeEffect() {
    val context = LocalContext.current
    DisposableEffect(Unit) {
        val activity = context.findActivity()
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
