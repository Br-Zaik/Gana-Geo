package com.ganageo.app.ui.tools

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.ExamBank
import com.ganageo.app.data.ExamQuestion
import com.ganageo.app.data.ExamQuestionType
import com.ganageo.app.data.ExamSession
import com.ganageo.app.data.ExamStore
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ExamBuilderScreen(onBack: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { ExamStore(context.applicationContext) }
    val banks by store.banks.collectAsState(initial = emptyList())
    val savedSession by store.session.collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    var selectedBankId by rememberSaveable { mutableStateOf<String?>(null) }
    val selectedBank = banks.firstOrNull { it.id == selectedBankId }
    var screenMode by rememberSaveable { mutableIntStateOf(0) } // 0 banks, 1 edit, 2 exam
    var bankName by rememberSaveable { mutableStateOf("") }
    var bankCourse by rememberSaveable { mutableStateOf("") }
    var editBankName by rememberSaveable { mutableStateOf("") }
    var editBankCourse by rememberSaveable { mutableStateOf("") }
    var question by rememberSaveable { mutableStateOf("") }
    var questionType by rememberSaveable { mutableIntStateOf(0) }
    var optionA by rememberSaveable { mutableStateOf("") }
    var optionB by rememberSaveable { mutableStateOf("") }
    var optionC by rememberSaveable { mutableStateOf("") }
    var optionD by rememberSaveable { mutableStateOf("") }
    var correctIndex by rememberSaveable { mutableIntStateOf(0) }
    var explanation by rememberSaveable { mutableStateOf("") }
    var examIndex by rememberSaveable { mutableIntStateOf(0) }
    var examAnswers by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var revealResults by rememberSaveable { mutableStateOf(false) }
    var elapsedSeconds by rememberSaveable { mutableIntStateOf(0) }
    var durationMinutes by rememberSaveable { mutableStateOf("0") }

    LaunchedEffect(screenMode, revealResults, selectedBankId) {
        while (screenMode == 2 && !revealResults) {
            delay(1000)
            elapsedSeconds++
            val limit = durationMinutes.toIntOrNull()?.times(60) ?: 0
            if (limit > 0 && elapsedSeconds >= limit) revealResults = true
        }
    }

    LaunchedEffect(selectedBankId, screenMode) {
        if (screenMode == 1) {
            banks.firstOrNull { it.id == selectedBankId }?.let {
                editBankName = it.name
                editBankCourse = it.course
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("No se pudo leer el archivo")
            }.mapCatching { store.importBank(it) }
                .onSuccess { onMessage("Banco importado: ${it.name}") }
                .onFailure { onMessage(it.message ?: "No se pudo importar") }
        }
    }
    var pendingExport by remember { mutableStateOf<ExamBank?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val bank = pendingExport
        if (uri != null && bank != null) scope.launch {
            runCatching {
                context.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(store.exportBank(bank)) }
                    ?: error("No se pudo guardar")
            }.onSuccess { onMessage("JSON exportado") }.onFailure { onMessage(it.message ?: "No se pudo exportar") }
        }
        pendingExport = null
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Exámenes y cuestionarios", "Bancos, alternativas, verdadero/falso y revisión", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (screenMode == 0) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Nuevo banco", style = MaterialTheme.typography.titleLarge)
                            OutlinedTextField(bankName, { bankName = it.take(100) }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(bankCourse, { bankCourse = it.take(100) }, label = { Text("Curso (opcional)") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = {
                                scope.launch {
                                    runCatching { store.createBank(bankName, bankCourse) }
                                        .onSuccess { bankName = ""; bankCourse = ""; selectedBankId = it.id; screenMode = 1 }
                                        .onFailure { onMessage(it.message ?: "No se pudo crear") }
                                }
                            }, enabled = bankName.isNotBlank(), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                                Text("Crear banco", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Rounded.Download, null); Text(" Importar JSON")
                            }
                        }
                    }
                }
                if (savedSession != null) item {
                    Card(colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.12f)), shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Tienes un examen pendiente", modifier = Modifier.weight(1f), color = Gold, fontWeight = FontWeight.Bold)
                            OutlinedButton(onClick = {
                                val session = savedSession ?: return@OutlinedButton
                                selectedBankId = session.bankId
                                examIndex = session.currentIndex
                                examAnswers = session.answers
                                durationMinutes = session.durationMinutes.toString()
                                elapsedSeconds = ((System.currentTimeMillis() - session.startedAt) / 1000).toInt().coerceAtLeast(0)
                                screenMode = 2
                            }) { Text("Continuar") }
                        }
                    }
                }
                items(banks, key = { it.id }) { bank ->
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(bank.name, fontWeight = FontWeight.Bold)
                            Text("${bank.questions.size} preguntas${if (bank.course.isBlank()) "" else " · ${bank.course}"}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                OutlinedButton(onClick = { selectedBankId = bank.id; screenMode = 1 }, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.Edit, null); Text(" Editar") }
                                OutlinedButton(onClick = {
                                    if (bank.questions.isEmpty()) onMessage("Agrega preguntas primero") else {
                                        selectedBankId = bank.id; examIndex = 0; examAnswers = emptyMap(); revealResults = false; elapsedSeconds = 0; screenMode = 2
                                    }
                                }, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.PlayArrow, null); Text(" Usar") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                OutlinedButton(onClick = { pendingExport = bank; exportLauncher.launch("${bank.name.replace(Regex("[^A-Za-z0-9_-]"), "_")}.json") }, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.Save, null); Text(" JSON") }
                                OutlinedButton(onClick = { scope.launch { store.deleteBank(bank.id) } }, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.Delete, null); Text(" Eliminar") }
                            }
                        }
                    }
                }
            } else if (screenMode == 1 && selectedBank != null) {
                item {
                    OutlinedButton(onClick = { screenMode = 0 }, modifier = Modifier.fillMaxWidth()) { Text("Volver a bancos") }
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp), modifier = Modifier.padding(top = 10.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Datos del banco", style = MaterialTheme.typography.titleLarge)
                            OutlinedTextField(editBankName, { editBankName = it.take(100) }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(editBankCourse, { editBankCourse = it.take(100) }, label = { Text("Curso") }, modifier = Modifier.fillMaxWidth())
                            OutlinedButton(
                                onClick = { scope.launch { runCatching { store.updateBankInfo(selectedBank.id, editBankName, editBankCourse) }.onSuccess { onMessage("Banco actualizado") }.onFailure { onMessage(it.message ?: "No se pudo actualizar") } } },
                                enabled = editBankName.isNotBlank(),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Guardar nombre y curso") }
                            Text("Agregar pregunta", style = MaterialTheme.typography.titleLarge)
                            SimpleDropdown("Tipo", listOf("Alternativas", "Verdadero / falso"), questionType) { questionType = it; correctIndex = 0 }
                            OutlinedTextField(question, { question = it.take(1000) }, label = { Text("Pregunta") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                            if (questionType == 0) {
                                listOf(optionA to { v: String -> optionA = v }, optionB to { v: String -> optionB = v }, optionC to { v: String -> optionC = v }, optionD to { v: String -> optionD = v }).forEachIndexed { index, pair ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(correctIndex == index, { correctIndex = index })
                                        OutlinedTextField(pair.first, { pair.second(it.take(400)) }, label = { Text("Opción ${('A'.code + index).toChar()}") }, modifier = Modifier.weight(1f))
                                    }
                                }
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(correctIndex == 0, { correctIndex = 0 }); Text("Verdadero") }
                                Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(correctIndex == 1, { correctIndex = 1 }); Text("Falso") }
                            }
                            OutlinedTextField(explanation, { explanation = it.take(1000) }, label = { Text("Explicación (opcional)") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = {
                                val options = if (questionType == 0) listOf(optionA, optionB, optionC, optionD) else listOf("Verdadero", "Falso")
                                val item = ExamQuestion(text = question.trim(), type = if (questionType == 0) ExamQuestionType.MULTIPLE_CHOICE else ExamQuestionType.TRUE_FALSE, options = options.map(String::trim), correctIndex = correctIndex, explanation = explanation.trim())
                                scope.launch {
                                    runCatching { store.addQuestion(selectedBank.id, item) }
                                        .onSuccess { question = ""; optionA = ""; optionB = ""; optionC = ""; optionD = ""; explanation = ""; correctIndex = 0 }
                                        .onFailure { onMessage(it.message ?: "No se pudo guardar") }
                                }
                            }, enabled = question.isNotBlank(), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Agregar pregunta", fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                items(selectedBank.questions, key = { it.id }) { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text(item.text, fontWeight = FontWeight.Bold)
                                Text("Correcta: ${item.options[item.correctIndex]}", color = NeonGreen)
                            }
                            IconButton(onClick = { scope.launch { store.deleteQuestion(selectedBank.id, item.id) } }) { Icon(Icons.Rounded.Delete, "Eliminar") }
                        }
                    }
                }
            } else if (screenMode == 2 && selectedBank != null && selectedBank.questions.isNotEmpty()) {
                val questionItem = selectedBank.questions[examIndex.coerceIn(0, selectedBank.questions.lastIndex)]
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Pregunta ${examIndex + 1} de ${selectedBank.questions.size}", fontWeight = FontWeight.Bold)
                            Text("Tiempo: ${elapsedSeconds / 60}:${(elapsedSeconds % 60).toString().padStart(2, '0')}")
                            if (!revealResults && examIndex == 0 && examAnswers.isEmpty()) {
                                OutlinedTextField(durationMinutes, { durationMinutes = it.filter(Char::isDigit).take(3) }, label = { Text("Límite en minutos (0 = sin límite)") }, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
                if (!revealResults) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(questionItem.text, style = MaterialTheme.typography.titleLarge)
                                questionItem.options.forEachIndexed { index, option ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(examAnswers[questionItem.id] == index, {
                                            examAnswers = examAnswers + (questionItem.id to index)
                                            scope.launch { store.saveSession(ExamSession(selectedBank.id, examIndex, examAnswers, System.currentTimeMillis() - elapsedSeconds * 1000L, durationMinutes.toIntOrNull() ?: 0)) }
                                        })
                                        Text(option)
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { if (examIndex > 0) examIndex-- }, enabled = examIndex > 0, modifier = Modifier.weight(1f)) { Text("Anterior") }
                                    Button(onClick = {
                                        if (examIndex < selectedBank.questions.lastIndex) examIndex++ else revealResults = true
                                        scope.launch { store.saveSession(ExamSession(selectedBank.id, examIndex, examAnswers, System.currentTimeMillis() - elapsedSeconds * 1000L, durationMinutes.toIntOrNull() ?: 0)) }
                                    }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text(if (examIndex == selectedBank.questions.lastIndex) "Finalizar" else "Siguiente") }
                                }
                            }
                        }
                    }
                } else {
                    val score = selectedBank.questions.count { examAnswers[it.id] == it.correctIndex }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.10f)), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Resultado: $score/${selectedBank.questions.size}", style = MaterialTheme.typography.headlineMedium, color = NeonGreen)
                                Text("${if (selectedBank.questions.isEmpty()) 0 else score * 100 / selectedBank.questions.size}% de aciertos")
                                Button(onClick = { scope.launch { store.saveSession(null) }; screenMode = 0; revealResults = false }, modifier = Modifier.fillMaxWidth()) { Text("Terminar") }
                            }
                        }
                    }
                    items(selectedBank.questions, key = { it.id }) { item ->
                        val selected = examAnswers[item.id]
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(item.text, fontWeight = FontWeight.Bold)
                                Text("Tu respuesta: ${selected?.let { item.options.getOrNull(it) } ?: "Sin responder"}")
                                Text("Correcta: ${item.options[item.correctIndex]}", color = NeonGreen)
                                if (item.explanation.isNotBlank()) Text(item.explanation, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}
