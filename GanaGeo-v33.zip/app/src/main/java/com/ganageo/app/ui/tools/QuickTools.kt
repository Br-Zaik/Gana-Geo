package com.ganageo.app.ui.tools

import android.content.Context
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.ui.platform.LocalView
import com.ganageo.app.ui.theme.Gold
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen
import com.google.zxing.BarcodeFormat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun QrToolScreen(onBack: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var content by rememberSaveable { mutableStateOf("") }
    var result by rememberSaveable { mutableStateOf("") }
    var codeTypeIndex by rememberSaveable { mutableStateOf(0) }
    val codeTypes = listOf("QR", "Code 128", "EAN-13", "EAN-8", "UPC-A")
    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }

    DisposableEffect(qrBitmap) {
        val current = qrBitmap
        onDispose {
            if (current != null && !current.isRecycled) current.recycle()
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("image/png")
    ) { uri ->
        if (uri != null && qrBitmap != null) {
            scope.launch {
                runCatching { ToolFileUtils.writeBitmap(context, qrBitmap!!, uri, Bitmap.CompressFormat.PNG, 100) }
                    .onSuccess { onMessage("QR guardado correctamente.") }
                    .onFailure { onMessage(it.message ?: "No se pudo guardar el QR.") }
            }
        }
    }
    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val bitmap = ToolFileUtils.loadBitmap(context, uri)
                    try {
                        ToolFileUtils.decodeQr(bitmap)
                    } finally {
                        if (!bitmap.isRecycled) bitmap.recycle()
                    }
                }.onSuccess { result = it }
                    .onFailure { onMessage("No se encontró un código legible en la imagen.") }
            }
        }
    }
    val scanLauncher = rememberLauncherForActivityResult(ScanContract()) { scanResult ->
        if (!scanResult.contents.isNullOrBlank()) result = scanResult.contents
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("QR y códigos de barras", "Crea y lee códigos localmente, sin enviar el contenido", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Crear código", style = MaterialTheme.typography.titleLarge)
                        SimpleDropdown("Tipo", codeTypes, codeTypeIndex) { codeTypeIndex = it; qrBitmap = null }
                        OutlinedTextField(
                            value = content,
                            onValueChange = { content = it.take(1000) },
                            label = { Text(if (codeTypeIndex == 0) "Texto, enlace, Wi-Fi o contacto" else "Número o texto compatible") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )
                        Button(
                            onClick = {
                                runCatching {
                                    when (codeTypeIndex) {
                                        0 -> ToolFileUtils.generateQr(content)
                                        1 -> ToolFileUtils.generateBarcode(content, BarcodeFormat.CODE_128)
                                        2 -> ToolFileUtils.generateBarcode(content, BarcodeFormat.EAN_13)
                                        3 -> ToolFileUtils.generateBarcode(content, BarcodeFormat.EAN_8)
                                        else -> ToolFileUtils.generateBarcode(content, BarcodeFormat.UPC_A)
                                    }
                                }.onSuccess { qrBitmap = it }
                                    .onFailure { onMessage(it.message ?: "No se pudo crear el código.") }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Generar código") }
                        qrBitmap?.let { bitmap ->
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Código generado",
                                modifier = Modifier.fillMaxWidth().height(280.dp)
                            )
                            OutlinedButton(
                                onClick = { saveLauncher.launch(if (codeTypeIndex == 0) "qr_gana_geo.png" else "codigo_gana_geo.png") },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Rounded.Save, contentDescription = null)
                                Text(" Guardar PNG")
                            }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Leer QR o código de barras", style = MaterialTheme.typography.titleLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                onClick = {
                                    scanLauncher.launch(
                                        ScanOptions()
                                            .setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES)
                                            .setPrompt("Apunta la cámara al QR o código de barras")
                                            .setBeepEnabled(false)
                                            .setOrientationLocked(false)
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.QrCodeScanner, contentDescription = null)
                                Text(" Cámara")
                            }
                            FilledTonalButton(
                                onClick = { imageLauncher.launch(arrayOf("image/*")) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.Photo, contentDescription = null)
                                Text(" Imagen")
                            }
                        }
                        if (result.isNotBlank()) {
                            OutlinedTextField(
                                value = result,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Contenido leído") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 3
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WordCounterScreen(onBack: () -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    val words = text.trim().takeIf { it.isNotEmpty() }
        ?.split(Regex("\\s+"))
        ?.count() ?: 0
    val characters = text.length
    val charactersNoSpaces = text.count { !it.isWhitespace() }
    val lines = if (text.isEmpty()) 0 else text.lines().size
    val readingSeconds = if (words == 0) 0 else (words / 200.0 * 60).toInt().coerceAtLeast(1)

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Contador de palabras", "Revisa la extensión de tareas y trabajos", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.take(100_000) },
                    label = { Text("Pega o escribe tu texto") },
                    modifier = Modifier.fillMaxWidth().height(260.dp)
                )
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatRow("Palabras", words.toString())
                        StatRow("Caracteres", characters.toString())
                        StatRow("Sin espacios", charactersNoSpaces.toString())
                        StatRow("Líneas", lines.toString())
                        StatRow("Lectura estimada", formatDuration(readingSeconds.toLong()))
                    }
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold, color = NeonGreen)
    }
}

@Composable
fun StopwatchTimerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    var mode by rememberSaveable { mutableStateOf("Cronómetro") }

    // ---- Cronómetro ----
    // Se guarda la marca de tiempo de arranque en vez de ir sumando +1 cada
    // segundo. Asi no se acumula desfase ni se congela si se apaga la pantalla:
    // al volver, el tiempo se recalcula contra el reloj del sistema.
    var swRunning by rememberSaveable { mutableStateOf(false) }
    var swStartedAt by rememberSaveable { mutableLongStateOf(0L) }
    var swAccumulated by rememberSaveable { mutableLongStateOf(0L) }
    var swNow by remember { mutableLongStateOf(0L) }
    var laps by rememberSaveable { mutableStateOf(listOf<Long>()) }

    val swElapsed = if (swRunning) swAccumulated + (swNow - swStartedAt) else swAccumulated

    // ---- Temporizador ----
    var tmRunning by rememberSaveable { mutableStateOf(false) }
    var tmEndsAt by rememberSaveable { mutableLongStateOf(0L) }
    var tmRemainingPaused by rememberSaveable { mutableLongStateOf(25 * 60_000L) }
    var tmConfigured by rememberSaveable { mutableLongStateOf(25 * 60_000L) }
    var tmNow by remember { mutableLongStateOf(0L) }
    var tmFinished by remember { mutableStateOf(false) }
    var hoursInput by rememberSaveable { mutableStateOf("0") }
    var minutesInput by rememberSaveable { mutableStateOf("25") }
    var secondsInput by rememberSaveable { mutableStateOf("0") }

    val tmRemaining = if (tmRunning) (tmEndsAt - tmNow).coerceAtLeast(0L) else tmRemainingPaused

    fun readConfigured(): Long {
        val h = hoursInput.toLongOrNull() ?: 0L
        val m = minutesInput.toLongOrNull() ?: 0L
        val s = secondsInput.toLongOrNull() ?: 0L
        return ((h * 3600) + (m * 60) + s) * 1000L
    }

    // Refresco de pantalla. 60 ms basta para ver centesimas fluidas sin gastar
    // bateria; el valor mostrado siempre sale del reloj, no de este contador.
    LaunchedEffect(swRunning, tmRunning) {
        while (swRunning || tmRunning) {
            val now = System.currentTimeMillis()
            swNow = now
            tmNow = now
            if (tmRunning && now >= tmEndsAt) {
                tmRunning = false
                tmRemainingPaused = 0L
                tmFinished = true
            }
            delay(60)
        }
    }

    // Aviso al terminar: sonido de alarma del sistema + vibracion. Antes el
    // temporizador simplemente llegaba a cero en silencio.
    LaunchedEffect(tmFinished) {
        if (!tmFinished) return@LaunchedEffect
        runCatching {
            val tone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            RingtoneManager.getRingtone(context, tone)?.play()
        }
        runCatching {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            vibrator.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400, 200, 600), -1)
            )
        }
    }

    // Mantener la pantalla encendida mientras corre, como cualquier cronometro.
    DisposableEffect(swRunning, tmRunning) {
        val keepOn = swRunning || tmRunning
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Cronómetro y temporizador", "Controla estudio, descansos y ejercicios", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Cronómetro", "Temporizador").forEach { option ->
                        FilledTonalButton(
                            onClick = { mode = option },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (mode == option) NeonGreen else CardGreen,
                                contentColor = if (mode == option) DeepGreen else MaterialTheme.colorScheme.onSurface
                            )
                        ) { Text(option) }
                    }
                }
            }

            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(22.dp)) {
                    Column(
                        Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        if (mode == "Cronómetro") {
                            Text(
                                formatStopwatch(swElapsed),
                                style = MaterialTheme.typography.displaySmall,
                                color = NeonGreen,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        if (swRunning) {
                                            swAccumulated += System.currentTimeMillis() - swStartedAt
                                            swRunning = false
                                        } else {
                                            swStartedAt = System.currentTimeMillis()
                                            swNow = swStartedAt
                                            swRunning = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                                ) {
                                    Icon(if (swRunning) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, contentDescription = null)
                                    Text(if (swRunning) " Pausar" else " Iniciar")
                                }
                                OutlinedButton(
                                    onClick = { laps = laps + swElapsed },
                                    enabled = swRunning
                                ) {
                                    Icon(Icons.Rounded.Flag, contentDescription = null)
                                    Text(" Vuelta")
                                }
                                OutlinedButton(onClick = {
                                    swRunning = false
                                    swAccumulated = 0L
                                    swStartedAt = 0L
                                    laps = emptyList()
                                }) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null)
                                    Text(" Reiniciar")
                                }
                            }
                        } else {
                            if (!tmRunning) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = hoursInput,
                                        onValueChange = {
                                            hoursInput = it.filter(Char::isDigit).take(2)
                                            tmRemainingPaused = readConfigured()
                                            tmConfigured = tmRemainingPaused
                                        },
                                        label = { Text("Horas") },
                                        modifier = Modifier.weight(1f),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = minutesInput,
                                        onValueChange = {
                                            minutesInput = it.filter(Char::isDigit).take(2)
                                            tmRemainingPaused = readConfigured()
                                            tmConfigured = tmRemainingPaused
                                        },
                                        label = { Text("Min") },
                                        modifier = Modifier.weight(1f),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = secondsInput,
                                        onValueChange = {
                                            secondsInput = it.filter(Char::isDigit).take(2)
                                            tmRemainingPaused = readConfigured()
                                            tmConfigured = tmRemainingPaused
                                        },
                                        label = { Text("Seg") },
                                        modifier = Modifier.weight(1f),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(1, 5, 10, 25).forEach { preset ->
                                        OutlinedButton(onClick = {
                                            hoursInput = "0"
                                            minutesInput = preset.toString()
                                            secondsInput = "0"
                                            tmRemainingPaused = preset * 60_000L
                                            tmConfigured = tmRemainingPaused
                                            tmFinished = false
                                        }) { Text("$preset m") }
                                    }
                                }
                            }

                            Text(
                                formatTimer(tmRemaining),
                                style = MaterialTheme.typography.displaySmall,
                                color = if (tmFinished) Gold else NeonGreen,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )

                            if (tmConfigured > 0L) {
                                LinearProgressIndicator(
                                    progress = { (1f - tmRemaining.toFloat() / tmConfigured.toFloat()).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            if (tmFinished) {
                                Text("¡Tiempo cumplido!", color = Gold, fontWeight = FontWeight.Bold)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        if (tmRunning) {
                                            tmRemainingPaused = (tmEndsAt - System.currentTimeMillis()).coerceAtLeast(0L)
                                            tmRunning = false
                                        } else {
                                            val base = if (tmRemainingPaused > 0L) tmRemainingPaused else readConfigured()
                                            if (base <= 0L) return@Button
                                            if (tmConfigured <= 0L) tmConfigured = base
                                            tmEndsAt = System.currentTimeMillis() + base
                                            tmNow = System.currentTimeMillis()
                                            tmFinished = false
                                            tmRunning = true
                                        }
                                    },
                                    enabled = tmRunning || tmRemainingPaused > 0L || readConfigured() > 0L,
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                                ) {
                                    Icon(if (tmRunning) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, contentDescription = null)
                                    Text(if (tmRunning) " Pausar" else " Iniciar")
                                }
                                OutlinedButton(onClick = {
                                    tmRunning = false
                                    tmFinished = false
                                    val base = readConfigured()
                                    tmRemainingPaused = base
                                    tmConfigured = base
                                }) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null)
                                    Text(" Reiniciar")
                                }
                            }
                        }
                    }
                }
            }

            if (mode == "Cronómetro" && laps.isNotEmpty()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Vueltas", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            laps.asReversed().forEachIndexed { indexFromEnd, total ->
                                val number = laps.size - indexFromEnd
                                val previous = if (number >= 2) laps[number - 2] else 0L
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Vuelta $number", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(formatStopwatch(total - previous), fontWeight = FontWeight.Bold, color = NeonGreen)
                                    Text(formatStopwatch(total), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatStopwatch(millis: Long): String {
    val totalSeconds = millis / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    val centis = (millis % 1000) / 10
    return if (hours > 0) {
        String.format(Locale.US, "%02d:%02d:%02d.%02d", hours, minutes, seconds, centis)
    } else {
        String.format(Locale.US, "%02d:%02d.%02d", minutes, seconds, centis)
    }
}

private fun formatTimer(millis: Long): String {
    val totalSeconds = (millis + 999) / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }
}

private fun formatDuration(seconds: Long): String {
    val hours = seconds / 3600
    val minutes = (seconds % 3600) / 60
    val secs = seconds % 60
    return if (hours > 0) String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, secs)
    else String.format(Locale.US, "%02d:%02d", minutes, secs)
}
