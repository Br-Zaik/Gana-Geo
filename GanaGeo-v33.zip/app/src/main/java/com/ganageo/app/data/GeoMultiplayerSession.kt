package com.ganageo.app.data

import android.content.Context
import com.ganageo.app.model.GeoLocalRoomBeacon
import com.ganageo.app.model.GeoMultiplayerInvite
import com.ganageo.app.model.GeoMultiplayerLobbyState
import com.ganageo.app.model.GeoMultiplayerMode
import com.ganageo.app.model.GeoPlayerLookup
import com.ganageo.app.model.GeoSkin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class GeoMultiplayerSession(
    private val context: Context,
    private val baseUnlockedLevels: Set<Int>,
    initialSkin: GeoSkin,
    private val guestMode: Boolean = false
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val online = GeoOnlineMultiplayerService()
    private var local: GeoLocalMultiplayerService? = null
    private var localCollectJob: Job? = null
    private var beaconCollectJob: Job? = null
    private var onlinePollJob: Job? = null
    private var resetJob: Job? = null
    private val progressScope: String
        get() = if (guestMode) "guest" else runCatching { online.currentUserId() }.getOrDefault("guest")
    private val allowPremiumSkins: Boolean
        get() = !guestMode && runCatching { online.isSignedIn() }.getOrDefault(false)
    private var selectedSkin = if (guestMode && initialSkin.premium) GeoSkin.GREEN else initialSkin
    private var lastOnlinePushAt = 0L
    private var lastOnlineSeq = 0L
    private var lastFinishedMatchNo = -1L
    private var lastLocalCloudSyncMatchNo = -1L
    private val progressStore = GeoMultiplayerLocalProgressStore(context.applicationContext)

    private val _state = MutableStateFlow<GeoMultiplayerLobbyState?>(null)
    val state: StateFlow<GeoMultiplayerLobbyState?> = _state.asStateFlow()
    private val _invites = MutableStateFlow<List<GeoMultiplayerInvite>>(emptyList())
    val invites: StateFlow<List<GeoMultiplayerInvite>> = _invites.asStateFlow()
    private val _beacons = MutableStateFlow<List<GeoLocalRoomBeacon>>(emptyList())
    val beacons: StateFlow<List<GeoLocalRoomBeacon>> = _beacons.asStateFlow()
    private val _onlineProfile = MutableStateFlow<GeoPlayerLookup?>(null)
    val onlineProfile: StateFlow<GeoPlayerLookup?> = _onlineProfile.asStateFlow()
    private val _friends = MutableStateFlow<List<GeoPlayerLookup>>(emptyList())
    val friends: StateFlow<List<GeoPlayerLookup>> = _friends.asStateFlow()

    fun isOnlineAvailable(): Boolean = runCatching { online.isSignedIn() }.getOrDefault(false)

    suspend fun prepareOnline(): Result<GeoPlayerLookup> = runCatching {
        check(online.isSignedIn()) { "Debes iniciar sesión para jugar Online." }
        val profile = online.registerProfile(selectedSkin)
        selectedSkin = GeoSkin.fromCode(profile.skinCode)
        _onlineProfile.value = profile
        // Una partida local no necesita Internet. Si la cuenta completo niveles sin conexion,
        // se conservan por cuenta en el dispositivo y se sincronizan al volver a Online.
        progressStore.sparseLevels(currentAccountScope()).forEach { level ->
            runCatching { online.claimLocalUnlock(level) }
        }
        val (_, premium) = online.refreshAccountState()
        progressStore.setPremiumSkins(premium, currentAccountScope())
        _invites.value = online.listInvites()
        _friends.value = online.listFriends()
        profile
    }

    suspend fun refreshInvites() {
        if (online.isSignedIn()) _invites.value = runCatching { online.listInvites() }.getOrDefault(_invites.value)
    }

    suspend fun refreshFriends() {
        if (online.isSignedIn()) _friends.value = runCatching { online.listFriends() }.getOrDefault(_friends.value)
    }

    suspend fun searchPlayer(publicId: String): Result<GeoPlayerLookup?> = runCatching { online.findPlayer(publicId) }
    suspend fun addFriend(publicId: String): Result<GeoPlayerLookup> = runCatching { online.addFriend(publicId).also { refreshFriends() } }
    suspend fun consumePendingOnlineRoom(): String? = progressStore.consumePendingRoom()

    suspend fun createOnlineRoom(level: Int): Result<GeoMultiplayerLobbyState> = runCatching {
        val fresh = online.createRoom(level, selectedSkin)
        _state.value = fresh
        startOnlinePolling(fresh.room.roomId)
        fresh
    }

    suspend fun acceptOnlineInvite(inviteId: String): Result<GeoMultiplayerLobbyState> = runCatching {
        val fresh = online.acceptInvite(inviteId, selectedSkin)
        _state.value = fresh
        startOnlinePolling(fresh.room.roomId)
        refreshInvites()
        fresh
    }

    suspend fun joinOnlineRoom(roomId: String): Result<GeoMultiplayerLobbyState> = runCatching {
        val fresh = online.joinRoom(roomId, selectedSkin)
        _state.value = fresh
        startOnlinePolling(fresh.room.roomId)
        fresh
    }

    suspend fun inviteOnline(publicId: String): Result<Unit> = runCatching {
        val room = _state.value?.room ?: error("Primero crea una sala.")
        online.invite(room.roomId, publicId)
        Unit
    }

    suspend fun createLocalRoom(name: String): Result<GeoMultiplayerLobbyState> = runCatching {
        stopLocal()
        val service = GeoLocalMultiplayerService(
            context = context,
            baseUnlockedLevels = baseUnlockedLevels,
            selectedSkin = selectedSkin,
            progressScope = progressScope,
            allowPremiumSkins = allowPremiumSkins
        )
        local = service
        collectLocal(service)
        service.createRoom(name)
    }

    fun startLocalDiscovery() {
        if (local == null) {
            val service = GeoLocalMultiplayerService(
                context = context,
                baseUnlockedLevels = baseUnlockedLevels,
                selectedSkin = selectedSkin,
                progressScope = progressScope,
                allowPremiumSkins = allowPremiumSkins
            )
            local = service
            collectLocal(service)
        }
        local?.startDiscovery()
    }

    suspend fun joinLocalRoom(beacon: GeoLocalRoomBeacon, name: String): Result<GeoMultiplayerLobbyState> = runCatching {
        if (local == null) {
            val service = GeoLocalMultiplayerService(
                context = context,
                baseUnlockedLevels = baseUnlockedLevels,
                selectedSkin = selectedSkin,
                progressScope = progressScope,
                allowPremiumSkins = allowPremiumSkins
            )
            local = service
            collectLocal(service)
        }
        local!!.join(beacon, name)
    }

    suspend fun joinLocalAddress(address: String, name: String): Result<GeoMultiplayerLobbyState> = runCatching {
        if (local == null) {
            val service = GeoLocalMultiplayerService(
                context = context,
                baseUnlockedLevels = baseUnlockedLevels,
                selectedSkin = selectedSkin,
                progressScope = progressScope,
                allowPremiumSkins = allowPremiumSkins
            )
            local = service
            collectLocal(service)
        }
        local!!.joinAddress(address, name)
    }

    fun localIpHints(): List<String> = GeoLocalMultiplayerService.localIpv4Addresses()

    fun setSkin(skin: GeoSkin) {
        if (skin.premium && !allowPremiumSkins) return
        selectedSkin = skin
        scope.launch { progressStore.setSelectedSkin(skin) }
        when (_state.value?.mode) {
            GeoMultiplayerMode.ONLINE -> scope.launch {
                val current = _state.value ?: return@launch
                runCatching { online.setReady(current.room.roomId, current.me?.isReady ?: false, skin) }
            }
            GeoMultiplayerMode.LOCAL -> local?.setSkin(skin)
            else -> Unit
        }
    }

    fun setReady(ready: Boolean) {
        val current = _state.value ?: return
        when (current.mode) {
            GeoMultiplayerMode.ONLINE -> scope.launch { runCatching { online.setReady(current.room.roomId, ready, selectedSkin) } }
            GeoMultiplayerMode.LOCAL -> local?.setReady(ready)
            else -> Unit
        }
    }

    fun setLevel(level: Int) {
        val current = _state.value ?: return
        when (current.mode) {
            GeoMultiplayerMode.ONLINE -> scope.launch { runCatching { online.setLevel(current.room.roomId, level) } }
            GeoMultiplayerMode.LOCAL -> local?.setLevel(level)
            else -> Unit
        }
    }

    suspend fun startMatch(): Result<Unit> {
        val current = _state.value ?: return Result.failure(IllegalStateException("No hay sala."))
        return when (current.mode) {
            GeoMultiplayerMode.ONLINE -> runCatching { online.startMatch(current.room.roomId) }
            GeoMultiplayerMode.LOCAL -> local?.startMatch() ?: Result.failure(IllegalStateException("No hay sala local."))
            else -> Result.failure(IllegalStateException("Modo inválido."))
        }
    }

    fun markLocalMatchReady() {
        val current = _state.value ?: return
        if (current.mode == GeoMultiplayerMode.LOCAL) local?.markMatchReady()
    }

    fun updateMyPlayer(x: Float, y: Float, vx: Float, vy: Float, lives: Int, checkpoint: Int, worldState: String = "") {
        val current = _state.value ?: return
        val me = current.me ?: return
        val next = me.copy(
            x = x, y = y, velocityX = vx, velocityY = vy,
            lives = lives.coerceIn(0, 15), checkpoint = checkpoint,
            worldState = worldState.take(4096),
            isEliminated = lives <= 0, isSpectator = lives <= 0,
            seq = me.seq + 1, updatedAtMs = System.currentTimeMillis()
        )
        when (current.mode) {
            GeoMultiplayerMode.LOCAL -> local?.updatePlayer(next)
            GeoMultiplayerMode.ONLINE -> {
                val now = System.currentTimeMillis()
                if (now - lastOnlinePushAt < 110L && lives > 0) return
                lastOnlinePushAt = now
                lastOnlineSeq = maxOf(lastOnlineSeq + 1, next.seq)
                scope.launch { runCatching { online.updatePlayer(current.room.roomId, next.copy(seq = lastOnlineSeq)) } }
            }
            else -> Unit
        }
    }

    fun reportWin() {
        val current = _state.value ?: return
        val me = current.me ?: return
        when (current.mode) {
            GeoMultiplayerMode.LOCAL -> local?.reportWin(me.playerId)
            GeoMultiplayerMode.ONLINE -> scope.launch { runCatching { online.finishMatch(current.room.roomId, true, me.playerId) } }
            else -> Unit
        }
    }

    fun leaveRoom() {
        val current = _state.value
        onlinePollJob?.cancel(); resetJob?.cancel()
        if (current?.mode == GeoMultiplayerMode.ONLINE) scope.launch { runCatching { online.leaveRoom(current.room.roomId) } }
        if (current?.mode == GeoMultiplayerMode.LOCAL) local?.leave()
        _state.value = null
    }

    fun close() {
        leaveRoom(); stopLocal(); scope.coroutineContext[Job]?.cancel()
    }

    private fun collectLocal(service: GeoLocalMultiplayerService) {
        localCollectJob?.cancel()
        beaconCollectJob?.cancel()
        localCollectJob = scope.launch {
            service.state.collect { fresh ->
                _state.value = fresh
                if (
                    fresh?.room?.status == "finished" &&
                    fresh.room.result == "won" &&
                    allowPremiumSkins &&
                    fresh.room.matchNo != lastLocalCloudSyncMatchNo
                ) {
                    lastLocalCloudSyncMatchNo = fresh.room.matchNo
                    val completed = fresh.room.selectedLevel.coerceIn(1, 20)
                    val next = (completed + 1).coerceAtMost(20)
                    scope.launch {
                        runCatching { online.claimLocalUnlock(completed) }
                        runCatching { online.claimLocalUnlock(next) }
                    }
                }
                if (fresh?.room?.status == "finished" && fresh.isHost && fresh.room.matchNo != lastFinishedMatchNo) {
                    lastFinishedMatchNo = fresh.room.matchNo
                    resetJob?.cancel()
                    resetJob = scope.launch { delay(1_800L); service.resetLobby() }
                }
            }
        }
        beaconCollectJob = scope.launch { service.beacons.collect { _beacons.value = it } }
    }

    private fun stopLocal() {
        localCollectJob?.cancel(); beaconCollectJob?.cancel(); local?.close(); local = null
    }

    private fun currentAccountScope(): String = runCatching { online.currentUserId() }.getOrDefault(progressScope)

    private fun startOnlinePolling(roomId: String) {
        onlinePollJob?.cancel()
        onlinePollJob = scope.launch {
            var consecutiveFailures = 0
            while (isActive) {
                val result = runCatching { online.roomState(roomId) }
                result.onSuccess { fresh ->
                    consecutiveFailures = 0
                    _state.value = fresh
                    if (fresh.room.status == "playing" && fresh.isHost && fresh.players.isNotEmpty() && fresh.players.all { it.lives <= 0 || it.isEliminated }) {
                        runCatching { online.finishMatch(roomId, false, null) }
                    }
                    if (fresh.room.status == "finished" && fresh.isHost && fresh.room.matchNo != lastFinishedMatchNo) {
                        lastFinishedMatchNo = fresh.room.matchNo
                        resetJob?.cancel()
                        resetJob = scope.launch { delay(1_800L); runCatching { online.resetLobby(roomId) } }
                    }
                }.onFailure { error ->
                    consecutiveFailures++
                    if (consecutiveFailures >= 3) _state.value = _state.value?.copy(connected = false, message = error.message ?: "Se perdió la conexión con la sala.")
                }
                delay(if (_state.value?.room?.status == "playing") 120L else 650L)
            }
        }
    }
}
