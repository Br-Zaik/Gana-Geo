package com.ganageo.app.tools

data class WorkPayResult(
    val regularHours: Double,
    val overtimeHours: Double,
    val regularPay: Double,
    val overtimePay: Double,
    val totalPay: Double,
    val overtimeFirstHours: Double = 0.0,
    val overtimeExtraHours: Double = 0.0,
    val overtimeFirstPay: Double = 0.0,
    val overtimeExtraPay: Double = 0.0
)

object WorkPayCalculator {
    /** Recargo de las 2 primeras horas extra de cada dia (D.S. 007-2002-TR). */
    const val PERU_FIRST_SURCHARGE = 0.25

    /** Recargo desde la 3ra hora extra de cada dia. */
    const val PERU_EXTRA_SURCHARGE = 0.35

    /** Horas extra por dia que se pagan al recargo menor antes de subir al mayor. */
    const val PERU_FIRST_BLOCK_HOURS = 2.0

    /** Trabajo en feriado o dia de descanso sin descanso sustitutorio (D.L. 713). */
    const val PERU_HOLIDAY_MULTIPLIER = 2.0

    /**
     * Valor de la hora ordinaria a partir del sueldo mensual.
     * Regla peruana: (sueldo / 30) da el valor dia, y ese valor entre las horas
     * de la jornada da el valor hora.
     */
    fun hourlyRateFromMonthly(monthlySalary: Double, hoursPerDay: Double = 8.0): Double {
        require(monthlySalary.isFinite() && monthlySalary >= 0) { "Sueldo inválido" }
        require(hoursPerDay.isFinite() && hoursPerDay > 0) { "Horas de jornada inválidas" }
        return (monthlySalary / 30.0) / hoursPerDay
    }

    /**
     * Calculo con los recargos escalonados de la ley peruana. El conteo de las
     * 2 primeras horas se reinicia cada dia, por eso se calcula por jornada y
     * luego se multiplica por los dias trabajados.
     */
    fun calculatePeru(
        hourlyRate: Double,
        regularHoursPerDay: Double,
        overtimeHoursPerDay: Double,
        days: Double,
        holiday: Boolean = false
    ): WorkPayResult {
        require(hourlyRate.isFinite() && hourlyRate >= 0) { "Pago por hora inválido" }
        require(regularHoursPerDay.isFinite() && regularHoursPerDay >= 0) { "Horas regulares inválidas" }
        require(overtimeHoursPerDay.isFinite() && overtimeHoursPerDay >= 0) { "Horas extra inválidas" }
        require(days.isFinite() && days > 0) { "Cantidad de días inválida" }

        // En feriado o dia de descanso la hora base ya vale el doble; sobre esa
        // base recien se aplican los recargos por sobretiempo.
        val baseRate = if (holiday) hourlyRate * PERU_HOLIDAY_MULTIPLIER else hourlyRate

        val firstPerDay = minOf(overtimeHoursPerDay, PERU_FIRST_BLOCK_HOURS)
        val extraPerDay = (overtimeHoursPerDay - PERU_FIRST_BLOCK_HOURS).coerceAtLeast(0.0)

        val regularHours = regularHoursPerDay * days
        val overtimeFirstHours = firstPerDay * days
        val overtimeExtraHours = extraPerDay * days
        val overtimeHours = overtimeFirstHours + overtimeExtraHours

        val regularPay = baseRate * regularHours
        val overtimeFirstPay = baseRate * (1.0 + PERU_FIRST_SURCHARGE) * overtimeFirstHours
        val overtimeExtraPay = baseRate * (1.0 + PERU_EXTRA_SURCHARGE) * overtimeExtraHours
        val overtimePay = overtimeFirstPay + overtimeExtraPay
        val totalPay = regularPay + overtimePay

        require(listOf(regularPay, overtimePay, totalPay).all(Double::isFinite)) {
            "El resultado está fuera del límite permitido"
        }

        return WorkPayResult(
            regularHours = regularHours,
            overtimeHours = overtimeHours,
            regularPay = regularPay,
            overtimePay = overtimePay,
            totalPay = totalPay,
            overtimeFirstHours = overtimeFirstHours,
            overtimeExtraHours = overtimeExtraHours,
            overtimeFirstPay = overtimeFirstPay,
            overtimeExtraPay = overtimeExtraPay
        )
    }

    fun calculate(
        hourlyRate: Double,
        regularHoursPerDay: Double,
        overtimeHoursPerDay: Double,
        overtimeMultiplier: Double,
        days: Double
    ): WorkPayResult {
        require(hourlyRate.isFinite() && hourlyRate >= 0) { "Pago por hora inválido" }
        require(regularHoursPerDay.isFinite() && regularHoursPerDay >= 0) { "Horas regulares inválidas" }
        require(overtimeHoursPerDay.isFinite() && overtimeHoursPerDay >= 0) { "Horas extra inválidas" }
        require(overtimeMultiplier.isFinite() && overtimeMultiplier > 0) { "Multiplicador inválido" }
        require(days.isFinite() && days > 0) { "Cantidad de días inválida" }

        val regularHours = regularHoursPerDay * days
        val overtimeHours = overtimeHoursPerDay * days
        val regularPay = hourlyRate * regularHours
        val overtimePay = hourlyRate * overtimeHours * overtimeMultiplier
        val totalPay = regularPay + overtimePay

        require(listOf(regularPay, overtimePay, totalPay).all(Double::isFinite)) {
            "El resultado está fuera del límite permitido"
        }

        return WorkPayResult(
            regularHours = regularHours,
            overtimeHours = overtimeHours,
            regularPay = regularPay,
            overtimePay = overtimePay,
            totalPay = totalPay
        )
    }
}

data class SaleProfitResult(
    val grossProfit: Double,
    val commission: Double,
    val netProfit: Double,
    val netMarginPercent: Double,
    val markupPercent: Double
)

object CommerceCalculator {
    fun analyzeSale(cost: Double, salePrice: Double, commissionPercent: Double): SaleProfitResult {
        require(cost.isFinite() && cost >= 0) { "Costo inválido" }
        require(salePrice.isFinite() && salePrice > 0) { "Precio de venta inválido" }
        require(commissionPercent.isFinite() && commissionPercent in 0.0..100.0) { "Comisión inválida" }

        val commission = salePrice * commissionPercent / 100.0
        val grossProfit = salePrice - cost
        val netProfit = grossProfit - commission
        val netMargin = netProfit / salePrice * 100.0
        val markup = if (cost > 0) grossProfit / cost * 100.0 else 0.0

        return SaleProfitResult(
            grossProfit = grossProfit,
            commission = commission,
            netProfit = netProfit,
            netMarginPercent = netMargin,
            markupPercent = markup
        )
    }

    fun targetSalePrice(cost: Double, desiredMarginPercent: Double, commissionPercent: Double): Double {
        require(cost.isFinite() && cost >= 0) { "Costo inválido" }
        require(desiredMarginPercent.isFinite() && desiredMarginPercent >= 0) { "Margen inválido" }
        require(commissionPercent.isFinite() && commissionPercent >= 0) { "Comisión inválida" }
        val margin = desiredMarginPercent / 100.0
        val commission = commissionPercent / 100.0
        require(margin + commission < 1.0) { "Margen y comisión juntos deben ser menores de 100%" }
        return cost / (1.0 - margin - commission)
    }

    fun quoteTotals(subtotal: Double, igvPercent: Double = 18.0): Triple<Double, Double, Double> {
        require(subtotal.isFinite() && subtotal >= 0) { "Subtotal inválido" }
        require(igvPercent.isFinite() && igvPercent >= 0) { "IGV inválido" }
        val tax = subtotal * igvPercent / 100.0
        return Triple(subtotal, tax, subtotal + tax)
    }

    /**
     * Camino inverso: a partir de un precio que YA incluye IGV, obtiene la base
     * imponible y el impuesto. El error tipico es multiplicar el total por 0.18;
     * lo correcto es dividir entre 1.18 y restar.
     */
    fun quoteFromTotal(total: Double, igvPercent: Double = 18.0): Triple<Double, Double, Double> {
        require(total.isFinite() && total >= 0) { "Total inválido" }
        require(igvPercent.isFinite() && igvPercent >= 0) { "IGV inválido" }
        val base = total / (1.0 + igvPercent / 100.0)
        return Triple(base, total - base, total)
    }
}
