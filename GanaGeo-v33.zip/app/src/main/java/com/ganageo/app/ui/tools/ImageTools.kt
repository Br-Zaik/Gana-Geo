package com.ganageo.app.ui.tools

import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.roundToInt
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ImageToolScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var inputUriText by rememberSaveable { mutableStateOf<String?>(null) }
    val input = inputUriText?.let { Uri.parse(it) }
    var sourcePreview by remember { mutableStateOf<Bitmap?>(null) }
    var resultPreview by remember { mutableStateOf<Bitmap?>(null) }
    var showOriginal by rememberSaveable { mutableStateOf(false) }
    var previewLoading by remember { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    var showFullPreview by rememberSaveable { mutableStateOf(false) }
    var editorPanel by rememberSaveable { mutableStateOf(0) }

    var qualityPreset by rememberSaveable { mutableStateOf(2) }
    var quality by rememberSaveable { mutableStateOf(82f) }
    var resizePreset by rememberSaveable { mutableStateOf(0) }
    var widthText by rememberSaveable { mutableStateOf("1080") }
    var heightText by rememberSaveable { mutableStateOf("1080") }
    var keepAspect by rememberSaveable { mutableStateOf(true) }
    var formatIndex by rememberSaveable { mutableStateOf(0) }
    var ratioIndex by rememberSaveable { mutableStateOf(0) }
    var rotationIndex by rememberSaveable { mutableStateOf(0) }
    var flipH by rememberSaveable { mutableStateOf(false) }
    var flipV by rememberSaveable { mutableStateOf(false) }
    var watermark by rememberSaveable { mutableStateOf("") }
    var opacity by rememberSaveable { mutableStateOf(55f) }
    var textSize by rememberSaveable { mutableStateOf(6f) }
    var positionIndex by rememberSaveable { mutableStateOf(8) }
    var repeatWatermark by rememberSaveable { mutableStateOf(false) }
    var darkText by rememberSaveable { mutableStateOf(false) }
    var brightness by rememberSaveable { mutableStateOf(0f) }
    var contrast by rememberSaveable { mutableStateOf(1f) }
    var saturation by rememberSaveable { mutableStateOf(1f) }
    var filterIndex by rememberSaveable { mutableStateOf(DocumentImageFilter.ORIGINAL.ordinal) }
    // Recorte libre: rectangulo normalizado 0..1 sobre la imagen original.
    var cropLeft by rememberSaveable { mutableStateOf(0f) }
    var cropTop by rememberSaveable { mutableStateOf(0f) }
    var cropRight by rememberSaveable { mutableStateOf(1f) }
    var cropBottom by rememberSaveable { mutableStateOf(1f) }
    // Angulo fino del dial (-45..45). Se suma a los giros de 90 grados.
    var fineRotation by rememberSaveable { mutableStateOf(0f) }
    // Redimension por porcentaje y por peso objetivo.
    var resizePercent by rememberSaveable { mutableStateOf(100f) }
    var targetSizeKbText by rememberSaveable { mutableStateOf("") }

    val formats = listOf("JPG", "PNG", "WebP")
    val ratios = listOf("Original", "1:1", "4:5", "3:4", "3:2", "16:9", "9:16")
    val rotations = listOf("0°", "90°", "180°", "270°")
    val watermarkPositions = listOf(
        "Arriba izquierda", "Arriba centro", "Arriba derecha",
        "Centro izquierda", "Centro", "Centro derecha",
        "Abajo izquierda", "Abajo centro", "Abajo derecha"
    )
    val resizePresets = listOf("Personalizado", "50 %", "75 %", "HD 1280×720", "Full HD 1920×1080")
    val qualityLabels = listOf("Máxima compresión", "Media", "Normal", "Calidad alta")
    val qualityValues = listOf(45f, 65f, 82f, 95f)

    fun outputSpec(): Triple<String, String, Bitmap.CompressFormat> {
        if (tool == ToolId.CONVERT_IMAGE) {
            return when (formats[formatIndex]) {
                "PNG" -> Triple("image/png", "imagen_convertida.png", Bitmap.CompressFormat.PNG)
                "WebP" -> Triple("image/webp", "imagen_convertida.webp", Bitmap.CompressFormat.WEBP)
                else -> Triple("image/jpeg", "imagen_convertida.jpg", Bitmap.CompressFormat.JPEG)
            }
        }
        return Triple("image/jpeg", defaultOutputName(tool), Bitmap.CompressFormat.JPEG)
    }

    fun currentTransform(source: Bitmap): Bitmap = transformImage(
        source = source,
        tool = tool,
        quality = quality.toInt(),
        resizePreset = resizePreset,
        widthText = widthText,
        heightText = heightText,
        keepAspect = keepAspect,
        ratio = ratios[ratioIndex],
        rotation = (rotations[rotationIndex].removeSuffix("°").toFloatOrNull() ?: 0f) + fineRotation,
        cropLeft = cropLeft,
        cropTop = cropTop,
        cropRight = cropRight,
        cropBottom = cropBottom,
        resizePercent = resizePercent,
        flipH = flipH,
        flipV = flipV,
        watermark = watermark,
        opacity = opacity.toInt(),
        textSize = textSize.toInt(),
        position = watermarkPositions[positionIndex],
        repeatWatermark = repeatWatermark,
        darkText = darkText,
        filter = DocumentImageFilter.entries[filterIndex],
        brightness = brightness.toInt(),
        contrast = contrast,
        saturation = saturation
    )


    fun resetSource(uri: Uri?) {
        inputUriText = uri?.toString()
        val oldSource = sourcePreview
        val oldResult = resultPreview
        showOriginal = false
        showFullPreview = false
        sourcePreview = null
        resultPreview = null
        oldSource?.takeIf { !it.isRecycled }?.recycle()
        oldResult?.takeIf { !it.isRecycled }?.recycle()
    }

    fun resetAdjustments() {
        cropLeft = 0f
        cropTop = 0f
        cropRight = 1f
        cropBottom = 1f
        fineRotation = 0f
        resizePercent = 100f
        targetSizeKbText = ""
        qualityPreset = 2
        quality = 82f
        resizePreset = 0
        widthText = "1080"
        heightText = "1080"
        keepAspect = true
        formatIndex = 0
        ratioIndex = 0
        rotationIndex = 0
        flipH = false
        flipV = false
        watermark = ""
        opacity = 55f
        textSize = 6f
        positionIndex = 8
        repeatWatermark = false
        darkText = false
        brightness = 0f
        contrast = 1f
        saturation = 1f
        filterIndex = DocumentImageFilter.ORIGINAL.ordinal
        editorPanel = 0
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) resetSource(uri)
    }

    val selectLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        resetSource(uri)
    }

    LaunchedEffect(inputUriText) {
        val uri = inputUriText?.let(Uri::parse) ?: return@LaunchedEffect
        if (sourcePreview != null) return@LaunchedEffect
        runCatching { ToolFileUtils.loadBitmap(context, uri, maxEdge = 1200) }
            .onSuccess { sourcePreview = it }
            .onFailure { onMessage(it.message ?: "No se pudo abrir la imagen.") }
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/*")) { output ->
        val sourceUri = input
        if (output == null || sourceUri == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                val source = ToolFileUtils.loadBitmap(context, sourceUri)
                var transformed: Bitmap = source
                try {
                    transformed = withContext(Dispatchers.Default) { currentTransform(source) }
                    val spec = outputSpec()
                    // Si el usuario pidio un peso objetivo, se busca la calidad que mas
                    // se acerque sin pasarse. Solo aplica a formatos con perdida.
                    val targetKb = targetSizeKbText.toIntOrNull()
                    val outputQuality = when {
                        spec.third == Bitmap.CompressFormat.PNG -> 100
                        targetKb != null && targetKb > 0 -> withContext(Dispatchers.Default) {
                            ToolFileUtils.qualityForTargetBytes(transformed, targetKb * 1024L)
                        }
                        tool == ToolId.COMPRESS_IMAGE || tool == ToolId.CONVERT_IMAGE -> quality.toInt()
                        else -> 92
                    }
                    ToolFileUtils.writeBitmap(context, transformed, output, spec.third, outputQuality)
                } finally {
                    if (transformed !== source && !transformed.isRecycled) transformed.recycle()
                    if (!source.isRecycled) source.recycle()
                }
            }.onSuccess { onMessage(successMessage("Imagen guardada correctamente.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar la imagen.") }
            processing = false
        }
    }

    LaunchedEffect(
        sourcePreview,
        resizePreset,
        widthText,
        heightText,
        keepAspect,
        ratioIndex,
        rotationIndex,
        cropLeft,
        cropTop,
        cropRight,
        cropBottom,
        fineRotation,
        resizePercent,
        flipH,
        flipV,
        watermark,
        opacity,
        textSize,
        positionIndex,
        repeatWatermark,
        darkText,
        brightness,
        contrast,
        saturation,
        filterIndex
    ) {
        val source = sourcePreview ?: return@LaunchedEffect
        previewLoading = true
        runCatching { withContext(Dispatchers.Default) { currentTransform(source) } }
            .onSuccess { newResult ->
                val safeResult = if (newResult === source) source.copy(Bitmap.Config.ARGB_8888, false) else newResult
                val old = resultPreview
                resultPreview = safeResult
                if (old != null && old !== safeResult && !old.isRecycled) old.recycle()
            }
            .onFailure { resultPreview = null }
        previewLoading = false
    }

    DisposableEffect(Unit) {
        onDispose {
            sourcePreview?.takeIf { !it.isRecycled }?.recycle()
            resultPreview?.takeIf { !it.isRecycled }?.recycle()
        }
    }

    val displayed = if (showOriginal) sourcePreview else resultPreview ?: sourcePreview

    if (showFullPreview && displayed != null) {
        ImageWorkspaceEditorDialog(
            tool = tool,
            bitmap = displayed,
            quality = quality,
            onQualityChange = { quality = it },
            resizePreset = resizePreset,
            onResizePresetChange = { resizePreset = it },
            widthText = widthText,
            onWidthTextChange = { widthText = it },
            heightText = heightText,
            onHeightTextChange = { heightText = it },
            keepAspect = keepAspect,
            onKeepAspectChange = { keepAspect = it },
            ratioIndex = ratioIndex,
            ratios = ratios,
            onRatioIndexChange = { ratioIndex = it },
            rotationIndex = rotationIndex,
            rotations = rotations,
            onRotationIndexChange = { rotationIndex = it },
            flipH = flipH,
            onFlipHChange = { flipH = !flipH },
            flipV = flipV,
            onFlipVChange = { flipV = !flipV },
            watermark = watermark,
            onWatermarkChange = { watermark = it.take(80) },
            opacity = opacity,
            onOpacityChange = { opacity = it },
            textSize = textSize,
            onTextSizeChange = { textSize = it },
            positionIndex = positionIndex,
            watermarkPositions = watermarkPositions,
            onPositionIndexChange = { positionIndex = it },
            repeatWatermark = repeatWatermark,
            onRepeatWatermarkChange = { repeatWatermark = it },
            darkText = darkText,
            onDarkTextChange = { darkText = it },
            brightness = brightness,
            onBrightnessChange = { brightness = it },
            contrast = contrast,
            onContrastChange = { contrast = it },
            saturation = saturation,
            onSaturationChange = { saturation = it },
            filterIndex = filterIndex,
            filterLabels = DocumentImageFilter.entries.map { it.label },
            onFilterIndexChange = { filterIndex = it },
            cropLeft = cropLeft,
            cropTop = cropTop,
            cropRight = cropRight,
            cropBottom = cropBottom,
            onCropChange = { l, t, r, b ->
                cropLeft = l
                cropTop = t
                cropRight = r
                cropBottom = b
            },
            fineRotation = fineRotation,
            onFineRotationChange = { fineRotation = it },
            resizePercent = resizePercent,
            onResizePercentChange = { resizePercent = it },
            targetSizeKbText = targetSizeKbText,
            onTargetSizeKbTextChange = { targetSizeKbText = it.filter(Char::isDigit).take(6) },
            formats = formats,
            formatIndex = formatIndex,
            onFormatIndexChange = { formatIndex = it },
            processing = processing,
            currentPanel = editorPanel,
            onPanelChange = { editorPanel = it },
            onClose = { showFullPreview = false },
            onReset = ::resetAdjustments,
            onSave = {
                if (tool == ToolId.WATERMARK_IMAGE && watermark.isBlank()) {
                    onMessage("Escribe el texto de la marca de agua.")
                } else {
                    launchPaidExport(viewModel, tool, onMessage) { saveLauncher.launch(outputSpec().second) }
                }
            }
        )
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Costo por exportación: ${tool.creditCost} créditos", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Imagen de trabajo", style = MaterialTheme.typography.titleLarge)
                        Text(
                            input?.let {
                                "${ToolFileUtils.displayName(context, it)} · ${ToolFileUtils.readableSize(ToolFileUtils.fileSize(context, it))}"
                            } ?: "Selecciona una imagen para comenzar.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                modifier = Modifier.weight(1f),
                                enabled = !processing
                            ) {
                                Icon(Icons.Rounded.Folder, contentDescription = null)
                                Text(" Galería")
                            }
                            OutlinedButton(
                                onClick = { selectLauncher.launch(arrayOf("image/*")) },
                                modifier = Modifier.weight(1f),
                                enabled = !processing
                            ) {
                                Icon(Icons.Rounded.Folder, contentDescription = null)
                                Text(" Archivos")
                            }
                        }
                        displayed?.let { bitmap ->
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Vista previa",
                                modifier = Modifier.fillMaxWidth().height(420.dp),
                                contentScale = ContentScale.Fit
                            )
                            FilledTonalButton(onClick = { showFullPreview = true }, modifier = Modifier.fillMaxWidth()) { Text("Abrir editor completo") }
                            Text("${bitmap.width} × ${bitmap.height} px", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(
                                    onClick = { showOriginal = true },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (showOriginal) NeonGreen else CardGreen,
                                        contentColor = if (showOriginal) DeepGreen else Color.White
                                    )
                                ) { Text("Original") }
                                FilledTonalButton(
                                    onClick = { showOriginal = false },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (!showOriginal) NeonGreen else CardGreen,
                                        contentColor = if (!showOriginal) DeepGreen else Color.White
                                    )
                                ) { Text("Resultado") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { resetAdjustments() }, enabled = !processing, modifier = Modifier.weight(1f)) { Text("Restablecer ajustes") }
                                OutlinedButton(onClick = { showOriginal = !showOriginal }, enabled = !processing, modifier = Modifier.weight(1f)) { Text(if (showOriginal) "Ver resultado" else "Ver original") }
                            }
                            if (previewLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }

            item {
                when (tool) {
                    ToolId.COMPRESS_IMAGE -> ImageSettingCard("Compresión") {
                        SimpleDropdown("Nivel rápido", qualityLabels, qualityPreset) {
                            qualityPreset = it
                            quality = qualityValues[it]
                        }
                        Text("Calidad: ${quality.toInt()} %")
                        Slider(value = quality, onValueChange = { quality = it }, valueRange = 30f..100f)
                        Text("Menor calidad reduce más el peso. El resultado exacto depende del contenido de la imagen.")
                    }
                    ToolId.RESIZE_IMAGE -> ImageSettingCard("Tamaño de salida") {
                        SimpleDropdown("Tamaño rápido", resizePresets, resizePreset) { resizePreset = it }
                        if (resizePreset == 0) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ImageNumberInput(widthText, { widthText = it }, "Ancho", Modifier.weight(1f))
                                ImageNumberInput(heightText, { heightText = it }, "Alto", Modifier.weight(1f))
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = keepAspect, onCheckedChange = { keepAspect = it })
                                Text("Mantener proporción sin deformar")
                            }
                        }
                        Text("Límite seguro: 8192 px por lado y 32 megapíxeles.")
                    }
                    ToolId.CONVERT_IMAGE -> ImageSettingCard("Formato de salida") {
                        SimpleDropdown("Formato", formats, formatIndex) { formatIndex = it }
                        if (formatIndex != 1) {
                            Text("Calidad: ${quality.toInt()} %")
                            Slider(value = quality, onValueChange = { quality = it }, valueRange = 40f..100f)
                        }
                        Text(if (formatIndex == 1) "PNG conserva transparencias." else "Las transparencias se reemplazan por fondo blanco al guardar JPG.")
                    }
                    ToolId.CROP_ROTATE_IMAGE -> ImageSettingCard("Recorte y orientación") {
                        SimpleDropdown("Proporción", ratios, ratioIndex) { ratioIndex = it }
                        SimpleDropdown("Rotación", rotations, rotationIndex) { rotationIndex = it }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ToggleButton("Voltear horizontal", flipH, { flipH = !flipH }, Modifier.weight(1f))
                            ToggleButton("Voltear vertical", flipV, { flipV = !flipV }, Modifier.weight(1f))
                        }
                        Text("El recorte usa el centro de la imagen para conservar la zona principal.")
                    }
                    ToolId.WATERMARK_IMAGE -> ImageSettingCard("Marca de agua") {
                        OutlinedTextField(
                            value = watermark,
                            onValueChange = { watermark = it.take(80) },
                            label = { Text("Texto") },
                            placeholder = { Text("Nombre, curso, fecha…") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        SimpleDropdown("Posición", watermarkPositions, positionIndex) { positionIndex = it }
                        Text("Opacidad: ${opacity.toInt()} %")
                        Slider(value = opacity, onValueChange = { opacity = it }, valueRange = 10f..100f)
                        Text("Tamaño: ${textSize.toInt()} %")
                        Slider(value = textSize, onValueChange = { textSize = it }, valueRange = 2f..15f)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = repeatWatermark, onCheckedChange = { repeatWatermark = it })
                            Text("Repetir por toda la imagen")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = darkText, onCheckedChange = { darkText = it })
                            Spacer(Modifier.width(8.dp))
                            Text(if (darkText) "Texto oscuro" else "Texto claro")
                        }
                    }
                    else -> Unit
                }
            }

            if (tool != ToolId.COMPRESS_IMAGE && tool != ToolId.CONVERT_IMAGE) {
                item {
                    ImageSettingCard("Ajustes finales") {
                        SimpleDropdown(
                            "Filtro",
                            DocumentImageFilter.entries.map { it.label },
                            filterIndex
                        ) { filterIndex = it }
                        Text("Brillo: ${brightness.toInt()}")
                        Slider(value = brightness, onValueChange = { brightness = it }, valueRange = -50f..50f)
                        Text("Contraste: ${String.format("%.2f", contrast)}")
                        Slider(value = contrast, onValueChange = { contrast = it }, valueRange = 0.7f..1.5f)
                        Text("Saturación: ${String.format("%.2f", saturation)}")
                        Slider(value = saturation, onValueChange = { saturation = it }, valueRange = 0f..1.8f)
                    }
                }
            }

            item {
                if (processing) {
                    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.12f)), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Procesando imagen", fontWeight = FontWeight.Bold)
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Text("No cierres la aplicación.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (tool == ToolId.WATERMARK_IMAGE && watermark.isBlank()) {
                            onMessage("Escribe el texto de la marca de agua.")
                        } else {
                            launchPaidExport(viewModel, tool, onMessage) {
                                saveLauncher.launch(outputSpec().second)
                            }
                        }
                    },
                    enabled = input != null && !processing,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) {
                    Icon(Icons.Rounded.Save, contentDescription = null)
                    Text(" Procesar y guardar · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                ImageInfoText("La imagen original permanece intacta. La vista previa usa una copia reducida; el archivo final se procesa con mayor resolución.")
            }
        }
    }
}

private fun transformImage(
    source: Bitmap,
    tool: ToolId,
    quality: Int,
    resizePreset: Int,
    widthText: String,
    heightText: String,
    keepAspect: Boolean,
    ratio: String,
    rotation: Float,
    cropLeft: Float,
    cropTop: Float,
    cropRight: Float,
    cropBottom: Float,
    resizePercent: Float,
    flipH: Boolean,
    flipV: Boolean,
    watermark: String,
    opacity: Int,
    textSize: Int,
    position: String,
    repeatWatermark: Boolean,
    darkText: Boolean,
    filter: DocumentImageFilter,
    brightness: Int,
    contrast: Float,
    saturation: Float
): Bitmap {
    var current: Bitmap = source
    fun replace(next: Bitmap) {
        if (next !== current && current !== source && !current.isRecycled) current.recycle()
        current = next
    }

    when (tool) {
        ToolId.RESIZE_IMAGE -> {
            val resized = when (resizePreset) {
                // Porcentaje libre con el deslizador.
                1 -> ToolFileUtils.resizeByPercent(current, resizePercent.roundToInt().coerceIn(5, 200))
                2 -> ToolFileUtils.resize(current, 1080, 1080, true)
                3 -> ToolFileUtils.resize(current, 1280, 720, true)
                4 -> ToolFileUtils.resize(current, 1920, 1080, true)
                else -> ToolFileUtils.resize(
                    current,
                    widthText.toIntOrNull() ?: error("Ancho inválido."),
                    heightText.toIntOrNull() ?: error("Alto inválido."),
                    keepAspect
                )
            }
            replace(resized)
        }
        ToolId.CROP_ROTATE_IMAGE -> {
            // Primero el recorte libre que el usuario dibujo con las esquinas.
            // Solo despues se aplica la proporcion fija, si eligio alguna.
            if (cropLeft > 0.001f || cropTop > 0.001f || cropRight < 0.999f || cropBottom < 0.999f) {
                replace(ToolFileUtils.cropRect(current, cropLeft, cropTop, cropRight, cropBottom))
            }
            if (ratio != "Original") {
                val (rw, rh) = when (ratio) {
                    "4:5" -> 4 to 5
                    "3:4" -> 3 to 4
                    "3:2" -> 3 to 2
                    "16:9" -> 16 to 9
                    "9:16" -> 9 to 16
                    else -> 1 to 1
                }
                replace(ToolFileUtils.centerCrop(current, rw, rh))
            }
            replace(ToolFileUtils.rotateFlip(current, rotation, flipH, flipV))
        }
        ToolId.WATERMARK_IMAGE -> replace(
            ToolFileUtils.addWatermark(
                current,
                watermark,
                opacity,
                textSize,
                position,
                repeatWatermark,
                darkText
            )
        )
        else -> Unit
    }

    if (tool != ToolId.COMPRESS_IMAGE && tool != ToolId.CONVERT_IMAGE) {
        replace(ToolFileUtils.applyImageAdjustments(current, filter, brightness, contrast, saturation))
    }
    return current
}

private fun defaultOutputName(tool: ToolId): String = when (tool) {
    ToolId.COMPRESS_IMAGE -> "imagen_comprimida.jpg"
    ToolId.RESIZE_IMAGE -> "imagen_redimensionada.jpg"
    ToolId.CROP_ROTATE_IMAGE -> "imagen_recortada.jpg"
    ToolId.WATERMARK_IMAGE -> "imagen_marca_agua.jpg"
    else -> "imagen_procesada.jpg"
}

@Composable
private fun ImageSettingCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            content()
        }
    }
}

@Composable
private fun ImageNumberInput(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(it.filter(Char::isDigit).take(5)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
        singleLine = true
    )
}

@Composable
private fun ToggleButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilledTonalButton(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = if (selected) NeonGreen else CardGreen,
            contentColor = if (selected) DeepGreen else Color.White
        )
    ) { Text(label) }
}

@Composable
private fun ImageInfoText(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
        Text(text, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


@Composable
private fun ImageWorkspaceEditorDialog(
    tool: ToolId,
    bitmap: Bitmap,
    quality: Float,
    onQualityChange: (Float) -> Unit,
    resizePreset: Int,
    onResizePresetChange: (Int) -> Unit,
    widthText: String,
    onWidthTextChange: (String) -> Unit,
    heightText: String,
    onHeightTextChange: (String) -> Unit,
    keepAspect: Boolean,
    onKeepAspectChange: (Boolean) -> Unit,
    ratioIndex: Int,
    ratios: List<String>,
    onRatioIndexChange: (Int) -> Unit,
    rotationIndex: Int,
    rotations: List<String>,
    onRotationIndexChange: (Int) -> Unit,
    flipH: Boolean,
    onFlipHChange: () -> Unit,
    flipV: Boolean,
    onFlipVChange: () -> Unit,
    watermark: String,
    onWatermarkChange: (String) -> Unit,
    opacity: Float,
    onOpacityChange: (Float) -> Unit,
    textSize: Float,
    onTextSizeChange: (Float) -> Unit,
    positionIndex: Int,
    watermarkPositions: List<String>,
    onPositionIndexChange: (Int) -> Unit,
    repeatWatermark: Boolean,
    onRepeatWatermarkChange: (Boolean) -> Unit,
    darkText: Boolean,
    onDarkTextChange: (Boolean) -> Unit,
    brightness: Float,
    onBrightnessChange: (Float) -> Unit,
    contrast: Float,
    onContrastChange: (Float) -> Unit,
    saturation: Float,
    onSaturationChange: (Float) -> Unit,
    filterIndex: Int,
    filterLabels: List<String>,
    onFilterIndexChange: (Int) -> Unit,
    cropLeft: Float,
    cropTop: Float,
    cropRight: Float,
    cropBottom: Float,
    onCropChange: (Float, Float, Float, Float) -> Unit,
    fineRotation: Float,
    onFineRotationChange: (Float) -> Unit,
    resizePercent: Float,
    onResizePercentChange: (Float) -> Unit,
    targetSizeKbText: String,
    onTargetSizeKbTextChange: (String) -> Unit,
    formats: List<String>,
    formatIndex: Int,
    onFormatIndexChange: (Int) -> Unit,
    processing: Boolean,
    currentPanel: Int,
    onPanelChange: (Int) -> Unit,
    onClose: () -> Unit,
    onReset: () -> Unit,
    onSave: () -> Unit
) {
    // Mismo motor de zoom que los visores: anclado al punto entre los dedos.
    val zoomState = remember { mutableFloatStateOf(1f) }
    val panXState = remember { mutableFloatStateOf(0f) }
    val panYState = remember { mutableFloatStateOf(0f) }
    var zoom by zoomState
    var panX by panXState
    var panY by panYState
    val title = when (tool) {
        ToolId.RESIZE_IMAGE -> "Ajustar el tamaño"
        ToolId.CROP_ROTATE_IMAGE -> "Editar foto"
        ToolId.WATERMARK_IMAGE -> "Texto y marca de agua"
        ToolId.CONVERT_IMAGE -> "Convertir formato"
        ToolId.COMPRESS_IMAGE -> "Comprimir imagen"
        else -> tool.title
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF151821))
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = Color.White) }
                Text(
                    title,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = onReset) { Text("Reset") }
                    Spacer(Modifier.width(8.dp))
                    FilledTonalButton(onClick = onSave, enabled = !processing) { Text(if (processing) "Guardando" else "Guardar") }
                }
            }
            val cropping = tool == ToolId.CROP_ROTATE_IMAGE && currentPanel == 0
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Black)
                    .clipToBounds()
            ) {
                val density = LocalDensity.current
                val viewportW = with(density) { maxWidth.toPx() }
                val viewportH = with(density) { maxHeight.toPx() }
                val imageRatio = bitmap.width.toFloat() / bitmap.height.toFloat().coerceAtLeast(1f)
                val maxRatio = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
                val displayWidth = if (imageRatio > maxRatio) maxWidth.value * 0.92f else maxHeight.value * 0.88f * imageRatio
                val displayHeight = displayWidth / imageRatio

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        // Mientras se recorta, el pellizco se desactiva para que arrastrar
                        // una esquina no compita con el zoom.
                        .then(
                            if (!cropping) {
                                Modifier.viewerPinchZoomGestures(
                                    gestureKey = bitmap,
                                    zoomState = zoomState,
                                    panXState = panXState,
                                    panYState = panYState,
                                    minZoom = 1f,
                                    maxZoom = 6f,
                                    viewportWidthPx = viewportW,
                                    viewportHeightPx = viewportH
                                )
                            } else Modifier
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                transformOrigin = TransformOrigin(0f, 0f)
                                scaleX = zoom
                                scaleY = zoom
                                translationX = panX
                                translationY = panY
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .width(displayWidth.dp)
                                .height(displayHeight.dp)
                        ) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                            if (cropping) {
                                ImageCropOverlay(
                                    left = cropLeft,
                                    top = cropTop,
                                    right = cropRight,
                                    bottom = cropBottom,
                                    lockedRatio = when (ratios.getOrNull(ratioIndex)) {
                                        "1:1" -> 1f
                                        "4:5" -> 4f / 5f
                                        "3:4" -> 3f / 4f
                                        "3:2" -> 3f / 2f
                                        "16:9" -> 16f / 9f
                                        "9:16" -> 9f / 16f
                                        else -> null
                                    },
                                    onChange = onCropChange,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xAA505050))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        if (cropping) {
                            val cw = ((cropRight - cropLeft) * bitmap.width).roundToInt()
                            val ch = ((cropBottom - cropTop) * bitmap.height).roundToInt()
                            "Recorte $cw×$ch"
                        } else {
                            "${bitmap.width}×${bitmap.height} · ${(zoom * 100).toInt()}%"
                        },
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1B1E27))
                    .imePadding()
            ) {
                when (tool) {
                    ToolId.RESIZE_IMAGE -> ResizeWorkspacePanel(
                        resizePreset, onResizePresetChange, widthText, onWidthTextChange,
                        heightText, onHeightTextChange, keepAspect, onKeepAspectChange,
                        resizePercent, onResizePercentChange,
                        targetSizeKbText, onTargetSizeKbTextChange,
                        bitmap.width, bitmap.height
                    )
                    ToolId.CROP_ROTATE_IMAGE -> CropRotateWorkspacePanel(
                        currentPanel, onPanelChange, ratioIndex, ratios, onRatioIndexChange,
                        rotationIndex, rotations, onRotationIndexChange,
                        fineRotation, onFineRotationChange,
                        flipH, onFlipHChange, flipV, onFlipVChange,
                        brightness, onBrightnessChange, contrast, onContrastChange,
                        saturation, onSaturationChange, filterIndex, filterLabels, onFilterIndexChange,
                        onCropReset = { onCropChange(0f, 0f, 1f, 1f) }
                    )
                    ToolId.WATERMARK_IMAGE -> WatermarkWorkspacePanel(watermark, onWatermarkChange, opacity, onOpacityChange, textSize, onTextSizeChange, positionIndex, watermarkPositions, onPositionIndexChange, repeatWatermark, onRepeatWatermarkChange, darkText, onDarkTextChange)
                    ToolId.CONVERT_IMAGE -> ConvertWorkspacePanel(formats, formatIndex, onFormatIndexChange, quality, onQualityChange)
                    ToolId.COMPRESS_IMAGE -> CompressWorkspacePanel(quality, onQualityChange)
                    else -> CompressWorkspacePanel(quality, onQualityChange)
                }
            }
        }
    }
}


/**
 * Recuadro de recorte libre. El usuario arrastra las cuatro esquinas o mueve todo
 * el recuadro. Se dibuja sobre la imagen con la rejilla de tercios, igual que en
 * cualquier editor de fotos. Antes la herramienta solo ofrecia proporciones fijas
 * con recorte centrado: no se podia elegir que parte de la foto se conservaba.
 */
@Composable
private fun ImageCropOverlay(
    left: Float,
    top: Float,
    right: Float,
    bottom: Float,
    lockedRatio: Float?,
    onChange: (Float, Float, Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val current by rememberUpdatedState(listOf(left, top, right, bottom))
    val onChangeState by rememberUpdatedState(onChange)
    val ratioState by rememberUpdatedState(lockedRatio)

    BoxWithConstraints(modifier) {
        val wPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val hPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        var mode by remember { mutableStateOf<CropDragMode?>(null) }
        val touchSlop = 46f
        val minSize = 0.08f

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(wPx, hPx) {
                    detectDragGestures(
                        onDragStart = { p ->
                            val (l, t, r, b) = current
                            val corners = listOf(
                                CropDragMode.TOP_LEFT to Offset(l * wPx, t * hPx),
                                CropDragMode.TOP_RIGHT to Offset(r * wPx, t * hPx),
                                CropDragMode.BOTTOM_LEFT to Offset(l * wPx, b * hPx),
                                CropDragMode.BOTTOM_RIGHT to Offset(r * wPx, b * hPx)
                            )
                            mode = corners
                                .minByOrNull { (_, c) -> (p - c).getDistance() }
                                ?.takeIf { (_, c) -> (p - c).getDistance() <= touchSlop }
                                ?.first
                                ?: if (p.x in (l * wPx)..(r * wPx) && p.y in (t * hPx)..(b * hPx)) {
                                    CropDragMode.MOVE
                                } else null
                        },
                        onDragEnd = { mode = null },
                        onDragCancel = { mode = null }
                    ) { _, drag ->
                        val (l, t, r, b) = current
                        val dx = drag.x / wPx
                        val dy = drag.y / hPx
                        var nl = l
                        var nt = t
                        var nr = r
                        var nb = b
                        when (mode) {
                            CropDragMode.MOVE -> {
                                val cw = r - l
                                val ch = b - t
                                nl = (l + dx).coerceIn(0f, 1f - cw)
                                nt = (t + dy).coerceIn(0f, 1f - ch)
                                nr = nl + cw
                                nb = nt + ch
                            }
                            CropDragMode.TOP_LEFT -> {
                                nl = (l + dx).coerceIn(0f, r - minSize)
                                nt = (t + dy).coerceIn(0f, b - minSize)
                            }
                            CropDragMode.TOP_RIGHT -> {
                                nr = (r + dx).coerceIn(l + minSize, 1f)
                                nt = (t + dy).coerceIn(0f, b - minSize)
                            }
                            CropDragMode.BOTTOM_LEFT -> {
                                nl = (l + dx).coerceIn(0f, r - minSize)
                                nb = (b + dy).coerceIn(t + minSize, 1f)
                            }
                            CropDragMode.BOTTOM_RIGHT -> {
                                nr = (r + dx).coerceIn(l + minSize, 1f)
                                nb = (b + dy).coerceIn(t + minSize, 1f)
                            }
                            null -> return@detectDragGestures
                        }

                        // Si hay proporcion bloqueada, se corrige el alto a partir del
                        // ancho para que el recuadro nunca se deforme.
                        val lockRatio = ratioState
                        if (lockRatio != null && mode != CropDragMode.MOVE) {
                            val widthPx = (nr - nl) * wPx
                            val targetHeightNorm = (widthPx / lockRatio) / hPx
                            when (mode) {
                                CropDragMode.TOP_LEFT, CropDragMode.TOP_RIGHT ->
                                    nt = (nb - targetHeightNorm).coerceIn(0f, nb - minSize)
                                else ->
                                    nb = (nt + targetHeightNorm).coerceIn(nt + minSize, 1f)
                            }
                        }
                        if (nr - nl >= minSize && nb - nt >= minSize) {
                            onChangeState(nl, nt, nr, nb)
                        }
                    }
                }
        ) {
            val l = left * size.width
            val t = top * size.height
            val r = right * size.width
            val b = bottom * size.height
            val shade = Color.Black.copy(alpha = 0.55f)
            drawRect(shade, Offset(0f, 0f), Size(size.width, t.coerceAtLeast(0f)))
            drawRect(shade, Offset(0f, b), Size(size.width, (size.height - b).coerceAtLeast(0f)))
            drawRect(shade, Offset(0f, t), Size(l.coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))
            drawRect(shade, Offset(r, t), Size((size.width - r).coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))

            // Rejilla de tercios
            val gridColor = Color.White.copy(alpha = 0.32f)
            for (i in 1..2) {
                val x = l + (r - l) * i / 3f
                val y = t + (b - t) * i / 3f
                drawLine(gridColor, Offset(x, t), Offset(x, b), strokeWidth = 1.5f)
                drawLine(gridColor, Offset(l, y), Offset(r, y), strokeWidth = 1.5f)
            }

            drawRect(
                color = Color.White,
                topLeft = Offset(l, t),
                size = Size((r - l).coerceAtLeast(1f), (b - t).coerceAtLeast(1f)),
                style = Stroke(width = 3f)
            )

            // Escuadras gruesas en las esquinas, como referencia de agarre
            val arm = ((r - l).coerceAtMost(b - t) * 0.18f).coerceIn(22f, 64f)
            val thick = 8f
            listOf(
                Triple(Offset(l, t), 1f, 1f),
                Triple(Offset(r, t), -1f, 1f),
                Triple(Offset(l, b), 1f, -1f),
                Triple(Offset(r, b), -1f, -1f)
            ).forEach { (corner, sx, sy) ->
                drawLine(Color.White, corner, Offset(corner.x + arm * sx, corner.y), strokeWidth = thick)
                drawLine(Color.White, corner, Offset(corner.x, corner.y + arm * sy), strokeWidth = thick)
            }
        }
    }
}

private enum class CropDragMode { MOVE, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }

@Composable
private fun ResizeWorkspacePanel(
    resizePreset: Int,
    onResizePresetChange: (Int) -> Unit,
    widthText: String,
    onWidthTextChange: (String) -> Unit,
    heightText: String,
    onHeightTextChange: (String) -> Unit,
    keepAspect: Boolean,
    onKeepAspectChange: (Boolean) -> Unit,
    resizePercent: Float,
    onResizePercentChange: (Float) -> Unit,
    targetSizeKbText: String,
    onTargetSizeKbTextChange: (String) -> Unit,
    sourceWidth: Int,
    sourceHeight: Int
) {
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(max = 330.dp)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Original: ${sourceWidth}×${sourceHeight} px",
            color = Color(0xFFB6C0D4),
            style = MaterialTheme.typography.bodySmall
        )

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "Resolución exacta",
                "Porcentaje",
                "Cuadrada 1080",
                "HD 1280×720",
                "Full HD 1920×1080"
            ).forEachIndexed { index, label ->
                WorkspaceChoiceChip(label, resizePreset == index) { onResizePresetChange(index) }
            }
        }

        when (resizePreset) {
            0 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ImageNumberInput(widthText, onWidthTextChange, "Ancho", Modifier.weight(1f))
                    ImageNumberInput(heightText, onHeightTextChange, "Alto", Modifier.weight(1f))
                }
                ToggleButton(
                    if (keepAspect) "Proporción bloqueada" else "Proporción libre",
                    keepAspect,
                    { onKeepAspectChange(!keepAspect) }
                )
                // Atajos de redes sociales tomados de las medidas mas usadas.
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "Historia 1080×1920" to (1080 to 1920),
                        "Post 1080×1080" to (1080 to 1080),
                        "Retrato 1080×1350" to (1080 to 1350),
                        "Portada 1200×630" to (1200 to 630),
                        "Miniatura 1280×720" to (1280 to 720)
                    ).forEach { (label, size) ->
                        WorkspaceChoiceChip(
                            label,
                            widthText == size.first.toString() && heightText == size.second.toString()
                        ) {
                            onWidthTextChange(size.first.toString())
                            onHeightTextChange(size.second.toString())
                        }
                    }
                }
            }
            1 -> {
                Text(
                    "Escala: ${resizePercent.roundToInt()} %  ·  " +
                        "${(sourceWidth * resizePercent / 100f).roundToInt()}×" +
                        "${(sourceHeight * resizePercent / 100f).roundToInt()} px",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold
                )
                Slider(
                    value = resizePercent,
                    onValueChange = onResizePercentChange,
                    valueRange = 10f..200f
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(25f, 50f, 75f, 100f, 150f).forEach { value ->
                        WorkspaceChoiceChip(
                            "${value.roundToInt()} %",
                            kotlin.math.abs(resizePercent - value) < 0.5f
                        ) { onResizePercentChange(value) }
                    }
                }
            }
            else -> ImageInfoText("Se usará una medida fija manteniendo la proporción original.")
        }

        ImageNumberInput(
            targetSizeKbText,
            onTargetSizeKbTextChange,
            "Peso objetivo en kB (opcional)",
            Modifier.fillMaxWidth()
        )
        ImageInfoText("Si escribes un peso, se busca la calidad JPEG que más se acerque sin pasarse.")
    }
}

@Composable
private fun CropRotateWorkspacePanel(
    currentPanel: Int,
    onPanelChange: (Int) -> Unit,
    ratioIndex: Int,
    ratios: List<String>,
    onRatioIndexChange: (Int) -> Unit,
    rotationIndex: Int,
    rotations: List<String>,
    onRotationIndexChange: (Int) -> Unit,
    fineRotation: Float,
    onFineRotationChange: (Float) -> Unit,
    flipH: Boolean,
    onFlipHChange: () -> Unit,
    flipV: Boolean,
    onFlipVChange: () -> Unit,
    brightness: Float,
    onBrightnessChange: (Float) -> Unit,
    contrast: Float,
    onContrastChange: (Float) -> Unit,
    saturation: Float,
    onSaturationChange: (Float) -> Unit,
    filterIndex: Int,
    filterLabels: List<String>,
    onFilterIndexChange: (Int) -> Unit,
    onCropReset: () -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 268.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (currentPanel) {
                0 -> {
                    ImageInfoText("Arrastra las esquinas para elegir qué parte se queda. Toca dentro para mover el recuadro.")
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ratios.forEachIndexed { index, label ->
                            WorkspaceChoiceChip(
                                if (index == 0) "Libre" else label,
                                ratioIndex == index
                            ) { onRatioIndexChange(index) }
                        }
                    }
                    ToggleButton("Restablecer recorte", false, { onCropReset() })
                }

                1 -> {
                    Text(
                        "Ángulo: ${"%.1f".format(fineRotation)}°",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                    // Dial fino de -45 a 45 grados, ademas de los giros de 90.
                    Slider(
                        value = fineRotation,
                        onValueChange = onFineRotationChange,
                        valueRange = -45f..45f
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WorkspaceChoiceChip("Enderezar 0°", kotlin.math.abs(fineRotation) < 0.05f) {
                            onFineRotationChange(0f)
                        }
                        WorkspaceChoiceChip("Girar 90°", false) {
                            onRotationIndexChange((rotationIndex + 1) % rotations.size)
                        }
                    }
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rotations.forEachIndexed { index, label ->
                            WorkspaceChoiceChip(label, rotationIndex == index) { onRotationIndexChange(index) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ToggleButton("Espejo ↔", flipH, { onFlipHChange() })
                        ToggleButton("Espejo ↕", flipV, { onFlipVChange() })
                    }
                }

                else -> {
                    Text("Brillo: ${brightness.roundToInt()}", color = Color.White)
                    Slider(value = brightness, onValueChange = onBrightnessChange, valueRange = -100f..100f)
                    Text("Contraste: ${"%.2f".format(contrast)}", color = Color.White)
                    Slider(value = contrast, onValueChange = onContrastChange, valueRange = 0.4f..2.2f)
                    Text("Saturación: ${"%.2f".format(saturation)}", color = Color.White)
                    Slider(value = saturation, onValueChange = onSaturationChange, valueRange = 0f..2.5f)
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        filterLabels.forEachIndexed { index, label ->
                            WorkspaceChoiceChip(label, filterIndex == index) { onFilterIndexChange(index) }
                        }
                    }
                    ToggleButton("Restablecer ajustes", false, {
                        onBrightnessChange(0f)
                        onContrastChange(1f)
                        onSaturationChange(1f)
                        onFilterIndexChange(0)
                    })
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xFF141720))
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            // La pestana intermedia antes estaba vacia: solo mostraba dos textos.
            // Ahora las tres hacen algo.
            WorkspaceToolbarTab("Cortar", currentPanel == 0) { onPanelChange(0) }
            WorkspaceToolbarTab("Rotar", currentPanel == 1) { onPanelChange(1) }
            WorkspaceToolbarTab("Ajustes", currentPanel == 2) { onPanelChange(2) }
        }
    }
}

@Composable
private fun WatermarkWorkspacePanel(
    watermark: String,
    onWatermarkChange: (String) -> Unit,
    opacity: Float,
    onOpacityChange: (Float) -> Unit,
    textSize: Float,
    onTextSizeChange: (Float) -> Unit,
    positionIndex: Int,
    watermarkPositions: List<String>,
    onPositionIndexChange: (Int) -> Unit,
    repeatWatermark: Boolean,
    onRepeatWatermarkChange: (Boolean) -> Unit,
    darkText: Boolean,
    onDarkTextChange: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(value = watermark, onValueChange = onWatermarkChange, label = { Text("Texto") }, modifier = Modifier.fillMaxWidth())
        Text("Posición", color = Color.White, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            watermarkPositions.forEachIndexed { index, label -> WorkspaceChoiceChip(label, positionIndex == index) { onPositionIndexChange(index) } }
        }
        Text("Opacidad: ${opacity.toInt()} %", color = Color.White, fontWeight = FontWeight.Bold)
        Slider(value = opacity, onValueChange = onOpacityChange, valueRange = 10f..100f)
        Text("Tamaño: ${textSize.toInt()} %", color = Color.White, fontWeight = FontWeight.Bold)
        Slider(value = textSize, onValueChange = onTextSizeChange, valueRange = 2f..15f)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = repeatWatermark, onCheckedChange = onRepeatWatermarkChange)
            Text("Repetir por toda la imagen", color = Color.White)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = darkText, onCheckedChange = onDarkTextChange)
            Spacer(Modifier.width(8.dp))
            Text(if (darkText) "Texto oscuro" else "Texto claro", color = Color.White)
        }
    }
}

@Composable
private fun ConvertWorkspacePanel(
    formats: List<String>,
    formatIndex: Int,
    onFormatIndexChange: (Int) -> Unit,
    quality: Float,
    onQualityChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Formato de salida", color = Color.White, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            formats.forEachIndexed { index, label -> WorkspaceChoiceChip(label, formatIndex == index) { onFormatIndexChange(index) } }
        }
        if (formats.getOrNull(formatIndex) != "PNG") {
            Text("Calidad: ${quality.toInt()} %", color = Color.White, fontWeight = FontWeight.Bold)
            Slider(value = quality, onValueChange = onQualityChange, valueRange = 40f..100f)
        }
    }
}

@Composable
private fun CompressWorkspacePanel(quality: Float, onQualityChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Calidad y compresión", color = Color.White, fontWeight = FontWeight.Bold)
        Slider(value = quality, onValueChange = onQualityChange, valueRange = 30f..100f)
        Text("${quality.toInt()} %", color = Color(0xFFE2E2E2))
    }
}

@Composable
private fun WorkspaceToolbarTab(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .height(46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (active) Color(0xFF6EA0E8) else Color(0xFF2B2F3B))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (active) Color.Black else Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun WorkspaceChoiceChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .heightIn(min = 42.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (active) Color(0xFF6EA0E8) else Color(0xFF232733))
            .border(1.dp, if (active) Color(0xFF93BEFF) else Color(0xFF3A3F4D), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (active) Color.Black else Color.White, fontWeight = FontWeight.SemiBold)
    }
}
