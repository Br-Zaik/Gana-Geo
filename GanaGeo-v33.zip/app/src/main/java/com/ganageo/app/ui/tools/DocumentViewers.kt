package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer as AndroidPdfRenderer
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.ContentUris
import android.content.pm.ActivityInfo
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.rendering.PDFRenderer as PdfBoxRenderer
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.CancellationSignal
import android.util.Xml
import android.provider.MediaStore
import android.util.LruCache
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.delay
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.flow.collect
import org.xmlpull.v1.XmlPullParser
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import java.io.Closeable
import java.text.DateFormat
import java.util.Date
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.InvertColors
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign

@Composable
fun PdfViewerScreen(
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    var uriText by remember { mutableStateOf<String?>(null) }
    val uri = remember(uriText) {
        uriText?.takeIf { it.isNotBlank() }?.let { stored -> runCatching { Uri.parse(stored) }.getOrNull() }
    }
    var pageCount by remember { mutableIntStateOf(0) }
    var loadingDocument by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var localPdfPath by remember { mutableStateOf<String?>(null) }
    var pdfEngine by remember { mutableStateOf<PdfRenderEngine?>(null) }
    var retryToken by remember { mutableIntStateOf(0) }
    var recentFiles by remember { mutableStateOf<List<ViewerRecentFile>>(emptyList()) }
    var recentLoading by remember { mutableStateOf(false) }
    var recentRefreshToken by remember { mutableIntStateOf(0) }

    fun selectPdf(selected: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                selected,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        rememberViewerRecentFile(context, ViewerRecentKind.PDF, selected)
        localPdfPath?.let { old ->
            ViewerBitmapCache.clearPrefix("pdf|$old")
            PdfSessionRegistry.close(old)
            runCatching { File(old).delete() }
        }
        localPdfPath = null
        pdfEngine = null
        loadingDocument = true
        uriText = selected.toString()
        pageCount = 0
        loadError = null
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        selected?.let(::selectPdf)
    }

    LaunchedEffect(uriText, recentRefreshToken) {
        if (uri == null) {
            recentLoading = true
            recentFiles = runCatching { loadViewerRecentFiles(context, ViewerRecentKind.PDF) }
                .getOrDefault(emptyList())
            recentLoading = false
        }
    }

    LaunchedEffect(uriText, retryToken) {
        val selected = uri ?: run {
            pageCount = 0
            loadError = null
            localPdfPath = null
            pdfEngine = null
            onImmersiveChanged(false)
            return@LaunchedEffect
        }
        onImmersiveChanged(true)
        loadingDocument = true
        loadError = null
        pageCount = 0

        val previousPath = localPdfPath
        var attemptedCopy: File? = null
        val result = runCatching {
            PDFBoxResourceLoader.init(context.applicationContext)

            // Siempre convertimos el URI SAF/Drive en un archivo local seekable antes de
            // abrir el documento. PdfRenderer necesita acceso aleatorio y algunos
            // proveedores content:// entregan pipes que funcionan en Drive pero no como
            // descriptor seekable directo.
            val copy = kotlinx.coroutines.withTimeout(25000L) {
                copyPdfToViewerCache(context, selected)
            }
            attemptedCopy = copy
            val openInfo = kotlinx.coroutines.withTimeout(20000L) {
                detectLocalPdf(copy)
            }
            require(openInfo.pageCount > 0) { "El PDF no contiene paginas." }
            Triple(copy, openInfo.pageCount, openInfo.engine)
        }
        result.exceptionOrNull()?.let { error ->
            if (error is kotlinx.coroutines.CancellationException &&
                error !is kotlinx.coroutines.TimeoutCancellationException
            ) {
                attemptedCopy?.let { cancelled ->
                    PdfSessionRegistry.close(cancelled.absolutePath)
                    runCatching { cancelled.delete() }
                }
                throw error
            }
        }

        result.onSuccess { (copy, count, engine) ->
            previousPath?.takeIf { it != copy.absolutePath }?.let { old ->
                PdfSessionRegistry.close(old)
                runCatching { File(old).delete() }
            }
            localPdfPath = copy.absolutePath
            pdfEngine = engine
            pageCount = count
        }.onFailure { error ->
            attemptedCopy?.let { failed ->
                PdfSessionRegistry.close(failed.absolutePath)
                runCatching { failed.delete() }
            }
            localPdfPath = null
            pdfEngine = null
            pageCount = 0
            loadError = when {
                error is kotlinx.coroutines.TimeoutCancellationException ->
                    "El PDF tardo demasiado en responder. Vuelve a intentarlo."
                error.message?.contains("password", ignoreCase = true) == true ->
                    "Este PDF esta protegido y no se pudo abrir."
                else -> error.message ?: "No se pudo abrir este PDF."
            }
        }
        loadingDocument = false
    }


    DisposableEffect(Unit) {
        onDispose {
            onImmersiveChanged(false)
            localPdfPath?.let { path ->
                ViewerBitmapCache.clearPrefix("pdf|$path")
                PdfSessionRegistry.close(path)
                runCatching { File(path).delete() }
            }
        }
    }

    if (uri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Visor gratuito · el archivo no se modifica", onBack)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Ningún PDF seleccionado", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { launcher.launch(arrayOf("application/pdf")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                        Text(" Abrir PDF")
                    }
                }
            }
            ViewerRecentFilesSection(
                kind = ViewerRecentKind.PDF,
                files = recentFiles,
                loading = recentLoading,
                modifier = Modifier.weight(1f),
                onOpen = { selectPdf(it.uri) },
                onRefresh = { recentRefreshToken++ }
            )
        }
        return
    }

    val fileName = remember(uriText, uri) {
        runCatching { ToolFileUtils.displayName(context, uri) }
            .getOrElse { uri.lastPathSegment ?: "archivo" }
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding(),
            color = Color(0xFF202124),
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = Color.White)
                }
                Text(
                    fileName,
                    modifier = Modifier.weight(1f),
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = { shareDocumentFile(context, uri, "application/pdf") }) {
                    Icon(Icons.Rounded.Share, contentDescription = "Compartir PDF", tint = Color.White)
                }
                IconButton(onClick = { launcher.launch(arrayOf("application/pdf")) }) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = "Cambiar PDF", tint = Color.White)
                }
            }
        }

        if (loadingDocument) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = NeonGreen)
                    Spacer(Modifier.height(14.dp))
                    Text("Abriendo PDF…", color = Color.White.copy(alpha = 0.78f))
                }
            }
        } else if (loadError != null || pageCount <= 0 || pdfEngine == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF202124)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("No se pudo abrir el PDF", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(
                            loadError ?: "El archivo no contiene páginas compatibles.",
                            color = Color.White.copy(alpha = 0.72f)
                        )
                        OutlinedButton(onClick = { retryToken++ }, modifier = Modifier.fillMaxWidth()) {
                            Text("Reintentar")
                        }
                        OutlinedButton(
                            onClick = { launcher.launch(arrayOf("application/pdf")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                            Text(" Elegir otro PDF")
                        }
                    }
                }
            }
        } else {
            DrivePagedSurface(
                viewerKey = "pdf_${uriText.orEmpty()}",
                pageCount = pageCount,
                background = Color(0xFF121212),
                minZoom = 1f,
                maxZoom = 2.5f,
                renderDebounceMillis = 240L,
                renderScaleMultiplier = 1.15f,
                maxRasterWidth = minOf(2400, viewerMaxRasterWidth()),
                neighborRasterWidth = 1100,
                onCurrentPageChanged = {},
                pageContent = { index, renderWidth, pageWidth, highQualityEnabled ->
                    ContinuousPdfPage(
                        uri = uri,
                        localPdfPath = localPdfPath,
                        engine = pdfEngine!!,
                        pageIndex = index,
                        renderWidth = renderWidth,
                        highQualityEnabled = highQualityEnabled,
                        modifier = Modifier.width(pageWidth),
                        onMessage = onMessage
                    )
                }
            )
        }
    }
}

@Composable
private fun PdfGridGlyph() {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(3) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                repeat(3) {
                    Box(
                        modifier = Modifier
                            .size(3.dp)
                            .background(Color(0xFF5F6368), RoundedCornerShape(1.dp))
                    )
                }
            }
        }
    }
}

@Composable
private fun ViewerZoomBadge(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color(0xE6323440),
        contentColor = Color.White,
        shape = RoundedCornerShape(18.dp),
        shadowElevation = 3.dp
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

/**
 * Cache compartida para paginas/diapositivas ya renderizadas. Mantener unas cuantas
 * superficies listas evita volver a rasterizar al subir/bajar rapido o al regresar a
 * una pagina que el usuario acaba de ver.
 */
private object ViewerBitmapCache {
    private val maxKb = ((Runtime.getRuntime().maxMemory() / 8L) / 1024L)
        .coerceIn(24L * 1024L, 64L * 1024L)
        .toInt()
    private val cache = object : LruCache<String, Bitmap>(maxKb) {
        override fun sizeOf(key: String, value: Bitmap): Int =
            (value.allocationByteCount / 1024).coerceAtLeast(1)
    }

    @Synchronized
    fun get(key: String): Bitmap? = cache.get(key)?.takeIf { !it.isRecycled }

    @Synchronized
    fun put(key: String, bitmap: Bitmap): Bitmap {
        cache.put(key, bitmap)
        return bitmap
    }

    @Synchronized
    fun clearPrefix(prefix: String) {
        val keys = cache.snapshot().keys.filter { it.startsWith(prefix) }
        keys.forEach(cache::remove)
    }
}

/**
 * Politica de calidad para las superficies paginadas.
 *
 * La referencia PDF a Audio escala inmediatamente el bitmap existente durante el gesto
 * y vuelve a rasterizar cuando termina el pinch. Aqui se conserva esa idea, pero el
 * limite de resolucion se adapta al heap para evitar que una sola pagina provoque OOM.
 */
private fun viewerMaxRasterWidth(): Int {
    val heapMb = Runtime.getRuntime().maxMemory() / (1024L * 1024L)
    return when {
        heapMb >= 384L -> 3200
        heapMb >= 256L -> 2900
        else -> 2400
    }
}

private fun viewerMaxPdfPixels(): Long {
    val heapMb = Runtime.getRuntime().maxMemory() / (1024L * 1024L)
    return when {
        heapMb >= 384L -> 13_000_000L
        heapMb >= 256L -> 10_500_000L
        else -> 7_500_000L
    }
}


/**
 * Visor paginado inspirado en el comportamiento del lector de Drive.
 *
 * Las páginas se mantienen como superficies completas: el gesto de zoom cambia el ancho
 * de la superficie, no el tamaño individual del texto. El control derecho permite saltar
 * rápidamente por documentos largos sin renderizar todas las páginas a la vez.
 */
@Composable
private fun DrivePagedSurface(
    viewerKey: String,
    pageCount: Int,
    background: Color,
    resetViewToken: Int = 0,
    jumpToPage: Int? = null,
    jumpRequestKey: Any? = null,
    minZoom: Float = 1f,
    maxZoom: Float = 2.25f,
    renderDebounceMillis: Long = 100L,
    renderScaleMultiplier: Float = 1.35f,
    maxRasterWidth: Int = viewerMaxRasterWidth(),
    neighborRasterWidth: Int? = null,
    fixedRasterWidth: Int? = null,
    showFastScrollHandle: Boolean = true,
    onCurrentPageChanged: (Int) -> Unit = {},
    onTap: () -> Unit = {},
    pageContent: @Composable (
        pageIndex: Int,
        renderWidth: Int,
        pageWidth: androidx.compose.ui.unit.Dp,
        highQualityEnabled: Boolean
    ) -> Unit
) {
    val listState = rememberLazyListState()

    // Una sola geometria visual permanente. Antes el visor hacia zoom por GPU durante
    // el pellizco y al soltar cambiaba el tamano real de todas las paginas. Ese cambio
    // de sistema dejaba uno o dos frames con el fondo expuesto (flash/marco negro).
    // Ahora scale + pan siguen siendo la verdad visual tambien despues de soltar.
    val zoomState = remember(viewerKey) { mutableFloatStateOf(1f) }
    val panXState = remember(viewerKey) { mutableFloatStateOf(0f) }
    val panYState = remember(viewerKey) { mutableFloatStateOf(0f) }
    var zoom by zoomState
    var panX by panXState
    var panY by panYState
    var renderZoom by remember(viewerKey) { mutableFloatStateOf(1f) }
    var transforming by remember(viewerKey) { mutableStateOf(false) }
    var highQualityEnabled by remember(viewerKey) { mutableStateOf(true) }
    var renderRequestSerial by remember(viewerKey) { mutableIntStateOf(0) }

    var scrubbing by remember { mutableStateOf(false) }
    var scrubPage by remember { mutableIntStateOf(0) }
    var fastScrollVisible by remember(viewerKey) { mutableStateOf(true) }
    val fastScrollAlpha by animateFloatAsState(
        targetValue = if (fastScrollVisible || scrubbing) 1f else 0f,
        animationSpec = tween(durationMillis = 170),
        label = "driveFastScrollAlpha"
    )

    val currentPageIndex by remember(pageCount) {
        derivedStateOf {
            if (pageCount <= 0) 0 else {
                val viewportStart = listState.layoutInfo.viewportStartOffset
                val viewportEnd = listState.layoutInfo.viewportEndOffset
                val best = listState.layoutInfo.visibleItemsInfo.maxByOrNull { item ->
                    val visibleStart = maxOf(item.offset, viewportStart)
                    val visibleEnd = minOf(item.offset + item.size, viewportEnd)
                    (visibleEnd - visibleStart).coerceAtLeast(0)
                }
                (best?.index ?: listState.firstVisibleItemIndex).coerceIn(0, pageCount - 1)
            }
        }
    }

    LaunchedEffect(currentPageIndex, pageCount) {
        if (pageCount > 0) onCurrentPageChanged(currentPageIndex)
    }

    LaunchedEffect(listState.isScrollInProgress, scrubbing, viewerKey) {
        if (listState.isScrollInProgress || scrubbing) {
            fastScrollVisible = true
        } else {
            delay(1300L)
            fastScrollVisible = false
        }
    }

    // Nitidez desacoplada de la geometria: el gesto nunca espera al render. Cuando los
    // dedos se estabilizan se pide una superficie mas grande y se sustituye en el mismo
    // sitio, sin cambiar el tamano visual ni resetear la matriz.
    LaunchedEffect(renderRequestSerial, viewerKey) {
        if (renderRequestSerial > 0) {
            delay(renderDebounceMillis.coerceAtLeast(0L))
            if (!transforming && !listState.isScrollInProgress && !scrubbing) {
                renderZoom = zoom
                highQualityEnabled = true
            }
        }
    }

    LaunchedEffect(listState.isScrollInProgress, scrubbing, viewerKey) {
        if (listState.isScrollInProgress || scrubbing) {
            // Cancela inmediatamente los renders grandes al navegar. La textura que ya
            // esta en pantalla se conserva; solo se detiene trabajo que ya no aporta.
            highQualityEnabled = false
        } else if (!transforming) {
            delay(renderDebounceMillis.coerceAtLeast(0L))
            if (!listState.isScrollInProgress && !scrubbing && !transforming) {
                renderZoom = zoom
                highQualityEnabled = true
            }
        }
    }

    LaunchedEffect(resetViewToken) {
        zoom = 1f.coerceIn(minZoom, maxZoom)
        renderZoom = zoom
        panX = 0f
        panY = 0f
        transforming = false
        highQualityEnabled = true
        renderRequestSerial = 0
        listState.requestScrollToItem(0, 0)
    }

    LaunchedEffect(jumpRequestKey, jumpToPage, pageCount) {
        val target = jumpToPage
        if (target != null && pageCount > 0) {
            listState.animateScrollToItem(target.coerceIn(0, pageCount - 1))
        }
    }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(background)
    ) {
        if (pageCount <= 0) return@BoxWithConstraints

        val density = LocalDensity.current
        val viewportWidthPx = with(density) { maxWidth.toPx() }
        val viewportHeightPx = with(density) { maxHeight.toPx() }
        val basePageWidth = (maxWidth - 8.dp).coerceAtLeast(180.dp)
        val basePageWidthPx = with(density) { basePageWidth.toPx() }
        val pageSpacing = 5.dp
        val pagePadding = 4.dp
        val desiredRenderWidth = (basePageWidthPx * renderZoom * renderScaleMultiplier).roundToInt()
        val quantizedRenderWidth = ((desiredRenderWidth + 127) / 128) * 128
        val dynamicRenderWidth = quantizedRenderWidth.coerceIn(960, maxRasterWidth.coerceAtLeast(960))
        val renderWidth = fixedRasterWidth?.coerceIn(960, maxRasterWidth.coerceAtLeast(960))
            ?: dynamicRenderWidth
        val allowHighQuality = highQualityEnabled && !listState.isScrollInProgress && !scrubbing

        fun clampPanX(value: Float, scale: Float): Float {
            val extra = (viewportWidthPx * (scale - 1f)).coerceAtLeast(0f)
            return if (extra <= 0.5f) 0f else value.coerceIn(-extra, 0f)
        }

        fun clampPanY(value: Float, scale: Float): Float {
            val extra = (viewportHeightPx * (scale - 1f)).coerceAtLeast(0f)
            return if (extra <= 0.5f) 0f else value.coerceIn(-extra, 0f)
        }

        // Si cambia el tamano del viewport (rotacion/insets), nunca dejamos el contenido
        // fuera de los limites permitidos.
        LaunchedEffect(viewportWidthPx, viewportHeightPx) {
            panX = clampPanX(panX, zoom)
            panY = clampPanY(panY, zoom)
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .viewerPinchZoomGestures(
                    gestureKey = viewerKey,
                    zoomState = zoomState,
                    panXState = panXState,
                    panYState = panYState,
                    minZoom = minZoom,
                    maxZoom = maxZoom,
                    viewportWidthPx = viewportWidthPx,
                    viewportHeightPx = viewportHeightPx,
                    onTransformStarted = {
                        transforming = true
                        highQualityEnabled = false
                    },
                    onTransformFinished = {
                        // Exactamente el mismo fin de gesto que ya usaba el visor:
                        // no se confirma/recalcula la geometría; solo se pide nitidez nueva.
                        transforming = false
                        highQualityEnabled = false
                        renderRequestSerial++
                    }
                )
                .pointerInput(viewerKey, minZoom, maxZoom, viewportWidthPx) {
                    detectHorizontalDragGestures { change, dragAmount ->
                        if (!transforming && zoom > minZoom + 0.001f) {
                            panX = clampPanX(panX + dragAmount, zoom)
                            change.consume()
                        }
                    }
                }
                .pointerInput(viewerKey, minZoom, maxZoom, viewportWidthPx, viewportHeightPx) {
                    detectTapGestures(
                        onTap = { onTap() },
                        onDoubleTap = { offset ->
                            val oldZoom = zoom.coerceIn(minZoom, maxZoom)
                            val newZoom = if (oldZoom > minZoom + 0.12f) {
                                minZoom
                            } else {
                                1.9f.coerceIn(minZoom, maxZoom)
                            }
                            val factor = newZoom / oldZoom.coerceAtLeast(0.001f)
                            val nextX = panX * factor + offset.x * (1f - factor)
                            val nextY = panY * factor + offset.y * (1f - factor)
                            zoom = newZoom
                            panX = clampPanX(nextX, newZoom)
                            panY = clampPanY(nextY, newZoom)
                            transforming = false
                            highQualityEnabled = false
                            renderRequestSerial++
                        }
                    )
                }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = zoom
                        scaleY = zoom
                        translationX = panX
                        translationY = panY
                    }
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = pagePadding, vertical = pagePadding),
                    verticalArrangement = Arrangement.spacedBy(pageSpacing)
                ) {
                    items(
                        count = pageCount,
                        key = { index -> "${viewerKey}_page_$index" },
                        contentType = { "drive_page" }
                    ) { index ->
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            val pageRenderWidth = if (neighborRasterWidth != null && index != currentPageIndex) {
                                minOf(renderWidth, neighborRasterWidth.coerceAtLeast(720))
                            } else {
                                renderWidth
                            }
                            val pageHighQuality = allowHighQuality &&
                                (neighborRasterWidth == null || index == currentPageIndex)
                            pageContent(index, pageRenderWidth, basePageWidth, pageHighQuality)
                        }
                    }
                }
            }
        }

        if (showFastScrollHandle) {
            val shownPage = if (scrubbing) scrubPage else currentPageIndex
            val progress = if (pageCount <= 1) 0f else shownPage.toFloat() / (pageCount - 1).toFloat()

            SixDotFastScrollHandle(
                progress = progress,
                visibleAlpha = fastScrollAlpha,
                label = if (scrubbing) "${shownPage + 1}/$pageCount" else null,
                key = "$viewerKey|$pageCount",
                onDragStart = {
                    scrubbing = true
                    scrubPage = currentPageIndex
                    fastScrollVisible = true
                },
                onFractionChanged = { fraction ->
                    val target = if (pageCount <= 1) 0 else {
                        (fraction * (pageCount - 1)).roundToInt().coerceIn(0, pageCount - 1)
                    }
                    if (target != scrubPage) {
                        scrubPage = target
                        listState.requestScrollToItem(target, 0)
                    }
                },
                onDragEnd = {
                    listState.requestScrollToItem(scrubPage.coerceIn(0, pageCount - 1), 0)
                    scrubbing = false
                }
            )
        }
    }
}

@Composable
private fun SixDotFastScrollHandle(
    progress: Float,
    visibleAlpha: Float,
    label: String?,
    key: Any?,
    onDragStart: () -> Unit,
    onFractionChanged: (Float) -> Unit,
    onDragEnd: () -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 8.dp, bottom = 10.dp)
    ) {
        val handleHeight = 52.dp
        val handleWidth = 30.dp
        val travel = (maxHeight - handleHeight).coerceAtLeast(0.dp)
        val travelPx = with(LocalDensity.current) { travel.toPx() }
        val safeProgress = progress.coerceIn(0f, 1f)
        val latestProgress = androidx.compose.runtime.rememberUpdatedState(safeProgress)

        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(y = travel * safeProgress)
                .height(handleHeight)
                .padding(end = 3.dp)
                .graphicsLayer { alpha = visibleAlpha },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (label != null) {
                Surface(
                    color = Color.White.copy(alpha = 0.97f),
                    contentColor = Color(0xFF303134),
                    shape = RoundedCornerShape(16.dp),
                    shadowElevation = 3.dp
                ) {
                    Text(
                        text = label,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .width(handleWidth)
                    .height(handleHeight)
                    .pointerInput(key, travelPx) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            onDragStart()
                            down.consume()
                            var handleY = latestProgress.value * travelPx
                            var previousY = down.position.y
                            do {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                if (change.pressed) {
                                    val deltaY = change.position.y - previousY
                                    previousY = change.position.y
                                    handleY = (handleY + deltaY).coerceIn(0f, travelPx)
                                    val fraction = if (travelPx <= 0f) 0f else handleY / travelPx
                                    onFractionChanged(fraction.coerceIn(0f, 1f))
                                    change.consume()
                                }
                            } while (event.changes.any { it.pressed })
                            onDragEnd()
                        }
                    },
                color = Color.White.copy(alpha = 0.97f),
                shape = RoundedCornerShape(topStart = 13.dp, bottomStart = 13.dp),
                shadowElevation = 3.dp
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    repeat(3) { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(3.5.dp)) {
                            repeat(2) {
                                Box(
                                    Modifier.size(4.25.dp)
                                        .background(Color(0xFF5F6368), RoundedCornerShape(2.dp))
                                )
                            }
                        }
                        if (row < 2) Spacer(Modifier.height(3.5.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfOverview(
    uri: Uri,
    localPdfPath: String?,
    engine: PdfRenderEngine,
    pageCount: Int,
    onSelectPage: (Int) -> Unit,
    onMessage: (String) -> Unit
) {
    val rowCount = (pageCount + 2) / 3
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF171717)),
        contentPadding = PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(count = rowCount, key = { "pdf_overview_row_$it" }) { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                repeat(3) { column ->
                    val pageIndex = row * 3 + column
                    if (pageIndex < pageCount) {
                        PdfThumbnail(
                            uri = uri,
                            localPdfPath = localPdfPath,
                            engine = engine,
                            pageIndex = pageIndex,
                            modifier = Modifier.weight(1f),
                            onClick = { onSelectPage(pageIndex) },
                            onMessage = onMessage
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfThumbnail(
    uri: Uri,
    localPdfPath: String?,
    engine: PdfRenderEngine,
    pageIndex: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var bitmap by remember(localPdfPath, pageIndex) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(localPdfPath, pageIndex) {
        runCatching {
            if (localPdfPath != null) {
                renderLocalPdfPage(File(localPdfPath), pageIndex, maxWidth = 360, engine = engine)
            } else {
                ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = 360)
            }
        }.recoverCatching { error ->
            if (error is kotlinx.coroutines.CancellationException) throw error
            ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = 360)
        }.onSuccess { fresh ->
            val previous = bitmap
            bitmap = fresh
            previous?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure { error ->
            if (error !is kotlinx.coroutines.CancellationException) {
                onMessage(error.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
            }
        }
    }

    DisposableEffect(localPdfPath, pageIndex) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    Column(
        modifier = modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            val current = bitmap
            if (current != null) {
                Image(
                    bitmap = current.asImageBitmap(),
                    contentDescription = "Página ${pageIndex + 1}",
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = NeonGreen,
                        strokeWidth = 2.dp
                    )
                }
            }
        }
        Text(
            "${pageIndex + 1}",
            color = Color.White.copy(alpha = 0.78f),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun ContinuousPdfPage(
    uri: Uri,
    localPdfPath: String?,
    engine: PdfRenderEngine,
    pageIndex: Int,
    renderWidth: Int,
    highQualityEnabled: Boolean,
    modifier: Modifier = Modifier,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val sourceKey = localPdfPath ?: uri.toString()
    val previewWidth = minOf(560, renderWidth)
    val cacheKey = remember(sourceKey, pageIndex, renderWidth) {
        "pdf|$sourceKey|$pageIndex|$renderWidth"
    }
    val previewKey = remember(sourceKey, pageIndex, previewWidth) {
        "pdf|$sourceKey|$pageIndex|$previewWidth"
    }
    var bitmap by remember(sourceKey, pageIndex) {
        mutableStateOf(ViewerBitmapCache.get(cacheKey) ?: ViewerBitmapCache.get(previewKey))
    }
    var pageRatio by remember(sourceKey, pageIndex) {
        val initial = bitmap
        mutableFloatStateOf(
            initial?.let { it.width.toFloat() / it.height.toFloat().coerceAtLeast(1f) } ?: 0.7071f
        )
    }
    var pageRatioLocked by remember(sourceKey, pageIndex) { mutableStateOf(bitmap != null) }

    LaunchedEffect(uri, localPdfPath, pageIndex, renderWidth, highQualityEnabled) {
        suspend fun renderAt(width: Int): Bitmap {
            return if (localPdfPath != null) {
                renderLocalPdfPage(File(localPdfPath), pageIndex, maxWidth = width, engine = engine)
            } else {
                ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = width)
            }
        }

        try {
            if ((bitmap?.width ?: 0) >= renderWidth) return@LaunchedEffect
            ViewerBitmapCache.get(cacheKey)?.let { cached ->
                if (!pageRatioLocked) {
                    pageRatio = cached.width.toFloat() / cached.height.toFloat().coerceAtLeast(1f)
                    pageRatioLocked = true
                }
                val shown = bitmap
                if (shown == null || cached.width >= shown.width) bitmap = cached
                return@LaunchedEffect
            }

            // Al pellizcar/arrastrar no se crea otra pagina gigante. Si aun no hay nada
            // visible, solo se permite una previsualizacion pequena y barata.
            if (!highQualityEnabled) {
                if (bitmap == null) {
                    ViewerBitmapCache.get(previewKey)?.let { preview ->
                        if (!pageRatioLocked) {
                            pageRatio = preview.width.toFloat() / preview.height.toFloat().coerceAtLeast(1f)
                            pageRatioLocked = true
                        }
                        bitmap = preview
                        return@LaunchedEffect
                    }
                    val preview = renderAt(previewWidth)
                    val stored = ViewerBitmapCache.put(previewKey, preview)
                    if (!pageRatioLocked) {
                        pageRatio = stored.width.toFloat() / stored.height.toFloat().coerceAtLeast(1f)
                        pageRatioLocked = true
                    }
                    bitmap = stored
                }
                return@LaunchedEffect
            }

            if (bitmap == null && ViewerBitmapCache.get(previewKey) == null && previewWidth < renderWidth) {
                val preview = renderAt(previewWidth)
                val storedPreview = ViewerBitmapCache.put(previewKey, preview)
                if (!pageRatioLocked) {
                    pageRatio = storedPreview.width.toFloat() / storedPreview.height.toFloat().coerceAtLeast(1f)
                    pageRatioLocked = true
                }
                bitmap = storedPreview
                currentCoroutineContext().ensureActive()
            }
            val full = renderAt(renderWidth)
            val storedFull = ViewerBitmapCache.put(cacheKey, full)
            if (!pageRatioLocked) {
                pageRatio = storedFull.width.toFloat() / storedFull.height.toFloat().coerceAtLeast(1f)
                pageRatioLocked = true
            }
            bitmap = storedFull
        } catch (error: kotlinx.coroutines.CancellationException) {
            throw error
        } catch (error: Throwable) {
            onMessage(error.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
        }
    }

    val current = bitmap
    Box(
        modifier = modifier
            .aspectRatio(pageRatio)
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = "Página ${pageIndex + 1}",
                contentScale = ContentScale.FillBounds,
                filterQuality = FilterQuality.Medium,
                modifier = Modifier.fillMaxSize().background(Color.White)
            )
        }
    }
}

private fun ensureViewerWorkerThreadActive(error: Throwable? = null) {
    if (error is kotlinx.coroutines.CancellationException) throw error
    val interrupted = Thread.currentThread().isInterrupted ||
        error is InterruptedException || error is java.io.InterruptedIOException
    if (interrupted) {
        throw kotlinx.coroutines.CancellationException("Trabajo del visor cancelado").also { cancellation ->
            if (error != null) runCatching { cancellation.initCause(error) }
        }
    }
}

private suspend fun copyPdfToViewerCache(context: android.content.Context, source: Uri): File =
    withContext(Dispatchers.IO) {
        val directory = File(context.cacheDir, "pdf_viewer").apply { mkdirs() }
        directory.listFiles()?.forEach { old ->
            if (System.currentTimeMillis() - old.lastModified() > 6 * 60 * 60 * 1000L) {
                PdfSessionRegistry.close(old.absolutePath)
                runCatching { old.delete() }
            }
        }
        val file = File(
            directory,
            "viewer_${System.currentTimeMillis()}_${kotlin.random.Random.nextInt(1000, 9999)}.pdf"
        )
        try {
            runInterruptible {
                // Para SAF/Drive el InputStream secuencial es mas compatible que asumir que
                // el FileDescriptor remoto es seekable. PdfRenderer se usa despues sobre
                // nuestra copia local real.
                val copiedFromStream = try {
                    context.contentResolver.openInputStream(source)?.buffered(256 * 1024)?.use { input ->
                        FileOutputStream(file).buffered(256 * 1024).use { output ->
                            val buffer = ByteArray(256 * 1024)
                            while (true) {
                                ensureViewerWorkerThreadActive()
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                            }
                            output.flush()
                        }
                        true
                    } ?: false
                } catch (error: Throwable) {
                    ensureViewerWorkerThreadActive(error)
                    false
                }
                ensureViewerWorkerThreadActive()

                if (!copiedFromStream || file.length() <= 0L) {
                    runCatching { file.delete() }
                    val cancellationSignal = CancellationSignal()
                    val copiedFromDescriptor = context.contentResolver
                        .openFileDescriptor(source, "r", cancellationSignal)?.use { descriptor ->
                            FileInputStream(descriptor.fileDescriptor).buffered(256 * 1024).use { input ->
                                FileOutputStream(file).buffered(256 * 1024).use { output ->
                                    val buffer = ByteArray(256 * 1024)
                                    while (true) {
                                        ensureViewerWorkerThreadActive()
                                        val count = input.read(buffer)
                                        if (count < 0) break
                                        output.write(buffer, 0, count)
                                    }
                                    output.flush()
                                }
                            }
                            true
                        } ?: false
                    require(copiedFromDescriptor) { "No se pudo leer el archivo seleccionado." }
                }
            }
            require(file.length() > 0L) { "El archivo PDF esta vacio." }
            file
        } catch (error: Throwable) {
            PdfSessionRegistry.close(file.absolutePath)
            runCatching { file.delete() }
            throw error
        }
    }

private enum class PdfRenderEngine { ANDROID, PDFBOX }
private data class PdfOpenInfo(val engine: PdfRenderEngine, val pageCount: Int)

/**
 * Mantiene el documento abierto durante toda la vida del visor. La v10.0.58 reabria el
 * PDF completo por cada pagina, lo que multiplicaba I/O y parsing al hacer scroll.
 */
private class PdfViewerSession private constructor(
    private val file: File,
    val engine: PdfRenderEngine,
    val pageCount: Int,
    private var descriptor: ParcelFileDescriptor?,
    private var androidRenderer: AndroidPdfRenderer?,
    private var pdfBoxDocument: PDDocument?
) : Closeable {
    private val renderLock = Any()
    private var preferPdfBox = false

    fun render(pageIndex: Int, requestedWidth: Int): Bitmap = synchronized(renderLock) {
        if (Thread.currentThread().isInterrupted) throw InterruptedException("Render cancelado")
        require(pageIndex in 0 until pageCount) { "La pagina indicada no existe." }
        when (engine) {
            PdfRenderEngine.ANDROID -> {
                if (preferPdfBox) {
                    renderWithPdfBox(pageIndex, requestedWidth)
                } else {
                    runCatching { renderWithAndroid(pageIndex, requestedWidth) }.getOrElse {
                        preferPdfBox = true
                        renderWithPdfBox(pageIndex, requestedWidth)
                    }
                }
            }
            PdfRenderEngine.PDFBOX -> renderWithPdfBox(pageIndex, requestedWidth)
        }
    }

    private fun renderWithAndroid(pageIndex: Int, requestedWidth: Int): Bitmap {
        val renderer = androidRenderer ?: error("PdfRenderer no esta disponible.")
        renderer.openPage(pageIndex).use { page ->
            val sourceWidth = page.width.coerceAtLeast(1)
            val sourceHeight = page.height.coerceAtLeast(1)
            var width = min(requestedWidth.coerceIn(520, viewerMaxRasterWidth()), sourceWidth * 6)
                .coerceAtLeast(320)
            var height = (width.toFloat() / sourceWidth.toFloat() * sourceHeight.toFloat())
                .roundToInt()
                .coerceAtLeast(320)
            val pixels = width.toLong() * height.toLong()
            val maxPixels = viewerMaxPdfPixels()
            if (pixels > maxPixels) {
                val scale = sqrt(maxPixels.toDouble() / pixels.toDouble()).toFloat()
                width = (width * scale).roundToInt().coerceAtLeast(1)
                height = (height * scale).roundToInt().coerceAtLeast(1)
            }
            return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
                eraseColor(AndroidColor.WHITE)
                page.render(this, null, null, AndroidPdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            }
        }
    }

    private fun renderWithPdfBox(pageIndex: Int, requestedWidth: Int): Bitmap {
        val document = pdfBoxDocument ?: PDDocument.load(file).also { pdfBoxDocument = it }
        require(pageIndex in 0 until document.numberOfPages) { "La pagina indicada no existe." }
        val page = document.getPage(pageIndex)
        val pageWidth = page.cropBox.width.coerceAtLeast(1f)
        val pageHeight = page.cropBox.height.coerceAtLeast(1f)
        var targetWidth = requestedWidth.coerceIn(520, viewerMaxRasterWidth())
        var targetHeight = (targetWidth.toFloat() / pageWidth * pageHeight).roundToInt().coerceAtLeast(1)
        val pixels = targetWidth.toLong() * targetHeight.toLong()
        val maxPixels = viewerMaxPdfPixels()
        if (pixels > maxPixels) {
            val reduce = sqrt(maxPixels.toDouble() / pixels.toDouble()).toFloat()
            targetWidth = (targetWidth * reduce).roundToInt().coerceAtLeast(1)
            targetHeight = (targetHeight * reduce).roundToInt().coerceAtLeast(1)
        }
        val scale = (targetWidth.toFloat() / pageWidth).coerceIn(0.75f, 6f)
        val bitmap = PdfBoxRenderer(document).renderImage(pageIndex, scale)
        if (bitmap.width == targetWidth && kotlin.math.abs(bitmap.height - targetHeight) <= 2) return bitmap
        val finalW = minOf(bitmap.width, targetWidth).coerceAtLeast(1)
        val finalH = (finalW.toFloat() / bitmap.width.toFloat().coerceAtLeast(1f) * bitmap.height.toFloat())
            .roundToInt()
            .coerceAtLeast(1)
        if (finalW == bitmap.width && finalH == bitmap.height) return bitmap
        val scaled = Bitmap.createScaledBitmap(bitmap, finalW, finalH, true)
        if (scaled !== bitmap && !bitmap.isRecycled) bitmap.recycle()
        return scaled
    }

    override fun close() {
        synchronized(renderLock) {
            runCatching { pdfBoxDocument?.close() }
            pdfBoxDocument = null
            runCatching { androidRenderer?.close() }
            androidRenderer = null
            runCatching { descriptor?.close() }
            descriptor = null
        }
    }

    companion object {
        fun open(file: File): PdfViewerSession {
            require(file.exists() && file.length() > 0L) { "El PDF no esta disponible." }

            val androidAttempt = runCatching {
                val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                try {
                    val renderer = AndroidPdfRenderer(descriptor)
                    require(renderer.pageCount > 0) { "El PDF no contiene paginas." }
                    PdfViewerSession(
                        file = file,
                        engine = PdfRenderEngine.ANDROID,
                        pageCount = renderer.pageCount,
                        descriptor = descriptor,
                        androidRenderer = renderer,
                        pdfBoxDocument = null
                    )
                } catch (error: Throwable) {
                    runCatching { descriptor.close() }
                    throw error
                }
            }
            androidAttempt.getOrNull()?.let { return it }

            val pdfBoxAttempt = runCatching {
                val document = PDDocument.load(file)
                require(document.numberOfPages > 0) { "El PDF no contiene paginas." }
                PdfViewerSession(
                    file = file,
                    engine = PdfRenderEngine.PDFBOX,
                    pageCount = document.numberOfPages,
                    descriptor = null,
                    androidRenderer = null,
                    pdfBoxDocument = document
                )
            }
            return pdfBoxAttempt.getOrElse { pdfBoxError ->
                val androidMessage = androidAttempt.exceptionOrNull()?.message.orEmpty()
                val pdfBoxMessage = pdfBoxError.message.orEmpty()
                error(
                    listOf(androidMessage, pdfBoxMessage)
                        .filter { it.isNotBlank() }
                        .distinct()
                        .joinToString(" · ")
                        .ifBlank { "No se pudo interpretar este PDF." }
                )
            }
        }
    }
}

private object PdfSessionRegistry {
    private val sessions = linkedMapOf<String, PdfViewerSession>()

    @Synchronized
    fun open(file: File): PdfViewerSession {
        close(file.absolutePath)
        return PdfViewerSession.open(file).also { sessions[file.absolutePath] = it }
    }

    @Synchronized
    fun getOrOpen(file: File): PdfViewerSession {
        return sessions[file.absolutePath] ?: PdfViewerSession.open(file).also {
            sessions[file.absolutePath] = it
        }
    }

    @Synchronized
    fun close(path: String) {
        sessions.remove(path)?.close()
    }
}

private suspend fun detectLocalPdf(file: File): PdfOpenInfo = runInterruptible(Dispatchers.IO) {
    try {
        val session = PdfSessionRegistry.open(file)
        PdfOpenInfo(session.engine, session.pageCount)
    } catch (error: Throwable) {
        PdfSessionRegistry.close(file.absolutePath)
        throw error
    }
}

private suspend fun renderLocalPdfPage(
    file: File,
    pageIndex: Int,
    maxWidth: Int,
    engine: PdfRenderEngine
): Bitmap = runInterruptible(Dispatchers.IO) {
    val session = PdfSessionRegistry.getOrOpen(file)
    if (Thread.currentThread().isInterrupted) throw InterruptedException("Render cancelado")
    // engine se conserva en la firma para no romper llamadas existentes; la sesion es la
    // fuente de verdad y puede caer automaticamente de PdfRenderer a PDFBox por pagina.
    @Suppress("UNUSED_VARIABLE") val requestedEngine = engine
    session.render(pageIndex, maxWidth)
}

enum class OfficeViewerType(val label: String, val extensions: String, val mimeTypes: Array<String>) {
    WORD("Word", "DOCX", arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")),
    EXCEL("Excel", "XLSX", arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")),
    POWERPOINT("PowerPoint", "PPTX", arrayOf("application/vnd.openxmlformats-officedocument.presentationml.presentation"))
}

private enum class ViewerRecentKind(
    val storageKey: String,
    val typeLabel: String,
    val extensions: Set<String>,
    val mimeTypes: Set<String>,
    val accent: Color
) {
    PDF(
        storageKey = "pdf",
        typeLabel = "PDF",
        extensions = setOf("pdf"),
        mimeTypes = setOf("application/pdf"),
        accent = Color(0xFFD93025)
    ),
    WORD(
        storageKey = "word",
        typeLabel = "DOCX",
        extensions = setOf("docx"),
        mimeTypes = setOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
        accent = Color(0xFF2B579A)
    ),
    EXCEL(
        storageKey = "excel",
        typeLabel = "XLSX",
        extensions = setOf("xlsx"),
        mimeTypes = setOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
        accent = Color(0xFF217346)
    ),
    POWERPOINT(
        storageKey = "powerpoint",
        typeLabel = "PPTX",
        extensions = setOf("pptx"),
        mimeTypes = setOf("application/vnd.openxmlformats-officedocument.presentationml.presentation"),
        accent = Color(0xFFD24726)
    );

    fun accepts(name: String, mimeType: String?): Boolean {
        val extension = name.substringAfterLast('.', "").lowercase()
        val normalizedMime = mimeType?.lowercase()?.substringBefore(';')?.trim()
        return extension in extensions || normalizedMime in mimeTypes
    }
}

private fun OfficeViewerType.recentKind(): ViewerRecentKind = when (this) {
    OfficeViewerType.WORD -> ViewerRecentKind.WORD
    OfficeViewerType.EXCEL -> ViewerRecentKind.EXCEL
    OfficeViewerType.POWERPOINT -> ViewerRecentKind.POWERPOINT
}

private data class ViewerRecentFile(
    val uri: Uri,
    val displayName: String,
    val mimeType: String?,
    val sizeBytes: Long,
    val modifiedMillis: Long,
    val lastOpenedMillis: Long = 0L
) {
    val sortMillis: Long get() = maxOf(lastOpenedMillis, modifiedMillis)
}

private const val VIEWER_RECENT_PREFS = "viewer_recent_files_v1"
private const val VIEWER_RECENT_LIMIT = 15

private fun rememberViewerRecentFile(context: Context, kind: ViewerRecentKind, uri: Uri) {
    runCatching {
        val prefs = context.getSharedPreferences(VIEWER_RECENT_PREFS, Context.MODE_PRIVATE)
        val current = runCatching { JSONArray(prefs.getString(kind.storageKey, "[]") ?: "[]") }
            .getOrElse { JSONArray() }
        val output = JSONArray()
        output.put(
            JSONObject()
                .put("uri", uri.toString())
                .put("opened", System.currentTimeMillis())
        )
        var added = 1
        for (index in 0 until current.length()) {
            if (added >= VIEWER_RECENT_LIMIT) break
            val item = current.optJSONObject(index) ?: continue
            val storedUri = item.optString("uri")
            if (storedUri.isBlank() || storedUri == uri.toString()) continue
            output.put(item)
            added++
        }
        prefs.edit().putString(kind.storageKey, output.toString()).apply()
    }
}

private fun viewerRecentMetadata(
    context: Context,
    kind: ViewerRecentKind,
    uri: Uri,
    lastOpenedMillis: Long = 0L
): ViewerRecentFile? = runCatching {
    val resolver = context.contentResolver
    val displayName = runCatching { ToolFileUtils.displayName(context, uri) }
        .getOrElse { uri.lastPathSegment ?: kind.typeLabel }
    val mimeType = runCatching { resolver.getType(uri) }.getOrNull()
    if (!kind.accepts(displayName, mimeType)) return@runCatching null
    val size = runCatching { ToolFileUtils.fileSize(context, uri) }.getOrDefault(0L)
    val modified = runCatching {
        androidx.documentfile.provider.DocumentFile.fromSingleUri(context, uri)?.lastModified() ?: 0L
    }.getOrDefault(0L)
    ViewerRecentFile(
        uri = uri,
        displayName = displayName,
        mimeType = mimeType,
        sizeBytes = size,
        modifiedMillis = modified,
        lastOpenedMillis = lastOpenedMillis
    )
}.getOrNull()

private suspend fun loadViewerRecentFiles(
    context: Context,
    kind: ViewerRecentKind
): List<ViewerRecentFile> = withContext(Dispatchers.IO) {
    val files = linkedMapOf<String, ViewerRecentFile>()
    fun add(item: ViewerRecentFile?) {
        if (item == null) return
        val key = item.uri.toString()
        val previous = files[key]
        if (previous == null || item.sortMillis > previous.sortMillis) files[key] = item
    }

    // Primero: historial propio. Estas URI vienen del selector SAF y conservan permiso,
    // por lo que son la fuente mas estable en Android moderno.
    val prefs = context.getSharedPreferences(VIEWER_RECENT_PREFS, Context.MODE_PRIVATE)
    val stored = runCatching { JSONArray(prefs.getString(kind.storageKey, "[]") ?: "[]") }
        .getOrElse { JSONArray() }
    for (index in 0 until stored.length()) {
        val obj = stored.optJSONObject(index) ?: continue
        val uri = runCatching { Uri.parse(obj.optString("uri")) }.getOrNull() ?: continue
        add(viewerRecentMetadata(context, kind, uri, obj.optLong("opened", 0L)))
    }

    // Segundo: permisos persistentes que ya tiene Gana Geo. Esto recupera archivos que
    // fueron elegidos antes incluso si aun no estaban en nuestro historial local.
    runCatching {
        context.contentResolver.persistedUriPermissions
            .asSequence()
            .filter { it.isReadPermission }
            .forEach { permission ->
                add(viewerRecentMetadata(context, kind, permission.uri))
            }
    }

    // Tercero: intentamos leer la coleccion de archivos del dispositivo. Android puede
    // limitar los documentos de otras apps por Scoped Storage; por eso esta consulta es
    // deliberadamente best-effort y nunca solicita MANAGE_EXTERNAL_STORAGE.
    runCatching {
        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Files.getContentUri("external")
        }
        val columns = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.SIZE
        )
        val selection = kind.mimeTypes.joinToString(" OR ") {
            "${MediaStore.MediaColumns.MIME_TYPE}=?"
        }
        resolver.query(
            collection,
            columns,
            selection,
            kind.mimeTypes.toTypedArray(),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
            val modifiedCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
            val sizeCol = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)
            var count = 0
            while (cursor.moveToNext() && count < VIEWER_RECENT_LIMIT) {
                val name = cursor.getString(nameCol) ?: continue
                val mime = if (mimeCol >= 0 && !cursor.isNull(mimeCol)) cursor.getString(mimeCol) else null
                if (!kind.accepts(name, mime)) continue
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                val modified = if (modifiedCol >= 0 && !cursor.isNull(modifiedCol)) cursor.getLong(modifiedCol) * 1000L else 0L
                val size = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
                add(ViewerRecentFile(uri, name, mime, size, modified))
                count++
            }
        }
    }

    files.values
        .sortedWith(compareByDescending<ViewerRecentFile> { it.sortMillis }.thenBy { it.displayName.lowercase() })
        .take(VIEWER_RECENT_LIMIT)
}

private fun formatViewerRecentDate(value: Long): String {
    if (value <= 0L) return "Reciente"
    return runCatching {
        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(value))
    }.getOrDefault("Reciente")
}

@Composable
private fun ViewerRecentFilesSection(
    kind: ViewerRecentKind,
    files: List<ViewerRecentFile>,
    loading: Boolean,
    modifier: Modifier = Modifier,
    onOpen: (ViewerRecentFile) -> Unit,
    onRefresh: () -> Unit
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Archivos recientes",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onRefresh) {
                Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar recientes")
            }
        }

        when {
            loading -> Box(Modifier.fillMaxWidth().height(86.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NeonGreen, modifier = Modifier.size(26.dp))
            }
            files.isEmpty() -> Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    "Aún no hay ${kind.typeLabel} recientes accesibles. Abre uno y aparecerá aquí.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            else -> LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(files, key = { it.uri.toString() }) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(item) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(width = 52.dp, height = 58.dp)
                                    .background(kind.accent.copy(alpha = 0.14f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    kind.typeLabel,
                                    color = kind.accent,
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    item.displayName,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    "${formatViewerRecentDate(item.sortMillis)} · ${ToolFileUtils.readableSize(item.sizeBytes)}",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(Icons.Rounded.FolderOpen, contentDescription = "Abrir ${item.displayName}", tint = kind.accent)
                        }
                    }
                }
            }
        }
    }
}

private sealed interface OfficeDocumentModel

private data class WordPageGeometry(
    val widthTwips: Int = 11906,
    val heightTwips: Int = 16838,
    val marginLeftTwips: Int = 900,
    val marginRightTwips: Int = 900,
    val marginTopTwips: Int = 900,
    val marginBottomTwips: Int = 900
) {
    val aspectRatio: Float
        get() = widthTwips.toFloat().coerceAtLeast(1f) / heightTwips.toFloat().coerceAtLeast(1f)
    val widthEmu: Long
        get() = widthTwips.toLong().coerceAtLeast(1L) * 635L
    val heightEmu: Long
        get() = heightTwips.toLong().coerceAtLeast(1L) * 635L
}

private data class WordDocumentModel(
    val pages: List<WordPageModel>,
    val geometry: WordPageGeometry = WordPageGeometry()
) : OfficeDocumentModel
private data class WordPageModel(val blocks: List<WordBlockModel>)
private sealed interface WordBlockModel {
    data class Paragraph(val text: String) : WordBlockModel
    data class Picture(
        val entryName: String,
        val widthEmu: Long? = null,
        val heightEmu: Long? = null
    ) : WordBlockModel
    data class Table(val rows: List<List<String>>) : WordBlockModel
}

private data class ExcelWorkbookModel(
    val sharedStrings: List<String>,
    val sheets: List<ExcelSheetRef>,
    val styles: List<ExcelCellStyleModel>
) : OfficeDocumentModel
private data class ExcelSheetRef(val name: String, val entryName: String)
private data class ExcelSheetData(
    val rows: Map<Int, ExcelRowData>,
    val maxColumns: Int,
    val maxRows: Int,
    val columnWidths: Map<Int, Float>,
    val totalRowsHint: Int = maxRows,
    val isComplete: Boolean = true
)
private data class ExcelRowData(
    val rowNumber: Int,
    val cells: Map<Int, ExcelCellData>,
    val heightPoints: Float? = null
)
private data class ExcelCellData(val value: String, val styleIndex: Int)
private data class ExcelCellStyleModel(
    val fillArgb: Int? = null,
    val textArgb: Int? = null,
    val bold: Boolean = false,
    val fontSizePt: Float? = null,
    val horizontal: String? = null,
    val numberFormatCode: String? = null
)

private data class PowerPointDeckModel(
    val widthEmu: Long,
    val heightEmu: Long,
    val slides: List<PowerPointSlideModel>
) : OfficeDocumentModel
private data class PowerPointSlideModel(
    val elements: List<PowerPointElementModel>,
    val transition: PowerPointTransitionModel?,
    val advanceAfterMs: Long?,
    val backgroundArgb: Int? = null
)
private data class PowerPointTransitionModel(
    val type: String,
    val direction: String? = null,
    val orientation: String? = null,
    val durationMs: Int = 900,
    val durationExplicit: Boolean = false,
    val spokes: Int? = null,
    // Conservamos todos los atributos del elemento concreto de transicion. PowerPoint
    // agrega parametros distintos segun el efecto (dir, orient, spokes, thruBlk, prst,
    // option, etc.). Guardarlos evita perder informacion al abrir PPTX nuevos.
    val parameters: Map<String, String> = emptyMap()
)
private sealed interface PowerPointElementModel {
    val x: Long
    val y: Long
    val width: Long
    val height: Long

    data class TextBox(
        val text: String,
        val textArgb: Int?,
        val fontSizePt: Float?,
        val bold: Boolean,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel

    data class Rectangle(
        val fillArgb: Int,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel

    data class Picture(
        val entryName: String,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel
}

@Composable
fun OfficeViewerScreen(
    tool: ToolId,
    type: OfficeViewerType,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    var uriText by remember { mutableStateOf<String?>(null) }
    val uri = remember(uriText) {
        uriText?.takeIf { it.isNotBlank() }?.let { stored -> runCatching { Uri.parse(stored) }.getOrNull() }
    }
    var localPath by remember { mutableStateOf<String?>(null) }
    var model by remember { mutableStateOf<OfficeDocumentModel?>(null) }
    var loading by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var retryToken by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var searchVisible by remember { mutableStateOf(false) }
    var inverted by remember { mutableStateOf(false) }
    var presenting by remember { mutableStateOf(false) }
    var presentationStart by remember { mutableIntStateOf(0) }
    var powerPointCurrentSlide by remember { mutableIntStateOf(0) }
    var resetViewToken by remember { mutableIntStateOf(0) }
    val recentKind = type.recentKind()
    var recentFiles by remember(type) { mutableStateOf<List<ViewerRecentFile>>(emptyList()) }
    var recentLoading by remember(type) { mutableStateOf(false) }
    var recentRefreshToken by remember(type) { mutableIntStateOf(0) }

    fun selectOfficeFile(selected: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                selected,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        rememberViewerRecentFile(context, recentKind, selected)
        localPath?.let { old ->
            ViewerBitmapCache.clearPrefix("word|$old")
            ViewerBitmapCache.clearPrefix("ppt|$old")
            runCatching { File(old).delete() }
        }
        localPath = null
        model = null
        loading = true
        loadError = null
        query = ""
        presenting = false
        powerPointCurrentSlide = 0
        uriText = selected.toString()
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        selected?.let(::selectOfficeFile)
    }

    LaunchedEffect(uriText, recentRefreshToken, type) {
        if (uri == null) {
            recentLoading = true
            recentFiles = runCatching { loadViewerRecentFiles(context, recentKind) }
                .getOrDefault(emptyList())
            recentLoading = false
        }
    }

    LaunchedEffect(uriText, retryToken) {
        val selected = uri ?: run {
            onImmersiveChanged(false)
            return@LaunchedEffect
        }
        onImmersiveChanged(true)
        loading = true
        loadError = null
        model = null
        val previous = localPath
        var attemptedCopy: File? = null
        val result = runCatching {
            val copy = kotlinx.coroutines.withTimeout(25000L) {
                copyOfficeToViewerCache(context, selected, type)
            }
            attemptedCopy = copy
            val parsed = kotlinx.coroutines.withTimeout(30000L) {
                runInterruptible(Dispatchers.IO) {
                    when (type) {
                        OfficeViewerType.WORD -> parseDocxModel(copy)
                        OfficeViewerType.EXCEL -> parseXlsxWorkbook(copy)
                        OfficeViewerType.POWERPOINT -> parsePptxDeck(copy)
                    }
                }
            }
            copy to parsed
        }
        result.exceptionOrNull()?.let { error ->
            if (error is kotlinx.coroutines.CancellationException &&
                error !is kotlinx.coroutines.TimeoutCancellationException
            ) {
                attemptedCopy?.let { cancelled -> runCatching { cancelled.delete() } }
                throw error
            }
        }
        result.onSuccess { (copy, parsed) ->
            previous?.takeIf { it != copy.absolutePath }?.let { runCatching { File(it).delete() } }
            localPath = copy.absolutePath
            model = parsed
        }.onFailure { error ->
            attemptedCopy?.let { failed -> runCatching { failed.delete() } }
            localPath = null
            model = null
            if (error is SecurityException || error is java.io.FileNotFoundException) {
                // Una URI restaurada puede perder permiso despues de reiniciar el telefono o
                // cambiar el proveedor. No dejamos que ese estado viejo cierre el visor.
                uriText = null
                loadError = null
                onImmersiveChanged(false)
            } else {
                loadError = if (error is kotlinx.coroutines.TimeoutCancellationException) {
                    "El archivo tardo demasiado en responder. Vuelve a intentarlo."
                } else error.message ?: "No se pudo abrir el archivo ${type.extensions}."
            }
        }
        loading = false
    }

    DisposableEffect(Unit) {
        onDispose {
            onImmersiveChanged(false)
            localPath?.let { path ->
                ViewerBitmapCache.clearPrefix("word|$path")
                ViewerBitmapCache.clearPrefix("ppt|$path")
                runCatching { File(path).delete() }
            }
        }
    }

    androidx.activity.compose.BackHandler(enabled = presenting) { presenting = false }

    if (uri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Visor gratuito ${type.extensions} · sin edición", onBack)
            Card(
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Ningún archivo seleccionado", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { launcher.launch(type.mimeTypes) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                        Text(" Abrir ${type.label}")
                    }
                    Text(
                        when (type) {
                            OfficeViewerType.WORD -> "Vista por páginas, zoom, búsqueda e invertir colores."
                            OfficeViewerType.EXCEL -> "Hojas, cuadrícula, zoom, búsqueda e invertir colores."
                            OfficeViewerType.POWERPOINT -> "Diapositivas, zoom, búsqueda, invertir colores y modo Presentar."
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            ViewerRecentFilesSection(
                kind = recentKind,
                files = recentFiles,
                loading = recentLoading,
                modifier = Modifier.weight(1f),
                onOpen = { selectOfficeFile(it.uri) },
                onRefresh = { recentRefreshToken++ }
            )
        }
        return
    }

    val fileName = remember(uriText, uri) {
        runCatching { ToolFileUtils.displayName(context, uri) }
            .getOrElse { uri.lastPathSegment ?: "archivo" }
    }
    val path = localPath
    val currentModel = model

    if (presenting && type == OfficeViewerType.POWERPOINT && path != null && currentModel is PowerPointDeckModel && currentModel.slides.isNotEmpty()) {
        PowerPointPresentation(
            localPath = path,
            deck = currentModel,
            initialSlide = presentationStart,
            inverted = inverted,
            onExit = { presenting = false }
        )
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF121212))
    ) {
        OfficeViewerTopBar(
            fileName = fileName,
            type = type,
            onBack = onBack,
            onOpen = { launcher.launch(type.mimeTypes) }
        )

        if (searchVisible) {
            ViewerSearchBar(
                query = query,
                onQueryChange = { query = it.take(120) },
                onClose = { query = ""; searchVisible = false }
            )
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when {
                loading -> ViewerLoading("Abriendo ${type.label}…")
                loadError != null || path == null || currentModel == null -> ViewerLoadError(
                    message = loadError ?: "No se pudo leer el archivo.",
                    onRetry = { retryToken++ },
                    onChooseOther = { launcher.launch(type.mimeTypes) }
                )
                type == OfficeViewerType.WORD && currentModel is WordDocumentModel -> WordDocumentViewer(
                    localPath = path,
                    document = currentModel,
                    query = query,
                    inverted = inverted,
                    resetViewToken = resetViewToken,
                    onMessage = onMessage
                )
                type == OfficeViewerType.EXCEL && currentModel is ExcelWorkbookModel -> ExcelWorkbookViewer(
                    localPath = path,
                    workbook = currentModel,
                    query = query,
                    inverted = inverted,
                    resetViewToken = resetViewToken,
                    onMessage = onMessage
                )
                type == OfficeViewerType.POWERPOINT && currentModel is PowerPointDeckModel -> PowerPointDeckViewer(
                    localPath = path,
                    deck = currentModel,
                    query = query,
                    inverted = inverted,
                    resetViewToken = resetViewToken,
                    onMessage = onMessage,
                    onCurrentSlideChanged = { powerPointCurrentSlide = it }
                )
            }
        }

        OfficeViewerBottomBar(
            type = type,
            inverted = inverted,
            onOpen = { launcher.launch(type.mimeTypes) },
            onSearch = { searchVisible = !searchVisible },
            onInvert = { inverted = !inverted },
            onShare = { shareDocumentFile(context, uri, type.mimeTypes.first()) },
            onResetView = { resetViewToken++ },
            onPresent = if (type == OfficeViewerType.POWERPOINT && currentModel is PowerPointDeckModel && currentModel.slides.isNotEmpty()) {
                { presentationStart = powerPointCurrentSlide; presenting = true }
            } else null
        )
    }
}


@Composable
internal fun DocumentEditorViewerSurface(
    formatName: String,
    sourceUriText: String,
    modifier: Modifier = Modifier,
    onMessage: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val uri = remember(sourceUriText) {
        sourceUriText.takeIf { it.isNotBlank() }?.let { runCatching { Uri.parse(it) }.getOrNull() }
    }
    var localPath by remember(sourceUriText, formatName) { mutableStateOf<String?>(null) }
    var officeModel by remember(sourceUriText, formatName) { mutableStateOf<OfficeDocumentModel?>(null) }
    var pdfPageCount by remember(sourceUriText, formatName) { mutableIntStateOf(0) }
    var pdfEngine by remember(sourceUriText, formatName) { mutableStateOf<PdfRenderEngine?>(null) }
    var loading by remember(sourceUriText, formatName) { mutableStateOf(true) }
    var error by remember(sourceUriText, formatName) { mutableStateOf<String?>(null) }

    val officeType = remember(formatName) {
        when (formatName.uppercase()) {
            "WORD" -> OfficeViewerType.WORD
            "EXCEL" -> OfficeViewerType.EXCEL
            "POWERPOINT" -> OfficeViewerType.POWERPOINT
            else -> null
        }
    }

    LaunchedEffect(sourceUriText, formatName) {
        val selected = uri ?: run {
            loading = false
            error = "No hay archivo original disponible."
            return@LaunchedEffect
        }
        loading = true
        error = null
        officeModel = null
        pdfPageCount = 0
        pdfEngine = null
        localPath?.let { old ->
            ViewerBitmapCache.clearPrefix("word|$old")
            ViewerBitmapCache.clearPrefix("ppt|$old")
            ViewerBitmapCache.clearPrefix("pdf|$old")
            PdfSessionRegistry.close(old)
            runCatching { File(old).delete() }
        }
        localPath = null

        try {
            if (formatName.equals("PDF", true)) {
                PDFBoxResourceLoader.init(context.applicationContext)
                val copy = kotlinx.coroutines.withTimeout(25000L) { copyPdfToViewerCache(context, selected) }
                val info = kotlinx.coroutines.withTimeout(20000L) { detectLocalPdf(copy) }
                require(info.pageCount > 0) { "El PDF no contiene páginas." }
                localPath = copy.absolutePath
                pdfPageCount = info.pageCount
                pdfEngine = info.engine
            } else {
                val type = officeType ?: kotlin.error("Formato no compatible con el visor.")
                val copy = kotlinx.coroutines.withTimeout(25000L) { copyOfficeToViewerCache(context, selected, type) }
                val parsed = kotlinx.coroutines.withTimeout(30000L) {
                    runInterruptible(Dispatchers.IO) {
                        when (type) {
                            OfficeViewerType.WORD -> parseDocxModel(copy)
                            OfficeViewerType.EXCEL -> parseXlsxWorkbook(copy)
                            OfficeViewerType.POWERPOINT -> parsePptxDeck(copy)
                        }
                    }
                }
                localPath = copy.absolutePath
                officeModel = parsed
            }
        } catch (failure: Throwable) {
            if (failure is kotlinx.coroutines.CancellationException &&
                failure !is kotlinx.coroutines.TimeoutCancellationException
            ) {
                throw failure
            }
            error = failure.message ?: "No se pudo cargar la vista original."
            onMessage(error!!)
        }
        loading = false
    }

    DisposableEffect(sourceUriText, formatName) {
        onDispose {
            localPath?.let { path ->
                ViewerBitmapCache.clearPrefix("word|$path")
                ViewerBitmapCache.clearPrefix("ppt|$path")
                ViewerBitmapCache.clearPrefix("pdf|$path")
                PdfSessionRegistry.close(path)
                runCatching { File(path).delete() }
            }
        }
    }

    Box(modifier = modifier.background(Color(0xFF121212))) {
        when {
            loading -> ViewerLoading("Cargando vista original…")
            error != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(error.orEmpty(), color = Color.White.copy(alpha = 0.75f), modifier = Modifier.padding(18.dp))
            }
            formatName.equals("PDF", true) && uri != null && localPath != null && pdfEngine != null && pdfPageCount > 0 -> {
                DrivePagedSurface(
                    viewerKey = "editor_pdf_${sourceUriText}",
                    pageCount = pdfPageCount,
                    background = Color(0xFF121212),
                    minZoom = 1f,
                    maxZoom = 2.5f,
                    renderDebounceMillis = 240L,
                    renderScaleMultiplier = 1.15f,
                    maxRasterWidth = minOf(2400, viewerMaxRasterWidth()),
                    neighborRasterWidth = 1100,
                    showFastScrollHandle = false,
                    pageContent = { index, renderWidth, pageWidth, highQualityEnabled ->
                        ContinuousPdfPage(
                            uri = uri,
                            localPdfPath = localPath,
                            engine = pdfEngine!!,
                            pageIndex = index,
                            renderWidth = renderWidth,
                            highQualityEnabled = highQualityEnabled,
                            modifier = Modifier.width(pageWidth),
                            onMessage = onMessage
                        )
                    }
                )
            }
            officeType == OfficeViewerType.WORD && localPath != null && officeModel is WordDocumentModel -> {
                WordDocumentViewer(
                    localPath = localPath!!,
                    document = officeModel as WordDocumentModel,
                    query = "",
                    inverted = false,
                    resetViewToken = 0,
                    onMessage = onMessage
                )
            }
            officeType == OfficeViewerType.EXCEL && localPath != null && officeModel is ExcelWorkbookModel -> {
                ExcelWorkbookViewer(
                    localPath = localPath!!,
                    workbook = officeModel as ExcelWorkbookModel,
                    query = "",
                    inverted = false,
                    resetViewToken = 0,
                    onMessage = onMessage
                )
            }
            officeType == OfficeViewerType.POWERPOINT && localPath != null && officeModel is PowerPointDeckModel -> {
                PowerPointDeckViewer(
                    localPath = localPath!!,
                    deck = officeModel as PowerPointDeckModel,
                    query = "",
                    inverted = false,
                    resetViewToken = 0,
                    onMessage = onMessage,
                    onCurrentSlideChanged = {}
                )
            }
            else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Vista original no disponible", color = Color.White.copy(alpha = 0.7f))
            }
        }
    }
}

@Composable
private fun OfficeViewerTopBar(
    fileName: String,
    type: OfficeViewerType,
    onBack: () -> Unit,
    onOpen: () -> Unit
) {
    val chromeColor = if (type == OfficeViewerType.EXCEL) Color(0xFF217346) else Color(0xFF202124)
    Surface(
        modifier = Modifier.fillMaxWidth().statusBarsPadding(),
        color = chromeColor,
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(54.dp).padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = Color.White)
            }
            Text(
                fileName,
                modifier = Modifier.weight(1f),
                color = Color.White,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = onOpen) {
                Icon(Icons.Rounded.FolderOpen, contentDescription = "Cambiar ${type.label}", tint = Color.White)
            }
        }
    }
}

@Composable
private fun OfficeViewerBottomBar(
    type: OfficeViewerType,
    inverted: Boolean,
    onOpen: () -> Unit,
    onSearch: () -> Unit,
    onInvert: () -> Unit,
    onShare: () -> Unit,
    onResetView: () -> Unit,
    onPresent: (() -> Unit)?
) {
    val chromeColor = if (type == OfficeViewerType.EXCEL) Color(0xFF217346) else Color(0xFF202124)
    Surface(
        modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
        color = chromeColor,
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            when (type) {
                OfficeViewerType.WORD -> {
                    ViewerBottomAction(
                        icon = Icons.Rounded.ViewAgenda,
                        label = "Vertical",
                        selected = true,
                        onClick = onResetView
                    )
                }
                OfficeViewerType.EXCEL -> Unit
                OfficeViewerType.POWERPOINT -> if (onPresent != null) {
                    ViewerBottomAction(
                        icon = Icons.Rounded.Slideshow,
                        label = "Presentar",
                        selected = false,
                        onClick = onPresent
                    )
                }
            }
            ViewerBottomAction(Icons.Rounded.Search, "Buscar", false, onSearch)
            ViewerBottomAction(Icons.Rounded.InvertColors, "Invertir", inverted, onInvert)
            ViewerBottomAction(Icons.Rounded.Share, "Compartir", false, onShare)
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.ViewerBottomAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier.weight(1f).fillMaxHeight().clickable(onClick = onClick).padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (selected) NeonGreen else Color.White.copy(alpha = 0.88f),
            modifier = Modifier.size(20.dp)
        )
        Text(
            label,
            color = if (selected) NeonGreen else Color.White.copy(alpha = 0.82f),
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1
        )
    }
}

@Composable
private fun ViewerSearchBar(query: String, onQueryChange: (String) -> Unit, onClose: () -> Unit) {
    Surface(color = Color(0xFF292A2D), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Buscar en el archivo") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = "Cerrar búsqueda", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ViewerLoading(label: String) {
    Box(Modifier.fillMaxSize().background(Color(0xFF121212)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = NeonGreen)
            Spacer(Modifier.height(12.dp))
            Text(label, color = Color.White.copy(alpha = 0.78f))
        }
    }
}

@Composable
private fun ViewerLoadError(message: String, onRetry: () -> Unit, onChooseOther: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xFF121212)).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202124)), shape = RoundedCornerShape(20.dp)) {
            Column(
                Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("No se pudo abrir el archivo", color = Color.White, fontWeight = FontWeight.Bold)
                Text(message, color = Color.White.copy(alpha = 0.72f))
                OutlinedButton(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text("Reintentar") }
                OutlinedButton(onClick = onChooseOther, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                    Text(" Elegir otro archivo")
                }
            }
        }
    }
}

@Composable
private fun WordDocumentViewer(
    localPath: String,
    document: WordDocumentModel,
    query: String,
    inverted: Boolean,
    resetViewToken: Int,
    onMessage: (String) -> Unit
) {
    val matchingPages = remember(document, query) {
        if (query.isBlank()) emptySet()
        else document.pages.mapIndexedNotNull { index, page ->
            if (page.blocks.any { block -> wordBlockContains(block, query) }) index else null
        }.toSet()
    }
    val jumpTarget = matchingPages.minOrNull()

    DrivePagedSurface(
        viewerKey = "word_$localPath",
        pageCount = document.pages.size,
        background = if (inverted) Color.Black else Color(0xFF303030),
        resetViewToken = resetViewToken,
        jumpToPage = jumpTarget,
        jumpRequestKey = query,
        minZoom = 1f,
        maxZoom = 2.5f,
        renderDebounceMillis = 260L,
        renderScaleMultiplier = 1.15f,
        maxRasterWidth = minOf(2400, viewerMaxRasterWidth()),
        neighborRasterWidth = 1050,
        pageContent = { index, renderWidth, pageWidth, highQualityEnabled ->
            WordRenderedPage(
                localPath = localPath,
                page = document.pages[index],
                geometry = document.geometry,
                inverted = inverted,
                matched = index in matchingPages,
                renderWidth = renderWidth,
                highQualityEnabled = highQualityEnabled,
                modifier = Modifier.width(pageWidth),
                onMessage = onMessage
            )
        }
    )
}

@Composable
private fun WordPageCard(
    localPath: String,
    page: WordPageModel,
    inverted: Boolean,
    matched: Boolean,
    modifier: Modifier = Modifier,
    onMessage: (String) -> Unit
) {
    val pageColor = if (inverted) Color(0xFF111111) else Color.White
    val textColor = if (inverted) Color(0xFFF1F1F1) else Color(0xFF181818)
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(1.dp))
            .background(pageColor)
            .then(if (matched) Modifier.border(2.dp, NeonGreen) else Modifier)
            .padding(horizontal = 26.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        page.blocks.forEach { block ->
            when (block) {
                is WordBlockModel.Paragraph -> if (block.text.isNotBlank()) {
                    Text(
                        block.text,
                        color = textColor,
                        fontSize = 10.5.sp,
                        lineHeight = 14.2.sp
                    )
                }
                is WordBlockModel.Picture -> OfficeZipImage(
                    localPath = localPath,
                    entryName = block.entryName,
                    inverted = inverted,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 210.dp),
                    onMessage = onMessage
                )
                is WordBlockModel.Table -> WordTableBlock(block, inverted)
            }
        }
    }
}

@Composable
private fun WordTableBlock(table: WordBlockModel.Table, inverted: Boolean) {
    val fg = if (inverted) Color(0xFFF1F1F1) else Color(0xFF202124)
    val grid = if (inverted) Color(0xFF686868) else Color(0xFFB7B7B7)
    Column(Modifier.fillMaxWidth().border(0.7.dp, grid)) {
        table.rows.take(20).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                if (row.isEmpty()) {
                    Box(Modifier.weight(1f).height(24.dp).border(0.5.dp, grid))
                } else {
                    row.forEach { cell ->
                        Box(
                            Modifier.weight(1f)
                                .heightIn(min = 24.dp)
                                .border(0.5.dp, grid)
                                .padding(4.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                cell,
                                color = fg,
                                fontSize = 8.5.sp,
                                lineHeight = 11.sp,
                                maxLines = 4,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun wordBlockContains(block: WordBlockModel, query: String): Boolean = when (block) {
    is WordBlockModel.Paragraph -> block.text.contains(query, true)
    is WordBlockModel.Picture -> false
    is WordBlockModel.Table -> block.rows.any { row -> row.any { it.contains(query, true) } }
}


@Composable
private fun WordRenderedPage(
    localPath: String,
    page: WordPageModel,
    geometry: WordPageGeometry,
    inverted: Boolean,
    matched: Boolean,
    renderWidth: Int,
    highQualityEnabled: Boolean,
    modifier: Modifier = Modifier,
    onMessage: (String) -> Unit
) {
    val stableRenderWidth = renderWidth.coerceIn(900, viewerMaxRasterWidth())
    val previewWidth = minOf(720, stableRenderWidth)
    val cacheKey = remember(localPath, page, geometry, inverted, stableRenderWidth) {
        "word|$localPath|${page.hashCode()}|${geometry.hashCode()}|$inverted|$stableRenderWidth"
    }
    val previewKey = remember(localPath, page, geometry, inverted) {
        "word|$localPath|${page.hashCode()}|${geometry.hashCode()}|$inverted|$previewWidth"
    }
    var bitmap by remember(localPath, page, geometry, inverted) {
        mutableStateOf(ViewerBitmapCache.get(cacheKey) ?: ViewerBitmapCache.get(previewKey))
    }

    LaunchedEffect(localPath, page, geometry, inverted, stableRenderWidth, highQualityEnabled) {
        try {
            if ((bitmap?.width ?: 0) >= stableRenderWidth) return@LaunchedEffect
            ViewerBitmapCache.get(cacheKey)?.let { cached ->
                val shown = bitmap
                if (shown == null || cached.width >= shown.width) bitmap = cached
                return@LaunchedEffect
            }
            if (!highQualityEnabled) {
                if (bitmap == null) {
                    ViewerBitmapCache.get(previewKey)?.let { preview ->
                        bitmap = preview
                        return@LaunchedEffect
                    }
                    val preview = runInterruptible(Dispatchers.IO) {
                        renderWordPageBitmap(File(localPath), page, geometry, previewWidth, inverted)
                    }
                    bitmap = ViewerBitmapCache.put(previewKey, preview)
                }
                return@LaunchedEffect
            }
            if (bitmap == null && ViewerBitmapCache.get(previewKey) == null) {
                val preview = runInterruptible(Dispatchers.IO) {
                    renderWordPageBitmap(File(localPath), page, geometry, previewWidth, inverted)
                }
                bitmap = ViewerBitmapCache.put(previewKey, preview)
                currentCoroutineContext().ensureActive()
            }
            val full = runInterruptible(Dispatchers.IO) {
                renderWordPageBitmap(File(localPath), page, geometry, stableRenderWidth, inverted)
            }
            bitmap = ViewerBitmapCache.put(cacheKey, full)
        } catch (error: kotlinx.coroutines.CancellationException) {
            throw error
        } catch (error: Throwable) {
            onMessage(error.message ?: "No se pudo renderizar una página de Word.")
        }
    }

    Box(
        modifier = modifier
            .aspectRatio(geometry.aspectRatio.coerceIn(0.35f, 2.5f))
            .background(if (inverted) Color(0xFF111111) else Color.White)
            .then(if (matched) Modifier.border(2.dp, NeonGreen) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        val current = bitmap
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                filterQuality = FilterQuality.Medium,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private fun renderWordPageBitmap(
    file: File,
    page: WordPageModel,
    geometry: WordPageGeometry,
    requestedWidth: Int,
    inverted: Boolean
): Bitmap {
    val width = requestedWidth.coerceIn(600, viewerMaxRasterWidth())
    val pageAspect = geometry.aspectRatio.coerceIn(0.35f, 2.5f)
    val height = (width.toFloat() / pageAspect).roundToInt().coerceAtLeast(1)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    val background = if (inverted) AndroidColor.rgb(18, 18, 18) else AndroidColor.WHITE
    val foreground = if (inverted) AndroidColor.rgb(238, 238, 238) else AndroidColor.rgb(28, 28, 28)
    val gridColor = if (inverted) AndroidColor.rgb(100, 100, 100) else AndroidColor.rgb(175, 175, 175)
    canvas.drawColor(background)

    // La pagina se maqueta SIEMPRE en el mismo sistema logico. 720/1050/2400 px
    // solamente cambian la densidad de raster, nunca saltos de linea ni posiciones.
    val logicalWidth = 1200f
    val logicalHeight = logicalWidth / pageAspect
    val rasterScale = width.toFloat() / logicalWidth
    canvas.save()
    canvas.scale(rasterScale, rasterScale)

    val safePageWidthTwips = geometry.widthTwips.coerceAtLeast(1).toFloat()
    val safePageHeightTwips = geometry.heightTwips.coerceAtLeast(1).toFloat()
    val leftMargin = (logicalWidth * geometry.marginLeftTwips.coerceAtLeast(0) / safePageWidthTwips)
        .coerceIn(logicalWidth * 0.025f, logicalWidth * 0.24f)
    val rightMargin = (logicalWidth * geometry.marginRightTwips.coerceAtLeast(0) / safePageWidthTwips)
        .coerceIn(logicalWidth * 0.025f, logicalWidth * 0.24f)
    val topMargin = (logicalHeight * geometry.marginTopTwips.coerceAtLeast(0) / safePageHeightTwips)
        .coerceIn(logicalHeight * 0.02f, logicalHeight * 0.20f)
    val bottomMargin = (logicalHeight * geometry.marginBottomTwips.coerceAtLeast(0) / safePageHeightTwips)
        .coerceIn(logicalHeight * 0.02f, logicalHeight * 0.20f)
    val contentWidth = (logicalWidth - leftMargin - rightMargin).roundToInt().coerceAtLeast(1)
    val bottom = logicalHeight - bottomMargin
    var y = topMargin

    val paragraphPaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.SUBPIXEL_TEXT_FLAG).apply {
        color = foreground
        textSize = logicalWidth * 0.0215f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.NORMAL)
    }
    val tablePaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.SUBPIXEL_TEXT_FLAG).apply {
        color = foreground
        textSize = logicalWidth * 0.0155f
    }
    val linePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = gridColor
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = (logicalWidth / 1000f).coerceAtLeast(1f)
    }
    val imagePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG).apply {
        if (inverted) colorFilter = android.graphics.ColorMatrixColorFilter(
            android.graphics.ColorMatrix(
                floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }

    java.util.zip.ZipFile(file).use { zip ->
        for (block in page.blocks) {
            if (Thread.currentThread().isInterrupted) throw InterruptedException("Render cancelado")
            if (y >= bottom) break
            when (block) {
                is WordBlockModel.Paragraph -> {
                    val text = block.text.trim()
                    if (text.isNotEmpty()) {
                        val layout = buildStaticLayout(text, paragraphPaint, contentWidth)
                        if (y + layout.height > bottom) break
                        canvas.save()
                        canvas.translate(leftMargin, y)
                        layout.draw(canvas)
                        canvas.restore()
                        y += layout.height + logicalWidth * 0.010f
                    }
                }
                is WordBlockModel.Picture -> {
                    val image = runCatching { decodeOfficeZipBitmap(zip, block.entryName) }.getOrNull()
                    if (image != null) {
                        val availableHeight = (bottom - y).coerceAtLeast(1f)
                        val extentW = block.widthEmu?.takeIf { it > 0L }
                        val extentH = block.heightEmu?.takeIf { it > 0L }
                        val hasWordExtent = extentW != null && extentH != null

                        val desiredW: Float
                        val desiredH: Float
                        if (hasWordExtent) {
                            desiredW = (logicalWidth * extentW!!.toDouble() / geometry.widthEmu.toDouble().coerceAtLeast(1.0))
                                .toFloat().coerceAtLeast(1f)
                            desiredH = (logicalHeight * extentH!!.toDouble() / geometry.heightEmu.toDouble().coerceAtLeast(1.0))
                                .toFloat().coerceAtLeast(1f)
                        } else {
                            // Compatibilidad con DOCX antiguos/VML sin wp:extent. Las imagenes
                            // grandes tipo pagina pueden usar todo el ancho; iconos pequenos no.
                            val pageLike = image.width >= 700 && image.height >= 850 && image.height > image.width
                            val fallbackW = if (pageLike) contentWidth.toFloat() else minOf(contentWidth.toFloat(), logicalWidth * 0.62f)
                            desiredW = fallbackW.coerceAtLeast(1f)
                            desiredH = desiredW * image.height.toFloat() / image.width.toFloat().coerceAtLeast(1f)
                        }

                        val fit = minOf(
                            1f,
                            contentWidth.toFloat() / desiredW.coerceAtLeast(1f),
                            availableHeight / desiredH.coerceAtLeast(1f)
                        )
                        val drawW = (desiredW * fit).coerceAtLeast(1f)
                        val drawH = (desiredH * fit).coerceAtLeast(1f)
                        val left = leftMargin + (contentWidth - drawW) / 2f
                        val dst = android.graphics.RectF(left, y, left + drawW, y + drawH)
                        canvas.drawBitmap(image, null, dst, imagePaint)
                        if (!image.isRecycled) image.recycle()
                        y += drawH + logicalWidth * 0.012f
                    }
                }
                is WordBlockModel.Table -> {
                    val rows = block.rows.take(24)
                    if (rows.isNotEmpty()) {
                        val columns = rows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
                        val cellWidth = contentWidth.toFloat() / columns
                        val rowHeight = (logicalWidth * 0.038f).coerceAtLeast(22f)
                        for (row in rows) {
                            if (y + rowHeight > bottom) break
                            for (column in 0 until columns) {
                                val left = leftMargin + column * cellWidth
                                val rect = android.graphics.RectF(left, y, left + cellWidth, y + rowHeight)
                                canvas.drawRect(rect, linePaint)
                                val cellText = row.getOrNull(column).orEmpty()
                                if (cellText.isNotBlank()) {
                                    val available = (cellWidth - logicalWidth * 0.010f).roundToInt().coerceAtLeast(1)
                                    val layout = buildStaticLayout(cellText, tablePaint, available, maxLines = 2)
                                    canvas.save()
                                    canvas.clipRect(rect)
                                    canvas.translate(left + logicalWidth * 0.005f, y + logicalWidth * 0.004f)
                                    layout.draw(canvas)
                                    canvas.restore()
                                }
                            }
                            y += rowHeight
                        }
                        y += logicalWidth * 0.012f
                    }
                }
            }
        }
    }
    canvas.restore()
    return bitmap
}

private fun buildStaticLayout(
    text: String,
    paint: android.text.TextPaint,
    width: Int,
    maxLines: Int = Int.MAX_VALUE
): android.text.StaticLayout {
    return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
        android.text.StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(1))
            .setAlignment(android.text.Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.08f)
            .setMaxLines(maxLines)
            .setEllipsize(if (maxLines == Int.MAX_VALUE) null else android.text.TextUtils.TruncateAt.END)
            .build()
    } else {
        @Suppress("DEPRECATION")
        android.text.StaticLayout(
            text,
            paint,
            width.coerceAtLeast(1),
            android.text.Layout.Alignment.ALIGN_NORMAL,
            1.08f,
            0f,
            false
        )
    }
}

@Composable
private fun ExcelWorkbookViewer(
    localPath: String,
    workbook: ExcelWorkbookModel,
    query: String,
    inverted: Boolean,
    resetViewToken: Int,
    onMessage: (String) -> Unit
) {
    var selectedSheet by remember(localPath) { mutableIntStateOf(0) }
    var sheetData by remember(localPath, selectedSheet) { mutableStateOf<ExcelSheetData?>(null) }
    var loadingSheet by remember(localPath, selectedSheet) { mutableStateOf(true) }
    var loadingMore by remember(localPath, selectedSheet) { mutableStateOf(false) }
    var loadedRowLimit by remember(localPath, selectedSheet) { mutableIntStateOf(0) }
    var sheetError by remember(localPath, selectedSheet) { mutableStateOf<String?>(null) }
    val sheetCache = remember(localPath) { mutableMapOf<Int, Pair<Int, ExcelSheetData>>() }
    val listState = rememberLazyListState()
    val horizontalState = rememberScrollState()
    val density = LocalDensity.current
    var selectedCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var zoom by remember(localPath) { mutableFloatStateOf(1f) }
    var panX by remember(localPath) { mutableFloatStateOf(0f) }
    var panY by remember(localPath) { mutableFloatStateOf(0f) }
    var transforming by remember(localPath) { mutableStateOf(false) }
    // Excel no usa el fast-scroll de seis puntos: la hoja se navega directamente
    // con sus barras/gestos, como una hoja de calculo normal.
    val minZoom = 1f
    val maxZoom = 2.5f

    LaunchedEffect(workbook.sheets.size) {
        if (workbook.sheets.isNotEmpty() && selectedSheet !in workbook.sheets.indices) {
            selectedSheet = 0
        }
    }

    LaunchedEffect(resetViewToken) {
        zoom = 1f
        panX = 0f
        panY = 0f
        transforming = false
        horizontalState.scrollTo(0)
        listState.requestScrollToItem(0)
    }

    LaunchedEffect(localPath, selectedSheet) {
        if (workbook.sheets.isEmpty()) {
            loadingSheet = false
            sheetError = "El archivo no contiene hojas."
            sheetData = null
            return@LaunchedEffect
        }
        val safeSheet = selectedSheet.coerceIn(workbook.sheets.indices)
        if (safeSheet != selectedSheet) {
            selectedSheet = safeSheet
            return@LaunchedEffect
        }

        loadingSheet = true
        loadingMore = false
        loadedRowLimit = 0
        sheetError = null
        sheetData = null
        horizontalState.scrollTo(0)

        val cached = sheetCache[safeSheet]
        if (cached != null) {
            loadedRowLimit = cached.first
            sheetData = cached.second
            loadingSheet = false
            // La LazyColumn no existe mientras se muestra "Cargando hoja". Esta API no
            // suspende: deja pedido el destino para el siguiente layout y no puede bloquear.
            listState.requestScrollToItem(0, 0)
            return@LaunchedEffect
        }

        var loadedSuccessfully = false
        try {
            val firstLimit = 100
            val initial = kotlinx.coroutines.withTimeout(15000L) {
                withContext(Dispatchers.IO) {
                    parseXlsxSheet(
                        File(localPath),
                        workbook.sheets[safeSheet],
                        workbook.sharedStrings,
                        workbook.styles,
                        rowLimit = firstLimit
                    )
                }
            }
            sheetData = initial
            loadedRowLimit = firstLimit
            sheetCache[safeSheet] = firstLimit to initial
            loadedSuccessfully = true
        } catch (error: Throwable) {
            sheetError = if (error is kotlinx.coroutines.TimeoutCancellationException) {
                "La hoja tardo demasiado en abrir."
            } else error.message ?: "No se pudo leer esta hoja."
            onMessage(sheetError!!)
        } finally {
            loadingSheet = false
        }
        if (loadedSuccessfully) {
            listState.requestScrollToItem(0, 0)
        }
    }

    // Carga progresiva: al acercarse al final de lo ya leido se trae el siguiente
    // bloque de filas sin bloquear el desplazamiento de la hoja.
    LaunchedEffect(localPath, selectedSheet, listState) {
        androidx.compose.runtime.snapshotFlow {
            listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
        }.collect { lastVisibleIndex ->
            val current = sheetData ?: return@collect
            if (loadingSheet || loadingMore || current.isComplete || workbook.sheets.isEmpty()) return@collect
            val safeSheet = selectedSheet.coerceIn(workbook.sheets.indices)
            val lastVisibleRow = lastVisibleIndex + 1
            if (lastVisibleRow < loadedRowLimit - 30) return@collect

            val totalHint = current.totalRowsHint.coerceAtLeast(current.maxRows)
            val nextLimit = maxOf(loadedRowLimit * 2, loadedRowLimit + 500, lastVisibleRow + 300)
                .coerceAtMost(totalHint.coerceAtLeast(loadedRowLimit + 1))
            if (nextLimit <= loadedRowLimit) return@collect

            loadingMore = true
            val expanded = runCatching {
                kotlinx.coroutines.withTimeout(15000L) {
                    withContext(Dispatchers.IO) {
                        parseXlsxSheet(
                            File(localPath),
                            workbook.sheets[safeSheet],
                            workbook.sharedStrings,
                            workbook.styles,
                            rowLimit = nextLimit
                        )
                    }
                }
            }
            expanded.onSuccess { fresh ->
                sheetData = fresh
                loadedRowLimit = nextLimit
                sheetCache[safeSheet] = nextLimit to fresh
            }.onFailure { error ->
                if (error !is kotlinx.coroutines.CancellationException) {
                    onMessage(error.message ?: "No se pudieron cargar mas filas.")
                }
            }
            loadingMore = false
        }
    }

    val dataForSearch = sheetData
    LaunchedEffect(query, dataForSearch) {
        if (query.isNotBlank() && dataForSearch != null) {
            val firstMatch = dataForSearch.rows.entries.firstOrNull { (_, row) ->
                row.cells.values.any { it.value.contains(query, ignoreCase = true) }
            }?.key
            if (firstMatch != null && firstMatch > 0) {
                listState.animateScrollToItem((firstMatch - 1).coerceAtLeast(0))
            }
        }
    }

    Column(Modifier.fillMaxSize().background(if (inverted) Color.Black else Color.White)) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .background(if (inverted) Color(0xFF121212) else Color(0xFFF5F5F5))
                .padding(horizontal = 4.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            workbook.sheets.forEachIndexed { index, sheet ->
                val active = index == selectedSheet
                Surface(
                    modifier = Modifier.clickable {
                        selectedSheet = index
                        selectedCell = null
                    },
                    color = if (active) {
                        if (inverted) Color(0xFF0C5D32) else Color(0xFFDFF4E8)
                    } else Color.Transparent,
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text(
                        sheet.name,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        color = if (active) {
                            if (inverted) Color.White else Color(0xFF0B6B3A)
                        } else if (inverted) Color(0xFFD0D0D0) else Color(0xFF555555),
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
            }
        }

        if (loadingSheet) {
            ViewerLoading("Cargando hoja…")
            return@Column
        }
        val data = sheetData
        if (sheetError != null || data == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(sheetError ?: "Hoja no disponible", color = if (inverted) Color.White else Color.DarkGray)
            }
        } else {
            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(localPath, selectedSheet, minZoom, maxZoom) {
                        awaitEachGesture {
                            var hadTransform = false
                            do {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.filter { it.pressed }
                                if (pressed.size >= 2) {
                                    if (!hadTransform) {
                                        hadTransform = true
                                        transforming = true
                                    }

                                    val centroidX = pressed.sumOf { it.position.x.toDouble() }.toFloat() / pressed.size
                                    val centroidY = pressed.sumOf { it.position.y.toDouble() }.toFloat() / pressed.size
                                    val oldZoom = zoom.coerceIn(minZoom, maxZoom)
                                    val requestedZoom = (oldZoom * event.calculateZoom()).coerceIn(minZoom, maxZoom)
                                    val actualFactor = requestedZoom / oldZoom.coerceAtLeast(0.001f)
                                    val drag = event.calculatePan()

                                    if (kotlin.math.abs(actualFactor - 1f) > 0.0001f ||
                                        kotlin.math.abs(drag.x) + kotlin.math.abs(drag.y) > 0.01f
                                    ) {
                                        val viewportW = size.width.toFloat().coerceAtLeast(1f)
                                        val viewportH = size.height.toFloat().coerceAtLeast(1f)
                                        val nextX = panX * actualFactor +
                                            centroidX * (1f - actualFactor) + drag.x
                                        val nextY = panY * actualFactor +
                                            centroidY * (1f - actualFactor) + drag.y
                                        val extraX = (viewportW * (requestedZoom - 1f)).coerceAtLeast(0f)
                                        val extraY = (viewportH * (requestedZoom - 1f)).coerceAtLeast(0f)

                                        // Igual que el visor paginado: la matriz que ve el usuario nunca se
                                        // desmonta al soltar los dedos. Por eso desaparecen los flashes blancos.
                                        zoom = requestedZoom
                                        panX = if (extraX <= 0.5f) 0f else nextX.coerceIn(-extraX, 0f)
                                        panY = if (extraY <= 0.5f) 0f else nextY.coerceIn(-extraY, 0f)
                                    }
                                    event.changes.forEach { it.consume() }
                                }
                            } while (event.changes.any { it.pressed })

                            if (hadTransform) {
                                transforming = false
                            }
                        }
                    }
                    .pointerInput(localPath, selectedSheet, minZoom, maxZoom) {
                        detectHorizontalDragGestures { change, dragAmount ->
                            if (!transforming && zoom > minZoom + 0.001f) {
                                val z = zoom.coerceAtLeast(1f)
                                val viewportPx = size.width.toFloat().coerceAtLeast(1f)
                                // Posicion horizontal real de la hoja en coordenadas 1x.
                                // graphicsLayer esta fuera del horizontalScroll, por eso la
                                // combinacion exacta es scroll - pan/zoom.
                                val currentBaseOffset = horizontalState.value.toFloat() - (panX / z)
                                val contentWidthPx = horizontalState.maxValue.toFloat() + viewportPx
                                val maxBaseOffset = (contentWidthPx - viewportPx / z).coerceAtLeast(0f)
                                val targetBaseOffset = (currentBaseOffset - dragAmount / z)
                                    .coerceIn(0f, maxBaseOffset)

                                val desiredScroll = targetBaseOffset
                                    .coerceIn(0f, horizontalState.maxValue.toFloat())
                                horizontalState.dispatchRawDelta(desiredScroll - horizontalState.value.toFloat())

                                val actualScroll = horizontalState.value.toFloat()
                                val remainingBase = (targetBaseOffset - actualScroll).coerceAtLeast(0f)
                                val extraX = (viewportPx * (z - 1f)).coerceAtLeast(0f)
                                panX = (-remainingBase * z).coerceIn(-extraX, 0f)
                                change.consume()
                            }
                        }
                    }
            ) {
                // La hoja conserva geometria base estable. El zoom completo vive en la capa GPU;
                // no se reconstruyen filas/columnas al terminar el pellizco.
                val rowHeaderWidth = 34.dp
                val headerHeight = 25.dp
                val columnWidths = remember(data) {
                    List(data.maxColumns) { col ->
                        val chars = data.columnWidths[col] ?: 9.0f
                        (chars * 7.1f).coerceIn(38f, 260f).dp
                    }
                }
                val prefixWidths = remember(columnWidths) {
                    FloatArray(columnWidths.size + 1).also { prefix ->
                        columnWidths.forEachIndexed { index, width ->
                            prefix[index + 1] = prefix[index] + width.value
                        }
                    }
                }
                val totalColumnsDp = prefixWidths.lastOrNull() ?: 0f
                val baseTotalWidth = rowHeaderWidth + totalColumnsDp.dp
                val contentWidth = if (baseTotalWidth < maxWidth) maxWidth else baseTotalWidth
                val totalDisplayRows = data.totalRowsHint.coerceAtLeast(data.maxRows).coerceAtLeast(1)

                val viewportWidthPx = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)
                val z = zoom.coerceAtLeast(1f)
                val visibleBaseStartPx = horizontalState.value.toFloat() - (panX / z)
                val visibleBaseEndPx = visibleBaseStartPx + viewportWidthPx / z
                val visibleBaseStartDp = with(density) { visibleBaseStartPx.toDp().value }
                val visibleBaseEndDp = with(density) { visibleBaseEndPx.toDp().value }
                val startInColumns = (visibleBaseStartDp - rowHeaderWidth.value).coerceAtLeast(0f)
                val endInColumns = (visibleBaseEndDp - rowHeaderWidth.value).coerceAtLeast(0f)
                var firstVisible = 0
                while (
                    firstVisible < data.maxColumns - 1 &&
                    prefixWidths[firstVisible + 1] < startInColumns
                ) firstVisible++
                var lastVisible = firstVisible
                while (
                    lastVisible < data.maxColumns - 1 &&
                    prefixWidths[lastVisible] <= endInColumns
                ) lastVisible++
                firstVisible = (firstVisible - 5).coerceAtLeast(0)
                lastVisible = (lastVisible + 5).coerceAtMost(data.maxColumns - 1)
                val leadingWidth = prefixWidths[firstVisible].dp
                val trailingWidth = (totalColumnsDp - prefixWidths[lastVisible + 1]).coerceAtLeast(0f).dp

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            transformOrigin = TransformOrigin(0f, 0f)
                            scaleX = zoom
                            scaleY = zoom
                            translationX = panX
                            translationY = panY
                        }
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(horizontalState, enabled = zoom <= minZoom + 0.001f)
                    ) {
                        Column(Modifier.width(contentWidth).fillMaxHeight()) {
                            ExcelColumnHeaders(
                                maxColumns = data.maxColumns,
                                rowHeaderWidth = rowHeaderWidth,
                                columnWidths = columnWidths,
                                rowHeight = headerHeight,
                                inverted = inverted,
                                zoom = 1f,
                                visibleStart = firstVisible,
                                visibleEnd = lastVisible,
                                leadingColumnsWidth = leadingWidth,
                                trailingColumnsWidth = trailingWidth,
                                modifier = Modifier.width(baseTotalWidth).height(headerHeight)
                            )
                            LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth()) {
                                items(totalDisplayRows, key = { index -> "excel_row_${index + 1}" }) { index ->
                                    val rowNumber = index + 1
                                    val row = data.rows[rowNumber] ?: ExcelRowData(rowNumber, emptyMap())
                                    val rowHeight = (((row.heightPoints ?: 18f) * 1.15f).coerceIn(20f, 120f)).dp
                                    ExcelGridRow(
                                        row = row,
                                        maxColumns = data.maxColumns,
                                        rowHeaderWidth = rowHeaderWidth,
                                        columnWidths = columnWidths,
                                        rowHeight = rowHeight,
                                        query = query,
                                        inverted = inverted,
                                        styles = workbook.styles,
                                        zoom = 1f,
                                        selectedCell = selectedCell,
                                        onCellSelected = { col -> selectedCell = row.rowNumber to col },
                                        visibleStart = firstVisible,
                                        visibleEnd = lastVisible,
                                        leadingColumnsWidth = leadingWidth,
                                        trailingColumnsWidth = trailingWidth,
                                        modifier = Modifier.width(baseTotalWidth).height(rowHeight)
                                    )
                                }
                            }
                        }
                    }
                }

            }
        }
    }
}

@Composable
private fun ExcelColumnHeaders(
    maxColumns: Int,
    rowHeaderWidth: androidx.compose.ui.unit.Dp,
    columnWidths: List<androidx.compose.ui.unit.Dp>,
    rowHeight: androidx.compose.ui.unit.Dp,
    inverted: Boolean,
    zoom: Float,
    visibleStart: Int,
    visibleEnd: Int,
    leadingColumnsWidth: androidx.compose.ui.unit.Dp,
    trailingColumnsWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    val bg = if (inverted) Color(0xFF202020) else Color(0xFFEFEFEF)
    val fg = if (inverted) Color(0xFFEAEAEA) else Color(0xFF333333)
    val grid = if (inverted) Color(0xFF4A4A4A) else Color(0xFFC9C9C9)
    Row(modifier) {
        Box(Modifier.width(rowHeaderWidth).height(rowHeight).background(bg).border(0.5.dp, grid))
        if (leadingColumnsWidth > 0.dp) Spacer(Modifier.width(leadingColumnsWidth))
        if (maxColumns > 0 && visibleStart <= visibleEnd) {
            for (col in visibleStart..visibleEnd) {
                androidx.compose.runtime.key("excel_header_$col") {
                    Box(
                        Modifier.width(columnWidths[col]).height(rowHeight).background(bg).border(0.5.dp, grid),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            excelColumnName(col),
                            color = fg,
                            fontWeight = FontWeight.Medium,
                            fontSize = (10f * zoom).sp
                        )
                    }
                }
            }
        }
        if (trailingColumnsWidth > 0.dp) Spacer(Modifier.width(trailingColumnsWidth))
    }
}

@Composable
private fun ExcelGridRow(
    row: ExcelRowData,
    maxColumns: Int,
    rowHeaderWidth: androidx.compose.ui.unit.Dp,
    columnWidths: List<androidx.compose.ui.unit.Dp>,
    rowHeight: androidx.compose.ui.unit.Dp,
    query: String,
    inverted: Boolean,
    styles: List<ExcelCellStyleModel>,
    zoom: Float,
    selectedCell: Pair<Int, Int>?,
    onCellSelected: (Int) -> Unit,
    visibleStart: Int,
    visibleEnd: Int,
    leadingColumnsWidth: androidx.compose.ui.unit.Dp,
    trailingColumnsWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    val bg = if (inverted) Color(0xFF0A0A0A) else Color.White
    val headerBg = if (inverted) Color(0xFF202020) else Color(0xFFEFEFEF)
    val fg = if (inverted) Color(0xFFF1F1F1) else Color(0xFF202124)
    val grid = if (inverted) Color(0xFF383838) else Color(0xFFD4D4D4)
    Row(modifier) {
        Box(
            Modifier.width(rowHeaderWidth).height(rowHeight).background(headerBg).border(0.5.dp, grid),
            contentAlignment = Alignment.Center
        ) {
            Text(row.rowNumber.toString(), color = fg, fontSize = (9.5f * zoom).sp)
        }
        if (leadingColumnsWidth > 0.dp) Spacer(Modifier.width(leadingColumnsWidth))
        if (maxColumns > 0 && visibleStart <= visibleEnd) {
            for (col in visibleStart..visibleEnd) {
                androidx.compose.runtime.key("excel_${row.rowNumber}_$col") {
                    val cell = row.cells[col]
                    val value = cell?.value.orEmpty()
                    val style = styles.getOrNull(cell?.styleIndex ?: 0)
                    val styledBg = style?.fillArgb?.let { Color(if (inverted) invertArgb(it) else it) } ?: bg
                    val styledFg = style?.textArgb?.let { Color(if (inverted) invertArgb(it) else it) } ?: fg
                    val isMatch = query.isNotBlank() && value.contains(query, ignoreCase = true)
                    val isSelected = selectedCell == (row.rowNumber to col)
                    val contentAlignment = when (style?.horizontal?.lowercase()) {
                        "center" -> Alignment.Center
                        "right" -> Alignment.CenterEnd
                        else -> Alignment.CenterStart
                    }
                    Box(
                        modifier = Modifier.width(columnWidths[col]).height(rowHeight).background(styledBg)
                            .border(
                                width = if (isSelected || isMatch) 1.8.dp else 0.5.dp,
                                color = if (isSelected || isMatch) Color(0xFF16A765) else grid
                            )
                            .clickable { onCellSelected(col) }
                            .padding(horizontal = 4.dp * zoom, vertical = 2.dp * zoom),
                        contentAlignment = contentAlignment
                    ) {
                        Text(
                            value,
                            color = styledFg,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = ((style?.fontSizePt ?: 10f) * zoom).sp,
                            lineHeight = ((style?.fontSizePt ?: 10f) * 1.15f * zoom).sp,
                            fontWeight = if (style?.bold == true) FontWeight.Bold else FontWeight.Normal,
                            textAlign = when (style?.horizontal?.lowercase()) {
                                "center" -> TextAlign.Center
                                "right" -> TextAlign.End
                                else -> TextAlign.Start
                            }
                        )
                    }
                }
            }
        }
        if (trailingColumnsWidth > 0.dp) Spacer(Modifier.width(trailingColumnsWidth))
    }
}

@Composable
private fun PowerPointDeckViewer(
    localPath: String,
    deck: PowerPointDeckModel,
    query: String,
    inverted: Boolean,
    resetViewToken: Int,
    onMessage: (String) -> Unit,
    onCurrentSlideChanged: (Int) -> Unit
) {
    val matchingSlides = remember(deck, query) {
        if (query.isBlank()) emptySet()
        else deck.slides.mapIndexedNotNull { index, slide ->
            val found = slide.elements.any { element ->
                element is PowerPointElementModel.TextBox && element.text.contains(query, true)
            }
            if (found) index else null
        }.toSet()
    }
    val jumpTarget = matchingSlides.minOrNull()

    DrivePagedSurface(
        viewerKey = "ppt_$localPath",
        pageCount = deck.slides.size,
        background = if (inverted) Color.Black else Color(0xFF252525),
        jumpToPage = jumpTarget,
        jumpRequestKey = query,
        resetViewToken = resetViewToken,
        minZoom = 1f,
        maxZoom = 2.5f,
        renderDebounceMillis = 160L,
        maxRasterWidth = minOf(2400, viewerMaxRasterWidth()),
        fixedRasterWidth = minOf(2400, viewerMaxRasterWidth()),
        showFastScrollHandle = false,
        onCurrentPageChanged = onCurrentSlideChanged,
        pageContent = { index, renderWidth, pageWidth, highQualityEnabled ->
            val ratio = deck.widthEmu.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f)
            PowerPointRenderedSlide(
                localPath = localPath,
                deck = deck,
                slide = deck.slides[index],
                inverted = inverted,
                renderWidth = renderWidth,
                highQualityEnabled = highQualityEnabled,
                matched = index in matchingSlides,
                modifier = Modifier.width(pageWidth).aspectRatio(ratio),
                onMessage = onMessage
            )
        }
    )
}

@Composable
private fun PowerPointPresentation(
    localPath: String,
    deck: PowerPointDeckModel,
    initialSlide: Int,
    inverted: Boolean,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    var current by remember(localPath, initialSlide) {
        mutableIntStateOf(initialSlide.coerceIn(0, deck.slides.lastIndex))
    }
    var previous by remember(localPath, initialSlide) { mutableIntStateOf(current) }
    var controlsVisible by remember { mutableStateOf(false) }
    var transitionSerial by remember { mutableIntStateOf(0) }
    var transitionPreparing by remember { mutableStateOf(false) }
    var activeTransition by remember { mutableStateOf<PowerPointTransitionModel?>(null) }
    // Al retroceder no elegimos la transicion de la diapositiva destino. PowerPoint
    // guarda la transicion en la diapositiva que entra al avanzar; volver hacia atras
    // significa reproducir ESA MISMA transicion en sentido temporal inverso.
    var activeTransitionReversed by remember { mutableStateOf(false) }
    var pendingTarget by remember(localPath) { mutableStateOf<Int?>(null) }
    var queuedTarget by remember(localPath) { mutableStateOf<Int?>(null) }
    var navigationBusy by remember(localPath) { mutableStateOf(false) }
    val transitionProgress = remember { androidx.compose.animation.core.Animatable(1f) }
    // Usamos el mismo ancho estable del visor normal. Asi, al pulsar Presentar, la
    // diapositiva visible suele existir ya en cache y no aparece un frame negro mientras
    // se vuelve a rasterizar a otra medida.
    val presentationRenderWidth = remember { minOf(2400, viewerMaxRasterWidth()) }
    val presentationBitmaps = remember(localPath, inverted, presentationRenderWidth) {
        mutableStateMapOf<Int, Bitmap>().apply {
            val initialIndex = initialSlide.coerceIn(0, deck.slides.lastIndex)
            val initial = deck.slides[initialIndex]
            val key = "ppt|$localPath|${initial.hashCode()}|$inverted|$presentationRenderWidth"
            ViewerBitmapCache.get(key)?.let { put(initialIndex, it) }
        }
    }
    var initialReady by remember(localPath, initialSlide, inverted, presentationRenderWidth) {
        mutableStateOf(presentationBitmaps.containsKey(initialSlide.coerceIn(0, deck.slides.lastIndex)))
    }

    // Solo Presentar fuerza paisaje y entra en modo inmersivo real. No quedan hora,
    // bateria, barra de navegacion ni controles de la app sobre la diapositiva.
    DisposableEffect(activity) {
        val previousOrientation = activity?.requestedOrientation
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        if (window != null && controller != null) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            if (window != null && controller != null) {
                controller.show(WindowInsetsCompat.Type.systemBars())
                WindowCompat.setDecorFitsSystemWindows(window, true)
            }
            if (previousOrientation != null) activity?.requestedOrientation = previousOrientation
        }
    }

    LaunchedEffect(localPath, initialSlide, inverted, presentationRenderWidth) {
        if (!initialReady) {
            val initialIndex = initialSlide.coerceIn(0, deck.slides.lastIndex)
            val slide = deck.slides[initialIndex]
            val key = "ppt|$localPath|${slide.hashCode()}|$inverted|$presentationRenderWidth"
            val cached = presentationBitmaps[initialIndex] ?: ViewerBitmapCache.get(key)
            val ready = if (cached != null) {
                presentationBitmaps[initialIndex] = cached
                true
            } else runCatching {
                val bitmap = runInterruptible(Dispatchers.IO) {
                    renderPowerPointSlideBitmap(File(localPath), deck, slide, presentationRenderWidth, inverted)
                }
                ViewerBitmapCache.put(key, bitmap)
                presentationBitmaps[initialIndex] = bitmap
                true
            }.getOrDefault(false)
            initialReady = ready
        }
    }

    val goTo: (Int) -> Unit = { target ->
        val fixed = target.coerceIn(0, deck.slides.lastIndex)
        if (fixed != current) {
            if (navigationBusy || pendingTarget != null) {
                // Un toque extra no corta una transicion a la mitad. Se conserva como
                // maximo un destino pendiente y se ejecuta cuando termina la actual.
                queuedTarget = fixed
            } else {
                navigationBusy = true
                pendingTarget = fixed
            }
        }
    }

    // Nunca cambiamos current a una diapositiva que aun no tenga bitmap. Incluso una
    // diapositiva sin transicion pasa primero por esta preparacion, eliminando el frame
    // blanco que antes aparecia entre dos cambios.
    LaunchedEffect(pendingTarget, localPath, inverted, presentationRenderWidth) {
        val target = pendingTarget ?: return@LaunchedEffect
        val slide = deck.slides[target]
        val key = "ppt|$localPath|${slide.hashCode()}|$inverted|$presentationRenderWidth"
        val cached = presentationBitmaps[target] ?: ViewerBitmapCache.get(key)
        val ready = if (cached != null) {
            presentationBitmaps[target] = cached
            true
        } else runCatching {
            val prepared = runInterruptible(Dispatchers.IO) {
                renderPowerPointSlideBitmap(File(localPath), deck, slide, presentationRenderWidth, inverted)
            }
            ViewerBitmapCache.put(key, prepared)
            presentationBitmaps[target] = prepared
            true
        }.getOrDefault(false)

        if (!ready) {
            pendingTarget = null
            queuedTarget = null
            navigationBusy = false
            return@LaunchedEffect
        }

        val sourceIndex = current
        previous = sourceIndex
        activeTransitionReversed = target < sourceIndex

        // Hacia delante la transicion pertenece a la diapositiva destino. Hacia atras
        // usamos la de la diapositiva origen y luego reproducimos su progreso de 1 -> 0.
        // Asi Push/Wipe/Split/etc. vuelven exactamente por el camino contrario en vez
        // de inventar la transicion configurada en otra diapositiva.
        val requested = if (activeTransitionReversed) {
            deck.slides[sourceIndex].transition
        } else {
            deck.slides[target].transition
        }
        activeTransition = normalizePowerPointTransition(requested)
        transitionPreparing = activeTransition != null
        pendingTarget = null
        current = target
        transitionSerial++
    }

    LaunchedEffect(transitionSerial, current) {
        if (transitionSerial == 0) {
            transitionProgress.snapTo(1f)
            transitionPreparing = false
            navigationBusy = false
            return@LaunchedEffect
        }
        val slide = deck.slides[current]
        val spec = activeTransition
        if (spec == null) {
            transitionProgress.snapTo(1f)
            transitionPreparing = false
        } else {
            // No se inicia la animacion hasta que la diapositiva entrante exista en cache.
            // Mientras se prepara, la diapositiva anterior permanece quieta en pantalla.
            val key = "ppt|$localPath|${slide.hashCode()}|$inverted|$presentationRenderWidth"
            if (presentationBitmaps[current] == null) {
                val cached = ViewerBitmapCache.get(key)
                if (cached != null) {
                    presentationBitmaps[current] = cached
                } else {
                    val prepared = runCatching {
                        withContext(Dispatchers.IO) {
                            renderPowerPointSlideBitmap(File(localPath), deck, slide, presentationRenderWidth, inverted)
                        }
                    }.getOrNull()
                    if (prepared != null) {
                        ViewerBitmapCache.put(key, prepared)
                        presentationBitmaps[current] = prepared
                    }
                }
            }

            // p14:dur esta expresado en milisegundos y, cuando existe, se respeta tal cual.
            // Para archivos antiguos sin duracion explicita, durationMs ya contiene el
            // respaldo derivado de spd. Solo existe un limite de seguridad muy amplio
            // contra valores corruptos; ya no hay el corte artificial de 1100 ms.
            val transitionDuration = spec.durationMs.coerceIn(0, 60_000)
            transitionProgress.snapTo(0f)
            transitionPreparing = false
            if (transitionDuration == 0) {
                transitionProgress.snapTo(1f)
            } else {
                transitionProgress.animateTo(
                    targetValue = 1f,
                    animationSpec = androidx.compose.animation.core.tween(
                        durationMillis = transitionDuration,
                        // La curva se aplica despues al progreso semantico. Mantener aqui
                        // el reloj lineal permite reproducir exactamente E(t) hacia delante
                        // y E(1-t) hacia atras con la misma duracion.
                        easing = androidx.compose.animation.core.LinearEasing
                    )
                )
            }
        }
        navigationBusy = false
        val queued = queuedTarget
        queuedTarget = null
        if (queued != null && queued != current) {
            navigationBusy = true
            pendingTarget = queued
        }
    }


    val autoMs = deck.slides[current].advanceAfterMs
    LaunchedEffect(current, autoMs, transitionSerial, initialReady) {
        if (initialReady && autoMs != null && autoMs in 200L..120000L && current < deck.slides.lastIndex) {
            // El tiempo automatico de permanencia empieza cuando la transicion de entrada
            // ya termino. Asi una transicion larga no se come el tiempo visible de la diapositiva.
            while (transitionPreparing || transitionProgress.value < 0.999f) {
                kotlinx.coroutines.delay(16L)
            }
            kotlinx.coroutines.delay(autoMs)
            goTo(current + 1)
        }
    }
    LaunchedEffect(controlsVisible, current) {
        if (controlsVisible) {
            kotlinx.coroutines.delay(1600L)
            controlsVisible = false
        }
    }

    // Precarga anterior/siguiente para que el cambio empiece con la imagen lista.
    LaunchedEffect(localPath, current, inverted, initialReady, navigationBusy) {
        if (!initialReady || navigationBusy) return@LaunchedEffect
        val file = File(localPath)
        val neighbors = listOf(current - 1, current + 1)
            .filter { it in deck.slides.indices }
        neighbors.forEach { index ->
            currentCoroutineContext().ensureActive()
            val slide = deck.slides[index]
            val key = "ppt|$localPath|${slide.hashCode()}|$inverted|$presentationRenderWidth"
            val cached = presentationBitmaps[index] ?: ViewerBitmapCache.get(key)
            if (cached != null) {
                presentationBitmaps[index] = cached
            } else {
                try {
                    val prepared = runInterruptible(Dispatchers.IO) {
                        renderPowerPointSlideBitmap(file, deck, slide, presentationRenderWidth, inverted)
                    }
                    ViewerBitmapCache.put(key, prepared)
                    presentationBitmaps[index] = prepared
                } catch (error: kotlinx.coroutines.CancellationException) {
                    throw error
                } catch (_: Throwable) {
                    // La precarga es opcional; el cambio de diapositiva vuelve a intentarlo.
                }
            }
        }
    }

    LaunchedEffect(current, previous, localPath) {
        // Presentar conserva referencias fuertes solo a las diapositivas que pueden entrar
        // en el siguiente frame. Asi una expulsion del LruCache no puede dejar una
        // transicion a mitad sin textura, pero tampoco acumulamos todo el PPT en RAM.
        val keep = setOf(current, previous, current - 1, current + 1)
            .filter { it in deck.slides.indices }
            .toSet()
        presentationBitmaps.keys.toList().filterNot { it in keep }.forEach {
            presentationBitmaps.remove(it)
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(current, deck.slides.size, initialReady) {
                detectTapGestures(
                    onTap = { offset ->
                        val leftLimit = size.width / 3f
                        val rightLimit = size.width * 2f / 3f
                        when {
                            !initialReady -> Unit
                            offset.x <= leftLimit -> if (current > 0) goTo(current - 1)
                            offset.x >= rightLimit -> if (current < deck.slides.lastIndex) goTo(current + 1)
                            else -> controlsVisible = !controlsVisible
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        val slideRatio = deck.widthEmu.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f)
        val availableRatio = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
        val fittedWidth: androidx.compose.ui.unit.Dp
        val fittedHeight: androidx.compose.ui.unit.Dp
        if (availableRatio > slideRatio) {
            fittedHeight = maxHeight
            fittedWidth = fittedHeight * slideRatio
        } else {
            fittedWidth = maxWidth
            fittedHeight = fittedWidth / slideRatio
        }
        val presentationDensity = LocalDensity.current
        val fittedWidthPx = with(presentationDensity) { fittedWidth.toPx() }
        val fittedHeightPx = with(presentationDensity) { fittedHeight.toPx() }

        if (!initialReady) {
            // No dibujamos un rectangulo blanco sin contenido al entrar a Presentar.
            // El fondo negro permanece hasta que la primera diapositiva este lista.
            return@BoxWithConstraints
        }

        // Durante la precarga visualmente seguimos en 0: la diapositiva entrante no
        // aparece hasta que su bitmap completo esta fijado en presentationBitmaps.
        val animationProgress = if (transitionPreparing) 0f else transitionProgress.value.coerceIn(0f, 1f)
        val spec = activeTransition
        val transitioning = transitionSerial > 0 && spec != null &&
            (transitionPreparing || animationProgress < 0.999f) && previous != current

        val currentBitmap = presentationBitmaps[current]
        val previousBitmap = presentationBitmaps[previous] ?: currentBitmap
        val safeCurrentBitmap = currentBitmap ?: previousBitmap

        // Renderizamos cada efecto con semantica FORWARD y para retroceder solo invertimos
        // el tiempo (1 -> 0) y los roles de las dos slides. Esto es mucho mas fiel que
        // cambiar manualmente left/right o in/out para cada efecto, y garantiza que la
        // reversa recorra exactamente la misma trayectoria.
        val semanticTime = if (activeTransitionReversed) {
            1f - animationProgress
        } else {
            animationProgress
        }.coerceIn(0f, 1f)
        val forwardProgress = powerPointTransitionEasing(spec).transform(semanticTime).coerceIn(0f, 1f)
        val forwardFromBitmap = if (activeTransitionReversed) safeCurrentBitmap else previousBitmap
        val forwardToBitmap = if (activeTransitionReversed) previousBitmap else safeCurrentBitmap

        // El marco de la diapositiva es el unico viewport. Siempre dibujamos una slide
        // completa como respaldo dentro del marco para que ni un redondeo de GPU ni una
        // mascara parcial pueda revelar el fondo negro de Presentar.
        Box(
            modifier = Modifier
                .width(fittedWidth)
                .height(fittedHeight)
                .graphicsLayer { clip = true },
            contentAlignment = Alignment.Center
        ) {
            if (!transitioning || spec == null) {
                PowerPointPresentationBitmap(safeCurrentBitmap, Modifier.fillMaxSize())
            } else {
                PowerPointTransitionFrame(
                    fromBitmap = forwardFromBitmap,
                    toBitmap = forwardToBitmap,
                    spec = spec,
                    progress = forwardProgress,
                    widthPx = fittedWidthPx,
                    heightPx = fittedHeightPx
                )
            }
        }

        // Presentacion limpia: no flechas, contador ni barras. El centro solo muestra
        // durante un instante el boton de salida; los costados cambian de diapositiva.
        if (controlsVisible) {
            Surface(
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
                color = Color(0xB3111111),
                shape = RoundedCornerShape(22.dp)
            ) {
                IconButton(onClick = onExit) {
                    Icon(Icons.Rounded.Close, contentDescription = "Salir de Presentar", tint = Color.White)
                }
            }
        }
    }
}

private val powerPointKnownTransitionTypes = setOf(
    // ISO/IEC 29500 / PowerPoint clasicos.
    "blinds", "checker", "circle", "comb", "cover", "cut", "diamond", "dissolve",
    "fade", "newsflash", "plus", "pull", "push", "random", "randombar", "split",
    "strips", "wedge", "wheel", "wipe", "zoom",
    // Extensiones que Microsoft publica como hijos validos de p:transition.
    "conveyor", "doors", "ferris", "flash", "flip", "flythrough", "gallery", "glitter",
    "honeycomb", "pan", "prism", "reveal", "ripple", "shred", "switch", "vortex",
    "warp", "wheelreverse", "window", "prsttrans", "morph",
    // Presets de Office 2013 (p15:prstTrans).
    "fallover", "drape", "curtains", "wind", "prestige", "fracture", "crush",
    "peeloff", "pagecurldouble", "pagecurlsingle", "airplane", "origami"
)

private fun canonicalPowerPointTransitionType(spec: PowerPointTransitionModel?): String {
    if (spec == null) return ""
    val raw = spec.type.lowercase().replace("-", "").replace("_", "")
    if (raw == "prsttrans") {
        val preset = spec.parameters["prst"]
            ?: spec.parameters["preset"]
            ?: spec.parameters["type"]
        if (!preset.isNullOrBlank()) return preset.lowercase().replace("-", "").replace("_", "")
    }
    return raw
}

private fun normalizePowerPointTransition(spec: PowerPointTransitionModel?): PowerPointTransitionModel? {
    if (spec == null) return null
    val canonical = canonicalPowerPointTransitionType(spec)
    // Cualquier transicion futura sigue respetando su duracion y no rompe Presentar:
    // si el motor aun no conoce su geometria, usa un crossfade limpio.
    return if (canonical in powerPointKnownTransitionTypes) spec else spec.copy(type = "fade")
}

private fun powerPointTransitionEasing(spec: PowerPointTransitionModel?): androidx.compose.animation.core.Easing {
    return when (canonicalPowerPointTransitionType(spec)) {
        // Las mascaras deben barrer a velocidad uniforme; aplicarles ease causa que
        // franjas/ruedas se aceleren de forma distinta a PowerPoint.
        "wipe", "split", "blinds", "checker", "circle", "comb", "diamond", "dissolve",
        "plus", "randombar", "strips", "wedge", "wheel", "wheelreverse", "glitter",
        "honeycomb", "ripple", "shred", "vortex", "warp" -> androidx.compose.animation.core.LinearEasing
        "push", "cover", "pull", "conveyor", "pan", "reveal" ->
            androidx.compose.animation.core.CubicBezierEasing(0.25f, 0.10f, 0.25f, 1f)
        "zoom", "flythrough", "gallery", "newsflash" ->
            androidx.compose.animation.core.CubicBezierEasing(0.30f, 0f, 0.25f, 1f)
        "flip", "prism", "switch", "ferris", "fallover", "prestige", "airplane", "origami" ->
            androidx.compose.animation.core.CubicBezierEasing(0.42f, 0f, 0.58f, 1f)
        else -> androidx.compose.animation.core.CubicBezierEasing(0.33f, 0f, 0.67f, 1f)
    }
}

private fun powerPointMotionSigns(spec: PowerPointTransitionModel): Pair<Float, Float> {
    var pair = when ((spec.direction ?: spec.parameters["dir"])?.lowercase()) {
        // En OOXML dir describe hacia donde se desplaza la composicion. Para una entrada,
        // una transicion hacia la izquierda trae la nueva slide desde la derecha.
        "l", "left" -> 1f to 0f
        "r", "right" -> -1f to 0f
        "u", "up" -> 0f to 1f
        "d", "down" -> 0f to -1f
        "lu", "ul" -> 1f to 1f
        "ld", "dl" -> 1f to -1f
        "ru", "ur" -> -1f to 1f
        "rd", "dr" -> -1f to -1f
        else -> 1f to 0f
    }
    val invertX = spec.parameters["invX"] == "1" || spec.parameters["invX"].equals("true", true)
    val invertY = spec.parameters["invY"] == "1" || spec.parameters["invY"].equals("true", true)
    if (invertX) pair = -pair.first to pair.second
    if (invertY) pair = pair.first to -pair.second
    return pair
}

@Composable
private fun PowerPointTransitionFrame(
    fromBitmap: Bitmap?,
    toBitmap: Bitmap?,
    spec: PowerPointTransitionModel,
    progress: Float,
    widthPx: Float,
    heightPx: Float
) {
    val p = progress.coerceIn(0f, 1f)
    val type = canonicalPowerPointTransitionType(spec)
    val (motionX, motionY) = powerPointMotionSigns(spec)
    val thruBlack = spec.parameters["thruBlk"] == "1" ||
        spec.parameters["thruBlk"].equals("true", ignoreCase = true)

    // Si por presion de memoria una textura desapareciera, nunca dejamos el marco vacio.
    val safeFrom = fromBitmap ?: toBitmap
    val safeTo = toBitmap ?: fromBitmap

    when (type) {
        "cut" -> {
            if (thruBlack) {
                Box(Modifier.fillMaxSize().background(Color.Black)) {
                    if (p < 0.5f) {
                        PowerPointPresentationBitmap(
                            safeFrom,
                            Modifier.fillMaxSize().graphicsLayer { alpha = (1f - p * 2f).coerceIn(0f, 1f) }
                        )
                    } else {
                        PowerPointPresentationBitmap(
                            safeTo,
                            Modifier.fillMaxSize().graphicsLayer { alpha = ((p - 0.5f) * 2f).coerceIn(0f, 1f) }
                        )
                    }
                }
            } else {
                PowerPointPresentationBitmap(if (p < 1f) safeFrom else safeTo, Modifier.fillMaxSize())
            }
        }

        "fade", "flash" -> {
            if (thruBlack) {
                Box(Modifier.fillMaxSize().background(Color.Black)) {
                    val fromAlpha = (1f - p * 2f).coerceIn(0f, 1f)
                    val toAlpha = ((p - 0.5f) * 2f).coerceIn(0f, 1f)
                    PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize().graphicsLayer { alpha = fromAlpha })
                    PowerPointPresentationBitmap(safeTo, Modifier.fillMaxSize().graphicsLayer { alpha = toAlpha })
                }
            } else {
                PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
                PowerPointPresentationBitmap(safeTo, Modifier.fillMaxSize().graphicsLayer { alpha = p })
            }
        }

        "push", "conveyor", "pan" -> {
            // Un respaldo completo evita una costura negra por redondeos de subpixel.
            PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
            PowerPointPresentationBitmap(
                safeFrom,
                Modifier.fillMaxSize().graphicsLayer {
                    translationX = widthPx * (-motionX * p)
                    translationY = heightPx * (-motionY * p)
                }
            )
            PowerPointPresentationBitmap(
                safeTo,
                Modifier.fillMaxSize().graphicsLayer {
                    translationX = widthPx * (motionX * (1f - p))
                    translationY = heightPx * (motionY * (1f - p))
                }
            )
        }

        "cover", "reveal" -> {
            PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
            PowerPointPresentationBitmap(
                safeTo,
                Modifier.fillMaxSize().graphicsLayer {
                    translationX = widthPx * (motionX * (1f - p))
                    translationY = heightPx * (motionY * (1f - p))
                }
            )
        }

        "pull" -> {
            PowerPointPresentationBitmap(safeTo, Modifier.fillMaxSize())
            PowerPointPresentationBitmap(
                safeFrom,
                Modifier.fillMaxSize().graphicsLayer {
                    translationX = widthPx * (-motionX * p)
                    translationY = heightPx * (-motionY * p)
                }
            )
        }

        "zoom", "flythrough", "gallery" -> {
            val zoomOut = spec.direction?.equals("out", true) == true ||
                spec.parameters["dir"]?.equals("out", true) == true
            if (zoomOut) {
                PowerPointPresentationBitmap(safeTo, Modifier.fillMaxSize())
                PowerPointPresentationBitmap(
                    safeFrom,
                    Modifier.fillMaxSize().graphicsLayer {
                        alpha = (1f - p).coerceIn(0f, 1f)
                        val scale = 1f - 0.22f * p
                        scaleX = scale
                        scaleY = scale
                    }
                )
            } else {
                PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
                PowerPointPresentationBitmap(
                    safeTo,
                    Modifier.fillMaxSize().graphicsLayer {
                        alpha = p
                        val scale = 0.78f + 0.22f * p
                        scaleX = scale
                        scaleY = scale
                    }
                )
            }
        }

        "newsflash" -> {
            PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
            PowerPointPresentationBitmap(
                safeTo,
                Modifier.fillMaxSize().graphicsLayer {
                    alpha = p
                    val scale = 0.55f + 0.45f * p
                    scaleX = scale
                    scaleY = scale
                    rotationZ = -18f * (1f - p)
                }
            )
        }

        "flip", "prism", "switch", "ferris", "fallover", "prestige", "airplane", "origami" -> {
            // Dos mitades de una unica rotacion 3D. Nunca dibujamos la cara trasera,
            // evitando el flash que producia intercambiar texturas a mitad del giro.
            if (p < 0.5f) {
                PowerPointPresentationBitmap(
                    safeFrom,
                    Modifier.fillMaxSize().graphicsLayer {
                        rotationY = -90f * (p * 2f)
                        cameraDistance = 24f * density
                    }
                )
            } else {
                PowerPointPresentationBitmap(
                    safeTo,
                    Modifier.fillMaxSize().graphicsLayer {
                        rotationY = 90f * ((1f - p) * 2f)
                        cameraDistance = 24f * density
                    }
                )
            }
        }

        "doors", "window", "drape", "curtains" -> {
            PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
            PowerPointPresentationBitmap(
                safeTo,
                Modifier.fillMaxSize().powerPointRevealClip(spec.copy(type = "split", orientation = "vert", direction = "out"), p)
            )
        }

        "wipe", "split", "blinds", "checker", "circle", "comb", "diamond", "dissolve",
        "plus", "randombar", "strips", "wedge", "wheel", "wheelreverse", "glitter",
        "honeycomb", "ripple", "shred", "vortex", "warp", "wind", "fracture", "crush",
        "peeloff", "pagecurldouble", "pagecurlsingle" -> {
            PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
            PowerPointPresentationBitmap(
                safeTo,
                Modifier.fillMaxSize().powerPointRevealClip(spec, p)
            )
        }

        "random" -> {
            // Para "random" usamos una eleccion determinista por slide/modelo. Al no
            // depender del sentido de navegacion, la reproduccion inversa conserva el
            // mismo patron en vez de elegir otro efecto al volver.
            val choices = listOf("fade", "wipe", "push", "split", "dissolve")
            val chosen = choices[(spec.hashCode() and Int.MAX_VALUE) % choices.size]
            when (chosen) {
                "push" -> {
                    PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
                    PowerPointPresentationBitmap(
                        safeFrom,
                        Modifier.fillMaxSize().graphicsLayer { translationX = widthPx * -p }
                    )
                    PowerPointPresentationBitmap(
                        safeTo,
                        Modifier.fillMaxSize().graphicsLayer { translationX = widthPx * (1f - p) }
                    )
                }
                "wipe" -> {
                    PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
                    PowerPointPresentationBitmap(
                        safeTo,
                        Modifier.fillMaxSize().powerPointRevealClip(spec.copy(type = "wipe", direction = "l"), p)
                    )
                }
                "split" -> {
                    PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
                    PowerPointPresentationBitmap(
                        safeTo,
                        Modifier.fillMaxSize().powerPointRevealClip(spec.copy(type = "split", orientation = "vert", direction = "out"), p)
                    )
                }
                "dissolve" -> {
                    PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
                    PowerPointPresentationBitmap(
                        safeTo,
                        Modifier.fillMaxSize().powerPointRevealClip(spec.copy(type = "dissolve"), p)
                    )
                }
                else -> {
                    PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
                    PowerPointPresentationBitmap(safeTo, Modifier.fillMaxSize().graphicsLayer { alpha = p })
                }
            }
        }

        "morph" -> {
            // Morph real necesita correspondencia de objetos entre slides. Este visor
            // rasteriza la diapositiva completa, asi que conservamos tiempo y continuidad
            // con una mezcla estable sin inventar movimientos de objetos que no conocemos.
            PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
            PowerPointPresentationBitmap(safeTo, Modifier.fillMaxSize().graphicsLayer { alpha = p })
        }

        else -> {
            // Fallback para extensiones futuras: nunca deja la pantalla vacia y conserva
            // el duration original ya parseado.
            PowerPointPresentationBitmap(safeFrom, Modifier.fillMaxSize())
            PowerPointPresentationBitmap(safeTo, Modifier.fillMaxSize().graphicsLayer { alpha = p })
        }
    }
}

private fun Modifier.powerPointRevealClip(
    spec: PowerPointTransitionModel,
    progress: Float
): Modifier {
    val type = canonicalPowerPointTransitionType(spec)
    val p = progress.coerceIn(0f, 1f)
    if (p >= 0.999f) return this
    val dir = spec.direction?.lowercase() ?: spec.parameters["dir"]?.lowercase()
    return drawWithContent {
        val contentScope = this
        fun drawPath(path: Path) = clipPath(path) { contentScope.drawContent() }
        fun pseudo01(value: Int): Float {
            var x = value * 1103515245 + 12345
            x = x xor (x ushr 16)
            return ((x and 0x7fffffff) % 10000) / 9999f
        }

        when (type) {
            "wipe" -> when (dir) {
                "r", "right" -> clipRect(size.width * (1f - p), 0f, size.width, size.height) { contentScope.drawContent() }
                "u", "up" -> clipRect(0f, size.height * (1f - p), size.width, size.height) { contentScope.drawContent() }
                "d", "down" -> clipRect(0f, 0f, size.width, size.height * p) { contentScope.drawContent() }
                else -> clipRect(0f, 0f, size.width * p, size.height) { contentScope.drawContent() }
            }

            "split", "doors", "window" -> {
                val vertical = spec.orientation?.equals("vert", true) == true ||
                    spec.parameters["orient"]?.equals("vert", true) == true
                val inward = dir == "in"
                if (vertical) {
                    val half = size.width * 0.5f * p
                    if (inward) {
                        val path = Path().apply {
                            addRect(Rect(0f, 0f, half, size.height))
                            addRect(Rect(size.width - half, 0f, size.width, size.height))
                        }
                        drawPath(path)
                    } else {
                        clipRect(size.width / 2f - half, 0f, size.width / 2f + half, size.height) { contentScope.drawContent() }
                    }
                } else {
                    val half = size.height * 0.5f * p
                    if (inward) {
                        val path = Path().apply {
                            addRect(Rect(0f, 0f, size.width, half))
                            addRect(Rect(0f, size.height - half, size.width, size.height))
                        }
                        drawPath(path)
                    } else {
                        clipRect(0f, size.height / 2f - half, size.width, size.height / 2f + half) { contentScope.drawContent() }
                    }
                }
            }

            "blinds" -> {
                val vertical = dir == "vert" || spec.orientation?.equals("vert", true) == true
                val count = 8
                val path = Path()
                if (vertical) {
                    val strip = size.width / count
                    repeat(count) { i ->
                        val left = strip * i
                        path.addRect(Rect(left, 0f, left + strip * p, size.height))
                    }
                } else {
                    val strip = size.height / count
                    repeat(count) { i ->
                        val top = strip * i
                        path.addRect(Rect(0f, top, size.width, top + strip * p))
                    }
                }
                drawPath(path)
            }

            "checker", "honeycomb" -> {
                val cols = if (type == "honeycomb") 10 else 8
                val rows = if (type == "honeycomb") 7 else 6
                val cellW = size.width / cols
                val cellH = size.height / rows
                val path = Path()
                repeat(rows) { row ->
                    repeat(cols) { col ->
                        val order = ((row + col) % 2) * 0.20f + (row * cols + col).toFloat() / (rows * cols) * 0.80f
                        if (p >= order) {
                            val local = ((p - order) / (1f - order).coerceAtLeast(0.001f)).coerceIn(0f, 1f)
                            val cx = (col + 0.5f) * cellW
                            val cy = (row + 0.5f) * cellH
                            path.addRect(Rect(cx - cellW * 0.5f * local, cy - cellH * 0.5f * local, cx + cellW * 0.5f * local, cy + cellH * 0.5f * local))
                        }
                    }
                }
                drawPath(path)
            }

            "circle", "ripple" -> {
                val radius = kotlin.math.sqrt(size.width * size.width + size.height * size.height) * 0.5f * p
                val cx = size.width / 2f
                val cy = size.height / 2f
                drawPath(Path().apply { addOval(Rect(cx - radius, cy - radius, cx + radius, cy + radius)) })
            }

            "diamond" -> {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val dx = size.width * p
                val dy = size.height * p
                drawPath(Path().apply {
                    moveTo(cx, cy - dy)
                    lineTo(cx + dx, cy)
                    lineTo(cx, cy + dy)
                    lineTo(cx - dx, cy)
                    close()
                })
            }

            "plus" -> {
                val path = Path()
                val cx = size.width / 2f
                val cy = size.height / 2f
                val armHalfW = size.width * 0.5f * p
                val armHalfH = size.height * 0.5f * p
                val thicknessHalfW = size.width * 0.5f * p * p
                val thicknessHalfH = size.height * 0.5f * p * p
                // Empieza como una cruz fina y termina cubriendo exactamente todo el slide.
                path.addRect(Rect(cx - armHalfW, cy - thicknessHalfH, cx + armHalfW, cy + thicknessHalfH))
                path.addRect(Rect(cx - thicknessHalfW, cy - armHalfH, cx + thicknessHalfW, cy + armHalfH))
                drawPath(path)
            }

            "randombar", "comb" -> {
                val vertical = dir == "vert" || spec.orientation?.equals("vert", true) == true
                val count = if (type == "comb") 12 else 18
                val path = Path()
                repeat(count) { logical ->
                    val i = if (type == "randombar") (logical * 7) % count else logical
                    val threshold = logical.toFloat() / count
                    val local = ((p - threshold) * count).coerceIn(0f, 1f)
                    if (local <= 0f) return@repeat
                    if (vertical) {
                        val bar = size.width / count
                        val left = i * bar
                        path.addRect(Rect(left, 0f, left + bar, size.height * local))
                    } else {
                        val bar = size.height / count
                        val top = i * bar
                        val fromLeft = type != "comb" || i % 2 == 0
                        if (fromLeft) path.addRect(Rect(0f, top, size.width * local, top + bar))
                        else path.addRect(Rect(size.width * (1f - local), top, size.width, top + bar))
                    }
                }
                drawPath(path)
            }

            "dissolve", "glitter", "shred", "vortex", "warp" -> {
                val cols = 18
                val rows = 12
                val cellW = size.width / cols
                val cellH = size.height / rows
                val path = Path()
                repeat(rows) { row ->
                    repeat(cols) { col ->
                        val index = row * cols + col
                        val threshold = pseudo01(index * 37 + type.hashCode())
                        if (p >= threshold) {
                            path.addRect(Rect(col * cellW, row * cellH, (col + 1) * cellW + 0.5f, (row + 1) * cellH + 0.5f))
                        }
                    }
                }
                drawPath(path)
            }

            "strips" -> {
                val count = 12
                val horizontalTravel = dir == "ld" || dir == "dl" || dir == "rd" || dir == "dr"
                val fromRight = dir == "ld" || dir == "dl"
                val path = Path()
                if (horizontalTravel) {
                    val stripH = size.height / count
                    repeat(count) { row ->
                        val stagger = row.toFloat() / count * 0.28f
                        val local = ((p - stagger) / (1f - stagger).coerceAtLeast(0.001f)).coerceIn(0f, 1f)
                        val top = row * stripH
                        if (fromRight) {
                            path.addRect(Rect(size.width * (1f - local), top, size.width, top + stripH + 0.5f))
                        } else {
                            path.addRect(Rect(0f, top, size.width * local, top + stripH + 0.5f))
                        }
                    }
                } else {
                    val stripW = size.width / count
                    val fromBottom = dir == "ru" || dir == "ur"
                    repeat(count) { col ->
                        val stagger = col.toFloat() / count * 0.28f
                        val local = ((p - stagger) / (1f - stagger).coerceAtLeast(0.001f)).coerceIn(0f, 1f)
                        val left = col * stripW
                        if (fromBottom) {
                            path.addRect(Rect(left, size.height * (1f - local), left + stripW + 0.5f, size.height))
                        } else {
                            path.addRect(Rect(left, 0f, left + stripW + 0.5f, size.height * local))
                        }
                    }
                }
                if (p > 0.995f) path.addRect(Rect(0f, 0f, size.width, size.height))
                drawPath(path)
            }

            "wedge", "wheel", "wheelreverse" -> {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val radius = kotlin.math.sqrt(size.width * size.width + size.height * size.height)
                val bounds = Rect(cx - radius, cy - radius, cx + radius, cy + radius)
                val spokes = if (type == "wedge") 1 else (spec.spokes ?: spec.parameters["spokes"]?.toIntOrNull() ?: 1).coerceIn(1, 16)
                val reverse = type == "wheelreverse"
                val segment = 360f / spokes
                val sweep = segment * p * if (reverse) -1f else 1f
                val path = Path()
                repeat(spokes) { spoke ->
                    val start = -90f + segment * spoke
                    path.moveTo(cx, cy)
                    path.arcTo(bounds, start, sweep, false)
                    path.lineTo(cx, cy)
                    path.close()
                }
                drawPath(path)
            }

            else -> contentScope.drawContent()
        }
    }
}

@Composable
private fun PowerPointPresentationBitmap(bitmap: Bitmap?, modifier: Modifier) {
    if (bitmap == null) return
    Image(
        bitmap = bitmap.asImageBitmap(),
        contentDescription = null,
        contentScale = ContentScale.FillBounds,
        filterQuality = FilterQuality.Medium,
        modifier = modifier
    )
}

@Composable
private fun PowerPointRenderedSlide(
    localPath: String,
    deck: PowerPointDeckModel,
    slide: PowerPointSlideModel,
    inverted: Boolean,
    renderWidth: Int,
    highQualityEnabled: Boolean = true,
    matched: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    val stableRenderWidth = renderWidth.coerceIn(900, viewerMaxRasterWidth())
    val previewWidth = minOf(800, stableRenderWidth)
    val cacheKey = remember(localPath, slide, inverted, stableRenderWidth) {
        "ppt|$localPath|${slide.hashCode()}|$inverted|$stableRenderWidth"
    }
    val previewKey = remember(localPath, slide, inverted) {
        "ppt|$localPath|${slide.hashCode()}|$inverted|$previewWidth"
    }
    var bitmap by remember(localPath, slide, inverted) {
        mutableStateOf(ViewerBitmapCache.get(cacheKey) ?: ViewerBitmapCache.get(previewKey))
    }

    LaunchedEffect(localPath, slide, inverted, stableRenderWidth, highQualityEnabled) {
        try {
            if ((bitmap?.width ?: 0) >= stableRenderWidth) return@LaunchedEffect
            ViewerBitmapCache.get(cacheKey)?.let { cached ->
                val shown = bitmap
                if (shown == null || cached.width >= shown.width) bitmap = cached
                return@LaunchedEffect
            }
            if (!highQualityEnabled) {
                if (bitmap == null) {
                    ViewerBitmapCache.get(previewKey)?.let { preview ->
                        bitmap = preview
                        return@LaunchedEffect
                    }
                    val preview = runInterruptible(Dispatchers.IO) {
                        renderPowerPointSlideBitmap(File(localPath), deck, slide, previewWidth, inverted)
                    }
                    bitmap = ViewerBitmapCache.put(previewKey, preview)
                }
                return@LaunchedEffect
            }
            if (bitmap == null && ViewerBitmapCache.get(previewKey) == null) {
                val preview = runInterruptible(Dispatchers.IO) {
                    renderPowerPointSlideBitmap(File(localPath), deck, slide, previewWidth, inverted)
                }
                bitmap = ViewerBitmapCache.put(previewKey, preview)
                currentCoroutineContext().ensureActive()
            }
            val full = runInterruptible(Dispatchers.IO) {
                renderPowerPointSlideBitmap(File(localPath), deck, slide, stableRenderWidth, inverted)
            }
            bitmap = ViewerBitmapCache.put(cacheKey, full)
        } catch (error: kotlinx.coroutines.CancellationException) {
            throw error
        } catch (error: Throwable) {
            onMessage(error.message ?: "No se pudo renderizar una diapositiva.")
        }
    }

    val current = bitmap
    Box(
        modifier = modifier
            // Nunca mostramos un rectangulo blanco artificial mientras llega el bitmap.
            // En Presentar esto deja ver la diapositiva anterior; en el visor normal,
            // el fondo oscuro del lienzo.
            .background(Color.Transparent)
            .then(if (matched) Modifier.border(2.dp, NeonGreen) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                filterQuality = FilterQuality.Medium,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private fun renderPowerPointSlideBitmap(
    file: File,
    deck: PowerPointDeckModel,
    slide: PowerPointSlideModel,
    requestedWidth: Int,
    inverted: Boolean
): Bitmap {
    val width = requestedWidth.coerceIn(700, viewerMaxRasterWidth())
    val deckWidth = deck.widthEmu.coerceAtLeast(1L)
    val deckHeight = deck.heightEmu.coerceAtLeast(1L)
    val height = (width.toDouble() * deckHeight.toDouble() / deckWidth.toDouble())
        .roundToInt()
        .coerceAtLeast(1)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    val rawBackground = slide.backgroundArgb ?: 0xFFFFFFFF.toInt()
    val background = if (inverted) invertArgb(rawBackground) else rawBackground
    canvas.drawColor(background)

    // Geometria maestra fija. Preview y alta resolucion se maquetan a 2400 unidades
    // logicas y solo cambia la escala final del canvas. Asi el texto no "baila" al
    // sustituir una textura de 800 px por otra de 2400 px.
    val logicalWidth = 2400f
    val logicalHeight = logicalWidth * deckHeight.toFloat() / deckWidth.toFloat().coerceAtLeast(1f)
    val rasterScale = width.toFloat() / logicalWidth
    canvas.save()
    canvas.scale(rasterScale, rasterScale)

    val scaleX = logicalWidth / deckWidth.toFloat()
    val scaleY = logicalHeight / deckHeight.toFloat()
    val imagePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG).apply {
        if (inverted) colorFilter = android.graphics.ColorMatrixColorFilter(
            android.graphics.ColorMatrix(
                floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }

    java.util.zip.ZipFile(file).use { zip ->
        slide.elements.forEach { element ->
            if (Thread.currentThread().isInterrupted) throw InterruptedException("Render cancelado")
            val left = element.x * scaleX
            val top = element.y * scaleY
            val right = (element.x + element.width) * scaleX
            val bottom = (element.y + element.height) * scaleY
            val rect = android.graphics.RectF(left, top, right, bottom)
            if (rect.width() <= 0f || rect.height() <= 0f) return@forEach

            when (element) {
                is PowerPointElementModel.Rectangle -> {
                    val fill = if (inverted) invertArgb(element.fillArgb) else element.fillArgb
                    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = fill
                        style = android.graphics.Paint.Style.FILL
                    }
                    canvas.drawRect(rect, paint)
                }
                is PowerPointElementModel.Picture -> {
                    val image = runCatching { decodeOfficeZipBitmap(zip, element.entryName) }.getOrNull()
                    if (image != null) {
                        canvas.drawBitmap(image, null, rect, imagePaint)
                        if (!image.isRecycled) image.recycle()
                    }
                }
                is PowerPointElementModel.TextBox -> {
                    val baseColor = element.textArgb ?: if (pptIsDark(rawBackground)) 0xFFFFFFFF.toInt() else 0xFF171717.toInt()
                    val textColor = if (inverted) invertArgb(baseColor) else baseColor
                    val textPaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.SUBPIXEL_TEXT_FLAG).apply {
                        color = textColor
                        val pointSize = element.fontSizePt ?: if (element.height > deckHeight / 7) 24f else 16f
                        textSize = (pointSize * 12700f * scaleY).coerceIn(logicalWidth * 0.012f, logicalWidth * 0.12f)
                        typeface = android.graphics.Typeface.create(
                            android.graphics.Typeface.SANS_SERIF,
                            if (element.bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL
                        )
                    }
                    val padding = (logicalWidth * 0.004f).coerceAtLeast(2f)
                    val textWidth = (rect.width() - padding * 2f).roundToInt().coerceAtLeast(1)
                    val layout = buildStaticLayout(element.text, textPaint, textWidth, maxLines = 30)
                    canvas.save()
                    canvas.clipRect(rect)
                    canvas.translate(rect.left + padding, rect.top + padding)
                    layout.draw(canvas)
                    canvas.restore()
                }
            }
        }
    }
    canvas.restore()
    return bitmap
}

@Composable
private fun PowerPointSlideCanvas(
    localPath: String,
    deck: PowerPointDeckModel,
    slide: PowerPointSlideModel,
    inverted: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    val rawBackground = slide.backgroundArgb ?: 0xFFFFFFFF.toInt()
    val background = Color(if (inverted) invertArgb(rawBackground) else rawBackground)
    val defaultForeground = if (pptIsDark(rawBackground) xor inverted) Color.White else Color(0xFF171717)
    BoxWithConstraints(
        modifier = modifier.clip(RoundedCornerShape(3.dp)).background(background)
    ) {
        val displayScale = (maxWidth.value / 360f).coerceIn(0.55f, 4f)
        slide.elements.forEach { element ->
            val left = maxWidth * (element.x.toFloat() / deck.widthEmu.toFloat().coerceAtLeast(1f))
            val top = maxHeight * (element.y.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f))
            val width = maxWidth * (element.width.toFloat() / deck.widthEmu.toFloat().coerceAtLeast(1f))
            val height = maxHeight * (element.height.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f))
            when (element) {
                is PowerPointElementModel.TextBox -> {
                    val rawText = element.textArgb
                    val textColor = if (rawText != null) Color(if (inverted) invertArgb(rawText) else rawText) else defaultForeground
                    val baseFontSp = element.fontSizePt?.times(0.52f)
                        ?: if (element.height > deck.heightEmu / 7) 17f else 11.5f
                    val fontSp = (baseFontSp * displayScale).coerceIn(5.5f, 64f)
                    Text(
                        element.text,
                        color = textColor,
                        modifier = Modifier.offset(left, top).width(width).height(height).padding(1.dp * displayScale),
                        fontSize = fontSp.sp,
                        lineHeight = (fontSp * 1.08f).sp,
                        fontWeight = if (element.bold) FontWeight.Bold else FontWeight.Normal,
                        overflow = TextOverflow.Ellipsis,
                        maxLines = 24
                    )
                }
                is PowerPointElementModel.Rectangle -> {
                    val rawFill = element.fillArgb
                    Box(
                        Modifier.offset(left, top).width(width).height(height)
                            .background(Color(if (inverted) invertArgb(rawFill) else rawFill))
                    )
                }
                is PowerPointElementModel.Picture -> OfficeZipImage(
                    localPath = localPath,
                    entryName = element.entryName,
                    inverted = inverted,
                    modifier = Modifier.offset(left, top).width(width).height(height),
                    onMessage = onMessage
                )
            }
        }
    }
}

@Composable
private fun OfficeZipImage(
    localPath: String,
    entryName: String,
    inverted: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    var bitmap by remember(localPath, entryName) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(localPath, entryName) {
        runCatching {
            withContext(Dispatchers.IO) {
                java.util.zip.ZipFile(File(localPath)).use { zip ->
                    decodeOfficeZipBitmap(zip, entryName)
                }
            }
        }.onSuccess { fresh ->
            val old = bitmap
            bitmap = fresh
            old?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure { error ->
            if (error !is kotlinx.coroutines.CancellationException) {
                onMessage(error.message ?: "No se pudo mostrar una imagen del documento.")
            }
        }
    }
    DisposableEffect(localPath, entryName) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }
    val current = bitmap
    if (current != null) {
        Image(
            bitmap = current.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = modifier,
            colorFilter = if (inverted) officeInvertColorFilter() else null
        )
    } else {
        Box(modifier.background(if (inverted) Color(0xFF1E1E1E) else Color(0xFFF1F1F1)), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = NeonGreen, strokeWidth = 2.dp)
        }
    }
}


private fun decodeOfficeZipBitmap(zip: java.util.zip.ZipFile, entryName: String): Bitmap {
    val entry = zip.getEntry(entryName) ?: error("Imagen no encontrada")
    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    zip.getInputStream(entry).use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    val largest = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
    while (largest / sample > 2200) sample *= 2
    val options = android.graphics.BitmapFactory.Options().apply {
        inSampleSize = sample.coerceAtLeast(1)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return zip.getInputStream(entry).use { input ->
        android.graphics.BitmapFactory.decodeStream(input, null, options)
    } ?: error("Imagen no compatible")
}

private fun officeInvertColorFilter(): androidx.compose.ui.graphics.ColorFilter =
    androidx.compose.ui.graphics.ColorFilter.colorMatrix(
        androidx.compose.ui.graphics.ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

private fun shareDocumentFile(context: android.content.Context, uri: Uri, mime: String) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = mime
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { context.startActivity(android.content.Intent.createChooser(intent, "Compartir archivo")) }
}

private suspend fun copyOfficeToViewerCache(
    context: android.content.Context,
    source: Uri,
    type: OfficeViewerType
): File = withContext(Dispatchers.IO) {
    val directory = File(context.cacheDir, "office_viewer").apply { mkdirs() }
    directory.listFiles()?.forEach { old ->
        if (System.currentTimeMillis() - old.lastModified() > 6 * 60 * 60 * 1000L) runCatching { old.delete() }
    }
    val extension = type.extensions.lowercase()
    val file = File(directory, "viewer_${System.currentTimeMillis()}_${kotlin.random.Random.nextInt(1000, 9999)}.$extension")
    try {
        runInterruptible {
            val cancellationSignal = CancellationSignal()
            val copiedFromDescriptor = try {
                context.contentResolver.openFileDescriptor(source, "r", cancellationSignal)?.use { descriptor ->
                    FileInputStream(descriptor.fileDescriptor).use { input ->
                        FileOutputStream(file).use { output ->
                            val buffer = ByteArray(256 * 1024)
                            while (true) {
                                ensureViewerWorkerThreadActive()
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                            }
                            output.fd.sync()
                        }
                    }
                    true
                } ?: false
            } catch (error: Throwable) {
                ensureViewerWorkerThreadActive(error)
                false
            }
            ensureViewerWorkerThreadActive()

            if (!copiedFromDescriptor || file.length() <= 0L) {
                runCatching { file.delete() }
                val copiedFromStream = context.contentResolver.openInputStream(source)?.use { input ->
                    FileOutputStream(file).use { output ->
                        val buffer = ByteArray(256 * 1024)
                        while (true) {
                            ensureViewerWorkerThreadActive()
                            val count = input.read(buffer)
                            if (count < 0) break
                            output.write(buffer, 0, count)
                        }
                        output.fd.sync()
                    }
                    true
                } ?: false
                require(copiedFromStream) { "No se pudo leer el archivo seleccionado." }
            }
        }
        require(file.length() > 0) { "El archivo está vacío." }
        java.util.zip.ZipFile(file).use { require(it.entries().hasMoreElements()) { "El archivo no tiene contenido OOXML válido." } }
        file
    } catch (error: Throwable) {
        runCatching { file.delete() }
        throw error
    }
}

private fun parseDocxModel(file: File): WordDocumentModel {
    java.util.zip.ZipFile(file).use { zip ->
        val documentEntry = zip.getEntry("word/document.xml") ?: error("El DOCX no contiene document.xml.")
        val relationships = parseZipRelationships(zip, "word/_rels/document.xml.rels", "word/document.xml")
        val rawPages = mutableListOf<MutableList<WordBlockModel>>(mutableListOf())
        var paragraphText = StringBuilder()
        var paragraphImages = mutableListOf<WordBlockModel.Picture>()
        var inParagraph = false
        var drawingDepth = -1
        var drawingWidthEmu: Long? = null
        var drawingHeightEmu: Long? = null
        var pageWidthTwips = 11906
        var pageHeightTwips = 16838
        var marginLeftTwips = 900
        var marginRightTwips = 900
        var marginTopTwips = 900
        var marginBottomTwips = 900
        var pageBreak = false
        var explicitBreakSeen = false
        var tableDepth = -1
        var rowDepth = -1
        var cellDepth = -1
        var tableRows = mutableListOf<MutableList<String>>()
        var currentRow = mutableListOf<String>()
        var currentCell = StringBuilder()

        val parser = Xml.newPullParser()
        zip.getInputStream(documentEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "tbl" -> if (tableDepth < 0) {
                            tableDepth = parser.depth
                            tableRows = mutableListOf()
                        }
                        "tr" -> if (tableDepth > 0 && rowDepth < 0) {
                            rowDepth = parser.depth
                            currentRow = mutableListOf()
                        }
                        "tc" -> if (tableDepth > 0 && cellDepth < 0) {
                            cellDepth = parser.depth
                            currentCell = StringBuilder()
                        }
                        "p" -> {
                            inParagraph = true
                            paragraphText = StringBuilder()
                            paragraphImages = mutableListOf()
                            pageBreak = false
                        }
                        "drawing" -> if (inParagraph) {
                            drawingDepth = parser.depth
                            drawingWidthEmu = null
                            drawingHeightEmu = null
                        }
                        "extent" -> if (inParagraph && drawingDepth > 0 && drawingWidthEmu == null) {
                            drawingWidthEmu = attributeByLocalName(parser, "cx")?.toLongOrNull()?.takeIf { it > 0L }
                            drawingHeightEmu = attributeByLocalName(parser, "cy")?.toLongOrNull()?.takeIf { it > 0L }
                        }
                        "pgSz" -> {
                            pageWidthTwips = attributeByLocalName(parser, "w")?.toIntOrNull()?.takeIf { it > 0 } ?: pageWidthTwips
                            pageHeightTwips = attributeByLocalName(parser, "h")?.toIntOrNull()?.takeIf { it > 0 } ?: pageHeightTwips
                        }
                        "pgMar" -> {
                            marginLeftTwips = attributeByLocalName(parser, "left")?.toIntOrNull()?.takeIf { it >= 0 } ?: marginLeftTwips
                            marginRightTwips = attributeByLocalName(parser, "right")?.toIntOrNull()?.takeIf { it >= 0 } ?: marginRightTwips
                            marginTopTwips = attributeByLocalName(parser, "top")?.toIntOrNull()?.takeIf { it >= 0 } ?: marginTopTwips
                            marginBottomTwips = attributeByLocalName(parser, "bottom")?.toIntOrNull()?.takeIf { it >= 0 } ?: marginBottomTwips
                        }
                        "t" -> if (inParagraph) paragraphText.append(parser.nextText())
                        "tab" -> if (inParagraph) paragraphText.append('\t')
                        "br" -> if (inParagraph) {
                            val type = attributeByLocalName(parser, "type")
                            if (type == "page") { pageBreak = true; explicitBreakSeen = true } else paragraphText.append('\n')
                        }
                        "lastRenderedPageBreak" -> if (inParagraph) { pageBreak = true; explicitBreakSeen = true }
                        "blip" -> if (inParagraph) {
                            val relId = attributeByLocalName(parser, "embed")
                            relId?.let { relationships[it] }?.let { entryName ->
                                paragraphImages += WordBlockModel.Picture(
                                    entryName = entryName,
                                    widthEmu = drawingWidthEmu,
                                    heightEmu = drawingHeightEmu
                                )
                            }
                        }
                    }
                    XmlPullParser.END_TAG -> when {
                        parser.name == "p" && inParagraph -> {
                            val text = paragraphText.toString().trim()
                            if (tableDepth > 0 && cellDepth > 0) {
                                if (text.isNotBlank()) {
                                    if (currentCell.isNotEmpty()) currentCell.append('\n')
                                    currentCell.append(text)
                                }
                            } else {
                                if (text.isNotBlank()) rawPages.last().add(WordBlockModel.Paragraph(text))
                                paragraphImages
                                    .distinctBy { Triple(it.entryName, it.widthEmu, it.heightEmu) }
                                    .forEach { rawPages.last().add(it) }
                                if (pageBreak && rawPages.last().isNotEmpty()) rawPages.add(mutableListOf())
                            }
                            inParagraph = false
                        }
                        parser.name == "drawing" && drawingDepth > 0 && parser.depth == drawingDepth -> {
                            drawingDepth = -1
                            drawingWidthEmu = null
                            drawingHeightEmu = null
                        }
                        parser.name == "tc" && cellDepth > 0 && parser.depth == cellDepth -> {
                            currentRow += currentCell.toString().trim()
                            currentCell = StringBuilder()
                            cellDepth = -1
                        }
                        parser.name == "tr" && rowDepth > 0 && parser.depth == rowDepth -> {
                            tableRows += currentRow
                            currentRow = mutableListOf()
                            rowDepth = -1
                        }
                        parser.name == "tbl" && tableDepth > 0 && parser.depth == tableDepth -> {
                            if (tableRows.isNotEmpty()) rawPages.last().add(WordBlockModel.Table(tableRows.map { it.toList() }))
                            tableRows = mutableListOf()
                            tableDepth = -1
                        }
                    }
                }
                event = parser.next()
            }
        }
        if (rawPages.lastOrNull()?.isEmpty() == true && rawPages.size > 1) rawPages.removeAt(rawPages.lastIndex)
        val geometry = WordPageGeometry(
            widthTwips = pageWidthTwips,
            heightTwips = pageHeightTwips,
            marginLeftTwips = marginLeftTwips,
            marginRightTwips = marginRightTwips,
            marginTopTwips = marginTopTwips,
            marginBottomTwips = marginBottomTwips
        )
        val pages = if (explicitBreakSeen) {
            rawPages.filter { it.isNotEmpty() }.map { WordPageModel(it.toList()) }
        } else repaginateWord(rawPages, geometry)
        require(pages.isNotEmpty()) { "El DOCX no contiene contenido visible." }
        return WordDocumentModel(pages, geometry)
    }
}

private fun repaginateWord(
    rawPages: List<List<WordBlockModel>>,
    geometry: WordPageGeometry
): List<WordPageModel> {
    val result = mutableListOf<WordPageModel>()
    rawPages.forEach { raw ->
        var current = mutableListOf<WordBlockModel>()
        var cost = 0
        fun flush() {
            if (current.isNotEmpty()) {
                result += WordPageModel(current)
                current = mutableListOf()
                cost = 0
            }
        }
        raw.forEach { block ->
            val blockCost = when (block) {
                is WordBlockModel.Paragraph -> 1 + block.text.length / 95
                is WordBlockModel.Picture -> {
                    val heightShare = block.heightEmu
                        ?.toFloat()
                        ?.div(geometry.heightEmu.toFloat().coerceAtLeast(1f))
                        ?.coerceIn(0.08f, 1f)
                    if (heightShare != null) (4f + heightShare * 24f).roundToInt().coerceIn(6, 28) else 7
                }
                is WordBlockModel.Table -> 3 + block.rows.size * 2
            }
            if (cost + blockCost > 28 && current.isNotEmpty()) flush()
            current += block
            cost += blockCost
        }
        flush()
    }
    return result
}

private fun parseXlsxWorkbook(file: File): ExcelWorkbookModel {
    java.util.zip.ZipFile(file).use { zip ->
        val shared = zip.getEntry("xl/sharedStrings.xml")?.let { entry ->
            zip.getInputStream(entry).use(::parseSharedStringsStream)
        }.orEmpty()
        val themeColors = zip.getEntry("xl/theme/theme1.xml")?.let { entry ->
            zip.getInputStream(entry).use(::parseOfficeThemeColorsStream)
        }.orEmpty()
        val styles = zip.getEntry("xl/styles.xml")?.let { entry ->
            zip.getInputStream(entry).use { parseExcelStylesStream(it, themeColors) }
        }.orEmpty().ifEmpty { listOf(ExcelCellStyleModel()) }
        val relationships = parseZipRelationships(zip, "xl/_rels/workbook.xml.rels", "xl/workbook.xml")
        val workbookEntry = zip.getEntry("xl/workbook.xml") ?: error("El XLSX no contiene workbook.xml.")
        val sheets = mutableListOf<ExcelSheetRef>()
        val parser = Xml.newPullParser()
        zip.getInputStream(workbookEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name == "sheet") {
                    val name = parser.getAttributeValue(null, "name").orEmpty().ifBlank { "Hoja ${sheets.size + 1}" }
                    val relId = relationshipIdAttribute(parser)
                    val target = relId?.let { relationships[it] }
                    if (!target.isNullOrBlank()) sheets += ExcelSheetRef(name, target)
                }
                event = parser.next()
            }
        }
        require(sheets.isNotEmpty()) { "El XLSX no contiene hojas legibles." }
        return ExcelWorkbookModel(shared, sheets, styles)
    }
}

private suspend fun parseXlsxSheet(
    file: File,
    ref: ExcelSheetRef,
    shared: List<String>,
    styles: List<ExcelCellStyleModel>,
    rowLimit: Int? = null
): ExcelSheetData {
    java.util.zip.ZipFile(file).use { zip ->
        val entry = zip.getEntry(ref.entryName) ?: error("No se encontró la hoja ${ref.name}.")
        val rows = linkedMapOf<Int, ExcelRowData>()
        val columnWidths = mutableMapOf<Int, Float>()
        var rowNumber = 0
        var rowHeightPoints: Float? = null
        var cells = linkedMapOf<Int, ExcelCellData>()
        var cellRef = ""
        var cellType: String? = null
        var cellStyleIndex = 0
        var value = StringBuilder()
        var inline = StringBuilder()
        var formula = StringBuilder()
        var captureValue = false
        var captureInline = false
        var captureFormula = false
        var maxColumn = 0
        var maxRow = 1
        var declaredMaxColumn = 0
        var declaredMaxRow = 0
        var stoppedEarly = false
        val parser = Xml.newPullParser()
        zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            var eventCounter = 0
            while (event != XmlPullParser.END_DOCUMENT) {
                if (++eventCounter % 256 == 0) currentCoroutineContext().ensureActive()
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "dimension" -> {
                            val range = parser.getAttributeValue(null, "ref").orEmpty()
                            val lastCell = range.substringAfterLast(':', range)
                            declaredMaxColumn = maxOf(declaredMaxColumn, excelColumnIndex(lastCell) + 1)
                            declaredMaxRow = maxOf(
                                declaredMaxRow,
                                lastCell.filter { it.isDigit() }.toIntOrNull() ?: 0
                            )
                        }
                        "col" -> {
                            val minCol = parser.getAttributeValue(null, "min")?.toIntOrNull()?.minus(1) ?: -1
                            val maxCol = parser.getAttributeValue(null, "max")?.toIntOrNull()?.minus(1) ?: minCol
                            val width = parser.getAttributeValue(null, "width")?.toFloatOrNull()
                            if (minCol >= 0 && maxCol >= minCol && width != null) {
                                for (col in minCol..maxCol.coerceAtMost(255)) columnWidths[col] = width
                                maxColumn = maxOf(maxColumn, maxCol + 1)
                            }
                        }
                        "row" -> {
                            val nextRow = parser.getAttributeValue(null, "r")?.toIntOrNull()
                                ?: (rowNumber + 1).coerceAtLeast(1)
                            if (rowLimit != null && nextRow > rowLimit) {
                                stoppedEarly = true
                            } else {
                                rowNumber = nextRow
                                rowHeightPoints = parser.getAttributeValue(null, "ht")?.toFloatOrNull()
                                cells = linkedMapOf()
                                maxRow = maxOf(maxRow, rowNumber)
                            }
                        }
                        "c" -> {
                            cellRef = parser.getAttributeValue(null, "r").orEmpty()
                            cellType = parser.getAttributeValue(null, "t")
                            cellStyleIndex = parser.getAttributeValue(null, "s")?.toIntOrNull() ?: 0
                            value = StringBuilder()
                            inline = StringBuilder()
                            formula = StringBuilder()
                        }
                        "v" -> captureValue = true
                        "t" -> captureInline = true
                        "f" -> captureFormula = true
                    }
                    XmlPullParser.TEXT -> {
                        if (captureValue) value.append(parser.text.orEmpty())
                        if (captureInline) inline.append(parser.text.orEmpty())
                        if (captureFormula) formula.append(parser.text.orEmpty())
                    }
                    XmlPullParser.END_TAG -> when (parser.name) {
                        "v" -> captureValue = false
                        "t" -> captureInline = false
                        "f" -> captureFormula = false
                        "c" -> {
                            val col = excelColumnIndex(cellRef)
                            if (col >= 0) {
                                val raw = value.toString()
                                val style = styles.getOrNull(cellStyleIndex)
                                val shown = when (cellType) {
                                    "s" -> shared.getOrNull(raw.toIntOrNull() ?: -1).orEmpty()
                                    "inlineStr", "str" -> inline.toString().ifBlank { raw }
                                    "b" -> if (raw == "1") "VERDADERO" else if (raw == "0") "FALSO" else raw
                                    else -> {
                                        val base = raw.ifBlank {
                                            formula.toString().takeIf { it.isNotBlank() }?.let { "=$it" }.orEmpty()
                                        }
                                        if (raw.isNotBlank()) formatExcelNumericValue(raw, style?.numberFormatCode) else base
                                    }
                                }
                                if (shown.isNotBlank() || cellStyleIndex != 0) {
                                    cells[col] = ExcelCellData(shown, cellStyleIndex)
                                }
                                maxColumn = maxOf(maxColumn, col + 1)
                            }
                        }
                        "row" -> if (rowNumber > 0) {
                            rows[rowNumber] = ExcelRowData(rowNumber, cells.toMap(), rowHeightPoints)
                        }
                    }
                }
                if (stoppedEarly) break
                event = parser.next()
            }
        }
        val totalHint = maxOf(declaredMaxRow, maxRow)
        val visibleRows = maxOf(60, totalHint, maxRow).coerceAtMost(200_000)
        return ExcelSheetData(
            rows = rows,
            maxColumns = maxOf(maxColumn, declaredMaxColumn).coerceAtLeast(1).coerceAtMost(256),
            maxRows = visibleRows,
            columnWidths = columnWidths.toMap(),
            totalRowsHint = totalHint.coerceAtLeast(visibleRows),
            isComplete = !stoppedEarly
        )
    }
}

private fun parseExcelStylesStream(
    input: java.io.InputStream,
    themeColors: Map<Int, Int>
): List<ExcelCellStyleModel> {
    data class FontStyle(val color: Int?, val bold: Boolean, val sizePt: Float?)
    val fonts = mutableListOf<FontStyle>()
    val fills = mutableListOf<Int?>()
    val styles = mutableListOf<ExcelCellStyleModel>()
    val customNumFormats = mutableMapOf<Int, String>()
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    var fontsDepth = -1
    var fillsDepth = -1
    var cellXfsDepth = -1
    var fontDepth = -1
    var fillDepth = -1
    var xfDepth = -1
    var fontColor: Int? = null
    var fontBold = false
    var fontSizePt: Float? = null
    var fillColor: Int? = null
    var fillPattern: String? = null
    var xfFontId = 0
    var xfFillId = 0
    var xfNumFmtId = 0
    var xfHorizontal: String? = null
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> when (parser.name) {
                "numFmt" -> {
                    val id = parser.getAttributeValue(null, "numFmtId")?.toIntOrNull()
                    val code = parser.getAttributeValue(null, "formatCode")
                    if (id != null && !code.isNullOrBlank()) customNumFormats[id] = code
                }
                "fonts" -> fontsDepth = parser.depth
                "fills" -> fillsDepth = parser.depth
                "cellXfs" -> cellXfsDepth = parser.depth
                "font" -> if (fontsDepth > 0 && parser.depth == fontsDepth + 1) {
                    fontDepth = parser.depth
                    fontColor = null
                    fontBold = false
                    fontSizePt = null
                }
                "b" -> if (fontDepth > 0) fontBold = true
                "sz" -> if (fontDepth > 0) {
                    fontSizePt = parser.getAttributeValue(null, "val")?.toFloatOrNull() ?: fontSizePt
                }
                "color" -> if (fontDepth > 0) {
                    fontColor = parseExcelStyleColor(parser, themeColors) ?: fontColor
                }
                "fill" -> if (fillsDepth > 0 && parser.depth == fillsDepth + 1) {
                    fillDepth = parser.depth
                    fillColor = null
                    fillPattern = null
                }
                "patternFill" -> if (fillDepth > 0) {
                    fillPattern = parser.getAttributeValue(null, "patternType")
                }
                "fgColor" -> if (fillDepth > 0) {
                    fillColor = parseExcelStyleColor(parser, themeColors) ?: fillColor
                }
                "xf" -> if (cellXfsDepth > 0 && parser.depth == cellXfsDepth + 1) {
                    xfDepth = parser.depth
                    xfFontId = parser.getAttributeValue(null, "fontId")?.toIntOrNull() ?: 0
                    xfFillId = parser.getAttributeValue(null, "fillId")?.toIntOrNull() ?: 0
                    xfNumFmtId = parser.getAttributeValue(null, "numFmtId")?.toIntOrNull() ?: 0
                    xfHorizontal = null
                }
                "alignment" -> if (xfDepth > 0) {
                    xfHorizontal = parser.getAttributeValue(null, "horizontal") ?: xfHorizontal
                }
            }
            XmlPullParser.END_TAG -> when {
                parser.name == "font" && parser.depth == fontDepth -> {
                    fonts += FontStyle(fontColor, fontBold, fontSizePt)
                    fontDepth = -1
                }
                parser.name == "fill" && parser.depth == fillDepth -> {
                    fills += fillColor.takeIf { fillPattern == "solid" }
                    fillDepth = -1
                }
                parser.name == "xf" && parser.depth == xfDepth -> {
                    val font = fonts.getOrNull(xfFontId)
                    styles += ExcelCellStyleModel(
                        fillArgb = fills.getOrNull(xfFillId),
                        textArgb = font?.color,
                        bold = font?.bold == true,
                        fontSizePt = font?.sizePt,
                        horizontal = xfHorizontal,
                        numberFormatCode = customNumFormats[xfNumFmtId] ?: builtInExcelNumberFormat(xfNumFmtId)
                    )
                    xfDepth = -1
                }
                parser.name == "fonts" && parser.depth == fontsDepth -> fontsDepth = -1
                parser.name == "fills" && parser.depth == fillsDepth -> fillsDepth = -1
                parser.name == "cellXfs" && parser.depth == cellXfsDepth -> cellXfsDepth = -1
            }
        }
        event = parser.next()
    }
    return styles.ifEmpty { listOf(ExcelCellStyleModel()) }
}

private fun parseOfficeThemeColorsStream(input: java.io.InputStream): Map<Int, Int> {
    // Orden de índices de tema definido por OOXML/Excel.
    val themeIndex = mapOf(
        "lt1" to 0, "dk1" to 1, "lt2" to 2, "dk2" to 3,
        "accent1" to 4, "accent2" to 5, "accent3" to 6,
        "accent4" to 7, "accent5" to 8, "accent6" to 9,
        "hlink" to 10, "folHlink" to 11
    )
    val colors = mutableMapOf<Int, Int>()
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    var currentIndex: Int? = null
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> {
                themeIndex[parser.name]?.let { currentIndex = it }
                if (parser.name == "srgbClr" || parser.name == "sysClr") {
                    val value = if (parser.name == "sysClr") {
                        parser.getAttributeValue(null, "lastClr") ?: parser.getAttributeValue(null, "val")
                    } else parser.getAttributeValue(null, "val")
                    val color = parseExcelArgb(value)
                    val index = currentIndex
                    if (color != null && index != null) colors[index] = color
                }
            }
            XmlPullParser.END_TAG -> if (themeIndex.containsKey(parser.name)) currentIndex = null
        }
        event = parser.next()
    }
    return colors
}

private fun parseExcelStyleColor(parser: XmlPullParser, themeColors: Map<Int, Int>): Int? {
    val direct = parseExcelArgb(parser.getAttributeValue(null, "rgb"))
    val themed = parser.getAttributeValue(null, "theme")?.toIntOrNull()?.let(themeColors::get)
    val indexed = parser.getAttributeValue(null, "indexed")?.toIntOrNull()?.let(::excelIndexedColor)
    val base = direct ?: themed ?: indexed ?: return null
    val tint = parser.getAttributeValue(null, "tint")?.toFloatOrNull() ?: 0f
    return applyExcelTint(base, tint)
}

private fun applyExcelTint(argb: Int, tint: Float): Int {
    if (tint == 0f) return argb
    fun tintChannel(value: Int): Int {
        val result = if (tint < 0f) value * (1f + tint) else value * (1f - tint) + 255f * tint
        return result.roundToInt().coerceIn(0, 255)
    }
    val a = (argb ushr 24) and 0xFF
    val r = tintChannel((argb ushr 16) and 0xFF)
    val g = tintChannel((argb ushr 8) and 0xFF)
    val b = tintChannel(argb and 0xFF)
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}

private fun excelIndexedColor(index: Int): Int? {
    val palette = intArrayOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt(), 0xFF00FF00.toInt(),
        0xFF0000FF.toInt(), 0xFFFFFF00.toInt(), 0xFFFF00FF.toInt(), 0xFF00FFFF.toInt(),
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt(), 0xFF00FF00.toInt(),
        0xFF0000FF.toInt(), 0xFFFFFF00.toInt(), 0xFFFF00FF.toInt(), 0xFF00FFFF.toInt(),
        0xFF800000.toInt(), 0xFF008000.toInt(), 0xFF000080.toInt(), 0xFF808000.toInt(),
        0xFF800080.toInt(), 0xFF008080.toInt(), 0xFFC0C0C0.toInt(), 0xFF808080.toInt(),
        0xFF9999FF.toInt(), 0xFF993366.toInt(), 0xFFFFFFCC.toInt(), 0xFFCCFFFF.toInt(),
        0xFF660066.toInt(), 0xFFFF8080.toInt(), 0xFF0066CC.toInt(), 0xFFCCCCFF.toInt(),
        0xFF000080.toInt(), 0xFFFF00FF.toInt(), 0xFFFFFF00.toInt(), 0xFF00FFFF.toInt(),
        0xFF800080.toInt(), 0xFF800000.toInt(), 0xFF008080.toInt(), 0xFF0000FF.toInt(),
        0xFF00CCFF.toInt(), 0xFFCCFFFF.toInt(), 0xFFCCFFCC.toInt(), 0xFFFFFF99.toInt(),
        0xFF99CCFF.toInt(), 0xFFFF99CC.toInt(), 0xFFCC99FF.toInt(), 0xFFFFCC99.toInt(),
        0xFF3366FF.toInt(), 0xFF33CCCC.toInt(), 0xFF99CC00.toInt(), 0xFFFFCC00.toInt(),
        0xFFFF9900.toInt(), 0xFFFF6600.toInt(), 0xFF666699.toInt(), 0xFF969696.toInt(),
        0xFF003366.toInt(), 0xFF339966.toInt(), 0xFF003300.toInt(), 0xFF333300.toInt(),
        0xFF993300.toInt(), 0xFF993366.toInt(), 0xFF333399.toInt(), 0xFF333333.toInt()
    )
    return palette.getOrNull(index)
}

private fun builtInExcelNumberFormat(id: Int): String? = when (id) {
    1 -> "0"
    2 -> "0.00"
    3 -> "#,##0"
    4 -> "#,##0.00"
    9 -> "0%"
    10 -> "0.00%"
    14 -> "mm-dd-yy"
    15 -> "d-mmm-yy"
    16 -> "d-mmm"
    17 -> "mmm-yy"
    18 -> "h:mm AM/PM"
    19 -> "h:mm:ss AM/PM"
    20 -> "h:mm"
    21 -> "h:mm:ss"
    22 -> "m/d/yy h:mm"
    else -> null
}

private fun formatExcelNumericValue(raw: String, formatCode: String?): String {
    val value = raw.toDoubleOrNull() ?: return raw
    val code = formatCode?.lowercase().orEmpty()
    if (code.isBlank()) return raw

    if ('%' in code) {
        val decimalPart = code.substringAfter('.', "").takeWhile { it == '0' || it == '#' }
        val decimals = decimalPart.count { it == '0' }.coerceIn(0, 6)
        return java.lang.String.format(java.util.Locale.US, "%.${decimals}f%%", value * 100.0)
    }

    if ((code.contains('y') || code.contains('d')) && (code.contains('m') || code.contains('y'))) {
        return runCatching {
            val wholeDays = kotlin.math.floor(value).toLong()
            val date = java.time.LocalDate.of(1899, 12, 30).plusDays(wholeDays)
            when {
                code.startsWith("yyyy-mm-dd") -> date.toString()
                code.contains("dd/mm/yyyy") -> "%02d/%02d/%04d".format(date.dayOfMonth, date.monthValue, date.year)
                else -> "%02d/%02d/%04d".format(date.dayOfMonth, date.monthValue, date.year)
            }
        }.getOrElse { raw }
    }

    val dot = code.indexOf('.')
    if (dot >= 0) {
        val decimals = code.substring(dot + 1).takeWhile { it == '0' || it == '#' }.count { it == '0' }.coerceIn(0, 8)
        if (decimals > 0) return java.lang.String.format(java.util.Locale.US, "%.${decimals}f", value)
    }
    if (code == "0" || code.contains("#,##0")) {
        return if (value % 1.0 == 0.0) value.toLong().toString() else raw
    }
    return raw
}

private fun parseExcelArgb(value: String?): Int? {
    val clean = value?.trim()?.removePrefix("#") ?: return null
    val raw = clean.toLongOrNull(16) ?: return null
    return when (clean.length) {
        6 -> (0xFF000000L or raw).toInt()
        8 -> {
            val argb = raw.toInt()
            // Excel/OpenPyXL suele escribir 00RRGGBB aunque el color sea opaco.
            if (((argb ushr 24) and 0xFF) == 0) (argb or 0xFF000000.toInt()) else argb
        }
        else -> null
    }
}

private fun parsePptxDeck(file: File): PowerPointDeckModel {
    java.util.zip.ZipFile(file).use { zip ->
        val presentationEntry = zip.getEntry("ppt/presentation.xml") ?: error("El PPTX no contiene presentation.xml.")
        var width = 12192000L
        var height = 6858000L
        val slideRelIds = mutableListOf<String>()
        val parser = Xml.newPullParser()
        zip.getInputStream(presentationEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                ensureViewerWorkerThreadActive()
                if (event == XmlPullParser.START_TAG) {
                    when (parser.name) {
                        "sldSz" -> {
                            width = parser.getAttributeValue(null, "cx")?.toLongOrNull() ?: width
                            height = parser.getAttributeValue(null, "cy")?.toLongOrNull() ?: height
                        }
                        "sldId" -> relationshipIdAttribute(parser)?.let(slideRelIds::add)
                    }
                }
                event = parser.next()
            }
        }
        ensureViewerWorkerThreadActive()
        val presentationRels = parseZipRelationships(zip, "ppt/_rels/presentation.xml.rels", "ppt/presentation.xml")
        val orderedSlides = slideRelIds.mapNotNull { presentationRels[it] }.ifEmpty {
            zip.entries().asSequence().map { it.name }
                .filter { it.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
                .sortedBy { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
                .toList()
        }
        val slides = orderedSlides.mapIndexed { index, slideEntry ->
            ensureViewerWorkerThreadActive()
            parsePowerPointSlide(zip, slideEntry, width, height, index)
        }
        require(slides.isNotEmpty()) { "El PPTX no contiene diapositivas legibles." }
        return PowerPointDeckModel(width, height, slides)
    }
}

private fun parsePowerPointSlide(
    zip: java.util.zip.ZipFile,
    slideEntry: String,
    deckWidth: Long,
    deckHeight: Long,
    slideIndex: Int
): PowerPointSlideModel {
    val entry = zip.getEntry(slideEntry) ?: error("Diapositiva no encontrada.")
    val fileName = slideEntry.substringAfterLast('/')
    val relEntry = slideEntry.substringBeforeLast('/') + "/_rels/$fileName.rels"
    val rels = parseZipRelationships(zip, relEntry, slideEntry)
    val elements = mutableListOf<PowerPointElementModel>()
    var shapeKind: String? = null
    var shapeDepth = -1
    var text = StringBuilder()
    var relId: String? = null
    var x = 0L; var y = 0L; var w = 0L; var h = 0L
    var shapeFillArgb: Int? = null
    var textArgb: Int? = null
    var textFontSizePt: Float? = null
    var textBold = false
    var spPrDepth = -1
    var rPrDepth = -1
    var solidFillDepth = -1
    var lineDepth = -1
    var transitionType: String? = null
    var transitionDirection: String? = null
    var transitionOrientation: String? = null
    var transitionDurationMs = 900
    var transitionDurationExplicit = false
    var transitionSpokes: Int? = null
    var transitionParameters: Map<String, String> = emptyMap()
    var advanceAfterMs: Long? = null
    var transitionDepth = -1
    var backgroundArgb: Int? = null
    var bgDepth = -1
    var bgSolidFillDepth = -1

    val parser = Xml.newPullParser()
    zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            ensureViewerWorkerThreadActive()
            when (event) {
                XmlPullParser.START_TAG -> {
                    if (parser.name == "bg" && shapeKind == null) bgDepth = parser.depth
                    if (bgDepth > 0 && parser.name == "solidFill") bgSolidFillDepth = parser.depth
                    if (bgSolidFillDepth > 0 && parser.name == "srgbClr" && backgroundArgb == null) {
                        backgroundArgb = parseRgbArgb(parser.getAttributeValue(null, "val"))
                    }

                    if ((parser.name == "sp" || parser.name == "pic") && shapeKind == null) {
                        shapeKind = parser.name
                        shapeDepth = parser.depth
                        text = StringBuilder(); relId = null; x = 0; y = 0; w = 0; h = 0
                        shapeFillArgb = null; textArgb = null; textFontSizePt = null; textBold = false
                        spPrDepth = -1; rPrDepth = -1; solidFillDepth = -1; lineDepth = -1
                    } else if (
                        parser.name == "transition" && shapeKind == null &&
                        transitionType == null && transitionDepth < 0
                    ) {
                        // Capturamos una sola representacion de la transicion. Esto es importante
                        // con mc:AlternateContent: no debemos mezclar el tipo de p14:Choice con
                        // la velocidad del p:Fallback que aparece despues en el mismo XML.
                        transitionDepth = parser.depth
                        advanceAfterMs = attributeByLocalName(parser, "advTm")?.toLongOrNull()
                        val explicitDuration = attributeByLocalName(parser, "dur")?.toLongOrNull()
                        if (explicitDuration != null) {
                            transitionDurationMs = explicitDuration.coerceIn(0L, 60_000L).toInt()
                            transitionDurationExplicit = true
                        } else {
                            transitionDurationExplicit = false
                            // spd no da milisegundos exactos; solo se usa como respaldo para
                            // PPTX antiguos que no contienen p14:dur. Se dejan tiempos suficientemente
                            // completos para que el efecto sea visible de principio a fin.
                            transitionDurationMs = when (attributeByLocalName(parser, "spd")?.lowercase()) {
                                "slow" -> 1500
                                "fast" -> 500
                                else -> 900
                            }
                        }
                    } else if (transitionDepth > 0 && parser.depth == transitionDepth + 1 && transitionType == null) {
                        transitionType = parser.name
                        transitionDirection = attributeByLocalName(parser, "dir")
                        transitionOrientation = attributeByLocalName(parser, "orient")
                        transitionSpokes = attributeByLocalName(parser, "spokes")?.toIntOrNull()
                        transitionParameters = buildMap {
                            for (attributeIndex in 0 until parser.attributeCount) {
                                val name = parser.getAttributeName(attributeIndex) ?: continue
                                val value = parser.getAttributeValue(attributeIndex) ?: continue
                                put(name, value)
                            }
                        }
                    }

                    if (shapeKind != null) {
                        when (parser.name) {
                            "spPr" -> spPrDepth = parser.depth
                            "rPr", "defRPr", "endParaRPr" -> {
                                rPrDepth = parser.depth
                                parser.getAttributeValue(null, "sz")?.toFloatOrNull()?.let { size ->
                                    if (textFontSizePt == null) textFontSizePt = size / 100f
                                }
                                val boldValue = parser.getAttributeValue(null, "b")
                                if (boldValue == "1" || boldValue.equals("true", true)) textBold = true
                            }
                            "ln" -> if (spPrDepth > 0) lineDepth = parser.depth
                            "solidFill" -> solidFillDepth = parser.depth
                            "srgbClr" -> {
                                val color = parseRgbArgb(parser.getAttributeValue(null, "val"))
                                if (color != null) {
                                    if (rPrDepth > 0) textArgb = textArgb ?: color
                                    else if (spPrDepth > 0 && solidFillDepth > 0 && lineDepth < 0) shapeFillArgb = shapeFillArgb ?: color
                                }
                            }
                            "t" -> text.append(parser.nextText())
                            "p" -> if (text.isNotEmpty() && text.last() != '\n') text.append('\n')
                            "off" -> {
                                x = parser.getAttributeValue(null, "x")?.toLongOrNull() ?: x
                                y = parser.getAttributeValue(null, "y")?.toLongOrNull() ?: y
                            }
                            "ext" -> {
                                w = parser.getAttributeValue(null, "cx")?.toLongOrNull() ?: w
                                h = parser.getAttributeValue(null, "cy")?.toLongOrNull() ?: h
                            }
                            "blip" -> relId = attributeByLocalName(parser, "embed") ?: relId
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "solidFill" -> {
                            if (parser.depth == solidFillDepth) solidFillDepth = -1
                            if (parser.depth == bgSolidFillDepth) bgSolidFillDepth = -1
                        }
                        "spPr" -> if (parser.depth == spPrDepth) spPrDepth = -1
                        "ln" -> if (parser.depth == lineDepth) lineDepth = -1
                        "rPr", "defRPr", "endParaRPr" -> if (parser.depth == rPrDepth) rPrDepth = -1
                        "bg" -> if (parser.depth == bgDepth) bgDepth = -1
                    }
                    if (transitionDepth > 0 && parser.name == "transition" && parser.depth == transitionDepth) transitionDepth = -1
                    if (shapeKind != null && parser.depth == shapeDepth && parser.name == shapeKind) {
                        val fallbackIndex = elements.size
                        val finalX = if (w > 0) x else deckWidth / 12
                        val finalY = if (h > 0) y else deckHeight / 12 + fallbackIndex * (deckHeight / 7)
                        val finalW = if (w > 0) w else deckWidth * 5 / 6
                        val finalH = if (h > 0) h else deckHeight / 6
                        when (shapeKind) {
                            "sp" -> {
                                shapeFillArgb?.let { elements += PowerPointElementModel.Rectangle(it, finalX, finalY, finalW, finalH) }
                                text.toString().trim().takeIf { it.isNotBlank() }?.let {
                                    elements += PowerPointElementModel.TextBox(it, textArgb, textFontSizePt, textBold, finalX, finalY, finalW, finalH)
                                }
                            }
                            "pic" -> relId?.let { rels[it] }?.let {
                                elements += PowerPointElementModel.Picture(it, finalX, finalY, finalW, finalH)
                            }
                        }
                        shapeKind = null
                        shapeDepth = -1
                    }
                }
            }
            event = parser.next()
        }
    }
    if (elements.isEmpty()) {
        elements += PowerPointElementModel.TextBox(
            "Diapositiva ${slideIndex + 1}", null, 24f, true,
            deckWidth / 10, deckHeight / 3, deckWidth * 4 / 5, deckHeight / 4
        )
    }
    val transition = transitionType?.let {
        PowerPointTransitionModel(
            type = it,
            direction = transitionDirection,
            orientation = transitionOrientation,
            durationMs = transitionDurationMs,
            durationExplicit = transitionDurationExplicit,
            spokes = transitionSpokes,
            parameters = transitionParameters
        )
    }
    return PowerPointSlideModel(elements, transition, advanceAfterMs, backgroundArgb)
}

private fun parseRgbArgb(value: String?): Int? {
    val clean = value?.trim()?.removePrefix("#") ?: return null
    if (clean.length != 6) return null
    val rgb = clean.toLongOrNull(16) ?: return null
    return (0xFF000000L or rgb).toInt()
}

private fun invertArgb(argb: Int): Int {
    val a = (argb ushr 24) and 0xFF
    val r = 255 - ((argb ushr 16) and 0xFF)
    val g = 255 - ((argb ushr 8) and 0xFF)
    val b = 255 - (argb and 0xFF)
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}

private fun pptIsDark(argb: Int): Boolean {
    val r = (argb ushr 16) and 0xFF
    val g = (argb ushr 8) and 0xFF
    val b = argb and 0xFF
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) < 145.0
}

private fun parseZipRelationships(
    zip: java.util.zip.ZipFile,
    relEntryName: String,
    sourceEntryName: String
): Map<String, String> {
    val entry = zip.getEntry(relEntryName) ?: return emptyMap()
    val result = linkedMapOf<String, String>()
    val parser = Xml.newPullParser()
    zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            ensureViewerWorkerThreadActive()
            if (event == XmlPullParser.START_TAG && parser.name == "Relationship") {
                val id = parser.getAttributeValue(null, "Id").orEmpty()
                val target = parser.getAttributeValue(null, "Target").orEmpty()
                val mode = parser.getAttributeValue(null, "TargetMode")
                if (id.isNotBlank() && target.isNotBlank() && !mode.equals("External", true)) {
                    result[id] = resolveZipTarget(sourceEntryName, target)
                }
            }
            event = parser.next()
        }
    }
    return result
}

private fun resolveZipTarget(sourceEntryName: String, target: String): String {
    if (target.startsWith('/')) return target.removePrefix("/")
    val base = sourceEntryName.substringBeforeLast('/', "")
    val combined = if (base.isBlank()) target else "$base/$target"
    val parts = mutableListOf<String>()
    combined.split('/').forEach { part ->
        when (part) {
            "", "." -> Unit
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
            else -> parts += part
        }
    }
    return parts.joinToString("/")
}

private fun attributeByLocalName(parser: XmlPullParser, localName: String): String? {
    for (index in 0 until parser.attributeCount) {
        val name = parser.getAttributeName(index)
        if (name == localName || name.substringAfter(':') == localName) {
            return parser.getAttributeValue(index)
        }
    }
    return null
}

private fun relationshipIdAttribute(parser: XmlPullParser): String? {
    // OOXML nodes such as p:sldId contain both a numeric `id` and an `r:id`.
    // Prefer the relationships namespace/prefix so slide/sheet ordering resolves correctly.
    for (index in 0 until parser.attributeCount) {
        val name = parser.getAttributeName(index)
        if (name != "id" && name != "r:id") continue
        val namespace = runCatching { parser.getAttributeNamespace(index) }.getOrNull().orEmpty()
        if (namespace.contains("relationships", ignoreCase = true) || name == "r:id") {
            return parser.getAttributeValue(index)
        }
    }
    // Most producers use rIdN. This fallback also works if namespace processing is disabled.
    for (index in 0 until parser.attributeCount) {
        val value = parser.getAttributeValue(index).orEmpty()
        if (value.startsWith("rId", ignoreCase = true)) return value
    }
    return null
}

private fun parseSharedStringsStream(input: java.io.InputStream): List<String> {
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    val values = mutableListOf<String>()
    var insideSi = false
    var current = StringBuilder()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> if (parser.name == "si") { insideSi = true; current = StringBuilder() }
            XmlPullParser.TEXT -> if (insideSi) current.append(parser.text.orEmpty())
            XmlPullParser.END_TAG -> if (parser.name == "si") { values += current.toString(); insideSi = false }
        }
        event = parser.next()
    }
    return values
}

private fun excelColumnIndex(cellRef: String): Int {
    var result = 0
    var found = false
    for (char in cellRef) {
        if (!char.isLetter()) break
        found = true
        result = result * 26 + (char.uppercaseChar() - 'A' + 1)
    }
    return if (found) result - 1 else -1
}

private fun excelColumnName(index: Int): String {
    var value = index + 1
    val out = StringBuilder()
    while (value > 0) {
        val rem = (value - 1) % 26
        out.append(('A'.code + rem).toChar())
        value = (value - 1) / 26
    }
    return out.reverse().toString()
}


private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
