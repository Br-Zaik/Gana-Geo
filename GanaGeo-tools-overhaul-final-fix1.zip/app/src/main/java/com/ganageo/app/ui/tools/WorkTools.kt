package com.ganageo.app.ui.tools

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.InventoryItem
import com.ganageo.app.data.InventoryStore
import com.ganageo.app.data.WorkChecklistItem
import com.ganageo.app.data.WorkChecklistStore
import com.ganageo.app.data.WorkLedgerEntry
import com.ganageo.app.data.WorkLedgerStore
import com.ganageo.app.tools.CommerceCalculator
import com.ganageo.app.tools.WorkPayCalculator
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import java.util.Locale
import kotlinx.coroutines.launch

private data class QuoteLine(
    val id: Long,
    val description: String,
    val quantity: Double,
    val unitPrice: Double
)

private data class CvExperienceDraft(
    val role: String = "",
    val company: String = "",
    val period: String = "",
    val details: String = ""
)

private data class CvEducationDraft(
    val degree: String = "",
    val institution: String = "",
    val period: String = ""
)

private data class CvDocumentData(
    val fullName: String,
    val desiredRole: String,
    val phone: String,
    val email: String,
    val city: String,
    val profile: String,
    val experiences: List<CvExperienceDraft>,
    val education: List<CvEducationDraft>,
    val skills: String,
    val languages: String,
    val certifications: String,
    val projects: String,
    val links: String,
    val templateIndex: Int
)

@Composable
fun CvBuilderScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var fullName by rememberSaveable { mutableStateOf("") }
    var desiredRole by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var city by rememberSaveable { mutableStateOf("") }
    var profile by rememberSaveable { mutableStateOf("") }
    var skills by rememberSaveable { mutableStateOf("") }
    var languages by rememberSaveable { mutableStateOf("") }
    var certifications by rememberSaveable { mutableStateOf("") }
    var projects by rememberSaveable { mutableStateOf("") }
    var links by rememberSaveable { mutableStateOf("") }
    var templateIndex by rememberSaveable { mutableStateOf(0) }
    var previewOnly by rememberSaveable { mutableStateOf(false) }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    val experiences = remember { mutableStateListOf(CvExperienceDraft()) }
    val education = remember { mutableStateListOf(CvEducationDraft()) }
    var pendingPdf by remember { mutableStateOf<CvDocumentData?>(null) }
    var pendingText by remember { mutableStateOf<String?>(null) }

    val snapshot = CvDocumentData(
        fullName = fullName,
        desiredRole = desiredRole,
        phone = phone,
        email = email,
        city = city,
        profile = profile,
        experiences = experiences.toList(),
        education = education.toList(),
        skills = skills,
        languages = languages,
        certifications = certifications,
        projects = projects,
        links = links,
        templateIndex = templateIndex
    )
    val cvText = remember(snapshot) { buildProfessionalCvText(snapshot) }
    val isReady = fullName.isNotBlank() && (profile.isNotBlank() || experiences.any { it.role.isNotBlank() || it.company.isNotBlank() } || education.any { it.degree.isNotBlank() })

    val txtLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val content = pendingText
        if (uri != null && content != null) {
            runCatching { saveText(context, uri.toString(), content) }
                .onSuccess { message = "CV guardado como texto" }
                .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
        }
        pendingText = null
    }

    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val data = pendingPdf
        pendingPdf = null
        if (uri == null || data == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                createProfessionalCvPdf(context, uri, data)
                message = "CV PDF guardado"
            } catch (error: Throwable) {
                message = "Error: ${error.message ?: "No se pudo crear el PDF"}"
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Constructor de CV", "CV profesional con secciones, vista previa y PDF", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Diseño del currículum", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        SimpleDropdown("Plantilla", listOf("Moderno", "Clásico", "Compacto"), templateIndex) { templateIndex = it }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { previewOnly = false },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (!previewOnly) NeonGreen else CardGreen,
                                    contentColor = if (!previewOnly) DeepGreen else MaterialTheme.colorScheme.onSurface
                                )
                            ) { Text("Editar", fontWeight = FontWeight.Bold) }
                            Button(
                                onClick = { previewOnly = true },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (previewOnly) NeonGreen else CardGreen,
                                    contentColor = if (previewOnly) DeepGreen else MaterialTheme.colorScheme.onSurface
                                )
                            ) { Text("Vista previa", fontWeight = FontWeight.Bold) }
                        }
                        Text(
                            "El PDF final usa tamaño A4 y conserva una estructura limpia. No necesitas acomodar espacios manualmente.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (!previewOnly) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Datos personales", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            OutlinedTextField(fullName, { fullName = it.take(120) }, label = { Text("Nombre completo *") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(desiredRole, { desiredRole = it.take(120) }, label = { Text("Puesto o especialidad") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(phone, { phone = it.take(30) }, label = { Text("Teléfono") }, modifier = Modifier.weight(1f), singleLine = true)
                                OutlinedTextField(city, { city = it.take(80) }, label = { Text("Ciudad") }, modifier = Modifier.weight(1f), singleLine = true)
                            }
                            OutlinedTextField(email, { email = it.take(120) }, label = { Text("Correo") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(links, { links = it.take(240) }, label = { Text("LinkedIn / portafolio / enlace") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Perfil profesional", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                profile,
                                { profile = it.take(1200) },
                                label = { Text("Resumen de 3 a 5 líneas") },
                                placeholder = { Text("Quién eres, qué sabes hacer y qué valor aportas.") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 4
                            )
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Experiencia", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                IconButton(onClick = { experiences.add(CvExperienceDraft()) }) { Icon(Icons.Rounded.Add, "Agregar experiencia", tint = NeonGreen) }
                            }
                            experiences.forEachIndexed { index, entry ->
                                Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.06f)), shape = RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Experiencia ${index + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                            IconButton(onClick = {
                                                if (index > 0) {
                                                    val item = experiences.removeAt(index)
                                                    experiences.add(index - 1, item)
                                                }
                                            }, enabled = index > 0) { Icon(Icons.Rounded.ArrowUpward, "Subir") }
                                            IconButton(onClick = {
                                                if (index < experiences.lastIndex) {
                                                    val item = experiences.removeAt(index)
                                                    experiences.add(index + 1, item)
                                                }
                                            }, enabled = index < experiences.lastIndex) { Icon(Icons.Rounded.ArrowDownward, "Bajar") }
                                            IconButton(onClick = { if (experiences.size > 1) experiences.removeAt(index) }, enabled = experiences.size > 1) {
                                                Icon(Icons.Rounded.Delete, "Eliminar", tint = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                        OutlinedTextField(entry.role, { experiences[index] = entry.copy(role = it.take(120)) }, label = { Text("Puesto") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                        OutlinedTextField(entry.company, { experiences[index] = experiences[index].copy(company = it.take(120)) }, label = { Text("Empresa / organización") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                        OutlinedTextField(entry.period, { experiences[index] = experiences[index].copy(period = it.take(80)) }, label = { Text("Periodo") }, placeholder = { Text("Ene 2024 – Actualidad") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                        OutlinedTextField(entry.details, { experiences[index] = experiences[index].copy(details = it.take(1600)) }, label = { Text("Logros y funciones") }, placeholder = { Text("Usa frases breves. Ej.: Reduje tiempos de atención en 20%.") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                                    }
                                }
                            }
                            OutlinedButton(onClick = { experiences.add(CvExperienceDraft()) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Rounded.Add, null)
                                Text(" Agregar experiencia")
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Formación", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                IconButton(onClick = { education.add(CvEducationDraft()) }) { Icon(Icons.Rounded.Add, "Agregar formación", tint = NeonGreen) }
                            }
                            education.forEachIndexed { index, entry ->
                                Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.06f)), shape = RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Formación ${index + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                            IconButton(onClick = {
                                                if (index > 0) {
                                                    val item = education.removeAt(index)
                                                    education.add(index - 1, item)
                                                }
                                            }, enabled = index > 0) { Icon(Icons.Rounded.ArrowUpward, "Subir") }
                                            IconButton(onClick = {
                                                if (index < education.lastIndex) {
                                                    val item = education.removeAt(index)
                                                    education.add(index + 1, item)
                                                }
                                            }, enabled = index < education.lastIndex) { Icon(Icons.Rounded.ArrowDownward, "Bajar") }
                                            IconButton(onClick = { if (education.size > 1) education.removeAt(index) }, enabled = education.size > 1) {
                                                Icon(Icons.Rounded.Delete, "Eliminar", tint = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                        OutlinedTextField(entry.degree, { education[index] = entry.copy(degree = it.take(160)) }, label = { Text("Carrera, grado o curso") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                        OutlinedTextField(entry.institution, { education[index] = education[index].copy(institution = it.take(160)) }, label = { Text("Institución") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                        OutlinedTextField(entry.period, { education[index] = education[index].copy(period = it.take(80)) }, label = { Text("Periodo / año") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    }
                                }
                            }
                            OutlinedButton(onClick = { education.add(CvEducationDraft()) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Rounded.Add, null)
                                Text(" Agregar formación")
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Competencias", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            OutlinedTextField(skills, { skills = it.take(1600) }, label = { Text("Habilidades") }, placeholder = { Text("Excel, AutoCAD, atención al cliente, liderazgo") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                            OutlinedTextField(languages, { languages = it.take(800) }, label = { Text("Idiomas") }, placeholder = { Text("Español nativo, Inglés intermedio") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                            OutlinedTextField(certifications, { certifications = it.take(1400) }, label = { Text("Cursos y certificaciones (opcional)") }, placeholder = { Text("Seguridad minera 2026; Excel avanzado; AutoCAD") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                            OutlinedTextField(projects, { projects = it.take(1800) }, label = { Text("Proyectos o logros (opcional)") }, placeholder = { Text("Describe proyectos, reconocimientos o resultados relevantes.") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                        }
                    }
                }
            }

            item { CvPreview(snapshot) }

            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Exportar", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Button(
                            onClick = {
                                pendingPdf = snapshot
                                pdfLauncher.launch("CV_${safeFileName(fullName, "sin_nombre")}.pdf")
                            },
                            enabled = isReady,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) {
                            Icon(Icons.Rounded.Save, contentDescription = null)
                            Text(" Guardar PDF A4", fontWeight = FontWeight.Bold)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { copyPlainText(context, "cv", cvText); message = "CV copiado" },
                                enabled = cvText.isNotBlank(),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.ContentCopy, null)
                                Text(" Copiar")
                            }
                            OutlinedButton(
                                onClick = { pendingText = cvText; txtLauncher.launch("CV_${safeFileName(fullName, "sin_nombre")}.txt") },
                                enabled = cvText.isNotBlank(),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Guardar TXT")
                            }
                        }
                        if (!isReady) {
                            Text("Completa tu nombre y al menos perfil, experiencia o formación para exportar.", color = Gold, style = MaterialTheme.typography.bodySmall)
                        }
                        message?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen) }
                    }
                }
            }
        }
    }
}

@Composable
private fun CvPreview(data: CvDocumentData) {
    val accent = when (data.templateIndex) {
        1 -> Color(0xFF1F2937)
        2 -> Color(0xFF111827)
        else -> Color(0xFF176B46)
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier.fillMaxWidth().padding(if (data.templateIndex == 2) 16.dp else 22.dp),
            verticalArrangement = Arrangement.spacedBy(if (data.templateIndex == 2) 7.dp else 10.dp)
        ) {
            Text(
                data.fullName.ifBlank { "Tu nombre" },
                color = accent,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                modifier = Modifier.fillMaxWidth()
            )
            if (data.desiredRole.isNotBlank()) Text(data.desiredRole, color = Color(0xFF333333), fontWeight = FontWeight.Bold)
            val contact = buildCvContactLine(data)
            if (contact.isNotBlank()) Text(contact, color = Color(0xFF555555), style = MaterialTheme.typography.bodySmall)
            if (data.links.isNotBlank()) Text(data.links.trim(), color = accent, style = MaterialTheme.typography.bodySmall)
            CvPreviewSection("PERFIL", data.profile, accent)
            val experienceText = data.experiences.filter { it.role.isNotBlank() || it.company.isNotBlank() || it.details.isNotBlank() }.joinToString("\n\n") { entry ->
                buildString {
                    append(listOf(entry.role.trim(), entry.company.trim()).filter { it.isNotBlank() }.joinToString(" · "))
                    if (entry.period.isNotBlank()) append("  |  ${entry.period.trim()}")
                    if (entry.details.isNotBlank()) append("\n${entry.details.trim()}")
                }
            }
            CvPreviewSection("EXPERIENCIA", experienceText, accent)
            val educationText = data.education.filter { it.degree.isNotBlank() || it.institution.isNotBlank() }.joinToString("\n") { entry ->
                listOf(entry.degree.trim(), entry.institution.trim(), entry.period.trim()).filter { it.isNotBlank() }.joinToString(" · ")
            }
            CvPreviewSection("FORMACIÓN", educationText, accent)
            CvPreviewSection("HABILIDADES", normalizeCvList(data.skills), accent)
            CvPreviewSection("IDIOMAS", normalizeCvList(data.languages), accent)
            CvPreviewSection("CERTIFICACIONES", normalizeCvList(data.certifications), accent)
            CvPreviewSection("PROYECTOS Y LOGROS", data.projects, accent)
        }
    }
}

@Composable
private fun CvPreviewSection(title: String, value: String, accent: Color) {
    if (value.isBlank()) return
    Spacer(Modifier.height(2.dp))
    Text(title, color = accent, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelLarge)
    Text(value.trim(), color = Color(0xFF222222), style = MaterialTheme.typography.bodyMedium, lineHeight = MaterialTheme.typography.bodyMedium.lineHeight)
}

@Composable
fun WorkHoursScreen(onBack: () -> Unit) {
    var usePeruRules by rememberSaveable { mutableStateOf(true) }
    var salaryMode by rememberSaveable { mutableStateOf(false) }
    var monthlySalary by rememberSaveable { mutableStateOf("1130") }
    var rate by rememberSaveable { mutableStateOf("15") }
    var regularHours by rememberSaveable { mutableStateOf("8") }
    var overtimeHours by rememberSaveable { mutableStateOf("2") }
    var overtimeMultiplier by rememberSaveable { mutableStateOf("1.25") }
    var days by rememberSaveable { mutableStateOf("5") }
    var holiday by rememberSaveable { mutableStateOf(false) }
    var result by rememberSaveable { mutableStateOf<String?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Horas de trabajo", "Pago regular y horas extra por jornada o semana", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Cálculo de pago", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("Regla peruana automática", fontWeight = FontWeight.Bold)
                                Text(
                                    "+25% las 2 primeras horas y +35% desde la 3ra",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(checked = usePeruRules, onCheckedChange = { usePeruRules = it })
                        }

                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Calcular desde el sueldo mensual", Modifier.weight(1f))
                            Switch(checked = salaryMode, onCheckedChange = { salaryMode = it })
                        }

                        if (salaryMode) {
                            DecimalField(monthlySalary, { monthlySalary = it }, "Sueldo mensual (S/)")
                            val previewRate = runCatching {
                                WorkPayCalculator.hourlyRateFromMonthly(
                                    parseNumber(monthlySalary),
                                    parseNumber(regularHours).coerceAtLeast(1.0)
                                )
                            }.getOrNull()
                            if (previewRate != null) {
                                Text(
                                    "Valor hora: S/ ${formatMoney(previewRate)}  ·  (sueldo ÷ 30) ÷ horas de jornada",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NeonGreen
                                )
                            }
                        } else {
                            DecimalField(rate, { rate = it }, "Pago por hora (S/)")
                        }

                        DecimalField(regularHours, { regularHours = it }, "Horas regulares por día")
                        DecimalField(overtimeHours, { overtimeHours = it }, "Horas extra por día")
                        if (!usePeruRules) {
                            DecimalField(overtimeMultiplier, { overtimeMultiplier = it }, "Multiplicador de extra")
                        }
                        DecimalField(days, { days = it }, "Cantidad de días")

                        if (usePeruRules) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text("Feriado o día de descanso")
                                    Text(
                                        "Paga el doble si no hay descanso compensatorio",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(checked = holiday, onCheckedChange = { holiday = it })
                            }
                        }

                        Button(
                            onClick = {
                                runCatching {
                                    val baseRate = if (salaryMode) {
                                        WorkPayCalculator.hourlyRateFromMonthly(
                                            parseNumber(monthlySalary),
                                            parseNumber(regularHours).coerceAtLeast(1.0)
                                        )
                                    } else {
                                        parseNumber(rate)
                                    }

                                    if (usePeruRules) {
                                        val data = WorkPayCalculator.calculatePeru(
                                            hourlyRate = baseRate,
                                            regularHoursPerDay = parseNumber(regularHours),
                                            overtimeHoursPerDay = parseNumber(overtimeHours),
                                            days = parseNumber(days),
                                            holiday = holiday
                                        )
                                        buildString {
                                            appendLine("Valor hora base: S/ ${formatMoney(baseRate)}")
                                            if (holiday) appendLine("Feriado: la hora base se paga al doble")
                                            appendLine()
                                            appendLine("Horas regulares totales: ${formatNumber(data.regularHours)}")
                                            appendLine("Pago regular: S/ ${formatMoney(data.regularPay)}")
                                            appendLine()
                                            if (data.overtimeFirstHours > 0) {
                                                appendLine("Extra al 25%: ${formatNumber(data.overtimeFirstHours)} h → S/ ${formatMoney(data.overtimeFirstPay)}")
                                            }
                                            if (data.overtimeExtraHours > 0) {
                                                appendLine("Extra al 35%: ${formatNumber(data.overtimeExtraHours)} h → S/ ${formatMoney(data.overtimeExtraPay)}")
                                            }
                                            appendLine("Total horas extra: S/ ${formatMoney(data.overtimePay)}")
                                            appendLine()
                                            append("Pago total estimado: S/ ${formatMoney(data.totalPay)}")
                                        }
                                    } else {
                                        val data = WorkPayCalculator.calculate(
                                            hourlyRate = baseRate,
                                            regularHoursPerDay = parseNumber(regularHours),
                                            overtimeHoursPerDay = parseNumber(overtimeHours),
                                            overtimeMultiplier = parseNumber(overtimeMultiplier),
                                            days = parseNumber(days)
                                        )
                                        buildString {
                                            appendLine("Horas regulares totales: ${formatNumber(data.regularHours)}")
                                            appendLine("Horas extra totales: ${formatNumber(data.overtimeHours)}")
                                            appendLine("Pago regular: S/ ${formatMoney(data.regularPay)}")
                                            appendLine("Pago por horas extra: S/ ${formatMoney(data.overtimePay)}")
                                            append("Pago total estimado: S/ ${formatMoney(data.totalPay)}")
                                        }
                                    }
                                }.onSuccess {
                                    result = it
                                    error = null
                                }.onFailure {
                                    error = it.message ?: "Datos inválidos"
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Calcular", fontWeight = FontWeight.Bold) }
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            result?.let {
                item {
                    ResultSurface(title = "Resultado") {
                        Text(it, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.10f)), shape = RoundedCornerShape(18.dp)) {
                    Text(
                        if (usePeruRules) {
                            "Jornada máxima legal en Perú: 8 horas diarias o 48 semanales. Las horas extra se pagan con un recargo mínimo de 25% las dos primeras de cada día y 35% desde la tercera. El conteo se reinicia cada día. Este cálculo es referencial y no constituye asesoría legal."
                        } else {
                            "Modo manual: usa el multiplicador que corresponda a tu acuerdo de pago. Es un cálculo práctico y rápido."
                        },
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun QuoteIgvScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var client by rememberSaveable { mutableStateOf("") }
    var quoteName by rememberSaveable { mutableStateOf("Cotización") }
    var notes by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var quantity by rememberSaveable { mutableStateOf("1") }
    var unitPrice by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingExport by remember { mutableStateOf<String?>(null) }
    val quoteItems = rememberSaveable(
        saver = listSaver(
            save = { items ->
                items.flatMap { line ->
                    listOf<Any>(line.id, line.description, line.quantity, line.unitPrice)
                }
            },
            restore = { saved ->
                saved.chunked(4).mapNotNull { row ->
                    if (row.size != 4) null else QuoteLine(
                        id = (row[0] as Number).toLong(),
                        description = row[1] as String,
                        quantity = (row[2] as Number).toDouble(),
                        unitPrice = (row[3] as Number).toDouble()
                    )
                }.toMutableStateList()
            }
        )
    ) { mutableStateListOf<QuoteLine>() }

    val subtotal = quoteItems.sumOf { it.quantity * it.unitPrice }
    val (_, igv, total) = CommerceCalculator.quoteTotals(subtotal)
    val summary = remember(client, quoteName, notes, quoteItems.size, subtotal, igv, total) {
        buildQuoteSummary(client, quoteName, notes, quoteItems, subtotal, igv, total)
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val content = pendingExport
        if (uri != null && content != null) {
            runCatching { saveText(context, uri.toString(), content) }
                .onSuccess { message = "Cotización guardada" }
                .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
        }
        pendingExport = null
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Cotización e IGV", "Arma ítems y obtén subtotal, IGV y total", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Encabezado", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(quoteName, { quoteName = it.take(120) }, label = { Text("Nombre del documento") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(client, { client = it.take(120) }, label = { Text("Cliente (opcional)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(notes, { notes = it.take(500) }, label = { Text("Observaciones") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Agregar ítem", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(description, { description = it.take(160) }, label = { Text("Descripción") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DecimalField(quantity, { quantity = it }, "Cantidad", Modifier.weight(1f))
                            DecimalField(unitPrice, { unitPrice = it }, "Precio unitario", Modifier.weight(1f))
                        }
                        Button(
                            onClick = {
                                runCatching {
                                    val q = parseNumber(quantity)
                                    val p = parseNumber(unitPrice)
                                    require(description.isNotBlank()) { "Escribe una descripción" }
                                    require(q > 0 && p >= 0) { "Cantidad o precio inválido" }
                                    QuoteLine(System.currentTimeMillis() + quoteItems.size, description.trim(), q, p)
                                }.onSuccess {
                                    quoteItems.add(it)
                                    description = ""
                                    quantity = "1"
                                    unitPrice = ""
                                    message = "Ítem agregado"
                                }.onFailure {
                                    message = "Error: ${it.message ?: "No se pudo agregar"}"
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Agregar ítem", fontWeight = FontWeight.Bold) }
                        message?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen) }
                    }
                }
            }
            if (quoteItems.isEmpty()) {
                item {
                    Text("Todavía no agregaste ítems.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(quoteItems, key = { it.id }) { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(item.description, fontWeight = FontWeight.Bold)
                                Text("${formatNumber(item.quantity)} × S/ ${formatMoney(item.unitPrice)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("S/ ${formatMoney(item.quantity * item.unitPrice)}", color = Gold, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { quoteItems.remove(item) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar")
                            }
                        }
                    }
                }
                item {
                    ResultSurface(title = "Totales") {
                        Text("Subtotal: S/ ${formatMoney(subtotal)}")
                        Text("IGV (18%): S/ ${formatMoney(igv)}")
                        Text("Total: S/ ${formatMoney(total)}", fontWeight = FontWeight.Bold, color = NeonGreen)
                    }
                }
                item {
                    // Camino inverso: muchas veces el precio ya viene con IGV
                    // incluido y hay que sacar la base. El error comun es
                    // multiplicar el total por 0.18; lo correcto es dividir
                    // entre 1.18.
                    IgvFromTotalCard()
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                copyPlainText(context, "cotizacion", summary)
                                message = "Resumen copiado"
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = null)
                            Text(" Copiar", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = {
                                pendingExport = summary
                                exportLauncher.launch("${safeFileName(quoteName, "cotizacion")}.txt")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.Save, contentDescription = null)
                            Text(" Guardar TXT")
                        }
                    }
                }
                item {
                    ResultSurface(title = "Resumen listo para compartir") {
                        Text(summary)
                    }
                }
            }
        }
    }
}

@Composable
fun IncomeExpenseTrackerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { WorkLedgerStore(context.applicationContext) }
    val entries by store.entries.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var movementType by rememberSaveable { mutableStateOf("gasto") }
    var description by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("General") }
    var amount by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingExport by remember { mutableStateOf<String?>(null) }

    val totalIncome = entries.filter { it.type == "ingreso" }.sumOf { it.amountCents }
    val totalExpense = entries.filter { it.type == "gasto" }.sumOf { it.amountCents }
    val balance = totalIncome - totalExpense
    val csv = remember(entries) { ledgerCsv(entries) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val content = pendingExport
        if (uri != null && content != null) {
            runCatching { saveText(context, uri.toString(), content) }
                .onSuccess { message = "Movimientos exportados" }
                .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
        }
        pendingExport = null
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Ingresos y gastos", "Control local con saldo y exportación CSV", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneySummaryCard("Ingresos", totalIncome, NeonGreen, Modifier.weight(1f))
                    MoneySummaryCard("Gastos", totalExpense, Gold, Modifier.weight(1f))
                }
            }
            item {
                ResultSurface(title = "Saldo actual") {
                    Text(
                        "S/ ${formatMoney(balance / 100.0)}",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (balance >= 0) NeonGreen else MaterialTheme.colorScheme.error
                    )
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Nuevo movimiento", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { movementType = "ingreso" },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (movementType == "ingreso") NeonGreen else CardGreen,
                                    contentColor = if (movementType == "ingreso") DeepGreen else MaterialTheme.colorScheme.onSurface
                                )
                            ) { Text("Ingreso") }
                            Button(
                                onClick = { movementType = "gasto" },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (movementType == "gasto") Gold else CardGreen,
                                    contentColor = if (movementType == "gasto") DeepGreen else MaterialTheme.colorScheme.onSurface
                                )
                            ) { Text("Gasto") }
                        }
                        OutlinedTextField(description, { description = it.take(160) }, label = { Text("Descripción") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(category, { category = it.take(80) }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth())
                        DecimalField(amount, { amount = it }, "Monto (S/)")
                        Button(
                            onClick = {
                                scope.launch {
                                    runCatching { store.add(movementType, description, category, parseNumber(amount)) }
                                        .onSuccess {
                                            description = ""
                                            amount = ""
                                            message = "Movimiento guardado"
                                        }
                                        .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
                                }
                            },
                            enabled = description.isNotBlank() && amount.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Guardar movimiento", fontWeight = FontWeight.Bold) }
                        message?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen) }
                    }
                }
            }
            if (entries.isNotEmpty()) {
                item {
                    OutlinedButton(
                        onClick = {
                            pendingExport = csv
                            exportLauncher.launch("ingresos_gastos.csv")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Save, contentDescription = null)
                        Text(" Exportar CSV")
                    }
                }
                items(entries, key = { it.id }) { entry ->
                    LedgerEntryCard(entry) {
                        scope.launch { store.delete(entry.id) }
                    }
                }
            } else {
                item { EmptyStateText("Todavía no registraste ingresos ni gastos.") }
            }
        }
    }
}

@Composable
fun InventoryBasicScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { InventoryStore(context.applicationContext) }
    val inventoryItems by store.items.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var name by rememberSaveable { mutableStateOf("") }
    var sku by rememberSaveable { mutableStateOf("") }
    var quantity by rememberSaveable { mutableStateOf("0") }
    var minimumStock by rememberSaveable { mutableStateOf("1") }
    var unitCost by rememberSaveable { mutableStateOf("0") }
    var unitSale by rememberSaveable { mutableStateOf("0") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingExport by remember { mutableStateOf<String?>(null) }

    val lowStock = inventoryItems.count { it.quantity <= it.minimumStock }
    val stockValueCents = inventoryItems.sumOf { kotlin.math.round(it.quantity * it.unitCostCents).toLong() }
    val potentialSaleCents = inventoryItems.sumOf { kotlin.math.round(it.quantity * it.unitSaleCents).toLong() }
    val csv = remember(inventoryItems) { inventoryCsv(inventoryItems) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val content = pendingExport
        if (uri != null && content != null) {
            runCatching { saveText(context, uri.toString(), content) }
                .onSuccess { message = "Inventario exportado" }
                .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
        }
        pendingExport = null
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Inventario básico", "Stock, costos, precios y alertas de mínimo", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallMetricCard("Productos", inventoryItems.size.toString(), Modifier.weight(1f))
                    SmallMetricCard("Stock bajo", lowStock.toString(), Modifier.weight(1f), if (lowStock > 0) Gold else NeonGreen)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallMetricCard("Costo en stock", "S/ ${formatMoney(stockValueCents / 100.0)}", Modifier.weight(1f))
                    SmallMetricCard("Venta potencial", "S/ ${formatMoney(potentialSaleCents / 100.0)}", Modifier.weight(1f))
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Agregar producto", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(name, { name = it.take(160) }, label = { Text("Producto") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(sku, { sku = it.take(80) }, label = { Text("Código o SKU (opcional)") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DecimalField(quantity, { quantity = it }, "Stock inicial", Modifier.weight(1f))
                            DecimalField(minimumStock, { minimumStock = it }, "Stock mínimo", Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DecimalField(unitCost, { unitCost = it }, "Costo unitario", Modifier.weight(1f))
                            DecimalField(unitSale, { unitSale = it }, "Precio de venta", Modifier.weight(1f))
                        }
                        Button(
                            onClick = {
                                scope.launch {
                                    runCatching {
                                        store.add(
                                            name = name,
                                            sku = sku,
                                            quantity = parseNumber(quantity),
                                            minimumStock = parseNumber(minimumStock),
                                            unitCost = parseNumber(unitCost),
                                            unitSale = parseNumber(unitSale)
                                        )
                                    }.onSuccess {
                                        name = ""
                                        sku = ""
                                        quantity = "0"
                                        minimumStock = "1"
                                        unitCost = "0"
                                        unitSale = "0"
                                        message = "Producto guardado"
                                    }.onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
                                }
                            },
                            enabled = name.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Guardar producto", fontWeight = FontWeight.Bold) }
                        message?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen) }
                    }
                }
            }
            if (inventoryItems.isNotEmpty()) {
                item {
                    OutlinedButton(
                        onClick = {
                            pendingExport = csv
                            exportLauncher.launch("inventario_gana_geo.csv")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Save, contentDescription = null)
                        Text(" Exportar inventario CSV")
                    }
                }
                items(inventoryItems, key = { it.id }) { item ->
                    InventoryItemCard(
                        item = item,
                        onDecrease = {
                            scope.launch {
                                runCatching { store.adjustStock(item.id, -1.0) }
                                    .onFailure { message = "Error: ${it.message ?: "No se pudo actualizar"}" }
                            }
                        },
                        onIncrease = { scope.launch { store.adjustStock(item.id, 1.0) } },
                        onDelete = { scope.launch { store.delete(item.id) } }
                    )
                }
            } else {
                item { EmptyStateText("Todavía no agregaste productos al inventario.") }
            }
        }
    }
}

@Composable
fun CommissionMarginScreen(onBack: () -> Unit) {
    var cost by rememberSaveable { mutableStateOf("50") }
    var sale by rememberSaveable { mutableStateOf("80") }
    var commissionPercent by rememberSaveable { mutableStateOf("5") }
    var desiredMargin by rememberSaveable { mutableStateOf("30") }
    var result by rememberSaveable { mutableStateOf<String?>(null) }
    var targetResult by rememberSaveable { mutableStateOf<String?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Comisiones y ganancias", "Utilidad, comisión, margen y precio objetivo", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Analizar una venta", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        DecimalField(cost, { cost = it }, "Costo (S/)")
                        DecimalField(sale, { sale = it }, "Precio de venta (S/)")
                        DecimalField(commissionPercent, { commissionPercent = it }, "Comisión sobre venta (%)")
                        Button(
                            onClick = {
                                runCatching {
                                    val data = CommerceCalculator.analyzeSale(
                                        cost = parseNumber(cost),
                                        salePrice = parseNumber(sale),
                                        commissionPercent = parseNumber(commissionPercent)
                                    )
                                    buildString {
                                        appendLine("Utilidad antes de comisión: S/ ${formatMoney(data.grossProfit)}")
                                        appendLine("Comisión: S/ ${formatMoney(data.commission)}")
                                        appendLine("Utilidad neta: S/ ${formatMoney(data.netProfit)}")
                                        appendLine("Margen neto: ${formatMoney(data.netMarginPercent)}%")
                                        append("Ganancia sobre costo: ${formatMoney(data.markupPercent)}%")
                                    }
                                }.onSuccess {
                                    result = it
                                    error = null
                                }.onFailure { error = it.message ?: "Datos inválidos" }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Calcular venta", fontWeight = FontWeight.Bold) }
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            result?.let {
                item { ResultSurface("Resultado de la venta") { Text(it, fontWeight = FontWeight.Bold) } }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Precio para un margen objetivo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        DecimalField(cost, { cost = it }, "Costo (S/)")
                        DecimalField(desiredMargin, { desiredMargin = it }, "Margen deseado (%)")
                        DecimalField(commissionPercent, { commissionPercent = it }, "Comisión estimada (%)")
                        OutlinedButton(
                            onClick = {
                                runCatching {
                                    val targetPrice = CommerceCalculator.targetSalePrice(
                                        cost = parseNumber(cost),
                                        desiredMarginPercent = parseNumber(desiredMargin),
                                        commissionPercent = parseNumber(commissionPercent)
                                    )
                                    "Precio sugerido: S/ ${formatMoney(targetPrice)}"
                                }.onSuccess { targetResult = it }
                                    .onFailure { targetResult = "Error: ${it.message ?: "Datos inválidos"}" }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Calcular precio sugerido") }
                        targetResult?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }
}

@Composable
fun WorkChecklistScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { WorkChecklistStore(context.applicationContext) }
    val checklistItems by store.items.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var title by rememberSaveable { mutableStateOf("") }
    var area by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }

    val pending = checklistItems.count { !it.completed }
    val completed = checklistItems.size - pending

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Checklist de trabajo", "Actividades, áreas y control de cumplimiento", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallMetricCard("Pendientes", pending.toString(), Modifier.weight(1f), Gold)
                    SmallMetricCard("Completadas", completed.toString(), Modifier.weight(1f), NeonGreen)
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Nueva actividad", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(title, { title = it.take(240) }, label = { Text("Actividad") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(area, { area = it.take(100) }, label = { Text("Área o grupo (opcional)") }, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = {
                                scope.launch {
                                    runCatching { store.add(title, area) }
                                        .onSuccess {
                                            title = ""
                                            area = ""
                                            message = "Actividad agregada"
                                        }
                                        .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
                                }
                            },
                            enabled = title.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Agregar actividad", fontWeight = FontWeight.Bold) }
                        message?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen) }
                    }
                }
            }
            if (completed > 0) {
                item {
                    OutlinedButton(
                        onClick = { scope.launch { store.clearCompleted() } },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = null)
                        Text(" Eliminar completadas")
                    }
                }
            }
            if (checklistItems.isEmpty()) {
                item { EmptyStateText("Todavía no agregaste actividades.") }
            } else {
                items(checklistItems, key = { it.id }) { item ->
                    ChecklistItemCard(
                        item = item,
                        onToggle = { scope.launch { store.toggle(item.id) } },
                        onDelete = { scope.launch { store.delete(item.id) } }
                    )
                }
            }
        }
    }
}

@Composable
private fun MoneySummaryCard(label: String, cents: Long, accent: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.10f)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("S/ ${formatMoney(cents / 100.0)}", color = accent, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SmallMetricCard(label: String, value: String, modifier: Modifier, accent: androidx.compose.ui.graphics.Color = NeonGreen) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.09f)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, color = accent, fontWeight = FontWeight.Bold)
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun LedgerEntryCard(entry: WorkLedgerEntry, onDelete: () -> Unit) {
    val accent = if (entry.type == "ingreso") NeonGreen else Gold
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(entry.description, fontWeight = FontWeight.Bold)
                Text(entry.category, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                "${if (entry.type == "ingreso") "+" else "-"} S/ ${formatMoney(entry.amountCents / 100.0)}",
                color = accent,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Eliminar") }
        }
    }
}

@Composable
private fun InventoryItemCard(
    item: InventoryItem,
    onDecrease: () -> Unit,
    onIncrease: () -> Unit,
    onDelete: () -> Unit
) {
    val low = item.quantity <= item.minimumStock
    Card(
        colors = CardDefaults.cardColors(containerColor = if (low) Gold.copy(alpha = 0.10f) else CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.name, fontWeight = FontWeight.Bold)
                    if (item.sku.isNotBlank()) Text("Código: ${item.sku}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        if (low) "Stock bajo o mínimo" else "Stock disponible",
                        color = if (low) Gold else NeonGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Eliminar") }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = onDecrease, enabled = item.quantity >= 1.0) {
                    Icon(Icons.Rounded.Remove, contentDescription = "Restar stock")
                }
                Text(formatNumber(item.quantity), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(onClick = onIncrease) {
                    Icon(Icons.Rounded.Add, contentDescription = "Aumentar stock")
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("Costo: S/ ${formatMoney(item.unitCostCents / 100.0)}")
                    Text("Venta: S/ ${formatMoney(item.unitSaleCents / 100.0)}", color = NeonGreen)
                }
            }
        }
    }
}

@Composable
private fun ChecklistItemCard(item: WorkChecklistItem, onToggle: () -> Unit, onDelete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onToggle) {
                Icon(
                    if (item.completed) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                    contentDescription = if (item.completed) "Marcar pendiente" else "Marcar completada",
                    tint = if (item.completed) NeonGreen else Gold
                )
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(item.title, fontWeight = FontWeight.Bold, color = if (item.completed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                if (item.area.isNotBlank()) Text(item.area, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Eliminar") }
        }
    }
}

@Composable
private fun EmptyStateText(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Text(text, modifier = Modifier.fillMaxWidth().padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun ledgerCsv(entries: List<WorkLedgerEntry>): String = buildString {
    appendLine("tipo,descripcion,categoria,monto")
    entries.forEach { entry ->
        appendLine("${csvCell(entry.type)},${csvCell(entry.description)},${csvCell(entry.category)},${formatMoney(entry.amountCents / 100.0)}")
    }
}

private fun inventoryCsv(items: List<InventoryItem>): String = buildString {
    appendLine("producto,sku,stock,stock_minimo,costo_unitario,precio_venta")
    items.forEach { item ->
        appendLine("${csvCell(item.name)},${csvCell(item.sku)},${formatNumber(item.quantity)},${formatNumber(item.minimumStock)},${formatMoney(item.unitCostCents / 100.0)},${formatMoney(item.unitSaleCents / 100.0)}")
    }
}

private fun csvCell(value: String): String {
    val escaped = value.replace("\"", "\"\"")
    return "\"$escaped\""
}

private fun safeFileName(value: String, fallback: String): String = value
    .trim()
    .ifBlank { fallback }
    .replace(Regex("[\\/:*?\"<>|]"), "_")
    .replace(Regex("\\s+"), "_")
    .take(70)


@Composable
private fun ResultSurface(title: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.08f)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun DecimalField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    OutlinedTextField(
        value = value,
        onValueChange = { candidate -> onValueChange(candidate.filter { it.isDigit() || it == '.' || it == ',' }) },
        label = { Text(label) },
        modifier = modifier,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
}

private suspend fun createProfessionalCvPdf(
    context: Context,
    output: android.net.Uri,
    data: CvDocumentData
) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
    require(data.fullName.isNotBlank()) { "Escribe tu nombre antes de exportar" }

    val pdf = android.graphics.pdf.PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val compact = data.templateIndex == 2
    val classic = data.templateIndex == 1
    val margin = if (compact) 36f else 46f
    val contentWidth = pageWidth - margin * 2f
    val accent = when (data.templateIndex) {
        1 -> android.graphics.Color.rgb(32, 32, 32)
        2 -> android.graphics.Color.rgb(55, 71, 79)
        else -> android.graphics.Color.rgb(20, 102, 67)
    }
    val dark = android.graphics.Color.rgb(28, 31, 30)
    val muted = android.graphics.Color.rgb(86, 92, 90)

    val namePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = dark
        textSize = if (compact) 21f else 25f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
    }
    val rolePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = accent
        textSize = if (compact) 11f else 12.5f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
    }
    val bodyPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = dark
        textSize = if (compact) 9.4f else 10.4f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.NORMAL)
    }
    val bodyBoldPaint = android.graphics.Paint(bodyPaint).apply {
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
    }
    val smallPaint = android.graphics.Paint(bodyPaint).apply {
        color = muted
        textSize = if (compact) 8.5f else 9.2f
    }
    val sectionPaint = android.graphics.Paint(bodyBoldPaint).apply {
        color = accent
        textSize = if (compact) 10.2f else 11.2f
    }

    var pageNumber = 0
    var page: android.graphics.pdf.PdfDocument.Page? = null
    var canvas: android.graphics.Canvas? = null
    var y = margin

    fun startPage() {
        page?.let { pdf.finishPage(it) }
        pageNumber += 1
        page = pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        canvas = page!!.canvas
        canvas!!.drawColor(android.graphics.Color.WHITE)
        y = margin
    }

    fun ensureSpace(required: Float) {
        if (page == null) startPage()
        if (y + required > pageHeight - margin) startPage()
    }

    fun wrappedLines(text: String, paint: android.graphics.Paint, maxWidth: Float): List<String> {
        val clean = text.trim()
        if (clean.isBlank()) return emptyList()
        val output = mutableListOf<String>()
        clean.split('\n').forEach { paragraph ->
            if (paragraph.isBlank()) {
                output += ""
                return@forEach
            }
            val words = paragraph.trim().split(Regex("\\s+")).filter(String::isNotBlank)
            var current = ""
            words.forEach { word ->
                val candidate = if (current.isBlank()) word else "$current $word"
                if (paint.measureText(candidate) <= maxWidth || current.isBlank()) {
                    current = candidate
                } else {
                    output += current
                    current = word
                }
            }
            if (current.isNotBlank()) output += current
        }
        return output
    }

    fun drawWrapped(
        text: String,
        paint: android.graphics.Paint = bodyPaint,
        x: Float = margin,
        maxWidth: Float = contentWidth,
        lineHeight: Float = if (compact) 12f else 13.5f,
        gapAfter: Float = 3f,
        bullet: Boolean = false
    ) {
        val prefixWidth = if (bullet) bodyPaint.measureText("•  ") else 0f
        val lines = wrappedLines(text, paint, (maxWidth - prefixWidth).coerceAtLeast(40f))
        lines.forEachIndexed { index, line ->
            ensureSpace(lineHeight + 2f)
            if (line.isBlank()) {
                y += lineHeight * 0.55f
            } else {
                if (bullet && index == 0) canvas!!.drawText("•", x, y + lineHeight, bodyPaint)
                canvas!!.drawText(line, x + if (bullet) prefixWidth else 0f, y + lineHeight, paint)
                y += lineHeight
            }
        }
        y += gapAfter
    }

    fun drawSectionTitle(title: String) {
        ensureSpace(27f)
        y += if (compact) 5f else 7f
        canvas!!.drawText(title.uppercase(), margin, y + 12f, sectionPaint)
        if (!classic) {
            val lineY = y + 16f
            canvas!!.drawLine(margin, lineY, pageWidth - margin, lineY, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = accent
                strokeWidth = 1.2f
            })
        }
        y += if (classic) 18f else 22f
    }

    startPage()

    // Encabezado limpio y legible para una salida profesional en A4.
    if (classic) {
        namePaint.textAlign = android.graphics.Paint.Align.CENTER
        rolePaint.textAlign = android.graphics.Paint.Align.CENTER
        canvas!!.drawText(data.fullName.trim(), pageWidth / 2f, y + 24f, namePaint)
        y += 31f
        if (data.desiredRole.isNotBlank()) {
            canvas!!.drawText(data.desiredRole.trim(), pageWidth / 2f, y + 13f, rolePaint)
            y += 19f
        }
        namePaint.textAlign = android.graphics.Paint.Align.LEFT
        rolePaint.textAlign = android.graphics.Paint.Align.LEFT
    } else {
        canvas!!.drawText(data.fullName.trim(), margin, y + 24f, namePaint)
        y += 31f
        if (data.desiredRole.isNotBlank()) {
            canvas!!.drawText(data.desiredRole.trim(), margin, y + 13f, rolePaint)
            y += 19f
        }
    }

    val contact = buildCvContactLine(data)
    if (contact.isNotBlank()) drawWrapped(contact, smallPaint, gapAfter = 1f)
    if (data.links.isNotBlank()) drawWrapped(data.links.trim(), smallPaint, gapAfter = 2f)
    y += 4f

    if (data.profile.isNotBlank()) {
        drawSectionTitle("Perfil profesional")
        drawWrapped(data.profile.trim())
    }

    val exp = data.experiences.filter { it.role.isNotBlank() || it.company.isNotBlank() || it.details.isNotBlank() }
    if (exp.isNotEmpty()) {
        drawSectionTitle("Experiencia")
        exp.forEach { item ->
            ensureSpace(34f)
            val heading = listOf(item.role.trim(), item.company.trim()).filter(String::isNotBlank).joinToString(" · ")
            if (heading.isNotBlank()) drawWrapped(heading, bodyBoldPaint, gapAfter = 0f)
            if (item.period.isNotBlank()) drawWrapped(item.period.trim(), smallPaint, gapAfter = 1f)
            item.details.trim().takeIf(String::isNotBlank)?.let { details ->
                details.split('\n').map(String::trim).filter(String::isNotBlank).forEach { line ->
                    drawWrapped(line.removePrefix("•").trim(), bodyPaint, bullet = true, gapAfter = 0f)
                }
            }
            y += 4f
        }
    }

    val edu = data.education.filter { it.degree.isNotBlank() || it.institution.isNotBlank() }
    if (edu.isNotEmpty()) {
        drawSectionTitle("Formación")
        edu.forEach { item ->
            ensureSpace(26f)
            val title = listOf(item.degree.trim(), item.institution.trim()).filter(String::isNotBlank).joinToString(" · ")
            if (title.isNotBlank()) drawWrapped(title, bodyBoldPaint, gapAfter = 0f)
            if (item.period.isNotBlank()) drawWrapped(item.period.trim(), smallPaint, gapAfter = 3f)
        }
    }

    normalizeCvList(data.skills).takeIf(String::isNotBlank)?.let {
        drawSectionTitle("Habilidades")
        drawWrapped(it)
    }
    normalizeCvList(data.languages).takeIf(String::isNotBlank)?.let {
        drawSectionTitle("Idiomas")
        drawWrapped(it)
    }
    normalizeCvList(data.certifications).takeIf(String::isNotBlank)?.let {
        drawSectionTitle("Certificaciones")
        drawWrapped(it)
    }
    data.projects.trim().takeIf(String::isNotBlank)?.let {
        drawSectionTitle("Proyectos y logros")
        it.split('\n').map(String::trim).filter(String::isNotBlank).forEach { line ->
            drawWrapped(line.removePrefix("•").trim(), bodyPaint, bullet = true, gapAfter = 0f)
        }
    }

    page?.let { pdf.finishPage(it) }
    context.contentResolver.openOutputStream(output, "w")?.use { stream ->
        pdf.writeTo(stream)
    } ?: error("No se pudo abrir el archivo de salida")
    pdf.close()
}

private fun buildCvContactLine(data: CvDocumentData): String =
    listOf(data.phone.trim(), data.email.trim(), data.city.trim()).filter { it.isNotBlank() }.joinToString("  ·  ")

private fun normalizeCvList(value: String): String = value
    .split(',', ';', '\n')
    .map(String::trim)
    .filter(String::isNotBlank)
    .joinToString(" · ")

private fun buildProfessionalCvText(data: CvDocumentData, includeHeader: Boolean = true): String = buildString {
    if (includeHeader) {
        if (data.fullName.isNotBlank()) appendLine(data.fullName.trim())
        if (data.desiredRole.isNotBlank()) appendLine(data.desiredRole.trim())
        buildCvContactLine(data).takeIf(String::isNotBlank)?.let { appendLine(it) }
        if (data.links.isNotBlank()) appendLine(data.links.trim())
    }
    if (data.profile.isNotBlank()) {
        if (isNotEmpty()) appendLine()
        appendLine("PERFIL")
        appendLine(data.profile.trim())
    }
    val exp = data.experiences.filter { it.role.isNotBlank() || it.company.isNotBlank() || it.details.isNotBlank() }
    if (exp.isNotEmpty()) {
        if (isNotEmpty()) appendLine()
        appendLine("EXPERIENCIA")
        exp.forEachIndexed { index, item ->
            val heading = listOf(item.role.trim(), item.company.trim()).filter { it.isNotBlank() }.joinToString(" · ")
            if (heading.isNotBlank()) append(heading)
            if (item.period.isNotBlank()) append(" | ${item.period.trim()}")
            appendLine()
            if (item.details.isNotBlank()) appendLine(item.details.trim())
            if (index < exp.lastIndex) appendLine()
        }
    }
    val edu = data.education.filter { it.degree.isNotBlank() || it.institution.isNotBlank() }
    if (edu.isNotEmpty()) {
        if (isNotEmpty()) appendLine()
        appendLine("FORMACIÓN")
        edu.forEach { item ->
            appendLine(listOf(item.degree.trim(), item.institution.trim(), item.period.trim()).filter { it.isNotBlank() }.joinToString(" · "))
        }
    }
    normalizeCvList(data.skills).takeIf(String::isNotBlank)?.let {
        if (isNotEmpty()) appendLine()
        appendLine("HABILIDADES")
        appendLine(it)
    }
    normalizeCvList(data.languages).takeIf(String::isNotBlank)?.let {
        if (isNotEmpty()) appendLine()
        appendLine("IDIOMAS")
        appendLine(it)
    }
    normalizeCvList(data.certifications).takeIf(String::isNotBlank)?.let {
        if (isNotEmpty()) appendLine()
        appendLine("CERTIFICACIONES")
        appendLine(it)
    }
    data.projects.trim().takeIf(String::isNotBlank)?.let {
        if (isNotEmpty()) appendLine()
        appendLine("PROYECTOS Y LOGROS")
        appendLine(it)
    }
}.trim()

private fun buildQuoteSummary(
    client: String,
    quoteName: String,
    notes: String,
    items: List<QuoteLine>,
    subtotal: Double,
    igv: Double,
    total: Double
): String = buildString {
    appendLine(quoteName.ifBlank { "Cotización" })
    if (client.isNotBlank()) appendLine("Cliente: ${client.trim()}")
    appendLine("")
    items.forEachIndexed { index, item ->
        appendLine("${index + 1}. ${item.description} · ${formatNumber(item.quantity)} × S/ ${formatMoney(item.unitPrice)} = S/ ${formatMoney(item.quantity * item.unitPrice)}")
    }
    appendLine("")
    appendLine("Subtotal: S/ ${formatMoney(subtotal)}")
    appendLine("IGV (18%): S/ ${formatMoney(igv)}")
    appendLine("Total: S/ ${formatMoney(total)}")
    if (notes.isNotBlank()) {
        appendLine("")
        appendLine("Observaciones: ${notes.trim()}")
    }
}

private fun parseNumber(value: String): Double = value.replace(',', '.').toDouble()

private fun formatMoney(value: Double): String = String.format(Locale.US, "%.2f", value)

private fun formatNumber(value: Double): String {
    val rounded = String.format(Locale.US, "%.2f", value)
    return rounded.removeSuffix(".00")
}

private fun copyPlainText(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}

private fun saveText(context: Context, uriString: String, text: String) {
    val uri = android.net.Uri.parse(uriString)
    context.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(text) }
        ?: error("No se pudo guardar")
}

/**
 * Calculadora inversa de IGV: a partir de un precio que ya lo incluye, separa la
 * base imponible del impuesto. Sirve para cuando el proveedor da un precio "todo
 * incluido" y hay que emitir factura con el desglose.
 */
@Composable
private fun IgvFromTotalCard() {
    var totalText by rememberSaveable { mutableStateOf("") }
    val parsed = totalText.replace(',', '.').toDoubleOrNull()
    val computed = parsed?.takeIf { it.isFinite() && it >= 0 }?.let {
        runCatching { CommerceCalculator.quoteFromTotal(it) }.getOrNull()
    }

    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("¿Tu precio ya incluye IGV?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Escribe el precio final y te separo la base y el impuesto.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            DecimalField(totalText, { totalText = it }, "Precio con IGV (S/)")
            if (computed != null) {
                val (base, tax, gross) = computed
                Text("Base imponible: S/ ${formatMoney(base)}")
                Text("IGV (18%): S/ ${formatMoney(tax)}")
                Text("Total: S/ ${formatMoney(gross)}", fontWeight = FontWeight.Bold, color = NeonGreen)
            }
        }
    }
}
