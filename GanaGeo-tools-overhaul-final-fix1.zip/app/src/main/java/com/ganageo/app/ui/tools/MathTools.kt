package com.ganageo.app.ui.tools

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.ExpressionEvaluator
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen
import java.text.DecimalFormat
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.pow

private val resultFormat = DecimalFormat("0.##########")

@Composable
fun ScientificCalculatorScreen(onBack: () -> Unit) {
    var expression by rememberSaveable { mutableStateOf("") }
    var result by rememberSaveable { mutableStateOf("0") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var degrees by rememberSaveable { mutableStateOf(true) }
    val history = rememberSaveable(
        saver = listSaver(
            save = { it.toList() },
            restore = { it.toMutableStateList() }
        )
    ) { mutableStateListOf<String>() }

    Column(modifier = Modifier.fillMaxSize()) {
        ToolHeader("Calculadora científica", "Funciones matemáticas sin conexión", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        OutlinedTextField(
                            value = expression,
                            onValueChange = { expression = it.take(120) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Expresión") },
                            placeholder = { Text("Escribe una expresión") },
                            singleLine = false
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            result,
                            style = MaterialTheme.typography.displaySmall,
                            color = NeonGreen,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.End
                        )
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (degrees) "Grados" else "Radianes", modifier = Modifier.weight(1f))
                            Switch(checked = degrees, onCheckedChange = { degrees = it })
                        }
                    }
                }
            }
            item {
                val rows = listOf(
                    listOf("sin(", "cos(", "tan(", "sqrt("),
                    listOf("log(", "ln(", "abs(", "π"),
                    listOf("7", "8", "9", "÷"),
                    listOf("4", "5", "6", "×"),
                    listOf("1", "2", "3", "−"),
                    listOf("0", ".", "⌫", "+"),
                    listOf("C", "(", ")", "=")
                )
                fun evaluateExpression() {
                    runCatching { ExpressionEvaluator(degrees).evaluate(expression) }
                        .onSuccess { value ->
                            val formatted = resultFormat.format(value)
                            result = formatted
                            error = null
                            if (expression.isNotBlank()) {
                                history.add(0, "$expression = $formatted")
                                while (history.size > 5) history.removeAt(history.lastIndex)
                            }
                        }
                        .onFailure { error = it.message ?: "Expresión inválida" }
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    rows.forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { key ->
                                FilledTonalButton(
                                    onClick = {
                                        when (key) {
                                            "C" -> {
                                                expression = ""
                                                result = "0"
                                                error = null
                                            }
                                            "⌫" -> {
                                                expression = expression.dropLast(1)
                                                error = null
                                            }
                                            "=" -> evaluateExpression()
                                            else -> {
                                                expression += key
                                                error = null
                                            }
                                        }
                                    },
                                    modifier = Modifier.weight(1f).height(56.dp),
                                    contentPadding = PaddingValues(vertical = 12.dp),
                                    colors = when (key) {
                                        "=" -> ButtonDefaults.filledTonalButtonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                                        "+", "−", "×", "÷" -> ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = NeonGreen)
                                        else -> ButtonDefaults.filledTonalButtonColors()
                                    }
                                ) { Text(key, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }
            if (history.isNotEmpty()) {
                item {
                    CalculationCard("Historial reciente") {
                        history.forEach { entry ->
                            OutlinedButton(
                                onClick = { expression = entry.substringBefore(" = ") },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(entry, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start) }
                        }
                    }
                }
            }
        }
    }
}

data class UnitDef(val name: String, val factor: Double, val offset: Double = 0.0)

data class UnitCategoryDef(val name: String, val units: List<UnitDef>, val temperature: Boolean = false)

private val unitCategories = listOf(
    UnitCategoryDef("Longitud", listOf(
        UnitDef("Milímetro", 0.001), UnitDef("Centímetro", 0.01), UnitDef("Metro", 1.0),
        UnitDef("Kilómetro", 1000.0), UnitDef("Pulgada", 0.0254), UnitDef("Pie", 0.3048),
        UnitDef("Yarda", 0.9144), UnitDef("Milla", 1609.344)
    )),
    UnitCategoryDef("Área", listOf(
        UnitDef("mm²", 0.000001), UnitDef("cm²", 0.0001), UnitDef("m²", 1.0),
        UnitDef("Hectárea", 10000.0), UnitDef("km²", 1_000_000.0), UnitDef("Pie²", 0.09290304)
    )),
    UnitCategoryDef("Volumen", listOf(
        UnitDef("Mililitro", 0.001), UnitDef("Litro", 1.0), UnitDef("m³", 1000.0),
        UnitDef("Galón US", 3.785411784), UnitDef("Taza US", 0.2365882365)
    )),
    UnitCategoryDef("Masa", listOf(
        UnitDef("Miligramo", 0.000001), UnitDef("Gramo", 0.001), UnitDef("Kilogramo", 1.0),
        UnitDef("Tonelada", 1000.0), UnitDef("Libra", 0.45359237), UnitDef("Onza", 0.028349523125)
    )),
    UnitCategoryDef("Tiempo", listOf(
        UnitDef("Segundo", 1.0), UnitDef("Minuto", 60.0), UnitDef("Hora", 3600.0),
        UnitDef("Día", 86400.0), UnitDef("Semana", 604800.0)
    )),
    UnitCategoryDef("Velocidad", listOf(
        UnitDef("m/s", 1.0), UnitDef("km/h", 0.2777777778), UnitDef("mph", 0.44704), UnitDef("Nudo", 0.514444)
    )),
    UnitCategoryDef("Presión", listOf(
        UnitDef("Pascal", 1.0), UnitDef("Kilopascal", 1000.0), UnitDef("Bar", 100000.0),
        UnitDef("Atmósfera", 101325.0), UnitDef("psi", 6894.757293)
    )),
    UnitCategoryDef("Energía", listOf(
        UnitDef("Joule", 1.0), UnitDef("Kilojoule", 1000.0), UnitDef("Caloría", 4.184),
        UnitDef("Kilocaloría", 4184.0), UnitDef("Wh", 3600.0), UnitDef("kWh", 3_600_000.0)
    )),
    UnitCategoryDef("Potencia", listOf(
        UnitDef("Watt", 1.0), UnitDef("Kilowatt", 1000.0), UnitDef("Megawatt", 1_000_000.0),
        UnitDef("Caballo de fuerza", 745.699872)
    )),
    UnitCategoryDef("Fuerza", listOf(
        UnitDef("Newton", 1.0), UnitDef("Kilonewton", 1000.0), UnitDef("Dina", 0.00001),
        UnitDef("Libra-fuerza", 4.4482216153)
    )),
    UnitCategoryDef("Ángulo", listOf(
        UnitDef("Grado", PI / 180.0), UnitDef("Radián", 1.0), UnitDef("Vuelta", 2 * PI),
        UnitDef("Gradián", PI / 200.0)
    )),
    UnitCategoryDef("Datos", listOf(
        UnitDef("Byte", 1.0), UnitDef("KiB", 1024.0), UnitDef("MiB", 1024.0.pow(2)),
        UnitDef("GiB", 1024.0.pow(3)), UnitDef("TiB", 1024.0.pow(4)),
        UnitDef("kB", 1000.0), UnitDef("MB", 1_000_000.0), UnitDef("GB", 1_000_000_000.0)
    )),
    UnitCategoryDef("Frecuencia", listOf(
        UnitDef("Hertz", 1.0), UnitDef("Kilohertz", 1_000.0), UnitDef("Megahertz", 1_000_000.0), UnitDef("Gigahertz", 1_000_000_000.0)
    )),
    UnitCategoryDef("Aceleración", listOf(
        UnitDef("m/s²", 1.0), UnitDef("cm/s²", 0.01), UnitDef("ft/s²", 0.3048), UnitDef("g", 9.80665)
    )),
    UnitCategoryDef("Densidad", listOf(
        UnitDef("kg/m³", 1.0), UnitDef("g/cm³", 1000.0), UnitDef("g/L", 1.0), UnitDef("lb/ft³", 16.01846337396)
    )),
    UnitCategoryDef("Temperatura", listOf(UnitDef("Celsius", 1.0), UnitDef("Fahrenheit", 1.0), UnitDef("Kelvin", 1.0)), true)
)

@Composable
fun UnitConverterScreen(onBack: () -> Unit) {
    var categoryIndex by rememberSaveable { mutableStateOf(0) }
    var fromIndex by rememberSaveable { mutableStateOf(0) }
    var toIndex by rememberSaveable { mutableStateOf(1) }
    var input by rememberSaveable { mutableStateOf("") }
    val history = rememberSaveable(
        saver = listSaver(
            save = { it.toList() },
            restore = { it.toMutableStateList() }
        )
    ) { mutableStateListOf<String>() }
    val focusManager = LocalFocusManager.current
    val category = unitCategories[categoryIndex]
    val value = input.replace(',', '.').toDoubleOrNull()
    val converted = value?.let {
        if (category.temperature) convertTemperature(it, category.units[fromIndex].name, category.units[toIndex].name)
        else it * category.units[fromIndex].factor / category.units[toIndex].factor
    }
    val fromUnit = category.units[fromIndex].name
    val toUnit = category.units[toIndex].name
    val formattedResult = converted?.let { resultFormat.format(it) }
    val conversionLine = if (value != null && formattedResult != null) {
        "${resultFormat.format(value)} $fromUnit = $formattedResult $toUnit"
    } else null

    fun recordCurrent() {
        conversionLine?.let { line ->
            if (history.firstOrNull() != line) {
                history.add(0, line)
                while (history.size > 6) history.removeAt(history.lastIndex)
            }
        }
    }

    fun swapUnits() {
        val oldFrom = fromIndex
        fromIndex = toIndex
        toIndex = oldFrom
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Conversor de unidades", "Conversiones académicas y cotidianas", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                CalculationCard("Conversión") {
                    SimpleDropdown(
                        label = "Categoría",
                        options = unitCategories.map { it.name },
                        selectedIndex = categoryIndex,
                        onSelected = {
                            categoryIndex = it
                            fromIndex = 0
                            toIndex = minOf(1, unitCategories[it].units.lastIndex)
                        }
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            SimpleDropdown("De", category.units.map { it.name }, fromIndex) { fromIndex = it }
                        }
                        FilledTonalButton(
                            onClick = { swapUnits() },
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp)
                        ) {
                            Text("⇄", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            SimpleDropdown("A", category.units.map { it.name }, toIndex) { toIndex = it }
                        }
                    }

                    NumberField(
                        value = input,
                        onChange = { input = it },
                        label = "Valor",
                        imeAction = ImeAction.Done,
                        onImeAction = {
                            recordCurrent()
                            focusManager.clearFocus()
                        }
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                swapUnits()
                                recordCurrent()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("⇄ Intercambiar")
                        }
                        OutlinedButton(
                            onClick = {
                                input = ""
                                focusManager.clearFocus()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("⌫ Limpiar")
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardGreen),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Resultado", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            if (converted != null) {
                                Text("✓ Listo", color = NeonGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            formattedResult?.let { "$it $toUnit" } ?: "—",
                            style = MaterialTheme.typography.displaySmall,
                            color = NeonGreen,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            conversionLine ?: "Escribe un valor para convertir.",
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (history.isNotEmpty()) {
                item {
                    CalculationCard("Historial reciente") {
                        history.forEach { entry ->
                            OutlinedButton(
                                onClick = { },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = false
                            ) {
                                Text(entry, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                            }
                        }
                        OutlinedButton(
                            onClick = { history.clear() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Limpiar historial")
                        }
                    }
                }
            }
        }
    }
}


private fun convertTemperature(value: Double, from: String, to: String): Double {
    val celsius = when (from) {
        "Fahrenheit" -> (value - 32) * 5 / 9
        "Kelvin" -> value - 273.15
        else -> value
    }
    return when (to) {
        "Fahrenheit" -> celsius * 9 / 5 + 32
        "Kelvin" -> celsius + 273.15
        else -> celsius
    }
}

@Composable
fun PercentRuleScreen(onBack: () -> Unit) {
    var base by rememberSaveable { mutableStateOf("") }
    var percent by rememberSaveable { mutableStateOf("") }
    var part by rememberSaveable { mutableStateOf("") }
    var total by rememberSaveable { mutableStateOf("") }
    var initial by rememberSaveable { mutableStateOf("") }
    var finalValue by rememberSaveable { mutableStateOf("") }
    var a by rememberSaveable { mutableStateOf("") }
    var b by rememberSaveable { mutableStateOf("") }
    var c by rememberSaveable { mutableStateOf("") }
    var proportionMode by rememberSaveable { mutableIntStateOf(0) }
    val percentFocus = remember { FocusRequester() }
    val bFocus = remember { FocusRequester() }
    val cFocus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    fun number(value: String): Double? = value.replace(',', '.').toDoubleOrNull()
    val baseValue = number(base)
    val percentValue = number(percent)
    val percentResult = if (baseValue != null && percentValue != null) baseValue * percentValue / 100.0 else null
    val partValue = number(part)
    val totalValue = number(total)
    val representedPercent = if (partValue != null && totalValue != null && kotlin.math.abs(totalValue) > 1e-12) partValue / totalValue * 100.0 else null
    val initialValue = number(initial)
    val endingValue = number(finalValue)
    val percentChange = if (initialValue != null && endingValue != null && kotlin.math.abs(initialValue) > 1e-12) (endingValue - initialValue) / kotlin.math.abs(initialValue) * 100.0 else null
    val proportionValues = listOf(a, b, c).map(::number)
    val ruleResult = if (proportionValues.all { it != null }) {
        val av = proportionValues[0]!!
        val bv = proportionValues[1]!!
        val cv = proportionValues[2]!!
        when (proportionMode) {
            0 -> if (kotlin.math.abs(av) > 1e-12) bv * cv / av else null
            else -> if (kotlin.math.abs(cv) > 1e-12) av * bv / cv else null
        }
    } else null

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Porcentajes y regla de tres", "Porcentajes, variaciones y proporciones directas o inversas", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                CalculationCard("Calcular un porcentaje") {
                    NumberField(
                        base, { base = it }, "Cantidad base",
                        imeAction = ImeAction.Next,
                        onImeAction = { percentFocus.requestFocus() }
                    )
                    NumberField(
                        percent, { percent = it }, "Porcentaje %",
                        modifier = Modifier.focusRequester(percentFocus),
                        imeAction = ImeAction.Done,
                        onImeAction = { focusManager.clearFocus() }
                    )
                    ResultText(percentResult)
                    if (baseValue != null && percentValue != null && percentResult != null) {
                        Text(
                            "Aumento: ${resultFormat.format(baseValue + percentResult)} · Descuento: ${resultFormat.format(baseValue - percentResult)}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item {
                CalculationCard("¿Qué porcentaje representa?") {
                    Text("Calcula qué porcentaje es una parte respecto de un total.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    NumberField(part, { part = it }, "Parte")
                    NumberField(total, { total = it }, "Total")
                    ResultText(representedPercent, prefix = "Resultado = ", suffix = " %")
                    if (totalValue == 0.0) Text("El total no puede ser cero.", color = MaterialTheme.colorScheme.error)
                }
            }
            item {
                CalculationCard("Variación porcentual") {
                    Text("Compara un valor inicial con uno final. Positivo = aumento; negativo = disminución.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    NumberField(initial, { initial = it }, "Valor inicial")
                    NumberField(finalValue, { finalValue = it }, "Valor final")
                    ResultText(percentChange, prefix = "Variación = ", suffix = " %")
                    if (initialValue == 0.0) Text("El valor inicial no puede ser cero para calcular una variación porcentual.", color = MaterialTheme.colorScheme.error)
                }
            }
            item {
                CalculationCard("Regla de tres") {
                    SimpleDropdown("Tipo de proporción", listOf("Directa", "Inversa"), proportionMode) { proportionMode = it }
                    Text(
                        if (proportionMode == 0) "Directa: si A corresponde a B, entonces C corresponde a X."
                        else "Inversa: cuando una magnitud aumenta y la otra disminuye (A × B = C × X).",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    NumberField(
                        a, { a = it }, "A",
                        imeAction = ImeAction.Next,
                        onImeAction = { bFocus.requestFocus() }
                    )
                    NumberField(
                        b, { b = it }, "B",
                        modifier = Modifier.focusRequester(bFocus),
                        imeAction = ImeAction.Next,
                        onImeAction = { cFocus.requestFocus() }
                    )
                    NumberField(
                        c, { c = it }, "C",
                        modifier = Modifier.focusRequester(cFocus),
                        imeAction = ImeAction.Done,
                        onImeAction = { focusManager.clearFocus() }
                    )
                    ResultText(ruleResult, prefix = "X = ")
                    if ((proportionMode == 0 && number(a) == 0.0) || (proportionMode == 1 && number(c) == 0.0)) {
                        Text("El divisor no puede ser cero.", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun GradesAverageScreen(onBack: () -> Unit) {
    val scores = rememberSaveable(
        saver = listSaver(
            save = { it.toList() },
            restore = { it.toMutableStateList() }
        )
    ) { mutableStateListOf("", "", "", "") }
    val weights = rememberSaveable(
        saver = listSaver(
            save = { it.toList() },
            restore = { it.toMutableStateList() }
        )
    ) { mutableStateListOf("25", "25", "25", "25") }
    var useWeights by rememberSaveable { mutableStateOf(false) }
    var passingGrade by rememberSaveable { mutableStateOf("11") }

    var neededMode by rememberSaveable { mutableStateOf(0) } // 0 = exámenes iguales, 1 = porcentaje
    var currentAverage by rememberSaveable { mutableStateOf("") }
    var totalExams by rememberSaveable { mutableStateOf("3") }
    var completedExams by rememberSaveable { mutableStateOf("2") }
    var completedWeight by rememberSaveable { mutableStateOf("70") }
    var finalWeight by rememberSaveable { mutableStateOf("30") }
    var targetGrade by rememberSaveable { mutableStateOf("11") }

    val validScores = scores.map { it.replace(',', '.').toDoubleOrNull() }
    val simple = validScores.filterNotNull().takeIf { it.isNotEmpty() }?.average()
    val weightedParts = validScores.zip(weights.map { it.replace(',', '.').toDoubleOrNull() })
        .filter { it.first != null && it.second != null }
    val weightTotal = weightedParts.sumOf { it.second!! }
    val weighted = if (useWeights && weightedParts.isNotEmpty() && weightTotal > 0) {
        weightedParts.sumOf { it.first!! * it.second!! } / weightTotal
    } else null
    val displayedAverage = if (useWeights) weighted else simple
    val pass = passingGrade.replace(',', '.').toDoubleOrNull()

    val currentValue = currentAverage.replace(',', '.').toDoubleOrNull()
    val targetValue = targetGrade.replace(',', '.').toDoubleOrNull()
    val totalExamValue = totalExams.toIntOrNull()
    val completedExamValue = completedExams.toIntOrNull()
    val pendingExams = if (
        totalExamValue != null && completedExamValue != null && totalExamValue > completedExamValue && completedExamValue > 0
    ) totalExamValue - completedExamValue else null
    val neededEqualExamAverage = if (
        currentValue != null && targetValue != null && pendingExams != null && totalExamValue != null && completedExamValue != null
    ) {
        (targetValue * totalExamValue - currentValue * completedExamValue) / pendingExams
    } else null

    val completedValue = completedWeight.replace(',', '.').toDoubleOrNull()
    val finalValue = finalWeight.replace(',', '.').toDoubleOrNull()
    val neededWeightedGrade = if (
        currentValue != null && completedValue != null && finalValue != null &&
        targetValue != null && finalValue > 0 && completedValue >= 0
    ) {
        (targetValue * (completedValue + finalValue) - currentValue * completedValue) / finalValue
    } else null

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Promedios y notas", "Escala libre y promedio ponderado", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                CalculationCard("Notas") {
                    scores.indices.forEach { index ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = scores[index],
                                onValueChange = { scores[index] = it.take(8) },
                                label = { Text("Nota ${index + 1}") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            if (useWeights) {
                                OutlinedTextField(
                                    value = weights.getOrElse(index) { "" },
                                    onValueChange = { value ->
                                        while (weights.size <= index) weights.add("")
                                        weights[index] = value.take(6)
                                    },
                                    label = { Text("Peso %") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                scores.add("")
                                weights.add("")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+ Añadir nota")
                        }
                        if (scores.size > 1) {
                            OutlinedButton(
                                onClick = {
                                    scores.removeAt(scores.lastIndex)
                                    if (weights.isNotEmpty()) weights.removeAt(weights.lastIndex)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("− Quitar última")
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Usar pesos %", fontWeight = FontWeight.Bold)
                            Text(
                                "Actívalo solo si unas evaluaciones valen más que otras.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = useWeights, onCheckedChange = { useWeights = it })
                    }

                    if (useWeights) {
                        Text(
                            "Peso total: ${resultFormat.format(weightTotal)}%",
                            color = if (abs(weightTotal - 100.0) < 0.01) NeonGreen else MaterialTheme.colorScheme.error
                        )
                        if (abs(weightTotal - 100.0) >= 0.01) {
                            Text("Los pesos deberían sumar 100%.", color = MaterialTheme.colorScheme.error)
                        }
                    }

                    NumberField(passingGrade, { passingGrade = it }, "Nota mínima aprobatoria")
                    Text(
                        "Promedio simple: ${simple?.let { resultFormat.format(it) } ?: "—"}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (useWeights) {
                        Text(
                            "Promedio ponderado: ${weighted?.let { resultFormat.format(it) } ?: "—"}",
                            style = MaterialTheme.typography.titleMedium,
                            color = NeonGreen
                        )
                    }
                    if (displayedAverage != null && pass != null) {
                        val difference = displayedAverage - pass
                        Text(
                            if (displayedAverage >= pass) {
                                "✓ APRUEBA — Promedio ${resultFormat.format(displayedAverage)} / Mínimo ${resultFormat.format(pass)}"
                            } else {
                                "✕ NO APRUEBA — faltan ${resultFormat.format(-difference)} puntos"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = if (displayedAverage >= pass) NeonGreen else MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            item {
                CalculationCard("Nota necesaria") {
                    Text("Calcula qué nota necesitas para alcanzar tu promedio objetivo.")

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { neededMode = 0 },
                            modifier = Modifier.weight(1f),
                            colors = if (neededMode == 0) {
                                ButtonDefaults.filledTonalButtonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                            } else ButtonDefaults.filledTonalButtonColors()
                        ) {
                            Text("Exámenes iguales")
                        }
                        FilledTonalButton(
                            onClick = { neededMode = 1 },
                            modifier = Modifier.weight(1f),
                            colors = if (neededMode == 1) {
                                ButtonDefaults.filledTonalButtonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                            } else ButtonDefaults.filledTonalButtonColors()
                        ) {
                            Text("Por porcentaje")
                        }
                    }

                    NumberField(currentAverage, { currentAverage = it }, "Promedio actual")

                    if (neededMode == 0) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = totalExams,
                                onValueChange = { totalExams = it.filter(Char::isDigit).take(3) },
                                label = { Text("Total de exámenes") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = completedExams,
                                onValueChange = { completedExams = it.filter(Char::isDigit).take(3) },
                                label = { Text("Exámenes rendidos") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                        NumberField(targetGrade, { targetGrade = it }, "Promedio objetivo")
                        Text(
                            neededEqualExamAverage?.let { needed ->
                                if (pendingExams == 1) {
                                    "Necesitas: ${resultFormat.format(needed)} en el próximo examen"
                                } else {
                                    "Necesitas un promedio de ${resultFormat.format(needed)} en los $pendingExams exámenes pendientes"
                                }
                            } ?: "Necesitas: —",
                            style = MaterialTheme.typography.titleLarge,
                            color = NeonGreen,
                            fontWeight = FontWeight.Bold
                        )
                        if (totalExamValue != null && completedExamValue != null && completedExamValue >= totalExamValue) {
                            Text("Los exámenes rendidos deben ser menos que el total.", color = MaterialTheme.colorScheme.error)
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = completedWeight,
                                onValueChange = { completedWeight = it.take(6) },
                                label = { Text("Peso ya evaluado %") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = finalWeight,
                                onValueChange = { finalWeight = it.take(6) },
                                label = { Text("Peso pendiente %") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                        NumberField(targetGrade, { targetGrade = it }, "Promedio objetivo")
                        Text(
                            neededWeightedGrade?.let {
                                "Nota que necesitas en el ${resultFormat.format(finalValue ?: 0.0)}% pendiente: ${resultFormat.format(it)}"
                            } ?: "Necesitas: —",
                            style = MaterialTheme.typography.titleLarge,
                            color = NeonGreen,
                            fontWeight = FontWeight.Bold
                        )
                        if (completedValue != null && finalValue != null && abs(completedValue + finalValue - 100.0) >= 0.01) {
                            Text(
                                "El peso evaluado y pendiente deberían sumar 100%.",
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun GeometryScreen(onBack: () -> Unit) {
    val shapes = listOf(
        "Cuadrado", "Rectángulo", "Triángulo", "Trapecio", "Círculo",
        "Cilindro", "Cono", "Prisma rectangular", "Esfera"
    )
    var shapeIndex by rememberSaveable { mutableStateOf(0) }
    var a by rememberSaveable { mutableStateOf("") }
    var b by rememberSaveable { mutableStateOf("") }
    var c by rememberSaveable { mutableStateOf("") }
    var unit by rememberSaveable { mutableStateOf("cm") }
    val x = a.replace(',', '.').toDoubleOrNull()?.takeIf { it > 0 }
    val y = b.replace(',', '.').toDoubleOrNull()?.takeIf { it > 0 }
    val z = c.replace(',', '.').toDoubleOrNull()?.takeIf { it > 0 }
    val results = when (shapeIndex) {
        0 -> if (x != null) listOf("Área" to x.pow(2), "Perímetro" to 4 * x) else emptyList()
        1 -> if (x != null && y != null) listOf("Área" to x * y, "Perímetro" to 2 * (x + y)) else emptyList()
        2 -> if (x != null && y != null) listOf("Área" to x * y / 2) else emptyList()
        3 -> if (x != null && y != null && z != null) listOf("Área" to (x + y) * z / 2) else emptyList()
        4 -> if (x != null) listOf("Área" to PI * x.pow(2), "Circunferencia" to 2 * PI * x) else emptyList()
        5 -> if (x != null && y != null) listOf("Volumen" to PI * x.pow(2) * y, "Área total" to 2 * PI * x * (x + y)) else emptyList()
        6 -> if (x != null && y != null) {
            val slant = kotlin.math.sqrt(x.pow(2) + y.pow(2))
            listOf("Volumen" to PI * x.pow(2) * y / 3, "Área total" to PI * x * (x + slant))
        } else emptyList()
        7 -> if (x != null && y != null && z != null) listOf("Volumen" to x * y * z, "Área total" to 2 * (x * y + x * z + y * z)) else emptyList()
        else -> if (x != null) listOf("Volumen" to 4.0 / 3.0 * PI * x.pow(3), "Área" to 4 * PI * x.pow(2)) else emptyList()
    }
    val formula = when (shapeIndex) {
        0 -> "A = L²  ·  P = 4L"
        1 -> "A = b·h  ·  P = 2(b+h)"
        2 -> "A = b·h ÷ 2"
        3 -> "A = (B+b)·h ÷ 2"
        4 -> "A = πr²  ·  C = 2πr"
        5 -> "V = πr²h  ·  At = 2πr(r+h)"
        6 -> "V = πr²h ÷ 3"
        7 -> "V = largo·ancho·alto"
        else -> "V = 4πr³ ÷ 3  ·  A = 4πr²"
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Geometría", "Áreas, perímetros y volúmenes", onBack)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                SimpleDropdown("Figura", shapes, shapeIndex) {
                    shapeIndex = it
                    a = ""
                    b = ""
                    c = ""
                }
            }
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardGreen),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(shapes[shapeIndex], style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                when (shapeIndex) {
                                    0 -> NumberField(a, { a = it }, "Lado")
                                    1 -> {
                                        NumberField(a, { a = it }, "Base")
                                        NumberField(b, { b = it }, "Altura")
                                    }
                                    2 -> {
                                        NumberField(a, { a = it }, "Base")
                                        NumberField(b, { b = it }, "Altura")
                                    }
                                    3 -> {
                                        NumberField(a, { a = it }, "Base mayor")
                                        NumberField(b, { b = it }, "Base menor")
                                        NumberField(c, { c = it }, "Altura")
                                    }
                                    4 -> NumberField(a, { a = it }, "Radio")
                                    5, 6 -> {
                                        NumberField(a, { a = it }, "Radio")
                                        NumberField(b, { b = it }, "Altura")
                                    }
                                    7 -> {
                                        NumberField(a, { a = it }, "Largo")
                                        NumberField(b, { b = it }, "Ancho")
                                        NumberField(c, { c = it }, "Alto")
                                    }
                                    else -> NumberField(a, { a = it }, "Radio")
                                }
                            }
                            GeometryFigurePreview(
                                shapeIndex = shapeIndex,
                                a = a,
                                b = b,
                                c = c,
                                unit = unit,
                                modifier = Modifier.width(132.dp)
                            )
                        }

                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it.filter { ch -> ch.isLetterOrDigit() || ch == '²' || ch == '³' }.take(8) },
                            label = { Text("Unidad") },
                            placeholder = { Text("cm, m, km…") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DeepGreen.copy(alpha = 0.42f), RoundedCornerShape(16.dp))
                                .padding(12.dp)
                        ) {
                            Text(formula, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        if (results.isNotEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(NeonGreen.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("Resultado", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                results.forEach { (label, value) ->
                                    val suffix = when {
                                        label.contains("Volumen") -> "${unit.ifBlank { "u" }}³"
                                        label.contains("Área") -> "${unit.ifBlank { "u" }}²"
                                        else -> unit.ifBlank { "u" }
                                    }
                                    Text(
                                        "$label: ${resultFormat.format(value)} $suffix",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = NeonGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else {
                            Text(
                                "Ingresa las medidas y el resultado aparecerá automáticamente.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }

                        if ((a.isNotBlank() && x == null) || (b.isNotBlank() && y == null) || (c.isNotBlank() && z == null)) {
                            Text("Usa valores numéricos mayores que cero.", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GeometryFigurePreview(
    shapeIndex: Int,
    a: String,
    b: String,
    c: String,
    unit: String,
    modifier: Modifier = Modifier
) {
    val accent = NeonGreen
    val line = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.92f)
    val guide = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.58f)
    val u = unit.ifBlank { "u" }
    val labels = when (shapeIndex) {
        0 -> listOf("L = ${a.ifBlank { "—" }} $u")
        1 -> listOf("b = ${a.ifBlank { "—" }} $u", "h = ${b.ifBlank { "—" }} $u")
        2 -> listOf("b = ${a.ifBlank { "—" }} $u", "h = ${b.ifBlank { "—" }} $u")
        3 -> listOf("B = ${a.ifBlank { "—" }} $u", "b = ${b.ifBlank { "—" }} $u", "h = ${c.ifBlank { "—" }} $u")
        4 -> listOf("r = ${a.ifBlank { "—" }} $u")
        5, 6 -> listOf("r = ${a.ifBlank { "—" }} $u", "h = ${b.ifBlank { "—" }} $u")
        7 -> listOf("L = ${a.ifBlank { "—" }}", "A = ${b.ifBlank { "—" }}", "H = ${c.ifBlank { "—" }}")
        else -> listOf("r = ${a.ifBlank { "—" }} $u")
    }

    Column(
        modifier = modifier
            .background(DeepGreen.copy(alpha = 0.52f), RoundedCornerShape(18.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("Vista técnica", style = MaterialTheme.typography.labelMedium, color = accent, fontWeight = FontWeight.Bold)
        Canvas(modifier = Modifier.size(112.dp)) {
            val w = size.width
            val h = size.height
            val stroke = 4f
            val thin = 2.5f
            when (shapeIndex) {
                0 -> {
                    val left = w * 0.18f; val top = h * 0.18f; val s = w * 0.64f
                    drawRect(line, topLeft = Offset(left, top), size = Size(s, s), style = Stroke(stroke))
                    drawLine(accent, Offset(left, top + s + 10f), Offset(left + s, top + s + 10f), thin, cap = StrokeCap.Round)
                }
                1 -> {
                    val left = w * 0.10f; val top = h * 0.24f; val rw = w * 0.80f; val rh = h * 0.52f
                    drawRect(line, Offset(left, top), Size(rw, rh), style = Stroke(stroke))
                    drawLine(accent, Offset(left, top + rh + 9f), Offset(left + rw, top + rh + 9f), thin)
                    drawLine(accent, Offset(left + rw + 8f, top), Offset(left + rw + 8f, top + rh), thin)
                }
                2 -> {
                    val p = Path().apply { moveTo(w * 0.12f, h * 0.78f); lineTo(w * 0.88f, h * 0.78f); lineTo(w * 0.56f, h * 0.18f); close() }
                    drawPath(p, line, style = Stroke(stroke))
                    drawLine(accent, Offset(w * 0.56f, h * 0.18f), Offset(w * 0.56f, h * 0.78f), thin)
                    drawLine(guide, Offset(w * 0.50f, h * 0.72f), Offset(w * 0.56f, h * 0.72f), thin)
                }
                3 -> {
                    val p = Path().apply { moveTo(w * 0.12f, h * 0.78f); lineTo(w * 0.88f, h * 0.78f); lineTo(w * 0.72f, h * 0.25f); lineTo(w * 0.32f, h * 0.25f); close() }
                    drawPath(p, line, style = Stroke(stroke))
                    drawLine(accent, Offset(w * 0.32f, h * 0.20f), Offset(w * 0.72f, h * 0.20f), thin)
                    drawLine(accent, Offset(w * 0.12f, h * 0.84f), Offset(w * 0.88f, h * 0.84f), thin)
                    drawLine(accent, Offset(w * 0.76f, h * 0.25f), Offset(w * 0.76f, h * 0.78f), thin)
                }
                4 -> {
                    drawCircle(line, radius = w * 0.34f, center = Offset(w * 0.50f, h * 0.50f), style = Stroke(stroke))
                    drawLine(accent, Offset(w * 0.50f, h * 0.50f), Offset(w * 0.84f, h * 0.50f), thin, cap = StrokeCap.Round)
                    drawCircle(accent, radius = 4f, center = Offset(w * 0.50f, h * 0.50f))
                }
                5 -> {
                    val left = w * 0.20f; val right = w * 0.80f; val top = h * 0.22f; val bottom = h * 0.78f
                    drawOval(line, Offset(left, top - 10f), Size(right-left, 22f), style = Stroke(stroke))
                    drawOval(line, Offset(left, bottom - 10f), Size(right-left, 22f), style = Stroke(stroke))
                    drawLine(line, Offset(left, top), Offset(left, bottom), stroke)
                    drawLine(line, Offset(right, top), Offset(right, bottom), stroke)
                    drawLine(accent, Offset(w * 0.50f, top), Offset(w * 0.50f, bottom), thin)
                    drawLine(accent, Offset(w * 0.50f, top), Offset(right, top), thin)
                }
                6 -> {
                    val apex = Offset(w * 0.50f, h * 0.16f); val left = w * 0.18f; val right = w * 0.82f; val baseY = h * 0.78f
                    drawLine(line, apex, Offset(left, baseY), stroke)
                    drawLine(line, apex, Offset(right, baseY), stroke)
                    drawOval(line, Offset(left, baseY - 10f), Size(right-left, 22f), style = Stroke(stroke))
                    drawLine(accent, apex, Offset(w * 0.50f, baseY), thin)
                    drawLine(accent, Offset(w * 0.50f, baseY), Offset(right, baseY), thin)
                }
                7 -> {
                    val x1=w*0.18f; val y1=h*0.30f; val x2=w*0.68f; val y2=h*0.76f; val dx=w*0.16f; val dy=-h*0.14f
                    drawRect(line, Offset(x1,y1), Size(x2-x1,y2-y1), style = Stroke(stroke))
                    drawRect(line, Offset(x1+dx,y1+dy), Size(x2-x1,y2-y1), style = Stroke(stroke))
                    drawLine(line, Offset(x1,y1), Offset(x1+dx,y1+dy), stroke)
                    drawLine(line, Offset(x2,y1), Offset(x2+dx,y1+dy), stroke)
                    drawLine(line, Offset(x1,y2), Offset(x1+dx,y2+dy), stroke)
                    drawLine(line, Offset(x2,y2), Offset(x2+dx,y2+dy), stroke)
                    drawLine(accent, Offset(x1,y2+8f), Offset(x2,y2+8f), thin)
                }
                else -> {
                    drawCircle(line, radius = w * 0.34f, center = Offset(w * 0.50f, h * 0.50f), style = Stroke(stroke))
                    drawOval(guide, Offset(w * 0.16f, h * 0.43f), Size(w * 0.68f, h * 0.14f), style = Stroke(thin))
                    drawLine(accent, Offset(w * 0.50f, h * 0.50f), Offset(w * 0.84f, h * 0.50f), thin)
                    drawCircle(accent, radius = 4f, center = Offset(w * 0.50f, h * 0.50f))
                }
            }
        }
        labels.forEach { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}


@Composable
private fun CalculationCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            content()
        }
    }
}

@Composable
private fun NumberField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    imeAction: ImeAction = ImeAction.Default,
    onImeAction: (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.take(30)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Decimal,
            imeAction = imeAction
        ),
        keyboardActions = KeyboardActions(
            onNext = { onImeAction?.invoke() },
            onDone = { onImeAction?.invoke() }
        ),
        modifier = modifier.fillMaxWidth(),
        singleLine = true
    )
}

@Composable
private fun ResultText(value: Double?, prefix: String = "Resultado: ", suffix: String = "") {
    Text(
        value?.let { prefix + resultFormat.format(it) + suffix } ?: "$prefix—$suffix",
        style = MaterialTheme.typography.titleLarge,
        color = NeonGreen
    )
}

@Composable
fun SimpleDropdown(label: String, options: List<String>, selectedIndex: Int, onSelected: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val selected = options.getOrElse(selectedIndex) { options.firstOrNull().orEmpty() }
    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { if (options.isNotEmpty()) expanded = true },
            enabled = options.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                Text(
                    label,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    selected,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text("▼", modifier = Modifier.padding(start = 8.dp))
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.fillMaxWidth(0.92f).heightIn(max = 420.dp)
        ) {
            options.forEachIndexed { index, option ->
                DropdownMenuItem(
                    text = {
                        Text(
                            option,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (index == selectedIndex) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    onClick = {
                        onSelected(index)
                        expanded = false
                    }
                )
            }
        }
    }
}
