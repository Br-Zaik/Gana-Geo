package com.ganageo.app.ui.tools

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Bitmap
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyListItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CropFree
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Redo
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.ganageo.app.GanaGeoViewModel
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.AdvancedFileUtils
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.PageSelectionParser
import com.ganageo.app.tools.PdfMargin
import com.ganageo.app.tools.PdfOrientation
import com.ganageo.app.tools.PdfPaperSize
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt
import java.io.File
import java.util.UUID
import org.json.JSONObject

@Composable
fun DocumentScannerScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var editorUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var galleryImages by remember { mutableStateOf<List<ScannerGalleryImage>>(emptyList()) }
    var galleryLoading by remember { mutableStateOf(false) }
    var galleryRefresh by remember { mutableIntStateOf(0) }
    val galleryGridState = rememberLazyGridState()
    var mode by remember { mutableIntStateOf(0) } // 0 = imagen, 1 = OCR, 2 = recrear
    var zoneMode by remember { mutableStateOf(false) }
    var selection by remember { mutableStateOf(ScannerSelection()) }
    var ocrText by remember { mutableStateOf("") }
    var ocrBusy by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var openingImage by remember { mutableStateOf(false) }
    var recreateDocument by remember { mutableStateOf<ScannerRecreateDocument?>(null) }
    var recreateLoading by remember { mutableStateOf(false) }
    var recreateError by remember { mutableStateOf<String?>(null) }
    var recreateRefresh by remember { mutableIntStateOf(0) }
    var recreateEditing by remember { mutableStateOf(false) }
    var pendingRecreateSave by remember { mutableStateOf<ScannerRecreateDocument?>(null) }

    // Aviso propio del escaner. El Snackbar del Scaffold se dibuja al fondo de
    // la pantalla y el panel verde lo tapa: el mensaje asomaba cortado y no se
    // podia leer, sobre todo el de creditos insuficientes.
    var bannerMessage by remember { mutableStateOf<String?>(null) }
    var bannerIsError by remember { mutableStateOf(false) }
    var bannerTick by remember { mutableIntStateOf(0) }

    fun showBanner(text: String, isError: Boolean) {
        bannerMessage = text
        bannerIsError = isError
        bannerTick++
    }

    // Todo aviso del escaner pasa por aqui. Al reenviarlo a onMessage, el
    // Snackbar del Scaffold lo pintaba al fondo de la pantalla, debajo del
    // panel, y solo asomaba una franja ilegible.
    val notifyError: (String) -> Unit = { showBanner(it, true) }

    LaunchedEffect(bannerTick) {
        if (bannerMessage != null) {
            delay(4500)
            bannerMessage = null
        }
    }

    // El escáner normal permanece dentro de la interfaz de Gana Geo. Solo el
    // editor de palabras de la imagen recreada entra en modo inmersivo.
    LaunchedEffect(recreateEditing) {
        onImmersiveChanged(recreateEditing)
    }
    DisposableEffect(Unit) {
        onDispose { onImmersiveChanged(false) }
    }

    fun openScannerEditor(uri: Uri) {
        if (openingImage || saving || ocrBusy) return
        openingImage = true
        scope.launch {
            try {
                if (scannerUriReadable(context, uri)) {
                    editorUri = uri
                    mode = 0
                    zoneMode = false
                    selection = ScannerSelection()
                    ocrText = ""
                    recreateDocument = null
                    recreateError = null
                    recreateEditing = false
                } else {
                    showBanner("Ya no se puede acceder a esta imagen. Elige otra foto.", true)
                }
            } finally {
                openingImage = false
            }
        }
    }

    val systemPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            openScannerEditor(uri)
        }
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val captured = pendingCameraUri
        pendingCameraUri = null
        if (ok && captured != null) {
            openScannerEditor(captured)
        }
    }

    fun openCamera() {
        if (saving || ocrBusy) return
        runCatching {
            val uri = ToolFileUtils.createCameraImageUri(context)
            pendingCameraUri = uri
            camera.launch(uri)
        }.onFailure {
            pendingCameraUri = null
            showBanner(it.message ?: "No se pudo abrir la cámara", true)
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openCamera() else showBanner("Se necesita permiso de cámara", true)
    }

    val galleryPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        galleryRefresh++
    }

    val saveRecreatedImage = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { output ->
        val document = pendingRecreateSave
        pendingRecreateSave = null
        if (output == null || document == null) return@rememberLauncherForActivityResult
        saving = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                withContext(Dispatchers.IO) {
                    val recreated = renderScannerRecreateDocumentBitmap(document, SCANNER_RECREATE_OUTPUT_MAX_EDGE)
                    try {
                        context.contentResolver.openOutputStream(output, "w")?.use { stream ->
                            check(recreated.compress(Bitmap.CompressFormat.PNG, 100, stream)) { "No se pudo guardar la imagen" }
                        } ?: error("No se pudo crear el archivo")
                    } finally {
                        if (!recreated.isRecycled) recreated.recycle()
                    }
                }
            }.onSuccess {
                showBanner(successMessage("Imagen recreada guardada", it), false)
            }.onFailure {
                showBanner(it.message ?: "No se pudo guardar la imagen", true)
            }
            saving = false
        }
    }

    // El boton atras retrocede un nivel a la vez, igual que la flecha de la
    // cabecera: texto extraido -> opciones de extraer -> menu -> galeria.
    BackHandler(enabled = editorUri != null || mode != 0 || recreateEditing) {
        when {
            mode == 2 && recreateEditing -> recreateEditing = false
            mode == 1 && ocrText.isNotBlank() -> {
                ocrText = ""
                zoneMode = false
            }
            mode != 0 -> {
                mode = 0
                zoneMode = false
                ocrText = ""
                recreateEditing = false
            }
            else -> editorUri = null
        }
    }

    val galleryGranted = scannerGalleryPermissionGranted(context)
    LaunchedEffect(galleryGranted, galleryRefresh) {
        if (galleryGranted) {
            galleryLoading = true
            galleryImages = try {
                loadScannerRecentImages(context, SCANNER_GALLERY_RECENT_LIMIT)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                showBanner("No se pudieron cargar las fotos recientes", true)
                emptyList()
            }
            galleryLoading = false
        } else {
            galleryImages = emptyList()
        }
    }

    LaunchedEffect(Unit) {
        if (!scannerGalleryPermissionGranted(context)) {
            galleryPermissionLauncher.launch(scannerGalleryPermissions())
        }
    }

    val currentUri = editorUri
    if (currentUri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Elige una foto para escanear o extraer texto", onBack)
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                openCamera()
                            } else {
                                cameraPermission.launch(Manifest.permission.CAMERA)
                            }
                        },
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) {
                        Icon(Icons.Rounded.AddAPhoto, null)
                        Text("  Cámara")
                    }
                    OutlinedButton(
                        onClick = { systemPicker.launch(arrayOf("image/*")) },
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) {
                        Icon(Icons.Rounded.Folder, null)
                        Text("  Archivos")
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Últimas 15 imágenes", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    if (galleryGranted) {
                        IconButton(onClick = { galleryRefresh++ }) {
                            Icon(Icons.Rounded.Refresh, "Actualizar")
                        }
                    }
                }
            }

            when {
                !galleryGranted -> {
                    Box(Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.TopCenter) {
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                            Column(
                                Modifier.fillMaxWidth().padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Rounded.PhotoLibrary, null, tint = NeonGreen)
                                Text("Permite acceso a tus fotos para mostrarlas aquí.", textAlign = TextAlign.Center)
                                Button(
                                    onClick = { galleryPermissionLauncher.launch(scannerGalleryPermissions()) },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                                ) { Text("Permitir fotos", fontWeight = FontWeight.Bold) }
                                Text("También puedes usar Archivos sin dar acceso permanente.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
                galleryLoading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NeonGreen)
                    }
                }
                galleryImages.isEmpty() -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No se encontraron imágenes", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                else -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        state = galleryGridState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 10.dp, end = 10.dp, bottom = 28.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(galleryImages, key = { it.uri.toString() }) { item ->
                            ScannerGalleryThumbnail(item) {
                                openScannerEditor(item.uri)
                            }
                        }
                    }
                }
            }
        }
        return
    }

    var sourceLoadFailed by remember(currentUri) { mutableStateOf(false) }
    val sourceBitmap by produceState<Bitmap?>(initialValue = null, currentUri, mode) {
        sourceLoadFailed = false
        if (mode == 2) {
            value = null
            return@produceState
        }
        value = try {
            ToolFileUtils.loadBitmap(context, currentUri, SCANNER_EDITOR_PREVIEW_MAX_EDGE)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Throwable) {
            sourceLoadFailed = true
            null
        }
    }

    LaunchedEffect(currentUri, mode, recreateRefresh) {
        if (mode == 2 && recreateDocument == null && !recreateLoading) {
            recreateLoading = true
            recreateError = null
            recreateDocument = try {
                scannerBuildRecreateDocument(context, currentUri, SCANNER_RECREATE_ANALYSIS_MAX_EDGE)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                recreateError = error.message ?: "No se pudo reconstruir la imagen"
                null
            }
            recreateLoading = false
        }
    }

    fun requestRecreatedImageSave(document: ScannerRecreateDocument) {
        val base = runCatching { ToolFileUtils.displayName(context, currentUri) }.getOrDefault("escaneo")
            .substringBeforeLast('.').replace(Regex("[\\/:*?\"<>|]"), "_").take(60)
        launchPaidExport(viewModel, tool, notifyError) {
            pendingRecreateSave = document
            saveRecreatedImage.launch("${base}_recreada.png")
        }
    }

    val bitmapToShow = sourceBitmap
    val clipboard = context.getSystemService(android.content.ClipboardManager::class.java)

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        ToolHeader(
            tool.title,
            when {
                mode == 1 && ocrText.isNotBlank() -> "Texto extraído · edítalo o cópialo"
                mode == 1 && zoneMode -> "Ajusta el cuadro sobre el texto"
                mode == 1 -> "Elige qué parte de la imagen leer"
                mode == 2 -> "Vista previa de la imagen recreada"
                else -> "Elige qué quieres hacer con la imagen"
            }
        ) {
            // El retroceso es por niveles: del texto extraido vuelve a las
            // opciones de extraer, y de ahi al menu principal.
            when {
                mode == 1 && ocrText.isNotBlank() -> {
                    ocrText = ""
                    zoneMode = false
                }
                mode != 0 -> {
                    mode = 0
                    zoneMode = false
                    ocrText = ""
                    recreateEditing = false
                }
                else -> editorUri = null
            }
        }

        // Nivel 3 de "Extraer texto": una vez hay texto, ocupa la pantalla
        // completa. Antes vivia en un recuadro de 148dp dentro del panel y solo
        // se veian cuatro lineas.
        if (mode == 1 && ocrText.isNotBlank()) {
            ScannerExtractedTextPanel(
                text = ocrText,
                creditCost = tool.creditCost,
                busy = ocrBusy,
                modifier = Modifier.fillMaxWidth().weight(1f),
                onTextChange = { ocrText = it },
                onCopy = {
                    clipboard?.setPrimaryClip(android.content.ClipData.newPlainText("Texto escaneado", ocrText))
                    showBanner("Texto copiado al portapapeles", false)
                },
                onRepeat = {
                    ocrText = ""
                    zoneMode = false
                }
            )
        } else {

        Box(
            modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF101412)).clipToBounds(),
            contentAlignment = Alignment.Center
        ) {
            when {
                mode == 2 -> ScannerRecreatePreview(
                    document = recreateDocument,
                    loading = recreateLoading,
                    error = recreateError,
                    modifier = Modifier.fillMaxSize()
                )
                bitmapToShow == null -> {
                    if (sourceLoadFailed) {
                        Text("No se pudo abrir o procesar esta imagen", color = Color.White)
                    } else {
                        CircularProgressIndicator(color = NeonGreen)
                    }
                }
                else -> ScannerImageViewport(
                    bitmap = bitmapToShow,
                    selectionEnabled = mode == 1 && zoneMode,
                    selection = selection,
                    onSelectionChange = { selection = it },
                    modifier = Modifier.fillMaxSize()
                )
            }

            Card(
            colors = CardDefaults.cardColors(containerColor = CardGreen),
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp, bottomEnd = 0.dp, bottomStart = 0.dp),
            modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter)
            ) {
            val screenHeightDp = LocalConfiguration.current.screenHeightDp
            val panelMaxHeight = (screenHeightDp * 0.42f).dp.coerceIn(200.dp, 420.dp)
            Column(
            Modifier
            .fillMaxWidth()
            .padding(14.dp)
            .heightIn(max = panelMaxHeight)
            .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
            // Nivel 1: solo las dos herramientas. Sus opciones no aparecen
            // hasta que se elige una, para no mezclar los dos flujos.
            if (mode == 0) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
            onClick = {
            mode = 1
            zoneMode = false
            ocrText = ""
            },
            modifier = Modifier.weight(1f).height(44.dp),
            contentPadding = PaddingValues(horizontal = 8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
            Icon(Icons.Rounded.TextFields, null, modifier = Modifier.size(18.dp))
            Text(
            "  Extraer texto",
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            style = MaterialTheme.typography.labelLarge
            )
            }
            Button(
            onClick = {
            mode = 2
            zoneMode = false
            ocrText = ""
            recreateDocument = null
            recreateError = null
            recreateEditing = false
            },
            modifier = Modifier.weight(1f).height(44.dp),
            contentPadding = PaddingValues(horizontal = 8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF244A37), contentColor = Color.White)
            ) {
            Icon(Icons.Rounded.AutoFixHigh, null, modifier = Modifier.size(18.dp))
            Text(
            "  Recrear imagen",
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            style = MaterialTheme.typography.labelLarge
            )
            }
            }
            }

            // Nivel 2 de "Extraer texto": sus dos opciones y nada mas.
            if (mode == 1) {
            ScannerStepHeader {
            mode = 0
            zoneMode = false
            ocrText = ""
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
            onClick = {
            zoneMode = false
            launchPaidExport(viewModel, tool, notifyError) {
            ocrBusy = true
            scope.launch {
            var recognized = ""
            runPaidTool(viewModel, tool) {
            recognized = scannerOcr(context, currentUri, null)
            require(recognized.isNotBlank()) { "No se detectó texto." }
            }.onSuccess { reward ->
            ocrText = recognized
            if (reward > 0) showBanner("Texto extraído. Ganaste $reward Geo Rewards.", false)
            }.onFailure { error ->
            if (recognized.isNotBlank()) ocrText = recognized
            showBanner(error.message ?: "No se pudo reconocer el texto", true)
            }
            ocrBusy = false
            }
            }
            },
            modifier = Modifier.weight(1f).height(44.dp),
            contentPadding = PaddingValues(horizontal = 8.dp),
            enabled = !ocrBusy,
            colors = ButtonDefaults.buttonColors(
            containerColor = if (zoneMode) Color(0xFF244A37) else NeonGreen,
            contentColor = if (zoneMode) Color.White else DeepGreen
            )
            ) {
            Text(
            "Toda la imagen · ${tool.creditCost}",
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            style = MaterialTheme.typography.labelLarge
            )
            }
            Button(
            onClick = {
            zoneMode = true
            ocrText = ""
            },
            modifier = Modifier.weight(1f).height(44.dp),
            contentPadding = PaddingValues(horizontal = 8.dp),
            enabled = !ocrBusy,
            colors = ButtonDefaults.buttonColors(
            containerColor = if (zoneMode) NeonGreen else Color(0xFF244A37),
            contentColor = if (zoneMode) DeepGreen else Color.White
            )
            ) {
            Text(
            "Seleccionar zona",
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            style = MaterialTheme.typography.labelLarge
            )
            }
            }

            if (zoneMode) {
            Text(
            "Arrastra el cuadro sobre la parte que quieres leer.",
            color = Color(0xFFBFD8C7),
            style = MaterialTheme.typography.bodySmall
            )
            Button(
            onClick = {
            launchPaidExport(viewModel, tool, notifyError) {
            ocrBusy = true
            scope.launch {
            var recognized = ""
            runPaidTool(viewModel, tool) {
            recognized = scannerOcr(context, currentUri, selection)
            require(recognized.isNotBlank()) { "No se detectó texto en la zona." }
            }.onSuccess { reward ->
            ocrText = recognized
            if (reward > 0) showBanner("Texto extraído. Ganaste $reward Geo Rewards.", false)
            }.onFailure { error ->
            if (recognized.isNotBlank()) ocrText = recognized
            showBanner(error.message ?: "No se pudo reconocer el texto", true)
            }
            ocrBusy = false
            }
            }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            enabled = !ocrBusy,
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
            Icon(Icons.Rounded.ContentCopy, null)
            Text("  Extraer esta zona · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
            }
            }

            if (ocrBusy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            // Nivel 2 de "Recrear imagen": sus opciones, sin nada de zonas.
            if (mode == 2) {
            ScannerStepHeader {
            mode = 0
            zoneMode = false
            ocrText = ""
            recreateEditing = false
            }
            when {
            // El texto "Recreando la imagen" ya se muestra sobre la vista; aqui
            // solo va la barra, si no el mismo aviso sale dos veces en pantalla.
            recreateLoading -> LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            recreateDocument == null -> {
            Text(
            recreateError ?: "No se pudo recrear la imagen",
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodyMedium
            )
            OutlinedButton(
            onClick = {
            recreateDocument = null
            recreateError = null
            recreateLoading = false
            recreateRefresh++
            },
            modifier = Modifier.fillMaxWidth()
            ) {
            Icon(Icons.Rounded.Refresh, null)
            Text("  Reintentar")
            }
            }
            else -> {
            val readyDocument = recreateDocument
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
            onClick = { recreateEditing = true },
            modifier = Modifier.weight(1f).height(44.dp),
            contentPadding = PaddingValues(horizontal = 8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
            Text(
            "Editar texto",
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            style = MaterialTheme.typography.labelLarge
            )
            }
            Button(
            onClick = { if (readyDocument != null) requestRecreatedImageSave(readyDocument) },
            modifier = Modifier.weight(1f).height(44.dp),
            contentPadding = PaddingValues(horizontal = 8.dp),
            enabled = !saving && readyDocument != null,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF244A37), contentColor = Color.White)
            ) {
            Text(
            if (saving) "Guardando…" else "Guardar · ${tool.creditCost}",
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            style = MaterialTheme.typography.labelLarge
            )
            }
            }
            }
            }
            }
            }
            }

            // El aviso se dibuja despues del panel para quedar por encima de el.
            // El Snackbar del Scaffold no sirve aqui: aparece al fondo de la
            // pantalla, tapado por el panel, y solo asoma una franja ilegible.
            ScannerBanner(
                message = bannerMessage,
                isError = bannerIsError,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
        }
    }

    if (mode == 2 && recreateEditing) {
        ScannerRecreateEditorScreen(
            document = recreateDocument,
            loading = recreateLoading,
            error = recreateError,
            onDocumentChange = { recreateDocument = it },
            saving = saving,
            onBack = {
                recreateEditing = false
            },
            onRetry = {
                recreateDocument = null
                recreateError = null
                recreateLoading = false
                recreateRefresh++
            },
            onSave = ::requestRecreatedImageSave
        )
    }
}


/**
 * Cabecera de un paso del escaner: nombre de la herramienta elegida y un
 * boton para volver al menu de las dos herramientas.
 */
@Composable
private fun ScannerStepHeader(onBack: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onBack)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text("‹ Volver", color = NeonGreen, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
    }
}

/**
 * Aviso flotante del escaner. Se dibuja sobre la imagen para que se lea
 * completo, con color distinto segun sea error o confirmacion.
 */
@Composable
private fun ScannerBanner(message: String?, isError: Boolean, modifier: Modifier = Modifier) {
    if (message.isNullOrBlank()) return
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (isError) Color(0xFF7A1F22) else Color(0xFF1D4030),
                    RoundedCornerShape(14.dp)
                )
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (isError) Icons.Rounded.Refresh else Icons.Rounded.ContentCopy,
                null,
                tint = if (isError) Color(0xFFFFC9CB) else NeonGreen
            )
            Spacer(Modifier.width(10.dp))
            Text(
                message,
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * Pantalla del texto ya extraido. Ocupa todo el alto disponible: antes el
 * texto vivia en un recuadro de 148dp dentro del panel y apenas se veian
 * cuatro lineas. Aqui no hay nada de recrear imagen ni de seleccionar zona,
 * porque la extraccion ya ocurrio.
 */
@Composable
private fun ScannerExtractedTextPanel(
    text: String,
    creditCost: Int,
    busy: Boolean,
    modifier: Modifier = Modifier,
    onTextChange: (String) -> Unit,
    onCopy: () -> Unit,
    onRepeat: () -> Unit
) {
    val words = remember(text) { text.split(Regex("\\s+")).count { it.isNotBlank() } }
    Column(
        modifier = modifier.background(Color(0xFF101412)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Texto reconocido",
                color = Color.White,
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.weight(1f))
            Text(
                "$words palabras · ${text.length} caracteres",
                color = Color(0xFF9AB8A5),
                style = MaterialTheme.typography.labelMedium
            )
        }

        OutlinedTextField(
            value = text,
            onValueChange = onTextChange,
            modifier = Modifier.fillMaxWidth().weight(1f),
            textStyle = MaterialTheme.typography.bodyLarge,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = Color(0xFF35573F),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = NeonGreen
            ),
            shape = RoundedCornerShape(14.dp)
        )

        Button(
            onClick = onCopy,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            enabled = text.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.ContentCopy, null)
            Text("  Copiar texto", fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
            onClick = onRepeat,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            enabled = !busy
        ) {
            Icon(Icons.Rounded.Refresh, null)
            Text("  Extraer otra vez · $creditCost créditos")
        }
    }
}

private const val SCANNER_GALLERY_RECENT_LIMIT = 15
private const val SCANNER_GALLERY_THUMBNAIL_SIZE = 256
private const val SCANNER_GALLERY_CACHE_BYTES = 6 * 1024 * 1024
// La vista del escaner carga la imagen a resolucion nativa. 4096 es el tope
// que admite ToolFileUtils.loadBitmap, y por encima de eso la foto se reduce
// solo lo justo para no agotar la memoria. A 1440 se veia borrosa apenas se
// ampliaba con dos dedos.
private const val SCANNER_EDITOR_PREVIEW_MAX_EDGE = 4096
// El render de la imagen recreada se mantiene mas bajo: es un dibujo generado,
// no una foto, y a 4096 el Canvas tardaba demasiado en cada recomposicion.
private const val SCANNER_RECREATE_PREVIEW_MAX_EDGE = 2048
private const val SCANNER_OCR_MAX_EDGE = 2048
private const val SCANNER_RECREATE_ANALYSIS_MAX_EDGE = 1800
private const val SCANNER_RECREATE_OUTPUT_MAX_EDGE = 2400

private data class ScannerGalleryImage(val uri: Uri, val name: String)

private val scannerThumbnailSemaphore = Semaphore(3)
private val scannerThumbnailCache = object : android.util.LruCache<String, Bitmap>(SCANNER_GALLERY_CACHE_BYTES) {
    override fun sizeOf(key: String, value: Bitmap): Int = runCatching { value.allocationByteCount }.getOrDefault(value.byteCount)
}

private data class ScannerSelection(
    val left: Float = 0.10f,
    val top: Float = 0.20f,
    val right: Float = 0.90f,
    val bottom: Float = 0.62f
)

private enum class ScannerDragMode { MOVE, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }

private fun scannerGalleryPermissions(): Array<String> = when {
    android.os.Build.VERSION.SDK_INT >= 34 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
    )
    android.os.Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

private fun scannerGalleryPermissionGranted(context: android.content.Context): Boolean = when {
    android.os.Build.VERSION.SDK_INT >= 34 -> {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
    }
    android.os.Build.VERSION.SDK_INT >= 33 ->
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
    else -> ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
}

private suspend fun loadScannerRecentImages(
    context: android.content.Context,
    limit: Int
): List<ScannerGalleryImage> = withContext(Dispatchers.IO) {
    val safeLimit = limit.coerceIn(1, SCANNER_GALLERY_RECENT_LIMIT)
    val collection = if (android.os.Build.VERSION.SDK_INT >= 29) {
        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
    } else {
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    }
    val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
    val result = ArrayList<ScannerGalleryImage>(safeLimit)
    context.contentResolver.query(
        collection,
        projection,
        null,
        null,
        "${MediaStore.Images.Media.DATE_ADDED} DESC"
    )?.use { cursor ->
        val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        val nameColumn = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
        while (result.size < safeLimit && cursor.moveToNext()) {
            val id = cursor.getLong(idColumn)
            val uri = android.content.ContentUris.withAppendedId(collection, id)
            val name = if (nameColumn >= 0) cursor.getString(nameColumn).orEmpty() else ""
            result += ScannerGalleryImage(uri, name)
        }
    }
    result
}

private suspend fun loadScannerThumbnail(context: android.content.Context, uri: Uri): Bitmap = withContext(Dispatchers.IO) {
    val key = uri.toString()
    synchronized(scannerThumbnailCache) {
        scannerThumbnailCache.get(key)?.takeIf { !it.isRecycled }
    }?.let { return@withContext it }

    scannerThumbnailSemaphore.withPermit {
        synchronized(scannerThumbnailCache) {
            scannerThumbnailCache.get(key)?.takeIf { !it.isRecycled }
        }?.let { return@withPermit it }

        val decoded = if (android.os.Build.VERSION.SDK_INT >= 29) {
            context.contentResolver.loadThumbnail(
                uri,
                android.util.Size(SCANNER_GALLERY_THUMBNAIL_SIZE, SCANNER_GALLERY_THUMBNAIL_SIZE),
                null
            )
        } else {
            ToolFileUtils.loadBitmap(context, uri, SCANNER_GALLERY_THUMBNAIL_SIZE)
        }
        synchronized(scannerThumbnailCache) {
            scannerThumbnailCache.put(key, decoded)
        }
        decoded
    }
}

@Composable
private fun ScannerGalleryThumbnail(item: ScannerGalleryImage, onClick: () -> Unit) {
    val context = LocalContext.current
    var attempted by remember(item.uri) { mutableStateOf(false) }
    val bitmap by produceState<Bitmap?>(initialValue = null, item.uri) {
        value = runCatching { loadScannerThumbnail(context, item.uri) }.getOrNull()
        attempted = true
    }
    Box(
        modifier = Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp)).background(Color(0xFF163324)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap == null) {
            if (attempted) {
                Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, tint = Color.White.copy(alpha = 0.55f))
            } else {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = NeonGreen)
            }
        } else {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = item.name.ifBlank { "Foto" },
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
    }
}

@Composable
private fun ScannerImageViewport(
    bitmap: Bitmap,
    selectionEnabled: Boolean,
    selection: ScannerSelection,
    onSelectionChange: (ScannerSelection) -> Unit,
    modifier: Modifier = Modifier
) {
    // El zoom usa el mismo motor que los visores: una sola matriz GPU anclada al
    // punto entre los dedos. Antes se escalaba desde el centro con limites de
    // desplazamiento mal calculados, y por eso el pellizco se sentia trabado y la
    // imagen se escapaba de la pantalla.
    val zoomState = remember(bitmap) { mutableFloatStateOf(1f) }
    val panXState = remember(bitmap) { mutableFloatStateOf(0f) }
    val panYState = remember(bitmap) { mutableFloatStateOf(0f) }
    var zoom by zoomState
    var panX by panXState
    var panY by panYState
    val currentSelection by rememberUpdatedState(selection)
    val currentOnSelectionChange by rememberUpdatedState(onSelectionChange)

    LaunchedEffect(selectionEnabled) {
        if (selectionEnabled) {
            zoom = 1f
            panX = 0f
            panY = 0f
        }
    }

    BoxWithConstraints(modifier = modifier.clipToBounds(), contentAlignment = Alignment.Center) {
        val maxW = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val maxH = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val fit = minOf(maxW / bitmap.width.toFloat(), maxH / bitmap.height.toFloat())
        val imageW = bitmap.width * fit
        val imageH = bitmap.height * fit
        val imageLeft = (maxW - imageW) / 2f
        val imageTop = (maxH - imageH) / 2f

        // Doble toque para acercar y alejar, como en cualquier galeria. Se interpola
        // el zoom y el desplazamiento a la vez para que no haya saltos.
        val scope = rememberCoroutineScope()

        // Los limites se calculan contra la imagen realmente dibujada, no contra el
        // viewport. Con ContentScale.Fit la imagen queda centrada con franjas vacias a
        // los lados; usando el ancho del viewport los topes quedaban corridos y la
        // imagen se escapaba o rebotaba sola al soltar.
        val clampToImageX: (Float, Float) -> Float = { value, scale ->
            val minPan = maxW - (imageLeft + imageW) * scale
            val maxPan = -imageLeft * scale
            if (minPan >= maxPan) (minPan + maxPan) / 2f else value.coerceIn(minPan, maxPan)
        }
        val clampToImageY: (Float, Float) -> Float = { value, scale ->
            val minPan = maxH - (imageTop + imageH) * scale
            val maxPan = -imageTop * scale
            if (minPan >= maxPan) (minPan + maxPan) / 2f else value.coerceIn(minPan, maxPan)
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .then(
                    if (!selectionEnabled) {
                        Modifier
                            .viewerPinchZoomGestures(
                                gestureKey = bitmap,
                                zoomState = zoomState,
                                panXState = panXState,
                                panYState = panYState,
                                minZoom = 1f,
                                maxZoom = 6f,
                                viewportWidthPx = maxW,
                                viewportHeightPx = maxH,
                                allowSingleFingerPan = true,
                                clampXOverride = clampToImageX,
                                clampYOverride = clampToImageY
                            )
                            .pointerInput(bitmap) {
                                detectTapGestures(
                                    onDoubleTap = { tap ->
                                        val startZoom = zoomState.floatValue
                                        val startX = panXState.floatValue
                                        val startY = panYState.floatValue
                                        val targetZoom = if (startZoom > 1.4f) 1f else 2.6f
                                        val factor = targetZoom / startZoom.coerceAtLeast(0.001f)
                                        val targetX: Float
                                        val targetY: Float
                                        if (targetZoom <= 1.001f) {
                                            targetX = clampToImageX(0f, 1f)
                                            targetY = clampToImageY(0f, 1f)
                                        } else {
                                            targetX = clampToImageX(
                                                startX * factor + tap.x * (1f - factor),
                                                targetZoom
                                            )
                                            targetY = clampToImageY(
                                                startY * factor + tap.y * (1f - factor),
                                                targetZoom
                                            )
                                        }
                                        scope.launch {
                                            animate(
                                                initialValue = 0f,
                                                targetValue = 1f,
                                                animationSpec = tween(
                                                    durationMillis = 220,
                                                    easing = FastOutSlowInEasing
                                                )
                                            ) { progress, _ ->
                                                zoomState.floatValue =
                                                    startZoom + (targetZoom - startZoom) * progress
                                                panXState.floatValue =
                                                    startX + (targetX - startX) * progress
                                                panYState.floatValue =
                                                    startY + (targetY - startY) * progress
                                            }
                                            zoomState.floatValue = targetZoom
                                            panXState.floatValue = targetX
                                            panYState.floatValue = targetY
                                        }
                                    }
                                )
                            }
                    } else Modifier
                )
        ) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Imagen seleccionada",
                contentScale = ContentScale.Fit,
                // Al ampliar, el remuestreo por defecto deja el texto pastoso. Con
                // calidad alta el documento se lee nitido a 3x o 4x.
                filterQuality = FilterQuality.High,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = zoom
                        scaleY = zoom
                        translationX = panX
                        translationY = panY
                    }
            )
        }

        if (selectionEnabled) {
            var dragMode by remember { mutableStateOf<ScannerDragMode?>(null) }
            val handleRadius = 34f
            Canvas(
                modifier = Modifier.fillMaxSize().pointerInput(imageW, imageH, imageLeft, imageTop) {
                    detectDragGestures(
                        onDragStart = { p ->
                            fun pointX(v: Float) = imageLeft + v * imageW
                            fun pointY(v: Float) = imageTop + v * imageH
                            val s = currentSelection
                            val corners = listOf(
                                ScannerDragMode.TOP_LEFT to Offset(pointX(s.left), pointY(s.top)),
                                ScannerDragMode.TOP_RIGHT to Offset(pointX(s.right), pointY(s.top)),
                                ScannerDragMode.BOTTOM_LEFT to Offset(pointX(s.left), pointY(s.bottom)),
                                ScannerDragMode.BOTTOM_RIGHT to Offset(pointX(s.right), pointY(s.bottom))
                            )
                            dragMode = corners.minByOrNull { (_, c) -> (p - c).getDistance() }
                                ?.takeIf { (_, c) -> (p - c).getDistance() <= handleRadius * 1.5f }?.first
                                ?: if (
                                    p.x in pointX(s.left)..pointX(s.right) &&
                                    p.y in pointY(s.top)..pointY(s.bottom)
                                ) ScannerDragMode.MOVE else null
                        },
                        onDragEnd = { dragMode = null },
                        onDragCancel = { dragMode = null }
                    ) { _, drag ->
                        val dx = drag.x / imageW
                        val dy = drag.y / imageH
                        val s = currentSelection
                        val minSize = 0.06f
                        val next = when (dragMode) {
                            ScannerDragMode.MOVE -> {
                                val width = s.right - s.left
                                val height = s.bottom - s.top
                                val l = (s.left + dx).coerceIn(0f, 1f - width)
                                val t = (s.top + dy).coerceIn(0f, 1f - height)
                                ScannerSelection(l, t, l + width, t + height)
                            }
                            ScannerDragMode.TOP_LEFT -> s.copy(
                                left = (s.left + dx).coerceIn(0f, s.right - minSize),
                                top = (s.top + dy).coerceIn(0f, s.bottom - minSize)
                            )
                            ScannerDragMode.TOP_RIGHT -> s.copy(
                                right = (s.right + dx).coerceIn(s.left + minSize, 1f),
                                top = (s.top + dy).coerceIn(0f, s.bottom - minSize)
                            )
                            ScannerDragMode.BOTTOM_LEFT -> s.copy(
                                left = (s.left + dx).coerceIn(0f, s.right - minSize),
                                bottom = (s.bottom + dy).coerceIn(s.top + minSize, 1f)
                            )
                            ScannerDragMode.BOTTOM_RIGHT -> s.copy(
                                right = (s.right + dx).coerceIn(s.left + minSize, 1f),
                                bottom = (s.bottom + dy).coerceIn(s.top + minSize, 1f)
                            )
                            null -> s
                        }
                        if (next != s) currentOnSelectionChange(next)
                    }
                }
            ) {
                val s = selection
                val l = imageLeft + s.left * imageW
                val t = imageTop + s.top * imageH
                val r = imageLeft + s.right * imageW
                val b = imageTop + s.bottom * imageH
                val shade = Color.Black.copy(alpha = 0.48f)
                drawRect(shade, Offset(imageLeft, imageTop), androidx.compose.ui.geometry.Size(imageW, (t - imageTop).coerceAtLeast(0f)))
                drawRect(shade, Offset(imageLeft, b), androidx.compose.ui.geometry.Size(imageW, (imageTop + imageH - b).coerceAtLeast(0f)))
                drawRect(shade, Offset(imageLeft, t), androidx.compose.ui.geometry.Size((l - imageLeft).coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))
                drawRect(shade, Offset(r, t), androidx.compose.ui.geometry.Size((imageLeft + imageW - r).coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))
                drawRect(
                    color = NeonGreen,
                    topLeft = Offset(l, t),
                    size = androidx.compose.ui.geometry.Size((r - l).coerceAtLeast(1f), (b - t).coerceAtLeast(1f)),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                )
                listOf(Offset(l, t), Offset(r, t), Offset(l, b), Offset(r, b)).forEach {
                    drawCircle(Color.White, radius = 13f, center = it)
                    drawCircle(NeonGreen, radius = 9f, center = it)
                }
            }
        }
    }
}

private suspend fun scannerUriReadable(context: android.content.Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
    try {
        context.contentResolver.openInputStream(uri)?.use { true } ?: false
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (_: Throwable) {
        false
    }
}

private data class ScannerRecognizedLine(
    val text: String,
    val bounds: android.graphics.Rect
)

private data class ScannerTextStyleSpan(
    val start: Int,
    val end: Int,
    val scale: Float
)

private data class ScannerRecreateLine(
    val id: Int,
    val text: String,
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
    val fontScale: Float = 1f,
    val bold: Boolean = false,
    val underlined: Boolean = false,
    val styleSpans: List<ScannerTextStyleSpan> = emptyList()
)

private data class ScannerRecreateDocument(
    val aspectRatio: Float,
    val body: String,
    val lines: List<ScannerRecreateLine> = emptyList(),
    // Geometria original del escaneo. Al elegir A4/Carta solo proyectamos estas
    // coordenadas sobre el nuevo lienzo; nunca estiramos ni perdemos el Original.
    val sourceAspectRatio: Float = aspectRatio,
    val sourceLines: List<ScannerRecreateLine> = lines,
    val fontSize: Float = 16f,
    val fontFamilyIndex: Int = 0,
    val bold: Boolean = false,
    val underlined: Boolean = false,
    // Formato por tramos del cuerpo. Permite que negrita, subrayado y tamano
    // se apliquen solo a lo que el usuario selecciona, como en un procesador
    // de texto, en vez de afectar el documento entero.
    val bodyStyleSpans: List<EditorTextStyleSpan> = emptyList()
)

private fun scannerTypeface(index: Int, bold: Boolean): android.graphics.Typeface {
    val family = when (index.mod(3)) {
        1 -> android.graphics.Typeface.SERIF
        2 -> android.graphics.Typeface.MONOSPACE
        else -> android.graphics.Typeface.SANS_SERIF
    }
    return android.graphics.Typeface.create(
        family,
        if (bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL
    )
}

@Composable
private fun ScannerRecreatePreview(
    document: ScannerRecreateDocument?,
    loading: Boolean,
    error: String?,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.clipToBounds(), contentAlignment = Alignment.Center) {
        when {
            loading -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CircularProgressIndicator(color = NeonGreen)
                    Text("Recreando la imagen…", color = Color.White.copy(alpha = 0.78f))
                }
            }
            document == null -> Text(
                error ?: "No se pudo recrear la imagen",
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(20.dp)
            )
            else -> {
                val previewBitmap by produceState<Bitmap?>(initialValue = null, document) {
                    value = withContext(Dispatchers.Default) {
                        renderScannerRecreateDocumentBitmap(document, SCANNER_RECREATE_PREVIEW_MAX_EDGE)
                    }
                }
                DisposableEffect(previewBitmap) {
                    val bitmap = previewBitmap
                    onDispose {
                        if (bitmap != null && !bitmap.isRecycled) bitmap.recycle()
                    }
                }
                if (previewBitmap == null) {
                    CircularProgressIndicator(color = NeonGreen)
                } else {
                    ScannerImageViewport(
                        bitmap = previewBitmap!!,
                        selectionEnabled = false,
                        selection = ScannerSelection(),
                        onSelectionChange = {},
                        modifier = Modifier.fillMaxSize().padding(10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ScannerRecreateEditorScreen(
    document: ScannerRecreateDocument?,
    loading: Boolean,
    error: String?,
    onDocumentChange: (ScannerRecreateDocument) -> Unit,
    saving: Boolean,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    onSave: (ScannerRecreateDocument) -> Unit
) {
    // Este editor se dibuja como una capa de la MISMA pantalla del escaner.
    // Antes se abría un Dialog de pantalla completa: Android llegaba a pintar
    // primero el fondo oscuro y después la hoja, produciendo el flash negro.
    // Al ser una capa normal no hay cambio de ventana ni transición negra.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .zIndex(50f)
            .background(Color(0xFF0E0E0E))
    ) {
        when {
            loading -> Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(color = NeonGreen)
                    Text("Reconstruyendo el documento…", color = Color(0xFFD5D5D5))
                }
            }

            document == null -> Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2A22)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(
                        Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            error ?: "No se pudo reconstruir la imagen",
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )
                        OutlinedButton(onClick = onRetry) { Text("Reintentar") }
                        OutlinedButton(onClick = onBack) { Text("Cerrar") }
                    }
                }
            }

            else -> ScannerTextDocumentEditor(
                document = document,
                saving = saving,
                onDocumentChange = onDocumentChange,
                onBack = onBack,
                onSave = onSave
            )
        }
    }
}

private enum class ScannerImageFormatPreset(val label: String, val ratio: Float?) {
    ORIGINAL("Original", null),
    A4_PORTRAIT("A4 V", 210f / 297f),
    A4_LANDSCAPE("A4 H", 297f / 210f),
    LETTER_PORTRAIT("Carta V", 8.5f / 11f),
    LETTER_LANDSCAPE("Carta H", 11f / 8.5f);

    fun resolvedRatio(originalRatio: Float): Float = ratio ?: originalRatio
}

private data class ScannerEditorHistorySnapshot(
    val lines: List<ScannerRecreateLine>,
    val aspectRatio: Float,
    val fontFamilyIndex: Int,
    val bold: Boolean,
    val underlined: Boolean
)

private fun scannerEditorCopyLines(lines: List<ScannerRecreateLine>): List<ScannerRecreateLine> =
    lines.map { line -> line.copy(styleSpans = line.styleSpans.map { it.copy() }) }

private fun scannerResolveImagePreset(currentRatio: Float, originalRatio: Float): ScannerImageFormatPreset {
    val safeCurrent = currentRatio.coerceIn(0.35f, 2.8f)
    val safeOriginal = originalRatio.coerceIn(0.35f, 2.8f)
    fun closeTo(target: Float) = kotlin.math.abs(safeCurrent - target) <= 0.035f
    return when {
        kotlin.math.abs(safeCurrent - safeOriginal) <= 0.035f -> ScannerImageFormatPreset.ORIGINAL
        closeTo(210f / 297f) -> ScannerImageFormatPreset.A4_PORTRAIT
        closeTo(297f / 210f) -> ScannerImageFormatPreset.A4_LANDSCAPE
        closeTo(8.5f / 11f) -> ScannerImageFormatPreset.LETTER_PORTRAIT
        closeTo(11f / 8.5f) -> ScannerImageFormatPreset.LETTER_LANDSCAPE
        else -> ScannerImageFormatPreset.ORIGINAL
    }
}


private fun scannerProjectLinesToCanvas(
    sourceLines: List<ScannerRecreateLine>,
    sourceAspectRatio: Float,
    targetAspectRatio: Float
): List<ScannerRecreateLine> {
    val sourceRatio = sourceAspectRatio.coerceIn(0.35f, 2.8f)
    val targetRatio = targetAspectRatio.coerceIn(0.35f, 2.8f)
    if (kotlin.math.abs(sourceRatio - targetRatio) < 0.0005f) {
        return scannerEditorCopyLines(sourceLines)
    }

    // Coordenadas logicas: alto = 1 y ancho = aspectRatio. Se escala todo el
    // documento de forma UNIFORME y luego se centra. Así A4/Carta son solo un
    // lienzo de referencia; el contenido jamás se estira horizontal o verticalmente.
    val scale = minOf(targetRatio / sourceRatio, 1f)
    val projectedWidth = sourceRatio * scale
    val projectedHeight = scale
    val offsetX = (targetRatio - projectedWidth) / 2f
    val offsetY = (1f - projectedHeight) / 2f

    return sourceLines.map { line ->
        val logicalLeft = line.left * sourceRatio
        val logicalWidth = line.width * sourceRatio
        line.copy(
            left = ((offsetX + logicalLeft * scale) / targetRatio).coerceIn(0f, 1f),
            top = (offsetY + line.top * scale).coerceIn(0f, 1f),
            width = (logicalWidth * scale / targetRatio).coerceIn(0.001f, 1f),
            height = (line.height * scale).coerceIn(0.001f, 1f)
        )
    }
}

private fun scannerRemapLineScaleSpans(
    oldText: String,
    newText: String,
    spans: List<ScannerTextStyleSpan>
): List<ScannerTextStyleSpan> {
    if (newText.isEmpty() || spans.isEmpty()) return emptyList()
    val oldStyles = FloatArray(oldText.length) { 1f }
    spans.forEach { span ->
        val from = span.start.coerceIn(0, oldText.length)
        val to = span.end.coerceIn(from, oldText.length)
        for (index in from until to) oldStyles[index] = span.scale.coerceIn(0.65f, 2.2f)
    }
    var prefix = 0
    while (prefix < oldText.length && prefix < newText.length && oldText[prefix] == newText[prefix]) prefix++
    var suffix = 0
    while (
        suffix < oldText.length - prefix &&
        suffix < newText.length - prefix &&
        oldText[oldText.length - 1 - suffix] == newText[newText.length - 1 - suffix]
    ) suffix++
    val next = FloatArray(newText.length) { 1f }
    for (index in 0 until prefix.coerceAtMost(newText.length)) {
        if (index in oldStyles.indices) next[index] = oldStyles[index]
    }
    for (offset in 0 until suffix) {
        val oldIndex = oldText.length - suffix + offset
        val newIndex = newText.length - suffix + offset
        if (oldIndex in oldStyles.indices && newIndex in next.indices) next[newIndex] = oldStyles[oldIndex]
    }
    val insertedStart = prefix
    val insertedEnd = newText.length - suffix
    if (insertedEnd > insertedStart) {
        val inherit = when {
            prefix > 0 && prefix - 1 in oldStyles.indices -> oldStyles[prefix - 1]
            prefix in oldStyles.indices -> oldStyles[prefix]
            else -> 1f
        }
        for (index in insertedStart until insertedEnd) next[index] = inherit
    }
    val result = mutableListOf<ScannerTextStyleSpan>()
    var start = 0
    while (start < next.size) {
        val scale = next[start]
        var end = start + 1
        while (end < next.size && kotlin.math.abs(next[end] - scale) < 0.005f) end++
        if (kotlin.math.abs(scale - 1f) > 0.005f) result += ScannerTextStyleSpan(start, end, scale)
        start = end
    }
    return result
}

private fun scannerAdjustLineScaleSpans(
    textLength: Int,
    spans: List<ScannerTextStyleSpan>,
    from: Int,
    to: Int,
    delta: Float
): List<ScannerTextStyleSpan> {
    if (textLength <= 0 || to <= from) return spans
    val scales = FloatArray(textLength) { 1f }
    spans.forEach { span ->
        val start = span.start.coerceIn(0, textLength)
        val end = span.end.coerceIn(start, textLength)
        for (index in start until end) scales[index] = span.scale.coerceIn(0.65f, 2.2f)
    }
    for (index in from.coerceIn(0, textLength) until to.coerceIn(0, textLength)) {
        scales[index] = (scales[index] + delta).coerceIn(0.65f, 2.2f)
    }
    val result = mutableListOf<ScannerTextStyleSpan>()
    var start = 0
    while (start < textLength) {
        val scale = scales[start]
        var end = start + 1
        while (end < textLength && kotlin.math.abs(scales[end] - scale) < 0.005f) end++
        if (kotlin.math.abs(scale - 1f) > 0.005f) result += ScannerTextStyleSpan(start, end, scale)
        start = end
    }
    return result
}

private fun scannerLineVisualTransformation(
    spans: List<ScannerTextStyleSpan>,
    baseFontSize: androidx.compose.ui.unit.TextUnit
): VisualTransformation = VisualTransformation { source ->
    val builder = AnnotatedString.Builder(source)
    spans.forEach { span ->
        val from = span.start.coerceIn(0, source.length)
        val to = span.end.coerceIn(from, source.length)
        if (to > from) {
            builder.addStyle(
                SpanStyle(fontSize = (baseFontSize.value * span.scale.coerceIn(0.65f, 2.2f)).sp),
                from,
                to
            )
        }
    }
    TransformedText(builder.toAnnotatedString(), OffsetMapping.Identity)
}

private fun scannerAnnotatedLine(
    text: String,
    spans: List<ScannerTextStyleSpan>,
    baseFontSize: androidx.compose.ui.unit.TextUnit
): AnnotatedString {
    val builder = AnnotatedString.Builder(text)
    spans.forEach { span ->
        val from = span.start.coerceIn(0, text.length)
        val to = span.end.coerceIn(from, text.length)
        if (to > from) {
            builder.addStyle(
                SpanStyle(fontSize = (baseFontSize.value * span.scale.coerceIn(0.65f, 2.2f)).sp),
                from,
                to
            )
        }
    }
    return builder.toAnnotatedString()
}

/**
 * Editor visual del documento recreado por el escaner.
 *
 * A diferencia de la version anterior, ya no destruye la maquetacion del OCR
 * convirtiendo todo a un solo bloque de texto. La hoja que el usuario ve al
 * entrar se mantiene en pantalla y cada linea detectada por OCR se puede
 * seleccionar y editar sobre la misma pagina. El resultado sigue guardandose
 * solo como imagen.
 */
@Composable
private fun ScannerTextDocumentEditor(
    document: ScannerRecreateDocument,
    saving: Boolean,
    onDocumentChange: (ScannerRecreateDocument) -> Unit,
    onBack: () -> Unit,
    onSave: (ScannerRecreateDocument) -> Unit
) {
    // Estado canonico: siempre editamos las coordenadas originales del OCR.
    // A4/Carta solo cambian el lienzo donde se proyectan; por eso "Original"
    // puede volver exactamente a la recreacion inicial sin deformaciones.
    val originalAspectRatio = remember {
        document.sourceAspectRatio.coerceIn(0.35f, 2.8f)
    }
    var sourceLines by remember {
        mutableStateOf(
            scannerEditorCopyLines(
                document.sourceLines.ifEmpty { document.lines }
            )
        )
    }
    var targetAspectRatio by remember {
        mutableFloatStateOf(document.aspectRatio.coerceIn(0.35f, 2.8f))
    }
    var selectedPreset by remember {
        mutableStateOf(scannerResolveImagePreset(targetAspectRatio, originalAspectRatio))
    }
    var fontFamilyIndex by remember { mutableIntStateOf(document.fontFamilyIndex) }
    var documentBold by remember { mutableStateOf(document.bold) }
    var documentUnderlined by remember { mutableStateOf(document.underlined) }

    var selectedLineId by remember { mutableIntStateOf(-1) }
    var editingLineId by remember { mutableIntStateOf(-1) }
    var editorValue by remember { mutableStateOf(TextFieldValue("")) }
    var undoStack by remember { mutableStateOf<List<ScannerEditorHistorySnapshot>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<ScannerEditorHistorySnapshot>>(emptyList()) }

    // Zoom solo de vista. No cambia el documento ni la imagen que se guarda.
    // Dos dedos amplian/reducen la hoja; con un dedo se desplaza normalmente.
    var viewZoom by remember { mutableFloatStateOf(1f) }

    val editFocusRequester = remember { FocusRequester() }

    fun projectedLines(): List<ScannerRecreateLine> = scannerProjectLinesToCanvas(
        sourceLines = sourceLines,
        sourceAspectRatio = originalAspectRatio,
        targetAspectRatio = targetAspectRatio
    )

    fun currentDocument(): ScannerRecreateDocument {
        val projected = projectedLines()
        return document.copy(
            aspectRatio = targetAspectRatio.coerceIn(0.35f, 2.8f),
            body = scannerBuildRecreateBody(sourceLines),
            lines = projected,
            sourceAspectRatio = originalAspectRatio,
            sourceLines = scannerEditorCopyLines(sourceLines),
            fontFamilyIndex = fontFamilyIndex,
            bold = documentBold,
            underlined = documentUnderlined
        )
    }

    fun snapshot(): ScannerEditorHistorySnapshot = ScannerEditorHistorySnapshot(
        lines = scannerEditorCopyLines(sourceLines),
        aspectRatio = targetAspectRatio,
        fontFamilyIndex = fontFamilyIndex,
        bold = documentBold,
        underlined = documentUnderlined
    )

    fun pushUndoSnapshot() {
        val item = snapshot()
        if (undoStack.lastOrNull() != item) {
            undoStack = (undoStack + item).takeLast(EDITOR_HISTORY_LIMIT)
        }
        redoStack = emptyList()
    }

    fun applySnapshot(item: ScannerEditorHistorySnapshot) {
        sourceLines = scannerEditorCopyLines(item.lines)
        targetAspectRatio = item.aspectRatio.coerceIn(0.35f, 2.8f)
        fontFamilyIndex = item.fontFamilyIndex
        documentBold = item.bold
        documentUnderlined = item.underlined
        selectedPreset = scannerResolveImagePreset(targetAspectRatio, originalAspectRatio)
        if (sourceLines.none { it.id == selectedLineId }) selectedLineId = -1
        editingLineId = -1
        editorValue = TextFieldValue("")
    }

    fun commitLocalState() {
        onDocumentChange(currentDocument())
    }

    fun mutateDocument(change: () -> Unit) {
        val before = snapshot()
        change()
        val after = snapshot()
        if (before != after) {
            undoStack = (undoStack + before).takeLast(EDITOR_HISTORY_LIMIT)
            redoStack = emptyList()
            commitLocalState()
        }
    }

    fun stopEditing(hideKeyboard: Boolean = false) {
        if (editingLineId >= 0) {
            editingLineId = -1
            editorValue = TextFieldValue("")
            commitLocalState()
        }
    }

    fun undo() {
        if (editingLineId >= 0) {
            editingLineId = -1
            editorValue = TextFieldValue("")
        }
        val target = undoStack.lastOrNull() ?: return
        val current = snapshot()
        undoStack = undoStack.dropLast(1)
        redoStack = (redoStack + current).takeLast(EDITOR_HISTORY_LIMIT)
        applySnapshot(target)
        commitLocalState()
    }

    fun redo() {
        if (editingLineId >= 0) {
            editingLineId = -1
            editorValue = TextFieldValue("")
        }
        val target = redoStack.lastOrNull() ?: return
        val current = snapshot()
        redoStack = redoStack.dropLast(1)
        undoStack = (undoStack + current).takeLast(EDITOR_HISTORY_LIMIT)
        applySnapshot(target)
        commitLocalState()
    }

    fun selectedSourceLine(): ScannerRecreateLine? =
        sourceLines.firstOrNull { it.id == selectedLineId }

    fun updateSelectedLine(
        recordHistory: Boolean = true,
        commit: Boolean = true,
        transform: (ScannerRecreateLine) -> ScannerRecreateLine
    ) {
        val id = selectedLineId
        if (id < 0) return
        if (recordHistory) pushUndoSnapshot()
        sourceLines = sourceLines.map { line ->
            if (line.id == id) transform(line) else line
        }
        if (recordHistory) redoStack = emptyList()
        if (commit) commitLocalState()
    }

    fun startEditing(lineId: Int) {
        val line = sourceLines.firstOrNull { it.id == lineId } ?: return
        if (editingLineId != line.id) pushUndoSnapshot()
        selectedLineId = line.id
        editingLineId = line.id
        editorValue = TextFieldValue(line.text, TextRange(line.text.length))
    }

    fun applyFormat(preset: ScannerImageFormatPreset) {
        stopEditing(hideKeyboard = true)
        mutateDocument {
            selectedPreset = preset
            targetAspectRatio = preset.resolvedRatio(originalAspectRatio).coerceIn(0.35f, 2.8f)
        }
    }

    fun deleteSelectedLine() {
        val id = selectedLineId
        if (id < 0) return
        pushUndoSnapshot()
        sourceLines = sourceLines.filterNot { it.id == id }
        selectedLineId = -1
        editingLineId = -1
        editorValue = TextFieldValue("")
        redoStack = emptyList()
        commitLocalState()
    }

    fun applySizeDelta(delta: Float) {
        val line = selectedSourceLine() ?: return
        val selection = editorValue.selection
        val from = minOf(selection.start, selection.end).coerceIn(0, line.text.length)
        val to = maxOf(selection.start, selection.end).coerceIn(from, line.text.length)

        if (editingLineId == line.id && to > from) {
            // Con una palabra/frase seleccionada, A+ y A- afectan solo ese tramo.
            updateSelectedLine(recordHistory = true, commit = false) { target ->
                target.copy(
                    styleSpans = scannerAdjustLineScaleSpans(
                        textLength = target.text.length,
                        spans = target.styleSpans,
                        from = from,
                        to = to,
                        delta = delta
                    )
                )
            }
        } else {
            // Sin seleccion de caracteres, A+ / A- afecta toda la linea. Usamos
            // spans relativos y no fontScale: el ajuste de OCR sigue intacto y
            // el tamaño realmente crece en vez de volver a encogerse para caber.
            updateSelectedLine(recordHistory = true, commit = editingLineId < 0) { target ->
                target.copy(
                    styleSpans = scannerAdjustLineScaleSpans(
                        textLength = target.text.length,
                        spans = target.styleSpans,
                        from = 0,
                        to = target.text.length,
                        delta = delta
                    )
                )
            }
        }
    }

    fun toggleBold() {
        if (selectedSourceLine() == null) return
        updateSelectedLine(recordHistory = true, commit = editingLineId < 0) {
            it.copy(bold = !it.bold)
        }
    }

    fun toggleUnderline() {
        if (selectedSourceLine() == null) return
        updateSelectedLine(recordHistory = true, commit = editingLineId < 0) {
            it.copy(underlined = !it.underlined)
        }
    }

    fun cycleFontFamily() {
        if (editingLineId >= 0) {
            pushUndoSnapshot()
            fontFamilyIndex = (fontFamilyIndex + 1) % 3
            redoStack = emptyList()
        } else {
            mutateDocument { fontFamilyIndex = (fontFamilyIndex + 1) % 3 }
        }
    }

    val selectedSourceLine = selectedSourceLine()
    val projectedLines = projectedLines()
    val editingProjectedLine = projectedLines.firstOrNull { it.id == editingLineId }
    val editingSourceLine = sourceLines.firstOrNull { it.id == editingLineId }

    val fontLabel = when (fontFamilyIndex.mod(3)) {
        1 -> "Serif"
        2 -> "Mono"
        else -> "Sans"
    }
    val composeFontFamily = when (fontFamilyIndex.mod(3)) {
        1 -> FontFamily.Serif
        2 -> FontFamily.Monospace
        else -> FontFamily.SansSerif
    }

    // Bitmap inicial SINCRONO: la primera imagen del editor ya existe en el
    // primer frame. Después las actualizaciones se recalculan en background,
    // manteniendo el bitmap anterior mientras tanto; nunca aparece una hoja
    // vacia ni un flash negro.
    val initialRenderedDocument = remember { currentDocument() }
    var previewBitmap by remember {
        mutableStateOf(
            renderScannerRecreateDocumentBitmap(
                initialRenderedDocument,
                SCANNER_RECREATE_PREVIEW_MAX_EDGE
            )
        )
    }
    val renderedDocument = currentDocument()
    LaunchedEffect(renderedDocument, editingLineId) {
        if (editingLineId < 0) {
            val nextBitmap = withContext(Dispatchers.Default) {
                renderScannerRecreateDocumentBitmap(
                    renderedDocument,
                    SCANNER_RECREATE_PREVIEW_MAX_EDGE
                )
            }
            previewBitmap = nextBitmap
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            val bitmap = previewBitmap
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    LaunchedEffect(editingLineId) {
        if (editingLineId >= 0) {
            delay(40)
            runCatching { editFocusRequester.requestFocus() }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0E0E))
            .statusBarsPadding()
            .imePadding()
    ) {
        // Barra superior compacta. No cambia de ventana, por eso no hay flash.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .background(Color(0xFF171717))
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Listo",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier
                    .clickable {
                        stopEditing(hideKeyboard = true)
                        commitLocalState()
                        onBack()
                    }
                    .padding(horizontal = 10.dp, vertical = 10.dp)
            )
            IconButton(onClick = { commitLocalState() }) {
                Icon(Icons.Rounded.Save, "Aplicar cambios", tint = Color(0xFFDADADA))
            }
            IconButton(onClick = ::undo, enabled = undoStack.isNotEmpty()) {
                Icon(
                    Icons.Rounded.Undo,
                    "Deshacer",
                    tint = if (undoStack.isNotEmpty()) Color(0xFFDADADA) else Color(0xFF555555)
                )
            }
            IconButton(onClick = ::redo, enabled = redoStack.isNotEmpty()) {
                Icon(
                    Icons.Rounded.Redo,
                    "Rehacer",
                    tint = if (redoStack.isNotEmpty()) Color(0xFFDADADA) else Color(0xFF555555)
                )
            }
            Spacer(Modifier.weight(1f))
            if (viewZoom > 1.01f) {
                Text(
                    "${(viewZoom * 100).roundToInt()}%",
                    color = Color(0xFFDADADA),
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier
                        .clickable { viewZoom = 1f }
                        .padding(horizontal = 7.dp, vertical = 6.dp)
                )
            }
            Box(
                modifier = Modifier
                    .background(Color(0xFF2B4A36), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text("IMG", color = NeonGreen, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = {
                stopEditing(hideKeyboard = true)
                commitLocalState()
                onBack()
            }) {
                Icon(Icons.Rounded.Close, "Cerrar", tint = Color(0xFFDADADA))
            }
        }

        // La hoja conserva el mismo aspecto del recreado. El zoom es solo visual:
        // no modifica coordenadas, formato ni la imagen que se guarda.
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF101010))
                .clipToBounds()
        ) {
            val density = LocalDensity.current
            val basePageWidth = (maxWidth - 16.dp).coerceAtLeast(180.dp)
            val pageWidth = basePageWidth * viewZoom
            val pageHeight = pageWidth / targetAspectRatio.coerceIn(0.35f, 2.8f)
            val pageWidthPx = with(density) { pageWidth.toPx() }
            val pageHeightPx = with(density) { pageHeight.toPx() }
            val pageScroll = rememberScrollState()
            val horizontalPageScroll = rememberScrollState()
            val contentWidth = maxOf(maxWidth, pageWidth + 16.dp)
            val contentHeight = pageHeight + 16.dp

            // El pellizco cambia el tamano de visualizacion. Se interceptan solo
            // dos dedos; con uno siguen funcionando el scroll y la edicion normal.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(targetAspectRatio) {
                        awaitEachGesture {
                            do {
                                val event = awaitPointerEvent(PointerEventPass.Initial)
                                val pressed = event.changes.filter { it.pressed }
                                if (pressed.size >= 2) {
                                    val next = (viewZoom * event.calculateZoom()).coerceIn(1f, 4.5f)
                                    if (kotlin.math.abs(next - viewZoom) > 0.0005f) {
                                        viewZoom = next
                                    }
                                    event.changes.forEach { it.consume() }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(pageScroll)
                        .horizontalScroll(horizontalPageScroll)
                ) {
                    Box(
                        modifier = Modifier
                            .width(contentWidth)
                            .height(contentHeight)
                    ) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 8.dp)
                                .width(pageWidth)
                                .height(pageHeight)
                                .background(Color.White, RoundedCornerShape(2.dp))
                                .clip(RoundedCornerShape(2.dp))
                        ) {
                            Image(
                                bitmap = previewBitmap.asImageBitmap(),
                                contentDescription = "Documento recreado editable",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.FillBounds,
                                filterQuality = FilterQuality.High
                            )

                            // Zonas de texto invisibles. No se dibuja ningun marco
                            // verde: un toque entra directamente a editar, como en un
                            // editor de texto normal.
                            projectedLines.forEach { line ->
                                val leftPx = line.left * pageWidthPx
                                val topPx = line.top * pageHeightPx
                                val widthPx = (line.width * pageWidthPx).coerceAtLeast(26f)
                                val heightPx = (line.height * pageHeightPx).coerceAtLeast(18f)
                                Box(
                                    modifier = Modifier
                                        .offset(
                                            x = with(density) { leftPx.toDp() },
                                            y = with(density) { topPx.toDp() }
                                        )
                                        .width(with(density) { widthPx.toDp() })
                                        .height(with(density) { heightPx.toDp() })
                                        .pointerInput(line.id, editingLineId) {
                                            // Mientras se escribe una linea, el campo
                                            // de texto es quien maneja los toques. Al
                                            // salir con OK se puede tocar otra linea.
                                            if (editingLineId < 0) {
                                                detectTapGestures(
                                                    onTap = { startEditing(line.id) }
                                                )
                                            }
                                        }
                                )
                            }

                            // Campo real sobre la misma linea de la hoja. La zona se
                            // limpia en blanco solo mientras se escribe; al pulsar OK
                            // se vuelve a renderizar la misma recreacion con el cambio.
                            if (editingProjectedLine != null && editingSourceLine != null) {
                                val line = editingProjectedLine
                                val sourceLine = editingSourceLine
                                val leftPx = line.left * pageWidthPx
                                val topPx = line.top * pageHeightPx
                                val boxWidthPx = (line.width * pageWidthPx).coerceAtLeast(26f)
                                val boxHeightPx = (line.height * pageHeightPx).coerceAtLeast(18f)
                                val textSizePx = scannerFittedTextSize(
                                    text = sourceLine.text.ifBlank { " " },
                                    boxWidth = boxWidthPx,
                                    boxHeight = boxHeightPx,
                                    typeface = scannerTypeface(fontFamilyIndex, documentBold || sourceLine.bold),
                                    scale = sourceLine.fontScale
                                )
                                val textSizeSp = with(density) { textSizePx.toSp() }
                                val editableWidthPx = (
                                    pageWidthPx - leftPx - pageWidthPx * 0.015f
                                ).coerceAtLeast(boxWidthPx)
                                val maxInlineScale = sourceLine.styleSpans.maxOfOrNull { it.scale }
                                    ?.coerceIn(0.65f, 2.2f) ?: 1f
                                val editorHeightPx = maxOf(
                                    boxHeightPx,
                                    textSizePx * 1.45f * maxInlineScale
                                )

                                Box(
                                    modifier = Modifier
                                        .offset(
                                            x = with(density) { leftPx.toDp() },
                                            y = with(density) { topPx.toDp() }
                                        )
                                        .width(with(density) { editableWidthPx.toDp() })
                                        .height(with(density) { editorHeightPx.toDp() })
                                        .background(Color.White)
                                ) {
                                    BasicTextField(
                                        value = editorValue,
                                        onValueChange = { next ->
                                            val oldText = sourceLine.text
                                            editorValue = next
                                            sourceLines = sourceLines.map { item ->
                                                if (item.id == editingLineId) {
                                                    item.copy(
                                                        text = next.text,
                                                        styleSpans = scannerRemapLineScaleSpans(
                                                            oldText,
                                                            next.text,
                                                            item.styleSpans
                                                        )
                                                    )
                                                } else item
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .focusRequester(editFocusRequester),
                                        singleLine = true,
                                        textStyle = androidx.compose.ui.text.TextStyle(
                                            color = Color.Black,
                                            fontSize = textSizeSp,
                                            lineHeight = with(density) { (textSizePx * 1.18f).toSp() },
                                            fontFamily = composeFontFamily,
                                            fontWeight = if (documentBold || sourceLine.bold) FontWeight.Bold else FontWeight.Normal,
                                            textDecoration = if (documentUnderlined || sourceLine.underlined) TextDecoration.Underline else null
                                        ),
                                        visualTransformation = scannerLineVisualTransformation(
                                            sourceLine.styleSpans,
                                            textSizeSp
                                        ),
                                        cursorBrush = SolidColor(Color.Black)
                                    )
                                }
                            }

                            if (saving) {
                                LinearProgressIndicator(
                                    modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        // Controles compactos: dejan la mayor parte de la pantalla a la hoja.
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF242424))
                .navigationBarsPadding()
        ) {
            Text(
                when {
                    editingLineId >= 0 -> "Edita normalmente · selecciona una palabra para usar A+ / A−"
                    else -> "Toca el texto para editar · pellizca con dos dedos para zoom"
                },
                color = Color(0xFFBDBDBD),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                textAlign = TextAlign.Center
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ScannerImageFormatPreset.entries.forEach { preset ->
                    ScannerEditorToolButton(
                        label = preset.label,
                        active = selectedPreset == preset,
                        weight = FontWeight.Bold,
                        size = 12.sp
                    ) { applyFormat(preset) }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ScannerEditorToolButton(
                    if (editingLineId >= 0) "OK" else "Editar",
                    editingLineId >= 0,
                    FontWeight.Bold,
                    14.sp
                ) {
                    if (editingLineId >= 0) stopEditing(hideKeyboard = true)
                    else selectedSourceLine?.let { startEditing(it.id) }
                }
                ScannerEditorToolButton("A−", false, FontWeight.Bold, 18.sp) { applySizeDelta(-0.12f) }
                ScannerEditorToolButton("A+", false, FontWeight.Bold, 18.sp) { applySizeDelta(0.12f) }
                ScannerEditorToolButton(
                    "B",
                    selectedSourceLine?.bold == true,
                    FontWeight.Black,
                    17.sp
                ) { toggleBold() }
                ScannerEditorToolButton(
                    "U̲",
                    selectedSourceLine?.underlined == true,
                    FontWeight.Bold,
                    17.sp
                ) { toggleUnderline() }
                ScannerEditorToolButton(fontLabel, false, FontWeight.Bold, 13.sp) { cycleFontFamily() }
                ScannerEditorToolButton("Borrar", false, FontWeight.Bold, 13.sp) { deleteSelectedLine() }
                ScannerEditorToolButton("IMG", false, FontWeight.Black, 13.sp, highlight = true) {
                    if (!saving && sourceLines.any { it.text.isNotBlank() }) {
                        commitLocalState()
                        onSave(currentDocument())
                    }
                }
            }
        }
    }
}

@Composable
private fun ScannerEditorToolButton(
    label: String,
    active: Boolean,
    weight: FontWeight = FontWeight.Bold,
    size: androidx.compose.ui.unit.TextUnit = 17.sp,
    highlight: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (highlight) NeonGreen else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = when {
                highlight -> DeepGreen
                active -> NeonGreen
                else -> Color(0xFFD0D0D0)
            },
            fontWeight = weight,
            fontSize = size
        )
    }
}

private fun scannerStyledText(
    text: String,
    spans: List<ScannerTextStyleSpan>
): android.text.SpannableString {
    val styled = android.text.SpannableString(text)
    spans.forEach { span ->
        val from = span.start.coerceIn(0, text.length)
        val to = span.end.coerceIn(from, text.length)
        if (to > from) {
            styled.setSpan(
                android.text.style.RelativeSizeSpan(span.scale.coerceIn(0.65f, 2.2f)),
                from,
                to,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }
    return styled
}

private fun scannerMedian(values: List<Float>): Float {
    if (values.isEmpty()) return 1f
    val sorted = values.sorted()
    val middle = sorted.size / 2
    return if (sorted.size % 2 == 0) {
        (sorted[middle - 1] + sorted[middle]) / 2f
    } else sorted[middle]
}

/**
 * ML Kit devuelve cajas de línea con alturas que varían por acentos, descendentes y ruido.
 * Usar esa altura directamente como tamaño de fuente hacía que líneas del mismo párrafo
 * aparecieran de tamaños distintos. Aquí estimamos el cuerpo por el ancho real del texto y
 * normalizamos todas las líneas de cuerpo a una misma escala. Solo conservamos una diferencia
 * pequeña cuando la evidencia de un título es clara; nunca se permite el salto enorme del OCR.
 */
private fun scannerNormalizeOcrFontScales(
    lines: List<ScannerRecreateLine>,
    aspectRatio: Float
): List<ScannerRecreateLine> {
    if (lines.isEmpty()) return lines
    val logicalHeight = 1000f
    val logicalWidth = logicalHeight * aspectRatio.coerceIn(0.35f, 2.8f)
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        textSize = 100f
    }

    fun estimateByWidth(line: ScannerRecreateLine): Float {
        val clean = line.text.trim()
        if (clean.isEmpty()) return line.height * logicalHeight * 0.72f
        val measuredAt100 = paint.measureText(clean).coerceAtLeast(1f)
        val boxWidth = (line.width * logicalWidth).coerceAtLeast(2f)
        return (boxWidth * 0.975f / measuredAt100 * 100f).coerceAtLeast(1f)
    }

    val allEstimates = lines.map(::estimateByWidth)
    val firstMedian = scannerMedian(allEstimates)
    val inliers = allEstimates.filter { it in (firstMedian * 0.62f)..(firstMedian * 1.42f) }
    val bodySize = scannerMedian(if (inliers.size >= 3) inliers else allEstimates)
        .coerceIn(logicalHeight * 0.006f, logicalHeight * 0.055f)
    val medianBoxHeight = scannerMedian(lines.map { it.height * logicalHeight })

    return lines.map { line ->
        val estimate = estimateByWidth(line)
        val rawHeight = (line.height * logicalHeight).coerceAtLeast(1f)
        val clearlyLargerHeading =
            line.top < 0.34f &&
            line.text.trim().length <= 72 &&
            estimate > bodySize * 1.42f &&
            rawHeight > medianBoxHeight * 1.22f
        val clearlySmallerText =
            estimate < bodySize * 0.58f &&
            rawHeight < medianBoxHeight * 0.70f

        val targetSize = when {
            clearlyLargerHeading -> minOf(estimate, bodySize * 1.18f)
            clearlySmallerText -> maxOf(estimate, bodySize * 0.82f)
            else -> bodySize
        }

        // scannerFittedTextSize usa 0.78 * altoCaja * fontScale como techo. Al
        // guardar la corrección aquí, una caja OCR anormalmente alta ya no agranda la letra.
        val normalizedScale = (targetSize / (rawHeight * 0.78f)).coerceIn(0.35f, 2.60f)
        line.copy(fontScale = normalizedScale)
    }
}

private suspend fun scannerBuildRecreateDocument(
    context: android.content.Context,
    uri: Uri,
    maxEdge: Int
): ScannerRecreateDocument = withContext(Dispatchers.IO) {
    val source = ToolFileUtils.loadBitmap(context, uri, maxEdge)
    // No recortamos de nuevo por el contenido OCR. autoDocumentCrop busca diferencias
    // contra el borde y, en capturas/documentos blancos, puede terminar recortando al
    // bloque de texto. Eso cambia la escala aparente aunque el usuario no haya usado A+.
    // La recreación conserva desde el inicio el ancho/alto de la imagen elegida; los
    // espacios sobrantes pueden eliminarse después desde el editor, como pidió el usuario.
    val working = source.copy(source.config ?: Bitmap.Config.ARGB_8888, false)
    if (!source.isRecycled) source.recycle()

    try {
        val enhanced = runCatching {
            ToolFileUtils.applyImageAdjustments(
                working,
                DocumentImageFilter.ENHANCE,
                brightness = 3,
                contrast = 1.12f
            )
        }.getOrNull()
        try {
            val recognitionBitmap = enhanced ?: working
            var lines = scannerRecognizeLines(recognitionBitmap)
            if (lines.isEmpty() && recognitionBitmap !== working) {
                lines = scannerRecognizeLines(working)
            }
            lines = filterScannerRecreateLines(lines, working.width, working.height)
            require(lines.isNotEmpty()) { "No se detectó texto para recrear." }

            // La imagen recreada debe conservar la geometría real de la hoja detectada.
            // Antes se recortaba otra vez alrededor del texto OCR y eso agrandaba todo el
            // contenido aunque el usuario no hubiera tocado A+/A-. La hoja ya viene
            // recortada por autoDocumentCrop, así que aquí preservamos el lienzo completo.
            val outputBounds = android.graphics.Rect(0, 0, working.width, working.height)

            val outputWidth = outputBounds.width().coerceAtLeast(1).toFloat()
            val outputHeight = outputBounds.height().coerceAtLeast(1).toFloat()
            val mappedLines = lines.mapIndexedNotNull { index, line ->
                val intersect = android.graphics.Rect(line.bounds)
                if (!intersect.intersect(outputBounds)) return@mapIndexedNotNull null
                val left = ((line.bounds.left - outputBounds.left) / outputWidth).coerceIn(0f, 0.99f)
                val top = ((line.bounds.top - outputBounds.top) / outputHeight).coerceIn(0f, 0.99f)
                val width = (line.bounds.width() / outputWidth).coerceIn(0.02f, 1f - left)
                val height = (line.bounds.height() / outputHeight).coerceIn(0.012f, 0.20f)
                ScannerRecreateLine(
                    id = index,
                    text = line.text,
                    left = left,
                    top = top,
                    width = width,
                    height = height,
                    bold = false
                )
            }
            val visibleLines = scannerNormalizeOcrFontScales(
                mappedLines,
                aspectRatio = outputWidth / outputHeight.coerceAtLeast(1f)
            )
            val body = scannerBuildRecreateBody(visibleLines)
            require(body.isNotBlank()) { "No se pudo reconstruir el contenido." }
            ScannerRecreateDocument(
                aspectRatio = (outputBounds.width().toFloat() / outputBounds.height().coerceAtLeast(1).toFloat()).coerceIn(0.35f, 2.8f),
                body = body,
                lines = visibleLines
            )
        } finally {
            if (enhanced != null && enhanced !== working && !enhanced.isRecycled) enhanced.recycle()
        }
    } finally {
        if (!working.isRecycled) working.recycle()
    }
}

private fun filterScannerRecreateLines(
    lines: List<ScannerRecognizedLine>,
    width: Int,
    height: Int
): List<ScannerRecognizedLine> {
    if (lines.isEmpty()) return emptyList()
    val systemLike = Regex("^(\\d{1,2}:\\d{2}|\\d{1,3}%|[0-9 ]+)$")
    val firstPass = lines.filterNot { line ->
        val normalizedTop = line.bounds.top.toFloat() / height.coerceAtLeast(1)
        normalizedTop < 0.10f && line.text.length <= 12 && systemLike.matches(line.text.trim())
    }
    val normalizedCounts = firstPass.groupingBy { it.text.trim().lowercase() }.eachCount()
    return firstPass.filter { line ->
        val key = line.text.trim().lowercase()
        val duplicate = (normalizedCounts[key] ?: 0) > 1
        val nearTop = line.bounds.top < height * 0.20f
        if (!duplicate || !nearTop) true
        else firstPass.filter { it.text.trim().lowercase() == key }.maxOfOrNull { it.bounds.top } == line.bounds.top
    }.filter { it.bounds.width() > width * 0.01f && it.bounds.height() > height * 0.006f }
}

private suspend fun scannerRecognizeLines(bitmap: Bitmap): List<ScannerRecognizedLine> {
    val result = recognizeScannerDocument(bitmap)
    return result.textBlocks
        .flatMap { block -> block.lines }
        .mapNotNull { line ->
            val bounds = line.boundingBox ?: return@mapNotNull null
            val text = line.text.replace("\n", " ").trim()
            if (text.isBlank()) null else ScannerRecognizedLine(text, android.graphics.Rect(bounds))
        }
        .sortedWith(compareBy<ScannerRecognizedLine> { it.bounds.top }.thenBy { it.bounds.left })
}

private fun scannerBuildRecreateBody(lines: List<ScannerRecreateLine>): String {
    if (lines.isEmpty()) return ""
    val sorted = lines.sortedWith(compareBy<ScannerRecreateLine> { it.top }.thenBy { it.left })
    val medianHeight = sorted.map { it.height }.sorted().let { values -> values[values.size / 2] }
    val builder = StringBuilder()
    var previous: ScannerRecreateLine? = null
    sorted.forEach { line ->
        val clean = line.text.replace(Regex("\\s+"), " ").trim()
        if (clean.isBlank()) return@forEach
        val prev = previous
        if (prev != null) {
            val gap = line.top - (prev.top + prev.height)
            if (gap > medianHeight * 0.9f) builder.append("\n\n") else builder.append("\n")
        }
        builder.append(clean)
        previous = line
    }
    return builder.toString().trim()
}

private fun scannerFittedTextSize(
    text: String,
    boxWidth: Float,
    boxHeight: Float,
    typeface: android.graphics.Typeface,
    scale: Float
): Float {
    val scaledBoxHeight = (boxHeight * scale).coerceAtLeast(1f)
    val maxByHeight = (scaledBoxHeight * 0.78f).coerceAtLeast(1f)
    if (text.isBlank()) return maxByHeight
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        this.typeface = typeface
        textSize = maxByHeight
    }
    val measured = paint.measureText(text).coerceAtLeast(1f)
    val fit = (boxWidth * 0.98f / measured).coerceAtMost(1f)
    return (maxByHeight * fit).coerceAtLeast(scaledBoxHeight * 0.30f)
}

private fun renderScannerRecreateDocumentBitmap(document: ScannerRecreateDocument, maxEdge: Int): Bitmap {
    val ratio = document.aspectRatio.coerceIn(0.35f, 2.8f)
    val safeEdge = maxEdge.coerceIn(800, 3200)
    val width: Int
    val height: Int
    if (ratio >= 1f) {
        width = safeEdge
        height = (safeEdge / ratio).roundToInt().coerceAtLeast(320)
    } else {
        height = safeEdge
        width = (safeEdge * ratio).roundToInt().coerceAtLeast(320)
    }
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(output)
    canvas.drawColor(android.graphics.Color.WHITE)
    val globalScale = 1f

    if (document.lines.isNotEmpty()) {
        val sourceLines = document.lines.sortedWith(compareBy<ScannerRecreateLine> { it.top }.thenBy { it.left })
        sourceLines.forEach { sourceLine ->
            val text = sourceLine.text.trimEnd()
            if (text.isBlank()) return@forEach
            val left = (sourceLine.left * width).coerceIn(0f, width - 2f)
            val top = (sourceLine.top * height).coerceIn(0f, height - 2f)
            val originalBoxWidth = (sourceLine.width * width).coerceAtLeast(20f).coerceAtMost(width - left)
            val layoutBoxWidth = (width - left - width * 0.015f).coerceAtLeast(originalBoxWidth)
            val boxHeight = (sourceLine.height * height).coerceAtLeast(8f)
            val typeface = scannerTypeface(document.fontFamilyIndex, document.bold || sourceLine.bold)
            val textSize = scannerFittedTextSize(
                text = text,
                boxWidth = originalBoxWidth,
                boxHeight = boxHeight,
                typeface = typeface,
                scale = globalScale * sourceLine.fontScale
            )
            val styled = scannerStyledText(text, sourceLine.styleSpans)
            val paint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.SUBPIXEL_TEXT_FLAG).apply {
                color = android.graphics.Color.BLACK
                isLinearText = true
                this.typeface = typeface
                isUnderlineText = document.underlined || sourceLine.underlined
                this.textSize = textSize
            }
            val layout = android.text.StaticLayout.Builder
                .obtain(styled, 0, styled.length, paint, layoutBoxWidth.roundToInt().coerceAtLeast(8))
                .setIncludePad(false)
                .setMaxLines(1)
                .build()
            canvas.save()
            canvas.translate(left, top + ((boxHeight - layout.height) / 2f).coerceAtLeast(0f))
            layout.draw(canvas)
            canvas.restore()
        }
        return output
    }

    val padding = (minOf(width, height) * 0.07f).roundToInt().coerceAtLeast(28)
    val contentWidth = (width - padding * 2).coerceAtLeast(80)
    val paint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.SUBPIXEL_TEXT_FLAG).apply {
        color = android.graphics.Color.BLACK
        textAlign = android.graphics.Paint.Align.LEFT
        isLinearText = true
        typeface = scannerTypeface(document.fontFamilyIndex, document.bold)
        isUnderlineText = document.underlined
        textSize = (document.fontSize * (minOf(width, height) / 900f)).coerceIn(14f, 82f)
    }
    // Se aplican los tramos con formato propio para que la imagen guardada
    // coincida con lo que se vio en el editor.
    val styledBody: CharSequence = if (document.bodyStyleSpans.isEmpty()) {
        document.body
    } else {
        android.text.SpannableString(document.body).apply {
            document.bodyStyleSpans.forEach { span ->
                val from = span.start.coerceIn(0, document.body.length)
                val to = span.end.coerceIn(from, document.body.length)
                if (to <= from) return@forEach
                val flag = android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                if (kotlin.math.abs(span.scale - 1f) > 0.005f) {
                    setSpan(android.text.style.RelativeSizeSpan(span.scale.coerceIn(0.65f, 2.2f)), from, to, flag)
                }
                if (span.bold) setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), from, to, flag)
                if (span.italic) setSpan(android.text.style.StyleSpan(android.graphics.Typeface.ITALIC), from, to, flag)
                if (span.underline) setSpan(android.text.style.UnderlineSpan(), from, to, flag)
            }
        }
    }
    val layout = android.text.StaticLayout.Builder
        .obtain(styledBody, 0, styledBody.length, paint, contentWidth)
        .setAlignment(android.text.Layout.Alignment.ALIGN_NORMAL)
        .setIncludePad(false)
        .setLineSpacing(0f, 1.25f)
        .build()
    canvas.save()
    canvas.translate(padding.toFloat(), padding.toFloat())
    layout.draw(canvas)
    canvas.restore()
    return output
}

private suspend fun recognizeScannerDocument(bitmap: Bitmap): com.google.mlkit.vision.text.Text = suspendCancellableCoroutine { continuation ->
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    val task = recognizer.process(InputImage.fromBitmap(bitmap, 0))
    task.addOnSuccessListener { result ->
        if (continuation.isActive) continuation.resume(result)
    }
    task.addOnFailureListener { error ->
        if (continuation.isActive) continuation.resumeWithException(error)
    }
    task.addOnCanceledListener {
        if (continuation.isActive) continuation.cancel()
    }
    val closed = java.util.concurrent.atomic.AtomicBoolean(false)
    fun closeRecognizer() {
        if (closed.compareAndSet(false, true)) recognizer.close()
    }
    task.addOnCompleteListener { closeRecognizer() }
    continuation.invokeOnCancellation { closeRecognizer() }
}

private suspend fun scannerOcr(
    context: android.content.Context,
    uri: Uri,
    selection: ScannerSelection?
): String = withContext(Dispatchers.IO) {
    val source = ToolFileUtils.loadBitmap(context, uri, SCANNER_OCR_MAX_EDGE)
    if (selection == null) {
        try {
            return@withContext recognizeScannerText(source).trim()
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }

    val left = (selection.left * source.width).roundToInt().coerceIn(0, source.width - 2)
    val top = (selection.top * source.height).roundToInt().coerceIn(0, source.height - 2)
    val right = (selection.right * source.width).roundToInt().coerceIn(left + 2, source.width)
    val bottom = (selection.bottom * source.height).roundToInt().coerceIn(top + 2, source.height)
    val target = Bitmap.createBitmap(source, left, top, right - left, bottom - top)
    try {
        recognizeScannerText(target).trim()
    } finally {
        if (target !== source && !target.isRecycled) target.recycle()
        if (!source.isRecycled) source.recycle()
    }
}

private suspend fun recognizeScannerText(bitmap: Bitmap): String = recognizeScannerDocument(bitmap).text

private const val TEXT_PDF_DRAFT_LIMIT = 15
private const val TEXT_PDF_MAX_CHARS = 300_000
private const val EDITOR_HISTORY_LIMIT = 24

private enum class EditorDocumentFormat(
    val label: String,
    val shortLabel: String,
    val extension: String,
    val mimeType: String
) {
    PDF("PDF", "PDF", "pdf", "application/pdf"),
    WORD("Word", "DOCX", "docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    EXCEL("Excel", "XLSX", "xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    POWERPOINT("PowerPoint", "PPTX", "pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    TEXT("Texto", "TXT", "txt", "text/plain")
}

private enum class EditorTextAlignment { LEFT, CENTER, RIGHT }

private data class EditorTextStyleSpan(
    val start: Int,
    val end: Int,
    val scale: Float = 1f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false
)

private data class TextPdfDraft(
    val id: String,
    val name: String,
    val body: String,
    val formatName: String = EditorDocumentFormat.WORD.name,
    val fontSize: Float = 14f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val styleSpans: List<EditorTextStyleSpan> = emptyList(),
    val alignmentIndex: Int = EditorTextAlignment.LEFT.ordinal,
    val paperIndex: Int = PdfPaperSize.A4.ordinal,
    val orientationIndex: Int = PdfOrientation.PORTRAIT.ordinal,
    val marginIndex: Int = PdfMargin.NORMAL.ordinal,
    val pageNumbers: Boolean = true,
    val columns: Int = 1,
    val sourceUriText: String = "",
    val modifiedAt: Long = System.currentTimeMillis()
) {
    val format: EditorDocumentFormat
        get() = runCatching { EditorDocumentFormat.valueOf(formatName) }.getOrDefault(EditorDocumentFormat.WORD)
}

private data class EditorExpandedTextStyles(
    val scales: FloatArray,
    val bold: BooleanArray,
    val italic: BooleanArray,
    val underline: BooleanArray
)

private data class EditorSelectionFormatState(
    val hasSelection: Boolean = false,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false
)

private data class EditorHistoryState(
    val body: String,
    val styleSpans: List<EditorTextStyleSpan>
)

private fun editorExpandTextStyles(
    textLength: Int,
    spans: List<EditorTextStyleSpan>
): EditorExpandedTextStyles {
    val scales = FloatArray(textLength) { 1f }
    val bold = BooleanArray(textLength)
    val italic = BooleanArray(textLength)
    val underline = BooleanArray(textLength)
    spans.forEach { span ->
        val from = span.start.coerceIn(0, textLength)
        val to = span.end.coerceIn(from, textLength)
        for (index in from until to) {
            scales[index] = span.scale.coerceIn(0.65f, 2.2f)
            bold[index] = span.bold
            italic[index] = span.italic
            underline[index] = span.underline
        }
    }
    return EditorExpandedTextStyles(scales, bold, italic, underline)
}

private fun editorCompressTextStyles(styles: EditorExpandedTextStyles): List<EditorTextStyleSpan> {
    val size = styles.scales.size
    if (size == 0) return emptyList()
    val result = mutableListOf<EditorTextStyleSpan>()
    var start = 0
    fun sameStyle(a: Int, b: Int): Boolean =
        kotlin.math.abs(styles.scales[a] - styles.scales[b]) < 0.005f &&
            styles.bold[a] == styles.bold[b] &&
            styles.italic[a] == styles.italic[b] &&
            styles.underline[a] == styles.underline[b]
    fun append(end: Int) {
        if (end <= start) return
        val scale = styles.scales[start]
        val bold = styles.bold[start]
        val italic = styles.italic[start]
        val underline = styles.underline[start]
        if (kotlin.math.abs(scale - 1f) > 0.005f || bold || italic || underline) {
            result += EditorTextStyleSpan(start, end, scale, bold, italic, underline)
        }
    }
    for (index in 1 until size) {
        if (!sameStyle(start, index)) {
            append(index)
            start = index
        }
    }
    append(size)
    return result
}

private fun editorRemapTextStyleSpans(
    oldText: String,
    newText: String,
    spans: List<EditorTextStyleSpan>
): List<EditorTextStyleSpan> {
    if (newText.isEmpty() || spans.isEmpty()) return emptyList()
    val oldStyles = editorExpandTextStyles(oldText.length, spans)
    var prefix = 0
    while (prefix < oldText.length && prefix < newText.length && oldText[prefix] == newText[prefix]) prefix++
    var suffix = 0
    while (
        suffix < oldText.length - prefix &&
        suffix < newText.length - prefix &&
        oldText[oldText.length - 1 - suffix] == newText[newText.length - 1 - suffix]
    ) suffix++

    val next = EditorExpandedTextStyles(
        FloatArray(newText.length) { 1f },
        BooleanArray(newText.length),
        BooleanArray(newText.length),
        BooleanArray(newText.length)
    )
    fun copyStyle(oldIndex: Int, newIndex: Int) {
        if (oldIndex !in oldStyles.scales.indices || newIndex !in next.scales.indices) return
        next.scales[newIndex] = oldStyles.scales[oldIndex]
        next.bold[newIndex] = oldStyles.bold[oldIndex]
        next.italic[newIndex] = oldStyles.italic[oldIndex]
        next.underline[newIndex] = oldStyles.underline[oldIndex]
    }
    for (index in 0 until prefix.coerceAtMost(newText.length)) copyStyle(index, index)
    for (offset in 0 until suffix) {
        copyStyle(oldText.length - suffix + offset, newText.length - suffix + offset)
    }

    val insertedStart = prefix
    val insertedEnd = newText.length - suffix
    if (insertedEnd > insertedStart) {
        val inheritOldIndex = when {
            prefix > 0 -> prefix - 1
            prefix < oldText.length -> prefix
            else -> -1
        }
        if (inheritOldIndex >= 0) {
            for (index in insertedStart until insertedEnd) copyStyle(inheritOldIndex, index)
        }
    }
    return editorCompressTextStyles(next)
}

private fun editorAdjustSelectionStyle(
    textLength: Int,
    spans: List<EditorTextStyleSpan>,
    selection: TextRange,
    scaleDelta: Float = 0f,
    toggleBold: Boolean = false,
    toggleItalic: Boolean = false,
    toggleUnderline: Boolean = false
): List<EditorTextStyleSpan> {
    val from = minOf(selection.start, selection.end).coerceIn(0, textLength)
    val to = maxOf(selection.start, selection.end).coerceIn(from, textLength)
    if (to <= from) return spans
    val styles = editorExpandTextStyles(textLength, spans)
    val makeBold = if (toggleBold) !(from until to).all { styles.bold[it] } else false
    val makeItalic = if (toggleItalic) !(from until to).all { styles.italic[it] } else false
    val makeUnderline = if (toggleUnderline) !(from until to).all { styles.underline[it] } else false
    for (index in from until to) {
        if (kotlin.math.abs(scaleDelta) > 0.0001f) {
            styles.scales[index] = (styles.scales[index] + scaleDelta).coerceIn(0.65f, 2.2f)
        }
        if (toggleBold) styles.bold[index] = makeBold
        if (toggleItalic) styles.italic[index] = makeItalic
        if (toggleUnderline) styles.underline[index] = makeUnderline
    }
    return editorCompressTextStyles(styles)
}

private fun editorSelectionFormatState(
    textLength: Int,
    spans: List<EditorTextStyleSpan>,
    selection: TextRange
): EditorSelectionFormatState {
    val from = minOf(selection.start, selection.end).coerceIn(0, textLength)
    val to = maxOf(selection.start, selection.end).coerceIn(from, textLength)
    if (to <= from) return EditorSelectionFormatState()
    val styles = editorExpandTextStyles(textLength, spans)
    return EditorSelectionFormatState(
        hasSelection = true,
        bold = (from until to).all { styles.bold[it] },
        italic = (from until to).all { styles.italic[it] },
        underline = (from until to).all { styles.underline[it] }
    )
}

private fun editorTextStyleTransformation(
    spans: List<EditorTextStyleSpan>,
    baseFontSize: androidx.compose.ui.unit.TextUnit
): VisualTransformation = VisualTransformation { source ->
    val builder = AnnotatedString.Builder(source)
    spans.forEach { span ->
        val from = span.start.coerceIn(0, source.length)
        val to = span.end.coerceIn(from, source.length)
        if (to > from) {
            builder.addStyle(
                SpanStyle(
                    fontSize = (baseFontSize.value * span.scale.coerceIn(0.65f, 2.2f)).sp,
                    fontWeight = if (span.bold) FontWeight.Bold else null,
                    fontStyle = if (span.italic) androidx.compose.ui.text.font.FontStyle.Italic else null,
                    textDecoration = if (span.underline) TextDecoration.Underline else null
                ),
                from,
                to
            )
        }
    }
    TransformedText(builder.toAnnotatedString(), OffsetMapping.Identity)
}

private fun textPdfDraftDirectory(context: android.content.Context): File =
    File(context.filesDir, "text_pdf_drafts").apply { mkdirs() }

private fun textPdfDraftFile(context: android.content.Context, id: String): File =
    File(textPdfDraftDirectory(context), "${id.replace(Regex("[^A-Za-z0-9_-]"), "_")}.json")

private fun saveTextPdfDraft(context: android.content.Context, draft: TextPdfDraft) {
    val normalized = draft.copy(
        name = draft.name.trim().ifBlank { "Documento sin título" }.take(80),
        body = draft.body.take(TEXT_PDF_MAX_CHARS),
        formatName = draft.format.name,
        fontSize = draft.fontSize.coerceIn(8f, 32f),
        styleSpans = draft.styleSpans.mapNotNull { span ->
            val from = span.start.coerceIn(0, draft.body.length)
            val to = span.end.coerceIn(from, draft.body.length)
            if (to <= from) null else span.copy(
                start = from,
                end = to,
                scale = span.scale.coerceIn(0.65f, 2.2f)
            )
        },
        alignmentIndex = draft.alignmentIndex.coerceIn(0, EditorTextAlignment.entries.lastIndex),
        paperIndex = draft.paperIndex.coerceIn(0, PdfPaperSize.entries.lastIndex),
        orientationIndex = draft.orientationIndex.coerceIn(0, PdfOrientation.entries.lastIndex),
        marginIndex = draft.marginIndex.coerceIn(0, PdfMargin.entries.lastIndex),
        columns = draft.columns.coerceIn(1, 2),
        sourceUriText = draft.sourceUriText.take(2048),
        modifiedAt = draft.modifiedAt.coerceAtLeast(1L)
    )
    val json = JSONObject().apply {
        put("version", 5)
        put("id", normalized.id)
        put("name", normalized.name)
        put("body", normalized.body)
        put("formatName", normalized.formatName)
        put("fontSize", normalized.fontSize.toDouble())
        put("bold", normalized.bold)
        put("italic", normalized.italic)
        put("underline", normalized.underline)
        put("styleSpans", org.json.JSONArray().apply {
            normalized.styleSpans.forEach { span ->
                put(JSONObject().apply {
                    put("start", span.start)
                    put("end", span.end)
                    put("scale", span.scale.toDouble())
                    put("bold", span.bold)
                    put("italic", span.italic)
                    put("underline", span.underline)
                })
            }
        })
        put("alignmentIndex", normalized.alignmentIndex)
        put("paperIndex", normalized.paperIndex)
        put("orientationIndex", normalized.orientationIndex)
        put("marginIndex", normalized.marginIndex)
        put("pageNumbers", normalized.pageNumbers)
        put("columns", normalized.columns)
        put("sourceUriText", normalized.sourceUriText)
        put("modifiedAt", normalized.modifiedAt)
    }
    val target = textPdfDraftFile(context, normalized.id)
    val temp = File(target.parentFile, "${target.name}.tmp")
    temp.writeText(json.toString())
    if (!temp.renameTo(target)) {
        target.writeText(json.toString())
        temp.delete()
    }
    textPdfDraftDirectory(context).listFiles()
        .orEmpty()
        .filter { it.isFile && it.extension.equals("json", true) }
        .sortedByDescending { file -> readTextPdfDraft(file)?.modifiedAt ?: file.lastModified() }
        .drop(TEXT_PDF_DRAFT_LIMIT)
        .forEach { it.delete() }
}

private fun readTextPdfDraft(file: File): TextPdfDraft? = runCatching {
    val json = JSONObject(file.readText())
    val version = json.optInt("version", 1)
    if (version !in 1..5) return@runCatching null
    val storedFormat = if (version >= 2) json.optString("formatName", EditorDocumentFormat.WORD.name)
        else EditorDocumentFormat.WORD.name
    TextPdfDraft(
        id = json.optString("id").ifBlank { file.nameWithoutExtension },
        name = json.optString("name", "Documento sin título"),
        body = json.optString("body", "").take(TEXT_PDF_MAX_CHARS),
        formatName = runCatching { EditorDocumentFormat.valueOf(storedFormat).name }
            .getOrDefault(EditorDocumentFormat.WORD.name),
        fontSize = json.optDouble("fontSize", 14.0).toFloat().coerceIn(8f, 32f),
        bold = json.optBoolean("bold", false),
        italic = json.optBoolean("italic", false),
        underline = json.optBoolean("underline", false),
        styleSpans = if (version >= 5) {
            val array = json.optJSONArray("styleSpans")
            buildList {
                if (array != null) {
                    for (index in 0 until array.length()) {
                        val item = array.optJSONObject(index) ?: continue
                        val from = item.optInt("start", 0).coerceAtLeast(0)
                        val to = item.optInt("end", from).coerceAtLeast(from)
                        if (to > from) {
                            add(
                                EditorTextStyleSpan(
                                    start = from,
                                    end = to,
                                    scale = item.optDouble("scale", 1.0).toFloat().coerceIn(0.65f, 2.2f),
                                    bold = item.optBoolean("bold", false),
                                    italic = item.optBoolean("italic", false),
                                    underline = item.optBoolean("underline", false)
                                )
                            )
                        }
                    }
                }
            }
        } else emptyList(),
        alignmentIndex = json.optInt("alignmentIndex", 0).coerceIn(0, EditorTextAlignment.entries.lastIndex),
        paperIndex = json.optInt("paperIndex", PdfPaperSize.A4.ordinal).coerceIn(0, PdfPaperSize.entries.lastIndex),
        orientationIndex = json.optInt("orientationIndex", PdfOrientation.PORTRAIT.ordinal).coerceIn(0, PdfOrientation.entries.lastIndex),
        marginIndex = json.optInt("marginIndex", PdfMargin.NORMAL.ordinal).coerceIn(0, PdfMargin.entries.lastIndex),
        pageNumbers = json.optBoolean("pageNumbers", true),
        columns = if (version >= 4) json.optInt("columns", 1).coerceIn(1, 2) else 1,
        sourceUriText = if (version >= 3) json.optString("sourceUriText", "").take(2048) else "",
        modifiedAt = json.optLong("modifiedAt", file.lastModified().coerceAtLeast(1L))
    )
}.getOrNull()

private suspend fun loadTextPdfDrafts(context: android.content.Context): List<TextPdfDraft> = withContext(Dispatchers.IO) {
    textPdfDraftDirectory(context).listFiles()
        .orEmpty()
        .asSequence()
        .filter { it.isFile && it.extension.equals("json", true) }
        .mapNotNull(::readTextPdfDraft)
        .sortedByDescending { it.modifiedAt }
        .take(TEXT_PDF_DRAFT_LIMIT)
        .toList()
}

private fun newTextPdfDraft(
    body: String = "",
    name: String = "",
    format: EditorDocumentFormat = EditorDocumentFormat.WORD,
    sourceUriText: String = ""
): TextPdfDraft = TextPdfDraft(
    id = UUID.randomUUID().toString(),
    name = name.trim().ifBlank {
        "Documento " + android.text.format.DateFormat.format("dd-MM HH-mm", System.currentTimeMillis()).toString()
    }.take(80),
    body = body.take(TEXT_PDF_MAX_CHARS),
    formatName = format.name,
    sourceUriText = sourceUriText.take(2048),
    modifiedAt = System.currentTimeMillis()
)

private fun textPdfOutputName(name: String): String {
    val safe = name.trim()
        .ifBlank { "documento" }
        .replace(Regex("[\\/:*?\"<>|]"), "_")
        .substringBeforeLast('.')
        .take(72)
    return "$safe.pdf"
}

private fun editorFormatFromName(name: String): EditorDocumentFormat = when (name.substringAfterLast('.', "").lowercase()) {
    "pdf" -> EditorDocumentFormat.PDF
    "docx" -> EditorDocumentFormat.WORD
    "xlsx" -> EditorDocumentFormat.EXCEL
    "pptx" -> EditorDocumentFormat.POWERPOINT
    else -> EditorDocumentFormat.TEXT
}

private suspend fun importEditorDocument(context: android.content.Context, uri: Uri): TextPdfDraft = withContext(Dispatchers.IO) {
    val displayName = runCatching { ToolFileUtils.displayName(context, uri) }.getOrDefault("Documento")
    val format = editorFormatFromName(displayName)
    val temp = File.createTempFile("editor_import_", ".${format.extension}", context.cacheDir)
    try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            temp.outputStream().use { output -> input.copyTo(output) }
        } ?: error("No se pudo abrir el archivo")
        val text = when (format) {
            EditorDocumentFormat.PDF -> editorExtractPdfText(context, temp)
            EditorDocumentFormat.WORD -> editorExtractDocxText(temp)
            EditorDocumentFormat.EXCEL -> editorExtractXlsxText(temp)
            EditorDocumentFormat.POWERPOINT -> editorExtractPptxText(temp)
            EditorDocumentFormat.TEXT -> temp.readText()
        }.trim().take(TEXT_PDF_MAX_CHARS)
        newTextPdfDraft(
            body = text,
            name = displayName.substringBeforeLast('.').ifBlank { format.label },
            format = format,
            sourceUriText = uri.toString()
        )
    } finally {
        temp.delete()
    }
}

private fun editorExtractPdfText(context: android.content.Context, file: File): String {
    com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(context.applicationContext)
    return com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { document ->
        require(document.numberOfPages <= 250) { "El PDF es demasiado grande para editarlo como texto." }
        com.tom_roush.pdfbox.text.PDFTextStripper().getText(document)
    }
}

private fun editorExtractDocxText(file: File): String = java.util.zip.ZipFile(file).use { zip ->
    val entry = zip.getEntry("word/document.xml") ?: error("DOCX no válido")
    zip.getInputStream(entry).use { stream ->
        val parser = android.util.Xml.newPullParser().apply { setInput(stream, "UTF-8") }
        val out = StringBuilder()
        while (parser.eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && out.length < TEXT_PDF_MAX_CHARS) {
            when (parser.eventType) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name.substringAfter(':')) {
                    "t" -> out.append(parser.nextText())
                    "tab" -> out.append('\t')
                    "br" -> out.append('\n')
                }
                org.xmlpull.v1.XmlPullParser.END_TAG -> if (parser.name.substringAfter(':') == "p") out.append('\n')
            }
            parser.next()
        }
        out.toString()
    }
}

private fun editorExtractPptxText(file: File): String = java.util.zip.ZipFile(file).use { zip ->
    val slideEntries = zip.entries().asSequence().toList()
        .filter { it.name.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
        .sortedBy { it.name.removePrefix("ppt/slides/slide").removeSuffix(".xml").toIntOrNull() ?: Int.MAX_VALUE }
    require(slideEntries.isNotEmpty()) { "PPTX no válido" }
    val out = StringBuilder()
    slideEntries.forEachIndexed { index, entry ->
        if (out.length >= TEXT_PDF_MAX_CHARS) return@forEachIndexed
        if (index > 0) out.append("\n\n──────── Diapositiva ${index + 1} ────────\n")
        zip.getInputStream(entry).use { stream ->
            val parser = android.util.Xml.newPullParser().apply { setInput(stream, "UTF-8") }
            var wroteText = false
            while (parser.eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && out.length < TEXT_PDF_MAX_CHARS) {
                if (parser.eventType == org.xmlpull.v1.XmlPullParser.START_TAG && parser.name.substringAfter(':') == "t") {
                    if (wroteText && out.isNotEmpty() && out.last() != '\n') out.append(' ')
                    out.append(parser.nextText())
                    wroteText = true
                }
                parser.next()
            }
        }
    }
    out.toString()
}

private fun editorExtractXlsxText(file: File): String = java.util.zip.ZipFile(file).use { zip ->
    val shared = mutableListOf<String>()
    zip.getEntry("xl/sharedStrings.xml")?.let { entry ->
        zip.getInputStream(entry).use { stream ->
            val parser = android.util.Xml.newPullParser().apply { setInput(stream, "UTF-8") }
            var insideSi = false
            var value = StringBuilder()
            while (parser.eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && shared.size < 20_000) {
                when (parser.eventType) {
                    org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name.substringAfter(':')) {
                        "si" -> { insideSi = true; value = StringBuilder() }
                        "t" -> if (insideSi) value.append(parser.nextText())
                    }
                    org.xmlpull.v1.XmlPullParser.END_TAG -> if (parser.name.substringAfter(':') == "si") {
                        shared += value.toString()
                        insideSi = false
                    }
                }
                parser.next()
            }
        }
    }

    val sheetEntry = zip.entries().asSequence().toList()
        .filter { it.name.matches(Regex("xl/worksheets/sheet\\d+\\.xml")) }
        .minByOrNull { it.name.removePrefix("xl/worksheets/sheet").removeSuffix(".xml").toIntOrNull() ?: Int.MAX_VALUE }
        ?: error("XLSX no válido")

    val rows = linkedMapOf<Int, MutableMap<Int, String>>()
    zip.getInputStream(sheetEntry).use { stream ->
        val parser = android.util.Xml.newPullParser().apply { setInput(stream, "UTF-8") }
        var rowIndex = 0
        var cellRef = ""
        var cellType = ""
        var cellValue = ""
        var inlineValue = ""
        while (parser.eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && rows.size < 800) {
            when (parser.eventType) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name.substringAfter(':')) {
                    "row" -> rowIndex = parser.getAttributeValue(null, "r")?.toIntOrNull() ?: (rowIndex + 1)
                    "c" -> {
                        cellRef = parser.getAttributeValue(null, "r").orEmpty()
                        cellType = parser.getAttributeValue(null, "t").orEmpty()
                        cellValue = ""
                        inlineValue = ""
                    }
                    "v" -> cellValue = parser.nextText()
                    "t" -> if (cellType == "inlineStr") inlineValue += parser.nextText()
                }
                org.xmlpull.v1.XmlPullParser.END_TAG -> if (parser.name.substringAfter(':') == "c") {
                    val col = editorExcelColumnIndex(cellRef)
                    if (col in 0..99 && rowIndex in 1..2000) {
                        val resolved = when (cellType) {
                            "s" -> shared.getOrNull(cellValue.toIntOrNull() ?: -1).orEmpty()
                            "inlineStr" -> inlineValue
                            "b" -> if (cellValue == "1") "VERDADERO" else "FALSO"
                            else -> cellValue
                        }
                        rows.getOrPut(rowIndex) { linkedMapOf() }[col] = resolved
                    }
                }
            }
            parser.next()
        }
    }
    if (rows.isEmpty()) {
        ""
    } else {
        val maxCol = rows.values.flatMap { it.keys }.maxOrNull()?.coerceAtMost(99) ?: 0
        rows.entries.joinToString("\n") { (_, cells) ->
            (0..maxCol).joinToString("\t") { col -> cells[col].orEmpty() }.trimEnd('\t')
        }
    }
}

private fun editorExcelColumnIndex(ref: String): Int {
    var result = 0
    var found = false
    for (ch in ref) {
        if (!ch.isLetter()) break
        found = true
        result = result * 26 + (ch.uppercaseChar() - 'A' + 1)
    }
    return if (found) result - 1 else 0
}

private fun editorToggleBullets(text: String): String {
    val lines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
    val nonBlank = lines.filter { it.isNotBlank() }
    val alreadyBulleted = nonBlank.isNotEmpty() && nonBlank.all { it.trimStart().startsWith("• ") }
    return lines.joinToString("\n") { line ->
        if (line.isBlank()) line
        else if (alreadyBulleted) line.replaceFirst(Regex("^\\s*•\\s+"), "")
        else "• ${line.trimStart()}"
    }
}

private fun editorNumberLines(text: String): String {
    val lines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
    var number = 1
    return lines.joinToString("\n") { line ->
        if (line.isBlank()) line else "${number++}. ${line.trimStart().replaceFirst(Regex("^\\d+[.)]\\s+"), "")}"
    }
}

private suspend fun editorCreateStyledPdf(
    context: android.content.Context,
    output: Uri,
    draft: TextPdfDraft
) = withContext(Dispatchers.IO) {
    require(draft.body.isNotBlank()) { "El documento está vacío" }
    val paper = PdfPaperSize.entries.getOrElse(draft.paperIndex) { PdfPaperSize.A4 }
    val orientation = PdfOrientation.entries.getOrElse(draft.orientationIndex) { PdfOrientation.PORTRAIT }
    val marginSetting = PdfMargin.entries.getOrElse(draft.marginIndex) { PdfMargin.NORMAL }
    val baseWidth = paper.widthPoints.takeIf { it > 0 } ?: PdfPaperSize.A4.widthPoints
    val baseHeight = paper.heightPoints.takeIf { it > 0 } ?: PdfPaperSize.A4.heightPoints
    val width = if (orientation == PdfOrientation.LANDSCAPE) baseHeight else baseWidth
    val height = if (orientation == PdfOrientation.LANDSCAPE) baseWidth else baseHeight
    val margin = marginSetting.points.coerceAtLeast(20)
    val pageNumberReserve = if (draft.pageNumbers) 24 else 0
    val usableHeight = (height - margin * 2 - pageNumberReserve).coerceAtLeast(120)
    val columns = draft.columns.coerceIn(1, 2)
    val gutter = if (columns == 2) 24 else 0
    val usableWidth = (width - margin * 2).coerceAtLeast(120)
    val columnWidth = ((usableWidth - gutter * (columns - 1)) / columns).coerceAtLeast(80)

    val styled = android.text.SpannableString(draft.body)
    draft.styleSpans.forEach { span ->
        val from = span.start.coerceIn(0, styled.length)
        val to = span.end.coerceIn(from, styled.length)
        if (to <= from) return@forEach
        if (kotlin.math.abs(span.scale - 1f) > 0.005f) {
            styled.setSpan(
                android.text.style.RelativeSizeSpan(span.scale.coerceIn(0.65f, 2.2f)),
                from,
                to,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        val style = when {
            span.bold && span.italic -> android.graphics.Typeface.BOLD_ITALIC
            span.bold -> android.graphics.Typeface.BOLD
            span.italic -> android.graphics.Typeface.ITALIC
            else -> android.graphics.Typeface.NORMAL
        }
        if (style != android.graphics.Typeface.NORMAL) {
            styled.setSpan(
                android.text.style.StyleSpan(style),
                from,
                to,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        if (span.underline) {
            styled.setSpan(
                android.text.style.UnderlineSpan(),
                from,
                to,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }

    val baseTypefaceStyle = when {
        draft.bold && draft.italic -> android.graphics.Typeface.BOLD_ITALIC
        draft.bold -> android.graphics.Typeface.BOLD
        draft.italic -> android.graphics.Typeface.ITALIC
        else -> android.graphics.Typeface.NORMAL
    }
    val paint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.SUBPIXEL_TEXT_FLAG).apply {
        color = android.graphics.Color.BLACK
        textSize = draft.fontSize.coerceIn(8f, 32f)
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, baseTypefaceStyle)
        isUnderlineText = draft.underline
    }
    val alignment = when (draft.alignmentIndex.coerceIn(0, 2)) {
        1 -> android.text.Layout.Alignment.ALIGN_CENTER
        2 -> android.text.Layout.Alignment.ALIGN_OPPOSITE
        else -> android.text.Layout.Alignment.ALIGN_NORMAL
    }
    val layout = android.text.StaticLayout.Builder
        .obtain(styled, 0, styled.length, paint, columnWidth)
        .setAlignment(alignment)
        .setIncludePad(false)
        .setLineSpacing(0f, 1.32f)
        .build()

    val pdf = android.graphics.pdf.PdfDocument()
    try {
        var lineIndex = 0
        var pageNumber = 1
        while (lineIndex < layout.lineCount || (layout.lineCount == 0 && pageNumber == 1)) {
            val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(width, height, pageNumber).create()
            val page = pdf.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawColor(android.graphics.Color.WHITE)

            for (column in 0 until columns) {
                if (lineIndex >= layout.lineCount) break
                val startLine = lineIndex
                val startTop = layout.getLineTop(startLine)
                var endLine = startLine
                while (endLine < layout.lineCount) {
                    val segmentHeight = layout.getLineBottom(endLine) - startTop
                    if (segmentHeight > usableHeight && endLine > startLine) break
                    endLine++
                    if (segmentHeight > usableHeight) break
                }
                if (endLine <= startLine) endLine = (startLine + 1).coerceAtMost(layout.lineCount)
                val columnLeft = margin + column * (columnWidth + gutter)
                canvas.save()
                canvas.clipRect(
                    columnLeft.toFloat(),
                    margin.toFloat(),
                    (columnLeft + columnWidth).toFloat(),
                    (margin + usableHeight).toFloat()
                )
                canvas.translate(columnLeft.toFloat(), (margin - startTop).toFloat())
                layout.draw(canvas)
                canvas.restore()
                lineIndex = endLine
            }

            if (draft.pageNumbers) {
                val numberPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.DKGRAY
                    textSize = 9f
                    textAlign = android.graphics.Paint.Align.CENTER
                }
                canvas.drawText(pageNumber.toString(), width / 2f, (height - 10).toFloat(), numberPaint)
            }
            pdf.finishPage(page)
            pageNumber++
            require(pageNumber <= 500) { "El documento supera el límite de páginas" }
            if (layout.lineCount == 0) break
        }
        context.contentResolver.openOutputStream(output, "w")?.use { stream ->
            pdf.writeTo(stream)
        } ?: error("No se pudo crear el PDF")
    } finally {
        pdf.close()
    }
}

@Composable
fun TextToPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var drafts by remember { mutableStateOf<List<TextPdfDraft>>(emptyList()) }
    var activeDraft by remember { mutableStateOf<TextPdfDraft?>(null) }
    var loadingDrafts by remember { mutableStateOf(true) }
    var importing by remember { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf<TextPdfDraft?>(null) }

    suspend fun refreshDrafts() {
        loadingDrafts = true
        drafts = loadTextPdfDrafts(context)
        loadingDrafts = false
    }

    LaunchedEffect(Unit) { refreshDrafts() }

    val openDocument = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        importing = true
        scope.launch {
            runCatching { importEditorDocument(context, uri) }
                .onSuccess { imported ->
                    withContext(Dispatchers.IO) { saveTextPdfDraft(context, imported) }
                    activeDraft = imported
                    refreshDrafts()
                }
                .onFailure { error -> onMessage(error.message ?: "No se pudo abrir el documento") }
            importing = false
        }
    }

    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val draft = pendingExport
        pendingExport = null
        if (output == null || draft == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                if (draft.styleSpans.isNotEmpty()) {
                    editorCreateStyledPdf(context, output, draft)
                } else {
                    AdvancedFileUtils.createTextPdf(
                        context = context,
                        output = output,
                        text = draft.body,
                        options = AdvancedFileUtils.TextPdfOptions(
                            title = "",
                            author = "",
                            fontSize = draft.fontSize,
                            lineSpacing = 1.32f,
                            paperSize = PdfPaperSize.entries.getOrElse(draft.paperIndex) { PdfPaperSize.A4 },
                            orientation = PdfOrientation.entries.getOrElse(draft.orientationIndex) { PdfOrientation.PORTRAIT },
                            margin = PdfMargin.entries.getOrElse(draft.marginIndex) { PdfMargin.NORMAL },
                            pageNumbers = draft.pageNumbers,
                            header = "",
                            bold = draft.bold,
                            italic = draft.italic,
                            underline = draft.underline,
                            alignment = draft.alignmentIndex,
                            columns = draft.columns
                        )
                    )
                }
            }.onSuccess { reward ->
                onMessage(successMessage("Documento PDF guardado", reward))
            }.onFailure { error ->
                onMessage(error.message ?: "No se pudo guardar el PDF")
            }
            processing = false
        }
    }

    fun createDraft(format: EditorDocumentFormat) {
        val created = newTextPdfDraft(format = format)
        activeDraft = created
        scope.launch { withContext(Dispatchers.IO) { saveTextPdfDraft(context, created) } }
    }

    fun closeEditor(draft: TextPdfDraft) {
        val saved = draft.copy(modifiedAt = System.currentTimeMillis())
        activeDraft = null
        scope.launch {
            withContext(Dispatchers.IO) { saveTextPdfDraft(context, saved) }
            refreshDrafts()
        }
    }

    BackHandler(enabled = activeDraft != null) {
        activeDraft?.let(::closeEditor)
    }

    val draft = activeDraft
    if (draft == null) {
        DocumentEditorHome(
            drafts = drafts,
            loading = loadingDrafts,
            importing = importing,
            onBack = onBack,
            onNew = ::createDraft,
            onOpenFile = {
                openDocument.launch(
                    arrayOf(
                        "application/pdf",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        "text/plain"
                    )
                )
            },
            onOpenDraft = { activeDraft = it },
            onRefresh = { scope.launch { refreshDrafts() } }
        )
        return
    }

    LaunchedEffect(draft) {
        delay(500)
        withContext(Dispatchers.IO) { saveTextPdfDraft(context, draft) }
    }

    var undoStack by remember(draft.id) {
        mutableStateOf(listOf(EditorHistoryState(draft.body, draft.styleSpans)))
    }
    var redoStack by remember(draft.id) { mutableStateOf<List<EditorHistoryState>>(emptyList()) }
    var toolbarPanel by remember(draft.id) { mutableIntStateOf(0) }

    LaunchedEffect(draft.body, draft.styleSpans) {
        delay(500)
        val currentDraft = activeDraft?.takeIf { it.id == draft.id } ?: return@LaunchedEffect
        val current = EditorHistoryState(currentDraft.body, currentDraft.styleSpans)
        if (undoStack.lastOrNull() != current) {
            undoStack = (undoStack + current).takeLast(EDITOR_HISTORY_LIMIT)
            redoStack = emptyList()
        }
    }

    fun undo() {
        if (undoStack.size <= 1) return
        val current = undoStack.last()
        val target = undoStack[undoStack.lastIndex - 1]
        undoStack = undoStack.dropLast(1)
        redoStack = (redoStack + current).takeLast(EDITOR_HISTORY_LIMIT)
        activeDraft = draft.copy(
            body = target.body,
            styleSpans = target.styleSpans,
            modifiedAt = System.currentTimeMillis()
        )
    }

    fun redo() {
        val target = redoStack.lastOrNull() ?: return
        redoStack = redoStack.dropLast(1)
        undoStack = (undoStack + target).takeLast(EDITOR_HISTORY_LIMIT)
        activeDraft = draft.copy(
            body = target.body,
            styleSpans = target.styleSpans,
            modifiedAt = System.currentTimeMillis()
        )
    }

    fun persistNow(message: Boolean = true) {
        val ready = draft.copy(modifiedAt = System.currentTimeMillis())
        activeDraft = ready
        scope.launch {
            withContext(Dispatchers.IO) { saveTextPdfDraft(context, ready) }
            if (message) onMessage("Documento guardado en Gana Geo")
        }
    }

    fun exportPdf() {
        if (draft.body.isBlank()) {
            onMessage("El documento está vacío")
            return
        }
        val ready = draft.copy(modifiedAt = System.currentTimeMillis())
        activeDraft = ready
        scope.launch { withContext(Dispatchers.IO) { saveTextPdfDraft(context, ready) } }
        launchPaidExport(viewModel, tool, onMessage) {
            pendingExport = ready
            savePdf.launch(textPdfOutputName(ready.name))
        }
    }

    DocumentEditorWorkspace(
        draft = draft,
        processing = processing,
        toolbarPanel = toolbarPanel,
        canUndo = undoStack.size > 1,
        canRedo = redoStack.isNotEmpty(),
        onToolbarPanelChange = { toolbarPanel = it },
        onDraftChange = { activeDraft = it.copy(modifiedAt = System.currentTimeMillis()) },
        onDone = { closeEditor(draft) },
        onSave = { persistNow() },
        onUndo = ::undo,
        onRedo = ::redo,
        onExportPdf = ::exportPdf,
        onMessage = onMessage
    )
}

@Composable
private fun DocumentEditorHome(
    drafts: List<TextPdfDraft>,
    loading: Boolean,
    importing: Boolean,
    onBack: () -> Unit,
    onNew: (EditorDocumentFormat) -> Unit,
    onOpenFile: () -> Unit,
    onOpenDraft: (TextPdfDraft) -> Unit,
    onRefresh: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Color(0xFF101010)).statusBarsPadding().navigationBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(60.dp).background(Color(0xFF171717)).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.Close, "Cerrar", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text("Editor de documentos", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                Text("Offline · PDF · Word · Excel · PowerPoint", color = Color(0xFFB8B8B8), style = MaterialTheme.typography.bodySmall)
            }
            Box(
                modifier = Modifier.background(Color(0xFF21372B), RoundedCornerShape(10.dp)).padding(horizontal = 9.dp, vertical = 5.dp)
            ) {
                Text("OFFLINE", color = NeonGreen, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
            }
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Button(
                onClick = onOpenFile,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                enabled = !importing,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
                Icon(Icons.Rounded.FolderOpen, null)
                Text(if (importing) "  Abriendo documento…" else "  Abrir PDF, Word, Excel o PowerPoint", fontWeight = FontWeight.Black)
            }
            if (importing) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

            Text("Nuevo documento", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EditorHomeFormatButton(EditorDocumentFormat.PDF, Color(0xFFE94F58), Modifier.weight(1f)) { onNew(EditorDocumentFormat.PDF) }
                EditorHomeFormatButton(EditorDocumentFormat.WORD, Color(0xFF3976D3), Modifier.weight(1f)) { onNew(EditorDocumentFormat.WORD) }
                EditorHomeFormatButton(EditorDocumentFormat.EXCEL, Color(0xFF2E8B57), Modifier.weight(1f)) { onNew(EditorDocumentFormat.EXCEL) }
                EditorHomeFormatButton(EditorDocumentFormat.POWERPOINT, Color(0xFFE36B39), Modifier.weight(1f)) { onNew(EditorDocumentFormat.POWERPOINT) }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Documentos recientes", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, "Actualizar", tint = Color.White) }
            }

            when {
                loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NeonGreen)
                }
                drafts.isEmpty() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("Todavía no hay documentos", color = Color(0xFFB8B8B8))
                }
                else -> LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    lazyListItems(drafts, key = { it.id }) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onOpenDraft(item) },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1D1D1D)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(13.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                EditorFormatBadge(item.format, 46.dp)
                                Column(Modifier.weight(1f)) {
                                    Text(item.name, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text(
                                        "${item.format.label} · ${item.body.length} caracteres · ${android.text.format.DateUtils.getRelativeTimeSpanString(item.modifiedAt)}",
                                        color = Color(0xFFAFAFAF),
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorHomeFormatButton(
    format: EditorDocumentFormat,
    accent: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(78.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF1E1E1E))
            .clickable(onClick = onClick)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                modifier = Modifier.background(accent, RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text(format.shortLabel, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
            }
            Text(format.label, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}

@Composable
private fun EditorFormatBadge(format: EditorDocumentFormat, size: androidx.compose.ui.unit.Dp) {
    val accent = when (format) {
        EditorDocumentFormat.PDF -> Color(0xFFE94F58)
        EditorDocumentFormat.WORD -> Color(0xFF3976D3)
        EditorDocumentFormat.EXCEL -> Color(0xFF2E8B57)
        EditorDocumentFormat.POWERPOINT -> Color(0xFFE36B39)
        EditorDocumentFormat.TEXT -> Color(0xFF6F7780)
    }
    Box(
        modifier = Modifier.size(size).background(accent, RoundedCornerShape(11.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(format.shortLabel, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun DocumentEditorWorkspace(
    draft: TextPdfDraft,
    processing: Boolean,
    toolbarPanel: Int,
    canUndo: Boolean,
    canRedo: Boolean,
    onToolbarPanelChange: (Int) -> Unit,
    onDraftChange: (TextPdfDraft) -> Unit,
    onDone: () -> Unit,
    onSave: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onExportPdf: () -> Unit,
    onMessage: (String) -> Unit
) {
    val paper = PdfPaperSize.entries.getOrElse(draft.paperIndex) { PdfPaperSize.A4 }
    val orientation = PdfOrientation.entries.getOrElse(draft.orientationIndex) { PdfOrientation.PORTRAIT }
    val margin = PdfMargin.entries.getOrElse(draft.marginIndex) { PdfMargin.NORMAL }
    val alignment = EditorTextAlignment.entries.getOrElse(draft.alignmentIndex) { EditorTextAlignment.LEFT }
    var zoom by remember(draft.id) { mutableFloatStateOf(1f) }
    var panX by remember(draft.id) { mutableFloatStateOf(0f) }
    var panY by remember(draft.id) { mutableFloatStateOf(0f) }
    var editorValue by remember(draft.id) { mutableStateOf(TextFieldValue(draft.body)) }

    LaunchedEffect(draft.body) {
        if (editorValue.text != draft.body) {
            val start = editorValue.selection.start.coerceIn(0, draft.body.length)
            val end = editorValue.selection.end.coerceIn(0, draft.body.length)
            editorValue = TextFieldValue(draft.body, selection = TextRange(start, end))
        }
    }

    fun updateEditorValue(next: TextFieldValue) {
        val limitedText = next.text.take(TEXT_PDF_MAX_CHARS)
        val limited = if (limitedText == next.text) next else TextFieldValue(
            text = limitedText,
            selection = TextRange(
                next.selection.start.coerceIn(0, limitedText.length),
                next.selection.end.coerceIn(0, limitedText.length)
            )
        )
        editorValue = limited
        if (limited.text != draft.body) {
            onDraftChange(
                draft.copy(
                    body = limited.text,
                    styleSpans = editorRemapTextStyleSpans(draft.body, limited.text, draft.styleSpans)
                )
            )
        }
    }

    val selectionFormat = editorSelectionFormatState(draft.body.length, draft.styleSpans, editorValue.selection)

    fun adjustSelectionScale(delta: Float) {
        if (!selectionFormat.hasSelection) return
        onDraftChange(
            draft.copy(
                styleSpans = editorAdjustSelectionStyle(
                    textLength = draft.body.length,
                    spans = draft.styleSpans,
                    selection = editorValue.selection,
                    scaleDelta = delta
                )
            )
        )
    }

    fun toggleSelectionBold() {
        if (!selectionFormat.hasSelection) return
        onDraftChange(draft.copy(styleSpans = editorAdjustSelectionStyle(draft.body.length, draft.styleSpans, editorValue.selection, toggleBold = true)))
    }

    fun toggleSelectionItalic() {
        if (!selectionFormat.hasSelection) return
        onDraftChange(draft.copy(styleSpans = editorAdjustSelectionStyle(draft.body.length, draft.styleSpans, editorValue.selection, toggleItalic = true)))
    }

    fun toggleSelectionUnderline() {
        if (!selectionFormat.hasSelection) return
        onDraftChange(draft.copy(styleSpans = editorAdjustSelectionStyle(draft.body.length, draft.styleSpans, editorValue.selection, toggleUnderline = true)))
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF0E0E0E)).statusBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(58.dp).background(Color(0xFF171717)).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.clickable(onClick = onDone).padding(horizontal = 8.dp, vertical = 10.dp)
            ) {
                Text("Listo", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
            IconButton(onClick = onSave) { Icon(Icons.Rounded.Save, "Guardar", tint = Color(0xFFDADADA)) }
            IconButton(onClick = onUndo, enabled = canUndo) {
                Icon(Icons.Rounded.Undo, "Deshacer", tint = if (canUndo) Color(0xFFDADADA) else Color(0xFF555555))
            }
            IconButton(onClick = onRedo, enabled = canRedo) {
                Icon(Icons.Rounded.Redo, "Rehacer", tint = if (canRedo) Color(0xFFDADADA) else Color(0xFF555555))
            }
            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier.background(Color(0xFF2B2B2B), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text(draft.format.shortLabel, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = onDone) { Icon(Icons.Rounded.Close, "Cerrar", tint = Color(0xFFDADADA)) }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF101010))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 72.dp)
            ) {
                if (draft.sourceUriText.isNotBlank() && draft.format != EditorDocumentFormat.TEXT) {
                    DocumentEditorViewerSurface(
                        formatName = draft.format.name,
                        sourceUriText = draft.sourceUriText,
                        modifier = Modifier.fillMaxSize(),
                        onMessage = onMessage
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 8.dp)
                            .background(Color(0xB31B1B1B), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "Vista original · edita desde Aa",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxSize()
                            .clipToBounds()
                            .pointerInput(draft.id) {
                                awaitEachGesture {
                                    do {
                                        val event = awaitPointerEvent(PointerEventPass.Initial)
                                        val pressed = event.changes.filter { it.pressed }
                                        if (pressed.size >= 2) {
                                            val viewportW = size.width.toFloat().coerceAtLeast(1f)
                                            val viewportH = size.height.toFloat().coerceAtLeast(1f)
                                            val centroidX = pressed.sumOf { it.position.x.toDouble() }.toFloat() / pressed.size
                                            val centroidY = pressed.sumOf { it.position.y.toDouble() }.toFloat() / pressed.size
                                            val oldZoom = zoom.coerceIn(1f, 4f)
                                            val requestedZoom = (oldZoom * event.calculateZoom()).coerceIn(1f, 4f)
                                            val actualFactor = requestedZoom / oldZoom.coerceAtLeast(0.001f)
                                            val drag = event.calculatePan()
                                            val relativeX = centroidX - viewportW / 2f
                                            val relativeY = centroidY - viewportH / 2f
                                            val nextX = panX * actualFactor + relativeX * (1f - actualFactor) + drag.x
                                            val nextY = panY * actualFactor + relativeY * (1f - actualFactor) + drag.y
                                            val extraX = (viewportW * (requestedZoom - 1f) / 2f).coerceAtLeast(0f)
                                            val extraY = (viewportH * (requestedZoom - 1f) / 2f).coerceAtLeast(0f)
                                            zoom = requestedZoom
                                            panX = if (extraX <= 0.5f) 0f else nextX.coerceIn(-extraX, extraX)
                                            panY = if (extraY <= 0.5f) 0f else nextY.coerceIn(-extraY, extraY)
                                            if (requestedZoom <= 1.001f) {
                                                panX = 0f
                                                panY = 0f
                                            }
                                            event.changes.forEach { it.consume() }
                                        }
                                    } while (event.changes.any { it.pressed })
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        val baseRatio = when (draft.format) {
                            EditorDocumentFormat.POWERPOINT -> 16f / 9f
                            EditorDocumentFormat.EXCEL -> 1.18f
                            else -> {
                                val pw = paper.widthPoints.takeIf { it > 0 } ?: PdfPaperSize.A4.widthPoints
                                val ph = paper.heightPoints.takeIf { it > 0 } ?: PdfPaperSize.A4.heightPoints
                                if (orientation == PdfOrientation.LANDSCAPE) ph.toFloat() / pw.toFloat() else pw.toFloat() / ph.toFloat()
                            }
                        }.coerceIn(0.5f, 2.0f)
                        val availableRatio = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
                        val pageWidth = if (baseRatio >= availableRatio) maxWidth.value * 0.96f else maxHeight.value * 0.96f * baseRatio
                        val pageHeight = pageWidth / baseRatio
                        val pagePadding = when (margin) {
                            PdfMargin.NONE -> 8.dp
                            PdfMargin.SMALL -> 12.dp
                            PdfMargin.NORMAL -> 20.dp
                            PdfMargin.LARGE -> 30.dp
                        }

                        Box(
                            modifier = Modifier
                                .width(pageWidth.dp)
                                .height(pageHeight.dp)
                                .graphicsLayer(
                                    scaleX = zoom,
                                    scaleY = zoom,
                                    translationX = panX,
                                    translationY = panY,
                                    clip = true
                                )
                                .background(Color.White)
                        ) {
                            if (draft.format == EditorDocumentFormat.EXCEL) {
                                Canvas(Modifier.fillMaxSize()) {
                                    val gridColor = androidx.compose.ui.graphics.Color(0xFFE0E5E2)
                                    var x = 0f
                                    while (x < size.width) {
                                        drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                                        x += 72f
                                    }
                                    var y = 0f
                                    while (y < size.height) {
                                        drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                                        y += 34f
                                    }
                                }
                            }

                            BasicTextField(
                                value = editorValue,
                                onValueChange = ::updateEditorValue,
                                visualTransformation = editorTextStyleTransformation(draft.styleSpans, draft.fontSize.sp),
                                modifier = Modifier.fillMaxSize().padding(pagePadding),
                                textStyle = MaterialTheme.typography.bodyLarge.copy(
                                    color = Color.Black,
                                    fontSize = draft.fontSize.sp,
                                    lineHeight = androidx.compose.ui.unit.TextUnit.Unspecified,
                                    fontFamily = if (draft.format == EditorDocumentFormat.EXCEL) FontFamily.Monospace else FontFamily.Default,
                                    fontWeight = if (draft.bold) FontWeight.Bold else FontWeight.Normal,
                                    fontStyle = if (draft.italic) androidx.compose.ui.text.font.FontStyle.Italic else androidx.compose.ui.text.font.FontStyle.Normal,
                                    textDecoration = if (draft.underline) TextDecoration.Underline else TextDecoration.None,
                                    textAlign = when (alignment) {
                                        EditorTextAlignment.LEFT -> TextAlign.Start
                                        EditorTextAlignment.CENTER -> TextAlign.Center
                                        EditorTextAlignment.RIGHT -> TextAlign.End
                                    }
                                ),
                                decorationBox = { inner ->
                                    if (draft.body.isBlank()) {
                                        Text(
                                            when (draft.format) {
                                                EditorDocumentFormat.PDF -> "Escribe o pega texto para crear una versión editable del PDF…"
                                                EditorDocumentFormat.WORD -> "Escribe tu documento…"
                                                EditorDocumentFormat.EXCEL -> "Escribe valores separados por tabulaciones y filas…"
                                                EditorDocumentFormat.POWERPOINT -> "Escribe el contenido de la diapositiva…"
                                                EditorDocumentFormat.TEXT -> "Escribe aquí…"
                                            },
                                            color = Color(0xFF9A9A9A),
                                            fontSize = draft.fontSize.sp
                                        )
                                    }
                                    inner()
                                }
                            )

                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(8.dp)
                                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
                                    .clickable {
                                        zoom = 1f
                                        panX = 0f
                                        panY = 0f
                                    }
                                    .padding(horizontal = 7.dp, vertical = 4.dp)
                            ) {
                                Text("${(zoom * 100).roundToInt()}%", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            if (toolbarPanel != 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 64.dp)
                        .navigationBarsPadding()
                        .fillMaxWidth()
                ) {
                    when (toolbarPanel) {
                        1 -> EditorTextFormatPanel(
                            draft = draft,
                            editorValue = editorValue,
                            selectionFormat = selectionFormat,
                            onEditorValueChange = ::updateEditorValue,
                            onDecreaseSelection = { adjustSelectionScale(-0.12f) },
                            onIncreaseSelection = { adjustSelectionScale(0.12f) },
                            onToggleBold = ::toggleSelectionBold,
                            onToggleItalic = ::toggleSelectionItalic,
                            onToggleUnderline = ::toggleSelectionUnderline,
                            onDraftChange = onDraftChange
                        )
                        2 -> EditorLayoutPanel(draft, paper, orientation, margin, onDraftChange, onExportPdf, processing)
                        3 -> EditorExportPanel(processing = processing, onExportPdf = onExportPdf)
                    }
                }
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color(0xFF242424))
                    .navigationBarsPadding()
                    .height(64.dp)
                    .padding(horizontal = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                EditorToolbarButton("Aa", toolbarPanel == 1) { onToolbarPanelChange(if (toolbarPanel == 1) 0 else 1) }
                EditorToolbarButton("B", selectionFormat.bold, FontWeight.Black) { toggleSelectionBold() }
                EditorToolbarButton("I", selectionFormat.italic) { toggleSelectionItalic() }
                EditorToolbarButton("U̲", selectionFormat.underline, FontWeight.Bold) { toggleSelectionUnderline() }
                EditorToolbarButton(
                    when (alignment) {
                        EditorTextAlignment.LEFT -> "≡←"
                        EditorTextAlignment.CENTER -> "≡↔"
                        EditorTextAlignment.RIGHT -> "→≡"
                    },
                    false
                ) {
                    val next = EditorTextAlignment.entries[(alignment.ordinal + 1) % EditorTextAlignment.entries.size]
                    onDraftChange(draft.copy(alignmentIndex = next.ordinal))
                }
                EditorToolbarButton("+", toolbarPanel == 2, FontWeight.Normal, 26.sp) { onToolbarPanelChange(if (toolbarPanel == 2) 0 else 2) }
                EditorToolbarButton("PDF", toolbarPanel == 3, FontWeight.Black) { onToolbarPanelChange(if (toolbarPanel == 3) 0 else 3) }
            }

            if (processing) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun EditorToolbarButton(
    label: String,
    active: Boolean,
    weight: FontWeight = FontWeight.Normal,
    size: androidx.compose.ui.unit.TextUnit = 19.sp,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) Color(0xFF3C5A48) else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (active) NeonGreen else Color(0xFFD0D0D0), fontWeight = weight, fontSize = size)
    }
}

@Composable
private fun EditorTextFormatPanel(
    draft: TextPdfDraft,
    editorValue: TextFieldValue,
    selectionFormat: EditorSelectionFormatState,
    onEditorValueChange: (TextFieldValue) -> Unit,
    onDecreaseSelection: () -> Unit,
    onIncreaseSelection: () -> Unit,
    onToggleBold: () -> Unit,
    onToggleItalic: () -> Unit,
    onToggleUnderline: () -> Unit,
    onDraftChange: (TextPdfDraft) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF303030))
            .imePadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            EditorPanelChip("A−") { onDecreaseSelection() }
            Text(
                if (selectionFormat.hasSelection) "Solo selección" else "Selecciona texto",
                color = if (selectionFormat.hasSelection) Color.White else Color(0xFFAAAAAA),
                fontWeight = FontWeight.Bold
            )
            EditorPanelChip("A+") { onIncreaseSelection() }
            EditorPanelChip(if (selectionFormat.bold) "Negrita ✓" else "Negrita") { onToggleBold() }
            EditorPanelChip(if (selectionFormat.italic) "Cursiva ✓" else "Cursiva") { onToggleItalic() }
            EditorPanelChip(if (selectionFormat.underline) "Subrayado ✓" else "Subrayado") { onToggleUnderline() }
            EditorPanelChip("• Viñetas") { onEditorValueChange(TextFieldValue(editorToggleBullets(draft.body))) }
            EditorPanelChip("1. Numeración") { onEditorValueChange(TextFieldValue(editorNumberLines(draft.body))) }
            EditorPanelChip(if (draft.columns == 2) "2 columnas ✓" else "2 columnas") {
                onDraftChange(draft.copy(columns = if (draft.columns == 2) 1 else 2))
            }
        }
        if (draft.sourceUriText.isNotBlank()) {
            OutlinedTextField(
                value = editorValue,
                onValueChange = onEditorValueChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 110.dp, max = 190.dp)
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                label = { Text("Texto editable del documento · selecciona para dar formato") },
                visualTransformation = editorTextStyleTransformation(draft.styleSpans, draft.fontSize.sp),
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = draft.fontSize.sp,
                    lineHeight = androidx.compose.ui.unit.TextUnit.Unspecified,
                    fontWeight = if (draft.bold) FontWeight.Bold else FontWeight.Normal,
                    fontStyle = if (draft.italic) androidx.compose.ui.text.font.FontStyle.Italic else androidx.compose.ui.text.font.FontStyle.Normal,
                    textDecoration = if (draft.underline) TextDecoration.Underline else TextDecoration.None
                )
            )
        }
    }
}


@Composable
private fun EditorLayoutPanel(
    draft: TextPdfDraft,
    paper: PdfPaperSize,
    orientation: PdfOrientation,
    margin: PdfMargin,
    onDraftChange: (TextPdfDraft) -> Unit,
    onExportPdf: () -> Unit,
    processing: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF303030))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        EditorPanelChip(paper.label.substringBefore(" ·")) {
            val allowed = listOf(PdfPaperSize.A4, PdfPaperSize.LETTER, PdfPaperSize.A3, PdfPaperSize.A5)
            val current = allowed.indexOf(paper).takeIf { it >= 0 } ?: 0
            onDraftChange(draft.copy(paperIndex = allowed[(current + 1) % allowed.size].ordinal))
        }
        EditorPanelChip(if (orientation == PdfOrientation.LANDSCAPE) "Horizontal" else "Vertical") {
            val next = if (orientation == PdfOrientation.LANDSCAPE) PdfOrientation.PORTRAIT else PdfOrientation.LANDSCAPE
            onDraftChange(draft.copy(orientationIndex = next.ordinal))
        }
        EditorPanelChip("Márgenes: ${margin.label}") {
            val next = PdfMargin.entries[(margin.ordinal + 1) % PdfMargin.entries.size]
            onDraftChange(draft.copy(marginIndex = next.ordinal))
        }
        EditorPanelChip(if (draft.pageNumbers) "Páginas ✓" else "Páginas") {
            onDraftChange(draft.copy(pageNumbers = !draft.pageNumbers))
        }
        EditorPanelChip(if (processing) "Exportando…" else "Exportar PDF") { if (!processing) onExportPdf() }
    }
}

@Composable
private fun EditorExportPanel(
    processing: Boolean,
    onExportPdf: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF303030))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text("Exportar PDF", color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                "Guarda una copia PDF con los ajustes actuales.",
                color = Color(0xFFBDBDBD),
                style = MaterialTheme.typography.bodySmall
            )
        }
        Button(
            onClick = onExportPdf,
            enabled = !processing,
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.Save, contentDescription = null)
            Text(if (processing) "  Guardando…" else "  Guardar PDF", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EditorPanelChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .height(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF454545))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
    }
}


@Composable
fun PdfWatermarkSecurityScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var modeIndex by rememberSaveable { mutableIntStateOf(0) }
    var watermark by rememberSaveable { mutableStateOf("GANA GEO") }
    var positionIndex by rememberSaveable { mutableIntStateOf(AdvancedFileUtils.WatermarkPosition.DIAGONAL.ordinal) }
    var opacity by rememberSaveable { mutableFloatStateOf(25f) }
    var fontSize by rememberSaveable { mutableFloatStateOf(42f) }
    var pagesText by rememberSaveable { mutableStateOf("") }
    var pageNumbers by rememberSaveable { mutableStateOf(false) }
    var firstPageNumber by rememberSaveable { mutableStateOf("1") }
    var currentPassword by rememberSaveable { mutableStateOf("") }
    var newPassword by rememberSaveable { mutableStateOf("") }
    var allowPrinting by rememberSaveable { mutableStateOf(true) }
    var allowCopy by rememberSaveable { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    val modes = listOf("Marca y numeración", "Agregar/cambiar contraseña", "Quitar contraseña")
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { input = it }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val source = input ?: return@rememberLauncherForActivityResult
        if (output == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                when (modeIndex) {
                    0 -> {
                        val count = ToolFileUtils.pdfPageCount(context, source)
                        val pages = PageSelectionParser.parse(pagesText, count).toSet()
                        AdvancedFileUtils.watermarkPdf(context, source, output, AdvancedFileUtils.PdfWatermarkOptions(
                            text = watermark,
                            opacityPercent = opacity.toInt(),
                            fontSize = fontSize,
                            position = AdvancedFileUtils.WatermarkPosition.entries[positionIndex],
                            addPageNumbers = pageNumbers,
                            firstPageNumber = firstPageNumber.toIntOrNull()?.coerceIn(1, 9999) ?: 1,
                            pages = pages
                        ), currentPassword)
                    }
                    1 -> AdvancedFileUtils.changePdfProtection(context, source, output, currentPassword, newPassword, allowPrinting, allowCopy)
                    else -> AdvancedFileUtils.changePdfProtection(context, source, output, currentPassword, null)
                }
            }.onSuccess { onMessage(successMessage("PDF guardado", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar el PDF") }
            processing = false
        }
    }
    AdvancedToolPage(tool, onBack) {
        AdvancedSection("Archivo") {
            OutlinedButton(onClick = { pick.launch(arrayOf("application/pdf")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Folder, null); Text(" Seleccionar PDF") }
            input?.let { Text(ToolFileUtils.displayName(context, it), color = NeonGreen) }
            SimpleDropdown("Operación", modes, modeIndex) { modeIndex = it }
        }
        if (modeIndex == 0 && input != null) AdvancedSection("Vista previa") {
            PdfWatermarkLivePreview(
                uri = input!!,
                watermark = watermark,
                position = AdvancedFileUtils.WatermarkPosition.entries[positionIndex],
                opacityPercent = opacity,
                fontSizePt = fontSize,
                pageNumbers = pageNumbers,
                firstPageNumber = firstPageNumber.toIntOrNull() ?: 1
            )
            Text(
                "La vista es aproximada; el PDF exportado conserva la página original y aplica la marca con la configuración elegida.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (modeIndex == 0) AdvancedSection("Marca de agua y páginas") {
            OutlinedTextField(watermark, { watermark = it.take(120) }, label = { Text("Texto de la marca") }, modifier = Modifier.fillMaxWidth())
            SimpleDropdown("Posición", AdvancedFileUtils.WatermarkPosition.entries.map { it.label }, positionIndex) { positionIndex = it }
            Text("Opacidad: ${opacity.toInt()} %"); Slider(opacity, { opacity = it }, valueRange = 5f..80f)
            Text("Tamaño: ${fontSize.toInt()} pt"); Slider(fontSize, { fontSize = it }, valueRange = 12f..90f)
            OutlinedTextField(pagesText, { pagesText = it.filter { c -> c.isDigit() || c in ", -" }.take(120) }, label = { Text("Páginas (vacío = todas)") }, placeholder = { Text("1-3, 5, 8") }, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Agregar número de página", modifier = Modifier.weight(1f)); Switch(pageNumbers, { pageNumbers = it }) }
            if (pageNumbers) OutlinedTextField(firstPageNumber, { firstPageNumber = it.filter(Char::isDigit).take(4) }, label = { Text("Comenzar numeración en") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(currentPassword, { currentPassword = it.take(60) }, label = { Text("Contraseña actual, si tiene") }, modifier = Modifier.fillMaxWidth())
        } else AdvancedSection("Contraseña y permisos") {
            OutlinedTextField(currentPassword, { currentPassword = it.take(60) }, label = { Text("Contraseña actual, si tiene") }, modifier = Modifier.fillMaxWidth())
            if (modeIndex == 1) {
                OutlinedTextField(newPassword, { newPassword = it.take(60) }, label = { Text("Nueva contraseña") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Permitir impresión", modifier = Modifier.weight(1f)); Switch(allowPrinting, { allowPrinting = it }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Permitir copiar contenido", modifier = Modifier.weight(1f)); Switch(allowCopy, { allowCopy = it }) }
            } else Text("Solo funciona cuando el usuario conoce la contraseña actual.", color = Gold)
        }
        if (processing) {
            item { AdvancedProgress("Procesando PDF", null) }
        }
        item {
            Button(onClick = {
                if (input == null) onMessage("Selecciona un PDF")
                else if (modeIndex == 1 && newPassword.length < 4) onMessage("La nueva contraseña debe tener al menos 4 caracteres")
                else launchPaidExport(viewModel, tool, onMessage) { save.launch("pdf_procesado_gana_geo.pdf") }
            }, enabled = input != null && !processing, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                Text("Guardar PDF · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PdfWatermarkLivePreview(
    uri: Uri,
    watermark: String,
    position: AdvancedFileUtils.WatermarkPosition,
    opacityPercent: Float,
    fontSizePt: Float,
    pageNumbers: Boolean,
    firstPageNumber: Int
) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, uri) {
        value = runCatching { ToolFileUtils.renderPdfPage(context, uri, 0, maxWidth = 760) }.getOrNull()
    }
    DisposableEffect(bitmap) {
        val current = bitmap
        onDispose { if (current != null && !current.isRecycled) current.recycle() }
    }
    Box(
        modifier = Modifier.fillMaxWidth().height(380.dp).background(Color(0xFF121212), RoundedCornerShape(14.dp)).padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        val page = bitmap
        if (page == null) {
            CircularProgressIndicator(color = NeonGreen)
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Image(page.asImageBitmap(), "Vista previa PDF", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                val watermarkSize = (fontSizePt * 0.42f).coerceIn(10f, 40f).sp
                val alpha = (opacityPercent / 100f).coerceIn(0.05f, 0.8f)
                when (position) {
                    AdvancedFileUtils.WatermarkPosition.REPEAT -> {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(vertical = 42.dp),
                            verticalArrangement = Arrangement.SpaceEvenly,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            repeat(4) {
                                Text(
                                    watermark.ifBlank { "Marca de agua" },
                                    color = Color.Black.copy(alpha = alpha),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = watermarkSize,
                                    modifier = Modifier.graphicsLayer { rotationZ = -28f }
                                )
                            }
                        }
                    }
                    else -> {
                        val alignment = when (position) {
                            AdvancedFileUtils.WatermarkPosition.TOP -> Alignment.TopCenter
                            AdvancedFileUtils.WatermarkPosition.BOTTOM -> Alignment.BottomCenter
                            else -> Alignment.Center
                        }
                        Text(
                            watermark.ifBlank { "Marca de agua" },
                            color = Color.Black.copy(alpha = alpha),
                            fontWeight = FontWeight.Bold,
                            fontSize = watermarkSize,
                            modifier = Modifier
                                .align(alignment)
                                .padding(22.dp)
                                .graphicsLayer { rotationZ = if (position == AdvancedFileUtils.WatermarkPosition.DIAGONAL) -32f else 0f }
                        )
                    }
                }
                if (pageNumbers) {
                    Text(
                        firstPageNumber.toString(),
                        color = Color.Black.copy(alpha = 0.78f),
                        fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AdvancedToolPage(tool: ToolId, onBack: () -> Unit, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, tool.subtitle, onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF401415)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = Gold)
                        Column(Modifier.weight(1f)) {
                            Text("Operación profesional", fontWeight = FontWeight.Bold)
                            Text(
                                "Costo: ${tool.creditCost} créditos. Solo se confirma cuando el archivo se crea correctamente.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            content()
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.AdvancedSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    item {
        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                content()
            }
        }
    }
}

@Composable
private fun AdvancedProgress(title: String, progress: Float?) {
    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (progress == null) LinearProgressIndicator(Modifier.fillMaxWidth()) else LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        }
    }
}
