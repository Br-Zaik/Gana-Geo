package com.ganageo.app.tools

import java.math.BigInteger
import java.text.DecimalFormat
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

private val academicNumberFormat = DecimalFormat("0.##########")

fun formatAcademicNumber(value: Double): String = academicNumberFormat.format(value)

data class StatisticsResult(
    val count: Int,
    val sum: Double,
    val mean: Double,
    val median: Double,
    val modes: List<Double>,
    val minimum: Double,
    val maximum: Double,
    val range: Double,
    val populationVariance: Double,
    val populationStandardDeviation: Double,
    val sampleVariance: Double?,
    val sampleStandardDeviation: Double?,
    val firstQuartile: Double,
    val thirdQuartile: Double
)

object StatisticsCalculator {
    fun parseValues(raw: String): List<Double> {
        val normalized = raw
            .replace('\n', ';')
            .replace('\t', ';')

        val tokens = if (normalized.contains(';') || normalized.contains(' ')) {
            normalized.split(Regex("[;\\s]+"))
        } else {
            // Cuando solo hay comas, se interpretan como separadores de valores.
            normalized.split(',')
        }

        return tokens
            .map(String::trim)
            .filter(String::isNotEmpty)
            .map { token ->
                token.replace(',', '.').toDoubleOrNull()
                    ?: throw IllegalArgumentException("Valor inválido: $token")
            }
    }

    fun calculate(values: List<Double>): StatisticsResult {
        require(values.isNotEmpty()) { "Ingresa al menos un valor" }
        require(values.all(Double::isFinite)) { "Todos los valores deben ser finitos" }

        val sorted = values.sorted()
        val count = sorted.size
        val sum = sorted.sum()
        val mean = sum / count
        val median = medianOf(sorted)

        val frequencies = sorted.groupingBy { it }.eachCount()
        val highestFrequency = frequencies.values.maxOrNull() ?: 1
        val modes = if (highestFrequency <= 1) emptyList() else {
            frequencies.filterValues { it == highestFrequency }.keys.sorted()
        }

        val populationVariance = sorted.sumOf { (it - mean).pow(2) } / count
        val sampleVariance = if (count > 1) {
            sorted.sumOf { (it - mean).pow(2) } / (count - 1)
        } else null

        val lowerHalf = sorted.subList(0, count / 2)
        val upperHalf = sorted.subList((count + 1) / 2, count)
        val firstQuartile = if (lowerHalf.isEmpty()) median else medianOf(lowerHalf)
        val thirdQuartile = if (upperHalf.isEmpty()) median else medianOf(upperHalf)

        return StatisticsResult(
            count = count,
            sum = sum,
            mean = mean,
            median = median,
            modes = modes,
            minimum = sorted.first(),
            maximum = sorted.last(),
            range = sorted.last() - sorted.first(),
            populationVariance = populationVariance,
            populationStandardDeviation = sqrt(populationVariance),
            sampleVariance = sampleVariance,
            sampleStandardDeviation = sampleVariance?.let(::sqrt),
            firstQuartile = firstQuartile,
            thirdQuartile = thirdQuartile
        )
    }

    private fun medianOf(sorted: List<Double>): Double {
        require(sorted.isNotEmpty())
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 0) {
            (sorted[middle - 1] + sorted[middle]) / 2.0
        } else {
            sorted[middle]
        }
    }
}

data class EquationResult(
    val title: String,
    val resultLines: List<String>,
    val steps: List<String>
)

object EquationSolver {
    private const val EPSILON = 1e-12

    fun solveLinear(a: Double, b: Double): EquationResult {
        require(a.isFinite() && b.isFinite()) { "Coeficientes inválidos" }
        return when {
            abs(a) < EPSILON && abs(b) < EPSILON -> EquationResult(
                "Ecuación lineal",
                listOf("Infinitas soluciones"),
                listOf("La ecuación se reduce a 0 = 0")
            )
            abs(a) < EPSILON -> EquationResult(
                "Ecuación lineal",
                listOf("No tiene solución"),
                listOf("La ecuación se reduce a ${formatAcademicNumber(b)} = 0")
            )
            else -> {
                val x = -b / a
                EquationResult(
                    "Ecuación lineal",
                    listOf("x = ${formatAcademicNumber(x)}"),
                    listOf(
                        "${formatAcademicNumber(a)}x + ${formatAcademicNumber(b)} = 0",
                        "${formatAcademicNumber(a)}x = ${formatAcademicNumber(-b)}",
                        "x = ${formatAcademicNumber(-b)} / ${formatAcademicNumber(a)}",
                        "x = ${formatAcademicNumber(x)}"
                    )
                )
            }
        }
    }

    fun solveQuadratic(a: Double, b: Double, c: Double): EquationResult {
        require(a.isFinite() && b.isFinite() && c.isFinite()) { "Coeficientes inválidos" }
        if (abs(a) < EPSILON) return solveLinear(b, c)

        val discriminant = b * b - 4 * a * c
        val steps = mutableListOf(
            "Δ = b² - 4ac",
            "Δ = (${formatAcademicNumber(b)})² - 4(${formatAcademicNumber(a)})(${formatAcademicNumber(c)})",
            "Δ = ${formatAcademicNumber(discriminant)}"
        )

        return when {
            discriminant > EPSILON -> {
                val sqrtD = sqrt(discriminant)
                val x1 = (-b + sqrtD) / (2 * a)
                val x2 = (-b - sqrtD) / (2 * a)
                steps += "x = (-b ± √Δ) / 2a"
                steps += "x₁ = ${formatAcademicNumber(x1)}"
                steps += "x₂ = ${formatAcademicNumber(x2)}"
                EquationResult(
                    "Ecuación cuadrática",
                    listOf("x₁ = ${formatAcademicNumber(x1)}", "x₂ = ${formatAcademicNumber(x2)}"),
                    steps
                )
            }
            abs(discriminant) <= EPSILON -> {
                val x = -b / (2 * a)
                steps += "Como Δ = 0, existe una raíz doble"
                steps += "x = ${formatAcademicNumber(x)}"
                EquationResult(
                    "Ecuación cuadrática",
                    listOf("Raíz doble: x = ${formatAcademicNumber(x)}"),
                    steps
                )
            }
            else -> {
                val real = -b / (2 * a)
                val imaginary = sqrt(-discriminant) / abs(2 * a)
                steps += "Como Δ < 0, las soluciones son complejas"
                EquationResult(
                    "Ecuación cuadrática",
                    listOf(
                        "x₁ = ${formatAcademicNumber(real)} + ${formatAcademicNumber(imaginary)}i",
                        "x₂ = ${formatAcademicNumber(real)} - ${formatAcademicNumber(imaginary)}i"
                    ),
                    steps
                )
            }
        }
    }

    fun solveSystem2x2(
        a1: Double,
        b1: Double,
        c1: Double,
        a2: Double,
        b2: Double,
        c2: Double
    ): EquationResult {
        val coefficients = listOf(a1, b1, c1, a2, b2, c2)
        require(coefficients.all(Double::isFinite)) { "Coeficientes inválidos" }

        val determinant = a1 * b2 - a2 * b1
        val determinantX = c1 * b2 - c2 * b1
        val determinantY = a1 * c2 - a2 * c1
        val steps = mutableListOf(
            "D = a₁b₂ - a₂b₁ = ${formatAcademicNumber(determinant)}",
            "Dx = c₁b₂ - c₂b₁ = ${formatAcademicNumber(determinantX)}",
            "Dy = a₁c₂ - a₂c₁ = ${formatAcademicNumber(determinantY)}"
        )

        return if (abs(determinant) > EPSILON) {
            val x = determinantX / determinant
            val y = determinantY / determinant
            steps += "x = Dx / D = ${formatAcademicNumber(x)}"
            steps += "y = Dy / D = ${formatAcademicNumber(y)}"
            EquationResult(
                "Sistema de ecuaciones 2×2",
                listOf("x = ${formatAcademicNumber(x)}", "y = ${formatAcademicNumber(y)}"),
                steps
            )
        } else if (abs(determinantX) < EPSILON && abs(determinantY) < EPSILON) {
            EquationResult(
                "Sistema de ecuaciones 2×2",
                listOf("Infinitas soluciones"),
                steps + "Las ecuaciones son dependientes"
            )
        } else {
            EquationResult(
                "Sistema de ecuaciones 2×2",
                listOf("No tiene solución"),
                steps + "Las rectas son paralelas"
            )
        }
    }
}

data class PhysicsOperation(
    val title: String,
    val firstLabel: String,
    val secondLabel: String,
    val resultLabel: String,
    val formula: String,
    val unit: String,
    val calculate: (Double, Double) -> Double
)

val physicsOperations = listOf(
    PhysicsOperation("Velocidad", "Distancia (m)", "Tiempo (s)", "Velocidad", "v = d / t", "m/s") { d, t ->
        require(abs(t) > 1e-12) { "El tiempo no puede ser cero" }
        d / t
    },
    PhysicsOperation("Distancia", "Velocidad (m/s)", "Tiempo (s)", "Distancia", "d = v × t", "m") { v, t -> v * t },
    PhysicsOperation("Tiempo", "Distancia (m)", "Velocidad (m/s)", "Tiempo", "t = d / v", "s") { d, v ->
        require(abs(v) > 1e-12) { "La velocidad no puede ser cero" }
        d / v
    },
    PhysicsOperation("Fuerza", "Masa (kg)", "Aceleración (m/s²)", "Fuerza", "F = m × a", "N") { m, a -> m * a },
    PhysicsOperation("Trabajo", "Fuerza (N)", "Distancia (m)", "Trabajo", "W = F × d", "J") { f, d -> f * d },
    PhysicsOperation("Potencia mecánica", "Trabajo (J)", "Tiempo (s)", "Potencia", "P = W / t", "W") { w, t ->
        require(abs(t) > 1e-12) { "El tiempo no puede ser cero" }
        w / t
    },
    PhysicsOperation("Densidad", "Masa (kg)", "Volumen (m³)", "Densidad", "ρ = m / V", "kg/m³") { m, v ->
        require(abs(v) > 1e-12) { "El volumen no puede ser cero" }
        m / v
    },
    PhysicsOperation("Presión", "Fuerza (N)", "Área (m²)", "Presión", "p = F / A", "Pa") { f, a ->
        require(abs(a) > 1e-12) { "El área no puede ser cero" }
        f / a
    },
    PhysicsOperation("Voltaje (Ley de Ohm)", "Corriente (A)", "Resistencia (Ω)", "Voltaje", "V = I × R", "V") { i, r -> i * r },
    PhysicsOperation("Corriente (Ley de Ohm)", "Voltaje (V)", "Resistencia (Ω)", "Corriente", "I = V / R", "A") { v, r ->
        require(abs(r) > 1e-12) { "La resistencia no puede ser cero" }
        v / r
    },
    PhysicsOperation("Potencia eléctrica", "Voltaje (V)", "Corriente (A)", "Potencia", "P = V × I", "W") { v, i -> v * i },
    PhysicsOperation("Energía cinética", "Masa (kg)", "Velocidad (m/s)", "Energía", "Ec = ½mv²", "J") { m, v -> 0.5 * m * v * v },
    PhysicsOperation("Energía potencial", "Masa (kg)", "Altura (m)", "Energía", "Ep = mgh (g = 9.80665)", "J") { m, h -> m * 9.80665 * h },
    PhysicsOperation("Frecuencia", "Número de ciclos", "Tiempo (s)", "Frecuencia", "f = ciclos / t", "Hz") { cycles, t ->
        require(abs(t) > 1e-12) { "El tiempo no puede ser cero" }; cycles / t
    },
    PhysicsOperation("Período", "Tiempo (s)", "Número de ciclos", "Período", "T = t / ciclos", "s") { t, cycles ->
        require(abs(cycles) > 1e-12) { "Los ciclos no pueden ser cero" }; t / cycles
    },
    PhysicsOperation("Resistencias en serie", "Resistencia 1 (Ω)", "Resistencia 2 (Ω)", "Resistencia equivalente", "Req = R₁ + R₂", "Ω") { r1, r2 -> r1 + r2 },
    PhysicsOperation("Resistencias en paralelo", "Resistencia 1 (Ω)", "Resistencia 2 (Ω)", "Resistencia equivalente", "Req = R₁R₂/(R₁+R₂)", "Ω") { r1, r2 ->
        require(abs(r1 + r2) > 1e-12) { "La suma de resistencias no puede ser cero" }; r1 * r2 / (r1 + r2)
    },
    PhysicsOperation("MRUA · velocidad final", "Velocidad inicial (m/s)", "Aceleración (m/s²)", "Velocidad final", "vf = vi + a × t", "m/s") { vi, at -> vi + at },
    PhysicsOperation("Caída libre", "Tiempo (s)", "Gravedad (m/s²)", "Altura recorrida", "h = ½gt²", "m") { t, g -> 0.5 * g * t * t }
)

data class ChemicalComposition(
    val elementCounts: Map<String, Int>,
    val molarMass: Double
)

object ChemistryCalculator {
    private val atomicMasses = mapOf(
        "H" to 1.008, "He" to 4.0026, "Li" to 6.94, "Be" to 9.0122, "B" to 10.81,
        "C" to 12.011, "N" to 14.007, "O" to 15.999, "F" to 18.998, "Ne" to 20.180,
        "Na" to 22.990, "Mg" to 24.305, "Al" to 26.982, "Si" to 28.085, "P" to 30.974,
        "S" to 32.06, "Cl" to 35.45, "Ar" to 39.948, "K" to 39.0983, "Ca" to 40.078,
        "Sc" to 44.956, "Ti" to 47.867, "V" to 50.942, "Cr" to 51.996, "Mn" to 54.938,
        "Fe" to 55.845, "Co" to 58.933, "Ni" to 58.693, "Cu" to 63.546, "Zn" to 65.38,
        "Ga" to 69.723, "Ge" to 72.630, "As" to 74.922, "Se" to 78.971, "Br" to 79.904,
        "Kr" to 83.798, "Rb" to 85.468, "Sr" to 87.62, "Y" to 88.906, "Zr" to 91.224,
        "Nb" to 92.906, "Mo" to 95.95, "Tc" to 98.0, "Ru" to 101.07, "Rh" to 102.91,
        "Pd" to 106.42, "Ag" to 107.87, "Cd" to 112.41, "In" to 114.82, "Sn" to 118.71,
        "Sb" to 121.76, "Te" to 127.60, "I" to 126.90, "Xe" to 131.29, "Cs" to 132.91,
        "Ba" to 137.33, "La" to 138.91, "Ce" to 140.12, "Pr" to 140.91, "Nd" to 144.24,
        "Pm" to 145.0, "Sm" to 150.36, "Eu" to 151.96, "Gd" to 157.25, "Tb" to 158.93,
        "Dy" to 162.50, "Ho" to 164.93, "Er" to 167.26, "Tm" to 168.93, "Yb" to 173.05,
        "Lu" to 174.97, "Hf" to 178.49, "Ta" to 180.95, "W" to 183.84, "Re" to 186.21,
        "Os" to 190.23, "Ir" to 192.22, "Pt" to 195.08, "Au" to 196.97, "Hg" to 200.59,
        "Tl" to 204.38, "Pb" to 207.2, "Bi" to 208.98, "Po" to 209.0, "At" to 210.0,
        "Rn" to 222.0, "Fr" to 223.0, "Ra" to 226.0, "Ac" to 227.0, "Th" to 232.04,
        "Pa" to 231.04, "U" to 238.03, "Np" to 237.0, "Pu" to 244.0, "Am" to 243.0,
        "Cm" to 247.0, "Bk" to 247.0, "Cf" to 251.0, "Es" to 252.0, "Fm" to 257.0,
        "Md" to 258.0, "No" to 259.0, "Lr" to 266.0, "Rf" to 267.0, "Db" to 268.0,
        "Sg" to 269.0, "Bh" to 270.0, "Hs" to 277.0, "Mt" to 278.0, "Ds" to 281.0,
        "Rg" to 282.0, "Cn" to 285.0, "Nh" to 286.0, "Fl" to 289.0, "Mc" to 290.0,
        "Lv" to 293.0, "Ts" to 294.0, "Og" to 294.0
    )

    fun atomicMass(symbol: String): Double? = atomicMasses[symbol]

    fun analyzeFormula(formula: String): ChemicalComposition {
        val cleaned = formula.replace(" ", "")
        require(cleaned.isNotBlank()) { "Escribe una fórmula química" }

        val totals = linkedMapOf<String, Int>()
        cleaned.split('·', '.').filter(String::isNotBlank).forEach { part ->
            var index = 0
            while (index < part.length && part[index].isDigit()) index++
            val coefficient = if (index > 0) part.substring(0, index).toInt() else 1
            val parser = FormulaParser(part.substring(index), atomicMasses.keys)
            val partCounts = parser.parse()
            partCounts.forEach { (symbol, count) ->
                totals[symbol] = (totals[symbol] ?: 0) + count * coefficient
            }
        }

        val mass = totals.entries.sumOf { (symbol, count) -> atomicMasses.getValue(symbol) * count }
        return ChemicalComposition(totals, mass)
    }

    fun molesFromMass(massGrams: Double, molarMass: Double): Double {
        require(massGrams >= 0 && massGrams.isFinite()) { "La masa debe ser válida" }
        require(molarMass > 0 && molarMass.isFinite()) { "La masa molar debe ser mayor que cero" }
        return massGrams / molarMass
    }

    fun massFromMoles(moles: Double, molarMass: Double): Double {
        require(moles >= 0 && moles.isFinite()) { "Los moles deben ser válidos" }
        require(molarMass > 0 && molarMass.isFinite()) { "La masa molar debe ser mayor que cero" }
        return moles * molarMass
    }

    private class FormulaParser(
        private val formula: String,
        private val validElements: Set<String>
    ) {
        private var position = 0

        fun parse(): Map<String, Int> {
            val result = parseGroup(expectClosingParenthesis = false)
            require(position == formula.length) { "Fórmula química inválida" }
            return result
        }

        private fun parseGroup(expectClosingParenthesis: Boolean): MutableMap<String, Int> {
            val counts = linkedMapOf<String, Int>()
            while (position < formula.length) {
                when (val char = formula[position]) {
                    '(' -> {
                        position++
                        val nested = parseGroup(expectClosingParenthesis = true)
                        require(position < formula.length && formula[position] == ')') {
                            "Falta cerrar un paréntesis"
                        }
                        position++
                        val multiplier = parseNumber()
                        nested.forEach { (symbol, count) -> add(counts, symbol, count * multiplier) }
                    }
                    ')' -> {
                        require(expectClosingParenthesis) { "Paréntesis inesperado" }
                        return counts
                    }
                    else -> {
                        require(char.isUpperCase()) { "Símbolo inválido cerca de: ${formula.substring(position)}" }
                        val symbol = buildString {
                            append(formula[position++])
                            if (position < formula.length && formula[position].isLowerCase()) {
                                append(formula[position++])
                            }
                        }
                        require(symbol in validElements) { "Elemento desconocido: $symbol" }
                        add(counts, symbol, parseNumber())
                    }
                }
            }
            require(!expectClosingParenthesis) { "Falta cerrar un paréntesis" }
            return counts
        }

        private fun parseNumber(): Int {
            val start = position
            while (position < formula.length && formula[position].isDigit()) position++
            return if (start == position) 1 else formula.substring(start, position).toInt().also {
                require(it > 0) { "Los subíndices deben ser mayores que cero" }
            }
        }

        private fun add(target: MutableMap<String, Int>, symbol: String, count: Int) {
            target[symbol] = (target[symbol] ?: 0) + count
        }
    }
}

data class BaseConversionResult(
    val binary: String,
    val octal: String,
    val decimal: String,
    val hexadecimal: String
)

object NumberBaseConverter {
    fun convert(raw: String, fromBase: Int): BaseConversionResult {
        require(fromBase in listOf(2, 8, 10, 16)) { "Base no soportada" }
        val normalized = raw.trim().replace("_", "")
        require(normalized.isNotBlank()) { "Escribe un número" }
        val value = try {
            BigInteger(normalized, fromBase)
        } catch (_: NumberFormatException) {
            throw IllegalArgumentException("El número no es válido para base $fromBase")
        }
        return BaseConversionResult(
            binary = value.toString(2),
            octal = value.toString(8),
            decimal = value.toString(10),
            hexadecimal = value.toString(16).uppercase()
        )
    }
}

enum class CitationStyle(val label: String) {
    APA7("APA 7"),
    VANCOUVER("Vancouver"),
    IEEE("IEEE"),
    MLA("MLA 9")
}

enum class CitationSourceType(val label: String) {
    BOOK("Libro"),
    WEBSITE("Página web"),
    ARTICLE("Artículo"),
    THESIS("Tesis"),
    VIDEO("Video"),
    REPORT("Informe"),
    CONFERENCE("Ponencia o conferencia"),
    DATASET("Conjunto de datos")
}

data class CitationInput(
    val author: String,
    val title: String,
    val year: String,
    val publisherOrInstitution: String = "",
    val journal: String = "",
    val volume: String = "",
    val issue: String = "",
    val pages: String = "",
    val url: String = "",
    val doi: String = "",
    val accessDate: String = ""
)

object CitationFormatter {
    fun format(style: CitationStyle, type: CitationSourceType, input: CitationInput): String {
        require(input.author.isNotBlank()) { "Escribe el autor" }
        require(input.title.isNotBlank()) { "Escribe el título" }
        require(input.year.isNotBlank()) { "Escribe el año" }

        val author = input.author.trim().removeSuffix(".")
        val title = input.title.trim().removeSuffix(".")
        val year = input.year.trim()
        val publisher = input.publisherOrInstitution.trim().removeSuffix(".")
        val journal = input.journal.trim().removeSuffix(".")
        val volumeIssue = buildString {
            if (input.volume.isNotBlank()) append(input.volume.trim())
            if (input.issue.isNotBlank()) append("(${input.issue.trim()})")
        }
        val pages = input.pages.trim()
        val url = input.url.trim()
        val doi = input.doi.trim().removePrefix("https://doi.org/").removePrefix("http://doi.org/").removePrefix("doi:").trim()
        val doiUrl = if (doi.isBlank()) "" else "https://doi.org/$doi"

        return when (style) {
            CitationStyle.APA7 -> when (type) {
                CitationSourceType.BOOK -> "$author. ($year). $title.${publisherPart(publisher)}"
                CitationSourceType.WEBSITE -> "$author. ($year). $title.${publisherPart(publisher)}${urlPart(url)}"
                CitationSourceType.ARTICLE -> buildString {
                    append("$author. ($year). $title.")
                    if (journal.isNotBlank()) append(" $journal")
                    if (volumeIssue.isNotBlank()) append(", $volumeIssue")
                    if (pages.isNotBlank()) append(", $pages")
                    append(".")
                    when {
                        doiUrl.isNotBlank() -> append(" $doiUrl")
                        url.isNotBlank() -> append(" $url")
                    }
                }
                CitationSourceType.THESIS -> "$author. ($year). $title [Tesis].${publisherPart(publisher)}${urlPart(url)}"
                CitationSourceType.VIDEO -> "$author. ($year). $title [Video].${publisherPart(publisher)}${urlPart(url)}"
                CitationSourceType.REPORT -> "$author. ($year). $title [Informe].${publisherPart(publisher)}${urlPart(url)}"
                CitationSourceType.CONFERENCE -> "$author. ($year). $title [Ponencia].${publisherPart(publisher)}${urlPart(url)}"
                CitationSourceType.DATASET -> "$author. ($year). $title [Conjunto de datos].${publisherPart(publisher)}${urlPart(url)}"
            }
            CitationStyle.VANCOUVER -> when (type) {
                CitationSourceType.BOOK -> "$author. $title. ${publisher.ifBlank { "Editorial" }}; $year."
                CitationSourceType.WEBSITE -> buildString {
                    append("$author. $title [Internet]. $year")
                    if (input.accessDate.isNotBlank()) append(" [citado ${input.accessDate.trim()}]")
                    append(".")
                    if (url.isNotBlank()) append(" Disponible en: $url")
                }
                CitationSourceType.ARTICLE -> buildString {
                    append("$author. $title. ${journal.ifBlank { "Revista" }}. $year")
                    if (volumeIssue.isNotBlank()) append(";$volumeIssue")
                    if (pages.isNotBlank()) append(":$pages")
                    append(".")
                    if (doi.isNotBlank()) append(" doi: $doi.")
                }
                CitationSourceType.THESIS -> "$author. $title [tesis]. ${publisher.ifBlank { "Institución" }}; $year.${urlPart(url)}"
                CitationSourceType.VIDEO -> "$author. $title [video]. ${publisher.ifBlank { "Plataforma" }}; $year.${urlPart(url)}"
                CitationSourceType.REPORT -> "$author. $title [informe]. ${publisher.ifBlank { "Institución" }}; $year.${urlPart(url)}"
                CitationSourceType.CONFERENCE -> "$author. $title [ponencia]. ${publisher.ifBlank { "Evento" }}; $year.${urlPart(url)}"
                CitationSourceType.DATASET -> "$author. $title [conjunto de datos]. ${publisher.ifBlank { "Repositorio" }}; $year.${urlPart(url)}"
            }
            CitationStyle.IEEE -> when (type) {
                CitationSourceType.BOOK -> "$author, “$title,” ${publisher.ifBlank { "Editorial" }}, $year."
                CitationSourceType.WEBSITE -> buildString {
                    append("$author, “$title,” $year. [En línea].")
                    if (url.isNotBlank()) append(" Disponible: $url.")
                    if (input.accessDate.isNotBlank()) append(" [Accedido: ${input.accessDate.trim()}].")
                }
                CitationSourceType.ARTICLE -> buildString {
                    append("$author, “$title,” ${journal.ifBlank { "Revista" }}")
                    if (input.volume.isNotBlank()) append(", vol. ${input.volume.trim()}")
                    if (input.issue.isNotBlank()) append(", no. ${input.issue.trim()}")
                    if (pages.isNotBlank()) append(", pp. $pages")
                    append(", $year.")
                    if (doi.isNotBlank()) append(" doi: $doi.")
                }
                CitationSourceType.THESIS -> "$author, “$title,” tesis, ${publisher.ifBlank { "Institución" }}, $year.${urlPart(url)}"
                CitationSourceType.VIDEO -> "$author, “$title,” video, ${publisher.ifBlank { "Plataforma" }}, $year.${urlPart(url)}"
                CitationSourceType.REPORT -> "$author, “$title,” informe, ${publisher.ifBlank { "Institución" }}, $year.${urlPart(url)}"
                CitationSourceType.CONFERENCE -> "$author, “$title,” ponencia, ${publisher.ifBlank { "Evento" }}, $year.${urlPart(url)}"
                CitationSourceType.DATASET -> "$author, “$title,” conjunto de datos, ${publisher.ifBlank { "Repositorio" }}, $year.${urlPart(url)}"
            }
            CitationStyle.MLA -> when (type) {
                CitationSourceType.BOOK -> "$author. $title. ${publisher.ifBlank { "Editorial" }}, $year."
                CitationSourceType.WEBSITE -> buildString {
                    append("$author. “$title.”")
                    if (publisher.isNotBlank()) append(" $publisher,")
                    append(" $year")
                    if (url.isNotBlank()) append(", $url")
                    append(".")
                    if (input.accessDate.isNotBlank()) append(" Consultado el ${input.accessDate.trim()}.")
                }
                CitationSourceType.ARTICLE -> buildString {
                    append("$author. “$title.” ${journal.ifBlank { "Revista" }}")
                    if (input.volume.isNotBlank()) append(", vol. ${input.volume.trim()}")
                    if (input.issue.isNotBlank()) append(", núm. ${input.issue.trim()}")
                    append(", $year")
                    if (pages.isNotBlank()) append(", pp. $pages")
                    if (doiUrl.isNotBlank()) append(", $doiUrl")
                    append(".")
                }
                CitationSourceType.THESIS -> "$author. $title. $year. ${publisher.ifBlank { "Institución" }}, tesis.${urlPart(url)}"
                CitationSourceType.VIDEO -> "$author. “$title.” ${publisher.ifBlank { "Plataforma" }}, $year.${urlPart(url)}"
                CitationSourceType.REPORT -> "$author. $title. ${publisher.ifBlank { "Institución" }}, $year.${urlPart(url)}"
                CitationSourceType.CONFERENCE -> "$author. “$title.” ${publisher.ifBlank { "Evento" }}, $year.${urlPart(url)}"
                CitationSourceType.DATASET -> "$author. $title. ${publisher.ifBlank { "Repositorio" }}, $year.${urlPart(url)}"
            }
        }.replace(Regex("\\s+"), " ").trim()
    }

    /**
     * Cita en el texto: la version corta que va dentro del parrafo, distinta de
     * la referencia completa de la bibliografia. Es el punto donde mas se
     * equivocan los estudiantes.
     *
     * - APA 7: (Apellido, Anio). Con 3 o mas autores se abrevia a "et al."
     *   desde la primera vez que se cita.
     * - Vancouver e IEEE: numericas, en el orden en que aparecen en el texto.
     * - MLA 9: (Apellido pagina), sin coma y sin anio.
     */
    fun inTextCitation(
        style: CitationStyle,
        input: CitationInput,
        number: Int = 1
    ): String {
        val surname = primarySurname(input.author)
        val authorCount = countAuthors(input.author)
        val year = input.year.trim().ifBlank { "s.f." }
        return when (style) {
            CitationStyle.APA7 -> {
                val name = if (authorCount >= 3) "$surname et al." else surname
                "($name, $year)"
            }
            CitationStyle.VANCOUVER -> "($number)"
            CitationStyle.IEEE -> "[$number]"
            CitationStyle.MLA -> {
                val page = input.pages.trim().substringBefore('-').trim()
                if (page.isBlank()) "($surname)" else "($surname $page)"
            }
        }
    }

    /**
     * Cuenta autores separados por ";" o por " y ". Se usa para decidir si APA
     * debe abreviar con "et al.".
     */
    private fun countAuthors(raw: String): Int {
        val cleaned = raw.trim()
        if (cleaned.isBlank()) return 0
        val bySemicolon = cleaned.split(';').map { it.trim() }.filter { it.isNotBlank() }
        if (bySemicolon.size > 1) return bySemicolon.size
        val byAnd = cleaned.split(" y ", " & ").map { it.trim() }.filter { it.isNotBlank() }
        if (byAnd.size > 1) return byAnd.size
        // "Perez, J., Gomez, M., Ruiz, L." -> las iniciales delatan cada autor.
        val initials = Regex("[A-ZÁÉÍÓÚÑ]\\.").findAll(cleaned).count()
        return if (initials > 1) initials else 1
    }

    /**
     * Extrae el apellido del primer autor, aceptando tanto "Perez, J." como
     * "Juan Perez".
     */
    private fun primarySurname(raw: String): String {
        val first = raw.split(';', '&')
            .firstOrNull()
            ?.split(" y ")
            ?.firstOrNull()
            ?.trim()
            .orEmpty()
        if (first.isBlank()) return "Autor"
        if (first.contains(',')) return first.substringBefore(',').trim()
        val words = first.split(' ').filter { it.isNotBlank() && !it.endsWith(".") }
        return words.lastOrNull()?.trim().orEmpty().ifBlank { first }
    }

    private fun publisherPart(value: String): String = if (value.isBlank()) "" else " $value."
    private fun urlPart(value: String): String = if (value.isBlank()) "" else " $value"
}

object TextToolkit {
    fun normalizeSpaces(text: String): String = text
        .lines()
        .joinToString("\n") { line -> line.trim().replace(Regex("[ \\t]+"), " ") }
        .trim()

    fun removeBlankLines(text: String): String = text
        .lines()
        .filter { it.isNotBlank() }
        .joinToString("\n") { it.trimEnd() }

    fun sortLines(text: String): String = text
        .lines()
        .filter { it.isNotBlank() }
        .sortedWith(String.CASE_INSENSITIVE_ORDER)
        .joinToString("\n")

    fun numberLines(text: String): String = text
        .lines()
        .filter { it.isNotBlank() }
        .mapIndexed { index, line -> "${index + 1}. ${line.trim()}" }
        .joinToString("\n")

    fun titleCase(text: String): String {
        val lower = text.lowercase()
        return Regex("(^|\\s)(\\S)").replace(lower) { match ->
            match.groupValues[1] + match.groupValues[2].uppercase()
        }
    }

    fun findAndReplace(text: String, search: String, replacement: String, ignoreCase: Boolean = false): Pair<String, Int> {
        require(search.isNotBlank()) { "Escribe el texto que deseas buscar" }
        val regex = Regex(Regex.escape(search), if (ignoreCase) setOf(RegexOption.IGNORE_CASE) else emptySet())
        val count = regex.findAll(text).count()
        return regex.replace(text, replacement) to count
    }

    data class Comparison(
        val equal: Boolean,
        val firstDifferentLine: Int?,
        val changedLines: Int,
        val leftLines: Int,
        val rightLines: Int
    )

    fun compare(left: String, right: String): Comparison {
        val leftItems = left.lines()
        val rightItems = right.lines()
        val max = maxOf(leftItems.size, rightItems.size)
        val differences = (0 until max).filter { index -> leftItems.getOrNull(index) != rightItems.getOrNull(index) }
        return Comparison(
            equal = differences.isEmpty(),
            firstDifferentLine = differences.firstOrNull()?.plus(1),
            changedLines = differences.size,
            leftLines = leftItems.size,
            rightLines = rightItems.size
        )
    }
}
