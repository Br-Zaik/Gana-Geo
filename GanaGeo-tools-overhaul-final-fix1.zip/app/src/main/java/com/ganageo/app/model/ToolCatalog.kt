package com.ganageo.app.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.ShowChart
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.CropRotate
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Draw
import androidx.compose.material.icons.rounded.EventNote
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Merge
import androidx.compose.material.icons.rounded.Percent
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.QrCode
import androidx.compose.material.icons.rounded.Rule
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.Transform
import androidx.compose.ui.graphics.vector.ImageVector

enum class ToolCategory(val title: String, val subtitle: String) {
    MATH("Números y matemática", "Cálculos, notas, geometría y conversiones"),
    VIEWERS("Visores gratuitos", "Abre PDF, Word, Excel y PowerPoint sin editar"),
    PDF("Documentos y PDF", "Crear, organizar, convertir y firmar PDF"),
    IMAGE("Imágenes", "Comprimir, transformar y exportar imágenes"),
    SCIENCE("Ciencias y análisis", "Ecuaciones, estadística, física y química"),
    ACADEMIC("Estudio y escritura", "Referencias, flashcards, agenda y texto"),
    WORK("Trabajo y empleo", "CV, horas, pagos y cotizaciones rápidas"),
    GAME("Geo Aventuras", "Juego de plataformas, niveles y vidas"),
    QUICK("Herramientas rápidas", "QR, texto, cronómetro y temporizador")
}

enum class ToolId(
    val title: String,
    val subtitle: String,
    val category: ToolCategory,
    val icon: ImageVector,
    val creditCost: Int = 0
) {
    SCIENTIFIC_CALCULATOR(
        "Calculadora científica",
        "Operaciones, trigonometría, raíces y logaritmos",
        ToolCategory.MATH,
        Icons.Rounded.Calculate
    ),
    UNIT_CONVERTER(
        "Conversor de unidades",
        "Longitud, área, volumen, masa, temperatura y más",
        ToolCategory.MATH,
        Icons.Rounded.SwapHoriz
    ),
    PERCENT_RULE(
        "Porcentajes y regla de tres",
        "Calcula aumentos, descuentos y proporciones",
        ToolCategory.MATH,
        Icons.Rounded.Percent
    ),
    GRADES_AVERAGES(
        "Promedios y notas",
        "Promedio simple, ponderado y nota necesaria",
        ToolCategory.MATH,
        Icons.Rounded.School
    ),
    GEOMETRY(
        "Geometría",
        "Áreas, perímetros y volúmenes",
        ToolCategory.MATH,
        Icons.Rounded.Straighten
    ),

    PDF_VIEWER(
        "Visor PDF",
        "Abre, recorre, amplía y busca páginas sin editar",
        ToolCategory.VIEWERS,
        Icons.Rounded.PictureAsPdf
    ),
    WORD_VIEWER(
        "Visor Word",
        "Lee documentos DOCX con títulos, párrafos y tablas básicas",
        ToolCategory.VIEWERS,
        Icons.Rounded.Description
    ),
    EXCEL_VIEWER(
        "Visor Excel",
        "Consulta hojas XLSX, filas, columnas y valores",
        ToolCategory.VIEWERS,
        Icons.Rounded.TableChart
    ),
    POWERPOINT_VIEWER(
        "Visor PowerPoint",
        "Revisa diapositivas PPTX y su contenido sin editar",
        ToolCategory.VIEWERS,
        Icons.Rounded.Slideshow
    ),

    DOCUMENT_SCANNER(
        "Escáner de documentos",
        "Extrae texto o recrea una imagen limpia",
        ToolCategory.PDF,
        Icons.Rounded.CropRotate,
        5
    ),
    TEXT_TO_PDF(
        "Editor de documentos",
        "Crea, edita y exporta documentos a PDF",
        ToolCategory.PDF,
        Icons.Rounded.TextFields,
        5
    ),
    PDF_WATERMARK_SECURITY(
        "Marca, numera y protege PDF",
        "Marca de agua, páginas y contraseña",
        ToolCategory.PDF,
        Icons.Rounded.Lock,
        5
    ),
    IMAGES_TO_PDF(
        "Imágenes a PDF",
        "Ordena, mejora, configura y protege tu PDF",
        ToolCategory.PDF,
        Icons.Rounded.PictureAsPdf,
        5
    ),
    PDF_ORGANIZER(
        "Organizar PDF",
        "Organiza visualmente, une, divide, comprime y gira páginas",
        ToolCategory.PDF,
        Icons.Rounded.Merge,
        10
    ),
    PDF_TO_IMAGES(
        "PDF a imágenes",
        "Elige páginas, formato, calidad y resolución",
        ToolCategory.PDF,
        Icons.Rounded.Description,
        5
    ),
    SIGN_PDF(
        "Firmar PDF",
        "Dibuja, ubica y ajusta tu firma en el PDF",
        ToolCategory.PDF,
        Icons.Rounded.Draw,
        5
    ),

    IMAGE_BATCH_STUDIO(
        "Estudio de imágenes por lote",
        "Collage, carnet, unir, metadatos, marcos y ZIP",
        ToolCategory.IMAGE,
        Icons.Rounded.Image,
        5
    ),
    COMPRESS_IMAGE(
        "Comprimir imagen",
        "Elige nivel, compara y exporta una copia",
        ToolCategory.IMAGE,
        Icons.Rounded.Compress,
        5
    ),
    RESIZE_IMAGE(
        "Cambiar tamaño",
        "Usa tamaños rápidos o dimensiones personalizadas",
        ToolCategory.IMAGE,
        Icons.Rounded.Transform,
        5
    ),
    CONVERT_IMAGE(
        "Convertir formato",
        "JPG, PNG y WebP",
        ToolCategory.IMAGE,
        Icons.Rounded.Image,
        5
    ),
    CROP_ROTATE_IMAGE(
        "Recortar, girar y voltear",
        "Proporciones, rotación, volteo y vista previa",
        ToolCategory.IMAGE,
        Icons.Rounded.CropRotate,
        5
    ),
    WATERMARK_IMAGE(
        "Texto y marca de agua",
        "Posición, opacidad, tamaño y repetición",
        ToolCategory.IMAGE,
        Icons.Rounded.TextFields,
        5
    ),

    ADVANCED_MATH(
        "Matemática avanzada",
        "Matrices, vectores, sucesiones, derivadas e integrales",
        ToolCategory.SCIENCE,
        Icons.Rounded.Functions
    ),
    EQUATION_SOLVER(
        "Solucionador de ecuaciones",
        "Lineales, cuadráticas y sistemas 2×2 con pasos",
        ToolCategory.SCIENCE,
        Icons.Rounded.Functions
    ),
    FUNCTION_GRAPHER(
        "Graficador de funciones",
        "Rectas, polinomios, trigonometría y logaritmos",
        ToolCategory.SCIENCE,
        Icons.Rounded.ShowChart
    ),
    STATISTICS(
        "Estadística descriptiva",
        "Media, mediana, moda, cuartiles y desviación",
        ToolCategory.SCIENCE,
        Icons.Rounded.Analytics
    ),
    PHYSICS_CALCULATOR(
        "Calculadora de física",
        "Mecánica, densidad, presión y electricidad",
        ToolCategory.SCIENCE,
        Icons.Rounded.Speed
    ),
    PERIODIC_TABLE(
        "Tabla periódica",
        "Tabla interactiva, fichas, masas, grupos y períodos sin conexión",
        ToolCategory.SCIENCE,
        Icons.Rounded.Science
    ),
    CHEMISTRY_CALCULATOR(
        "Calculadora de química",
        "Masa molar, composición, gramos y moles",
        ToolCategory.SCIENCE,
        Icons.Rounded.Science
    ),
    NUMBER_SYSTEMS(
        "Sistemas numéricos",
        "Binario, octal, decimal y hexadecimal",
        ToolCategory.ACADEMIC,
        Icons.Rounded.Code
    ),
    CITATION_GENERATOR(
        "Generador de referencias",
        "APA 7, Vancouver, IEEE y MLA",
        ToolCategory.ACADEMIC,
        Icons.Rounded.MenuBook
    ),
    EXAM_BUILDER(
        "Exámenes y cuestionarios",
        "Alternativas, verdadero/falso, tiempo y revisión",
        ToolCategory.ACADEMIC,
        Icons.Rounded.School
    ),
    STUDY_PLANNER_PRO(
        "Planificador de estudio",
        "Pomodoro, horario, metas, asistencia y recordatorios",
        ToolCategory.ACADEMIC,
        Icons.Rounded.EventNote
    ),
    FINANCE_CALCULATOR(
        "Finanzas para estudiantes",
        "Interés, préstamos, cuotas y distribución de gastos",
        ToolCategory.ACADEMIC,
        Icons.Rounded.Calculate
    ),
    FLASHCARDS(
        "Flashcards y práctica",
        "Crea tarjetas, practica y guarda tu progreso local",
        ToolCategory.ACADEMIC,
        Icons.Rounded.Style
    ),
    ACADEMIC_PLANNER(
        "Agenda académica",
        "Tareas, cursos, fechas y seguimiento local",
        ToolCategory.ACADEMIC,
        Icons.Rounded.EventNote
    ),
    TEXT_TOOLKIT(
        "Herramientas de texto",
        "Limpia, ordena y transforma textos",
        ToolCategory.ACADEMIC,
        Icons.Rounded.TextFields
    ),

    CV_BUILDER(
        "Constructor de CV",
        "Plantillas, secciones, vista previa y exportación PDF",
        ToolCategory.WORK,
        Icons.Rounded.Description
    ),
    WORK_HOURS(
        "Horas de trabajo",
        "Calcula pago, horas extra y total por jornada o semana",
        ToolCategory.WORK,
        Icons.Rounded.Timer
    ),
    QUOTE_IGV(
        "Cotización e IGV",
        "Arma ítems, subtotal, IGV y total con resumen exportable",
        ToolCategory.WORK,
        Icons.Rounded.Calculate
    ),
    INCOME_EXPENSE_TRACKER(
        "Ingresos y gastos",
        "Registra movimientos, revisa el saldo y exporta un resumen",
        ToolCategory.WORK,
        Icons.Rounded.Analytics
    ),
    INVENTORY_BASIC(
        "Inventario básico",
        "Controla stock, costos, precios y alertas de mínimo",
        ToolCategory.WORK,
        Icons.Rounded.TableChart
    ),
    COMMISSION_MARGIN(
        "Comisiones y ganancias",
        "Calcula comisión, margen, utilidad y precio de venta",
        ToolCategory.WORK,
        Icons.Rounded.Percent
    ),
    WORK_CHECKLIST(
        "Checklist de trabajo",
        "Organiza actividades, áreas y tareas completadas",
        ToolCategory.WORK,
        Icons.Rounded.EventNote
    ),

    GEO_ADVENTURES(
        "Geo Aventuras",
        "20 niveles extremos, vidas rojas gratis y 15 vidas por partida",
        ToolCategory.GAME,
        Icons.Rounded.SportsEsports
    ),

    QR_TOOL(
        "QR y códigos de barras",
        "Genera, valida y lee QR, Code 128, EAN y UPC",
        ToolCategory.QUICK,
        Icons.Rounded.QrCode
    ),
    WORD_COUNTER(
        "Contador de palabras",
        "Palabras, párrafos, caracteres y tiempos de lectura",
        ToolCategory.QUICK,
        Icons.Rounded.Rule
    ),
    STOPWATCH_TIMER(
        "Cronómetro y temporizador",
        "Mide sesiones de estudio y descansos",
        ToolCategory.QUICK,
        Icons.Rounded.Timer
    )
}
