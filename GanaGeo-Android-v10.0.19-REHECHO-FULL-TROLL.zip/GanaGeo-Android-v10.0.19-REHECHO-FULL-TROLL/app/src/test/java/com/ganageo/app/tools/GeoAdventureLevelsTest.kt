package com.ganageo.app.tools

import java.util.ArrayDeque
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class GeoAdventureLevelsTest {
    private val levels get() = (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build)

    @Test
    fun createsTwentyConnectedAdventureLevelsWithoutMandatoryCollectibles() {
        assertEquals(20, levels.size)
        levels.forEachIndexed { index, level ->
            assertEquals(index + 1, level.number)
            assertTrue("Nivel ${level.number}: demasiado corto", level.width >= 6_800f)
            assertEquals("Nivel ${level.number}: no debe exigir cristales", 0, level.requiredCrystals)
            assertTrue("Nivel ${level.number}: quedaron cristales obligatorios", level.crystals.isEmpty())
            assertTrue("Nivel ${level.number}: faltan enemigos", level.enemies.isNotEmpty())
            val threatCount = level.hazards.size + level.enemies.size + level.fallingObjects.size +
                level.crushers.size + level.chasingHoles.size + level.fans.size + level.plantTraps.size
            assertTrue("Nivel ${level.number}: pocas amenazas jugables", threatCount >= 25)
            assertTrue("Nivel ${level.number}: par inválido", level.parSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS)
        }
    }

    @Test
    fun everyExitContinuesIntoTheNextLevelEntry() {
        levels.zipWithNext().forEach { (current, next) ->
            assertEquals(
                "La salida del nivel ${current.number} no conecta con la entrada del ${next.number}",
                current.exitConnection,
                next.entryConnection
            )
        }
        assertEquals("awakening", levels.first().entryConnection)
        assertEquals("adventure-end", levels.last().exitConnection)
    }

    @Test
    fun actsProgressFromDayToDepthsNightAndDesertDawn() {
        assertTrue(levels.slice(0..3).all { it.biome == AdventureBiome.FOREST_DAY })
        assertTrue(levels.slice(4..7).all { it.biome == AdventureBiome.FOREST_SUNSET })
        assertTrue(levels.slice(8..9).all { it.biome == AdventureBiome.UNDERGROUND })
        assertTrue(levels.slice(10..14).all { it.biome == AdventureBiome.CAVE_NIGHT })
        assertTrue(levels.slice(15..19).all { it.biome == AdventureBiome.DESERT_DAWN })
    }

    @Test
    fun terrainIsARealMazeWithFloorsCeilingsAndSideStructures() {
        levels.forEach { level ->
            val distinctHeights = level.platforms.map { it.y }.distinct()
            val verticalRange = distinctHeights.maxOrNull()!! - distinctHeights.minOrNull()!!
            val tallStructures = level.platforms.count { it.height >= 90f }
            val roofStructures = level.platforms.count { it.y <= 1f && it.height >= 90f }
            assertTrue("Nivel ${level.number}: muy pocas alturas", distinctHeights.size >= 6)
            assertTrue("Nivel ${level.number}: todavía se siente plano", verticalRange >= 180f)
            assertTrue("Nivel ${level.number}: faltan muros y bloques laterales", tallStructures >= 5)
            assertTrue("Nivel ${level.number}: falta estructura de laberinto superior/vertical", roofStructures >= 1 || level.conduits.size >= 2 || level.movingPlatforms.count { it.vertical } >= 2)
        }
    }

    @Test
    fun adjacentLevelsDoNotRepeatTheSameOpening() {
        fun openingSignature(level: AdventureLevel): String {
            val firstTerrain = level.platforms.sortedBy { it.x }.take(3)
                .joinToString("|") { "${it.y.toInt()}:${it.kind}" }
            return "${level.biome}:${level.entryKind}:${level.spawnY.toInt()}:$firstTerrain"
        }
        levels.zipWithNext().forEach { (current, next) ->
            assertTrue(
                "Los niveles ${current.number} y ${next.number} repiten el mismo inicio",
                openingSignature(current) != openingSignature(next)
            )
        }
        assertTrue("No debe repetirse pinchos + checkpoint falso al inicio", levels.all { level ->
            level.checkpoints.none { it.kind == CheckpointKind.DECOY && it.x < 600f }
        })
    }

    @Test
    fun spikesAreAttachedToRealFloorOrCeilingStructures() {
        levels.forEach { level ->
            level.hazards.forEach { hazard ->
                when (hazard.orientation) {
                    HazardOrientation.UP -> assertTrue("Nivel ${level.number}: pinchos de piso flotantes", level.platforms.any { platform ->
                        platform.x <= hazard.x + 3f && platform.x + platform.width >= hazard.x + hazard.width - 3f &&
                            abs(platform.y - (hazard.y + hazard.height)) <= 5f
                    })
                    HazardOrientation.DOWN -> assertTrue("Nivel ${level.number}: pinchos de techo sin techo", level.platforms.any { platform ->
                        platform.x <= hazard.x && platform.x + platform.width >= hazard.x + hazard.width &&
                            abs((platform.y + platform.height) - hazard.y) <= 5f
                    })
                    HazardOrientation.LEFT -> assertTrue("Nivel ${level.number}: pincho lateral izquierdo sin pared", level.platforms.any { platform ->
                        abs(platform.x - (hazard.x + hazard.width)) <= 8f &&
                            platform.y <= hazard.y + 3f && platform.y + platform.height >= hazard.y + hazard.height - 3f
                    })
                    HazardOrientation.RIGHT -> assertTrue("Nivel ${level.number}: pincho lateral derecho sin pared", level.platforms.any { platform ->
                        abs((platform.x + platform.width) - hazard.x) <= 8f &&
                            platform.y <= hazard.y + 3f && platform.y + platform.height >= hazard.y + hazard.height - 3f
                    })
                }
            }
        }
    }

    @Test
    fun keysOpenOnlyPurposefulLockedDoors() {
        val keyLevels = levels.filter { it.requiresKey }
        assertEquals(setOf(4, 9, 15, 18, 20), keyLevels.map { it.number }.toSet())
        keyLevels.forEach { level ->
            assertTrue("Nivel ${level.number}: puerta con llave sin llave", level.keys.isNotEmpty())
            assertEquals("Nivel ${level.number}: la llave debe abrir una puerta", LevelExitKind.DOOR, level.exitKind)
            level.keys.forEach { key ->
                assertTrue("Nivel ${level.number}: llave fuera del terreno", level.platforms.any { platform ->
                    key.x in platform.x..(platform.x + platform.width) && abs(key.y - (platform.y - 72f)) <= 1f
                })
            }
        }
    }

    @Test
    fun realCheckpointsStayPermanentAndSafe() {
        levels.forEach { level ->
            val real = level.checkpoints.filter { it.kind != CheckpointKind.DECOY }
            assertTrue("Nivel ${level.number}: faltan checkpoints reales", real.size >= 2)
            real.forEach { checkpoint ->
                assertTrue("Nivel ${level.number}: checkpoint sin plataforma sólida", level.platforms.any { platform ->
                    platform.kind == PlatformKind.SOLID &&
                        checkpoint.x in platform.x..(platform.x + platform.width) &&
                        abs(platform.y - (checkpoint.y + 85f)) < 0.1f
                })
                assertTrue("Nivel ${level.number}: checkpoint junto a peligro", level.hazards.none { hazard ->
                    abs((hazard.x + hazard.width / 2f) - checkpoint.x) < 85f
                })
                assertTrue("Nivel ${level.number}: checkpoint bajo objeto que cae", level.fallingObjects.none { falling ->
                    abs((falling.x + falling.size / 2f) - checkpoint.x) < 100f
                })
                assertTrue("Nivel ${level.number}: checkpoint junto a suelo que se abre", level.chasingHoles.none { hole ->
                    abs((hole.startX + hole.width / 2f) - checkpoint.x) < 150f
                })
                assertTrue("Nivel ${level.number}: checkpoint junto a planta trampa", level.plantTraps.none { plant ->
                    abs((plant.x + plant.width / 2f) - checkpoint.x) < 130f
                })
            }
        }
        assertTrue("Los checkpoints falsos deben usarse con moderación", levels.sumOf { level ->
            level.checkpoints.count { it.kind == CheckpointKind.DECOY }
        } <= 5)
    }

    @Test
    fun applesAreUnexpectedFastAndStillLearnable() {
        val falling = levels.flatMap { it.fallingObjects }
        val fruit = falling.filter { it.kind == FallingObjectKind.FRUIT }
        assertTrue(fruit.any { it.behavior == FallingBehavior.EXPLODE })
        assertTrue(fruit.any { it.behavior == FallingBehavior.CHASE })
        assertTrue(fruit.any { it.behavior == FallingBehavior.ROLL })
        assertTrue(fruit.any { it.treeFallsAfterTrap })
        assertTrue(fruit.filter { it.behavior == FallingBehavior.CHASE }.all {
            it.chaseDurationMs <= 4_800L && it.chaseMaxTravel <= 750f
        })
        assertTrue("Las manzanas explosivas deben reaccionar rápido", fruit.filter { it.behavior == FallingBehavior.EXPLODE }.all {
            it.explosionDelayMs in 180L..350L
        })
        val triggerModes = fruit.map { it.triggerMode }.toSet()
        assertTrue("Las trampas de árbol deben activarse de varias maneras", triggerModes.size >= 4)
        assertTrue("Debe haber árboles normales mezclados con árboles trampa", levels.filter {
            it.biome == AdventureBiome.FOREST_DAY || it.biome == AdventureBiome.FOREST_SUNSET
        }.all { it.trees.isNotEmpty() })
        assertTrue("Debe haber rocas que se convierten en camino", falling.any { it.becomesPlatform })
    }

    @Test
    fun surpriseSpikesEmergeOnceAndStayVisible() {
        val hidden = levels.flatMap { it.hazards }.filter { it.kind == HazardKind.HIDDEN_SPIKES }
        assertTrue("Deben existir pinchos sorpresa", hidden.isNotEmpty())
        assertTrue("Los pinchos sorpresa no deben esconderse y salir en bucle", hidden.all {
            it.cycleMs == 0L && !it.retractable
        })
        assertTrue("Debe haber distintos disparadores de pinchos sorpresa", hidden.map { it.triggerMode }.toSet().size >= 2)
    }

    @Test
    fun fallingWallsAreSmallerWarnedAndAestheticallyTemporary() {
        val crushers = levels.flatMap { it.crushers }
        val fallingWalls = crushers.filter { it.style == CrusherStyle.FALLING_WALL }
        assertTrue(fallingWalls.isNotEmpty())
        fallingWalls.forEach { wall ->
            assertTrue("Muro demasiado ancho", wall.width <= 170f)
            assertTrue("Muro sin aviso", wall.delayMs >= 300L)
            assertTrue("Muro permanente tras caer", wall.despawnAfterMs in 2_500L..3_500L)
        }
        crushers.filter { it.axis == CrusherAxis.HORIZONTAL }.forEach { wall ->
            assertTrue("Prensa horizontal demasiado larga", abs(wall.travel) <= 150f)
            assertTrue("Prensa horizontal demasiado rápida", wall.speed <= 300f)
            assertTrue("Prensa horizontal sin ventana", wall.reverseAfterMs >= 1_450L)
        }
    }

    @Test
    fun reactivePlatformFamiliesExistWithoutTimerOnlyFloors() {
        val allPlatforms = levels.flatMap { it.platforms }
        assertTrue(allPlatforms.any { it.kind == PlatformKind.FALLING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.PROXIMITY_DISAPPEARING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.REVEALING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.BOUNCE })
        assertTrue("No debe haber pisos que desaparezcan solo por reloj", allPlatforms.none {
            it.kind == PlatformKind.DISAPPEARING
        })
        assertTrue(allPlatforms.filter { it.kind == PlatformKind.PROXIMITY_DISAPPEARING }.all {
            it.delayMs >= 900L
        })
    }

    @Test
    fun everyLevelHasAnApproximateReachableRouteFromSpawnToExit() {
        levels.forEach { level ->
            // The route can deliberately depend on moving platforms, rocks that become bridges,
            // fallen trees and mechanisms. Include those dynamic surfaces in the route graph.
            val platforms = buildList {
                addAll(level.platforms)
                level.movingPlatforms.forEach { moving ->
                    if (moving.vertical) {
                        add(GamePlatform(moving.x, moving.y - moving.travel, moving.width, 26f))
                        add(GamePlatform(moving.x, moving.y, moving.width, 26f))
                        add(GamePlatform(moving.x, moving.y + moving.travel, moving.width, 26f))
                    } else {
                        add(GamePlatform(moving.x - moving.travel, moving.y, moving.width + moving.travel * 2f, 26f))
                    }
                }
                level.fallingObjects.filter { it.becomesPlatform }.forEach { falling ->
                    add(GamePlatform(falling.x, falling.targetY - falling.size, falling.size, 24f))
                }
                level.switches.forEach { sw ->
                    add(GamePlatform(sw.opensAtX, 520f, 235f, 26f))
                }
                level.fallingObjects.forEachIndexed { index, falling ->
                    if (falling.treeFallsAfterTrap && falling.kind == FallingObjectKind.FRUIT) {
                        val trunkLength = (falling.targetY - (falling.startY - 28f)).coerceAtLeast(180f)
                        val direction = if ((index + level.number) % 2 == 0) 1f else -1f
                        val base = falling.x + falling.size / 2f
                        val tip = base + direction * trunkLength
                        add(
                            GamePlatform(
                                minOf(base, tip) + 24f,
                                falling.targetY - 11f,
                                (abs(tip - base) - 48f).coerceAtLeast(120f),
                                22f
                            )
                        )
                    }
                }
            }

            fun platformIndicesNear(x: Float, feetY: Float): List<Int> = platforms.indices.filter { index ->
                val platform = platforms[index]
                x + 44f >= platform.x - 25f && x <= platform.x + platform.width + 25f &&
                    abs(platform.y - feetY) <= 105f
            }

            val startIndices = platformIndicesNear(level.spawnX, level.spawnY + 58f)
            assertTrue("Nivel ${level.number}: el inicio no está sobre terreno", startIndices.isNotEmpty())

            val reachable = startIndices.toMutableSet()
            val pending = ArrayDeque<Int>()
            startIndices.forEach(pending::add)

            while (pending.isNotEmpty()) {
                val currentIndex = pending.removeFirst()
                val current = platforms[currentIndex]
                for (candidateIndex in platforms.indices) {
                    if (candidateIndex in reachable) continue
                    val candidate = platforms[candidateIndex]
                    val horizontalGap = when {
                        candidate.x > current.x + current.width -> candidate.x - (current.x + current.width)
                        current.x > candidate.x + candidate.width -> current.x - (candidate.x + candidate.width)
                        else -> 0f
                    }
                    val upwardDistance = current.y - candidate.y
                    val downwardDistance = candidate.y - current.y
                    val allowedGap = when {
                        upwardDistance > 220f -> 285f
                        upwardDistance > 145f -> 350f
                        else -> 455f
                    }
                    if (horizontalGap <= allowedGap && upwardDistance <= 270f && downwardDistance <= 620f) {
                        reachable += candidateIndex
                        pending.add(candidateIndex)
                    }
                }

                level.conduits.filter { !it.arrivalOnly && !it.endsLevel }.forEach { conduit ->
                    val entranceNearCurrent = conduit.x + conduit.width >= current.x - 45f &&
                        conduit.x <= current.x + current.width + 45f &&
                        abs((conduit.y + conduit.height) - current.y) < 170f
                    if (!entranceNearCurrent) return@forEach
                    platformIndicesNear(conduit.targetX, conduit.targetY + 58f).forEach { candidateIndex ->
                        if (candidateIndex !in reachable) {
                            reachable += candidateIndex
                            pending.add(candidateIndex)
                        }
                    }
                }
            }

            val goalHasRoute = platforms.indices.any { index ->
                val platform = platforms[index]
                index in reachable && platform.x + platform.width >= level.goalX - 155f &&
                    abs(platform.y - (level.goalY + 135f)) < 300f
            }
            val conduitExitHasRoute = level.conduits.any { exit ->
                exit.endsLevel && platforms.indices.any { index ->
                    val platform = platforms[index]
                    index in reachable &&
                        exit.x + exit.width >= platform.x - 45f &&
                        exit.x <= platform.x + platform.width + 45f &&
                        abs((exit.y + exit.height) - platform.y) < 180f
                }
            }
            assertTrue("Nivel ${level.number}: no hay una ruta aproximada desde GEO hasta la salida", goalHasRoute || conduitExitHasRoute)
        }
    }

    @Test
    fun exitTypesStayVariedAcrossTheAdventure() {
        val exitTypes = levels.map { it.exitKind }.toSet()
        assertTrue(exitTypes.contains(LevelExitKind.ASCENT))
        assertTrue(exitTypes.contains(LevelExitKind.DESCENT))
        assertTrue(exitTypes.contains(LevelExitKind.DOOR))
        assertTrue(exitTypes.contains(LevelExitKind.CAVE))
        assertTrue(exitTypes.contains(LevelExitKind.TUNNEL))
        assertTrue(exitTypes.contains(LevelExitKind.BRIDGE))
        assertTrue(exitTypes.contains(LevelExitKind.LIFT))
        assertTrue(exitTypes.contains(LevelExitKind.RUIN_GATE))
        assertTrue(exitTypes.contains(LevelExitKind.SUMMIT))
    }

    @Test
    fun difficultyDoesNotDependMostlyOnSpikes() {
        levels.forEach { level ->
            val totalThreats = level.hazards.size + level.enemies.size + level.fallingObjects.size +
                level.crushers.size + level.chasingHoles.size + level.fans.size + level.plantTraps.size
            val spikes = level.hazards.count {
                it.kind == HazardKind.SPIKES || it.kind == HazardKind.HIDDEN_SPIKES || it.kind == HazardKind.CEILING_SPIKES
            }
            assertTrue("Nivel ${level.number}: demasiada dependencia de pinchos", totalThreats == 0 || spikes.toFloat() / totalThreats <= 0.30f)
        }
    }

    @Test
    fun everyLevelKeepsTensionAcrossTheWholeRoute() {
        levels.forEach { level ->
            val threatPositions = buildList {
                level.hazards.forEach { add(it.x + it.width / 2f) }
                level.enemies.forEach { add(it.x) }
                level.fallingObjects.forEach { add(it.x + it.size / 2f) }
                level.crushers.forEach { add(it.x + it.width / 2f) }
                level.chasingHoles.forEach { add(it.startX + it.width / 2f) }
                level.fans.forEach { add(it.x + it.width / 2f) }
                level.plantTraps.forEach { add(it.x + it.width / 2f) }
            }.sorted()
            assertTrue("Nivel ${level.number}: faltan amenazas", threatPositions.size >= 25)
            val structureCount = level.platforms.count { it.height >= 90f }
            assertTrue("Nivel ${level.number}: el recorrido sigue demasiado abierto", structureCount >= 5)
        }
    }


    @Test
    fun conduitsPlantsAndNewTrollFamiliesAreActuallyPresent() {
        val allConduits = levels.flatMap { it.conduits }
        val allPlants = levels.flatMap { it.plantTraps }
        val allFalling = levels.flatMap { it.fallingObjects }
        val allPlatforms = levels.flatMap { it.platforms }
        val allCrushers = levels.flatMap { it.crushers }

        assertTrue("Deben existir conductos internos entre zonas", allConduits.any { !it.arrivalOnly && !it.endsLevel })
        assertTrue("Deben existir conductos que conecten niveles", allConduits.any { it.endsLevel })
        assertTrue("Deben existir plantas trampa retráctiles", allPlants.isNotEmpty())
        assertTrue("Debe existir al menos una planta agresiva por proximidad", allPlants.any { it.proximityAggressive })
        assertTrue("Deben existir rocas perseguidoras limitadas", allFalling.any { it.kind == FallingObjectKind.ROCK && it.behavior == FallingBehavior.CHASE })
        assertTrue("Deben existir pisos que se hunden por proximidad", allPlatforms.any { it.kind == PlatformKind.PROXIMITY_DISAPPEARING })
        assertTrue("Deben existir puentes o plataformas que caen", allPlatforms.any { it.kind == PlatformKind.FALLING })
        assertTrue("Deben existir caminos que se revelan tras mecanismos", allPlatforms.any { it.kind == PlatformKind.REVEALING })
        assertTrue("Deben existir plataformas de rebote", allPlatforms.any { it.kind == PlatformKind.BOUNCE })
        assertTrue("Deben existir troncos/prensas integradas", allCrushers.any { it.style == CrusherStyle.LOG_PRESS })
        assertTrue("Deben existir muros o bloques de ruina temporales", allCrushers.any { it.style == CrusherStyle.FALLING_WALL || it.style == CrusherStyle.RUIN_BLOCK })
        assertTrue("Algunos enemigos deben activar mecanismos al ser derrotados", levels.flatMap { it.enemies }.any { it.onDefeatSwitchIndex != null })
    }

    @Test
    fun everyLevelStillUsesExactlyFifteenInternalLives() {
        levels.forEach { level ->
            assertEquals(15, GeoGameRules.attemptsForLevel(level.number))
        }
    }
}
