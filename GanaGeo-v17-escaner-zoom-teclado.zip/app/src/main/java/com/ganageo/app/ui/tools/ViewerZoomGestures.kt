package com.ganageo.app.ui.tools

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.runtime.MutableFloatState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs

/**
 * Gesto de zoom/pan compartido por los visores y el editor del escáner.
 *
 * Mantiene una única matriz visual durante y después del pellizco. Así no hay
 * "commit" de zoom al soltar, ni recálculo de la geometría, ni saltos de página.
 */
internal fun Modifier.viewerPinchZoomGestures(
    gestureKey: Any?,
    zoomState: MutableFloatState,
    panXState: MutableFloatState,
    panYState: MutableFloatState,
    minZoom: Float,
    maxZoom: Float,
    viewportWidthPx: Float,
    viewportHeightPx: Float,
    eventPass: PointerEventPass = PointerEventPass.Main,
    onTransformStarted: () -> Unit = {},
    onTransformFinished: () -> Unit = {}
): Modifier = pointerInput(
    gestureKey,
    minZoom,
    maxZoom,
    viewportWidthPx,
    viewportHeightPx,
    eventPass
) {
    fun clampPanX(value: Float, scale: Float): Float {
        val extra = (viewportWidthPx * (scale - 1f)).coerceAtLeast(0f)
        return if (extra <= 0.5f) 0f else value.coerceIn(-extra, 0f)
    }

    fun clampPanY(value: Float, scale: Float): Float {
        val extra = (viewportHeightPx * (scale - 1f)).coerceAtLeast(0f)
        return if (extra <= 0.5f) 0f else value.coerceIn(-extra, 0f)
    }

    awaitEachGesture {
        var hadTransform = false
        do {
            val event = awaitPointerEvent(eventPass)
            val pressed = event.changes.filter { it.pressed }
            if (pressed.size >= 2) {
                if (!hadTransform) {
                    hadTransform = true
                    onTransformStarted()
                }

                val centroidX = pressed.sumOf { it.position.x.toDouble() }.toFloat() / pressed.size
                val centroidY = pressed.sumOf { it.position.y.toDouble() }.toFloat() / pressed.size
                val oldZoom = zoomState.floatValue.coerceIn(minZoom, maxZoom)
                val requestedZoom = (oldZoom * event.calculateZoom()).coerceIn(minZoom, maxZoom)
                val actualFactor = requestedZoom / oldZoom.coerceAtLeast(0.001f)
                val drag = event.calculatePan()

                if (
                    abs(actualFactor - 1f) > 0.0001f ||
                    abs(drag.x) + abs(drag.y) > 0.01f
                ) {
                    val nextX = panXState.floatValue * actualFactor +
                        centroidX * (1f - actualFactor) + drag.x
                    val nextY = panYState.floatValue * actualFactor +
                        centroidY * (1f - actualFactor) + drag.y

                    zoomState.floatValue = requestedZoom
                    panXState.floatValue = clampPanX(nextX, requestedZoom)
                    panYState.floatValue = clampPanY(nextY, requestedZoom)
                }

                event.changes.forEach { it.consume() }
            }
        } while (event.changes.any { it.pressed })

        if (hadTransform) onTransformFinished()
    }
}

internal fun clampViewerPanX(value: Float, scale: Float, viewportWidthPx: Float): Float {
    val extra = (viewportWidthPx * (scale - 1f)).coerceAtLeast(0f)
    return if (extra <= 0.5f) 0f else value.coerceIn(-extra, 0f)
}

internal fun clampViewerPanY(value: Float, scale: Float, viewportHeightPx: Float): Float {
    val extra = (viewportHeightPx * (scale - 1f)).coerceAtLeast(0f)
    return if (extra <= 0.5f) 0f else value.coerceIn(-extra, 0f)
}
