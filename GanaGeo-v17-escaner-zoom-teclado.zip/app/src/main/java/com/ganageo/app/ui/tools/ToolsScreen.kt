package com.ganageo.app.ui.tools

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ganageo.app.BuildConfig
import com.ganageo.app.R
import com.ganageo.app.GanaGeoUiState
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolCategory
import com.ganageo.app.model.ToolId
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.flow.collect

private data class CategoryPalette(
    val container: Color,
    val accent: Color,
    val badge: Color
)

private data class ToolCategoryGroup(
    val category: ToolCategory,
    val tools: List<ToolId>
)

private val HomeToolCategories = listOf(
    ToolCategory.PDF,
    ToolCategory.WORK,
    ToolCategory.ACADEMIC,
    ToolCategory.MATH,
    ToolCategory.SCIENCE,
    ToolCategory.IMAGE,
    ToolCategory.VIEWERS,
    ToolCategory.QUICK
)

private val HomeTools = ToolId.entries.filter { it.category != ToolCategory.GAME }
private val HomeFreeToolsCount = HomeTools.count { it.creditCost == 0 }
private val HomePaidToolsCount = HomeTools.count { it.creditCost > 0 }

// Los visores manejan archivos pesados y no deben restaurar automaticamente su pantalla
// ni el documento abierto despues de cerrar/reabrir la aplicacion.
private val NonPersistentViewerTools = setOf(
    ToolId.PDF_VIEWER,
    ToolId.WORD_VIEWER,
    ToolId.EXCEL_VIEWER,
    ToolId.POWERPOINT_VIEWER
)
private val NonPersistentViewerToolNames = NonPersistentViewerTools.mapTo(mutableSetOf<String>()) { it.name }

// Herramientas PDF/Imagen con espacio de trabajo propio. Igual que los visores, al
// abrirlas ocupan toda la superficie de Gana Geo y ocultan la navegacion inferior.
// La logica interna de cada herramienta permanece independiente para poder
// perfeccionarlas una por una sin volver a tocar la navegacion global.
private val FullscreenWorkspaceTools = setOf(
    ToolId.TEXT_TO_PDF,
    ToolId.PDF_WATERMARK_SECURITY,
    ToolId.IMAGES_TO_PDF,
    ToolId.PDF_ORGANIZER,
    ToolId.PDF_TO_IMAGES,
    ToolId.SIGN_PDF,
    ToolId.IMAGE_BATCH_STUDIO,
    ToolId.COMPRESS_IMAGE,
    ToolId.RESIZE_IMAGE,
    ToolId.CONVERT_IMAGE,
    ToolId.CROP_ROTATE_IMAGE,
    ToolId.WATERMARK_IMAGE
)

private fun groupTools(tools: List<ToolId>): List<ToolCategoryGroup> =
    HomeToolCategories.mapNotNull { category ->
        tools.filter { it.category == category }
            .takeIf { it.isNotEmpty() }
            ?.let { ToolCategoryGroup(category, it) }
    }

private fun ToolCategory.palette(): CategoryPalette = when (this) {
    ToolCategory.MATH -> CategoryPalette(Color(0xFF102A48), Color(0xFF6EC1FF), Color(0xFF123B63))
    ToolCategory.VIEWERS -> CategoryPalette(Color(0xFF233244), Color(0xFFC5D9F1), Color(0xFF31455D))
    ToolCategory.PDF -> CategoryPalette(Color(0xFF401415), Color(0xFFFF7D7D), Color(0xFF5B1D1F))
    ToolCategory.IMAGE -> CategoryPalette(Color(0xFF402511), Color(0xFFFFB35A), Color(0xFF5A3517))
    ToolCategory.SCIENCE -> CategoryPalette(Color(0xFF113A3F), Color(0xFF74F1FF), Color(0xFF1B4F55))
    ToolCategory.ACADEMIC -> CategoryPalette(Color(0xFF2E184B), Color(0xFFC997FF), Color(0xFF43216C))
    ToolCategory.WORK -> CategoryPalette(Color(0xFF173825), Color(0xFF7CF3A6), Color(0xFF214B31))
    ToolCategory.GAME -> CategoryPalette(Color(0xFF102E45), NeonGreen, Color(0xFF1C425E))
    ToolCategory.QUICK -> CategoryPalette(Color(0xFF16343A), Color(0xFF6DE1D2), Color(0xFF1E4950))
}

@Composable
fun ToolsScreen(
    uiState: GanaGeoUiState,
    viewModel: GanaGeoViewModel,
    guestMode: Boolean = false,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val rememberedToolName = viewModel.rememberedToolName
    // La navegacion a una herramienta solo vive en el proceso actual. Los datos internos
    // de cada herramienta siguen usando PersistentToolSaveableState, pero Android no debe
    // reabrir automaticamente una herramienta despues de matar/recrear el proceso.
    // El ViewModel conserva la seleccion durante recreaciones normales de la Activity.
    var persistentSelectedToolName by remember {
        mutableStateOf(rememberedToolName?.takeUnless { it in NonPersistentViewerToolNames })
    }
    var sessionViewerToolName by remember {
        mutableStateOf(rememberedToolName?.takeIf { it in NonPersistentViewerToolNames })
    }
    // Si Android intenta restaurar un Bundle antiguo de V5 con un visor seleccionado,
    // se ignora antes de componer el visor.
    val safePersistentSelectedToolName =
        persistentSelectedToolName?.takeUnless { it in NonPersistentViewerToolNames }
    val selectedToolName = sessionViewerToolName ?: safePersistentSelectedToolName
    val selectedTool = selectedToolName?.let { name ->
        ToolId.entries.firstOrNull { it.name == name }
    }
    val snackbar = remember { SnackbarHostState() }
    var localMessage by remember { mutableStateOf<String?>(null) }
    var immersiveTool by remember { mutableStateOf(false) }
    val homeListState = rememberSaveable(saver = LazyListState.Saver) {
        LazyListState(viewModel.rememberedToolsScrollIndex, viewModel.rememberedToolsScrollOffset)
    }
    val dashboard = uiState.dashboard
    val realCredits = dashboard?.toolCredits?.availableCredits ?: 0
    val realRewardPoints = dashboard?.wallet?.internalPoints ?: 0
    val realProgress = dashboard?.toolCredits?.rewardProgress ?: 0
    val testCredits = if (BuildConfig.DEBUG) uiState.testToolBalance.availableCredits else 0
    val testRewardPoints = if (BuildConfig.DEBUG) uiState.testToolBalance.rewardPoints else 0
    val testProgress = if (BuildConfig.DEBUG) uiState.testToolBalance.rewardProgress else 0

    fun selectTool(name: String?) {
        val targetTool = name?.let { toolName -> ToolId.entries.firstOrNull { it.name == toolName } }
        if (targetTool?.let { it in FullscreenWorkspaceTools } == true) {
            immersiveTool = true
            onImmersiveChanged(true)
        } else if (name == null) {
            immersiveTool = false
            onImmersiveChanged(false)
        }

        if (name != null && name in NonPersistentViewerToolNames) {
            sessionViewerToolName = name
            persistentSelectedToolName = null
        } else {
            sessionViewerToolName = null
            persistentSelectedToolName = name
        }
        // Se conserva en ViewModel solo para sobrevivir recreaciones temporales de Activity
        // (por ejemplo al abrir el selector de archivos). No se escribe a disco.
        viewModel.rememberTool(name)
    }

    // Limpia una sola vez los estados de visor guardados por versiones anteriores.
    // Las demas herramientas conservan su PersistentToolSaveableState sin cambios.
    LaunchedEffect(Unit) {
        clearPersistentToolSaveableStates(context, NonPersistentViewerToolNames)
        if (persistentSelectedToolName?.let { it in NonPersistentViewerToolNames } == true) {
            persistentSelectedToolName = null
        }
    }

    BackHandler(enabled = selectedTool != null) {
        immersiveTool = false
        onImmersiveChanged(false)
        selectTool(null)
    }

    LaunchedEffect(homeListState) {
        snapshotFlow { homeListState.isScrollInProgress }
            .collect { scrolling ->
                if (!scrolling) {
                    viewModel.rememberToolsScroll(
                        homeListState.firstVisibleItemIndex,
                        homeListState.firstVisibleItemScrollOffset
                    )
                }
            }
    }

    DisposableEffect(homeListState, viewModel) {
        onDispose {
            viewModel.rememberToolsScroll(
                homeListState.firstVisibleItemIndex,
                homeListState.firstVisibleItemScrollOffset
            )
        }
    }

    LaunchedEffect(selectedToolName) {
        if (selectedToolName == null) viewModel.retryPendingToolCompletions()

        // Estas herramientas son workspaces completos: al entrar se comportan como
        // los visores y la barra inferior global desaparece. Al volver a Herramientas
        // se restaura inmediatamente.
        val fullscreenWorkspace = selectedTool?.let { it in FullscreenWorkspaceTools } == true
        if (fullscreenWorkspace) {
            immersiveTool = true
            onImmersiveChanged(true)
        } else if (selectedToolName == null) {
            immersiveTool = false
            onImmersiveChanged(false)
        }
    }

    LaunchedEffect(localMessage) {
        localMessage?.let {
            snackbar.showSnackbar(it)
            localMessage = null
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { padding ->
        Box(
            modifier = if (immersiveTool) Modifier.fillMaxSize()
            else Modifier.fillMaxSize().padding(padding)
        ) {
            if (selectedTool == null) {
                ToolsHome(
                    listState = homeListState,
                    guestMode = guestMode,
                    realCredits = realCredits,
                    realRewardPoints = realRewardPoints,
                    realProgress = realProgress,
                    testCredits = testCredits,
                    testRewardPoints = testRewardPoints,
                    testProgress = testProgress,
                    onOpen = { selectTool(it.name) },
                    onLocked = { localMessage = "Inicia sesión para desbloquear esta herramienta." },
                    onAddTestCredits = viewModel::addTestToolCredits
                )
            } else {
                ToolDestination(
                    tool = selectedTool,
                    viewModel = viewModel,
                    onBack = {
                        immersiveTool = false
                        onImmersiveChanged(false)
                        selectTool(null)
                    },
                    onMessage = { localMessage = it },
                    onImmersiveChanged = { enabled ->
                        immersiveTool = enabled
                        onImmersiveChanged(enabled)
                    },
                    guestMode = guestMode
                )
            }
        }
    }
}

@Composable
private fun ToolsHome(
    listState: LazyListState,
    guestMode: Boolean,
    realCredits: Long,
    realRewardPoints: Long,
    realProgress: Long,
    testCredits: Long,
    testRewardPoints: Long,
    testProgress: Long,
    onOpen: (ToolId) -> Unit,
    onLocked: () -> Unit,
    onAddTestCredits: (Long) -> Unit
) {
    var search by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf("Todas") }
    var showCreditDetails by rememberSaveable { mutableStateOf(false) }
    val normalizedSearch = remember(search) { search.trim().lowercase() }
    val filteredTools = remember(selectedCategory, normalizedSearch) {
        HomeTools.filter { tool ->
            val matchesCategory = selectedCategory == "Todas" || tool.category.name == selectedCategory
            val matchesSearch = normalizedSearch.isBlank() ||
                tool.title.lowercase().contains(normalizedSearch) ||
                tool.subtitle.lowercase().contains(normalizedSearch) ||
                tool.category.title.lowercase().contains(normalizedSearch)
            matchesCategory && matchesSearch
        }
    }
    val toolRows = remember(filteredTools) { filteredTools.chunked(2) }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "tools_header_compact", contentType = "header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Herramientas Geo",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        "${HomeTools.size} herramientas en un solo lugar",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Box(
                    modifier = Modifier
                        .background(NeonGreen.copy(alpha = 0.12f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    Text(
                        "${filteredTools.size} visibles",
                        color = NeonGreen,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item(key = "tools_search_compact", contentType = "search") {
            CompactSearchAndFilters(
                search = search,
                onSearchChange = { search = it.take(60) },
                selectedCategory = selectedCategory,
                categories = HomeToolCategories,
                onSelectCategory = { selectedCategory = it }
            )
        }

        item(key = "tools_geo_adventures", contentType = "promo") {
            GeoAdventurePromoCard(
                guestMode = guestMode,
                onClick = { onOpen(ToolId.GEO_ADVENTURES) }
            )
        }

        if (!guestMode) {
            item(key = "tools_credit_summary", contentType = "credit_summary") {
                CompactCreditSummary(
                    credits = realCredits,
                    rewards = realRewardPoints,
                    testCredits = testCredits,
                    testRewards = testRewardPoints,
                    expanded = showCreditDetails,
                    onToggle = { showCreditDetails = !showCreditDetails }
                )
            }

            if (showCreditDetails) {
                item(key = "tools_credit_details", contentType = "credit_details") {
                    CompactCreditDetails(
                        realProgress = realProgress,
                        testCredits = testCredits,
                        testRewardPoints = testRewardPoints,
                        testProgress = testProgress,
                        onAddTestCredits = onAddTestCredits
                    )
                }
            }
        }

        if (guestMode) {
            item(key = "tools_guest_banner", contentType = "guest_banner") {
                CompactGuestBanner()
            }
        }

        item(key = "tools_catalog_label", contentType = "section_title") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (selectedCategory == "Todas") "Todas las herramientas" else
                        HomeToolCategories.firstOrNull { it.name == selectedCategory }?.title ?: "Herramientas",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (search.isNotBlank() || selectedCategory != "Todas") {
                    Text(
                        "${filteredTools.size} resultado${if (filteredTools.size == 1) "" else "s"}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        if (filteredTools.isEmpty()) {
            item(key = "tools_empty", contentType = "empty") {
                EmptyToolsResultCard(
                    onReset = {
                        search = ""
                        selectedCategory = "Todas"
                    }
                )
            }
        } else {
            items(
                items = toolRows,
                key = { row -> row.joinToString(separator = "_") { it.name } },
                contentType = { "tool_grid_row" }
            ) { rowTools ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    rowTools.forEach { tool ->
                        val locked = guestMode && tool.creditCost > 0
                        CompactToolCard(
                            tool = tool,
                            locked = locked,
                            modifier = Modifier.weight(1f),
                            onClick = { if (locked) onLocked() else onOpen(tool) }
                        )
                    }
                    if (rowTools.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        item(key = "tools_footer_info", contentType = "info") {
            CompactFooterInfo(guestMode = guestMode)
        }
    }
}

@Composable
private fun CompactSearchAndFilters(
    search: String,
    onSearchChange: (String) -> Unit,
    selectedCategory: String,
    categories: List<ToolCategory>,
    onSelectCategory: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
            value = search,
            onValueChange = onSearchChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Buscar: PDF, CV, QR, matemáticas...") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            trailingIcon = {
                if (search.isNotBlank()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Limpiar")
                    }
                }
            },
            shape = RoundedCornerShape(18.dp)
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            item {
                FilterChip(
                    selected = selectedCategory == "Todas",
                    onClick = { onSelectCategory("Todas") },
                    label = { Text("Todas") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonGreen,
                        selectedLabelColor = DeepGreen
                    )
                )
            }
            items(categories, key = { it.name }) { category ->
                val palette = category.palette()
                FilterChip(
                    selected = selectedCategory == category.name,
                    onClick = { onSelectCategory(category.name) },
                    label = { Text(category.title) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = palette.container,
                        labelColor = MaterialTheme.colorScheme.onSurface,
                        selectedContainerColor = palette.accent,
                        selectedLabelColor = DeepGreen
                    )
                )
            }
        }
    }
}

@Composable
private fun CompactGuestBanner() {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Info, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                "Las gratuitas funcionan sin cuenta; las de créditos aparecen con candado.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CompactCreditSummary(
    credits: Long,
    rewards: Long,
    testCredits: Long,
    testRewards: Long,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    val showTestBalance = BuildConfig.DEBUG && (testCredits > 0 || testRewards > 0)
    val primaryBalance = when {
        showTestBalance && credits == 0L -> "$testCredits créditos de prueba"
        showTestBalance -> "$credits créditos reales"
        else -> "$credits créditos"
    }
    val secondaryBalance = when {
        showTestBalance && credits == 0L -> "$rewards Rewards reales · $testRewards de prueba"
        showTestBalance -> "$testCredits cr. de prueba · $rewards Rewards reales · $testRewards de prueba"
        else -> "$rewards Geo Rewards"
    }

    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onToggle),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(40.dp).background(NeonGreen.copy(alpha = 0.15f), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = NeonGreen)
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(primaryBalance, fontWeight = FontWeight.Bold)
                Text(
                    secondaryBalance,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Box(
                modifier = Modifier.background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 7.dp)
            ) {
                Text(
                    if (expanded) "Cerrar" else "Packs",
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun CompactCreditDetails(
    realProgress: Long,
    testCredits: Long,
    testRewardPoints: Long,
    testProgress: Long,
    onAddTestCredits: (Long) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Text("Packs de créditos", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                CompactPackCard(
                    title = "50 créditos",
                    price = "S/5",
                    reward = "Hasta 250 Rewards",
                    modifier = Modifier.weight(1f),
                    onClick = { if (BuildConfig.DEBUG) onAddTestCredits(50) }
                )
                CompactPackCard(
                    title = "100 créditos",
                    price = "S/10",
                    reward = "Hasta 500 Rewards",
                    modifier = Modifier.weight(1f),
                    onClick = { if (BuildConfig.DEBUG) onAddTestCredits(100) }
                )
            }
            Text(
                "Próximos 50 Rewards: $realProgress/10 créditos comprados usados",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
            if (BuildConfig.DEBUG) {
                Text(
                    "Prueba: $testCredits créditos · $testRewardPoints Rewards · progreso $testProgress/10",
                    color = Gold,
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "Modo de prueba: los packs agregan créditos simulados y no realizan cobros.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text(
                    "Las compras se mostrarán cuando los productos de Google Play estén configurados y verificados.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun CompactPackCard(
    title: String,
    price: String,
    reward: String,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(enabled = BuildConfig.DEBUG, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(15.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(6.dp))
                Text(price, color = NeonGreen, fontWeight = FontWeight.Black)
            }
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            Text(reward, color = Gold, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun compactCategoryLabel(category: ToolCategory): String = when (category) {
    ToolCategory.PDF -> "PDF"
    ToolCategory.WORK -> "Trabajo"
    ToolCategory.ACADEMIC -> "Estudio"
    ToolCategory.MATH -> "Matemática"
    ToolCategory.SCIENCE -> "Ciencia"
    ToolCategory.IMAGE -> "Imágenes"
    ToolCategory.VIEWERS -> "Visores"
    ToolCategory.QUICK -> "Rápidas"
    ToolCategory.GAME -> "Juego"
}

private fun toolPreviewRes(tool: ToolId): Int = when (tool) {
    ToolId.SCIENTIFIC_CALCULATOR -> R.drawable.tool_preview_scientific_calculator
    ToolId.UNIT_CONVERTER -> R.drawable.tool_preview_unit_converter
    ToolId.PERCENT_RULE -> R.drawable.tool_preview_percent_rule
    ToolId.GRADES_AVERAGES -> R.drawable.tool_preview_grades_averages
    ToolId.GEOMETRY -> R.drawable.tool_preview_geometry
    ToolId.PDF_VIEWER -> R.drawable.tool_preview_pdf_viewer
    ToolId.WORD_VIEWER -> R.drawable.tool_preview_word_viewer
    ToolId.EXCEL_VIEWER -> R.drawable.tool_preview_excel_viewer
    ToolId.POWERPOINT_VIEWER -> R.drawable.tool_preview_powerpoint_viewer
    ToolId.DOCUMENT_SCANNER -> R.drawable.tool_preview_document_scanner
    ToolId.TEXT_TO_PDF -> R.drawable.tool_preview_text_to_pdf
    ToolId.PDF_WATERMARK_SECURITY -> R.drawable.tool_preview_pdf_watermark_security
    ToolId.IMAGES_TO_PDF -> R.drawable.tool_preview_images_to_pdf
    ToolId.PDF_ORGANIZER -> R.drawable.tool_preview_pdf_organizer
    ToolId.PDF_TO_IMAGES -> R.drawable.tool_preview_pdf_to_images
    ToolId.SIGN_PDF -> R.drawable.tool_preview_sign_pdf
    ToolId.IMAGE_BATCH_STUDIO -> R.drawable.tool_preview_image_batch_studio
    ToolId.COMPRESS_IMAGE -> R.drawable.tool_preview_compress_image
    ToolId.RESIZE_IMAGE -> R.drawable.tool_preview_resize_image
    ToolId.CONVERT_IMAGE -> R.drawable.tool_preview_convert_image
    ToolId.CROP_ROTATE_IMAGE -> R.drawable.tool_preview_crop_rotate_image
    ToolId.WATERMARK_IMAGE -> R.drawable.tool_preview_watermark_image
    ToolId.ADVANCED_MATH -> R.drawable.tool_preview_advanced_math
    ToolId.EQUATION_SOLVER -> R.drawable.tool_preview_equation_solver
    ToolId.FUNCTION_GRAPHER -> R.drawable.tool_preview_function_grapher
    ToolId.STATISTICS -> R.drawable.tool_preview_statistics
    ToolId.PHYSICS_CALCULATOR -> R.drawable.tool_preview_physics_calculator
    ToolId.PERIODIC_TABLE -> R.drawable.tool_preview_periodic_table
    ToolId.CHEMISTRY_CALCULATOR -> R.drawable.tool_preview_chemistry_calculator
    ToolId.NUMBER_SYSTEMS -> R.drawable.tool_preview_number_systems
    ToolId.CITATION_GENERATOR -> R.drawable.tool_preview_citation_generator
    ToolId.EXAM_BUILDER -> R.drawable.tool_preview_exam_builder
    ToolId.STUDY_PLANNER_PRO -> R.drawable.tool_preview_study_planner_pro
    ToolId.FINANCE_CALCULATOR -> R.drawable.tool_preview_finance_calculator
    ToolId.FLASHCARDS -> R.drawable.tool_preview_flashcards
    ToolId.ACADEMIC_PLANNER -> R.drawable.tool_preview_academic_planner
    ToolId.TEXT_TOOLKIT -> R.drawable.tool_preview_text_toolkit
    ToolId.CV_BUILDER -> R.drawable.tool_preview_cv_builder
    ToolId.WORK_HOURS -> R.drawable.tool_preview_work_hours
    ToolId.QUOTE_IGV -> R.drawable.tool_preview_quote_igv
    ToolId.INCOME_EXPENSE_TRACKER -> R.drawable.tool_preview_income_expense_tracker
    ToolId.INVENTORY_BASIC -> R.drawable.tool_preview_inventory_basic
    ToolId.COMMISSION_MARGIN -> R.drawable.tool_preview_commission_margin
    ToolId.WORK_CHECKLIST -> R.drawable.tool_preview_work_checklist
    ToolId.QR_TOOL -> R.drawable.tool_preview_qr_tool
    ToolId.WORD_COUNTER -> R.drawable.tool_preview_word_counter
    ToolId.STOPWATCH_TIMER -> R.drawable.tool_preview_stopwatch_timer
    ToolId.GEO_ADVENTURES -> R.drawable.tool_preview_geo_adventures
}

@Composable
private fun CompactToolCard(
    tool: ToolId,
    locked: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    if (tool == ToolId.DOCUMENT_SCANNER || tool == ToolId.TEXT_TO_PDF) {
        DocumentPremiumToolCard(tool, locked, modifier, onClick)
        return
    }
    val palette = tool.category.palette()
    Card(
        modifier = modifier.height(246.dp).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (locked) palette.container.copy(alpha = 0.76f) else palette.container
        ),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(92.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                Image(
                    painter = painterResource(id = toolPreviewRes(tool)),
                    contentDescription = "Vista previa de ${tool.title}",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 8.dp, bottom = 8.dp)
                        .background(palette.badge.copy(alpha = 0.92f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                ) {
                    Text(
                        compactCategoryLabel(tool.category),
                        color = palette.accent,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (locked) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.58f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 6.dp, vertical = 5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.Lock,
                            contentDescription = null,
                            tint = Gold,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
            Column(modifier = Modifier.weight(1f).padding(top = 11.dp)) {
                Text(
                    tool.title,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    tool.subtitle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (locked) "Requiere cuenta" else if (tool.creditCost > 0) "${tool.creditCost} créditos" else "Gratis",
                    color = if (tool.creditCost > 0 || locked) Gold else palette.accent,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                Icon(
                    if (locked || tool.creditCost > 0) Icons.Rounded.Lock else Icons.Rounded.ArrowForward,
                    contentDescription = null,
                    tint = if (locked || tool.creditCost > 0) Gold else palette.accent,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun DocumentPremiumToolCard(
    tool: ToolId,
    locked: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val scanner = tool == ToolId.DOCUMENT_SCANNER
    val subtitle = if (scanner) {
        "Escanea, extrae texto y limpia documentos"
    } else {
        "Abre y edita PDF, Word, Excel y PowerPoint"
    }
    Card(
        modifier = modifier.height(246.dp).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF4A111C)),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(92.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                Image(
                    painter = painterResource(id = toolPreviewRes(tool)),
                    contentDescription = "Vista previa de ${tool.title}",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 8.dp, bottom = 8.dp)
                        .background(Color(0x8E6C1C2C), RoundedCornerShape(10.dp))
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                ) {
                    Text(
                        "PDF",
                        color = Color(0xFFFFA7B7),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (locked) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.58f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 6.dp, vertical = 5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.Lock,
                            contentDescription = null,
                            tint = Gold,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
            Column(modifier = Modifier.weight(1f).padding(top = 11.dp)) {
                Text(
                    tool.title,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    subtitle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("5 créditos", color = Gold, fontWeight = FontWeight.Black)
                Icon(Icons.Rounded.Lock, contentDescription = null, tint = Gold)
            }
        }
    }
}


@Composable
private fun CompactFooterInfo(guestMode: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.035f)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Text(
            if (guestMode) {
                "Tu progreso de invitado y Geo Aventuras se guardan en este dispositivo."
            } else {
                "Las gratuitas no generan Rewards. Las de créditos descuentan al iniciar y confirman Rewards al completar la operación."
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun GeoAdventurePromoCard(guestMode: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF102E45)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.tool_preview_geo_adventures),
                contentDescription = "Vista previa de Geo Aventuras",
                modifier = Modifier
                    .size(width = 84.dp, height = 46.dp)
                    .clip(RoundedCornerShape(14.dp)),
                contentScale = ContentScale.Crop
            )
            Column(Modifier.weight(1f)) {
                Text("Geo Aventuras", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    if (guestMode) "20 niveles · modo invitado" else "20 niveles extremos · toca para jugar",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Icon(Icons.Rounded.ArrowForward, contentDescription = null, tint = NeonGreen)
        }
    }
}

@Composable
private fun ToolAccessSectionHeader(title: String, subtitle: String, locked: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (locked) Gold.copy(alpha = 0.10f) else NeonGreen.copy(alpha = 0.10f),
                RoundedCornerShape(18.dp)
            )
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            if (locked) Icons.Rounded.Lock else Icons.Rounded.CheckCircle,
            contentDescription = null,
            tint = if (locked) Gold else NeonGreen
        )
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CategoryHeaderCard(category: ToolCategory, total: Int) {
    val palette = category.palette()
    Card(
        colors = CardDefaults.cardColors(containerColor = palette.container),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(category.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(category.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box(
                modifier = Modifier.background(palette.badge, RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("$total", color = palette.accent, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun EmptyToolsResultCard(onReset: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2C1B1D)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("No encontramos herramientas con ese filtro", fontWeight = FontWeight.Bold)
            Text(
                "Prueba con otra palabra o vuelve a mostrar todas las categorías.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = onReset,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
                Text("Mostrar todo", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun CreditHero(
    realCredits: Long,
    realRewardPoints: Long,
    testCredits: Long,
    testRewardPoints: Long,
    realProgress: Long,
    testProgress: Long,
    freeToolsCount: Int,
    paidToolsCount: Int
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = NeonGreen)
                Spacer(Modifier.width(8.dp))
                Text("Créditos para herramientas", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallInfo("Créditos disponibles", realCredits.toString(), Icons.Rounded.CheckCircle, Modifier.weight(1f))
                SmallInfo("Geo Rewards", realRewardPoints.toString(), Icons.Rounded.CheckCircle, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallInfo("Gratis", freeToolsCount.toString(), Icons.Rounded.Info, Modifier.weight(1f))
                SmallInfo("Con créditos", paidToolsCount.toString(), Icons.Rounded.Lock, Modifier.weight(1f))
            }
            Text(
                "Progreso para los próximos 50 Rewards: $realProgress/10 créditos comprados usados",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium
            )
            if (BuildConfig.DEBUG) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SmallInfo("Créditos de prueba", testCredits.toString(), Icons.Rounded.Info, Modifier.weight(1f))
                    SmallInfo("Rewards de prueba", testRewardPoints.toString(), Icons.Rounded.Info, Modifier.weight(1f))
                }
                Text(
                    "Progreso de prueba: $testProgress/10",
                    color = Gold,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun SmallInfo(label: String, value: String, icon: ImageVector, modifier: Modifier) {
    Row(
        modifier = modifier
            .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(7.dp))
        Column {
            Text(value, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PackCard(
    title: String,
    price: String,
    credits: String,
    reward: String,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(enabled = BuildConfig.DEBUG, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = NeonGreen)
            Spacer(Modifier.height(6.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(price, color = NeonGreen, style = MaterialTheme.typography.titleLarge)
            Text(credits, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(reward, color = Gold, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                if (BuildConfig.DEBUG) "Agregar para probar" else "Google Play",
                color = if (BuildConfig.DEBUG) NeonGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun ToolCard(tool: ToolId, locked: Boolean = false, onClick: () -> Unit) {
    val palette = tool.category.palette()
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (locked) palette.container.copy(alpha = 0.84f) else palette.container
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(palette.badge, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(tool.icon, contentDescription = null, tint = palette.accent)
            }
            Spacer(Modifier.width(13.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(tool.title, fontWeight = FontWeight.Bold)
                Text(tool.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Text(
                    tool.category.title,
                    color = palette.accent,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (locked || tool.creditCost > 0) {
                Column(horizontalAlignment = Alignment.End) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = Gold, modifier = Modifier.size(18.dp))
                    Text(if (locked) "Bloqueada" else "${tool.creditCost} cr.", color = Gold, fontWeight = FontWeight.Bold)
                }
            } else {
                Text("Gratis", color = palette.accent, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun InfoBanner(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.10f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Rounded.Info, contentDescription = null, tint = Gold)
            Spacer(Modifier.width(10.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun ToolHeader(title: String, subtitle: String, onBack: () -> Unit) {
    val accent = when {
        title.contains("PDF", ignoreCase = true) || title.contains("document", ignoreCase = true) || title.contains("Word", ignoreCase = true) -> Color(0xFFFF7D7D)
        title.contains("matem", ignoreCase = true) || title.contains("calcul", ignoreCase = true) || title.contains("ecuaci", ignoreCase = true) || title.contains("funci", ignoreCase = true) || title.contains("geometr", ignoreCase = true) || title.contains("estad", ignoreCase = true) -> Color(0xFF6EC1FF)
        title.contains("imagen", ignoreCase = true) || title.contains("foto", ignoreCase = true) || title.contains("escáner", ignoreCase = true) -> Color(0xFFFFB35A)
        title.contains("estudio", ignoreCase = true) || title.contains("acad", ignoreCase = true) || title.contains("flash", ignoreCase = true) || title.contains("referenc", ignoreCase = true) || title.contains("examen", ignoreCase = true) -> Color(0xFFC997FF)
        title.contains("trabajo", ignoreCase = true) || title.contains("CV", ignoreCase = true) || title.contains("inventario", ignoreCase = true) || title.contains("cotiz", ignoreCase = true) || title.contains("ingresos", ignoreCase = true) || title.contains("comision", ignoreCase = true) -> Color(0xFF7CF3A6)
        title.contains("química", ignoreCase = true) || title.contains("física", ignoreCase = true) || title.contains("periódica", ignoreCase = true) -> Color(0xFF74F1FF)
        else -> NeonGreen
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 12.dp, end = 12.dp, top = 2.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = accent)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .size(46.dp)
                .background(accent.copy(alpha = 0.16f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                title.trim().firstOrNull()?.uppercase() ?: "G",
                color = accent,
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.titleLarge
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                subtitle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}


@Composable
private fun ToolDestination(
    tool: ToolId,
    viewModel: GanaGeoViewModel,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit,
    guestMode: Boolean
) {
    if (guestMode && tool.creditCost > 0) {
        LaunchedEffect(tool) { onMessage("Inicia sesión para usar esta función."); onBack() }
        return
    }

    // Geo Aventuras conserva su estado y lógica propios; no se modifica aquí.
    if (tool == ToolId.GEO_ADVENTURES) {
        GeoAdventuresScreen(viewModel, onBack, onMessage, onImmersiveChanged, guestMode)
        return
    }

    // PDF/Word/Excel/PowerPoint son visores pesados: no participan en la persistencia
    // automatica de herramientas. Al reiniciar la app siempre empiezan sin archivo.
    if (tool in NonPersistentViewerTools) {
        when (tool) {
            ToolId.PDF_VIEWER -> PdfViewerScreen(tool, onBack, onMessage, onImmersiveChanged)
            ToolId.WORD_VIEWER -> OfficeViewerScreen(tool, OfficeViewerType.WORD, onBack, onMessage, onImmersiveChanged)
            ToolId.EXCEL_VIEWER -> OfficeViewerScreen(tool, OfficeViewerType.EXCEL, onBack, onMessage, onImmersiveChanged)
            ToolId.POWERPOINT_VIEWER -> OfficeViewerScreen(tool, OfficeViewerType.POWERPOINT, onBack, onMessage, onImmersiveChanged)
            else -> Unit
        }
        return
    }

    PersistentToolSaveableState(tool.name) {
        when (tool) {
            ToolId.SCIENTIFIC_CALCULATOR -> ScientificCalculatorScreen(onBack)
            ToolId.UNIT_CONVERTER -> UnitConverterScreen(onBack)
            ToolId.PERCENT_RULE -> PercentRuleScreen(onBack)
            ToolId.GRADES_AVERAGES -> GradesAverageScreen(onBack)
            ToolId.GEOMETRY -> GeometryScreen(onBack)
            ToolId.ADVANCED_MATH -> AdvancedMathScreen(onBack)
            ToolId.EQUATION_SOLVER -> EquationSolverScreen(onBack)
            ToolId.FUNCTION_GRAPHER -> FunctionGrapherScreen(onBack)
            ToolId.STATISTICS -> StatisticsScreen(onBack)
            ToolId.PHYSICS_CALCULATOR -> PhysicsCalculatorScreen(onBack)
            ToolId.PERIODIC_TABLE -> PeriodicTableScreen(onBack)
            ToolId.CHEMISTRY_CALCULATOR -> ChemistryCalculatorScreen(onBack)
            ToolId.NUMBER_SYSTEMS -> NumberSystemsScreen(onBack)
            ToolId.CITATION_GENERATOR -> CitationGeneratorScreen(onBack)
            ToolId.EXAM_BUILDER -> ExamBuilderScreen(onBack, onMessage)
            ToolId.STUDY_PLANNER_PRO -> StudyPlannerProScreen(onBack, onMessage)
            ToolId.FINANCE_CALCULATOR -> StudentFinanceScreen(onBack)
            ToolId.FLASHCARDS -> FlashcardsScreen(onBack)
            ToolId.ACADEMIC_PLANNER -> AcademicPlannerScreen(onBack)
            ToolId.TEXT_TOOLKIT -> TextToolkitScreen(onBack)
            ToolId.CV_BUILDER -> CvBuilderScreen(onBack)
            ToolId.WORK_HOURS -> WorkHoursScreen(onBack)
            ToolId.QUOTE_IGV -> QuoteIgvScreen(onBack)
            ToolId.INCOME_EXPENSE_TRACKER -> IncomeExpenseTrackerScreen(onBack)
            ToolId.INVENTORY_BASIC -> InventoryBasicScreen(onBack)
            ToolId.COMMISSION_MARGIN -> CommissionMarginScreen(onBack)
            ToolId.WORK_CHECKLIST -> WorkChecklistScreen(onBack)
            ToolId.DOCUMENT_SCANNER -> DocumentScannerScreen(viewModel, tool, onBack, onMessage)
            ToolId.TEXT_TO_PDF -> TextToPdfScreen(viewModel, tool, onBack, onMessage)
            ToolId.PDF_WATERMARK_SECURITY -> PdfWatermarkSecurityScreen(viewModel, tool, onBack, onMessage)
            ToolId.IMAGES_TO_PDF -> ImagesToPdfScreen(viewModel, tool, onBack, onMessage)
            ToolId.PDF_ORGANIZER -> PdfOrganizerScreen(viewModel, tool, onBack, onMessage)
            ToolId.PDF_TO_IMAGES -> PdfToImagesScreen(viewModel, tool, onBack, onMessage)
            ToolId.SIGN_PDF -> SignPdfScreen(viewModel, tool, onBack, onMessage)
            ToolId.IMAGE_BATCH_STUDIO -> ImageBatchStudioScreen(viewModel, tool, onBack, onMessage)
            ToolId.COMPRESS_IMAGE,
            ToolId.RESIZE_IMAGE,
            ToolId.CONVERT_IMAGE,
            ToolId.CROP_ROTATE_IMAGE,
            ToolId.WATERMARK_IMAGE -> ImageToolScreen(viewModel, tool, onBack, onMessage)
            ToolId.QR_TOOL -> QrToolScreen(onBack, onMessage)
            ToolId.WORD_COUNTER -> WordCounterScreen(onBack)
            ToolId.STOPWATCH_TIMER -> StopwatchTimerScreen(onBack)
            ToolId.PDF_VIEWER,
            ToolId.WORD_VIEWER,
            ToolId.EXCEL_VIEWER,
            ToolId.POWERPOINT_VIEWER,
            ToolId.GEO_ADVENTURES -> Unit
        }
    }
}
