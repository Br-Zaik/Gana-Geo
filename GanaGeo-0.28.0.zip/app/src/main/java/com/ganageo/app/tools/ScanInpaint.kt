package com.ganageo.app.tools

import kotlin.math.max
import kotlin.math.min

/**
 * Borra el texto de una foto dejando el fondo limpio, para poner encima el
 * texto de verdad (como hace Acrobat al "editar un escaneo").
 *
 * Cada caja de texto se rellena con los colores que tiene alrededor: de
 * izquierda a derecha y de arriba abajo, mezclados. Así el papel, las barras de
 * color y los fondos con degradado quedan parejos, sin manchas de letras.
 *
 * Trabaja sobre un arreglo de colores ARGB (sin Android) para poder probarlo.
 */
object ScanInpaint {
    private const val NONE = 0 // color "no encontrado" (transparente)
    private const val REACH = 12 // cuántos píxeles hacia afuera se busca color
    private const val SMOOTH = 3 // suavizado de las muestras (vecinos a cada lado)

    private fun alpha(c: Int) = (c ushr 24) and 0xFF
    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun rgb(r: Int, g: Int, b: Int): Int =
        -0x1000000 or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    /**
     * boxes: cajas [izquierda, arriba, derecha, abajo) en píxeles, ya con margen.
     * fallback: color de papel de cada caja, por si no hay nada alrededor.
     */
    fun erase(pixels: IntArray, width: Int, height: Int, boxes: List<IntArray>, fallback: IntArray) {
        if (width <= 0 || height <= 0 || pixels.size < width * height) return
        val mask = BooleanArray(width * height)
        val clipped = boxes.map { box ->
            val left = box[0].coerceIn(0, width)
            val top = box[1].coerceIn(0, height)
            val right = box[2].coerceIn(left, width)
            val bottom = box[3].coerceIn(top, height)
            intArrayOf(left, top, right, bottom)
        }
        for (box in clipped) {
            for (y in box[1] until box[3]) {
                java.util.Arrays.fill(mask, y * width + box[0], y * width + box[2], true)
            }
        }

        fun sample(x0: Int, y0: Int, dx: Int, dy: Int): Int {
            var r = 0
            var g = 0
            var b = 0
            var found = 0
            var x = x0
            var y = y0
            var steps = 0
            while (steps < REACH && found < 3 && x in 0 until width && y in 0 until height) {
                val offset = y * width + x
                if (!mask[offset]) {
                    val c = pixels[offset]
                    r += red(c)
                    g += green(c)
                    b += blue(c)
                    found++
                }
                x += dx
                y += dy
                steps++
            }
            return if (found == 0) NONE else rgb(r / found, g / found, b / found)
        }

        clipped.forEachIndexed { index, box ->
            val left = box[0]
            val top = box[1]
            val right = box[2]
            val bottom = box[3]
            val boxWidth = right - left
            val boxHeight = bottom - top
            if (boxWidth <= 0 || boxHeight <= 0) return@forEachIndexed
            val paper = fallback.getOrElse(index) { -1 }

            val leftSide = IntArray(boxHeight) { sample(left - 1, top + it, -1, 0) }
            val rightSide = IntArray(boxHeight) { sample(right, top + it, 1, 0) }
            val topSide = IntArray(boxWidth) { sample(left + it, top - 1, 0, -1) }
            val bottomSide = IntArray(boxWidth) { sample(left + it, bottom, 0, 1) }
            val leftSmooth = smooth(leftSide)
            val rightSmooth = smooth(rightSide)
            val topSmooth = smooth(topSide)
            val bottomSmooth = smooth(bottomSide)

            for (y in 0 until boxHeight) {
                val ty = (y + 0.5f) / boxHeight
                val l = leftSmooth[y]
                val r = rightSmooth[y]
                for (x in 0 until boxWidth) {
                    val tx = (x + 0.5f) / boxWidth
                    val horizontal = mix(l, r, tx)
                    val vertical = mix(topSmooth[x], bottomSmooth[x], ty)
                    val color = when {
                        horizontal != NONE && vertical != NONE -> mix(horizontal, vertical, 0.5f)
                        horizontal != NONE -> horizontal
                        vertical != NONE -> vertical
                        else -> paper
                    }
                    pixels[(top + y) * width + left + x] = color
                }
            }
        }
    }

    /** Mezcla dos colores; si falta uno, devuelve el otro. */
    private fun mix(a: Int, b: Int, t: Float): Int {
        if (a == NONE) return b
        if (b == NONE) return a
        val u = 1f - t
        return rgb(
            (red(a) * u + red(b) * t + 0.5f).toInt(),
            (green(a) * u + green(b) * t + 0.5f).toInt(),
            (blue(a) * u + blue(b) * t + 0.5f).toInt()
        )
    }

    /** Promedio con los vecinos (ignora los que no tienen color) para que no queden rayas. */
    private fun smooth(values: IntArray): IntArray {
        val result = IntArray(values.size)
        for (i in values.indices) {
            var r = 0
            var g = 0
            var b = 0
            var count = 0
            for (j in max(0, i - SMOOTH)..min(values.size - 1, i + SMOOTH)) {
                val c = values[j]
                if (alpha(c) == 0) continue
                r += red(c)
                g += green(c)
                b += blue(c)
                count++
            }
            result[i] = if (count == 0) NONE else rgb(r / count, g / count, b / count)
        }
        return result
    }
}
