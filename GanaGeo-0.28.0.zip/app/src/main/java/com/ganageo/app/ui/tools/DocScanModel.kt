package com.ganageo.app.ui.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.InkLook
import com.ganageo.app.tools.OcrLine
import com.ganageo.app.tools.OcrTextRefiner
import com.ganageo.app.tools.ScanInpaint
import com.ganageo.app.tools.ScanLook
import com.ganageo.app.tools.ScanRebuild
import com.ganageo.app.tools.ToolFileUtils
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.util.Matrix
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Escáner de documentos: reconstrucción de la hoja (como "editar un escaneo"
// en Acrobat).
//
// 1. Se lee el texto de la foto (lector de Google, en el celular).
// 2. Se BORRA todo ese texto de la foto: queda el fondo limpio, con sus fotos,
//    logos, barras de color y líneas.
// 3. Encima se escribe el texto de verdad, párrafo por párrafo, con su tamaño,
//    color, negrita y alineación. Ese texto se puede editar todo y, al cambiar
//    un párrafo, se vuelve a acomodar en su ancho.
// 4. El PDF guarda ese texto real (se puede seleccionar, copiar y editar) y el
//    Word sale con párrafos con formato.
// ---------------------------------------------------------------------------

/** Lado más largo con que se trabaja cada página (lectura, vista y guardado). */
internal const val DOC_SCAN_PAGE_EDGE = 2200
internal const val DOC_SCAN_THUMB_EDGE = 256
internal const val DOC_SCAN_MAX_PAGES = 20
internal const val DOC_SCAN_DOCX_MIME =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

private const val DOC_SCAN_DESCENDERS = "gjpqyQ,;()[]{}|"

internal const val DOC_SCAN_ALIGN_LEFT = OcrTextRefiner.ALIGN_LEFT
internal const val DOC_SCAN_ALIGN_CENTER = OcrTextRefiner.ALIGN_CENTER
internal const val DOC_SCAN_ALIGN_RIGHT = OcrTextRefiner.ALIGN_RIGHT
internal const val DOC_SCAN_ALIGN_JUSTIFY = OcrTextRefiner.ALIGN_JUSTIFY

/** Una página del documento: la foto tal como llegó. */
internal data class DocScanPage(val id: Int, val uri: Uri)

/** Renglón leído, en píxeles de la foto, con su aspecto. */
internal class DocScanLine(
    val id: Int,
    val text: String,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val background: Int,
    val ink: Int,
    val bold: Boolean
)

/** Párrafo: renglones seguidos del mismo estilo. Es lo que se toca y se edita. */
internal class DocScanBlock(
    val id: Int,
    val lines: List<DocScanLine>,
    val text: String,
    val align: Int,
    val ink: Int,
    val background: Int,
    val bold: Boolean,
    /** Hasta dónde puede crecer a la derecha un título de un solo renglón. */
    val maxRight: Float
) {
    val left: Float = lines.minOf { it.left }
    val top: Float = lines.minOf { it.top }
    val right: Float = lines.maxOf { it.right }
    val bottom: Float = lines.maxOf { it.bottom }
}

/** Resultado de leer una página (medidas en píxeles de la foto). */
internal class DocScanAnalysis(
    val width: Int,
    val height: Int,
    val lines: List<DocScanLine>,
    val blocks: List<DocScanBlock>,
    val failed: Boolean = false
)

/** Cambio hecho por la persona a un párrafo. */
internal data class DocScanBlockEdit(
    val text: String,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val align: Int,
    val scale: Float = 1f,
    val deleted: Boolean = false
)

internal fun DocScanBlock.originalEdit() = DocScanBlockEdit(text, bold, false, ink, align)

/** Texto nuevo agregado en la hoja. x = borde izquierdo, y = línea base (de 0 a 1). */
internal data class DocScanAddedText(
    val id: Int,
    val x: Float,
    val y: Float,
    val text: String,
    /** Tamaño de la letra como fracción del alto de la página. */
    val size: Float,
    val color: Int,
    val bold: Boolean = false,
    val italic: Boolean = false
)

/** Firma o imagen pegada. x, y = esquina de arriba a la izquierda; width = fracción del ancho. */
internal class DocScanSign(
    val id: Int,
    val x: Float,
    val y: Float,
    val width: Float,
    val bitmap: Bitmap
) {
    fun movedBy(dx: Float, dy: Float) =
        DocScanSign(id, (x + dx).coerceIn(-0.2f, 0.98f), (y + dy).coerceIn(-0.2f, 0.98f), width, bitmap)

    fun resizedBy(factor: Float) = DocScanSign(id, x, y, (width * factor).coerceIn(0.05f, 1f), bitmap)
}

/** Todo lo que se cambió en una página. */
internal data class DocScanPageEdits(
    val blocks: Map<Int, DocScanBlockEdit> = emptyMap(),
    val texts: List<DocScanAddedText> = emptyList(),
    val signs: List<DocScanSign> = emptyList()
) {
    val isEmpty: Boolean get() = blocks.isEmpty() && texts.isEmpty() && signs.isEmpty()
}

// ---------------------------------------------------------------------------
// Lectura
// ---------------------------------------------------------------------------

private suspend fun docScanRecognize(bitmap: Bitmap): Text = suspendCancellableCoroutine { continuation ->
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    val closed = java.util.concurrent.atomic.AtomicBoolean(false)
    fun closeRecognizer() {
        if (closed.compareAndSet(false, true)) recognizer.close()
    }
    val task = recognizer.process(InputImage.fromBitmap(bitmap, 0))
    task.addOnSuccessListener { result ->
        if (continuation.isActive) continuation.resume(result)
    }
    task.addOnFailureListener { error ->
        if (continuation.isActive) continuation.resumeWithException(error)
    }
    task.addOnCanceledListener {
        if (continuation.isActive) continuation.cancel()
    }
    task.addOnCompleteListener { closeRecognizer() }
    continuation.invokeOnCancellation { closeRecognizer() }
}

private fun docScanColorDistance(a: Int, b: Int): Int =
    abs(android.graphics.Color.red(a) - android.graphics.Color.red(b)) +
        abs(android.graphics.Color.green(a) - android.graphics.Color.green(b)) +
        abs(android.graphics.Color.blue(a) - android.graphics.Color.blue(b))

/** Lee el texto de la página, el aspecto de cada renglón y arma los párrafos. Todo en el celular. */
internal suspend fun docScanAnalyze(bitmap: Bitmap): DocScanAnalysis {
    val result = try {
        docScanRecognize(bitmap)
    } catch (cancelled: kotlinx.coroutines.CancellationException) {
        throw cancelled
    } catch (error: Throwable) {
        return DocScanAnalysis(bitmap.width, bitmap.height, emptyList(), emptyList(), failed = true)
    }
    return withContext(Dispatchers.Default) {
        val width = bitmap.width
        val height = bitmap.height
        val texts = ArrayList<String>()
        val boxes = ArrayList<android.graphics.Rect>()
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val raw = line.boundingBox ?: continue
                val text = OcrTextRefiner.fixLine(line.text).trim()
                // Sin letras ni números (manchas, íconos): no es texto.
                if (text.none { it.isLetterOrDigit() }) continue
                val box = android.graphics.Rect(raw)
                if (!box.intersect(0, 0, width, height) || box.width() < 2 || box.height() < 4) continue
                texts += text
                boxes += box
            }
        }
        val looks = ArrayList<InkLook>(boxes.size)
        for (box in boxes) {
            val pad = max(3, box.height() / 3)
            val left = max(0, box.left - pad)
            val top = max(0, box.top - pad)
            val right = min(width, box.right + pad)
            val bottom = min(height, box.bottom + pad)
            val zoneWidth = right - left
            val zoneHeight = bottom - top
            val look = runCatching {
                val pixels = IntArray(zoneWidth * zoneHeight)
                bitmap.getPixels(pixels, 0, zoneWidth, left, top, zoneWidth, zoneHeight)
                ScanLook.measure(
                    pixels,
                    zoneWidth,
                    zoneHeight,
                    box.left - left,
                    box.top - top,
                    box.right - left,
                    box.bottom - top
                )
            }.getOrElse { InkLook(android.graphics.Color.WHITE, android.graphics.Color.BLACK, 0f) }
            looks += look
        }
        val bold = ScanLook.boldFlags(
            FloatArray(boxes.size) { looks[it].stroke },
            FloatArray(boxes.size) { boxes[it].height().toFloat() }
        )
        val lines = boxes.mapIndexed { index, box ->
            DocScanLine(
                id = index,
                text = texts[index],
                left = box.left.toFloat(),
                top = box.top.toFloat(),
                right = box.right.toFloat(),
                bottom = box.bottom.toFloat(),
                background = looks[index].background,
                ink = looks[index].ink,
                bold = bold[index]
            )
        }
        DocScanAnalysis(width, height, lines, docScanBuildBlocks(lines, width))
    }
}

/** Junta los renglones en párrafos (orden de lectura, también en columnas). */
private fun docScanBuildBlocks(lines: List<DocScanLine>, width: Int): List<DocScanBlock> {
    if (lines.isEmpty()) return emptyList()
    val located = lines.map {
        OcrLine(it.text, it.left.roundToInt(), it.top.roundToInt(), it.right.roundToInt(), it.bottom.roundToInt())
    }
    val groups = runCatching {
        OcrTextRefiner.paragraphs(located, width) { a, b ->
            val first = lines[a]
            val second = lines[b]
            val firstHeight = first.bottom - first.top
            val secondHeight = second.bottom - second.top
            first.bold == second.bold &&
                abs(firstHeight - secondHeight) <= max(firstHeight, secondHeight) * 0.25f &&
                docScanColorDistance(first.ink, second.ink) < 120 &&
                docScanColorDistance(first.background, second.background) < 90
        }
    }.getOrElse { lines.indices.map { intArrayOf(it) } }

    val raw = groups.mapNotNull { group -> group.map { lines[it] }.takeIf { it.isNotEmpty() } }
    return raw.mapIndexed { index, members ->
        val align = if (members.size == 1) {
            val line = members.first()
            val center = (line.left + line.right) / 2f
            if (abs(center - width / 2f) < width * 0.025f && line.left > width * 0.12f) DOC_SCAN_ALIGN_CENTER else DOC_SCAN_ALIGN_LEFT
        } else {
            OcrTextRefiner.alignmentOf(members.map { located[it.id] }, width)
        }
        val left = members.minOf { it.left }
        val top = members.minOf { it.top }
        val right = members.maxOf { it.right }
        val bottom = members.maxOf { it.bottom }
        val lineHeight = bottom - top
        // Espacio libre a la derecha (para que un título editado pueda crecer).
        var limit = width * 0.98f
        if (members.size == 1) {
            for (other in raw) {
                if (other === members) continue
                val otherTop = other.minOf { it.top }
                val otherBottom = other.maxOf { it.bottom }
                val otherLeft = other.minOf { it.left }
                val overlap = min(bottom, otherBottom) - max(top, otherTop)
                if (overlap > lineHeight * 0.4f && otherLeft >= right - lineHeight * 0.2f) {
                    limit = min(limit, otherLeft - lineHeight * 0.3f)
                }
            }
        }
        DocScanBlock(
            id = index,
            lines = members,
            text = ScanRebuild.joinLines(members.map { it.text }),
            align = align,
            ink = members.first().ink,
            background = members.first().background,
            bold = members.count { it.bold } * 2 > members.size,
            maxRight = max(right, limit)
        )
    }
}

/**
 * Fondo limpio: la foto sin el texto leído (se rellena con el color de alrededor).
 * Quedan las fotos, logos, barras y líneas. Devuelve una imagen nueva.
 */
internal suspend fun docScanCleanPage(source: Bitmap, analysis: DocScanAnalysis): Bitmap = withContext(Dispatchers.Default) {
    val width = source.width
    val height = source.height
    val scaleX = width / analysis.width.coerceAtLeast(1).toFloat()
    val scaleY = height / analysis.height.coerceAtLeast(1).toFloat()
    val pixels = IntArray(width * height)
    source.getPixels(pixels, 0, width, 0, 0, width, height)
    val boxes = ArrayList<IntArray>(analysis.lines.size)
    val fallback = IntArray(analysis.lines.size)
    analysis.lines.forEachIndexed { index, line ->
        val lineHeight = (line.bottom - line.top) * scaleY
        val padX = max(2f, lineHeight * 0.12f)
        val padY = max(2f, lineHeight * 0.18f)
        boxes += intArrayOf(
            (line.left * scaleX - padX).toInt(),
            (line.top * scaleY - padY).toInt(),
            (line.right * scaleX + padX).toInt() + 1,
            (line.bottom * scaleY + padY).toInt() + 1
        )
        fallback[index] = line.background
    }
    ScanInpaint.erase(pixels, width, height, boxes, fallback)
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    output.setPixels(pixels, 0, width, 0, 0, width, height)
    output
}

// ---------------------------------------------------------------------------
// Filtros de imagen (se aplican al dibujar: no se copia la foto)
// ---------------------------------------------------------------------------

/** Matriz de color del filtro (la misma que usa Imágenes a PDF), o null si es el original. */
internal fun docScanFilterMatrix(filter: DocumentImageFilter): FloatArray? {
    if (filter == DocumentImageFilter.ORIGINAL) return null
    val contrast = when (filter) {
        DocumentImageFilter.DOCUMENT -> 1.28f
        DocumentImageFilter.ENHANCE -> 1.08f
        else -> 1f
    }
    val saturation = when (filter) {
        DocumentImageFilter.GRAYSCALE, DocumentImageFilter.DOCUMENT -> 0f
        DocumentImageFilter.ENHANCE -> 1.18f
        else -> 1f
    }
    val matrix = ColorMatrix()
    matrix.setSaturation(saturation)
    val translate = (-0.5f * contrast + 0.5f) * 255f
    matrix.postConcat(
        ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )
    return matrix.array.copyOf()
}

/** Aplica la matriz del filtro a un color (para que el texto combine con la foto filtrada). */
internal fun docScanFilterColor(color: Int, matrix: FloatArray?): Int {
    if (matrix == null) return color
    val r = android.graphics.Color.red(color).toFloat()
    val g = android.graphics.Color.green(color).toFloat()
    val b = android.graphics.Color.blue(color).toFloat()
    fun channel(row: Int): Int =
        (matrix[row * 5] * r + matrix[row * 5 + 1] * g + matrix[row * 5 + 2] * b + matrix[row * 5 + 3] * 255f + matrix[row * 5 + 4])
            .roundToInt().coerceIn(0, 255)
    return android.graphics.Color.rgb(channel(0), channel(1), channel(2))
}

// ---------------------------------------------------------------------------
// Armado del texto de la hoja (sirve igual para la pantalla, el PDF y la imagen)
// ---------------------------------------------------------------------------

private val docScanTypefaces = arrayOfNulls<Typeface>(8)

internal fun docScanTypeface(serif: Boolean, bold: Boolean, italic: Boolean): Typeface {
    val index = (if (serif) 4 else 0) + (if (bold) 2 else 0) + (if (italic) 1 else 0)
    docScanTypefaces[index]?.let { return it }
    val style = when {
        bold && italic -> Typeface.BOLD_ITALIC
        bold -> Typeface.BOLD
        italic -> Typeface.ITALIC
        else -> Typeface.NORMAL
    }
    val created = Typeface.create(if (serif) Typeface.SERIF else Typeface.SANS_SERIF, style)
    docScanTypefaces[index] = created
    return created
}

/** Un renglón de texto listo para dibujar. width = ancho final; justify = repartir palabras. */
internal class DocScanRun(
    val text: String,
    val x: Float,
    val baseline: Float,
    val size: Float,
    val scaleX: Float,
    val width: Float,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val justify: Boolean
)

/** Párrafo ya armado: dónde quedó y con qué formato (para tocarlo, copiarlo y el Word). */
internal class DocScanPlacedBlock(
    val id: Int,
    val rect: RectF,
    val text: String,
    val size: Float,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val align: Int,
    val background: Int,
    val deleted: Boolean
)

/** Hoja armada, en píxeles de la foto. */
internal class DocScanLayout(
    val width: Int,
    val height: Int,
    val runs: List<DocScanRun>,
    val blocks: List<DocScanPlacedBlock>
) {
    private val byId = blocks.associateBy { it.id }
    fun block(id: Int): DocScanPlacedBlock? = byId[id]
}

private fun docScanBaseline(line: DocScanLine, paint: Paint): Float {
    val lineHeight = (line.bottom - line.top).coerceAtLeast(1f)
    val hasDescender = line.text.any { it in DOC_SCAN_DESCENDERS }
    return if (hasDescender) line.bottom - paint.descent() * 0.8f else line.bottom - lineHeight * 0.04f
}

/**
 * Arma todo el texto de la hoja. Lo que no se cambió queda en el mismo lugar y
 * del mismo tamaño que en la foto. Un párrafo cambiado se vuelve a cortar en
 * renglones dentro de su ancho, con su alineación.
 */
internal fun docScanLayout(
    analysis: DocScanAnalysis,
    edits: Map<Int, DocScanBlockEdit>,
    serif: Boolean,
    paint: Paint = Paint(Paint.ANTI_ALIAS_FLAG)
): DocScanLayout {
    val runs = ArrayList<DocScanRun>()
    val placed = ArrayList<DocScanPlacedBlock>(analysis.blocks.size)
    paint.textScaleX = 1f
    for (block in analysis.blocks) {
        val lines = block.lines
        // Tamaño de letra del párrafo: el que hace que cada renglón ocupe su ancho
        // (se toma uno de los menores: los renglones justificados salen estirados).
        paint.typeface = docScanTypeface(serif, block.bold, false)
        paint.textSize = 100f
        val sizes = lines.map { line ->
            val lineHeight = (line.bottom - line.top).coerceAtLeast(1f)
            val natural = paint.measureText(line.text).coerceAtLeast(1f)
            (100f * (line.right - line.left) / natural).coerceIn(lineHeight * 0.55f, lineHeight * 1.4f)
        }
        val baseSize = if (sizes.size == 1) sizes.first() else ScanRebuild.quantile(sizes, 0.3f)
        val edit = edits[block.id]

        if (edit == null) {
            paint.textSize = baseSize
            lines.forEachIndexed { index, line ->
                val boxWidth = line.right - line.left
                val natural = paint.measureText(line.text).coerceAtLeast(1f)
                val lastLine = index == lines.lastIndex
                val justify = block.align == DOC_SCAN_ALIGN_JUSTIFY && !lastLine &&
                    line.text.contains(' ') && natural <= boxWidth
                val scaleX = if (justify) 1f else (boxWidth / natural).coerceIn(0.8f, 1.2f)
                val width = if (justify) boxWidth else natural * scaleX
                val x = when (block.align) {
                    DOC_SCAN_ALIGN_CENTER -> (line.left + line.right) / 2f - width / 2f
                    DOC_SCAN_ALIGN_RIGHT -> line.right - width
                    else -> line.left
                }
                runs += DocScanRun(
                    line.text, x, docScanBaseline(line, paint), baseSize, scaleX, width,
                    block.bold, false, block.ink, justify
                )
            }
            placed += DocScanPlacedBlock(
                block.id, RectF(block.left, block.top, block.right, block.bottom), block.text,
                baseSize, block.bold, false, block.ink, block.align, block.background, deleted = false
            )
            continue
        }

        val firstBaseline = docScanBaseline(lines.first(), paint.apply { textSize = baseSize })
        if (edit.deleted || edit.text.isBlank()) {
            placed += DocScanPlacedBlock(
                block.id, RectF(block.left, block.top, block.right, block.bottom), "",
                baseSize, edit.bold, edit.italic, edit.color, edit.align, block.background, deleted = true
            )
            continue
        }

        val size = baseSize * edit.scale.coerceIn(0.4f, 3f)
        val leading = if (lines.size >= 2) {
            val gaps = (1 until lines.size).map { lines[it].top - lines[it - 1].top }.filter { it > 0f }
            (if (gaps.isEmpty()) baseSize * 1.25f else ScanRebuild.quantile(gaps, 0.5f)) * size / baseSize
        } else {
            size * 1.25f
        }
        // Ancho del párrafo; un renglón solo puede crecer hasta el espacio libre.
        val pageMargin = analysis.width * 0.02f
        val (areaLeft, areaRight) = when {
            lines.size > 1 -> block.left to block.right
            edit.align == DOC_SCAN_ALIGN_CENTER -> {
                val center = (block.left + block.right) / 2f
                val half = max((block.right - block.left) / 2f, min(center - pageMargin, block.maxRight - center))
                (center - half) to (center + half)
            }
            edit.align == DOC_SCAN_ALIGN_RIGHT -> block.left to block.right
            else -> block.left to max(block.right, block.maxRight)
        }
        val areaWidth = (areaRight - areaLeft).coerceAtLeast(size)
        paint.typeface = docScanTypeface(serif, edit.bold, edit.italic)
        paint.textSize = size
        val wrapped = ArrayList<Pair<String, Boolean>>() // renglón, ¿cierra su párrafo?
        for (paragraph in edit.text.split('\n')) {
            val pieces = ScanRebuild.wrap(paragraph, areaWidth) { paint.measureText(it) }
            pieces.forEachIndexed { index, piece -> wrapped += piece to (index == pieces.lastIndex) }
        }
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        wrapped.forEachIndexed { index, (text, closes) ->
            val natural = paint.measureText(text)
            val justify = edit.align == DOC_SCAN_ALIGN_JUSTIFY && !closes && text.contains(' ')
            val width = if (justify) areaWidth else natural
            val x = when (edit.align) {
                DOC_SCAN_ALIGN_CENTER -> areaLeft + (areaWidth - width) / 2f
                DOC_SCAN_ALIGN_RIGHT -> areaRight - width
                else -> areaLeft
            }
            if (text.isNotEmpty()) {
                runs += DocScanRun(text, x, firstBaseline + index * leading, size, 1f, width, edit.bold, edit.italic, edit.color, justify)
            }
            minX = min(minX, x)
            maxX = max(maxX, x + width)
        }
        val rect = RectF(
            min(minX, block.left),
            min(block.top, firstBaseline + paint.ascent()),
            max(maxX, block.left + size),
            max(block.bottom, firstBaseline + (wrapped.size - 1) * leading + paint.descent())
        )
        placed += DocScanPlacedBlock(
            block.id, rect, edit.text, size, edit.bold, edit.italic, edit.color, edit.align, block.background, deleted = false
        )
    }
    paint.textScaleX = 1f
    return DocScanLayout(analysis.width, analysis.height, runs, placed)
}

/** Dibuja los renglones armados (en píxeles de la foto: el lienzo ya viene escalado). */
internal fun docScanDrawRuns(canvas: Canvas, runs: List<DocScanRun>, serif: Boolean, paint: Paint) {
    for (run in runs) {
        paint.typeface = docScanTypeface(serif, run.bold, run.italic)
        paint.textSize = run.size
        paint.textScaleX = run.scaleX
        paint.color = run.color
        if (!run.justify) {
            canvas.drawText(run.text, run.x, run.baseline, paint)
            continue
        }
        val words = run.text.split(' ').filter { it.isNotEmpty() }
        if (words.size < 2) {
            canvas.drawText(run.text, run.x, run.baseline, paint)
            continue
        }
        val widths = FloatArray(words.size) { paint.measureText(words[it]) }
        val gap = (run.width - widths.sum()) / (words.size - 1)
        var x = run.x
        for (index in words.indices) {
            canvas.drawText(words[index], x, run.baseline, paint)
            x += widths[index] + gap
        }
    }
    paint.textScaleX = 1f
}

/** Caja de un texto agregado. */
internal fun docScanAddedBounds(text: DocScanAddedText, width: Float, height: Float, serif: Boolean, paint: Paint): RectF {
    paint.textScaleX = 1f
    paint.typeface = docScanTypeface(serif, text.bold, text.italic)
    paint.textSize = (text.size * height).coerceAtLeast(2f)
    val textWidth = paint.measureText(text.text.ifEmpty { " " })
    val x = text.x * width
    val y = text.y * height
    return RectF(x, y + paint.ascent(), x + textWidth, y + paint.descent())
}

/** Caja de una firma. */
internal fun docScanSignRect(sign: DocScanSign, width: Float, height: Float): RectF {
    val signWidth = sign.width * width
    val ratio = sign.bitmap.height.toFloat() / sign.bitmap.width.coerceAtLeast(1)
    val left = sign.x * width
    val top = sign.y * height
    return RectF(left, top, left + signWidth, top + signWidth * ratio)
}

/** Textos agregados (con filtro de color) y firmas (sin filtro: quedan con su tinta). */
internal fun docScanDrawAdded(
    canvas: Canvas,
    width: Float,
    height: Float,
    edits: DocScanPageEdits,
    serif: Boolean,
    paint: Paint,
    drawSigns: Boolean = true
) {
    paint.textScaleX = 1f
    for (text in edits.texts) {
        if (text.text.isBlank()) continue
        paint.typeface = docScanTypeface(serif, text.bold, text.italic)
        paint.textSize = (text.size * height).coerceAtLeast(2f)
        paint.color = text.color
        canvas.drawText(text.text, text.x * width, text.y * height, paint)
    }
    if (!drawSigns) return
    val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    for (sign in edits.signs) {
        if (!sign.bitmap.isRecycled) canvas.drawBitmap(sign.bitmap, null, docScanSignRect(sign, width, height), imagePaint)
    }
}

/** Hoja completa en una imagen nueva: fondo limpio + filtro + texto + agregados. */
internal fun docScanRender(
    clean: Bitmap,
    layout: DocScanLayout,
    edits: DocScanPageEdits,
    serif: Boolean,
    filter: FloatArray?,
    withText: Boolean = true
): Bitmap {
    val width = clean.width
    val height = clean.height
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    canvas.drawColor(android.graphics.Color.WHITE)
    val colorFilter = filter?.let { ColorMatrixColorFilter(it) }
    canvas.drawBitmap(clean, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { this.colorFilter = colorFilter })
    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply { this.colorFilter = colorFilter }
    if (withText) {
        canvas.save()
        canvas.scale(width / layout.width.coerceAtLeast(1).toFloat(), height / layout.height.coerceAtLeast(1).toFloat())
        docScanDrawRuns(canvas, layout.runs, serif, textPaint)
        canvas.restore()
        docScanDrawAdded(canvas, width.toFloat(), height.toFloat(), edits, serif, textPaint)
    } else {
        // Para el PDF: solo las firmas van en la imagen; el texto va como texto real.
        docScanDrawAdded(canvas, width.toFloat(), height.toFloat(), edits.copy(texts = emptyList()), serif, textPaint)
    }
    return output
}

// ---------------------------------------------------------------------------
// Texto de la hoja (para copiar, compartir y Word)
// ---------------------------------------------------------------------------

/** Un párrafo para copiar o para el Word, en orden de lectura. */
internal class DocScanParagraph(
    val text: String,
    /** Tamaño de letra como fracción del ancho de la página. */
    val size: Float,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val align: Int,
    val background: Int
)

/** Párrafos de la página en orden de lectura, con los cambios y los textos agregados. */
internal fun docScanParagraphs(layout: DocScanLayout?, edits: DocScanPageEdits): List<DocScanParagraph> {
    if (layout == null) return emptyList()
    val width = layout.width.coerceAtLeast(1).toFloat()
    val height = layout.height.toFloat()
    val result = ArrayList<Pair<Float, DocScanParagraph>>()
    for (block in layout.blocks) {
        if (block.deleted || block.text.isBlank()) continue
        result += block.rect.top to DocScanParagraph(
            block.text, block.size / width, block.bold, block.italic, block.color, block.align, block.background
        )
    }
    // Los textos agregados van antes del primer párrafo que esté más abajo.
    for (added in edits.texts.sortedBy { it.y }) {
        if (added.text.isBlank()) continue
        val y = added.y * height
        val paragraph = DocScanParagraph(
            added.text, added.size * height / width, added.bold, added.italic, added.color,
            DOC_SCAN_ALIGN_LEFT, android.graphics.Color.WHITE
        )
        val at = result.indexOfFirst { it.first > y }
        if (at < 0) result += y to paragraph else result.add(at, y to paragraph)
    }
    return result.map { it.second }
}

internal fun docScanPageText(layout: DocScanLayout?, edits: DocScanPageEdits): String =
    docScanParagraphs(layout, edits).joinToString("\n\n") { it.text }

/** Lee y arma las páginas que falten (para Word y para copiar el texto de todas). */
internal suspend fun docScanEnsureAnalyses(
    context: Context,
    pages: List<DocScanPage>,
    known: Map<Int, DocScanAnalysis>
): Map<Int, DocScanAnalysis> {
    val result = HashMap(known)
    for (page in pages) {
        if (result[page.id] != null) continue
        val source = ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
        try {
            result[page.id] = docScanAnalyze(source)
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }
    return result
}

/** Texto de todas las páginas, separadas. */
internal fun docScanAllText(
    pages: List<DocScanPage>,
    analyses: Map<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    serif: Boolean
): String {
    fun pageText(page: DocScanPage): String {
        val pageEdits = edits[page.id] ?: DocScanPageEdits()
        val layout = analyses[page.id]?.let { docScanLayout(it, pageEdits.blocks, serif) }
        return docScanPageText(layout, pageEdits)
    }
    if (pages.size == 1) return pageText(pages.first())
    return pages.mapIndexed { index, page -> "— Página ${index + 1} —\n\n" + pageText(page) }.joinToString("\n\n")
}

// ---------------------------------------------------------------------------
// Guardado
// ---------------------------------------------------------------------------

/** Una página lista para guardar: fondo limpio, lectura y armado. */
private class DocScanPrepared(val clean: Bitmap, val analysis: DocScanAnalysis, val layout: DocScanLayout)

private suspend fun docScanPreparePage(
    context: Context,
    page: DocScanPage,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    serif: Boolean
): DocScanPrepared {
    val source = ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
    try {
        val read = analysis ?: docScanAnalyze(source)
        val clean = if (read.lines.isEmpty()) source.copy(Bitmap.Config.ARGB_8888, false) else docScanCleanPage(source, read)
        val layout = withContext(Dispatchers.Default) { docScanLayout(read, edits.blocks, serif) }
        return DocScanPrepared(clean, read, layout)
    } finally {
        if (!source.isRecycled) source.recycle()
    }
}

private fun docScanPdfFont(serif: Boolean, bold: Boolean, italic: Boolean): PDType1Font = when {
    serif && bold && italic -> PDType1Font.TIMES_BOLD_ITALIC
    serif && bold -> PDType1Font.TIMES_BOLD
    serif && italic -> PDType1Font.TIMES_ITALIC
    serif -> PDType1Font.TIMES_ROMAN
    bold && italic -> PDType1Font.HELVETICA_BOLD_OBLIQUE
    bold -> PDType1Font.HELVETICA_BOLD
    italic -> PDType1Font.HELVETICA_OBLIQUE
    else -> PDType1Font.HELVETICA
}

/**
 * PDF reconstruido: cada página es el fondo limpio (fotos, logos, barras) y
 * encima el texto REAL, visible, en su lugar, con su tamaño, color y negrita.
 * Se puede seleccionar, copiar, buscar y editar en cualquier lector de PDF.
 */
internal suspend fun docScanWritePdf(
    context: Context,
    output: OutputStream,
    pages: List<DocScanPage>,
    analyses: Map<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    serif: Boolean,
    filter: FloatArray?
) = withContext(Dispatchers.IO) {
    PDFBoxResourceLoader.init(context.applicationContext)
    val measure = Paint(Paint.ANTI_ALIAS_FLAG)
    PDDocument().use { document ->
        val encodable = HashMap<Pair<PDType1Font, Char>, Boolean>()
        fun clean(font: PDType1Font, text: String): String = buildString {
            for (char in text) {
                val ok = encodable.getOrPut(font to char) { runCatching { font.encode(char.toString()); true }.getOrDefault(false) }
                append(if (ok) char else ' ')
            }
        }

        for (page in pages) {
            val pageEdits = edits[page.id] ?: DocScanPageEdits()
            val prepared = docScanPreparePage(context, page, analyses[page.id], pageEdits, serif)
            val background = try {
                withContext(Dispatchers.Default) {
                    docScanRender(prepared.clean, prepared.layout, pageEdits, serif, filter, withText = false)
                }
            } finally {
                prepared.clean.recycle()
            }
            val imageWidth = background.width
            val imageHeight = background.height
            val bytes = try {
                ByteArrayOutputStream().also { background.compress(Bitmap.CompressFormat.JPEG, 86, it) }.toByteArray()
            } finally {
                background.recycle()
            }
            val ratio = imageWidth.toFloat() / imageHeight.coerceAtLeast(1)
            val pageWidth = if (ratio >= 1f) 842f else 842f * ratio
            val pageHeight = if (ratio >= 1f) 842f / ratio else 842f
            val pdfPage = PDPage(PDRectangle(pageWidth, pageHeight))
            document.addPage(pdfPage)
            val image = PDImageXObject.createFromByteArray(document, bytes, "pagina")

            // Todos los renglones (los leídos y los agregados) en píxeles de la foto.
            val layout = prepared.layout
            val runs = ArrayList(layout.runs)
            measure.textScaleX = 1f
            for (added in pageEdits.texts) {
                if (added.text.isBlank()) continue
                val size = added.size * layout.height
                measure.typeface = docScanTypeface(serif, added.bold, added.italic)
                measure.textSize = size
                runs += DocScanRun(
                    added.text, added.x * layout.width, added.y * layout.height, size, 1f,
                    measure.measureText(added.text), added.bold, added.italic, added.color, false
                )
            }
            val k = pageWidth / layout.width.coerceAtLeast(1)

            PDPageContentStream(document, pdfPage).use { stream ->
                stream.drawImage(image, 0f, 0f, pageWidth, pageHeight)
                for (run in runs) {
                    val font = docScanPdfFont(serif, run.bold, run.italic)
                    val color = docScanFilterColor(run.color, filter)
                    val pieces: List<Pair<String, Float>> // texto y su x (en píxeles de la foto)
                    val targets: List<Float> // ancho que debe ocupar cada pedazo
                    measure.typeface = docScanTypeface(serif, run.bold, run.italic)
                    measure.textSize = run.size
                    measure.textScaleX = run.scaleX
                    val words = run.text.split(' ').filter { it.isNotEmpty() }
                    if (run.justify && words.size >= 2) {
                        val widths = words.map { measure.measureText(it) }
                        val gap = (run.width - widths.sum()) / (words.size - 1)
                        var x = run.x
                        val list = ArrayList<Pair<String, Float>>()
                        for (index in words.indices) {
                            list += words[index] to x
                            x += widths[index] + gap
                        }
                        pieces = list
                        targets = widths
                    } else {
                        pieces = listOf(run.text to run.x)
                        targets = listOf(run.width)
                    }
                    val sizePt = run.size * k
                    if (sizePt < 0.5f) continue
                    pieces.forEachIndexed { index, (text, x) ->
                        val cleaned = clean(font, text)
                        if (cleaned.isBlank()) return@forEachIndexed
                        val units = runCatching { font.getStringWidth(cleaned) }.getOrDefault(0f)
                        if (units <= 0f) return@forEachIndexed
                        val pdfWidth = units / 1000f * sizePt
                        val stretch = (targets[index] * k / pdfWidth).coerceIn(0.5f, 2f)
                        runCatching {
                            stream.beginText()
                            stream.setFont(font, sizePt)
                            stream.setNonStrokingColor(
                                PDColor(
                                    floatArrayOf(
                                        android.graphics.Color.red(color) / 255f,
                                        android.graphics.Color.green(color) / 255f,
                                        android.graphics.Color.blue(color) / 255f
                                    ),
                                    PDDeviceRGB.INSTANCE
                                )
                            )
                            stream.setTextMatrix(Matrix(stretch, 0f, 0f, 1f, x * k, pageHeight - run.baseline * k))
                            stream.showText(cleaned)
                            stream.endText()
                        }
                    }
                }
            }
        }
        document.save(output)
    }
}

/** Imagen JPG de una página, igual a lo que se ve. */
internal suspend fun docScanWriteImage(
    context: Context,
    output: OutputStream,
    page: DocScanPage,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    serif: Boolean,
    filter: FloatArray?
) = withContext(Dispatchers.IO) {
    val prepared = docScanPreparePage(context, page, analysis, edits, serif)
    val rendered = try {
        withContext(Dispatchers.Default) { docScanRender(prepared.clean, prepared.layout, edits, serif, filter) }
    } finally {
        prepared.clean.recycle()
    }
    try {
        check(rendered.compress(Bitmap.CompressFormat.JPEG, 92, output)) { "No se pudo guardar la imagen" }
    } finally {
        rendered.recycle()
    }
}

private fun docScanXml(value: String): String = value
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")
    .filter { it == '\t' || it == '\n' || it >= ' ' }

private fun docScanZip(zip: ZipOutputStream, name: String, text: String) {
    zip.putNextEntry(ZipEntry(name))
    zip.write(text.toByteArray(Charsets.UTF_8))
    zip.closeEntry()
}

/**
 * Word (.docx) armado a mano, sin librerías: los párrafos de cada página en
 * orden, con su tamaño, negrita, cursiva, color, alineación y fondo de color
 * (por ejemplo, títulos en barras). Cada página empieza en una hoja nueva.
 */
internal fun docScanWriteDocx(output: OutputStream, pages: List<List<DocScanParagraph>>, serif: Boolean) {
    val font = if (serif) "Times New Roman" else "Arial"
    fun hex(color: Int): String = String.format(
        java.util.Locale.ROOT, "%02X%02X%02X",
        android.graphics.Color.red(color), android.graphics.Color.green(color), android.graphics.Color.blue(color)
    )
    fun light(color: Int): Boolean =
        android.graphics.Color.red(color) * 299 + android.graphics.Color.green(color) * 587 +
            android.graphics.Color.blue(color) * 114 > 160_000

    val body = StringBuilder()
    pages.forEachIndexed { pageIndex, paragraphs ->
        if (pageIndex > 0) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
        if (paragraphs.isEmpty()) body.append("<w:p/>")
        for (paragraph in paragraphs) {
            // Tamaño: proporcional al ancho de una hoja A4 (595 puntos).
            val halfPoints = (paragraph.size * 595f * 2f).roundToInt().coerceIn(14, 96)
            val shaded = !light(paragraph.background)
            val textColor = if (!shaded && light(paragraph.color)) android.graphics.Color.BLACK else paragraph.color
            val justify = when (paragraph.align) {
                DOC_SCAN_ALIGN_CENTER -> "center"
                DOC_SCAN_ALIGN_RIGHT -> "right"
                DOC_SCAN_ALIGN_JUSTIFY -> "both"
                else -> "left"
            }
            body.append("<w:p><w:pPr>")
            if (shaded) body.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(hex(paragraph.background)).append("\"/>")
            body.append("<w:spacing w:after=\"120\"/><w:jc w:val=\"").append(justify).append("\"/></w:pPr>")
            val runProperties = StringBuilder("<w:rPr><w:rFonts w:ascii=\"$font\" w:hAnsi=\"$font\" w:cs=\"$font\"/>")
            if (paragraph.bold) runProperties.append("<w:b/>")
            if (paragraph.italic) runProperties.append("<w:i/>")
            runProperties.append("<w:color w:val=\"").append(hex(textColor)).append("\"/>")
            runProperties.append("<w:sz w:val=\"$halfPoints\"/><w:szCs w:val=\"$halfPoints\"/></w:rPr>")
            paragraph.text.split('\n').forEachIndexed { lineIndex, line ->
                if (lineIndex > 0) body.append("<w:r><w:br/></w:r>")
                body.append("<w:r>").append(runProperties)
                body.append("<w:t xml:space=\"preserve\">").append(docScanXml(line)).append("</w:t></w:r>")
            }
            body.append("</w:p>")
        }
    }
    val documentXml =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
            "<w:body>" + body +
            "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
            "<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"709\" w:footer=\"709\" w:gutter=\"0\"/>" +
            "</w:sectPr></w:body></w:document>"
    val types =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"
    val rootRels =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"
    ZipOutputStream(output).use { zip ->
        docScanZip(zip, "[Content_Types].xml", types)
        docScanZip(zip, "_rels/.rels", rootRels)
        docScanZip(zip, "word/document.xml", documentXml)
    }
}

/**
 * Copia las páginas del escáner de Google a la carpeta temporal de la app.
 * El escáner borra sus archivos en el siguiente escaneo; con la copia no se pierden.
 */
internal suspend fun docScanCopyToCache(context: Context, sources: List<Uri>): List<Uri> = withContext(Dispatchers.IO) {
    val directory = java.io.File(context.cacheDir, "camera").apply { mkdirs() }
    val stamp = System.currentTimeMillis()
    val copied = ArrayList<Uri>()
    sources.forEachIndexed { index, source ->
        val target = java.io.File(directory, "docscan_${stamp}_${index + 1}.jpg")
        val ok = runCatching {
            context.contentResolver.openInputStream(source)?.use { input ->
                target.outputStream().use { out -> input.copyTo(out) }
            } != null
        }.getOrDefault(false)
        if (ok && target.length() > 0L) {
            copied += androidx.core.content.FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                target
            )
        }
    }
    copied
}

/** Borra las copias de escaneos viejos (de otras sesiones). */
internal suspend fun docScanCleanCache(context: Context, keep: Set<String>) = withContext(Dispatchers.IO) {
    val directory = java.io.File(context.cacheDir, "camera")
    directory.listFiles()?.forEach { file ->
        if (file.name.startsWith("docscan_") && file.name !in keep) runCatching { file.delete() }
    }
}
