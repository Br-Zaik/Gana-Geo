package com.ganageo.app.tools

/**
 * Piezas simples (sin Android) para rearmar un párrafo escaneado como texto de verdad:
 * unir los renglones leídos en un solo párrafo y volver a cortarlo en renglones
 * cuando la persona lo cambia.
 */
object ScanRebuild {
    private val hyphenEnd = Regex("[\\p{L}]-$")

    /**
     * Une los renglones de un párrafo. Si un renglón termina en palabra cortada
     * con guion ("explota-" + "ción"), la junta sin el guion.
     */
    fun joinLines(lines: List<String>): String {
        val result = StringBuilder()
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (result.isEmpty()) {
                result.append(line)
                continue
            }
            val cut = hyphenEnd.containsMatchIn(result) && line.first().isLowerCase()
            if (cut) {
                result.setLength(result.length - 1)
            } else {
                result.append(' ')
            }
            result.append(line)
        }
        return result.toString()
    }

    /**
     * Corta el texto en renglones que entren en [maxWidth]. Respeta los saltos de
     * línea que escribió la persona. Una palabra que no entra sola se parte por letras.
     */
    fun wrap(text: String, maxWidth: Float, measure: (String) -> Float): List<String> {
        val result = ArrayList<String>()
        if (maxWidth <= 0f) {
            result += text.split('\n')
            return result
        }
        for (paragraph in text.split('\n')) {
            val words = paragraph.split(' ').filter { it.isNotEmpty() }
            if (words.isEmpty()) {
                result += ""
                continue
            }
            val line = StringBuilder()
            for (word in words) {
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (measure(candidate) <= maxWidth) {
                    line.setLength(0)
                    line.append(candidate)
                    continue
                }
                if (line.isNotEmpty()) {
                    result += line.toString()
                    line.setLength(0)
                }
                if (measure(word) <= maxWidth) {
                    line.append(word)
                    continue
                }
                // Palabra más ancha que el renglón: se parte por letras.
                var piece = StringBuilder()
                for (char in word) {
                    if (piece.isNotEmpty() && measure(piece.toString() + char) > maxWidth) {
                        result += piece.toString()
                        piece = StringBuilder()
                    }
                    piece.append(char)
                }
                line.append(piece)
            }
            result += line.toString()
        }
        return result
    }

    /** Valor que deja fuera los extremos: el del puesto [fraction] (0 = menor, 1 = mayor). */
    fun quantile(values: List<Float>, fraction: Float): Float {
        if (values.isEmpty()) return 0f
        val sorted = values.sorted()
        val index = ((sorted.size - 1) * fraction.coerceIn(0f, 1f)).toInt()
        return sorted[index]
    }
}
