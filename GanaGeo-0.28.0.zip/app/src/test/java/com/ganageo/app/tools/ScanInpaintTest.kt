package com.ganageo.app.tools

import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ScanInpaintTest {
    private fun rgb(r: Int, g: Int, b: Int): Int = -0x1000000 or (r shl 16) or (g shl 8) or b
    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun close(a: Int, b: Int, tolerance: Int) =
        abs(red(a) - red(b)) <= tolerance && abs(green(a) - green(b)) <= tolerance && abs(blue(a) - blue(b)) <= tolerance

    @Test
    fun borraLetrasNegrasSobreBarraAzul() {
        val width = 80
        val height = 30
        val blue = rgb(20, 60, 140)
        val pixels = IntArray(width * height) { blue }
        for (y in 10 until 20) for (x in 10 until 70 step 4) pixels[y * width + x] = rgb(255, 255, 255)
        ScanInpaint.erase(pixels, width, height, listOf(intArrayOf(8, 8, 72, 22)), intArrayOf(blue))
        for (y in 8 until 22) for (x in 8 until 72) assertTrue(close(pixels[y * width + x], blue, 2))
    }

    @Test
    fun respetaUnFondoEnDegradado() {
        val width = 100
        val height = 30
        val pixels = IntArray(width * height) { index ->
            val x = index % width
            rgb(x * 2, 100, 255 - x * 2)
        }
        for (y in 10 until 20) for (x in 30 until 70 step 3) pixels[y * width + x] = rgb(0, 0, 0)
        ScanInpaint.erase(pixels, width, height, listOf(intArrayOf(28, 8, 72, 22)), intArrayOf(-1))
        // En medio de la caja el color sigue el degradado original.
        val middle = pixels[15 * width + 50]
        assertTrue(close(middle, rgb(100, 100, 155), 8))
    }
}
