package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanRebuildTest {
    private val measure: (String) -> Float = { it.length * 10f }

    @Test
    fun uneRenglonesYPalabrasCortadas() {
        val text = ScanRebuild.joinLines(listOf("La voladura minera requiere una gestión", "preventiva que conside-", "re a las personas."))
        assertEquals("La voladura minera requiere una gestión preventiva que considere a las personas.", text)
    }

    @Test
    fun noQuitaGuionSiSigueMayuscula() {
        assertEquals("WebGen- 200", ScanRebuild.joinLines(listOf("WebGen-", "200")))
        assertEquals("Explotación- Minera", ScanRebuild.joinLines(listOf("Explotación-", "Minera")))
    }

    @Test
    fun cortaEnRenglonesQueEntran() {
        val lines = ScanRebuild.wrap("uno dos tres cuatro cinco", 95f, measure)
        assertEquals(listOf("uno dos", "tres", "cuatro", "cinco"), lines)
        lines.forEach { assertTrue(measure(it) <= 95f) }
    }

    @Test
    fun respetaSaltosYParteLaPalabraLarga() {
        assertEquals(listOf("hola", "chau"), ScanRebuild.wrap("hola\nchau", 200f, measure))
        assertEquals(listOf("abcde", "fghij", "k"), ScanRebuild.wrap("abcdefghijk", 50f, measure))
    }

    @Test
    fun cuantilTomaUnValorDelMedioBajo() {
        assertEquals(2f, ScanRebuild.quantile(listOf(5f, 1f, 2f, 9f, 3f), 0.3f))
        assertEquals(0f, ScanRebuild.quantile(emptyList(), 0.5f))
    }
}
