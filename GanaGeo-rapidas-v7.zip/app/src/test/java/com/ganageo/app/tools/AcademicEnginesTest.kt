package com.ganageo.app.tools

import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AcademicEnginesTest {

    private fun bd(value: String) = BigDecimal(value)

    // ---------------- Referencias ----------------

    @Test
    fun `lee apellidos compuestos del español`() {
        val conComa = CitationEngine.parseAuthors("García Márquez, Gabriel").first()
        assertEquals("García Márquez", conComa.lastName)
        assertEquals("Gabriel", conComa.firstNames)

        val sinComa = CitationEngine.parseAuthors("Gabriel García Márquez").first()
        assertEquals("García Márquez", sinComa.lastName)
        assertEquals("Gabriel", sinComa.firstNames)
    }

    @Test
    fun `detecta autores institucionales`() {
        val autor = CitationEngine.parseAuthors("Organización Mundial de la Salud").first()
        assertTrue(autor.isOrganization)
    }

    @Test
    fun `referencia APA de un libro`() {
        val data = SourceData(
            type = SourceType.BOOK,
            authors = CitationEngine.parseAuthors("García Márquez, Gabriel"),
            year = "2000",
            title = "Cien años de soledad",
            publisher = "Sudamericana"
        )
        val referencia = CitationEngine.reference(CitationStyle.APA7, data)
        assertEquals(
            "García Márquez, G. (2000). *Cien años de soledad*. Sudamericana.",
            referencia
        )
    }

    @Test
    fun `en español APA une con y, en ingles con ampersand`() {
        val data = SourceData(
            type = SourceType.BOOK,
            authors = CitationEngine.parseAuthors("Pérez, Ana; López, Juan"),
            year = "2020",
            title = "Metodología",
            publisher = "Trillas"
        )
        assertTrue(CitationEngine.reference(CitationStyle.APA7, data, spanish = true).contains(", y "))
        assertTrue(CitationEngine.reference(CitationStyle.APA7, data, spanish = false).contains(", & "))
    }

    @Test
    fun `APA 7 usa et al desde tres autores en la primera cita`() {
        val data = SourceData(
            authors = CitationEngine.parseAuthors("Pérez, Ana; López, Juan; Ruiz, Sara"),
            year = "2021",
            title = "Estudio"
        )
        assertEquals("(Pérez et al., 2021)", CitationEngine.inText(CitationStyle.APA7, data))
    }

    @Test
    fun `normaliza el DOI al formato actual`() {
        assertEquals("https://doi.org/10.1000/xyz", CitationEngine.normalizeDoi("doi:10.1000/xyz"))
        assertEquals("https://doi.org/10.1000/xyz", CitationEngine.normalizeDoi("http://dx.doi.org/10.1000/xyz"))
        assertEquals("https://doi.org/10.1000/xyz", CitationEngine.normalizeDoi("10.1000/xyz."))
    }

    @Test
    fun `Vancouver corta en seis autores`() {
        val autores = (1..8).joinToString("; ") { "Apellido$it, Nombre$it" }
        val data = SourceData(
            type = SourceType.ARTICLE,
            authors = CitationEngine.parseAuthors(autores),
            year = "2022",
            title = "Un estudio",
            containerTitle = "Rev Med",
            volume = "10",
            pages = "1-9"
        )
        val referencia = CitationEngine.reference(CitationStyle.VANCOUVER, data)
        assertTrue(referencia.contains("et al."))
        assertFalse(referencia.contains("Apellido7"))
    }

    @Test
    fun `las citas numericas usan corchetes en IEEE`() {
        val data = SourceData(authors = CitationEngine.parseAuthors("Pérez, Ana"), year = "2020", title = "X")
        assertEquals("[3]", CitationEngine.inText(CitationStyle.IEEE, data, number = 3))
        assertEquals("(3)", CitationEngine.inText(CitationStyle.VANCOUVER, data, number = 3))
    }

    @Test
    fun `MLA cita autor y pagina sin coma`() {
        val data = SourceData(authors = CitationEngine.parseAuthors("García, Gabriel"), year = "2000", title = "X")
        assertEquals("(García 45)", CitationEngine.inText(CitationStyle.MLA9, data, page = "45"))
    }

    @Test
    fun `ISO 690 pone los apellidos en mayusculas`() {
        val data = SourceData(
            type = SourceType.BOOK,
            authors = CitationEngine.parseAuthors("Pérez, Ana"),
            year = "2019",
            title = "Manual",
            publisher = "Ediciones"
        )
        assertTrue(CitationEngine.reference(CitationStyle.ISO690, data).contains("PÉREZ"))
    }

    @Test
    fun `avisa de los campos que faltan`() {
        val data = SourceData(type = SourceType.ARTICLE, title = "Solo el título")
        val faltantes = CitationEngine.missingFields(data)
        assertTrue(faltantes.contains("Autores"))
        assertTrue(faltantes.contains("Revista"))
        assertTrue(faltantes.contains("Año"))
    }

    // ---------------- Repetición espaciada ----------------

    @Test
    fun `los primeros intervalos de SM-2 son uno y seis dias`() {
        var estado = CardSchedule()
        estado = Sm2Scheduler.review(estado, 4, applyFuzz = false)
        assertEquals(1, estado.intervalDays)
        estado = Sm2Scheduler.review(estado, 4, applyFuzz = false)
        assertEquals(6, estado.intervalDays)
        estado = Sm2Scheduler.review(estado, 4, applyFuzz = false)
        assertEquals(15, estado.intervalDays)
    }

    @Test
    fun `responder bien no cambia el factor y responder facil lo sube`() {
        val bien = Sm2Scheduler.review(CardSchedule(), 4, applyFuzz = false)
        assertEquals(2.5, bien.easeFactor, 1e-9)
        val facil = Sm2Scheduler.review(CardSchedule(), 5, applyFuzz = false)
        assertEquals(2.6, facil.easeFactor, 1e-9)
    }

    @Test
    fun `fallar reinicia la tarjeta y suma un lapso`() {
        val avanzada = CardSchedule(easeFactor = 2.5, intervalDays = 30, repetitions = 4)
        val fallada = Sm2Scheduler.review(avanzada, 1, applyFuzz = false)
        assertEquals(1, fallada.intervalDays)
        assertEquals(0, fallada.repetitions)
        assertEquals(1, fallada.lapses)
        assertTrue(fallada.easeFactor < 2.5)
    }

    @Test
    fun `el factor de facilidad nunca baja de 1punto3`() {
        var estado = CardSchedule()
        repeat(20) { estado = Sm2Scheduler.review(estado, 0, applyFuzz = false) }
        assertEquals(Sm2Scheduler.MIN_EASE, estado.easeFactor, 1e-9)
    }

    @Test
    fun `marca como problematica la tarjeta muy fallada`() {
        assertTrue(Sm2Scheduler.isLeech(CardSchedule(lapses = 8)))
        assertFalse(Sm2Scheduler.isLeech(CardSchedule(lapses = 3)))
    }

    // ---------------- Notas y asistencia ----------------

    @Test
    fun `promedio ponderado por pesos`() {
        val escala = GradeEngine.scale("PE20")
        val resumen = GradeEngine.weightedAverage(
            listOf(GradeItem("P1", 15.0, 30.0), GradeItem("Parcial", 12.0, 30.0)),
            escala
        )
        assertEquals(13.5, resumen.average, 1e-9)
        assertEquals(60.0, resumen.accumulatedWeight, 1e-9)
        assertEquals(40.0, resumen.missingWeight, 1e-9)
    }

    @Test
    fun `promedio ponderado por creditos`() {
        val promedio = GradeEngine.creditWeightedAverage(listOf(16.0 to 4.0, 12.0 to 2.0))
        assertEquals(14.666, promedio, 0.01)
    }

    @Test
    fun `calcula la nota que falta para aprobar`() {
        val escala = GradeEngine.scale("PE20")
        val necesaria = GradeEngine.neededScore(
            listOf(GradeItem("P1", 15.0, 30.0), GradeItem("Parcial", 12.0, 30.0)),
            remainingWeight = 40.0,
            target = 11.0,
            scale = escala
        )
        assertTrue(necesaria.achievable)
        assertEquals(7.25, necesaria.value, 1e-9)
    }

    @Test
    fun `avisa cuando el objetivo ya es inalcanzable`() {
        val escala = GradeEngine.scale("PE20")
        val necesaria = GradeEngine.neededScore(
            listOf(GradeItem("P1", 5.0, 80.0)),
            remainingWeight = 20.0,
            target = 18.0,
            scale = escala
        )
        assertFalse(necesaria.achievable)
    }

    @Test
    fun `inhabilita al llegar al treinta por ciento de faltas`() {
        val limite = GradeEngine.attendance(missedSessions = 9, totalSessions = 30)
        assertTrue(limite.disqualified)
        assertEquals(0, limite.remainingAllowed)

        val tranquilo = GradeEngine.attendance(missedSessions = 3, totalSessions = 30)
        assertFalse(tranquilo.disqualified)
        assertEquals(6, tranquilo.remainingAllowed)
    }

    // ---------------- Exámenes ----------------

    @Test
    fun `lee y escribe el formato Aiken`() {
        val texto = """
            ¿Qué base tiene el hexadecimal?
            A. 2
            B. 8
            C. 16
            ANSWER: C
        """.trimIndent()
        val preguntas = QuizEngine.parseAiken(texto)
        assertEquals(1, preguntas.size)
        assertEquals(2, preguntas.first().correctIndex)
        assertEquals(3, preguntas.first().options.size)

        val exportado = QuizEngine.toAiken(preguntas)
        assertEquals(preguntas, QuizEngine.parseAiken(exportado))
    }

    @Test
    fun `lee el formato GIFT de Moodle`() {
        val texto = "::Bases:: ¿Qué base tiene el hexadecimal? {~2 ~8 =16}"
        val preguntas = QuizEngine.parseGift(texto)
        assertEquals(1, preguntas.size)
        assertEquals(2, preguntas.first().correctIndex)
    }

    @Test
    fun `la correccion por adivinacion resta los errores`() {
        assertEquals(8.0, QuizEngine.score(8, 2, 4, penalize = false), 1e-9)
        assertEquals(8 - 2.0 / 3.0, QuizEngine.score(8, 2, 4, penalize = true), 1e-9)
    }

    @Test
    fun `indices de dificultad y discriminacion`() {
        assertEquals(0.5, QuizEngine.difficultyIndex(10, 20), 1e-9)
        assertEquals(0.4, QuizEngine.discriminationIndex(8, 4, 10), 1e-9)
        val analisis = QuizEngine.analyze(0.5, -0.1)
        assertEquals("Revisar con urgencia", analisis.verdict)
    }

    @Test
    fun `avisa de los errores clasicos al redactar`() {
        val pregunta = QuizQuestion(
            "¿Cuál es la capital?",
            listOf("Lima", "Cusco", "Todas las anteriores"),
            0
        )
        assertTrue(QuizEngine.reviewWriting(pregunta).any { it.contains("todas las anteriores", true) })
    }

    @Test
    fun `al barajar se mantiene cual es la correcta`() {
        val original = QuizQuestion("P", listOf("a", "b", "c"), 1)
        repeat(20) {
            val barajada = QuizEngine.shuffle(listOf(original)).first()
            assertEquals("b", barajada.options[barajada.correctIndex])
        }
    }

    // ---------------- Finanzas ----------------

    @Test
    fun `cuota del sistema frances`() {
        val cuota = StudentFinanceLab.frenchInstallment(bd("1000"), bd("2"), 12)
        assertEquals(94.56, cuota.toDouble(), 0.02)
    }

    @Test
    fun `la tasa mensual sale de la raiz doceava, no de dividir entre doce`() {
        val tem = StudentFinanceLab.effectiveAnnualToMonthly(bd("35"))
        assertEquals(2.5324, tem.toDouble(), 0.001)
        assertTrue(tem.toDouble() < 35.0 / 12.0)
    }

    @Test
    fun `de tasa nominal a efectiva`() {
        val tea = StudentFinanceLab.nominalToEffective(bd("30"), 12)
        assertEquals(34.4889, tea.toDouble(), 0.01)
    }

    @Test
    fun `la tabla de amortizacion deja el saldo en cero`() {
        val prestamo = StudentFinanceLab.amortization(bd("5000"), bd("2.5"), 12)
        assertEquals(12, prestamo.rows.size)
        assertEquals(0.0, prestamo.rows.last().balance.toDouble(), 0.01)
        assertTrue(prestamo.totalInterest.toDouble() > 0)
    }

    @Test
    fun `reparte un gasto sin perder centimos`() {
        val partes = StudentFinanceLab.equalShares(bd("100"), listOf("Ana", "Luis", "Sara"))
        val suma = partes.values.fold(BigDecimal.ZERO) { acc, value -> acc.add(value) }
        assertEquals(0, suma.compareTo(bd("100.00")))
    }

    @Test
    fun `liquida las deudas con pocas transferencias`() {
        val saldos = mapOf(
            "Ana" to bd("60"),
            "Luis" to bd("-30"),
            "Sara" to bd("-30")
        )
        val movimientos = StudentFinanceLab.settleBalances(saldos)
        assertEquals(2, movimientos.size)
        assertTrue(movimientos.all { it.to == "Ana" })
        val total = movimientos.fold(BigDecimal.ZERO) { acc, item -> acc.add(item.amount) }
        assertEquals(0, total.compareTo(bd("60.00")))
    }

    // ---------------- Texto ----------------

    @Test
    fun `cuenta silabas en español`() {
        assertEquals(2, TextLab.countSyllables("casa"))
        assertEquals(4, TextLab.countSyllables("murciélago"))
        assertEquals(1, TextLab.countSyllables("sol"))
    }

    @Test
    fun `mide la legibilidad con formulas para el español`() {
        val texto = "El gato duerme. La casa es grande. El sol brilla mucho hoy."
        val resultado = TextLab.readability(texto)
        assertTrue("Un texto simple debe salir fácil", resultado.szigriszt > 60)
    }

    @Test
    fun `quita tildes y arma slugs`() {
        assertEquals("algebra lineal", TextLab.removeAccents("álgebra lineal"))
        assertEquals("algebra-lineal-ii", TextLab.toSlug("Álgebra Lineal II"))
    }

    @Test
    fun `limpia el texto copiado de un PDF`() {
        val sucio = "la investi-\ngación demuestra\nque funciona."
        assertEquals("la investigación demuestra que funciona.", TextLab.cleanPdfText(sucio))
    }

    @Test
    fun `cuenta palabras y caracteres`() {
        val stats = TextLab.stats("Hola mundo cruel")
        assertEquals(3, stats.words)
        assertEquals(16, stats.characters)
        assertEquals(14, stats.charactersNoSpaces)
    }

    // ---------------- Sistemas numéricos ----------------

    @Test
    fun `convierte entre bases`() {
        assertEquals(255L, NumberLab.parse("FF", 16))
        assertEquals("11111111", NumberLab.format(255, 2))
        assertEquals("377", NumberLab.format(255, 8))
        assertEquals("ZZ", NumberLab.format(1295, 36))
    }

    @Test
    fun `rechaza digitos que no existen en la base`() {
        assertFalse(NumberLab.isValidIn("2", 2))
        assertTrue(NumberLab.isValidIn("101", 2))
    }

    @Test
    fun `complemento a dos de un negativo`() {
        assertEquals("11111011", NumberLab.twosComplement(-5, 8))
        assertEquals(-5L, NumberLab.fromTwosComplement("11111011", 8))
        assertEquals("00000101", NumberLab.twosComplement(5, 8))
    }

    @Test
    fun `operaciones bit a bit`() {
        val resultado = NumberLab.bitwise(12, 10)
        assertEquals(8L, resultado.and)
        assertEquals(14L, resultado.or)
        assertEquals(6L, resultado.xor)
    }
}
