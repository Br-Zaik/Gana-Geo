package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ScienceEnginesTest {

    // ---------------- Motor matemático ----------------

    @Test
    fun `multiplicacion implicita se interpreta bien`() {
        val f = MathEngine.compile("2x + 3")
        assertEquals(9.0, f(3.0), 1e-9)
    }

    @Test
    fun `respeta la jerarquia de operaciones`() {
        val node = MathEngine.parse("2 + 3 * 4 ^ 2")
        assertEquals(50.0, MathEngine.eval(node, emptyMap()), 1e-9)
    }

    @Test
    fun `la potencia es asociativa por la derecha`() {
        val node = MathEngine.parse("2^3^2")
        assertEquals(512.0, MathEngine.eval(node, emptyMap()), 1e-9)
    }

    @Test
    fun `fuera de dominio devuelve NaN en vez de fallar`() {
        val f = MathEngine.compile("sqrt(x)")
        assertTrue(f(-1.0).isNaN())
        val g = MathEngine.compile("ln(x)")
        assertTrue(g(0.0).isNaN())
        val h = MathEngine.compile("1/x")
        assertTrue(h(0.0).isNaN())
    }

    @Test
    fun `derivada simbolica de un polinomio`() {
        val derivative = MathEngine.derivative(MathEngine.parse("x^3 - 3x"))
        val f = MathEngine.compileNode(derivative)
        assertEquals(9.0, f(2.0), 1e-9)
        assertEquals(-3.0, f(0.0), 1e-9)
    }

    @Test
    fun `derivada de producto y cadena`() {
        val derivative = MathEngine.derivative(MathEngine.parse("sin(2x)"))
        val f = MathEngine.compileNode(derivative)
        // d/dx sin(2x) = 2cos(2x); en x = 0 vale 2
        assertEquals(2.0, f(0.0), 1e-9)
    }

    // ---------------- Ecuaciones con pasos ----------------

    @Test
    fun `resuelve una ecuacion lineal escrita con parentesis`() {
        val solution = AlgebraSteps.solveEquation("3(x - 2) = 5x + 4")
        assertTrue(solution.headline.contains("-5"))
        assertTrue(solution.steps.isNotEmpty())
    }

    @Test
    fun `resuelve una cuadratica con dos raices`() {
        val solution = AlgebraSteps.quadratic(1.0, -5.0, 6.0)
        assertTrue(solution.results.any { it.contains("3") })
        assertTrue(solution.results.any { it.contains("2") })
    }

    @Test
    fun `detecta raices complejas`() {
        val solution = AlgebraSteps.quadratic(1.0, 2.0, 5.0)
        assertTrue(solution.headline.contains("i"))
    }

    @Test
    fun `sistema 2x2 con solucion unica`() {
        val solution = AlgebraSteps.system2x2(2.0, 3.0, 12.0, 1.0, -1.0, 1.0)
        assertTrue(solution.results.any { it.contains("x = 3") })
        assertTrue(solution.results.any { it.contains("y = 2") })
    }

    // ---------------- Álgebra lineal ----------------

    @Test
    fun `determinante e inversa`() {
        val matrix = arrayOf(doubleArrayOf(4.0, 7.0), doubleArrayOf(2.0, 6.0))
        assertEquals(10.0, LinearAlgebraPro.determinant(matrix), 1e-9)
        val inverse = LinearAlgebraPro.inverse(matrix)!!
        assertEquals(0.6, inverse[0][0], 1e-9)
        assertEquals(-0.7, inverse[0][1], 1e-9)
    }

    @Test
    fun `resuelve un sistema lineal 3x3`() {
        val matrix = arrayOf(
            doubleArrayOf(1.0, 1.0, 1.0),
            doubleArrayOf(2.0, -1.0, 1.0),
            doubleArrayOf(1.0, 2.0, -1.0)
        )
        val solution = LinearAlgebraPro.solveSystem(matrix, doubleArrayOf(6.0, 3.0, 2.0))!!
        assertEquals(1.0, solution[0], 1e-6)
        assertEquals(2.0, solution[1], 1e-6)
        assertEquals(3.0, solution[2], 1e-6)
    }

    @Test
    fun `matriz singular no tiene inversa`() {
        val matrix = arrayOf(doubleArrayOf(1.0, 2.0), doubleArrayOf(2.0, 4.0))
        assertEquals(0.0, LinearAlgebraPro.determinant(matrix), 1e-9)
        assertTrue(LinearAlgebraPro.inverse(matrix) == null)
    }

    // ---------------- Cálculo numérico ----------------

    @Test
    fun `integral definida de x cuadrado`() {
        val area = NumericCalculus.integrate({ x -> x * x }, 0.0, 3.0)
        assertEquals(9.0, area, 1e-4)
    }

    @Test
    fun `encuentra las raices de una cuadratica`() {
        val roots = NumericCalculus.rootsIn({ x -> x * x - 4 }, -10.0, 10.0)
        assertEquals(2, roots.size)
        assertTrue(roots.any { abs(it + 2.0) < 1e-4 })
        assertTrue(roots.any { abs(it - 2.0) < 1e-4 })
    }

    // ---------------- Estadística ----------------

    @Test
    fun `media mediana y moda`() {
        val values = listOf(12.0, 15.0, 15.0, 18.0, 21.0)
        val summary = StatsLab.summarize(values)
        assertEquals(16.2, summary.mean, 1e-9)
        assertEquals(15.0, summary.median, 1e-9)
        assertEquals(listOf(15.0), summary.modes)
    }

    @Test
    fun `desviacion muestral y poblacional son distintas`() {
        val values = listOf(2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0)
        val summary = StatsLab.summarize(values)
        assertEquals(2.0, summary.deviationPopulation, 1e-9)
        assertTrue(summary.deviationSample > summary.deviationPopulation)
    }

    @Test
    fun `los dos metodos de cuartiles dan resultados distintos`() {
        val values = listOf(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0)
        val inclusive = StatsLab.summarize(values, QuartileMethod.INCLUSIVE)
        val exclusive = StatsLab.summarize(values, QuartileMethod.EXCLUSIVE)
        assertEquals(3.0, inclusive.q1, 1e-9)
        assertEquals(2.5, exclusive.q1, 1e-9)
    }

    @Test
    fun `regresion lineal perfecta`() {
        val points = listOf(1.0 to 2.0, 2.0 to 4.0, 3.0 to 6.0)
        val result = StatsLab.linearRegression(points)
        assertEquals(2.0, result.slope, 1e-9)
        assertEquals(0.0, result.intercept, 1e-9)
        assertEquals(1.0, result.correlation, 1e-9)
    }

    // ---------------- Química ----------------

    @Test
    fun `masa molar del agua`() {
        val analysis = ChemLab.analyze("H2O")
        assertEquals(18.015, analysis.molarMass, 0.01)
    }

    @Test
    fun `lee formulas con parentesis e hidratos`() {
        assertEquals(mapOf("Ca" to 1, "O" to 2, "H" to 2), ChemLab.parseFormula("Ca(OH)2"))
        val hydrate = ChemLab.parseFormula("CuSO4·5H2O")
        assertEquals(10, hydrate["H"])
        assertEquals(9, hydrate["O"])
    }

    @Test
    fun `balancea la combustion del propano`() {
        val balanced = ChemLab.balance("C3H8 + O2 → CO2 + H2O")
        assertEquals(1, balanced.reactants[0].first)
        assertEquals(5, balanced.reactants[1].first)
        assertEquals(3, balanced.products[0].first)
        assertEquals(4, balanced.products[1].first)
    }

    @Test
    fun `balancea la formacion de agua`() {
        val balanced = ChemLab.balance("H2 + O2 = H2O")
        assertEquals(2, balanced.reactants[0].first)
        assertEquals(1, balanced.reactants[1].first)
        assertEquals(2, balanced.products[0].first)
    }

    @Test
    fun `calcula el pH de un acido fuerte`() {
        val result = ChemLab.fromConcentration(0.01, isAcid = true)
        assertEquals(2.0, result.ph, 1e-9)
        assertEquals(12.0, result.poh, 1e-9)
        assertEquals("Ácida", result.nature)
    }

    // ---------------- Tabla periódica ----------------

    @Test
    fun `el catalogo tiene los 118 elementos`() {
        assertEquals(118, ElementsCatalog.elements.size)
        assertEquals("H", ElementsCatalog.elements.first().symbol)
        assertEquals("Og", ElementsCatalog.elements.last().symbol)
    }

    @Test
    fun `masas atomicas segun IUPAC`() {
        assertEquals(1.008, ElementsCatalog.atomicMass("H")!!, 1e-6)
        assertEquals(12.011, ElementsCatalog.atomicMass("C")!!, 1e-6)
        assertEquals(39.95, ElementsCatalog.atomicMass("Ar")!!, 1e-6)
        assertEquals(207.2, ElementsCatalog.atomicMass("Pb")!!, 1e-6)
    }

    @Test
    fun `configuracion electronica con y sin excepciones`() {
        assertEquals("[Ne] 3s¹", ElementsCatalog.configurationOf(11))
        assertEquals("[Ar] 3d⁵ 4s¹", ElementsCatalog.configurationOf(24))
    }

    @Test
    fun `posiciones en la tabla larga`() {
        assertEquals(1 to 1, ElementsCatalog.gridPosition(1))
        assertEquals(1 to 18, ElementsCatalog.gridPosition(2))
        assertEquals(2 to 13, ElementsCatalog.gridPosition(5))
        assertEquals(9 to 3, ElementsCatalog.gridPosition(57))
    }

    // ---------------- Física ----------------

    @Test
    fun `la segunda ley despeja cualquier variable`() {
        val formula = PhysicsLab.byId("newton2")!!
        assertEquals(20.0, formula.solve("F", mapOf("m" to 5.0, "a" to 4.0)), 1e-9)
        assertEquals(5.0, formula.solve("m", mapOf("F" to 20.0, "a" to 4.0)), 1e-9)
        assertEquals(4.0, formula.solve("a", mapOf("F" to 20.0, "m" to 5.0)), 1e-9)
    }

    @Test
    fun `la gravedad tiene valor por defecto`() {
        val formula = PhysicsLab.byId("peso")!!
        assertEquals(98.0665, formula.solve("P", mapOf("m" to 10.0)), 1e-4)
    }

    @Test
    fun `constantes exactas del SI`() {
        assertEquals(299_792_458.0, PhysicsConstants.bySymbol("c")!!.value, 0.0)
        assertTrue(PhysicsConstants.bySymbol("h")!!.exact)
        assertTrue(!PhysicsConstants.bySymbol("G")!!.exact)
    }

    // ---------------- Graficado ----------------

    @Test
    fun `la asintota parte la curva en trozos`() {
        val f = MathEngine.compile("1/x")
        val segments = PlotEngine.sample(f, -5.0, 5.0, -10.0, 10.0, 400)
        assertTrue("Debe haber al menos dos trozos separados", segments.size >= 2)
    }

    @Test
    fun `una funcion continua da un solo trozo`() {
        val f = MathEngine.compile("x^2")
        val segments = PlotEngine.sample(f, -3.0, 3.0, -1.0, 10.0, 300)
        assertEquals(1, segments.size)
    }
}
