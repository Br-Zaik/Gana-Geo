package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QuickEnginesTest {

    // ---------------- Codigos de barras ----------------

    @Test
    fun `calcula el digito verificador de un UPC-A`() {
        assertEquals(5, BarcodeEngine.gtinCheckDigit("72641217542"))
        assertEquals("726412175425", BarcodeEngine.appendCheckDigit("72641217542"))
    }

    @Test
    fun `calcula el digito verificador de un EAN-13`() {
        assertEquals(1, BarcodeEngine.gtinCheckDigit("400638133393"))
        assertTrue(BarcodeEngine.isGtinValid("4006381333931"))
        assertFalse(BarcodeEngine.isGtinValid("4006381333932"))
    }

    @Test
    fun `un UPC-A es el mismo codigo que un EAN-13 con cero delante`() {
        assertEquals("0726412175425", BarcodeEngine.upcAToEan13("726412175425"))
        assertEquals("726412175425", BarcodeEngine.ean13ToUpcA("0726412175425"))
        assertNull(BarcodeEngine.ean13ToUpcA("4006381333931"))
    }

    @Test
    fun `reconoce el prefijo GS1 de Peru`() {
        val peruvian = BarcodeEngine.appendCheckDigit("775123456789")
        assertEquals("Peru", BarcodeEngine.gs1Issuer(peruvian))
        assertEquals("Chile", BarcodeEngine.gs1Issuer(BarcodeEngine.appendCheckDigit("780123456789")))
    }

    @Test
    fun `completa el verificador cuando faltan digitos`() {
        val check = BarcodeEngine.validate(BarcodeKind.EAN_13, "400638133393")
        assertTrue(check.valid)
        assertEquals("4006381333931", check.normalized)
        assertEquals("4006381333931", check.suggestion)
    }

    @Test
    fun `avisa cuando el verificador no cuadra y propone el correcto`() {
        val check = BarcodeEngine.validate(BarcodeKind.EAN_13, "4006381333932")
        assertFalse(check.valid)
        assertEquals("4006381333931", check.suggestion)
    }

    @Test
    fun `rechaza tildes en Code 128`() {
        assertFalse(BarcodeEngine.validate(BarcodeKind.CODE_128, "SESIÓN").valid)
        assertTrue(BarcodeEngine.validate(BarcodeKind.CODE_128, "SESION-01").valid)
    }

    @Test
    fun `ITF exige cantidad par de digitos`() {
        assertFalse(BarcodeEngine.validate(BarcodeKind.ITF, "12345").valid)
        assertTrue(BarcodeEngine.validate(BarcodeKind.ITF, "123456").valid)
    }

    // ---------------- Contenidos QR ----------------

    @Test
    fun `arma un QR de wifi con la sintaxis del estandar`() {
        val payload = QrContent.wifi("Casa GEO", "clave;123", WifiSecurity.WPA, hidden = false)
        assertEquals("WIFI:S:Casa GEO;T:WPA;P:clave\\;123;;", payload)
    }

    @Test
    fun `una red abierta no lleva contrasena`() {
        val payload = QrContent.wifi("Invitados", "loquesea", WifiSecurity.ABIERTA, hidden = false)
        assertEquals("WIFI:S:Invitados;T:nopass;;", payload)
    }

    @Test
    fun `completa el esquema del enlace`() {
        assertEquals("https://ganageo.app", QrContent.url("ganageo.app"))
        assertEquals("http://interno.local", QrContent.url("http://interno.local"))
    }

    @Test
    fun `whatsapp usa el numero internacional sin el signo mas`() {
        assertEquals("https://wa.me/51987654321", QrContent.whatsapp("+51 987 654 321", ""))
    }

    // ---------------- Analisis de lo leido ----------------

    @Test
    fun `detecta el tipo de contenido leido`() {
        assertEquals("Wi-Fi", ScannedContentAnalyzer.analyze("WIFI:S:Casa;T:WPA;P:1234;;").kind)
        assertEquals("Telefono", ScannedContentAnalyzer.analyze("tel:+51987654321").kind)
        assertEquals("Enlace", ScannedContentAnalyzer.analyze("https://ganageo.app").kind)
        assertEquals("Producto (GTIN)", ScannedContentAnalyzer.analyze("4006381333931").kind)
    }

    @Test
    fun `avisa de enlaces sospechosos`() {
        assertTrue(ScannedContentAnalyzer.urlWarnings("http://banco.com").isNotEmpty())
        assertTrue(ScannedContentAnalyzer.urlWarnings("https://bit.ly/2abc").isNotEmpty())
        assertTrue(ScannedContentAnalyzer.urlWarnings("https://banco.com@malo.net/x").isNotEmpty())
        assertTrue(ScannedContentAnalyzer.urlWarnings("https://ganageo.app/promo").isEmpty())
    }

    // ---------------- QR de pago EMVCo ----------------

    @Test
    fun `calcula el CRC de un QR de pago`() {
        // CRC-16/CCITT-FALSE sobre todo el contenido, incluidos los caracteres "6304".
        val body = "00020101021153036045802PE5909Mi Bodega6304"
        assertEquals("FB18", String.format("%04X", EmvQr.crc16(body)))
    }

    @Test
    fun `interpreta un QR de pago peruano y verifica su CRC`() {
        val info = EmvQr.describe("00020101021153036045802PE5909Mi Bodega6304FB18")
        assertNotNull(info)
        assertEquals("QR de pago (EMVCo)", info!!.kind)
        assertEquals("Mi Bodega", info.summary)
        assertTrue(info.details.contains("Moneda" to "PEN (soles)"))
        assertTrue(info.details.contains("CRC" to "verificado"))
    }

    @Test
    fun `detecta un QR de pago alterado`() {
        val info = EmvQr.describe("00020101021153036045802PE5909Mi Bodega63040000")
        assertNotNull(info)
        assertTrue(info!!.details.contains("CRC" to "NO COINCIDE"))
        assertTrue(info.warnings.any { it.contains("CRC") })
    }

    @Test
    fun `lee la estructura TLV de un QR de pago`() {
        val fields = EmvQr.parse("00020101021153036045802PE5909Mi Bodega6304ABCD")
        assertNotNull(fields)
        assertEquals("01", fields!!["00"])
        assertEquals("604", fields["53"])
        assertEquals("PE", fields["58"])
        assertEquals("Mi Bodega", fields["59"])
    }

    @Test
    fun `descarta una cadena que no es TLV`() {
        assertNull(EmvQr.parse("hola mundo"))
    }

    // ---------------- Metricas de texto ----------------

    @Test
    fun `no parte las palabras por espacios a lo bruto`() {
        val words = TextMetricsEngine.words("Costo 10,000 soles en EE.UU. no cambió")
        assertEquals(listOf("Costo", "10,000", "soles", "en", "EE.UU", "no", "cambió"), words)
    }

    @Test
    fun `cuenta un emoji como un solo caracter`() {
        assertEquals(5, TextMetricsEngine.visibleCharacters("Hola👋"))
    }

    @Test
    fun `una tilde minuscula obliga a UCS-2 y recorta el SMS`() {
        val plain = TextMetricsEngine.smsInfo("Nos vemos manana en clase")
        assertEquals("GSM-7", plain.encoding)
        assertEquals(160, plain.perSegment)

        val accented = TextMetricsEngine.smsInfo("Nos vemos mañana en clase")
        assertEquals("GSM-7", accented.encoding) // la ñ si esta en GSM-7

        val tilde = TextMetricsEngine.smsInfo("Sesión de estudio")
        assertEquals("UCS-2", tilde.encoding)
        assertEquals(70, tilde.perSegment)
    }

    @Test
    fun `parte el SMS largo en segmentos de 153`() {
        val info = TextMetricsEngine.smsInfo("a".repeat(200))
        assertEquals("GSM-7", info.encoding)
        assertEquals(2, info.segments)
        assertEquals(153, info.perSegment)
    }

    @Test
    fun `los tiempos de lectura crecen con el texto`() {
        val short = TextMetricsEngine.analyze("Una frase corta para medir.")
        val long = TextMetricsEngine.analyze("palabra ".repeat(500))
        val shortSeconds = short.readingTimes.first().seconds
        val longSeconds = long.readingTimes.first().seconds
        assertTrue(longSeconds > shortSeconds)
        assertEquals(500, long.words)
    }

    @Test
    fun `un texto sencillo puntua mas alto que uno enrevesado`() {
        val simple = TextMetricsEngine.analyze("El sol sale. La luna se va. Hoy hay clase.")
        val complex = TextMetricsEngine.analyze(
            "La implementación multidimensional de procedimientos administrativos interinstitucionales " +
                "condiciona significativamente la operatividad presupuestaria correspondiente."
        )
        assertTrue(simple.fleschSzigriszt > complex.fleschSzigriszt)
        assertEquals("Muy facil", TextMetricsEngine.infleszLabel(85.0))
        assertEquals("Muy dificil", TextMetricsEngine.infleszLabel(30.0))
    }

    @Test
    fun `la densidad de palabras ignora los articulos`() {
        val top = TextMetricsEngine.topWords(
            TextMetricsEngine.words("el estudio de la geologia y el estudio del terreno y la geologia aplicada")
        )
        assertEquals("estudio", top.first().word)
        assertTrue(top.none { it.word == "el" || it.word == "la" })
    }

    @Test
    fun `un texto vacio no rompe el analisis`() {
        val metrics = TextMetricsEngine.analyze("")
        assertEquals(0, metrics.words)
        assertTrue(metrics.isEmpty)
    }

    // ---------------- Tiempo y enfoque ----------------

    @Test
    fun `el tiempo se mide contra el reloj y no sumando segundos`() {
        val anchor = TimeAnchor(realtime = 1_000L, wallClock = 500_000L)
        assertEquals(9_000L, FocusLab.elapsedSince(anchor, 10_000L, 509_000L))
    }

    @Test
    fun `si el telefono se reinicio se usa el reloj normal`() {
        // Tras un reinicio elapsedRealtime vuelve a cero: el ancla queda en el futuro.
        val anchor = TimeAnchor(realtime = 900_000L, wallClock = 1_000_000L)
        assertEquals(4_000L, FocusLab.elapsedSince(anchor, 5_000L, 1_004_000L))
    }

    @Test
    fun `la cuenta regresiva sobrevive a un reinicio`() {
        val endsAt = TimeAnchor(realtime = 900_000L, wallClock = 2_000_000L)
        // Reloj monotonico reiniciado: daria 890 s de mas, se cae al reloj normal.
        assertEquals(60_000L, FocusLab.remainingUntil(endsAt, 10_000L, 1_940_000L))
        // Funcionamiento normal.
        assertEquals(30_000L, FocusLab.remainingUntil(endsAt, 870_000L, 1_970_000L))
    }

    @Test
    fun `el descanso largo llega cada cuatro pomodoros`() {
        val preset = FocusLab.presets.first()
        assertEquals(4, preset.cyclesBeforeLongBreak)
        assertEquals(FocusPhase.SHORT_BREAK, FocusLab.nextPhase(FocusPhase.FOCUS, 1, preset))
        assertEquals(FocusPhase.SHORT_BREAK, FocusLab.nextPhase(FocusPhase.FOCUS, 3, preset))
        assertEquals(FocusPhase.LONG_BREAK, FocusLab.nextPhase(FocusPhase.FOCUS, 4, preset))
        assertEquals(FocusPhase.FOCUS, FocusLab.nextPhase(FocusPhase.LONG_BREAK, 4, preset))
    }

    @Test
    fun `los formatos de tiempo mantienen el ancho fijo`() {
        assertEquals("00:05.00", FocusLab.formatStopwatch(5_000L))
        assertEquals("01:00:00.00", FocusLab.formatStopwatch(3_600_000L))
        assertEquals("25:00", FocusLab.formatTimer(25 * 60_000L))
        assertEquals("00:00", FocusLab.formatTimer(0L))
        assertEquals("1 h 25 min", FocusLab.formatAccumulated(85 * 60_000L))
    }
}
