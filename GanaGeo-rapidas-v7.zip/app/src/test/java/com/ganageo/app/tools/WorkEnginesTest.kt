package com.ganageo.app.tools

import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkEnginesTest {

    private fun bd(value: String) = BigDecimal(value)

    // ---------------- Dinero ----------------

    @Test
    fun `lee montos con coma o punto decimal`() {
        assertEquals(1234.56, Money.of("1.234,56").toDouble(), 1e-9)
        assertEquals(1234.56, Money.of("1,234.56").toDouble(), 1e-9)
        assertEquals(19.99, Money.of("S/ 19.99").toDouble(), 1e-9)
        assertTrue(Money.parseOrNull("abc") == null)
    }

    @Test
    fun `la suma de importes no arrastra error de coma flotante`() {
        val total = listOf("0.1", "0.2").fold(BigDecimal.ZERO) { acc, value -> acc.add(Money.of(value)) }
        assertEquals(0.30, Money.round(total).toDouble(), 0.0)
    }

    @Test
    fun `reparte el centimo que sobra al redondear lineas`() {
        val lines = listOf(bd("33.333"), bd("33.333"), bd("33.334"))
        val result = Money.distributeResidue(lines, bd("100.00"))
        val sum = result.fold(BigDecimal.ZERO) { acc, value -> acc.add(value) }
        assertEquals(0, sum.compareTo(bd("100.00")))
    }

    @Test
    fun `escribe el monto en letras`() {
        assertEquals(
            "MIL DOSCIENTOS TREINTA Y CUATRO CON 50/100 SOLES",
            Money.toWords(bd("1234.50"))
        )
        assertEquals("CIEN CON 00/100 SOLES", Money.toWords(bd("100")))
    }

    // ---------------- Impuesto ----------------

    @Test
    fun `desagrega el impuesto desde un precio que ya lo incluye`() {
        val split = TaxEngine.split(bd("118"), bd("18"), TaxMode.INCLUDED)
        assertEquals(100.0, split.base.toDouble(), 1e-9)
        assertEquals(18.0, split.tax.toDouble(), 1e-9)
        assertEquals(118.0, split.total.toDouble(), 1e-9)
    }

    @Test
    fun `agrega el impuesto a un precio sin impuesto`() {
        val split = TaxEngine.split(bd("100"), bd("18"), TaxMode.EXCLUDED)
        assertEquals(18.0, split.tax.toDouble(), 1e-9)
        assertEquals(118.0, split.total.toDouble(), 1e-9)
    }

    @Test
    fun `restar el porcentaje al total seria un error`() {
        // 118 menos 18% da 96.76, que NO es la base imponible.
        val wrong = bd("118").multiply(bd("0.82"))
        val right = TaxEngine.split(bd("118"), bd("18"), TaxMode.INCLUDED).base
        assertTrue(wrong.compareTo(right) != 0)
    }

    // ---------------- Cotización ----------------

    @Test
    fun `la cotizacion cuadra con el total`() {
        val items = listOf(
            QuoteItem("Servicio A", bd("1"), bd("50")),
            QuoteItem("Servicio B", bd("1"), bd("50"))
        )
        val totals = QuoteEngine.compute(items, bd("18"), TaxMode.EXCLUDED)
        assertEquals(100.0, totals.base.toDouble(), 1e-9)
        assertEquals(18.0, totals.tax.toDouble(), 1e-9)
        assertEquals(118.0, totals.total.toDouble(), 1e-9)
        val sumLines = totals.lines.fold(BigDecimal.ZERO) { acc, line -> acc.add(line.netAmount) }
        assertEquals(0, sumLines.compareTo(totals.base))
    }

    @Test
    fun `aplica descuentos por linea y global`() {
        val items = listOf(QuoteItem("Producto", bd("2"), bd("100"), bd("10")))
        val totals = QuoteEngine.compute(items, bd("18"), TaxMode.EXCLUDED, bd("10"))
        // 200 - 10% = 180, menos 10% global = 162
        assertEquals(162.0, totals.base.toDouble(), 1e-9)
    }

    @Test
    fun `numera el documento con serie y correlativo`() {
        assertEquals("COT-000007", QuoteEngine.documentNumber("cot", 7))
    }

    // ---------------- Precios ----------------

    @Test
    fun `margen y markup no son lo mismo`() {
        assertEquals(100.0, PricingEngine.marginToMarkup(bd("50")).toDouble(), 0.01)
        assertEquals(33.33, PricingEngine.markupToMargin(bd("50")).toDouble(), 0.01)
    }

    @Test
    fun `precio para un margen deseado`() {
        val price = PricingEngine.priceFor(bd("100"), bd("25"), PriceBasis.MARGIN)
        assertEquals(133.33, price.toDouble(), 0.01)
    }

    @Test
    fun `precio para un markup deseado`() {
        val price = PricingEngine.priceFor(bd("100"), bd("25"), PriceBasis.MARKUP)
        assertEquals(125.0, price.toDouble(), 0.01)
    }

    @Test
    fun `analiza una venta con comision`() {
        val result = PricingEngine.analyze(bd("50"), bd("100"), bd("10"))
        assertEquals(50.0, result.grossProfit.toDouble(), 1e-9)
        assertEquals(10.0, result.commission.toDouble(), 1e-9)
        assertEquals(40.0, result.netProfit.toDouble(), 1e-9)
        assertEquals(40.0, result.marginPercent.toDouble(), 0.01)
        assertEquals(100.0, result.markupPercent.toDouble(), 0.01)
    }

    @Test
    fun `punto de equilibrio en unidades`() {
        val units = PricingEngine.breakEvenUnits(bd("2000"), bd("100"), bd("60"))
        assertEquals(50.0, units.toDouble(), 1e-9)
    }

    @Test
    fun `comision escalonada paga cada tramo a su tasa`() {
        val tiers = listOf(
            PricingEngine.CommissionTier(BigDecimal.ZERO, bd("2")),
            PricingEngine.CommissionTier(bd("5000"), bd("4")),
            PricingEngine.CommissionTier(bd("10000"), bd("6"))
        )
        assertEquals(420.0, PricingEngine.tieredCommission(bd("12000"), tiers).toDouble(), 0.01)
    }

    // ---------------- RUC ----------------

    @Test
    fun `valida el digito verificador del RUC`() {
        assertTrue(FiscalData.isValidRuc("20123456786"))
        assertFalse(FiscalData.isValidRuc("20123456780"))
        assertFalse(FiscalData.isValidRuc("12345678901"))
        assertFalse(FiscalData.isValidRuc("2012345678"))
    }

    @Test
    fun `reconoce el tipo de contribuyente`() {
        assertEquals("Persona jurídica (empresa)", FiscalData.rucType("20123456786"))
    }

    // ---------------- Honorarios y planilla ----------------

    @Test
    fun `retiene 8 por ciento solo cuando el recibo supera el tope`() {
        val big = PayrollEngine.honorarios(bd("2000"))
        assertTrue(big.retentionApplied)
        assertEquals(160.0, big.retention.toDouble(), 1e-9)
        assertEquals(1840.0, big.net.toDouble(), 1e-9)

        val small = PayrollEngine.honorarios(bd("1000"))
        assertFalse(small.retentionApplied)
        assertEquals(1000.0, small.net.toDouble(), 1e-9)
    }

    @Test
    fun `con suspension vigente no hay retencion`() {
        val result = PayrollEngine.honorarios(bd("5000"), hasSuspension = true)
        assertEquals(0.0, result.retention.toDouble(), 1e-9)
    }

    @Test
    fun `sueldo neto con ONP descuenta 13 por ciento y quinta categoria`() {
        val result = PayrollEngine.netSalary(bd("3000"), useOnp = true)
        assertEquals(390.0, result.pensionAmount.toDouble(), 0.01)
        assertEquals(2586.67, result.net.toDouble(), 0.05)
        // EsSalud lo paga el empleador, no se descuenta del trabajador.
        assertEquals(270.0, result.employerEsSalud.toDouble(), 0.01)
    }

    @Test
    fun `sueldo bajo no paga quinta categoria`() {
        val result = PayrollEngine.netSalary(bd("1500"), useOnp = true)
        assertEquals(0.0, result.incomeTax.toDouble(), 1e-9)
    }

    @Test
    fun `gratificacion completa mas bonificacion del 9 por ciento`() {
        val result = PayrollEngine.gratificacion(bd("3000"), 6)
        assertEquals(3000.0, result.amount.toDouble(), 1e-9)
        assertEquals(270.0, result.extra.toDouble(), 1e-9)
        assertEquals(3270.0, result.total.toDouble(), 1e-9)
    }

    @Test
    fun `la CTS incluye un sexto de la gratificacion`() {
        val result = PayrollEngine.cts(bd("3000"), bd("3000"), 6)
        assertEquals(1750.0, result.total.toDouble(), 0.01)
    }

    // ---------------- Horas ----------------

    @Test
    fun `calcula la jornada con descanso`() {
        val shift = TimeEngine.analyzeShift(
            startMinutes = TimeEngine.minutesOf(8, 0),
            endMinutes = TimeEngine.minutesOf(18, 30),
            breakMinutes = 60
        )
        assertEquals(630, shift.totalMinutes)
        assertEquals(570, shift.workedMinutes)
        assertEquals(480, shift.regularMinutes)
        assertEquals(90, shift.overtimeMinutes)
        assertFalse(shift.crossesMidnight)
    }

    @Test
    fun `el turno que cruza medianoche se cuenta completo`() {
        val shift = TimeEngine.analyzeShift(
            startMinutes = TimeEngine.minutesOf(22, 0),
            endMinutes = TimeEngine.minutesOf(6, 0),
            breakMinutes = 0
        )
        assertTrue(shift.crossesMidnight)
        assertEquals(480, shift.totalMinutes)
        assertEquals(480, shift.nightMinutes)
    }

    @Test
    fun `las horas extra suben de 25 a 35 por ciento desde la tercera`() {
        val pay = TimeEngine.computePay(
            hourlyRate = bd("10"),
            regularMinutes = 480,
            overtimeMinutes = 180
        )
        assertEquals(80.0, pay.regularPay.toDouble(), 1e-9)
        assertEquals(25.0, pay.overtimeFirstPay.toDouble(), 1e-9)
        assertEquals(13.5, pay.overtimeRestPay.toDouble(), 1e-9)
        assertEquals(118.5, pay.total.toDouble(), 1e-9)
    }

    @Test
    fun `el valor hora sale del sueldo entre 30 y entre la jornada`() {
        val rate = TimeEngine.hourlyFromMonthly(bd("1200"), 8.0)
        assertEquals(5.0, rate.toDouble(), 1e-6)
    }

    @Test
    fun `redondea las marcaciones al bloque elegido`() {
        assertEquals(60, TimeEngine.roundMinutes(58, 15))
        assertEquals(45, TimeEngine.roundMinutes(44, 15))
    }

    // ---------------- Inventario ----------------

    @Test
    fun `costo promedio ponderado tras una compra`() {
        val average = InventoryEngine.weightedAverage(bd("10"), bd("5"), bd("10"), bd("7"))
        assertEquals(6.0, average.toDouble(), 1e-9)
    }

    @Test
    fun `consume stock por PEPS`() {
        val layers = listOf(StockLayer(bd("10"), bd("5")), StockLayer(bd("10"), bd("7")))
        val (cost, rest) = InventoryEngine.consumeFifo(layers, bd("15"))
        assertEquals(85.0, cost.toDouble(), 1e-9)
        assertEquals(1, rest.size)
        assertEquals(5.0, rest.first().quantity.toDouble(), 1e-9)
    }

    @Test
    fun `punto de reorden con tiempo de entrega`() {
        val point = InventoryEngine.reorderPoint(bd("5"), 7, bd("10"))
        assertEquals(45.0, point.toDouble(), 1e-9)
    }

    // ---------------- Datos fiscales ----------------

    @Test
    fun `el catalogo de paises trae el nombre correcto del impuesto`() {
        assertEquals("IGV", FiscalData.country("PE").taxName)
        assertEquals("IVA", FiscalData.country("MX").taxName)
        assertEquals("ITBIS", FiscalData.country("DO").taxName)
        assertEquals(18.0, FiscalData.country("PE").defaultRate.percent.toDouble(), 1e-9)
    }

    @Test
    fun `constantes peruanas vigentes`() {
        assertEquals(5500.0, FiscalData.Peru.UIT.toDouble(), 1e-9)
        assertEquals(1130.0, FiscalData.Peru.RMV.toDouble(), 1e-9)
        assertEquals(113.0, FiscalData.Peru.ASIGNACION_FAMILIAR.toDouble(), 1e-9)
        assertEquals(38500.0, FiscalData.Peru.DEDUCCION_7_UIT.toDouble(), 1e-9)
    }
}
