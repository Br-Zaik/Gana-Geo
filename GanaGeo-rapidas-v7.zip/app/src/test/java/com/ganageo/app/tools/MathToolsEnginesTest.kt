package com.ganageo.app.tools

import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MathToolsEnginesTest {

    // ---------------- Calculadora ----------------

    @Test
    fun `el porcentaje se toma sobre lo que hay a la izquierda`() {
        // 50 + 10 % debe dar 55, como en una calculadora de mostrador.
        val resultado = CalculatorEngine.evaluate("50+10%", degrees = true).getOrThrow()
        assertEquals(55.0, resultado, 1e-9)

        val descuento = CalculatorEngine.evaluate("200-10%", degrees = true).getOrThrow()
        assertEquals(180.0, descuento, 1e-9)
    }

    @Test
    fun `en multiplicacion el porcentaje es solo una fraccion`() {
        val resultado = CalculatorEngine.evaluate("200*10%", degrees = true).getOrThrow()
        assertEquals(20.0, resultado, 1e-9)
    }

    @Test
    fun `respeta la jerarquia de operaciones`() {
        assertEquals(14.0, CalculatorEngine.evaluate("2+3*4", true).getOrThrow(), 1e-9)
        assertEquals(20.0, CalculatorEngine.evaluate("(2+3)*4", true).getOrThrow(), 1e-9)
    }

    @Test
    fun `trabaja en grados o en radianes segun el modo`() {
        assertEquals(1.0, CalculatorEngine.evaluate("sin(90)", degrees = true).getOrThrow(), 1e-9)
        assertEquals(0.0, CalculatorEngine.evaluate("sin(pi)", degrees = false).getOrThrow(), 1e-9)
    }

    @Test
    fun `avisa del error en vez de devolver NaN`() {
        val division = CalculatorEngine.evaluate("5/0", true)
        assertTrue(division.isFailure)
        assertTrue(division.exceptionOrNull()?.message?.contains("dividir entre cero") == true)

        val raiz = CalculatorEngine.evaluate("sqrt(-9)", true)
        assertTrue(raiz.isFailure)

        val parentesis = CalculatorEngine.evaluate("(2+3", true)
        assertTrue(parentesis.exceptionOrNull()?.message?.contains("paréntesis") == true)
    }

    @Test
    fun `el formato de pantalla limpia la basura de la coma flotante`() {
        val suma = CalculatorEngine.evaluate("0.1+0.2", true).getOrThrow()
        assertEquals("0.3", CalculatorEngine.format(suma))
        assertEquals("100", CalculatorEngine.format(100.0))
    }

    @Test
    fun `convierte decimales periodicos a fraccion`() {
        assertEquals("1/3", CalculatorEngine.toFraction(1.0 / 3.0))
        assertEquals("3/4", CalculatorEngine.toFraction(0.75))
    }

    // ---------------- Conversor ----------------

    @Test
    fun `los factores de longitud son los oficiales`() {
        val metros = UnitLab.category("Longitud")
        val pulgada = metros.units.first { it.symbol == "in" }
        val centimetro = metros.units.first { it.symbol == "cm" }
        assertEquals(2.54, UnitLab.convert(1.0, pulgada, centimetro), 1e-12)

        val milla = metros.units.first { it.symbol == "mi" }
        val kilometro = metros.units.first { it.symbol == "km" }
        assertEquals(1.609344, UnitLab.convert(1.0, milla, kilometro), 1e-12)
    }

    @Test
    fun `la libra pesa exactamente lo que dice el acuerdo internacional`() {
        val masa = UnitLab.category("Masa")
        val libra = masa.units.first { it.symbol == "lb" }
        val kilo = masa.units.first { it.symbol == "kg" }
        assertEquals(0.45359237, UnitLab.convert(1.0, libra, kilo), 1e-12)
    }

    @Test
    fun `el galon estadounidense y el imperial son distintos`() {
        val volumen = UnitLab.category("Volumen")
        val galonUs = volumen.units.first { it.symbol == "gal US" }
        val galonImp = volumen.units.first { it.symbol == "gal imp" }
        val litro = volumen.units.first { it.symbol == "L" }
        assertEquals(3.785411784, UnitLab.convert(1.0, galonUs, litro), 1e-12)
        assertEquals(4.54609, UnitLab.convert(1.0, galonImp, litro), 1e-12)
    }

    @Test
    fun `la temperatura se convierte con desplazamiento, no con factor`() {
        val temperatura = UnitLab.category("Temperatura")
        val celsius = temperatura.units.first { it.symbol == "°C" }
        val fahrenheit = temperatura.units.first { it.symbol == "°F" }
        val kelvin = temperatura.units.first { it.symbol == "K" }

        assertEquals(32.0, UnitLab.convert(0.0, celsius, fahrenheit), 1e-9)
        assertEquals(212.0, UnitLab.convert(100.0, celsius, fahrenheit), 1e-9)
        assertEquals(273.15, UnitLab.convert(0.0, celsius, kelvin), 1e-9)
        assertEquals(-40.0, UnitLab.convert(-40.0, celsius, fahrenheit), 1e-9)
    }

    @Test
    fun `una diferencia de temperatura no lleva desplazamiento`() {
        val temperatura = UnitLab.category("Temperatura")
        val celsius = temperatura.units.first { it.symbol == "°C" }
        val fahrenheit = temperatura.units.first { it.symbol == "°F" }
        assertEquals(9.0, UnitLab.convertDifference(5.0, celsius, fahrenheit), 1e-9)
    }

    @Test
    fun `distingue el kilobyte decimal del binario`() {
        val datos = UnitLab.category("Datos digitales")
        val byte = datos.units.first { it.symbol == "B" }
        val kb = datos.units.first { it.symbol == "kB" }
        val kib = datos.units.first { it.symbol == "KiB" }
        assertEquals(1000.0, UnitLab.convert(1.0, kb, byte), 1e-9)
        assertEquals(1024.0, UnitLab.convert(1.0, kib, byte), 1e-9)

        // Un disco de 1 TB decimal son unos 931 GiB
        val tb = datos.units.first { it.symbol == "TB" }
        val gib = datos.units.first { it.symbol == "GiB" }
        assertEquals(931.32, UnitLab.convert(1.0, tb, gib), 0.01)
    }

    @Test
    fun `avisa de las unidades que cambian segun el pais`() {
        val longitud = UnitLab.category("Longitud")
        val cuadra = longitud.units.first { it.symbol == "cuadra" }
        val metro = longitud.units.first { it.symbol == "m" }
        assertNotNull(UnitLab.regionalWarning(cuadra, metro))
    }

    // ---------------- Porcentajes ----------------

    @Test
    fun `porcentaje de una cantidad`() {
        val respuesta = PercentLab.percentOf(200.0, 15.0)
        assertTrue(respuesta.headline.contains("30"))
    }

    @Test
    fun `el precio antes del descuento se calcula dividiendo`() {
        val respuesta = PercentLab.originalBeforeDiscount(80.0, 20.0)
        assertTrue(respuesta.headline.contains("100"))
    }

    @Test
    fun `dos descuentos encadenados no se suman`() {
        val respuesta = PercentLab.chainedDiscounts(100.0, listOf(20.0, 10.0))
        // 100 -> 80 -> 72, es decir 28 % y no 30 %
        assertTrue(respuesta.headline.contains("72"))
        assertTrue(respuesta.headline.contains("28"))
    }

    @Test
    fun `saca el IGV de un precio que ya lo incluye`() {
        val respuesta = PercentLab.tax(118.0, 18.0, included = true)
        assertTrue(respuesta.headline.contains("100"))
        assertTrue(respuesta.headline.contains("18"))
    }

    @Test
    fun `agrega el IGV a un valor de venta`() {
        val respuesta = PercentLab.tax(100.0, 18.0, included = false)
        assertTrue(respuesta.headline.contains("118"))
    }

    @Test
    fun `regla de tres directa e inversa`() {
        val directa = PercentLab.ruleOfThree(2.0, 10.0, 5.0, direct = true)
        assertTrue(directa.headline.contains("25"))

        val inversa = PercentLab.ruleOfThree(20.0, 10.0, 40.0, direct = false)
        assertTrue(inversa.headline.contains("5"))
    }

    @Test
    fun `regla de tres compuesta con magnitudes inversas`() {
        // 3 obreros, 6 h/día tardan 5 días. Con 5 obreros y 8 h/día: 2.25 días
        val respuesta = PercentLab.compoundRule(
            5.0,
            listOf(
                PercentLab.CompoundMagnitude("Obreros", 3.0, 5.0, direct = false),
                PercentLab.CompoundMagnitude("Horas", 6.0, 8.0, direct = false)
            )
        )
        assertTrue(respuesta.headline.contains("2.25"))
    }

    @Test
    fun `variacion porcentual entre dos valores`() {
        val respuesta = PercentLab.change(40.0, 44.0)
        assertTrue(respuesta.headline.contains("10"))
    }

    // ---------------- Promedios ----------------

    @Test
    fun `calcula las tres medias de Pitagoras`() {
        val datos = AverageLab.analyze(listOf(40.0, 60.0))
        assertEquals(50.0, datos.arithmetic, 1e-9)
        assertEquals(48.0, datos.harmonic!!, 1e-9)
        assertTrue(datos.harmonic!! <= datos.geometric!!)
        assertTrue(datos.geometric!! <= datos.arithmetic)
    }

    @Test
    fun `media ponderada con pesos`() {
        val datos = AverageLab.analyze(listOf(15.0, 12.0), listOf(30.0, 70.0))
        assertEquals(12.9, datos.weighted!!, 1e-9)
    }

    @Test
    fun `mediana y moda`() {
        val datos = AverageLab.analyze(listOf(1.0, 3.0, 3.0, 7.0))
        assertEquals(3.0, datos.median, 1e-9)
        assertEquals(listOf(3.0), datos.mode)
    }

    @Test
    fun `redondeo de notas configurable`() {
        assertEquals(11.0, AverageLab.roundGrade(10.5, halfUp = true), 1e-9)
        assertEquals(10.0, AverageLab.roundGrade(10.5, halfUp = false), 1e-9)
    }

    @Test
    fun `promedio eliminando la peor nota`() {
        assertEquals(15.0, AverageLab.dropLowest(listOf(8.0, 14.0, 16.0)), 1e-9)
    }

    // ---------------- Geometría ----------------

    @Test
    fun `area y perimetro del circulo`() {
        val circulo = GeometryLab.byId("circulo")!!
        val resultados = circulo.compute(mapOf("r" to 2.0))
        assertEquals(Math.PI * 4, resultados.first { it.label == "Área" }.value, 1e-9)
        assertEquals(2 * Math.PI * 2, resultados.first { it.label == "Circunferencia" }.value, 1e-9)
    }

    @Test
    fun `formula de Heron`() {
        val triangulo = GeometryLab.byId("triangulo_heron")!!
        val resultados = triangulo.compute(mapOf("a" to 3.0, "b" to 4.0, "c" to 5.0))
        assertEquals(6.0, resultados.first { it.label == "Área" }.value, 1e-9)
        assertEquals(90.0, resultados.first { it.label == "Ángulo C" }.value, 1e-6)
    }

    @Test
    fun `rechaza tres lados que no forman triangulo`() {
        val triangulo = GeometryLab.byId("triangulo_heron")!!
        val resultado = runCatching { triangulo.compute(mapOf("a" to 1.0, "b" to 2.0, "c" to 10.0)) }
        assertTrue(resultado.isFailure)
    }

    @Test
    fun `volumen de la esfera y del cono`() {
        val esfera = GeometryLab.byId("esfera")!!.compute(mapOf("r" to 3.0))
        assertEquals(113.097, esfera.first { it.label == "Volumen" }.value, 0.001)

        val cono = GeometryLab.byId("cono")!!.compute(mapOf("r" to 3.0, "h" to 4.0))
        assertEquals(5.0, cono.first { it.label == "Generatriz" }.value, 1e-9)
        assertEquals(37.699, cono.first { it.label == "Volumen" }.value, 0.001)
    }

    @Test
    fun `poligono regular de seis lados`() {
        val poligono = GeometryLab.byId("poligono")!!.compute(mapOf("n" to 6.0, "l" to 2.0))
        assertEquals(120.0, poligono.first { it.label == "Ángulo interior" }.value, 1e-9)
        assertEquals(10.392, poligono.first { it.label == "Área" }.value, 0.001)
    }

    @Test
    fun `el casquete no puede ser mas alto que la esfera`() {
        val resultado = runCatching {
            GeometryLab.byId("casquete")!!.compute(mapOf("R" to 5.0, "h" to 12.0))
        }
        assertTrue(resultado.isFailure)
    }

    @Test
    fun `resuelve un triangulo por sus lados`() {
        val solucion = GeometryLab.solveSides(3.0, 4.0, 5.0)
        assertEquals(90.0, solucion.angles.third, 1e-6)
        assertEquals(6.0, solucion.area, 1e-9)
        assertTrue(solucion.kind.contains("rectángulo"))
    }

    @Test
    fun `ley de cosenos con dos lados y el angulo`() {
        val solucion = GeometryLab.solveTwoSidesAngle(3.0, 4.0, 90.0)
        assertEquals(5.0, solucion.sides.third, 1e-9)
    }

    @Test
    fun `teorema de Pitagoras en los dos sentidos`() {
        assertEquals(5.0, GeometryLab.pythagoras(3.0, 4.0, null).second, 1e-9)
        assertEquals(4.0, GeometryLab.pythagoras(3.0, null, 5.0).second, 1e-9)
    }

    @Test
    fun `area de un terreno por sus coordenadas`() {
        val puntos = GeometryLab.parsePoints("0 0\n10 0\n10 8\n0 8")
        assertEquals(80.0, GeometryLab.shoelaceArea(puntos), 1e-9)
        assertEquals(36.0, GeometryLab.polygonPerimeter(puntos), 1e-9)
    }

    @Test
    fun `distancia, punto medio y pendiente`() {
        val p = GeometryLab.Point(0.0, 0.0)
        val q = GeometryLab.Point(3.0, 4.0)
        assertEquals(5.0, GeometryLab.distance(p, q), 1e-9)
        assertEquals(1.5, GeometryLab.midpoint(p, q).x, 1e-9)
        assertEquals(4.0 / 3.0, GeometryLab.slope(p, q)!!, 1e-9)
        assertFalse(GeometryLab.lineEquation(p, q).isBlank())
    }

    @Test
    fun `la pendiente de una recta vertical no existe`() {
        val p = GeometryLab.Point(2.0, 0.0)
        val q = GeometryLab.Point(2.0, 9.0)
        assertTrue(GeometryLab.slope(p, q) == null)
        assertTrue(GeometryLab.lineEquation(p, q).contains("vertical"))
    }

    @Test
    fun `los sufijos de unidad cambian con la dimension`() {
        assertEquals(" m", GeometryLab.unitSuffix(1, "m"))
        assertEquals(" m²", GeometryLab.unitSuffix(2, "m"))
        assertEquals(" m³", GeometryLab.unitSuffix(3, "m"))
        assertEquals("", GeometryLab.unitSuffix(0, "m"))
    }

    @Test
    fun `el formato del conversor usa cifras significativas`() {
        assertEquals("2.54", UnitLab.format(2.54))
        assertTrue(abs(UnitLab.format(1234.5678, 6).toDouble() - 1234.57) < 0.01)
    }
}
