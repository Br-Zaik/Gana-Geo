package com.ganageo.app.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ganageo.app.tools.BalancedEquation
import com.ganageo.app.tools.ChemLab
import com.ganageo.app.tools.ChemicalElement
import com.ganageo.app.tools.ElementCategory
import com.ganageo.app.tools.ElementsCatalog
import com.ganageo.app.tools.FormulaAnalysis
import com.ganageo.app.tools.MathEngine

// ---------------------------------------------------------------------------
// Calculadora de química
// ---------------------------------------------------------------------------

/**
 * Calculadora de química.
 *
 * El balanceo no se hace por tanteo: se plantea el sistema de ecuaciones de
 * conservación de átomos y se resuelve con fracciones exactas, así que funciona
 * igual de bien con una reacción sencilla que con una de combustión larga.
 */
@Composable
fun ChemistryCalculatorScreen(onBack: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var tab by rememberSaveable { mutableIntStateOf(0) }

    ScienceShell(
        title = "Calculadora de química",
        subtitle = "Masa molar, balanceo, disoluciones, gases y pH",
        onBack = onBack
    ) {
        StudioTabs(listOf("Masa molar", "Balanceo", "Disoluciones", "Gases y pH"), tab) { tab = it }
        when (tab) {
            0 -> MolarMassSection(clipboard)
            1 -> BalanceSection()
            2 -> SolutionsSection()
            else -> GasAndPhSection()
        }
    }
}

@Composable
private fun MolarMassSection(clipboard: androidx.compose.ui.platform.ClipboardManager) {
    var formula by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue("Ca(OH)2"))
    }
    var gramsText by rememberSaveable { mutableStateOf("") }
    var molesText by rememberSaveable { mutableStateOf("") }

    val analysis: Result<FormulaAnalysis> = remember(formula.text) {
        runCatching { ChemLab.analyze(formula.text) }
    }

    ScienceCard("Fórmula química") {
        MathInput(
            value = formula,
            onValueChange = { formula = it },
            label = "Compuesto",
            placeholder = "H2SO4, Ca(OH)2, CuSO4·5H2O",
            paletteLayers = com.ganageo.app.ui.tools.MathKeys.chemistry
        )
        StudioChipRow {
            listOf("H2O", "H2SO4", "Ca(OH)2", "NaCl", "C6H12O6", "CuSO4·5H2O", "NaHCO3").forEach { sample ->
                StudioChip(sample, formula.text == sample, onClick = {
                    formula = TextFieldValue(sample, androidx.compose.ui.text.TextRange(sample.length))
                })
            }
        }
        StudioHint("Escribe los subíndices como números normales. El punto · sirve para los hidratos.")
    }

    analysis.exceptionOrNull()?.let { ScienceError(it.message ?: "Fórmula inválida.") }

    analysis.getOrNull()?.let { data ->
        ScienceResult(
            headline = "M = ${MathEngine.formatNumber(data.molarMass, 4)} g/mol",
            caption = "${data.counts.size} elementos · ${data.totalAtoms} átomos por fórmula",
            onCopy = { clipboard.setText(AnnotatedString(MathEngine.formatNumber(data.molarMass, 6))) }
        )

        ScienceCard("Composición porcentual") {
            data.composition.forEach { (symbol, mass, percent) ->
                val element = ElementsCatalog.bySymbol(symbol)
                Column {
                    ScienceRow(
                        "${element?.name ?: symbol} ($symbol) × ${data.counts[symbol]}",
                        "${MathEngine.formatNumber(percent, 2)} %"
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(StudioTheme.Outline)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth((percent / 100).toFloat().coerceIn(0f, 1f))
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(
                                    element?.category?.let { Color(it.colorArgb) } ?: StudioTheme.Accent
                                )
                        )
                    }
                    Text(
                        "Aporta ${MathEngine.formatNumber(mass, 4)} g/mol",
                        color = StudioTheme.TextSecondary,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        ScienceCard("Gramos y moles") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScienceNumberField(gramsText, {
                    gramsText = it
                    val g = it.toScienceDouble()
                    molesText = if (g == null) "" else MathEngine.formatNumber(g / data.molarMass, 6)
                }, "Gramos", Modifier.weight(1f))
                ScienceNumberField(molesText, {
                    molesText = it
                    val m = it.toScienceDouble()
                    gramsText = if (m == null) "" else MathEngine.formatNumber(m * data.molarMass, 6)
                }, "Moles", Modifier.weight(1f))
            }
            molesText.toScienceDouble()?.let { moles ->
                ScienceRow(
                    "Número de partículas",
                    MathEngine.formatNumber(ChemLab.particles(moles), 4),
                    highlight = true
                )
                StudioHint("Un mol contiene 6,02214076×10²³ partículas (número de Avogadro, exacto por definición).")
            }
        }
    }
}

@Composable
private fun BalanceSection() {
    var equation by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue("C3H8 + O2 → CO2 + H2O"))
    }
    var balanced by remember { mutableStateOf<BalancedEquation?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var knownFormula by rememberSaveable { mutableStateOf("") }
    var knownMoles by rememberSaveable { mutableStateOf("1") }

    ScienceCard("Ecuación química") {
        MathInput(
            value = equation,
            onValueChange = { equation = it },
            label = "Reacción",
            placeholder = "H2 + O2 → H2O",
            paletteLayers = com.ganageo.app.ui.tools.MathKeys.chemistry
        )
        StudioChipRow {
            listOf(
                "H2 + O2 → H2O",
                "C3H8 + O2 → CO2 + H2O",
                "Fe + O2 → Fe2O3",
                "KMnO4 + HCl → KCl + MnCl2 + H2O + Cl2"
            ).forEach { sample ->
                StudioChip(sample.take(22), false, onClick = {
                    equation = TextFieldValue(sample, androidx.compose.ui.text.TextRange(sample.length))
                })
            }
        }
    }

    ChemistryActionButton("Balancear") {
        runCatching { ChemLab.balance(equation.text) }
            .onSuccess {
                balanced = it
                knownFormula = it.reactants.first().second
                error = null
            }
            .onFailure {
                balanced = null
                error = it.message ?: "No se pudo balancear."
            }
    }

    error?.let { ScienceError(it) }

    balanced?.let { result ->
        ScienceResult(result.text, "Coeficientes mínimos enteros")
        StepsSection(result.steps, "Álgebra lineal")

        ScienceCard("Estequiometría") {
            StudioLabel("Sustancia conocida")
            StudioChipRow {
                (result.reactants + result.products).forEach { (_, name) ->
                    StudioChip(name, knownFormula == name, onClick = { knownFormula = name })
                }
            }
            ScienceNumberField(knownMoles, { knownMoles = it }, "Moles de $knownFormula", Modifier.fillMaxWidth())
            val moles = knownMoles.toScienceDouble()
            if (moles != null && knownFormula.isNotEmpty()) {
                val table = runCatching { ChemLab.stoichiometry(result, knownFormula, moles) }.getOrNull()
                table?.forEach { (name, mol, grams) ->
                    ScienceRow(
                        name,
                        "${MathEngine.formatNumber(mol, 4)} mol  ·  ${MathEngine.formatNumber(grams, 3)} g",
                        highlight = name == knownFormula
                    )
                }
                StudioHint("Las cantidades se obtienen con la proporción entre coeficientes de la ecuación balanceada.")
            }
        }
    }
}

@Composable
private fun SolutionsSection() {
    var moles by rememberSaveable { mutableStateOf("0.5") }
    var liters by rememberSaveable { mutableStateOf("2") }
    var kilos by rememberSaveable { mutableStateOf("1") }
    var c1 by rememberSaveable { mutableStateOf("2") }
    var v1 by rememberSaveable { mutableStateOf("50") }
    var c2 by rememberSaveable { mutableStateOf("0.5") }

    ScienceCard("Concentración") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ScienceNumberField(moles, { moles = it }, "Moles de soluto", Modifier.weight(1f))
            ScienceNumberField(liters, { liters = it }, "Litros de disolución", Modifier.weight(1f))
        }
        val n = moles.toScienceDouble()
        val v = liters.toScienceDouble()
        if (n != null && v != null && v > 0) {
            ScienceRow("Molaridad (M)", "${MathEngine.formatNumber(n / v, 5)} mol/L", highlight = true)
        }
        ScienceNumberField(kilos, { kilos = it }, "Kilos de disolvente", Modifier.fillMaxWidth())
        val kg = kilos.toScienceDouble()
        if (n != null && kg != null && kg > 0) {
            ScienceRow("Molalidad (m)", "${MathEngine.formatNumber(n / kg, 5)} mol/kg")
        }
        StudioHint("La molaridad usa el volumen total de la disolución; la molalidad, la masa del disolvente.")
    }

    ScienceCard("Dilución C₁V₁ = C₂V₂") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ScienceNumberField(c1, { c1 = it }, "C₁ (mol/L)", Modifier.weight(1f))
            ScienceNumberField(v1, { v1 = it }, "V₁ (mL)", Modifier.weight(1f))
        }
        ScienceNumberField(c2, { c2 = it }, "C₂ final (mol/L)", Modifier.fillMaxWidth())
        val a = c1.toScienceDouble()
        val b = v1.toScienceDouble()
        val c = c2.toScienceDouble()
        if (a != null && b != null && c != null && c > 0) {
            val finalVolume = ChemLab.dilution(a, b, c)
            ScienceRow("Volumen final V₂", "${MathEngine.formatNumber(finalVolume, 3)} mL", highlight = true)
            ScienceRow("Agua a agregar", "${MathEngine.formatNumber(finalVolume - b, 3)} mL")
        }
    }
}

@Composable
private fun GasAndPhSection() {
    var pressure by rememberSaveable { mutableStateOf("1") }
    var volume by rememberSaveable { mutableStateOf("22.4") }
    var molesGas by rememberSaveable { mutableStateOf("1") }
    var temperature by rememberSaveable { mutableStateOf("") }
    var gasResult by remember { mutableStateOf<Pair<String, Double>?>(null) }
    var gasError by remember { mutableStateOf<String?>(null) }

    var concentration by rememberSaveable { mutableStateOf("0.01") }
    var isAcid by rememberSaveable { mutableStateOf(true) }

    ScienceCard("Gases ideales · PV = nRT") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ScienceNumberField(pressure, { pressure = it }, "P (atm)", Modifier.weight(1f))
            ScienceNumberField(volume, { volume = it }, "V (L)", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ScienceNumberField(molesGas, { molesGas = it }, "n (mol)", Modifier.weight(1f))
            ScienceNumberField(temperature, { temperature = it }, "T (K)", Modifier.weight(1f))
        }
        StudioHint("Deja en blanco el dato que quieres calcular. La temperatura va en kelvin: °C + 273,15.")
    }
    ChemistryActionButton("Calcular gas") {
        runCatching {
            ChemLab.idealGas(
                pressure.toScienceDouble(),
                volume.toScienceDouble(),
                molesGas.toScienceDouble(),
                temperature.toScienceDouble()
            )
        }.onSuccess {
            gasResult = it
            gasError = null
        }.onFailure {
            gasResult = null
            gasError = it.message ?: "Revisa los datos."
        }
    }
    gasError?.let { ScienceError(it) }
    gasResult?.let { (label, value) ->
        ScienceResult("$label = ${MathEngine.formatNumber(value, 5)}")
    }

    ScienceCard("pH y pOH") {
        StudioChipRow {
            StudioChip("Ácido [H⁺]", isAcid, onClick = { isAcid = true })
            StudioChip("Base [OH⁻]", !isAcid, onClick = { isAcid = false })
        }
        ScienceNumberField(
            concentration,
            { concentration = it },
            if (isAcid) "Concentración [H⁺] (mol/L)" else "Concentración [OH⁻] (mol/L)",
            Modifier.fillMaxWidth()
        )
        val value = concentration.toScienceDouble()
        if (value != null && value > 0) {
            val result = ChemLab.fromConcentration(value, isAcid)
            ScienceRow("pH", MathEngine.formatNumber(result.ph, 3), highlight = true)
            ScienceRow("pOH", MathEngine.formatNumber(result.poh, 3))
            ScienceRow("[H⁺]", "${MathEngine.formatNumber(result.hydrogen, 4)} mol/L")
            ScienceRow("[OH⁻]", "${MathEngine.formatNumber(result.hydroxide, 4)} mol/L")
            ScienceRow("Carácter", result.nature)
            PhScale(result.ph)
            StudioHint("Cálculo válido para ácidos y bases fuertes, que se disocian por completo.")
        }
    }
}

@Composable
private fun PhScale(ph: Double) {
    val position = (ph / 14.0).coerceIn(0.0, 1.0).toFloat()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(18.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(
                    androidx.compose.ui.graphics.Brush.horizontalGradient(
                        listOf(
                            Color(0xFFE53935),
                            Color(0xFFFFB300),
                            Color(0xFF66BB6A),
                            Color(0xFF29B6F6),
                            Color(0xFF7E57C2)
                        )
                    )
                )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(position)
                    .height(18.dp)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .width(3.dp)
                        .height(18.dp)
                        .background(Color.White)
                )
            }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            Text("0 ácido", color = StudioTheme.TextSecondary, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.weight(1f))
            Text("7 neutro", color = StudioTheme.TextSecondary, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.weight(1f))
            Text("14 básico", color = StudioTheme.TextSecondary, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun ChemistryActionButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = StudioTheme.Accent,
            contentColor = StudioTheme.OnAccent
        )
    ) {
        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
        Text("  $text", fontWeight = FontWeight.Bold)
    }
}

// ---------------------------------------------------------------------------
// Tabla periódica
// ---------------------------------------------------------------------------

/**
 * Tabla periódica interactiva.
 *
 * La tabla larga no cabe legible en un teléfono en vertical, así que se muestra
 * completa con desplazamiento en los dos ejes y celdas de tamaño cómodo para el
 * dedo. Al tocar un elemento se abre su ficha a pantalla completa.
 */
@Composable
fun PeriodicTableScreen(onBack: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var colorBy by rememberSaveable { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<ChemicalElement?>(null) }
    var cellSize by rememberSaveable { mutableFloatStateOf(54f) }

    val matches = remember(query) { ElementsCatalog.search(query).map { it.number }.toSet() }
    val filtering = query.isNotBlank()

    val element = selected
    if (element != null) {
        ElementDetail(element) { selected = null }
        return
    }

    ScienceStage(
        title = "Tabla periódica",
        subtitle = "118 elementos · masas IUPAC 2021",
        onBack = onBack,
        stage = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .horizontalScroll(rememberScrollState())
                    .padding(10.dp)
            ) {
                (1..7).forEach { period ->
                    PeriodicRow(period, cellSize, colorBy, matches, filtering) { selected = it }
                }
                Spacer(Modifier.height(10.dp))
                (9..10).forEach { row ->
                    PeriodicRow(row, cellSize, colorBy, matches, filtering) { selected = it }
                }
            }
        },
        panel = {
            StudioPanel(maxHeight = 250.dp) {
                StudioTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = "Buscar elemento",
                    placeholder = "Nombre, símbolo o número atómico",
                    modifier = Modifier.fillMaxWidth()
                )
                if (filtering) {
                    val found = ElementsCatalog.search(query)
                    StudioHint("${found.size} coincidencias. Los demás se ven atenuados.")
                    if (found.size in 1..6) {
                        StudioChipRow {
                            found.forEach { item ->
                                StudioChip(
                                    label = "${item.symbol} · ${item.name}",
                                    active = false,
                                    onClick = { selected = item }
                                )
                            }
                        }
                    }
                }
                StudioLabel("Colorear por")
                StudioChipRow {
                    listOf("Familia", "Bloque", "Estado").forEachIndexed { index, label ->
                        StudioChip(label, colorBy == index, onClick = { colorBy = index })
                    }
                }
                StudioLabel("Tamaño de las celdas", "${cellSize.toInt()} dp")
                StudioSlider(
                    label = "Zoom",
                    valueText = "${cellSize.toInt()} dp",
                    value = cellSize,
                    range = 40f..80f
                ) { cellSize = it }
                LegendRow(colorBy)
            }
        }
    )
}

@Composable
private fun PeriodicRow(
    row: Int,
    cellSize: Float,
    colorBy: Int,
    matches: Set<Int>,
    filtering: Boolean,
    onSelect: (ChemicalElement) -> Unit
) {
    val byPosition = remember(row) {
        ElementsCatalog.elements.filter { ElementsCatalog.gridPosition(it.number).first == row }
            .associateBy { ElementsCatalog.gridPosition(it.number).second }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        (1..18).forEach { column ->
            val item = byPosition[column]
            if (item == null) {
                Spacer(Modifier.size(cellSize.dp))
            } else {
                ElementTile(item, cellSize, colorBy, filtering && item.number !in matches, onSelect)
            }
        }
    }
    Spacer(Modifier.height(3.dp))
}

@Composable
private fun ElementTile(
    element: ChemicalElement,
    cellSize: Float,
    colorBy: Int,
    dimmed: Boolean,
    onSelect: (ChemicalElement) -> Unit
) {
    val color = tileColor(element, colorBy)
    Column(
        modifier = Modifier
            .size(cellSize.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (dimmed) color.copy(alpha = 0.10f) else color.copy(alpha = 0.28f))
            .border(
                1.dp,
                if (dimmed) Color.Transparent else color.copy(alpha = 0.7f),
                RoundedCornerShape(8.dp)
            )
            .clickable { onSelect(element) }
            .padding(2.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            element.number.toString(),
            color = if (dimmed) StudioTheme.TextSecondary.copy(alpha = 0.5f) else StudioTheme.TextSecondary,
            fontSize = (cellSize * 0.16f).sp,
            lineHeight = (cellSize * 0.2f).sp
        )
        Text(
            element.symbol,
            color = if (dimmed) StudioTheme.TextSecondary.copy(alpha = 0.5f) else StudioTheme.TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = (cellSize * 0.33f).sp,
            lineHeight = (cellSize * 0.36f).sp
        )
        if (cellSize > 50) {
            Text(
                element.name.take(8),
                color = if (dimmed) StudioTheme.TextSecondary.copy(alpha = 0.4f) else StudioTheme.TextSecondary,
                fontSize = (cellSize * 0.13f).sp,
                lineHeight = (cellSize * 0.16f).sp,
                maxLines = 1
            )
        }
    }
}

private fun tileColor(element: ChemicalElement, colorBy: Int): Color = when (colorBy) {
    1 -> when (element.block) {
        "s" -> Color(0xFFFF7043)
        "p" -> Color(0xFF4DB6AC)
        "d" -> Color(0xFF64B5F6)
        else -> Color(0xFFBA68C8)
    }
    2 -> when (element.stateAt25C) {
        "Sólido" -> Color(0xFF81C784)
        "Líquido" -> Color(0xFF4FC3F7)
        "Gas" -> Color(0xFFFFB74D)
        else -> Color(0xFF90A4AE)
    }
    else -> Color(element.category.colorArgb)
}

@Composable
private fun LegendRow(colorBy: Int) {
    val entries: List<Pair<String, Color>> = when (colorBy) {
        1 -> listOf(
            "Bloque s" to Color(0xFFFF7043),
            "Bloque p" to Color(0xFF4DB6AC),
            "Bloque d" to Color(0xFF64B5F6),
            "Bloque f" to Color(0xFFBA68C8)
        )
        2 -> listOf(
            "Sólido" to Color(0xFF81C784),
            "Líquido" to Color(0xFF4FC3F7),
            "Gas" to Color(0xFFFFB74D),
            "Sintético" to Color(0xFF90A4AE)
        )
        else -> ElementCategory.entries.map { it.label to Color(it.colorArgb) }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        entries.forEach { (label, color) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(color)
                )
                Spacer(Modifier.width(5.dp))
                Text(label, color = StudioTheme.TextSecondary, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun ElementDetail(element: ChemicalElement, onClose: () -> Unit) {
    var temperature by rememberSaveable { mutableFloatStateOf(298f) }
    val color = Color(element.category.colorArgb)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioTheme.Background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = StudioTheme.TextPrimary)
            }
            Text(
                element.name,
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(color.copy(alpha = 0.18f))
                    .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        element.number.toString(),
                        color = StudioTheme.TextSecondary,
                        style = MaterialTheme.typography.labelMedium
                    )
                    Text(
                        element.symbol,
                        color = StudioTheme.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 52.sp,
                        lineHeight = 58.sp
                    )
                    Text(
                        element.category.label,
                        color = color,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        MathEngine.formatNumber(element.mass, 4),
                        color = StudioTheme.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )
                    Text(
                        if (element.massIsMostStable) "u (isótopo más estable)" else "u (masa atómica)",
                        color = StudioTheme.TextSecondary,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            element.massNote?.let {
                ScienceCard(null) {
                    StudioHint("$it. La composición isotópica de este elemento varía en la naturaleza, por eso la IUPAC publica un intervalo.")
                }
            }

            ScienceCard("Posición en la tabla") {
                ScienceRow("Número atómico", element.number.toString())
                ScienceRow("Periodo", element.period.toString())
                ScienceRow("Grupo", element.group?.toString() ?: "—  (lantánido o actínido)")
                ScienceRow("Bloque", element.block)
                ScienceRow("Configuración electrónica", element.electronConfiguration, highlight = true)
                ElementsCatalog.valenceElectrons(element.number)?.let {
                    ScienceRow("Electrones de valencia", it.toString())
                }
            }

            ScienceCard("Propiedades") {
                ScienceRow(
                    "Electronegatividad (Pauling)",
                    element.electronegativity?.let { MathEngine.formatNumber(it, 2) } ?: "—"
                )
                ScienceRow("Punto de fusión", ElementsCatalog.formatTemperature(element.meltingPointK))
                ScienceRow("Punto de ebullición", ElementsCatalog.formatTemperature(element.boilingPointK))
                ScienceRow(
                    "Densidad",
                    element.density?.let { "${MathEngine.formatNumber(it, 3)} g/cm³" } ?: "—"
                )
                ScienceRow("Estado a 25 °C", element.stateAt25C)
            }

            if (element.meltingPointK != null) {
                ScienceCard("Estado según la temperatura") {
                    StudioSlider(
                        label = "Temperatura",
                        valueText = "${MathEngine.formatNumber(temperature.toDouble() - 273.15, 0)} °C",
                        value = temperature,
                        range = 1f..6000f
                    ) { temperature = it }
                    ScienceResult(
                        ElementsCatalog.stateAt(element, temperature.toDouble()),
                        "A ${MathEngine.formatNumber(temperature.toDouble(), 0)} K"
                    )
                }
            }

            if (element.use.isNotBlank()) {
                ScienceCard("Para qué se usa") {
                    Text(
                        element.use,
                        color = StudioTheme.TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}
