package com.ganageo.app.ui.tools

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.AdvancedFileUtils
import com.ganageo.app.tools.ImageStudioPresets
import com.ganageo.app.tools.ToolFileUtils
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private const val MAX_BATCH_IMAGES = 50

/**
 * Estudio por lote a pantalla completa.
 *
 * Mismo esquema que el resto de herramientas de imagen: lienzo con las fotos
 * elegidas, pestanas abajo y un solo boton para exportar. El orden de las
 * miniaturas es el orden real que tendran el collage, la union y la hoja de
 * carnet, por eso se puede reordenar tocando las flechas.
 */
@Composable
fun ImageBatchStudioScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var inputUriTexts by rememberSaveable { mutableStateOf<List<String>>(emptyList()) }
    var modeIndex by rememberSaveable {
        mutableIntStateOf(AdvancedFileUtils.BatchImageMode.COMPRESS.ordinal)
    }
    var formatIndex by rememberSaveable { mutableIntStateOf(0) }
    var quality by rememberSaveable { mutableFloatStateOf(85f) }
    var maxEdgeText by rememberSaveable { mutableStateOf("1600") }
    var colorIndex by rememberSaveable { mutableIntStateOf(0) }
    var columns by rememberSaveable { mutableFloatStateOf(2f) }
    var frameWidth by rememberSaveable { mutableFloatStateOf(24f) }
    var passportWidth by rememberSaveable { mutableStateOf("35") }
    var passportHeight by rememberSaveable { mutableStateOf("45") }
    var passportCopies by rememberSaveable { mutableStateOf("8") }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var processing by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }

    val thumbnails = remember { mutableStateMapOf<String, Bitmap>() }
    val inputs = inputUriTexts.map(Uri::parse)
    val mode = AdvancedFileUtils.BatchImageMode.entries[
        modeIndex.coerceIn(0, AdvancedFileUtils.BatchImageMode.entries.lastIndex)
    ]

    val formats = listOf("JPG", "PNG", "WebP")
    val colors = listOf("Blanco", "Negro", "Gris", "Azul claro")
    val colorValues = listOf(
        android.graphics.Color.WHITE,
        android.graphics.Color.BLACK,
        android.graphics.Color.LTGRAY,
        android.graphics.Color.rgb(220, 235, 255)
    )

    fun addImages(selected: List<Uri>, persist: Boolean) {
        if (selected.isEmpty()) return
        if (persist) {
            selected.forEach { uri ->
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
            }
        }
        val combined = (inputUriTexts + selected.map(Uri::toString)).distinct()
        inputUriTexts = combined.take(MAX_BATCH_IMAGES)
        if (combined.size > MAX_BATCH_IMAGES) {
            onMessage("Puedes procesar hasta $MAX_BATCH_IMAGES imágenes.")
        }
    }

    val galleryPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(MAX_BATCH_IMAGES)
    ) { selected -> addImages(selected, persist = false) }

    val filesPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { selected -> addImages(selected, persist = true) }

    LaunchedEffect(inputUriTexts) {
        inputUriTexts.forEach { key ->
            if (!thumbnails.containsKey(key)) {
                runCatching { ToolFileUtils.loadBitmap(context, Uri.parse(key), maxEdge = 256) }
                    .onSuccess { thumbnails[key] = it }
            }
        }
        // Libera las miniaturas de imágenes que ya se quitaron del lote.
        thumbnails.keys.toList().forEach { key ->
            if (key !in inputUriTexts) {
                thumbnails.remove(key)?.takeIf { !it.isRecycled }?.recycle()
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            thumbnails.values.forEach { bitmap ->
                if (!bitmap.isRecycled) bitmap.recycle()
            }
            thumbnails.clear()
        }
    }

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { folder ->
        if (folder == null || inputs.isEmpty()) return@rememberLauncherForActivityResult
        val format = when (formatIndex) {
            1 -> Bitmap.CompressFormat.PNG
            2 -> Bitmap.CompressFormat.WEBP
            else -> Bitmap.CompressFormat.JPEG
        }
        val options = AdvancedFileUtils.BatchImageOptions(
            mode = mode,
            outputFormat = format,
            quality = quality.roundToInt(),
            maxEdge = maxEdgeText.toIntOrNull() ?: 1600,
            backgroundColor = colorValues[colorIndex.coerceIn(0, colorValues.lastIndex)],
            frameWidth = frameWidth.roundToInt(),
            columns = columns.roundToInt(),
            passportWidthMm = passportWidth.replace(',', '.').toDoubleOrNull() ?: 35.0,
            passportHeightMm = passportHeight.replace(',', '.').toDoubleOrNull() ?: 45.0,
            passportCopies = passportCopies.toIntOrNull() ?: 8
        )
        processing = true
        progress = 0f
        scope.launch {
            runPaidTool(viewModel, tool) {
                AdvancedFileUtils.processImageBatch(context, inputs, folder, options) { done, total ->
                    scope.launch { progress = done.toFloat() / total.coerceAtLeast(1) }
                }
            }.onSuccess { awarded ->
                onMessage(successMessage("Lote procesado correctamente.", awarded))
            }.onFailure {
                onMessage(it.message ?: "No se pudo procesar el lote.")
            }
            processing = false
            progress = 0f
        }
    }

    fun onExport() {
        if (inputs.isEmpty()) {
            onMessage("Selecciona al menos una imagen.")
            return
        }
        val maxEdge = maxEdgeText.toIntOrNull()
        if (maxEdge == null || maxEdge !in 256..8192) {
            onMessage("El lado máximo debe estar entre 256 y 8192 px.")
            return
        }
        if (mode == AdvancedFileUtils.BatchImageMode.PASSPORT_SHEET && inputs.size > 1) {
            onMessage("La hoja de carnet usa la primera imagen del lote.")
        }
        launchPaidExport(viewModel, tool, onMessage) { folderPicker.launch(null) }
    }

    if (inputs.isEmpty()) {
        StudioPicker(
            title = tool.title,
            description = "Procesa hasta $MAX_BATCH_IMAGES imágenes de una sola vez y guárdalas en la carpeta que elijas.",
            features = listOf(
                "Comprimir, cambiar tamaño o convertir todo el lote",
                "Unir en vertical u horizontal y crear collages",
                "Hoja de fotos carnet lista para imprimir en A4",
                "Fondo sólido, marco y exportación a ZIP",
                "Quitar metadatos EXIF de todas las fotos"
            ),
            creditCost = tool.creditCost,
            multiple = true,
            onBack = onBack,
            onGallery = {
                galleryPicker.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onFiles = { filesPicker.launch(arrayOf("image/*")) },
            onCamera = null
        )
        return
    }

    val totalBytes = remember(inputUriTexts) {
        inputs.sumOf { ToolFileUtils.fileSize(context, it) }
    }

    StudioShell(
        title = "Estudio por lote",
        subtitle = "${inputs.size} imágenes · ${ToolFileUtils.readableSize(totalBytes)}",
        saving = processing,
        saveLabel = "Exportar",
        saveEnabled = inputs.isNotEmpty(),
        onClose = onBack,
        onReset = {
            inputUriTexts = emptyList()
            tab = 0
        },
        onSave = { onExport() },
        canvas = {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(inputUriTexts, key = { _, key -> key }) { index, key ->
                    BatchThumbnail(
                        bitmap = thumbnails[key],
                        index = index,
                        enabled = !processing,
                        canMoveBack = index > 0,
                        canMoveForward = index < inputUriTexts.lastIndex,
                        onRemove = {
                            inputUriTexts = inputUriTexts.filterNot { it == key }
                        },
                        onMoveBack = {
                            val list = inputUriTexts.toMutableList()
                            if (index > 0) {
                                val item = list.removeAt(index)
                                list.add(index - 1, item)
                                inputUriTexts = list
                            }
                        },
                        onMoveForward = {
                            val list = inputUriTexts.toMutableList()
                            if (index < list.lastIndex) {
                                val item = list.removeAt(index)
                                list.add(index + 1, item)
                                inputUriTexts = list
                            }
                        }
                    )
                }
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(StudioTheme.Surface)
                            .border(1.dp, StudioTheme.Outline, RoundedCornerShape(14.dp))
                            .clickable(enabled = !processing) {
                                galleryPicker.launch(
                                    PickVisualMediaRequest(
                                        ActivityResultContracts.PickVisualMedia.ImageOnly
                                    )
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Rounded.Add,
                                contentDescription = "Añadir imágenes",
                                tint = StudioTheme.Accent
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Añadir",
                                color = StudioTheme.TextSecondary,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
            if (processing) {
                StudioProgressOverlay("Procesando ${inputs.size} imágenes", progress)
            }
        },
        panel = {
            StudioPanel {
                when (tab) {
                    0 -> {
                        StudioLabel("Operación")
                        StudioChipRow {
                            AdvancedFileUtils.BatchImageMode.entries.forEachIndexed { index, entry ->
                                StudioChip(
                                    label = entry.label,
                                    active = modeIndex == index,
                                    onClick = { modeIndex = index }
                                )
                            }
                        }
                        StudioHint(batchModeHint(mode))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StudioSecondaryButton(
                                label = "Galería",
                                icon = Icons.Rounded.Image,
                                onClick = {
                                    galleryPicker.launch(
                                        PickVisualMediaRequest(
                                            ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                },
                                modifier = Modifier.weight(1f),
                                enabled = !processing
                            )
                            StudioSecondaryButton(
                                label = "Archivos",
                                icon = Icons.Rounded.Folder,
                                onClick = { filesPicker.launch(arrayOf("image/*")) },
                                modifier = Modifier.weight(1f),
                                enabled = !processing
                            )
                        }
                    }
                    else -> {
                        if (mode != AdvancedFileUtils.BatchImageMode.ZIP_ORIGINALS) {
                            StudioLabel("Formato")
                            StudioChipRow {
                                formats.forEachIndexed { index, label ->
                                    StudioChip(
                                        label = label,
                                        active = formatIndex == index,
                                        onClick = { formatIndex = index }
                                    )
                                }
                            }
                            if (formatIndex != 1) {
                                StudioSlider(
                                    label = "Calidad",
                                    valueText = "${quality.roundToInt()} %",
                                    value = quality,
                                    range = 30f..100f
                                ) { quality = it }
                            }
                        }

                        if (mode in setOf(
                                AdvancedFileUtils.BatchImageMode.COMPRESS,
                                AdvancedFileUtils.BatchImageMode.RESIZE,
                                AdvancedFileUtils.BatchImageMode.JOIN_VERTICAL,
                                AdvancedFileUtils.BatchImageMode.JOIN_HORIZONTAL,
                                AdvancedFileUtils.BatchImageMode.COLLAGE
                            )
                        ) {
                            StudioChipRow {
                                listOf(800, 1080, 1600, 2048, 3200).forEach { edge ->
                                    StudioChip(
                                        label = "$edge px",
                                        active = maxEdgeText == edge.toString(),
                                        onClick = { maxEdgeText = edge.toString() }
                                    )
                                }
                            }
                            StudioNumberField(
                                value = maxEdgeText,
                                onValueChange = { maxEdgeText = it },
                                label = "Lado máximo por imagen",
                                modifier = Modifier.fillMaxWidth(),
                                maxLength = 4
                            )
                        }

                        if (mode in setOf(
                                AdvancedFileUtils.BatchImageMode.SOLID_BACKGROUND,
                                AdvancedFileUtils.BatchImageMode.FRAME,
                                AdvancedFileUtils.BatchImageMode.JOIN_VERTICAL,
                                AdvancedFileUtils.BatchImageMode.JOIN_HORIZONTAL,
                                AdvancedFileUtils.BatchImageMode.COLLAGE
                            )
                        ) {
                            StudioLabel("Color de fondo")
                            StudioChipRow {
                                colors.forEachIndexed { index, label ->
                                    StudioChip(
                                        label = label,
                                        active = colorIndex == index,
                                        onClick = { colorIndex = index }
                                    )
                                }
                            }
                        }

                        if (mode == AdvancedFileUtils.BatchImageMode.FRAME) {
                            StudioSlider(
                                label = "Grosor del marco",
                                valueText = "${frameWidth.roundToInt()} px",
                                value = frameWidth,
                                range = 2f..160f
                            ) { frameWidth = it }
                        }

                        if (mode == AdvancedFileUtils.BatchImageMode.COLLAGE) {
                            StudioSlider(
                                label = "Columnas",
                                valueText = columns.roundToInt().toString(),
                                value = columns,
                                range = 1f..5f
                            ) { columns = it }
                        }

                        if (mode == AdvancedFileUtils.BatchImageMode.PASSPORT_SHEET) {
                            StudioLabel("Medidas de carnet")
                            StudioChipRow {
                                ImageStudioPresets.idPhotos.forEach { preset ->
                                    StudioChip(
                                        label = preset.label,
                                        active = passportWidth == trimNumber(preset.widthMm) &&
                                            passportHeight == trimNumber(preset.heightMm),
                                        onClick = {
                                            passportWidth = trimNumber(preset.widthMm)
                                            passportHeight = trimNumber(preset.heightMm)
                                        }
                                    )
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StudioNumberField(
                                    value = passportWidth,
                                    onValueChange = { passportWidth = it },
                                    label = "Ancho mm",
                                    modifier = Modifier.weight(1f),
                                    decimal = true
                                )
                                StudioNumberField(
                                    value = passportHeight,
                                    onValueChange = { passportHeight = it },
                                    label = "Alto mm",
                                    modifier = Modifier.weight(1f),
                                    decimal = true
                                )
                                StudioNumberField(
                                    value = passportCopies,
                                    onValueChange = { passportCopies = it },
                                    label = "Copias",
                                    modifier = Modifier.width(96.dp),
                                    maxLength = 2
                                )
                            }
                            StudioHint("Se genera una hoja A4 a 300 dpi con la primera imagen del lote. Verifica la medida oficial de tu trámite.")
                        }

                        StudioHint("El lote se procesa en el teléfono y se guarda en la carpeta que elijas. Los originales no se modifican.")
                    }
                }
            }
            StudioTabs(listOf("Operación", "Ajustes"), tab) { tab = it }
        }
    )
}

@Composable
private fun BatchThumbnail(
    bitmap: Bitmap?,
    index: Int,
    enabled: Boolean,
    canMoveBack: Boolean,
    canMoveForward: Boolean,
    onRemove: () -> Unit,
    onMoveBack: () -> Unit,
    onMoveForward: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(14.dp))
                .background(StudioTheme.Surface)
        ) {
            if (bitmap != null && !bitmap.isRecycled) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(5.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(StudioTheme.Accent)
                    .padding(horizontal = 6.dp, vertical = 1.dp)
            ) {
                Text(
                    "${index + 1}",
                    color = StudioTheme.OnAccent,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(3.dp)
                    .size(26.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xCC0B0E14))
                    .clickable(enabled = enabled, onClick = onRemove),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Close,
                    contentDescription = "Quitar",
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            IconButton(
                onClick = onMoveBack,
                enabled = enabled && canMoveBack,
                modifier = Modifier.weight(1f).height(24.dp)
            ) {
                Icon(
                    Icons.Rounded.ArrowBack,
                    contentDescription = "Mover antes",
                    tint = if (canMoveBack) StudioTheme.TextSecondary else StudioTheme.Outline,
                    modifier = Modifier.size(15.dp)
                )
            }
            IconButton(
                onClick = onMoveForward,
                enabled = enabled && canMoveForward,
                modifier = Modifier.weight(1f).height(24.dp)
            ) {
                Icon(
                    Icons.Rounded.ArrowForward,
                    contentDescription = "Mover después",
                    tint = if (canMoveForward) StudioTheme.TextSecondary else StudioTheme.Outline,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

private fun trimNumber(value: Double): String =
    if (value == value.toInt().toDouble()) value.toInt().toString()
    else value.toString()

private fun batchModeHint(mode: AdvancedFileUtils.BatchImageMode): String = when (mode) {
    AdvancedFileUtils.BatchImageMode.COMPRESS -> "Reduce el peso de cada imagen por separado."
    AdvancedFileUtils.BatchImageMode.RESIZE -> "Cambia el tamaño de todas al mismo lado máximo."
    AdvancedFileUtils.BatchImageMode.CONVERT -> "Convierte todo el lote al formato elegido."
    AdvancedFileUtils.BatchImageMode.REMOVE_METADATA -> "Vuelve a guardar cada foto sin datos EXIF, incluida la ubicación."
    AdvancedFileUtils.BatchImageMode.JOIN_VERTICAL -> "Une las imágenes una debajo de otra, en el orden de las miniaturas."
    AdvancedFileUtils.BatchImageMode.JOIN_HORIZONTAL -> "Une las imágenes una al lado de otra, en el orden de las miniaturas."
    AdvancedFileUtils.BatchImageMode.COLLAGE -> "Arma una cuadrícula con todas las imágenes."
    AdvancedFileUtils.BatchImageMode.PASSPORT_SHEET -> "Repite la primera foto en una hoja A4 lista para imprimir."
    AdvancedFileUtils.BatchImageMode.SOLID_BACKGROUND -> "Pone un fondo sólido detrás de cada imagen con transparencia."
    AdvancedFileUtils.BatchImageMode.FRAME -> "Añade un marco de color alrededor de cada imagen."
    AdvancedFileUtils.BatchImageMode.ZIP_ORIGINALS -> "Empaqueta los archivos originales en un ZIP, sin recomprimir."
}
