package com.ganageo.app.ui.tools

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.OfficePdf
import kotlinx.coroutines.launch

private class CvJob(
    role: String = "",
    company: String = "",
    period: String = "",
    achievements: String = ""
) {
    var role by mutableStateOf(role)
    var company by mutableStateOf(company)
    var period by mutableStateOf(period)
    var achievements by mutableStateOf(achievements)
}

private class CvStudy(
    degree: String = "",
    school: String = "",
    period: String = ""
) {
    var degree by mutableStateOf(degree)
    var school by mutableStateOf(school)
    var period by mutableStateOf(period)
}

/**
 * Constructor de CV.
 *
 * La plantilla por defecto es de una sola columna, sin tablas, sin iconos y sin
 * gráficos. No es por falta de gusto: los filtros automáticos que usan las
 * empresas (ATS) leen el PDF de izquierda a derecha y una hoja a dos columnas
 * les sale toda mezclada. Un CV bonito que el filtro no puede leer no llega a
 * ningún reclutador.
 */
@Composable
fun CvBuilderScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var fullName by rememberSaveable { mutableStateOf("") }
    var headline by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var city by rememberSaveable { mutableStateOf("") }
    var linkedin by rememberSaveable { mutableStateOf("") }
    var summary by rememberSaveable { mutableStateOf("") }
    var skills by rememberSaveable { mutableStateOf("") }
    var languages by rememberSaveable { mutableStateOf("") }
    var certifications by rememberSaveable { mutableStateOf("") }
    var atsMode by rememberSaveable { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }

    val jobs = remember { mutableStateListOf(CvJob()) }
    val studies = remember { mutableStateListOf(CvStudy()) }

    fun skillList(): List<String> = skills.split('\n', ',')
        .map { it.trim() }
        .filter { it.isNotBlank() }

    fun plainText(): String = buildString {
        appendLine(fullName.uppercase())
        if (headline.isNotBlank()) appendLine(headline)
        appendLine(listOf(phone, email, city, linkedin).filter { it.isNotBlank() }.joinToString(" | "))
        if (summary.isNotBlank()) {
            appendLine()
            appendLine("PERFIL PROFESIONAL")
            appendLine(summary)
        }
        val realJobs = jobs.filter { it.role.isNotBlank() || it.company.isNotBlank() }
        if (realJobs.isNotEmpty()) {
            appendLine()
            appendLine("EXPERIENCIA")
            realJobs.forEach { job ->
                appendLine("${job.role} — ${job.company}${if (job.period.isNotBlank()) " (${job.period})" else ""}")
                job.achievements.split('\n').filter { it.isNotBlank() }.forEach { appendLine("- ${it.trim()}") }
            }
        }
        val realStudies = studies.filter { it.degree.isNotBlank() || it.school.isNotBlank() }
        if (realStudies.isNotEmpty()) {
            appendLine()
            appendLine("EDUCACIÓN")
            realStudies.forEach { study ->
                appendLine("${study.degree} — ${study.school}${if (study.period.isNotBlank()) " (${study.period})" else ""}")
            }
        }
        if (skillList().isNotEmpty()) {
            appendLine()
            appendLine("HABILIDADES")
            appendLine(skillList().joinToString(", "))
        }
        if (languages.isNotBlank()) {
            appendLine()
            appendLine("IDIOMAS")
            appendLine(languages)
        }
        if (certifications.isNotBlank()) {
            appendLine()
            appendLine("CERTIFICACIONES")
            appendLine(certifications)
        }
    }

    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            runCatching {
                require(fullName.isNotBlank()) { "Escribe tu nombre antes de exportar." }
                OfficePdf.write(
                    context = context,
                    output = uri,
                    margin = if (atsMode) 48f else 44f,
                    accentColor = if (atsMode) android.graphics.Color.rgb(30, 30, 30)
                    else android.graphics.Color.rgb(18, 92, 62)
                ) {
                    title(fullName)
                    if (headline.isNotBlank()) subtitle(headline)
                    val contact = listOf(phone, email, city, linkedin).filter { it.isNotBlank() }
                    if (contact.isNotEmpty()) subtitle(contact.joinToString("  |  "))
                    if (summary.isNotBlank()) {
                        section("Perfil profesional")
                        paragraph(summary)
                    }
                    val realJobs = jobs.filter { it.role.isNotBlank() || it.company.isNotBlank() }
                    if (realJobs.isNotEmpty()) {
                        section("Experiencia")
                        realJobs.forEach { job ->
                            paragraph(
                                listOfNotNull(
                                    job.role.takeIf { it.isNotBlank() },
                                    job.company.takeIf { it.isNotBlank() }
                                ).joinToString(" — "),
                                bold = true
                            )
                            if (job.period.isNotBlank()) paragraph(job.period, muted = true)
                            job.achievements.split('\n').filter { it.isNotBlank() }.forEach { bullet(it.trim()) }
                            spacer(4f)
                        }
                    }
                    val realStudies = studies.filter { it.degree.isNotBlank() || it.school.isNotBlank() }
                    if (realStudies.isNotEmpty()) {
                        section("Educación")
                        realStudies.forEach { study ->
                            paragraph(
                                listOfNotNull(
                                    study.degree.takeIf { it.isNotBlank() },
                                    study.school.takeIf { it.isNotBlank() }
                                ).joinToString(" — "),
                                bold = true
                            )
                            if (study.period.isNotBlank()) paragraph(study.period, muted = true)
                        }
                    }
                    if (skillList().isNotEmpty()) {
                        section("Habilidades")
                        paragraph(skillList().joinToString(" · "))
                    }
                    if (languages.isNotBlank()) {
                        section("Idiomas")
                        paragraph(languages)
                    }
                    if (certifications.isNotBlank()) {
                        section("Certificaciones")
                        paragraph(certifications)
                    }
                }
            }.onSuccess { message = "CV exportado. El texto queda seleccionable, que es lo que necesita el filtro ATS." }
                .onFailure { message = it.message ?: "No se pudo generar el PDF." }
        }
    }

    ScienceShell(
        title = "Constructor de CV",
        subtitle = if (atsMode) "Plantilla legible por filtros ATS" else "Plantilla visual",
        onBack = onBack
    ) {
        StudioTabs(listOf("Datos", "Experiencia", "Estudios", "Revisión"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Datos de contacto") {
                    StudioTextField(fullName, { fullName = it }, "Nombre completo", modifier = Modifier.fillMaxWidth())
                    StudioTextField(headline, { headline = it }, "Puesto al que apuntas", placeholder = "Técnico topógrafo", modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioTextField(phone, { phone = it }, "Teléfono", modifier = Modifier.weight(1f))
                        StudioTextField(city, { city = it }, "Ciudad", modifier = Modifier.weight(1f))
                    }
                    StudioTextField(email, { email = it }, "Correo", modifier = Modifier.fillMaxWidth())
                    StudioTextField(linkedin, { linkedin = it }, "LinkedIn o portafolio", modifier = Modifier.fillMaxWidth())
                    StudioHint(
                        "No pongas DNI, edad, estado civil ni foto en la versión que subes a bolsas de trabajo: " +
                            "ya no se piden y en algunos países se evitan para no dar pie a discriminación."
                    )
                }
                ScienceCard("Perfil profesional") {
                    ScienceTextArea(
                        value = summary,
                        onValueChange = { summary = it },
                        label = "Resumen",
                        placeholder = "Tres o cuatro líneas: qué haces, cuántos años de experiencia y qué resultado sabes lograr.",
                        minHeight = 110
                    )
                    StudioHint("Lo leen en diez segundos. Que diga qué sabes hacer y con qué resultado, no adjetivos.")
                }
                ScienceCard("Habilidades e idiomas") {
                    ScienceTextArea(
                        value = skills,
                        onValueChange = { skills = it },
                        label = "Habilidades",
                        placeholder = "Una por línea o separadas por comas",
                        minHeight = 90
                    )
                    StudioTextField(languages, { languages = it }, "Idiomas", placeholder = "Español nativo, inglés B2", modifier = Modifier.fillMaxWidth())
                    StudioTextField(certifications, { certifications = it }, "Certificaciones", modifier = Modifier.fillMaxWidth())
                }
            }

            1 -> {
                jobs.forEachIndexed { index, job ->
                    ScienceCard("Puesto ${index + 1}") {
                        StudioTextField(job.role, { job.role = it }, "Cargo", modifier = Modifier.fillMaxWidth())
                        StudioTextField(job.company, { job.company = it }, "Empresa", modifier = Modifier.fillMaxWidth())
                        StudioTextField(job.period, { job.period = it }, "Periodo", placeholder = "Mar 2023 – Actualidad", modifier = Modifier.fillMaxWidth())
                        ScienceTextArea(
                            value = job.achievements,
                            onValueChange = { job.achievements = it },
                            label = "Logros (uno por línea)",
                            placeholder = "Reduje el tiempo de levantamiento topográfico en 30 %",
                            minHeight = 100
                        )
                        if (jobs.size > 1) {
                            Row {
                                Spacer(Modifier.weight(1f))
                                IconButton(onClick = { jobs.removeAt(index) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = StudioTheme.TextSecondary)
                                }
                            }
                        }
                    }
                }
                WorkActionButton("Agregar puesto", { jobs.add(CvJob()) }, Icons.Rounded.Add)
                StudioHint(
                    "Escribe logros con número: «atendí 40 clientes al día» dice mucho más que " +
                        "«responsable de atención al cliente»."
                )
            }

            2 -> {
                studies.forEachIndexed { index, study ->
                    ScienceCard("Estudio ${index + 1}") {
                        StudioTextField(study.degree, { study.degree = it }, "Título o carrera", modifier = Modifier.fillMaxWidth())
                        StudioTextField(study.school, { study.school = it }, "Institución", modifier = Modifier.fillMaxWidth())
                        StudioTextField(study.period, { study.period = it }, "Periodo", modifier = Modifier.fillMaxWidth())
                        if (studies.size > 1) {
                            Row {
                                Spacer(Modifier.weight(1f))
                                IconButton(onClick = { studies.removeAt(index) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = StudioTheme.TextSecondary)
                                }
                            }
                        }
                    }
                }
                WorkActionButton("Agregar estudio", { studies.add(CvStudy()) }, Icons.Rounded.Add)
            }

            else -> {
                ScienceCard("Formato") {
                    StudioChipRow {
                        StudioChip("Legible por ATS", atsMode, onClick = { atsMode = true })
                        StudioChip("Visual", !atsMode, onClick = { atsMode = false })
                    }
                    StudioHint(
                        if (atsMode) {
                            "Una sola columna, tipografía estándar y sin adornos. Es la que conviene para postular " +
                                "por internet, donde un programa lee tu CV antes que una persona."
                        } else {
                            "Con color de acento. Úsala para entregar en mano o enviar directo a una persona, " +
                                "no para portales de empleo."
                        }
                    )
                }

                val checks = buildList {
                    add(Triple("Nombre completo", fullName.isNotBlank(), "Es lo primero que busca el filtro."))
                    add(Triple("Teléfono y correo", phone.isNotBlank() && email.isNotBlank(), "Sin contacto no te pueden llamar."))
                    add(
                        Triple(
                            "Perfil profesional entre 40 y 600 caracteres",
                            summary.length in 40..600,
                            "Ahora tiene ${summary.length}."
                        )
                    )
                    add(
                        Triple(
                            "Al menos una experiencia con logros",
                            jobs.any { it.role.isNotBlank() && it.achievements.isNotBlank() },
                            "Agrega qué lograste en cada puesto."
                        )
                    )
                    add(
                        Triple(
                            "Algún logro con número",
                            jobs.any { job -> job.achievements.any(Char::isDigit) },
                            "Los números hacen creíble el logro."
                        )
                    )
                    add(Triple("Tres habilidades o más", skillList().size >= 3, "Van ${skillList().size}."))
                    add(
                        Triple(
                            "Sin datos que ya no se piden",
                            !plainText().lowercase().let { text ->
                                text.contains("dni") || text.contains("estado civil") || text.contains("edad:")
                            },
                            "Quita DNI, edad y estado civil."
                        )
                    )
                }

                ScienceCard("Revisión antes de enviar") {
                    checks.forEach { (label, ok, hint) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (ok) Icons.Rounded.Check else Icons.Rounded.Close,
                                contentDescription = null,
                                tint = if (ok) StudioTheme.Accent else Color(0xFFFF8A80),
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(Modifier.width(9.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    label,
                                    color = StudioTheme.TextPrimary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (!ok) {
                                    Text(
                                        hint,
                                        color = StudioTheme.TextSecondary,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                    }
                }

                ScienceCard("Vista previa") {
                    DocumentSheet {
                        SheetTitle(fullName.ifBlank { "Tu nombre" })
                        if (headline.isNotBlank()) SheetText(headline, bold = true)
                        SheetText(listOf(phone, email, city).filter { it.isNotBlank() }.joinToString(" | "))
                        if (summary.isNotBlank()) {
                            SheetLabel("Perfil profesional")
                            SheetText(summary)
                        }
                        jobs.filter { it.role.isNotBlank() }.take(2).forEach { job ->
                            SheetLabel("Experiencia")
                            SheetText("${job.role} — ${job.company}", bold = true)
                            job.achievements.split('\n').filter { it.isNotBlank() }.take(3).forEach {
                                SheetText("• ${it.trim()}")
                            }
                        }
                    }
                }

                WorkActionButton(
                    "Exportar CV en PDF",
                    { pdfLauncher.launch("${safeFileName(fullName, "CV")}_CV.pdf") },
                    Icons.Rounded.PictureAsPdf,
                    enabled = fullName.isNotBlank()
                )
                WorkActionButton(
                    "Copiar como texto",
                    {
                        copyToClipboard(context, "CV", plainText())
                        message = "CV copiado. Útil para pegarlo en formularios web."
                    },
                    Icons.Rounded.Add
                )
                message?.let { StudioHint(it) }
            }
        }
    }
}
