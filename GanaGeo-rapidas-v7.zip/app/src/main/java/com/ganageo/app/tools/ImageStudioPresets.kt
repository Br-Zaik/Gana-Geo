package com.ganageo.app.tools

import kotlin.math.roundToInt

/**
 * Medidas listas para usar. Son las que ofrecen las apps de redimension mas
 * descargadas: en vez de obligar a escribir numeros, se toca un chip y listo.
 */
object ImageStudioPresets {

    data class SizePreset(
        val label: String,
        val width: Int,
        val height: Int,
        val group: String
    )

    data class TargetWeight(val label: String, val kilobytes: Int)

    data class QualityPreset(val label: String, val quality: Int, val hint: String)

    data class AspectPreset(val label: String, val ratio: Float?)

    data class IdPhotoPreset(
        val label: String,
        val widthMm: Double,
        val heightMm: Double,
        val note: String
    ) {
        fun pixels(dpi: Int): Pair<Int, Int> {
            val w = (widthMm / 25.4 * dpi).roundToInt().coerceAtLeast(1)
            val h = (heightMm / 25.4 * dpi).roundToInt().coerceAtLeast(1)
            return w to h
        }
    }

    val socialSizes: List<SizePreset> = listOf(
        SizePreset("Instagram vertical", 1080, 1350, "Redes"),
        SizePreset("Instagram cuadrado", 1080, 1080, "Redes"),
        SizePreset("Instagram alto", 1080, 1440, "Redes"),
        SizePreset("Historia / Reel", 1080, 1920, "Redes"),
        SizePreset("Facebook portada", 1200, 630, "Redes"),
        SizePreset("WhatsApp estado", 1080, 1920, "Redes"),
        SizePreset("Foto de perfil", 640, 640, "Redes"),
        SizePreset("LinkedIn publicación", 1200, 1200, "Redes"),
        SizePreset("Pinterest", 1000, 1500, "Redes"),
        SizePreset("Miniatura YouTube", 1280, 720, "Redes"),
        SizePreset("Portada YouTube", 2560, 1440, "Redes")
    )

    val screenSizes: List<SizePreset> = listOf(
        SizePreset("HD 720p", 1280, 720, "Pantalla"),
        SizePreset("Full HD 1080p", 1920, 1080, "Pantalla"),
        SizePreset("2K", 2560, 1440, "Pantalla"),
        SizePreset("4K", 3840, 2160, "Pantalla"),
        SizePreset("Web ligera", 1600, 1600, "Pantalla"),
        SizePreset("Correo", 1024, 1024, "Pantalla")
    )

    /**
     * Medidas oficiales mas usadas. Los tramites cambian de un pais a otro y de
     * un formulario a otro, asi que la app muestra el aviso de verificar el
     * requisito antes de imprimir o subir la foto.
     */
    val idPhotos: List<IdPhotoPreset> = listOf(
        IdPhotoPreset("Carnet 35×45 mm", 35.0, 45.0, "Medida estándar en Europa, Latinoamérica, India y China"),
        IdPhotoPreset("Visa EE. UU. 2×2 in", 50.8, 50.8, "600×600 a 1200×1200 px, máximo 240 KB en el DS-160"),
        IdPhotoPreset("Carnet 30×40 mm", 30.0, 40.0, "Formato reducido de varios documentos escolares"),
        IdPhotoPreset("Carnet 25×35 mm", 25.0, 35.0, "Usado en algunos carnés y fichas internas"),
        IdPhotoPreset("Pasaporte 40×60 mm", 40.0, 60.0, "Formato ampliado para algunos trámites")
    )

    val compressPresets: List<QualityPreset> = listOf(
        QualityPreset("WhatsApp", 60, "Peso mínimo para enviar por chat"),
        QualityPreset("Correo", 70, "Buen equilibrio para adjuntar"),
        QualityPreset("Web", 80, "Recomendado: casi no se nota la pérdida"),
        QualityPreset("Alta", 90, "Para imprimir o archivar"),
        QualityPreset("Máxima", 96, "Reduce poco el peso")
    )

    val targetWeights: List<TargetWeight> = listOf(
        TargetWeight("50 KB", 50),
        TargetWeight("100 KB", 100),
        TargetWeight("250 KB", 250),
        TargetWeight("500 KB", 500),
        TargetWeight("1 MB", 1024),
        TargetWeight("2 MB", 2048)
    )

    val aspects: List<AspectPreset> = listOf(
        AspectPreset("Libre", null),
        AspectPreset("1:1", 1f),
        AspectPreset("4:5", 4f / 5f),
        AspectPreset("3:4", 3f / 4f),
        AspectPreset("4:3", 4f / 3f),
        AspectPreset("2:3", 2f / 3f),
        AspectPreset("3:2", 3f / 2f),
        AspectPreset("16:9", 16f / 9f),
        AspectPreset("9:16", 9f / 16f),
        AspectPreset("A4 vertical", 210f / 297f),
        AspectPreset("A4 apaisado", 297f / 210f)
    )

    val percentShortcuts: List<Float> = listOf(25f, 50f, 75f, 100f, 150f)

    val watermarkPositions: List<Pair<String, Pair<Float, Float>>> = listOf(
        "Arriba izquierda" to (0.16f to 0.10f),
        "Arriba centro" to (0.5f to 0.10f),
        "Arriba derecha" to (0.84f to 0.10f),
        "Centro izquierda" to (0.16f to 0.5f),
        "Centro" to (0.5f to 0.5f),
        "Centro derecha" to (0.84f to 0.5f),
        "Abajo izquierda" to (0.16f to 0.90f),
        "Abajo centro" to (0.5f to 0.90f),
        "Abajo derecha" to (0.84f to 0.90f)
    )

    fun simplifiedRatio(width: Int, height: Int): String {
        if (width <= 0 || height <= 0) return ""
        val divisor = greatestCommonDivisor(width, height)
        val w = width / divisor
        val h = height / divisor
        return if (w <= 40 && h <= 40) "$w:$h" else String.format("%.2f", width.toFloat() / height)
    }

    private fun greatestCommonDivisor(a: Int, b: Int): Int {
        var x = a
        var y = b
        while (y != 0) {
            val temp = y
            y = x % y
            x = temp
        }
        return if (x == 0) 1 else x
    }
}
