package com.ganageo.app.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ganageo.app.data.ExamQuestion
import com.ganageo.app.data.ExamQuestionType
import com.ganageo.app.data.ExamStore
import com.ganageo.app.tools.CurrencyInfo
import com.ganageo.app.tools.Money
import com.ganageo.app.tools.NumberLab
import com.ganageo.app.tools.QuizEngine
import com.ganageo.app.tools.QuizQuestion
import com.ganageo.app.tools.StudentFinanceLab
import com.ganageo.app.tools.TextLab
import java.math.BigDecimal
import kotlinx.coroutines.launch

// ---------------------------------------------------------------------------
// Exámenes y cuestionarios
// ---------------------------------------------------------------------------

/**
 * Exámenes y cuestionarios.
 *
 * La investigación es clara: tres alternativas bien hechas miden igual que
 * cinco y se responden más rápido. La app revisa la redacción y avisa de los
 * errores clásicos, como poner «todas las anteriores» o dejar la correcta
 * mucho más larga que las demás.
 */
@Composable
fun ExamBuilderScreen(onBack: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { ExamStore(context) }
    val banks by store.banks.collectAsState(initial = emptyList())

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var selectedBankId by rememberSaveable { mutableStateOf<String?>(null) }
    var bankName by rememberSaveable { mutableStateOf("") }
    var questionText by rememberSaveable { mutableStateOf("") }
    val options = remember { mutableStateListOf("", "", "") }
    var correctIndex by rememberSaveable { mutableIntStateOf(0) }
    var explanation by rememberSaveable { mutableStateOf("") }
    var importText by rememberSaveable { mutableStateOf("") }
    var penalize by rememberSaveable { mutableStateOf(false) }

    // Práctica
    val practice = remember { mutableStateListOf<QuizQuestion>() }
    var practiceIndex by rememberSaveable { mutableIntStateOf(0) }
    val answers = remember { mutableStateListOf<Int>() }
    var finished by rememberSaveable { mutableStateOf(false) }

    val bank = banks.firstOrNull { it.id == selectedBankId } ?: banks.firstOrNull()

    val draft = QuizQuestion(
        text = questionText,
        options = options.filter { it.isNotBlank() },
        correctIndex = correctIndex.coerceIn(0, (options.count { it.isNotBlank() } - 1).coerceAtLeast(0)),
        explanation = explanation
    )
    val warnings = if (draft.text.isNotBlank() && draft.options.size >= 2) QuizEngine.reviewWriting(draft) else emptyList()

    ScienceShell(
        title = "Exámenes y cuestionarios",
        subtitle = bank?.let { "${it.name} · ${it.questions.size} preguntas" } ?: "Sin banco seleccionado",
        onBack = onBack
    ) {
        StudioTabs(listOf("Banco", "Practicar", "Importar"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Bancos de preguntas") {
                    if (banks.isNotEmpty()) {
                        StudioChipRow {
                            banks.forEach { item ->
                                StudioChip(
                                    label = item.name,
                                    active = item.id == bank?.id,
                                    onClick = { selectedBankId = item.id },
                                    caption = "${item.questions.size}"
                                )
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        StudioTextField(bankName, { bankName = it }, "Nuevo banco", modifier = Modifier.weight(1f))
                        StudioChip("Crear", false, onClick = {
                            scope.launch {
                                runCatching { store.createBank(bankName, "") }
                                    .onSuccess {
                                        selectedBankId = it.id
                                        bankName = ""
                                    }
                                    .onFailure { onMessage(it.message ?: "No se pudo crear.") }
                            }
                        })
                    }
                }

                if (bank != null) {
                    ScienceCard("Nueva pregunta") {
                        ScienceTextArea(questionText, { questionText = it }, "Enunciado", "¿Qué mide el índice de dificultad?", minHeight = 80)
                        options.forEachIndexed { index, value ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StudioChip(
                                    label = "${('A' + index)}",
                                    active = correctIndex == index,
                                    onClick = { correctIndex = index }
                                )
                                Spacer(Modifier.size(8.dp))
                                StudioTextField(
                                    value = value,
                                    onValueChange = { options[index] = it },
                                    label = "Alternativa ${('A' + index)}",
                                    modifier = Modifier.weight(1f)
                                )
                                if (options.size > 2) {
                                    IconButton(onClick = {
                                        options.removeAt(index)
                                        if (correctIndex >= options.size) correctIndex = 0
                                    }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = StudioTheme.TextSecondary)
                                    }
                                }
                            }
                        }
                        StudioChipRow {
                            if (options.size < 5) {
                                StudioChip("Añadir alternativa", false, onClick = { options.add("") })
                            }
                            StudioChip("Marca la correcta con su letra", false, onClick = { })
                        }
                        StudioTextField(explanation, { explanation = it }, "Explicación de la respuesta", modifier = Modifier.fillMaxWidth())
                        warnings.forEach { StudioHint("Aviso: $it") }
                        WorkActionButton("Guardar pregunta", {
                            scope.launch {
                                runCatching {
                                    require(draft.isValid) { "Completa el enunciado y al menos dos alternativas." }
                                    store.addQuestion(
                                        bank.id,
                                        ExamQuestion(
                                            text = draft.text,
                                            type = if (draft.options.size == 2) ExamQuestionType.TRUE_FALSE
                                            else ExamQuestionType.MULTIPLE_CHOICE,
                                            options = draft.options,
                                            correctIndex = draft.correctIndex,
                                            explanation = draft.explanation
                                        )
                                    )
                                }.onSuccess {
                                    questionText = ""
                                    explanation = ""
                                    options.indices.forEach { options[it] = "" }
                                    correctIndex = 0
                                    onMessage("Pregunta guardada.")
                                }.onFailure { onMessage(it.message ?: "No se pudo guardar.") }
                            }
                        }, Icons.Rounded.Add)
                        StudioHint(
                            "Con tres alternativas bien pensadas basta: se responde más rápido y mide igual que con cinco."
                        )
                    }

                    bank.questions.forEachIndexed { index, question ->
                        ScienceCard("Pregunta ${index + 1}") {
                            Text(question.text, color = StudioTheme.TextPrimary, style = MaterialTheme.typography.bodyMedium)
                            question.options.forEachIndexed { optionIndex, option ->
                                ScienceRow(
                                    "${('A' + optionIndex)}. $option",
                                    if (optionIndex == question.correctIndex) "correcta" else "",
                                    highlight = optionIndex == question.correctIndex
                                )
                            }
                            Row {
                                Spacer(Modifier.weight(1f))
                                IconButton(onClick = {
                                    scope.launch { store.deleteQuestion(bank.id, question.id) }
                                }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = StudioTheme.TextSecondary)
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                if (bank == null || bank.questions.isEmpty()) {
                    StudioHint("Crea un banco con preguntas para poder practicar.")
                } else if (practice.isEmpty()) {
                    ScienceCard("Empezar práctica") {
                        ScienceRow("Preguntas disponibles", bank.questions.size.toString())
                        StudioChipRow {
                            StudioChip(
                                label = if (penalize) "Con penalización" else "Sin penalización",
                                active = penalize,
                                onClick = { penalize = !penalize }
                            )
                        }
                        StudioHint(
                            if (penalize) "Cada error resta 1/(alternativas − 1) puntos, que es lo que se acierta al azar."
                            else "Los errores no restan."
                        )
                        WorkActionButton("Empezar", {
                            practice.clear()
                            practice.addAll(
                                QuizEngine.shuffle(
                                    bank.questions.map {
                                        QuizQuestion(it.text, it.options, it.correctIndex, it.explanation)
                                    }
                                )
                            )
                            answers.clear()
                            repeat(practice.size) { answers.add(-1) }
                            practiceIndex = 0
                            finished = false
                        }, Icons.Rounded.PlayArrow)
                    }
                } else if (!finished) {
                    val question = practice[practiceIndex]
                    ScienceCard("Pregunta ${practiceIndex + 1} de ${practice.size}") {
                        Text(
                            question.text,
                            color = StudioTheme.TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 17.sp
                        )
                        question.options.forEachIndexed { index, option ->
                            StudioChip(
                                label = "${('A' + index)}. $option",
                                active = answers.getOrNull(practiceIndex) == index,
                                onClick = { answers[practiceIndex] = index },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioSecondaryButton(
                            label = "Anterior",
                            icon = Icons.Rounded.PlayArrow,
                            onClick = { if (practiceIndex > 0) practiceIndex-- },
                            modifier = Modifier.weight(1f),
                            enabled = practiceIndex > 0
                        )
                        StudioSecondaryButton(
                            label = if (practiceIndex == practice.lastIndex) "Terminar" else "Siguiente",
                            icon = Icons.Rounded.PlayArrow,
                            onClick = {
                                if (practiceIndex == practice.lastIndex) finished = true else practiceIndex++
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                } else {
                    val correct = practice.indices.count { answers.getOrNull(it) == practice[it].correctIndex }
                    val answered = practice.indices.count { answers.getOrNull(it) != -1 }
                    val wrong = answered - correct
                    val optionsPerQuestion = practice.firstOrNull()?.options?.size ?: 4
                    val raw = QuizEngine.score(correct, wrong, optionsPerQuestion, penalize)
                    val vigesimal = QuizEngine.scoreOn20(raw, practice.size)

                    WorkTotals(
                        rows = listOf(
                            "Respondidas" to "$answered de ${practice.size}",
                            "Correctas" to correct.toString(),
                            "Incorrectas" to wrong.toString(),
                            "Puntaje bruto" to String.format("%.2f", raw)
                        ),
                        total = "Nota sobre 20" to String.format("%.1f", vigesimal),
                        note = if (vigesimal >= 11) "Aprobado en escala vigesimal." else "Por debajo de 11."
                    )

                    practice.forEachIndexed { index, question ->
                        val given = answers.getOrNull(index) ?: -1
                        val ok = given == question.correctIndex
                        ScienceCard("${index + 1}. ${if (ok) "Correcta" else "Incorrecta"}") {
                            Text(question.text, color = StudioTheme.TextPrimary, style = MaterialTheme.typography.bodySmall)
                            ScienceRow(
                                "Tu respuesta",
                                if (given >= 0) question.options[given] else "sin responder",
                                highlight = ok
                            )
                            if (!ok) {
                                ScienceRow("Correcta", question.options[question.correctIndex], highlight = true)
                            }
                            if (question.explanation.isNotBlank()) {
                                StudioHint(question.explanation)
                            }
                        }
                    }

                    WorkActionButton("Practicar de nuevo", {
                        practice.clear()
                        finished = false
                    }, Icons.Rounded.PlayArrow)
                }
            }

            else -> {
                ScienceCard("Importar preguntas") {
                    ScienceTextArea(
                        importText, { importText = it },
                        "Pega en formato Aiken o GIFT",
                        "¿Qué base tiene el hexadecimal?\nA. 2\nB. 8\nC. 16\nANSWER: C",
                        minHeight = 140
                    )
                    val parsedAiken = QuizEngine.parseAiken(importText)
                    val parsedGift = QuizEngine.parseGift(importText)
                    val parsed = if (parsedAiken.size >= parsedGift.size) parsedAiken else parsedGift
                    StudioHint("Detectadas ${parsed.size} preguntas válidas.")
                    WorkActionButton("Añadir al banco", {
                        val target = bank
                        if (target == null) {
                            onMessage("Crea primero un banco.")
                        } else {
                            scope.launch {
                                runCatching {
                                    parsed.forEach { question ->
                                        store.addQuestion(
                                            target.id,
                                            ExamQuestion(
                                                text = question.text,
                                                type = ExamQuestionType.MULTIPLE_CHOICE,
                                                options = question.options,
                                                correctIndex = question.correctIndex
                                            )
                                        )
                                    }
                                }.onSuccess {
                                    importText = ""
                                    onMessage("Se importaron ${parsed.size} preguntas.")
                                }.onFailure { onMessage(it.message ?: "No se pudo importar.") }
                            }
                        }
                    }, Icons.Rounded.Add, enabled = parsed.isNotEmpty())
                }

                if (bank != null && bank.questions.isNotEmpty()) {
                    val exportable = bank.questions.map {
                        QuizQuestion(it.text, it.options, it.correctIndex, it.explanation)
                    }
                    ScienceCard("Exportar «${bank.name}»") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StudioSecondaryButton(
                                label = "Aiken",
                                icon = Icons.Rounded.ContentCopy,
                                onClick = {
                                    copyToClipboard(context, "Aiken", QuizEngine.toAiken(exportable))
                                    onMessage("Formato Aiken copiado.")
                                },
                                modifier = Modifier.weight(1f)
                            )
                            StudioSecondaryButton(
                                label = "GIFT",
                                icon = Icons.Rounded.ContentCopy,
                                onClick = {
                                    copyToClipboard(context, "GIFT", QuizEngine.toGift(exportable))
                                    onMessage("Formato GIFT copiado.")
                                },
                                modifier = Modifier.weight(1f)
                            )
                            StudioSecondaryButton(
                                label = "CSV",
                                icon = Icons.Rounded.ContentCopy,
                                onClick = {
                                    copyToClipboard(context, "CSV", QuizEngine.toCsv(exportable))
                                    onMessage("CSV copiado.")
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        StudioHint("Aiken y GIFT se importan directamente en Moodle.")
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Finanzas para estudiantes
// ---------------------------------------------------------------------------

private class PersonRow(name: String = "", paid: String = "") {
    var name by mutableStateOf(name)
    var paid by mutableStateOf(paid)
}

/**
 * Finanzas para estudiantes.
 *
 * Con las tasas peruanas de verdad: la TEA no se divide entre 12 para sacar la
 * mensual, se saca la raíz doceava. Ese error hace que la cuota calculada salga
 * más baja que la del banco.
 */
@Composable
fun StudentFinanceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val currency = CurrencyInfo.PEN

    var capital by rememberSaveable { mutableStateOf("1000") }
    var rate by rememberSaveable { mutableStateOf("2") }
    var periods by rememberSaveable { mutableStateOf("12") }
    var compound by rememberSaveable { mutableStateOf(true) }

    var loanAmount by rememberSaveable { mutableStateOf("5000") }
    var loanRate by rememberSaveable { mutableStateOf("2.5") }
    var loanPeriods by rememberSaveable { mutableStateOf("12") }
    var germanSystem by rememberSaveable { mutableStateOf(false) }

    var tea by rememberSaveable { mutableStateOf("35") }
    var tna by rememberSaveable { mutableStateOf("30") }
    var capitalizations by rememberSaveable { mutableStateOf("12") }
    var cardBalance by rememberSaveable { mutableStateOf("2000") }
    var cardRate by rememberSaveable { mutableStateOf("3.5") }
    var cardMinimum by rememberSaveable { mutableStateOf("5") }

    var total by rememberSaveable { mutableStateOf("120") }
    val people = remember { mutableStateListOf(PersonRow("Ana", "120"), PersonRow("Luis", "0")) }

    ScienceShell(
        title = "Finanzas para estudiantes",
        subtitle = "Interés, cuotas, tasas y gastos compartidos",
        onBack = onBack
    ) {
        StudioTabs(listOf("Interés", "Préstamo", "Tasas", "Gastos"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Datos") {
                    ScienceNumberField(capital, { capital = it }, "Capital", Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(rate, { rate = it }, "Tasa % por periodo", Modifier.weight(1f))
                        ScienceNumberField(periods, { periods = it }, "Periodos", Modifier.weight(1f))
                    }
                    StudioChipRow {
                        StudioChip("Compuesto", compound, onClick = { compound = true })
                        StudioChip("Simple", !compound, onClick = { compound = false })
                    }
                    StudioHint(
                        if (compound) "En el interés compuesto los intereses se suman al capital y generan más intereses."
                        else "En el interés simple los intereses se calculan siempre sobre el capital inicial."
                    )
                }
                val c = Money.ofOrZero(capital)
                val r = Money.ofOrZero(rate)
                val n = periods.toIntOrNull() ?: 0
                val result = if (compound) StudentFinanceLab.compoundAmount(c, r, n)
                else c.add(StudentFinanceLab.simpleInterest(c, r, BigDecimal(n)))
                WorkTotals(
                    rows = listOf(
                        "Capital inicial" to Money.format(c, currency),
                        "Intereses ganados" to Money.format(result.subtract(c), currency)
                    ),
                    total = "Monto final" to Money.format(result, currency)
                )
            }

            1 -> {
                ScienceCard("Préstamo") {
                    ScienceNumberField(loanAmount, { loanAmount = it }, "Monto", Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(loanRate, { loanRate = it }, "Tasa % mensual", Modifier.weight(1f))
                        ScienceNumberField(loanPeriods, { loanPeriods = it }, "Cuotas", Modifier.weight(1f))
                    }
                    StudioChipRow {
                        StudioChip("Cuota fija (francés)", !germanSystem, onClick = { germanSystem = false })
                        StudioChip("Cuota decreciente (alemán)", germanSystem, onClick = { germanSystem = true })
                    }
                }
                val summary = runCatching {
                    StudentFinanceLab.amortization(
                        Money.ofOrZero(loanAmount),
                        Money.ofOrZero(loanRate),
                        loanPeriods.toIntOrNull() ?: 12,
                        germanSystem
                    )
                }
                summary.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los datos.") }
                summary.getOrNull()?.let { loan ->
                    WorkTotals(
                        rows = listOf(
                            (if (germanSystem) "Primera cuota" else "Cuota mensual") to
                                Money.format(loan.installment, currency),
                            "Total de intereses" to Money.format(loan.totalInterest, currency)
                        ),
                        total = "Total a pagar" to Money.format(loan.totalPaid, currency)
                    )
                    val tcea = runCatching {
                        StudentFinanceLab.effectiveRateFromInstallment(
                            Money.ofOrZero(loanAmount), loan.installment, loanPeriods.toIntOrNull() ?: 12
                        )
                    }.getOrNull()
                    if (tcea != null) {
                        StudioHint(
                            "Ese flujo de cuotas equivale a una tasa efectiva anual de " +
                                "${Money.formatPercent(tcea)}. Si la cuota incluyera seguros y comisiones, eso sería la TCEA."
                        )
                    }
                    ScienceCard("Primeras cuotas") {
                        loan.rows.take(12).forEach { row ->
                            MoneyRow(
                                "Cuota ${row.period}",
                                "int. ${Money.format(row.interest, currency, withSymbol = false)} · " +
                                    "cap. ${Money.format(row.principal, currency, withSymbol = false)} · " +
                                    "saldo ${Money.format(row.balance, currency, withSymbol = false)}"
                            )
                        }
                        StudioHint("Al principio casi todo lo que pagas es interés: el capital baja despacio.")
                    }
                }
            }

            2 -> {
                ScienceCard("De nominal a efectiva") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(tna, { tna = it }, "TNA %", Modifier.weight(1f))
                        ScienceNumberField(capitalizations, { capitalizations = it }, "Capitaliza/año", Modifier.weight(1f))
                    }
                    val effective = runCatching {
                        StudentFinanceLab.nominalToEffective(
                            Money.ofOrZero(tna),
                            capitalizations.toIntOrNull() ?: 12
                        )
                    }.getOrNull()
                    if (effective != null) {
                        ScienceRow("TEA equivalente", Money.formatPercent(effective, 4), highlight = true)
                    }
                    StudioHint("TEA = (1 + TNA/m)^m − 1, donde m es cuántas veces al año capitaliza.")
                }

                ScienceCard("De anual a mensual") {
                    ScienceNumberField(tea, { tea = it }, "TEA %", Modifier.fillMaxWidth())
                    val tem = StudentFinanceLab.effectiveAnnualToMonthly(Money.ofOrZero(tea))
                    ScienceRow("TEM equivalente", Money.formatPercent(tem, 4), highlight = true)
                    ScienceRow(
                        "Dividir entre 12 daría",
                        Money.formatPercent(Money.ofOrZero(tea).divide(BigDecimal(12), 4, java.math.RoundingMode.HALF_UP), 4)
                    )
                    StudioHint(
                        "La correcta es la raíz doceava: TEM = (1 + TEA)^(1/12) − 1. Dividir entre 12 subestima el costo."
                    )
                }

                ScienceCard("Pagar solo el mínimo de la tarjeta") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(cardBalance, { cardBalance = it }, "Deuda", Modifier.weight(1.2f))
                        ScienceNumberField(cardRate, { cardRate = it }, "Interés % mes", Modifier.weight(1f))
                        ScienceNumberField(cardMinimum, { cardMinimum = it }, "Mínimo %", Modifier.weight(1f))
                    }
                    val plan = StudentFinanceLab.minimumPaymentPlan(
                        Money.ofOrZero(cardBalance),
                        Money.ofOrZero(cardRate),
                        Money.ofOrZero(cardMinimum)
                    )
                    if (plan.months < 0) {
                        ScienceError(plan.warning)
                    } else {
                        WorkTotals(
                            rows = listOf(
                                "Meses pagando el mínimo" to plan.months.toString(),
                                "Intereses pagados" to Money.format(plan.totalInterest, currency)
                            ),
                            total = "Total desembolsado" to Money.format(plan.totalPaid, currency),
                            note = plan.warning
                        )
                    }
                }
            }

            else -> {
                ScienceCard("Gasto compartido") {
                    ScienceNumberField(total, { total = it }, "Gasto total", Modifier.fillMaxWidth())
                    people.forEachIndexed { index, person ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            StudioTextField(person.name, { person.name = it }, "Nombre", modifier = Modifier.weight(1.2f))
                            ScienceNumberField(person.paid, { person.paid = it }, "Puso", Modifier.weight(1f))
                            if (people.size > 2) {
                                IconButton(onClick = { people.removeAt(index) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = StudioTheme.TextSecondary)
                                }
                            }
                        }
                    }
                    WorkActionButton("Agregar persona", { people.add(PersonRow()) }, Icons.Rounded.Add)
                }

                val names = people.map { it.name.ifBlank { "Sin nombre" } }
                val totalAmount = Money.ofOrZero(total)
                val shares = StudentFinanceLab.equalShares(totalAmount, names)
                val paid = people.associate { (it.name.ifBlank { "Sin nombre" }) to Money.ofOrZero(it.paid) }
                val balances = StudentFinanceLab.balancesFrom(paid, shares)
                val settlements = StudentFinanceLab.settleBalances(balances)

                ScienceCard("Cuánto le toca a cada uno") {
                    shares.forEach { (name, amount) ->
                        val balance = balances[name] ?: BigDecimal.ZERO
                        MoneyRow(
                            name,
                            "le toca ${Money.format(amount, currency, withSymbol = false)} · " +
                                (if (balance.signum() >= 0) "a favor " else "debe ") +
                                Money.format(balance.abs(), currency, withSymbol = false)
                        )
                    }
                }

                ScienceCard("Cómo saldar", accent = true) {
                    if (settlements.isEmpty()) {
                        StudioHint("Todos pusieron lo que les tocaba: no hay nada que transferir.")
                    } else {
                        settlements.forEach { settlement ->
                            MoneyRow(
                                "${settlement.from} → ${settlement.to}",
                                Money.format(settlement.amount, currency),
                                highlight = true
                            )
                        }
                        StudioHint(
                            "Se emparejan los montos mayores primero, así salen ${settlements.size} " +
                                "transferencias en vez de que todos le paguen a todos."
                        )
                    }
                }

                WorkActionButton("Copiar el reparto", {
                    copyToClipboard(
                        context,
                        "Gastos",
                        buildString {
                            appendLine("Gasto total: ${Money.format(totalAmount, currency)}")
                            shares.forEach { (name, amount) ->
                                appendLine("$name: ${Money.format(amount, currency)}")
                            }
                            appendLine()
                            settlements.forEach {
                                appendLine("${it.from} paga a ${it.to}: ${Money.format(it.amount, currency)}")
                            }
                        }
                    )
                }, Icons.Rounded.ContentCopy)
            }
        }

        LegalNote("Los cálculos son referenciales. Antes de firmar un crédito compara siempre la TCEA que informa el banco.")
    }
}

// ---------------------------------------------------------------------------
// Herramientas de texto
// ---------------------------------------------------------------------------

/**
 * Herramientas de texto.
 *
 * La legibilidad se mide con fórmulas hechas para el español. Las de Flesch en
 * inglés no valen aquí: nuestras palabras tienen más sílabas y cualquier texto
 * normal saldría marcado como dificilísimo.
 */
@Composable
fun TextToolkitScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var text by rememberSaveable { mutableStateOf("") }
    var wordLimit by rememberSaveable { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    val stats = TextLab.stats(text)

    fun transform(label: String, block: (String) -> String) {
        text = block(text)
        message = "$label aplicado."
    }

    ScienceShell(
        title = "Herramientas de texto",
        subtitle = "${stats.words} palabras · ${stats.characters} caracteres",
        onBack = onBack,
        trailing = {
            IconButton(onClick = {
                copyToClipboard(context, "Texto", text)
                message = "Texto copiado."
            }) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = "Copiar", tint = StudioTheme.TextPrimary)
            }
        }
    ) {
        ScienceTextArea(text, { text = it }, "Tu texto", "Pega aquí el texto que quieres analizar o limpiar", minHeight = 160)

        StudioTabs(listOf("Analizar", "Transformar", "Limpiar"), tab) { tab = it }

        when (tab) {
            0 -> {
                WorkTotals(
                    rows = listOf(
                        "Caracteres" to stats.characters.toString(),
                        "Sin espacios" to stats.charactersNoSpaces.toString(),
                        "Oraciones" to stats.sentences.toString(),
                        "Párrafos" to stats.paragraphs.toString()
                    ),
                    total = "Palabras" to stats.words.toString(),
                    note = "Tiempo de lectura aproximado: ${"%.1f".format(stats.readingMinutes)} minutos a 200 palabras por minuto."
                )

                ScienceCard("Límite de palabras") {
                    ScienceNumberField(wordLimit, { wordLimit = it }, "Límite del trabajo", Modifier.fillMaxWidth())
                    val limit = wordLimit.toIntOrNull() ?: 0
                    if (limit > 0) {
                        StudioHint(TextLab.limitStatus(stats.words, limit))
                    }
                }

                if (stats.words > 20) {
                    val readability = TextLab.readability(text)
                    ScienceCard("Legibilidad") {
                        ScienceRow("Nivel", readability.level, highlight = true)
                        ScienceRow("Fernández Huerta", "%.1f".format(readability.fernandezHuerta))
                        ScienceRow("Szigriszt (INFLESZ)", "%.1f".format(readability.szigriszt))
                        ScienceRow("Palabras por oración", "%.1f".format(stats.averageWordsPerSentence))
                        ScienceRow("Sílabas por palabra", "%.2f".format(stats.averageSyllablesPerWord))
                        StudioHint(readability.advice)
                    }

                    ScienceCard("Palabras más usadas") {
                        TextLab.wordFrequency(text, 10).forEach { (word, count) ->
                            MoneyRow(word, count.toString())
                        }
                        StudioHint("Si una palabra se repite demasiado, busca sinónimos.")
                    }
                }
            }

            1 -> {
                ScienceCard("Mayúsculas y minúsculas") {
                    StudioChipRow {
                        StudioChip("MAYÚSCULAS", false, onClick = { transform("Mayúsculas") { it.uppercase() } })
                        StudioChip("minúsculas", false, onClick = { transform("Minúsculas") { it.lowercase() } })
                        StudioChip("Tipo Título", false, onClick = { transform("Título") { TextLab.toTitleCase(it) } })
                        StudioChip("Tipo oración", false, onClick = { transform("Oración") { TextLab.toSentenceCase(it) } })
                    }
                }
                ScienceCard("Líneas") {
                    StudioChipRow {
                        StudioChip("Ordenar A-Z", false, onClick = { transform("Orden") { TextLab.sortLines(it) } })
                        StudioChip("Ordenar Z-A", false, onClick = { transform("Orden") { TextLab.sortLines(it, true) } })
                        StudioChip("Quitar repetidas", false, onClick = { transform("Duplicados") { TextLab.removeDuplicateLines(it) } })
                        StudioChip("Invertir", false, onClick = { transform("Inversión") { TextLab.reverseLines(it) } })
                    }
                }
                ScienceCard("Otros") {
                    StudioChipRow {
                        StudioChip("Quitar tildes", false, onClick = { transform("Tildes") { TextLab.removeAccents(it) } })
                        StudioChip("Convertir a slug", false, onClick = { transform("Slug") { TextLab.toSlug(it) } })
                    }
                    StudioHint("El slug sirve para nombres de archivo y direcciones web.")
                }
            }

            else -> {
                ScienceCard("Limpieza") {
                    StudioChipRow {
                        StudioChip("Normalizar espacios", false, onClick = { transform("Espacios") { TextLab.normalizeSpaces(it) } })
                        StudioChip("Texto pegado de PDF", false, onClick = { transform("Limpieza") { TextLab.cleanPdfText(it) } })
                    }
                    StudioHint(
                        "«Texto pegado de PDF» une las palabras cortadas con guion al final de línea y junta " +
                            "los saltos que parten una misma oración."
                    )
                }
                ScienceCard("Ejemplo de lo que arregla") {
                    FormulaText(
                        "Antes:  la investi-\\ngación demuestra\\nque...\n" +
                            "Después: la investigación demuestra que...",
                        size = 13,
                        color = StudioTheme.TextSecondary
                    )
                }
            }
        }

        message?.let { StudioHint(it) }
        LegalNote(
            "Estas herramientas ordenan y limpian tu propio texto. No reescriben trabajos ajenos: " +
                "citar bien es parte de la honestidad académica."
        )
    }
}

// ---------------------------------------------------------------------------
// Sistemas numéricos
// ---------------------------------------------------------------------------

/**
 * Sistemas numéricos.
 *
 * Los cuatro campos están vivos a la vez: escribes en cualquiera y los demás se
 * actualizan. Además muestra el complemento a dos, que es como los
 * computadores guardan los números negativos.
 */
@Composable
fun NumberSystemsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var decimalText by rememberSaveable { mutableStateOf("42") }
    var activeBase by rememberSaveable { mutableIntStateOf(10) }
    var input by rememberSaveable { mutableStateOf("42") }
    var bits by rememberSaveable { mutableIntStateOf(8) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var otherValue by rememberSaveable { mutableStateOf("12") }
    var customBase by rememberSaveable { mutableStateOf("36") }

    val parsed = runCatching { NumberLab.parse(input, activeBase) }
    val value = parsed.getOrNull()

    ScienceShell(
        title = "Sistemas numéricos",
        subtitle = value?.let { "Decimal $it" } ?: "Número inválido",
        onBack = onBack,
        trailing = {
            IconButton(onClick = {
                value?.let {
                    copyToClipboard(
                        context, "Conversión",
                        "Decimal: $it\nBinario: ${NumberLab.format(it, 2)}\n" +
                            "Octal: ${NumberLab.format(it, 8)}\nHexadecimal: ${NumberLab.format(it, 16)}"
                    )
                }
            }) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = "Copiar", tint = StudioTheme.TextPrimary)
            }
        }
    ) {
        StudioTabs(listOf("Convertir", "Bits", "Decimales"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Escribe en la base que quieras") {
                    StudioChipRow {
                        listOf(2 to "Binario", 8 to "Octal", 10 to "Decimal", 16 to "Hexadecimal").forEach { (base, name) ->
                            StudioChip(
                                label = name,
                                active = activeBase == base,
                                onClick = {
                                    val current = parsed.getOrNull()
                                    activeBase = base
                                    if (current != null) input = NumberLab.format(current, base)
                                },
                                caption = "base $base"
                            )
                        }
                    }
                    StudioTextField(input, { input = it.uppercase() }, "Número en base $activeBase", modifier = Modifier.fillMaxWidth())
                    if (parsed.isFailure) {
                        ScienceError(parsed.exceptionOrNull()?.message ?: "Número inválido.")
                    }
                }

                if (value != null) {
                    ScienceCard("Equivalencias", accent = true) {
                        MoneyRow("Binario", NumberLab.groupBinary(NumberLab.format(value, 2)))
                        MoneyRow("Octal", NumberLab.format(value, 8))
                        MoneyRow("Decimal", value.toString())
                        MoneyRow("Hexadecimal", NumberLab.format(value, 16))
                    }

                    ScienceCard("Otra base") {
                        ScienceNumberField(customBase, { customBase = it }, "Base (2 a 36)", Modifier.fillMaxWidth())
                        val base = customBase.toIntOrNull()?.coerceIn(2, 36) ?: 36
                        MoneyRow("En base $base", NumberLab.format(value, base))
                        StudioHint("A partir de la base 11 se usan letras: A vale 10, B vale 11 y así.")
                    }
                }
            }

            1 -> {
                if (value == null) {
                    StudioHint("Escribe un número válido en la pestaña «Convertir».")
                } else {
                    ScienceCard("Complemento a dos") {
                        StudioChipRow {
                            listOf(8, 16, 32).forEach { size ->
                                StudioChip("$size bits", bits == size, onClick = { bits = size })
                            }
                        }
                        val complement = runCatching { NumberLab.twosComplement(value, bits) }
                        complement.exceptionOrNull()?.let { ScienceError(it.message ?: "Fuera de rango.") }
                        complement.getOrNull()?.let {
                            MoneyRow("Representación", NumberLab.groupBinary(it))
                            StudioHint(
                                "Así guarda el computador los negativos: se invierten los bits y se suma uno. " +
                                    "Con $bits bits el rango va de ${-(1L shl (bits - 1))} a ${(1L shl (bits - 1)) - 1}."
                            )
                        }
                    }

                    ScienceCard("Operaciones bit a bit") {
                        ScienceNumberField(otherValue, { otherValue = it }, "Segundo número (decimal)", Modifier.fillMaxWidth())
                        val other = otherValue.toLongOrNull() ?: 0L
                        val result = NumberLab.bitwise(value, other)
                        MoneyRow("AND", "${result.and}  ·  ${NumberLab.format(result.and, 2)}")
                        MoneyRow("OR", "${result.or}  ·  ${NumberLab.format(result.or, 2)}")
                        MoneyRow("XOR", "${result.xor}  ·  ${NumberLab.format(result.xor, 2)}")
                        MoneyRow("Desplazar izquierda", result.shiftLeft.toString())
                        MoneyRow("Desplazar derecha", result.shiftRight.toString())
                        StudioHint("Desplazar a la izquierda multiplica por dos; a la derecha, divide entre dos.")
                    }
                }
            }

            else -> {
                ScienceCard("Números con decimales") {
                    ScienceNumberField(decimalText, { decimalText = it }, "Número decimal", Modifier.fillMaxWidth())
                    val number = decimalText.replace(',', '.').toDoubleOrNull()
                    if (number == null) {
                        ScienceError("Escribe un número válido.")
                    } else {
                        val breakdown = NumberLab.ieee754(number)
                        MoneyRow("Signo", breakdown.sign)
                        MoneyRow("Exponente", "${breakdown.exponentBits} (${breakdown.exponentValue})")
                        MoneyRow("Mantisa", breakdown.mantissaBits)
                        MoneyRow("Valor reconstruido", breakdown.reconstructed.toString())
                        StudioHint(NumberLab.floatingPointNote(number))
                    }
                }
                ScienceCard("Por qué importa") {
                    StudioHint(
                        "0,1 + 0,2 no da exactamente 0,3 en coma flotante porque ninguno de los dos cabe exacto " +
                            "en binario. Por eso el dinero se calcula con decimales exactos y no con este formato."
                    )
                }
            }
        }
    }
}
