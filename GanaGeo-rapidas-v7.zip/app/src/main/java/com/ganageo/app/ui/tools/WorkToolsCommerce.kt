package com.ganageo.app.ui.tools

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.InventoryMovementStore
import com.ganageo.app.data.InventoryStore
import com.ganageo.app.tools.CurrencyInfo
import com.ganageo.app.tools.FiscalData
import com.ganageo.app.tools.InventoryEngine
import com.ganageo.app.tools.Money
import com.ganageo.app.tools.PriceBasis
import com.ganageo.app.tools.PricingEngine
import java.math.BigDecimal
import kotlinx.coroutines.launch

// ---------------------------------------------------------------------------
// Comisiones y ganancias
// ---------------------------------------------------------------------------

/**
 * Comisiones, margen y precio de venta.
 *
 * El error que más plata cuesta en el comercio pequeño es confundir margen con
 * markup. Un 50 % de markup sobre el costo deja solo 33,3 % de margen sobre la
 * venta. Aquí hay que elegir explícitamente cuál se está usando y la app muestra
 * siempre los dos resultados en paralelo para que quede claro.
 */
@Composable
fun CommissionMarginScreen(onBack: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val currency = CurrencyInfo.PEN

    var cost by rememberSaveable { mutableStateOf("100") }
    var percent by rememberSaveable { mutableStateOf("30") }
    var basisIndex by rememberSaveable { mutableIntStateOf(0) }
    var commission by rememberSaveable { mutableStateOf("0") }
    var taxPercent by rememberSaveable { mutableStateOf("18") }
    var applyTax by rememberSaveable { mutableStateOf(true) }

    var salePrice by rememberSaveable { mutableStateOf("150") }

    var fixedCosts by rememberSaveable { mutableStateOf("2000") }
    var variableCost by rememberSaveable { mutableStateOf("60") }
    var unitPrice by rememberSaveable { mutableStateOf("100") }

    var sales by rememberSaveable { mutableStateOf("12000") }

    val basis = PriceBasis.entries[basisIndex.coerceIn(0, 1)]
    val tax = if (applyTax) Money.parseOrNull(taxPercent) ?: BigDecimal.ZERO else BigDecimal.ZERO

    ScienceShell(
        title = "Comisiones y ganancias",
        subtitle = "Margen, markup, comisión y punto de equilibrio",
        onBack = onBack
    ) {
        StudioTabs(listOf("Precio", "Análisis", "Comisión", "Equilibrio"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Qué porcentaje estás usando") {
                    StudioChipRow {
                        PriceBasis.entries.forEachIndexed { index, entry ->
                            StudioChip(entry.label, basisIndex == index, onClick = { basisIndex = index })
                        }
                    }
                    StudioHint(basis.explanation)
                }

                ScienceCard("Datos") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(cost, { cost = it }, "Costo del producto", Modifier.weight(1.3f))
                        ScienceNumberField(percent, { percent = it }, "${basis.label} %", Modifier.weight(1f))
                    }
                    ScienceNumberField(commission, { commission = it }, "Comisión del vendedor %", Modifier.fillMaxWidth())
                    StudioChipRow {
                        StudioChip("Agregar ${FiscalData.country("PE").taxName}", applyTax, onClick = { applyTax = !applyTax })
                        if (applyTax) {
                            ScienceNumberField(taxPercent, { taxPercent = it }, "Tasa %", Modifier.width(110.dp))
                        }
                    }
                }

                val costValue = Money.ofOrZero(cost)
                val percentValue = Money.ofOrZero(percent)
                val commissionValue = Money.ofOrZero(commission)
                val price = runCatching {
                    PricingEngine.priceFor(costValue, percentValue, basis, commissionValue)
                }

                price.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los porcentajes.") }
                price.getOrNull()?.let { computed ->
                    val analysis = PricingEngine.analyze(costValue, computed, commissionValue, tax)
                    WorkTotals(
                        rows = listOf(
                            "Costo" to Money.format(analysis.cost, currency),
                            "Ganancia bruta" to Money.format(analysis.grossProfit, currency),
                            "Comisión" to "− " + Money.format(analysis.commission, currency),
                            "Ganancia neta" to Money.format(analysis.netProfit, currency)
                        ),
                        total = if (applyTax) {
                            "Precio con impuesto" to Money.format(analysis.priceWithTax, currency)
                        } else {
                            "Precio de venta" to Money.format(analysis.salePrice, currency)
                        },
                        note = if (applyTax) {
                            "Sin impuesto: ${Money.format(analysis.salePrice, currency)} · " +
                                "El impuesto va encima del margen, no se lo come."
                        } else null
                    )

                    ScienceCard("Los dos porcentajes") {
                        MoneyRow("Margen sobre la venta", Money.formatPercent(analysis.marginPercent), highlight = basis == PriceBasis.MARGIN)
                        MoneyRow("Markup sobre el costo", Money.formatPercent(analysis.markupPercent), highlight = basis == PriceBasis.MARKUP)
                        StudioHint(
                            "Son distintos: un markup de ${Money.formatPercent(analysis.markupPercent)} equivale a " +
                                "un margen de ${Money.formatPercent(analysis.marginPercent)}."
                        )
                    }
                }
            }

            1 -> {
                ScienceCard("Venta ya realizada") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(cost, { cost = it }, "Costo", Modifier.weight(1f))
                        ScienceNumberField(salePrice, { salePrice = it }, "Precio de venta", Modifier.weight(1f))
                    }
                    ScienceNumberField(commission, { commission = it }, "Comisión %", Modifier.fillMaxWidth())
                }
                val analysis = runCatching {
                    PricingEngine.analyze(
                        Money.ofOrZero(cost),
                        Money.ofOrZero(salePrice),
                        Money.ofOrZero(commission),
                        tax
                    )
                }
                analysis.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los datos.") }
                analysis.getOrNull()?.let { result ->
                    WorkTotals(
                        rows = listOf(
                            "Ganancia bruta" to Money.format(result.grossProfit, currency),
                            "Comisión" to "− " + Money.format(result.commission, currency),
                            "Margen" to Money.formatPercent(result.marginPercent),
                            "Markup" to Money.formatPercent(result.markupPercent)
                        ),
                        total = "Ganancia neta" to Money.format(result.netProfit, currency)
                    )
                    if (result.netProfit.signum() <= 0) {
                        ScienceError("Con ese precio estás perdiendo dinero en cada venta.")
                    }
                }
            }

            2 -> {
                ScienceCard("Comisión escalonada") {
                    ScienceNumberField(sales, { sales = it }, "Ventas del periodo", Modifier.fillMaxWidth())
                    StudioHint(
                        "Escala de ejemplo: 2 % hasta 5 000, 4 % de 5 000 a 10 000 y 6 % de ahí en adelante. " +
                            "Cada tramo paga su propio porcentaje, no todo se paga a la tasa más alta."
                    )
                }
                val tiers = listOf(
                    PricingEngine.CommissionTier(BigDecimal.ZERO, BigDecimal("2")),
                    PricingEngine.CommissionTier(BigDecimal("5000"), BigDecimal("4")),
                    PricingEngine.CommissionTier(BigDecimal("10000"), BigDecimal("6"))
                )
                val salesValue = Money.ofOrZero(sales)
                val tiered = PricingEngine.tieredCommission(salesValue, tiers)
                val flat = Money.percent(salesValue, Money.ofOrZero(commission))
                WorkTotals(
                    rows = listOf(
                        "Ventas" to Money.format(salesValue, currency),
                        "Comisión plana (${Money.formatPercent(Money.ofOrZero(commission))})" to Money.format(flat, currency)
                    ),
                    total = "Comisión escalonada" to Money.format(tiered, currency)
                )
            }

            else -> {
                ScienceCard("Punto de equilibrio") {
                    ScienceNumberField(fixedCosts, { fixedCosts = it }, "Costos fijos del mes", Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(unitPrice, { unitPrice = it }, "Precio por unidad", Modifier.weight(1f))
                        ScienceNumberField(variableCost, { variableCost = it }, "Costo variable", Modifier.weight(1f))
                    }
                }
                val result = runCatching {
                    PricingEngine.breakEvenUnits(
                        Money.ofOrZero(fixedCosts),
                        Money.ofOrZero(unitPrice),
                        Money.ofOrZero(variableCost)
                    )
                }
                result.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los datos.") }
                result.getOrNull()?.let { units ->
                    val contribution = Money.ofOrZero(unitPrice).subtract(Money.ofOrZero(variableCost))
                    WorkTotals(
                        rows = listOf(
                            "Margen de contribución por unidad" to Money.format(contribution, currency),
                            "Ventas necesarias" to Money.format(
                                units.multiply(Money.ofOrZero(unitPrice)),
                                currency
                            )
                        ),
                        total = "Unidades para no perder" to Money.formatQuantity(units),
                        note = "A partir de esa cantidad, cada unidad vendida ya es ganancia."
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Inventario
// ---------------------------------------------------------------------------

/**
 * Inventario básico con kardex.
 *
 * Guardar los movimientos es lo que permite valorizar el stock de verdad: con el
 * costo promedio ponderado, cada compra recalcula el costo unitario. Sin
 * historial solo se puede adivinar con el último precio de compra, que casi
 * nunca es el costo real de lo que hay en el almacén.
 */
@Composable
fun InventoryBasicScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { InventoryStore(context) }
    val movementStore = remember { InventoryMovementStore(context) }
    val items by store.items.collectAsState(initial = emptyList())
    val movements by movementStore.movements.collectAsState(initial = emptyList())
    val currency = CurrencyInfo.PEN

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var name by rememberSaveable { mutableStateOf("") }
    var sku by rememberSaveable { mutableStateOf("") }
    var quantity by rememberSaveable { mutableStateOf("") }
    var minimum by rememberSaveable { mutableStateOf("") }
    var unitCost by rememberSaveable { mutableStateOf("") }
    var unitSale by rememberSaveable { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var moveQuantity by rememberSaveable { mutableStateOf("1") }
    var moveCost by rememberSaveable { mutableStateOf("") }

    val lowStock = items.filter { it.quantity <= it.minimumStock && it.minimumStock > 0 }
    val totalCost = items.fold(BigDecimal.ZERO) { acc, item ->
        acc.add(Money.fromCents(item.unitCostCents).multiply(BigDecimal(item.quantity.toString())))
    }
    val totalSale = items.fold(BigDecimal.ZERO) { acc, item ->
        acc.add(Money.fromCents(item.unitSaleCents).multiply(BigDecimal(item.quantity.toString())))
    }

    val csvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            val csv = buildString {
                appendLine("Producto,SKU,Stock,Minimo,Costo,Precio,Valor costo,Valor venta")
                items.forEach { item ->
                    val cost = Money.fromCents(item.unitCostCents)
                    val sale = Money.fromCents(item.unitSaleCents)
                    val qty = BigDecimal(item.quantity.toString())
                    appendLine(
                        listOf(
                            csvCell(item.name),
                            csvCell(item.sku),
                            Money.formatQuantity(qty),
                            Money.formatQuantity(BigDecimal(item.minimumStock.toString())),
                            cost.toPlainString(),
                            sale.toPlainString(),
                            Money.round(cost.multiply(qty)).toPlainString(),
                            Money.round(sale.multiply(qty)).toPlainString()
                        ).joinToString(",")
                    )
                }
            }
            writeTextToUri(context, uri, csv)
        }.onSuccess { message = "Inventario exportado." }
            .onFailure { message = it.message ?: "No se pudo exportar." }
    }

    ScienceShell(
        title = "Inventario básico",
        subtitle = "${items.size} productos · ${lowStock.size} bajo el mínimo",
        onBack = onBack
    ) {
        StudioTabs(listOf("Productos", "Movimiento", "Valuación"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Nuevo producto") {
                    StudioTextField(name, { name = it }, "Nombre", modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioTextField(sku, { sku = it }, "SKU o código", modifier = Modifier.weight(1f))
                        ScienceNumberField(quantity, { quantity = it }, "Stock inicial", Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(unitCost, { unitCost = it }, "Costo unitario", Modifier.weight(1f))
                        ScienceNumberField(unitSale, { unitSale = it }, "Precio de venta", Modifier.weight(1f))
                    }
                    ScienceNumberField(minimum, { minimum = it }, "Stock mínimo (alerta)", Modifier.fillMaxWidth())
                    val costValue = Money.parseOrNull(unitCost)
                    val saleValue = Money.parseOrNull(unitSale)
                    if (costValue != null && saleValue != null && costValue.signum() > 0 && saleValue.signum() > 0) {
                        val analysis = PricingEngine.analyze(costValue, saleValue)
                        StudioHint(
                            "Con esos valores el margen es ${Money.formatPercent(analysis.marginPercent)} " +
                                "y el markup ${Money.formatPercent(analysis.markupPercent)}."
                        )
                    }
                    WorkActionButton("Guardar producto", {
                        scope.launch {
                            runCatching {
                                store.add(
                                    name = name,
                                    sku = sku,
                                    quantity = Money.ofOrZero(quantity).toDouble(),
                                    minimumStock = Money.ofOrZero(minimum).toDouble(),
                                    unitCost = Money.ofOrZero(unitCost).toDouble(),
                                    unitSale = Money.ofOrZero(unitSale).toDouble()
                                )
                            }.onSuccess {
                                name = ""; sku = ""; quantity = ""; minimum = ""
                                unitCost = ""; unitSale = ""
                                message = "Producto guardado."
                            }.onFailure { message = it.message ?: "No se pudo guardar." }
                        }
                    }, Icons.Rounded.Add)
                }

                if (lowStock.isNotEmpty()) {
                    LegalNote(
                        "Bajo el mínimo: " + lowStock.joinToString(", ") { it.name } +
                            ". Conviene reponer antes de quedarte sin stock."
                    )
                }

                items.forEach { item ->
                    val cost = Money.fromCents(item.unitCostCents)
                    val sale = Money.fromCents(item.unitSaleCents)
                    val qty = BigDecimal(item.quantity.toString())
                    ScienceCard(item.name) {
                        if (item.sku.isNotBlank()) {
                            Text(
                                "SKU ${item.sku}",
                                color = StudioTheme.TextSecondary,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        MoneyRow(
                            "Stock",
                            Money.formatQuantity(qty),
                            highlight = item.quantity <= item.minimumStock && item.minimumStock > 0
                        )
                        MoneyRow("Costo unitario", Money.format(cost, currency))
                        MoneyRow("Precio de venta", Money.format(sale, currency))
                        MoneyRow("Valor en costo", Money.format(cost.multiply(qty), currency))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StudioChip(
                                label = if (selectedId == item.id) "Seleccionado" else "Mover stock",
                                active = selectedId == item.id,
                                onClick = {
                                    selectedId = item.id
                                    moveCost = cost.toPlainString()
                                    tab = 1
                                }
                            )
                            androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                            IconButton(onClick = {
                                scope.launch {
                                    store.delete(item.id)
                                    movementStore.deleteForItem(item.id)
                                }
                            }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = StudioTheme.TextSecondary)
                            }
                        }
                    }
                }

                if (items.isEmpty()) {
                    StudioHint("Todavía no hay productos. Agrega el primero arriba.")
                }
            }

            1 -> {
                val selected = items.firstOrNull { it.id == selectedId }
                if (selected == null) {
                    StudioHint("Elige un producto en la pestaña «Productos» para registrar entradas o salidas.")
                } else {
                    ScienceCard("Movimiento de ${selected.name}") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ScienceNumberField(moveQuantity, { moveQuantity = it }, "Cantidad", Modifier.weight(1f))
                            ScienceNumberField(moveCost, { moveCost = it }, "Costo unitario", Modifier.weight(1f))
                        }
                        MoneyRow("Stock actual", Money.formatQuantity(BigDecimal(selected.quantity.toString())))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StudioChip("Entrada", false, onClick = {
                                scope.launch {
                                    runCatching {
                                        val qty = Money.ofOrZero(moveQuantity).toDouble()
                                        store.adjustStock(selected.id, qty)
                                        movementStore.add(
                                            selected.id, selected.name, "entrada", qty,
                                            Money.ofOrZero(moveCost).toDouble()
                                        )
                                    }.onSuccess { message = "Entrada registrada." }
                                        .onFailure { message = it.message ?: "No se pudo registrar." }
                                }
                            })
                            StudioChip("Salida", false, onClick = {
                                scope.launch {
                                    runCatching {
                                        val qty = Money.ofOrZero(moveQuantity).toDouble()
                                        store.adjustStock(selected.id, -qty)
                                        movementStore.add(
                                            selected.id, selected.name, "salida", qty,
                                            Money.ofOrZero(moveCost).toDouble()
                                        )
                                    }.onSuccess { message = "Salida registrada." }
                                        .onFailure { message = it.message ?: "No se pudo registrar." }
                                }
                            })
                        }
                        val entradas = movements.filter { it.itemId == selected.id && it.type == "entrada" }
                        if (entradas.isNotEmpty()) {
                            val average = entradas.fold(BigDecimal.ZERO to BigDecimal.ZERO) { acc, move ->
                                val qty = BigDecimal(move.quantity.toString())
                                acc.first.add(qty) to acc.second.add(qty.multiply(Money.fromCents(move.unitCostCents)))
                            }
                            if (average.first.signum() > 0) {
                                val weighted = average.second.divide(average.first, 4, java.math.RoundingMode.HALF_UP)
                                MoneyRow("Costo promedio de las compras", Money.format(weighted, currency), highlight = true)
                                StudioHint("Promedio ponderado: cada compra recalcula el costo unitario real.")
                            }
                        }
                    }
                }

                ScienceCard("Kardex") {
                    if (movements.isEmpty()) {
                        StudioHint("Aún no hay movimientos registrados.")
                    } else {
                        movements.take(40).forEach { move ->
                            MoneyRow(
                                "${move.type.replaceFirstChar { it.uppercase() }} · ${move.itemName}",
                                "${Money.formatQuantity(BigDecimal(move.quantity.toString()))} × " +
                                    Money.format(Money.fromCents(move.unitCostCents), currency)
                            )
                        }
                    }
                }
            }

            else -> {
                WorkTotals(
                    rows = listOf(
                        "Productos" to items.size.toString(),
                        "Valorizado al costo" to Money.format(totalCost, currency),
                        "Valorizado a precio de venta" to Money.format(totalSale, currency)
                    ),
                    total = "Ganancia potencial" to Money.format(totalSale.subtract(totalCost), currency),
                    note = "La ganancia potencial es lo que quedaría si vendieras todo el stock al precio actual."
                )

                ScienceCard("Punto de reorden") {
                    var dailyUsage by rememberSaveable { mutableStateOf("5") }
                    var leadTime by rememberSaveable { mutableStateOf("7") }
                    var safety by rememberSaveable { mutableStateOf("10") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(dailyUsage, { dailyUsage = it }, "Venta diaria", Modifier.weight(1f))
                        ScienceNumberField(leadTime, { leadTime = it }, "Días de entrega", Modifier.weight(1f))
                        ScienceNumberField(safety, { safety = it }, "Seguridad", Modifier.weight(1f))
                    }
                    val point = InventoryEngine.reorderPoint(
                        Money.ofOrZero(dailyUsage),
                        leadTime.toIntOrNull() ?: 0,
                        Money.ofOrZero(safety)
                    )
                    MoneyRow("Volver a pedir cuando el stock llegue a", Money.formatQuantity(point), highlight = true)
                    StudioHint(
                        "Consumo diario × días que tarda el proveedor + stock de seguridad. " +
                            "Así no te quedas sin producto mientras llega el pedido."
                    )
                }

                WorkActionButton(
                    "Exportar inventario en CSV",
                    { csvLauncher.launch("inventario.csv") },
                    Icons.Rounded.Save,
                    enabled = items.isNotEmpty()
                )
                StudioHint("El CSV se abre en Excel o en Google Sheets.")
            }
        }

        message?.let { StudioHint(it) }
    }
}
