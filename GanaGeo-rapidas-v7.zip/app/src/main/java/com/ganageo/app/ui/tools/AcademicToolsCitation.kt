package com.ganageo.app.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.CitationAuthor
import com.ganageo.app.tools.CitationEngine
import com.ganageo.app.tools.CitationStyle
import com.ganageo.app.tools.SourceData
import com.ganageo.app.tools.SourceType

/** Convierte los asteriscos del motor en cursiva de verdad. */
@Composable
fun ItalicMarkdownText(text: String, modifier: Modifier = Modifier) {
    val annotated: AnnotatedString = buildAnnotatedString {
        var italic = false
        text.split("*").forEachIndexed { index, chunk ->
            if (index > 0) italic = !italic
            if (italic) {
                pushStyle(SpanStyle(fontStyle = FontStyle.Italic))
                append(chunk)
                pop()
            } else {
                append(chunk)
            }
        }
    }
    Text(
        annotated,
        modifier = modifier,
        color = StudioTheme.TextPrimary,
        style = MaterialTheme.typography.bodyMedium
    )
}

/**
 * Generador de referencias.
 *
 * Cada estilo tiene su propia plantilla campo por campo. El detalle que más se
 * falla es la cita dentro del texto: desde APA 7, con tres autores o más se
 * escribe «et al.» ya en la primera mención, no a partir de la segunda.
 */
@Composable
fun CitationGeneratorScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var styleIndex by rememberSaveable { mutableIntStateOf(0) }
    var typeIndex by rememberSaveable { mutableIntStateOf(0) }
    var spanish by rememberSaveable { mutableStateOf(true) }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    var authors by rememberSaveable { mutableStateOf("") }
    var year by rememberSaveable { mutableStateOf("") }
    var title by rememberSaveable { mutableStateOf("") }
    var container by rememberSaveable { mutableStateOf("") }
    var editors by rememberSaveable { mutableStateOf("") }
    var edition by rememberSaveable { mutableStateOf("") }
    var volume by rememberSaveable { mutableStateOf("") }
    var issue by rememberSaveable { mutableStateOf("") }
    var pages by rememberSaveable { mutableStateOf("") }
    var publisher by rememberSaveable { mutableStateOf("") }
    var siteName by rememberSaveable { mutableStateOf("") }
    var doi by rememberSaveable { mutableStateOf("") }
    var url by rememberSaveable { mutableStateOf("") }
    var accessed by rememberSaveable { mutableStateOf("") }
    var university by rememberSaveable { mutableStateOf("") }
    var thesisKind by rememberSaveable { mutableStateOf("Tesis de licenciatura") }
    var city by rememberSaveable { mutableStateOf("") }
    var identifier by rememberSaveable { mutableStateOf("") }
    var pageCited by rememberSaveable { mutableStateOf("") }

    val saved = remember { mutableStateListOf<String>() }
    var message by remember { mutableStateOf<String?>(null) }

    val style = CitationStyle.entries[styleIndex.coerceIn(0, CitationStyle.entries.lastIndex)]
    val type = SourceType.entries[typeIndex.coerceIn(0, SourceType.entries.lastIndex)]

    val data = SourceData(
        type = type,
        authors = CitationEngine.parseAuthors(authors),
        year = year.trim(),
        title = title.trim(),
        containerTitle = container.trim(),
        editors = CitationEngine.parseAuthors(editors),
        edition = edition.trim(),
        volume = volume.trim(),
        issue = issue.trim(),
        pages = pages.trim(),
        publisher = publisher.trim(),
        siteName = siteName.trim(),
        doi = doi.trim(),
        url = url.trim(),
        accessed = accessed.trim(),
        university = university.trim(),
        thesisKind = thesisKind.trim(),
        city = city.trim(),
        identifier = identifier.trim()
    )

    val reference = CitationEngine.reference(style, data, spanish)
    val missing = CitationEngine.missingFields(data)

    fun clearForm() {
        authors = ""; year = ""; title = ""; container = ""; editors = ""
        edition = ""; volume = ""; issue = ""; pages = ""; publisher = ""
        siteName = ""; doi = ""; url = ""; accessed = ""; university = ""
        city = ""; identifier = ""
    }

    ScienceShell(
        title = "Generador de referencias",
        subtitle = "${style.label} · ${type.label}",
        onBack = onBack,
        trailing = {
            IconButton(onClick = {
                copyToClipboard(context, "Referencia", CitationEngine.plain(reference))
                message = "Referencia copiada."
            }) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = "Copiar", tint = StudioTheme.TextPrimary)
            }
        }
    ) {
        StudioTabs(listOf("Fuente", "Datos", "Bibliografía"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Estilo") {
                    StudioChipRow {
                        CitationStyle.entries.forEachIndexed { index, entry ->
                            StudioChip(entry.label, styleIndex == index, onClick = { styleIndex = index })
                        }
                    }
                    StudioHint(style.description)
                    if (style == CitationStyle.APA7) {
                        StudioChipRow {
                            StudioChip("Trabajo en español (y)", spanish, onClick = { spanish = true })
                            StudioChip("En inglés (&)", !spanish, onClick = { spanish = false })
                        }
                        StudioHint(
                            "En un trabajo en español se une el último autor con «y»; en inglés se usa «&»."
                        )
                    }
                }

                ScienceCard("Tipo de fuente") {
                    StudioChipRow {
                        SourceType.entries.forEachIndexed { index, entry ->
                            StudioChip(entry.label, typeIndex == index, onClick = { typeIndex = index })
                        }
                    }
                    StudioHint("Necesitas: " + CitationEngine.requiredFields(type).joinToString(", ") + ".")
                }
            }

            1 -> {
                ScienceCard("Autoría") {
                    ScienceTextArea(
                        value = authors,
                        onValueChange = { authors = it },
                        label = "Autores",
                        placeholder = "García Márquez, Gabriel; Vargas Llosa, Mario",
                        minHeight = 80
                    )
                    StudioHint(
                        "Separa con punto y coma. En español los dos apellidos van juntos y no se abrevia el " +
                            "segundo: «García Márquez, G.». Si es una institución, escríbela completa."
                    )
                    if (data.authors.isNotEmpty()) {
                        StudioHint("Detectados: " + data.authors.joinToString(" · ") { describeAuthor(it) })
                    }
                }

                ScienceCard("Datos de la fuente") {
                    StudioTextField(title, { title = it }, "Título", modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(year, { year = it }, "Año", Modifier.weight(1f))
                        if (type == SourceType.WEBSITE || type == SourceType.VIDEO) {
                            StudioTextField(accessed, { accessed = it }, "Consultado el", modifier = Modifier.weight(1.4f))
                        }
                    }
                    when (type) {
                        SourceType.BOOK, SourceType.REPORT -> {
                            StudioTextField(publisher, { publisher = it }, "Editorial", modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                StudioTextField(edition, { edition = it }, "Edición", modifier = Modifier.weight(1f))
                                StudioTextField(city, { city = it }, "Ciudad", modifier = Modifier.weight(1f))
                            }
                            if (type == SourceType.REPORT) {
                                StudioTextField(identifier, { identifier = it }, "N.º de informe", modifier = Modifier.fillMaxWidth())
                            }
                        }
                        SourceType.CHAPTER -> {
                            StudioTextField(container, { container = it }, "Título del libro", modifier = Modifier.fillMaxWidth())
                            StudioTextField(editors, { editors = it }, "Editores", modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                StudioTextField(pages, { pages = it }, "Páginas", modifier = Modifier.weight(1f))
                                StudioTextField(publisher, { publisher = it }, "Editorial", modifier = Modifier.weight(1.2f))
                            }
                        }
                        SourceType.ARTICLE -> {
                            StudioTextField(container, { container = it }, "Nombre de la revista", modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                StudioTextField(volume, { volume = it }, "Volumen", modifier = Modifier.weight(1f))
                                StudioTextField(issue, { issue = it }, "Número", modifier = Modifier.weight(1f))
                                StudioTextField(pages, { pages = it }, "Páginas", modifier = Modifier.weight(1.2f))
                            }
                            StudioTextField(doi, { doi = it }, "DOI", modifier = Modifier.fillMaxWidth())
                            if (doi.isNotBlank()) {
                                StudioHint("Se guardará como ${CitationEngine.normalizeDoi(doi)} y sin punto final.")
                            }
                        }
                        SourceType.WEBSITE, SourceType.VIDEO -> {
                            StudioTextField(siteName, { siteName = it }, "Sitio o plataforma", modifier = Modifier.fillMaxWidth())
                            StudioTextField(url, { url = it }, "URL", modifier = Modifier.fillMaxWidth())
                        }
                        SourceType.THESIS -> {
                            StudioTextField(university, { university = it }, "Universidad", modifier = Modifier.fillMaxWidth())
                            StudioChipRow {
                                listOf("Tesis de licenciatura", "Tesis de maestría", "Tesis doctoral").forEach { kind ->
                                    StudioChip(kind, thesisKind == kind, onClick = { thesisKind = kind })
                                }
                            }
                            StudioTextField(url, { url = it }, "Repositorio o URL", modifier = Modifier.fillMaxWidth())
                        }
                        SourceType.CONFERENCE -> {
                            StudioTextField(container, { container = it }, "Nombre del congreso", modifier = Modifier.fillMaxWidth())
                            StudioTextField(city, { city = it }, "Ciudad", modifier = Modifier.fillMaxWidth())
                        }
                        SourceType.LAW -> {
                            StudioTextField(identifier, { identifier = it }, "Número de la norma", modifier = Modifier.fillMaxWidth())
                            StudioTextField(publisher, { publisher = it }, "Publicación oficial", modifier = Modifier.fillMaxWidth())
                        }
                    }
                }

                if (missing.isNotEmpty()) {
                    ScienceError("Faltan datos: " + missing.joinToString(", ") + ".")
                }

                ScienceCard("Referencia", accent = true) {
                    ItalicMarkdownText(reference)
                    StudioHint("Lo que va en cursiva ya está marcado. En Word aplícalo tal cual.")
                }

                ScienceCard("Cita dentro del texto") {
                    ScienceNumberField(pageCited, { pageCited = it }, "Página citada (opcional)", Modifier.fillMaxWidth())
                    val number = saved.size + 1
                    ScienceRow(
                        "Entre paréntesis",
                        CitationEngine.inText(style, data, number, pageCited, narrative = false, spanish = spanish),
                        highlight = true
                    )
                    ScienceRow(
                        "Narrativa",
                        CitationEngine.inText(style, data, number, pageCited, narrative = true, spanish = spanish)
                    )
                    if (style == CitationStyle.APA7 && data.authors.size >= 3) {
                        StudioHint("Con tres autores o más, APA 7 usa «et al.» desde la primera cita.")
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StudioSecondaryButton(
                        label = "Añadir a bibliografía",
                        icon = Icons.Rounded.Add,
                        onClick = {
                            if (missing.isEmpty()) {
                                saved.add(reference)
                                clearForm()
                                message = "Referencia añadida."
                                tab = 2
                            } else {
                                message = "Completa los datos que faltan antes de añadirla."
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                    StudioSecondaryButton(
                        label = "Limpiar",
                        icon = Icons.Rounded.Delete,
                        onClick = { clearForm() },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            else -> {
                if (saved.isEmpty()) {
                    StudioHint("Aún no has añadido referencias. Complétalas en «Datos» y pulsa «Añadir a bibliografía».")
                } else {
                    val ordered = CitationEngine.sortReferences(style, saved.toList())
                    ScienceCard("Bibliografía (${ordered.size})") {
                        ordered.forEachIndexed { index, entry ->
                            Row(verticalAlignment = Alignment.Top) {
                                if (style == CitationStyle.VANCOUVER || style == CitationStyle.IEEE) {
                                    Text(
                                        if (style == CitationStyle.IEEE) "[${index + 1}] " else "${index + 1}. ",
                                        color = StudioTheme.TextSecondary,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                ItalicMarkdownText(entry, Modifier.weight(1f))
                                IconButton(onClick = { saved.remove(entry) }) {
                                    Icon(
                                        Icons.Rounded.Delete,
                                        contentDescription = "Quitar",
                                        tint = StudioTheme.TextSecondary
                                    )
                                }
                            }
                        }
                        StudioHint(
                            when (style) {
                                CitationStyle.VANCOUVER, CitationStyle.IEEE ->
                                    "En este estilo la lista va por orden de aparición en el texto, no alfabético."
                                else ->
                                    "Lista ordenada alfabéticamente. En Word aplícale sangría francesa de 1,27 cm."
                            }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioSecondaryButton(
                            label = "Copiar todo",
                            icon = Icons.Rounded.ContentCopy,
                            onClick = {
                                copyToClipboard(
                                    context,
                                    "Bibliografía",
                                    ordered.joinToString("\n\n") { CitationEngine.plain(it) }
                                )
                                message = "Bibliografía copiada."
                            },
                            modifier = Modifier.weight(1f)
                        )
                        StudioSecondaryButton(
                            label = "Compartir",
                            icon = Icons.Rounded.Share,
                            onClick = {
                                shareText(
                                    context,
                                    "Bibliografía",
                                    ordered.joinToString("\n\n") { CitationEngine.plain(it) }
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                ScienceCard("Exportar la ficha actual") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioSecondaryButton(
                            label = "RIS",
                            icon = Icons.Rounded.ContentCopy,
                            onClick = {
                                copyToClipboard(context, "RIS", CitationEngine.toRis(data))
                                message = "Formato RIS copiado. Se importa en Mendeley o Zotero."
                            },
                            modifier = Modifier.weight(1f)
                        )
                        StudioSecondaryButton(
                            label = "BibTeX",
                            icon = Icons.Rounded.ContentCopy,
                            onClick = {
                                copyToClipboard(context, "BibTeX", CitationEngine.toBibTeX(data))
                                message = "Formato BibTeX copiado. Se usa en LaTeX y Overleaf."
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        message?.let { StudioHint(it) }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(StudioTheme.Surface)
                .padding(12.dp)
        ) {
            Text(
                "Las normas cambian con cada edición y muchas universidades tienen su propio manual. " +
                    "Contrasta el resultado con la guía que te pidió tu profesor.",
                color = StudioTheme.TextSecondary,
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}

private fun describeAuthor(author: CitationAuthor): String =
    if (author.isOrganization) "${author.lastName} (institución)"
    else "${author.lastName}, ${author.firstNames}".trim().trimEnd(',')
