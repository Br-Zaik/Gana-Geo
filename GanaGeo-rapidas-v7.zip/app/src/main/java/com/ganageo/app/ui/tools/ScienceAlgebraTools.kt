package com.ganageo.app.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.AlgebraSteps
import com.ganageo.app.tools.LinearAlgebraPro
import com.ganageo.app.tools.MathEngine
import com.ganageo.app.tools.NumericCalculus
import com.ganageo.app.tools.SequenceLab
import com.ganageo.app.tools.SolveStep
import com.ganageo.app.tools.StepSolution
import com.ganageo.app.tools.VectorLab
import kotlin.math.abs

// ---------------------------------------------------------------------------
// Solucionador de ecuaciones
// ---------------------------------------------------------------------------

@Composable
fun EquationSolverScreen(onBack: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var solution by remember { mutableStateOf<StepSolution?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    var equation by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue("2x + 5 = 13"))
    }

    var a1 by rememberSaveable { mutableStateOf("2") }
    var b1 by rememberSaveable { mutableStateOf("3") }
    var c1 by rememberSaveable { mutableStateOf("12") }
    var a2 by rememberSaveable { mutableStateOf("1") }
    var b2 by rememberSaveable { mutableStateOf("-1") }
    var c2 by rememberSaveable { mutableStateOf("1") }

    val cells = remember3x3()

    fun solveWith(block: () -> StepSolution) {
        runCatching(block)
            .onSuccess {
                solution = it
                error = null
            }
            .onFailure {
                solution = null
                error = it.message ?: "No se pudo resolver."
            }
    }

    ScienceShell(
        title = "Solucionador de ecuaciones",
        subtitle = "Lineales, cuadráticas y sistemas, con el desarrollo completo",
        onBack = onBack
    ) {
        StudioTabs(listOf("Ecuación", "Sistema 2×2", "Sistema 3×3"), tab) {
            tab = it
            solution = null
            error = null
        }

        when (tab) {
            0 -> {
                ScienceCard("Escribe la ecuación") {
                    MathInput(
                        value = equation,
                        onValueChange = { equation = it },
                        label = "Ecuación en x",
                        placeholder = "Por ejemplo: x^2 - 5x + 6 = 0"
                    )
                    StudioHint("Detecta sola si es lineal, cuadrática o de grado mayor. Acepta paréntesis y fracciones.")
                    StudioChipRow {
                        listOf(
                            "2x + 5 = 13",
                            "x^2 - 5x + 6 = 0",
                            "3(x-2) = 5x + 4",
                            "x^2 + 2x + 5 = 0",
                            "x^3 - 6x^2 + 11x - 6 = 0"
                        ).forEach { sample ->
                            StudioChip(
                                label = sample,
                                active = equation.text == sample,
                                onClick = { equation = TextFieldValue(sample, androidx.compose.ui.text.TextRange(sample.length)) }
                            )
                        }
                    }
                }
                ScienceActionButtonInline("Resolver") {
                    solveWith { AlgebraSteps.solveEquation(equation.text) }
                }
            }

            1 -> {
                ScienceCard("Sistema de dos ecuaciones") {
                    FormulaText("a₁x + b₁y = c₁\na₂x + b₂y = c₂", color = StudioTheme.TextSecondary, size = 14)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(a1, { a1 = it }, "a₁", Modifier.weight(1f))
                        ScienceNumberField(b1, { b1 = it }, "b₁", Modifier.weight(1f))
                        ScienceNumberField(c1, { c1 = it }, "c₁", Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(a2, { a2 = it }, "a₂", Modifier.weight(1f))
                        ScienceNumberField(b2, { b2 = it }, "b₂", Modifier.weight(1f))
                        ScienceNumberField(c2, { c2 = it }, "c₂", Modifier.weight(1f))
                    }
                }
                ScienceActionButtonInline("Resolver sistema") {
                    solveWith {
                        AlgebraSteps.system2x2(
                            number(a1, "a₁"), number(b1, "b₁"), number(c1, "c₁"),
                            number(a2, "a₂"), number(b2, "b₂"), number(c2, "c₂")
                        )
                    }
                }
            }

            else -> {
                ScienceCard("Sistema de tres ecuaciones") {
                    FormulaText(
                        "a₁x + b₁y + c₁z = d₁\na₂x + b₂y + c₂z = d₂\na₃x + b₃y + c₃z = d₃",
                        color = StudioTheme.TextSecondary,
                        size = 13
                    )
                    (0..2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (0..3).forEach { column ->
                                ScienceNumberField(
                                    value = cells[row][column].value,
                                    onValueChange = { cells[row][column].value = it },
                                    label = listOf("a", "b", "c", "d")[column] + "${row + 1}",
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
                ScienceActionButtonInline("Resolver sistema") {
                    solveWith {
                        val matrix = Array(3) { row ->
                            DoubleArray(3) { column -> number(cells[row][column].value, "coeficiente") }
                        }
                        val constants = DoubleArray(3) { row -> number(cells[row][3].value, "término") }
                        AlgebraSteps.system3x3(matrix, constants)
                    }
                }
            }
        }

        error?.let { ScienceError(it) }

        solution?.let { result ->
            ScienceResult(
                headline = result.headline,
                caption = result.note,
                onCopy = { clipboard.setText(AnnotatedString(result.results.joinToString("\n"))) }
            )
            StepsSection(result.steps, result.method)
        }
    }
}

private class Cell(initial: String) {
    var value by mutableStateOf(initial)
}

@Composable
private fun remember3x3(): List<List<Cell>> = androidx.compose.runtime.remember {
    listOf(
        listOf(Cell("1"), Cell("1"), Cell("1"), Cell("6")),
        listOf(Cell("2"), Cell("-1"), Cell("1"), Cell("3")),
        listOf(Cell("1"), Cell("2"), Cell("-1"), Cell("2"))
    )
}

private fun number(text: String, label: String): Double =
    text.replace(',', '.').trim().toDoubleOrNull()
        ?: throw IllegalArgumentException("Revisa el valor de $label.")

// ---------------------------------------------------------------------------
// Matemática avanzada
// ---------------------------------------------------------------------------

@Composable
fun AdvancedMathScreen(onBack: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }

    ScienceShell(
        title = "Matemática avanzada",
        subtitle = "Matrices, vectores, cálculo y sucesiones",
        onBack = onBack
    ) {
        StudioTabs(listOf("Matrices", "Vectores", "Cálculo", "Sucesiones"), tab) { tab = it }
        when (tab) {
            0 -> MatrixSection()
            1 -> VectorSection()
            2 -> CalculusSection()
            else -> SequenceSection()
        }
    }
}

@Composable
private fun MatrixSection() {
    var textA by rememberSaveable { mutableStateOf("1 2\n3 4") }
    var textB by rememberSaveable { mutableStateOf("5 6\n7 8") }
    var result by rememberSaveable { mutableStateOf<String?>(null) }
    var detail by rememberSaveable { mutableStateOf<String?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    fun compute(label: String, block: () -> Pair<String, String?>) {
        runCatching(block)
            .onSuccess {
                result = it.first
                detail = it.second ?: label
                error = null
            }
            .onFailure {
                result = null
                detail = null
                error = it.message ?: "No se pudo calcular."
            }
    }

    ScienceCard("Matriz A") {
        ScienceTextArea(textA, { textA = it }, "A", "Una fila por línea:\n1 2\n3 4")
    }
    ScienceCard("Matriz B") {
        ScienceTextArea(textB, { textB = it }, "B", "Solo hace falta para A+B, A−B y A×B")
    }
    ScienceCard("Operación") {
        StudioChipRow {
            StudioChip("A + B", false, onClick = {
                compute("Suma de matrices") {
                    LinearAlgebraPro.format(
                        LinearAlgebraPro.add(LinearAlgebraPro.parse(textA), LinearAlgebraPro.parse(textB))
                    ) to "A + B"
                }
            })
            StudioChip("A − B", false, onClick = {
                compute("Resta de matrices") {
                    LinearAlgebraPro.format(
                        LinearAlgebraPro.add(LinearAlgebraPro.parse(textA), LinearAlgebraPro.parse(textB), subtract = true)
                    ) to "A − B"
                }
            })
            StudioChip("A × B", false, onClick = {
                compute("Producto de matrices") {
                    LinearAlgebraPro.format(
                        LinearAlgebraPro.multiply(LinearAlgebraPro.parse(textA), LinearAlgebraPro.parse(textB))
                    ) to "A × B  (el producto no es conmutativo)"
                }
            })
            StudioChip("Aᵀ", false, onClick = {
                compute("Transpuesta") {
                    LinearAlgebraPro.format(LinearAlgebraPro.transpose(LinearAlgebraPro.parse(textA))) to
                        "Transpuesta de A: se intercambian filas por columnas"
                }
            })
        }
        StudioChipRow {
            StudioChip("det A", false, onClick = {
                compute("Determinante") {
                    val matrix = LinearAlgebraPro.parse(textA)
                    val det = LinearAlgebraPro.determinant(matrix)
                    MathEngine.formatNumber(det) to
                        if (abs(det) < 1e-12) "det A = 0: la matriz es singular y no tiene inversa"
                        else "Determinante de A"
                }
            })
            StudioChip("A⁻¹", false, onClick = {
                compute("Inversa") {
                    val matrix = LinearAlgebraPro.parse(textA)
                    val inverse = LinearAlgebraPro.inverse(matrix)
                        ?: throw IllegalArgumentException("La matriz no tiene inversa: su determinante es cero.")
                    LinearAlgebraPro.format(inverse) to "Inversa de A (comprobación: A·A⁻¹ = I)"
                }
            })
            StudioChip("Rango", false, onClick = {
                compute("Rango") {
                    val matrix = LinearAlgebraPro.parse(textA)
                    LinearAlgebraPro.rank(matrix).toString() to
                        "Cantidad de filas linealmente independientes"
                }
            })
            StudioChip("Traza", false, onClick = {
                compute("Traza") {
                    MathEngine.formatNumber(LinearAlgebraPro.trace(LinearAlgebraPro.parse(textA))) to
                        "Suma de la diagonal principal"
                }
            })
            StudioChip("Valores propios", false, onClick = {
                compute("Valores propios") {
                    val values = LinearAlgebraPro.eigenvalues(LinearAlgebraPro.parse(textA))
                    if (values.isEmpty()) {
                        "Sin valores propios reales" to "Las soluciones del polinomio característico son complejas"
                    } else {
                        values.joinToString("\n") { "λ = ${MathEngine.formatNumber(it, 4)}" } to
                            "Valores propios reales (matrices 2×2 y 3×3)"
                    }
                }
            })
        }
        StudioHint("Escribe los números separados por espacios o comas y usa una línea por fila.")
    }

    error?.let { ScienceError(it) }
    result?.let {
        ScienceCard("Resultado", accent = true) {
            FormulaText(it, size = 17)
            detail?.let { text ->
                Text(text, color = StudioTheme.TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun VectorSection() {
    var textA by rememberSaveable { mutableStateOf("3 -1 2") }
    var textB by rememberSaveable { mutableStateOf("1 4 -2") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var rows by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }

    ScienceCard("Vectores") {
        ScienceNumberFieldWide(textA, { textA = it }, "Vector a")
        ScienceNumberFieldWide(textB, { textB = it }, "Vector b")
        StudioHint("Dos o tres componentes separadas por espacios. El producto vectorial necesita tres.")
    }
    ScienceActionButtonInline("Analizar vectores") {
        runCatching {
            val a = VectorLab.parse(textA)
            val b = VectorLab.parse(textB)
            val list = mutableListOf<Pair<String, String>>()
            list += "a + b" to VectorLab.format(DoubleArray(a.size) { a[it] + b.getOrElse(it) { 0.0 } })
            list += "a − b" to VectorLab.format(DoubleArray(a.size) { a[it] - b.getOrElse(it) { 0.0 } })
            list += "|a|" to MathEngine.formatNumber(VectorLab.norm(a), 4)
            list += "|b|" to MathEngine.formatNumber(VectorLab.norm(b), 4)
            list += "a · b (producto punto)" to MathEngine.formatNumber(VectorLab.dot(a, b), 4)
            list += "a × b (producto vectorial)" to VectorLab.format(VectorLab.cross(a, b))
            val angle = VectorLab.angleDegrees(a, b)
            list += "Ángulo entre a y b" to
                if (angle.isNaN()) "—" else "${MathEngine.formatNumber(angle, 2)}°"
            list += "Proyección de a sobre b" to VectorLab.format(VectorLab.projection(a, b))
            list += "Vector unitario de a" to VectorLab.format(VectorLab.unit(a))
            list += "¿Perpendiculares?" to if (abs(VectorLab.dot(a, b)) < 1e-9) "Sí, el producto punto es 0" else "No"
            list
        }.onSuccess {
            rows = it
            error = null
        }.onFailure {
            rows = emptyList()
            error = it.message ?: "No se pudo calcular."
        }
    }

    error?.let { ScienceError(it) }
    if (rows.isNotEmpty()) {
        ScienceCard("Resultados", accent = true) {
            rows.forEach { (label, value) -> ScienceRow(label, value) }
        }
    }
}

@Composable
private fun CalculusSection() {
    var expression by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue("x^3 - 3x + 1"))
    }
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var pointText by rememberSaveable { mutableStateOf("1") }
    var fromText by rememberSaveable { mutableStateOf("0") }
    var toText by rememberSaveable { mutableStateOf("2") }
    var headline by rememberSaveable { mutableStateOf<String?>(null) }
    var steps by remember { mutableStateOf<List<SolveStep>>(emptyList()) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    ScienceCard("Función") {
        MathInput(
            value = expression,
            onValueChange = { expression = it },
            label = "f(x)",
            placeholder = "x^3 - 3x + 1"
        )
        StudioChipRow {
            listOf("Derivada", "Derivada en un punto", "Integral definida", "Límite", "Raíces").forEachIndexed { index, label ->
                StudioChip(label, mode == index, onClick = { mode = index })
            }
        }
        when (mode) {
            1, 3 -> ScienceNumberField(pointText, { pointText = it }, "x =", Modifier.fillMaxWidth())
            2 -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScienceNumberField(fromText, { fromText = it }, "Desde a", Modifier.weight(1f))
                ScienceNumberField(toText, { toText = it }, "Hasta b", Modifier.weight(1f))
            }
            4 -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScienceNumberField(fromText, { fromText = it }, "Buscar desde", Modifier.weight(1f))
                ScienceNumberField(toText, { toText = it }, "Hasta", Modifier.weight(1f))
            }
            else -> Unit
        }
    }

    ScienceActionButtonInline("Calcular") {
        runCatching {
            val node = MathEngine.parse(expression.text)
            val f = MathEngine.compileNode(node)
            when (mode) {
                0 -> {
                    val derivative = MathEngine.derivative(node)
                    val second = MathEngine.derivative(derivative)
                    headline = "f′(x) = ${MathEngine.format(derivative)}"
                    steps = listOf(
                        SolveStep(
                            "Función original",
                            "f(x) = ${MathEngine.format(node)}",
                            "Se deriva término a término aplicando las reglas del producto, del cociente y de la cadena."
                        ),
                        SolveStep(
                            "Primera derivada",
                            "f′(x) = ${MathEngine.format(derivative)}",
                            "Indica la pendiente de la recta tangente en cada punto."
                        ),
                        SolveStep(
                            "Segunda derivada",
                            "f″(x) = ${MathEngine.format(second)}",
                            "Sirve para saber la concavidad y clasificar máximos y mínimos."
                        )
                    )
                }
                1 -> {
                    val x = number(pointText, "x")
                    val derivative = MathEngine.derivative(node)
                    val exact = MathEngine.eval(derivative, mapOf("x" to x))
                    val numeric = NumericCalculus.derivativeAt(f, x)
                    val value = if (exact.isFinite()) exact else numeric
                    headline = "f′(${MathEngine.formatNumber(x)}) = ${MathEngine.formatNumber(value, 6)}"
                    steps = listOf(
                        SolveStep(
                            "Derivada simbólica",
                            "f′(x) = ${MathEngine.format(derivative)}",
                            "Primero se deriva y después se sustituye el valor."
                        ),
                        SolveStep(
                            "Sustitución",
                            "f′(${MathEngine.formatNumber(x)}) = ${MathEngine.formatNumber(value, 6)}",
                            "Es la pendiente de la recta tangente en ese punto."
                        ),
                        SolveStep(
                            "Recta tangente",
                            run {
                                val y = f(x)
                                val b = y - value * x
                                "y = ${MathEngine.formatNumber(value, 4)}x ${if (b < 0) "−" else "+"} ${MathEngine.formatNumber(abs(b), 4)}"
                            },
                            "Recta que toca la curva en ese punto con la misma pendiente."
                        )
                    )
                }
                2 -> {
                    val a = number(fromText, "a")
                    val b = number(toText, "b")
                    val area = NumericCalculus.integrate(f, a, b)
                    if (!area.isFinite()) throw IllegalArgumentException("La función no está definida en todo el intervalo.")
                    headline = "∫ = ${MathEngine.formatNumber(area, 6)}"
                    steps = listOf(
                        SolveStep(
                            "Integral planteada",
                            "∫ desde ${MathEngine.formatNumber(a)} hasta ${MathEngine.formatNumber(b)} de ${MathEngine.format(node)} dx",
                            "Se calcula el área con signo entre la curva y el eje X."
                        ),
                        SolveStep(
                            "Método de Simpson",
                            "Resultado ≈ ${MathEngine.formatNumber(area, 6)}",
                            "Se aproxima la curva por parábolas en 2000 subintervalos; el error es muy pequeño."
                        ),
                        SolveStep(
                            "Interpretación",
                            if (area < 0) "El área queda mayormente por debajo del eje X" else "El área queda mayormente por encima del eje X",
                            "La integral definida cuenta como negativa la parte bajo el eje."
                        )
                    )
                }
                3 -> {
                    val x = number(pointText, "x")
                    val (left, right, value) = NumericCalculus.limitAt(f, x)
                    headline = if (value.isNaN()) "El límite no existe" else "lím = ${MathEngine.formatNumber(value, 6)}"
                    steps = listOf(
                        SolveStep(
                            "Por la izquierda",
                            "x → ${MathEngine.formatNumber(x)}⁻ : ${MathEngine.formatNumber(left, 6)}",
                            "Se acerca al punto con valores menores."
                        ),
                        SolveStep(
                            "Por la derecha",
                            "x → ${MathEngine.formatNumber(x)}⁺ : ${MathEngine.formatNumber(right, 6)}",
                            "Se acerca al punto con valores mayores."
                        ),
                        SolveStep(
                            "Conclusión",
                            if (value.isNaN()) "Los dos lados no coinciden: el límite no existe"
                            else "El límite existe y vale ${MathEngine.formatNumber(value, 6)}",
                            "Para que el límite exista, los dos laterales deben dar lo mismo."
                        )
                    )
                }
                else -> {
                    val a = number(fromText, "desde")
                    val b = number(toText, "hasta")
                    val roots = NumericCalculus.rootsIn(f, a, b, 3000)
                    headline = if (roots.isEmpty()) "Sin raíces en el intervalo"
                    else roots.joinToString("  ·  ") { "x = ${MathEngine.formatNumber(it, 6)}" }
                    steps = listOf(
                        SolveStep(
                            "Búsqueda de cambios de signo",
                            "Intervalo [${MathEngine.formatNumber(a)}, ${MathEngine.formatNumber(b)}]",
                            "Donde la función pasa de positiva a negativa hay una raíz."
                        ),
                        SolveStep(
                            "Refinamiento",
                            if (roots.isEmpty()) "No se encontró ningún cruce" else roots.joinToString("\n") { "x ≈ ${MathEngine.formatNumber(it, 8)}" },
                            "Cada cruce se afina por bisección hasta la precisión mostrada."
                        )
                    )
                }
            }
            error = null
        }.onFailure {
            headline = null
            steps = emptyList()
            error = it.message ?: "No se pudo calcular."
        }
    }

    error?.let { ScienceError(it) }
    headline?.let {
        ScienceResult(it)
        StepsSection(steps)
    }
}

@Composable
private fun SequenceSection() {
    var type by rememberSaveable { mutableIntStateOf(0) }
    var firstText by rememberSaveable { mutableStateOf("2") }
    var stepText by rememberSaveable { mutableStateOf("3") }
    var countText by rememberSaveable { mutableStateOf("10") }
    var info by remember { mutableStateOf<com.ganageo.app.tools.SequenceInfo?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    ScienceCard("Tipo de sucesión") {
        StudioChipRow {
            listOf("Aritmética", "Geométrica", "Fibonacci").forEachIndexed { index, label ->
                StudioChip(label, type == index, onClick = { type = index })
            }
        }
        if (type != 2) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScienceNumberField(firstText, { firstText = it }, "Primer término a₁", Modifier.weight(1f))
                ScienceNumberField(
                    stepText,
                    { stepText = it },
                    if (type == 0) "Diferencia d" else "Razón r",
                    Modifier.weight(1f)
                )
            }
        }
        ScienceNumberField(countText, { countText = it }, "Cantidad de términos", Modifier.fillMaxWidth())
    }

    ScienceActionButtonInline("Generar") {
        runCatching {
            val count = countText.trim().toIntOrNull() ?: throw IllegalArgumentException("Cantidad inválida.")
            when (type) {
                0 -> SequenceLab.arithmetic(number(firstText, "a₁"), number(stepText, "d"), count)
                1 -> SequenceLab.geometric(number(firstText, "a₁"), number(stepText, "r"), count)
                else -> SequenceLab.fibonacci(count)
            }
        }.onSuccess {
            info = it
            error = null
        }.onFailure {
            info = null
            error = it.message ?: "No se pudo generar."
        }
    }

    error?.let { ScienceError(it) }
    info?.let { data ->
        ScienceResult(data.generalTerm, data.note)
        ScienceCard("Términos") {
            FormulaText(data.terms.joinToString(",  ") { MathEngine.formatNumber(it, 4) })
            ScienceRow("Suma de los términos", MathEngine.formatNumber(data.sum, 4), highlight = true)
        }
    }
}

@Composable
private fun ScienceActionButtonInline(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = StudioTheme.Accent,
            contentColor = StudioTheme.OnAccent
        )
    ) {
        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
        Text("  $text", fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ScienceNumberFieldWide(value: String, onValueChange: (String) -> Unit, label: String) {
    ScienceNumberField(value, onValueChange, label, Modifier.fillMaxWidth())
}
