package com.ganageo.app.tools

import java.math.BigDecimal
import java.math.RoundingMode

// ---------------------------------------------------------------------------
// Impuesto sobre las ventas (IGV / IVA / ITBIS)
// ---------------------------------------------------------------------------

/** Si el precio que escribe el usuario ya trae el impuesto adentro o no. */
enum class TaxMode(val label: String, val hint: String) {
    EXCLUDED(
        "Precio sin impuesto",
        "Escribes el valor de venta y la app le suma el impuesto encima."
    ),
    INCLUDED(
        "Precio con impuesto",
        "Escribes el precio final al público y la app le saca el impuesto por dentro."
    )
}

data class TaxSplit(
    val base: BigDecimal,
    val tax: BigDecimal,
    val total: BigDecimal
)

object TaxEngine {

    /**
     * Desagrega el impuesto.
     *
     * El error más común es restarle el 18 % al precio final: eso da mal. Cuando
     * el precio ya incluye impuesto hay que DIVIDIR entre 1.18 y restar, no
     * multiplicar por 0.18.
     */
    fun split(amount: BigDecimal, taxPercent: BigDecimal, mode: TaxMode): TaxSplit {
        require(amount.signum() >= 0) { "El monto no puede ser negativo." }
        require(taxPercent.signum() >= 0) { "El impuesto no puede ser negativo." }
        val factor = BigDecimal.ONE.add(taxPercent.divide(BigDecimal(100), Money.WORK_SCALE, RoundingMode.HALF_UP))
        return when (mode) {
            TaxMode.EXCLUDED -> {
                val tax = Money.percent(amount, taxPercent)
                TaxSplit(Money.round(amount), Money.round(tax), Money.round(amount.add(tax)))
            }
            TaxMode.INCLUDED -> {
                val base = amount.divide(factor, Money.WORK_SCALE, RoundingMode.HALF_UP)
                val roundedBase = Money.round(base)
                val roundedTotal = Money.round(amount)
                TaxSplit(roundedBase, roundedTotal.subtract(roundedBase), roundedTotal)
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Cotización
// ---------------------------------------------------------------------------

data class QuoteItem(
    val description: String,
    val quantity: BigDecimal,
    val unitPrice: BigDecimal,
    val discountPercent: BigDecimal = BigDecimal.ZERO,
    val unit: String = "und"
)

data class QuoteLineResult(
    val item: QuoteItem,
    val grossAmount: BigDecimal,
    val discountAmount: BigDecimal,
    val netAmount: BigDecimal
)

data class QuoteTotals(
    val lines: List<QuoteLineResult>,
    val gross: BigDecimal,
    val lineDiscounts: BigDecimal,
    val globalDiscount: BigDecimal,
    val base: BigDecimal,
    val tax: BigDecimal,
    val total: BigDecimal,
    val taxPercent: BigDecimal,
    val taxName: String,
    val amountInWords: String
)

object QuoteEngine {

    /**
     * Calcula la cotización completa.
     *
     * El impuesto se calcula UNA sola vez sobre la base total, no línea por
     * línea: así no aparece el descuadre de un céntimo entre la suma de los
     * ítems y el total del documento.
     */
    fun compute(
        items: List<QuoteItem>,
        taxPercent: BigDecimal,
        mode: TaxMode,
        globalDiscountPercent: BigDecimal = BigDecimal.ZERO,
        taxName: String = "IGV",
        currency: CurrencyInfo = CurrencyInfo.PEN
    ): QuoteTotals {
        val lines = items.map { item ->
            val gross = item.quantity.multiply(item.unitPrice)
            val discount = Money.percent(gross, item.discountPercent)
            QuoteLineResult(
                item = item,
                grossAmount = Money.round(gross),
                discountAmount = Money.round(discount),
                netAmount = Money.round(gross.subtract(discount))
            )
        }

        val grossTotal = lines.fold(BigDecimal.ZERO) { acc, line -> acc.add(line.grossAmount) }
        val lineDiscounts = lines.fold(BigDecimal.ZERO) { acc, line -> acc.add(line.discountAmount) }
        val afterLineDiscounts = grossTotal.subtract(lineDiscounts)
        val globalDiscount = Money.round(Money.percent(afterLineDiscounts, globalDiscountPercent))
        val netTotal = afterLineDiscounts.subtract(globalDiscount)

        val split = TaxEngine.split(netTotal.max(BigDecimal.ZERO), taxPercent, mode)

        return QuoteTotals(
            lines = lines,
            gross = Money.round(grossTotal),
            lineDiscounts = Money.round(lineDiscounts),
            globalDiscount = globalDiscount,
            base = split.base,
            tax = split.tax,
            total = split.total,
            taxPercent = taxPercent,
            taxName = taxName,
            amountInWords = Money.toWords(split.total, currency)
        )
    }

    /** Número correlativo con serie, al estilo de los documentos peruanos. */
    fun documentNumber(series: String, number: Int): String {
        val cleanSeries = series.trim().uppercase().ifBlank { "COT" }.take(4)
        return "$cleanSeries-${number.coerceAtLeast(1).toString().padStart(6, '0')}"
    }
}

// ---------------------------------------------------------------------------
// Precios, márgenes y comisiones
// ---------------------------------------------------------------------------

/**
 * Margen y markup NO son lo mismo y confundirlos cuesta dinero.
 * El margen se calcula sobre el PRECIO DE VENTA y el markup sobre el COSTO.
 * Un markup del 50 % equivale a un margen del 33.3 %.
 */
enum class PriceBasis(val label: String, val explanation: String) {
    MARGIN(
        "Margen",
        "Porcentaje sobre el precio de venta. Es el que usa la contabilidad: de cada S/ 100 vendidos, cuánto queda."
    ),
    MARKUP(
        "Markup",
        "Porcentaje que se le suma al costo. Es el que se usa al comprar y revender."
    )
}

data class PricingResult(
    val cost: BigDecimal,
    val salePrice: BigDecimal,
    val grossProfit: BigDecimal,
    val commission: BigDecimal,
    val netProfit: BigDecimal,
    val marginPercent: BigDecimal,
    val markupPercent: BigDecimal,
    val priceWithTax: BigDecimal,
    val taxAmount: BigDecimal
)

object PricingEngine {

    /** Precio de venta necesario para lograr el margen o el markup pedido. */
    fun priceFor(
        cost: BigDecimal,
        percent: BigDecimal,
        basis: PriceBasis,
        commissionPercent: BigDecimal = BigDecimal.ZERO
    ): BigDecimal {
        require(cost.signum() >= 0) { "El costo no puede ser negativo." }
        val p = percent.divide(BigDecimal(100), Money.WORK_SCALE, RoundingMode.HALF_UP)
        val c = commissionPercent.divide(BigDecimal(100), Money.WORK_SCALE, RoundingMode.HALF_UP)
        return when (basis) {
            PriceBasis.MARKUP -> {
                val price = cost.multiply(BigDecimal.ONE.add(p))
                // La comisión se descuenta del precio, así que hay que subirlo para compensarla.
                val denominator = BigDecimal.ONE.subtract(c)
                require(denominator.signum() > 0) { "La comisión no puede llegar al 100 %." }
                Money.round(price.divide(denominator, Money.WORK_SCALE, RoundingMode.HALF_UP))
            }
            PriceBasis.MARGIN -> {
                val denominator = BigDecimal.ONE.subtract(p).subtract(c)
                require(denominator.signum() > 0) {
                    "El margen y la comisión juntos deben sumar menos de 100 %."
                }
                Money.round(cost.divide(denominator, Money.WORK_SCALE, RoundingMode.HALF_UP))
            }
        }
    }

    /** Analiza una venta ya definida: cuánto se gana de verdad. */
    fun analyze(
        cost: BigDecimal,
        salePrice: BigDecimal,
        commissionPercent: BigDecimal = BigDecimal.ZERO,
        taxPercent: BigDecimal = BigDecimal.ZERO
    ): PricingResult {
        require(salePrice.signum() > 0) { "El precio de venta debe ser mayor que cero." }
        val commission = Money.percent(salePrice, commissionPercent)
        val gross = salePrice.subtract(cost)
        val net = gross.subtract(commission)
        val margin = net.divide(salePrice, Money.WORK_SCALE, RoundingMode.HALF_UP).multiply(BigDecimal(100))
        val markup = if (cost.signum() > 0) {
            gross.divide(cost, Money.WORK_SCALE, RoundingMode.HALF_UP).multiply(BigDecimal(100))
        } else BigDecimal.ZERO
        val tax = Money.percent(salePrice, taxPercent)
        return PricingResult(
            cost = Money.round(cost),
            salePrice = Money.round(salePrice),
            grossProfit = Money.round(gross),
            commission = Money.round(commission),
            netProfit = Money.round(net),
            marginPercent = margin.setScale(2, RoundingMode.HALF_UP),
            markupPercent = markup.setScale(2, RoundingMode.HALF_UP),
            priceWithTax = Money.round(salePrice.add(tax)),
            taxAmount = Money.round(tax)
        )
    }

    fun marginToMarkup(marginPercent: BigDecimal): BigDecimal {
        val m = marginPercent.divide(BigDecimal(100), Money.WORK_SCALE, RoundingMode.HALF_UP)
        val denominator = BigDecimal.ONE.subtract(m)
        require(denominator.signum() > 0) { "El margen debe ser menor que 100 %." }
        return m.divide(denominator, Money.WORK_SCALE, RoundingMode.HALF_UP)
            .multiply(BigDecimal(100)).setScale(2, RoundingMode.HALF_UP)
    }

    fun markupToMargin(markupPercent: BigDecimal): BigDecimal {
        val m = markupPercent.divide(BigDecimal(100), Money.WORK_SCALE, RoundingMode.HALF_UP)
        val denominator = BigDecimal.ONE.add(m)
        return m.divide(denominator, Money.WORK_SCALE, RoundingMode.HALF_UP)
            .multiply(BigDecimal(100)).setScale(2, RoundingMode.HALF_UP)
    }

    /** Unidades que hay que vender para empezar a ganar. */
    fun breakEvenUnits(
        fixedCosts: BigDecimal,
        pricePerUnit: BigDecimal,
        variableCostPerUnit: BigDecimal
    ): BigDecimal {
        val contribution = pricePerUnit.subtract(variableCostPerUnit)
        require(contribution.signum() > 0) {
            "El precio debe ser mayor que el costo variable, si no nunca se llega al equilibrio."
        }
        return fixedCosts.divide(contribution, 2, RoundingMode.CEILING)
    }

    data class CommissionTier(val fromAmount: BigDecimal, val percent: BigDecimal)

    /** Comisión escalonada: cada tramo paga su propio porcentaje. */
    fun tieredCommission(sales: BigDecimal, tiers: List<CommissionTier>): BigDecimal {
        if (tiers.isEmpty()) return BigDecimal.ZERO
        val ordered = tiers.sortedBy { it.fromAmount }
        var total = BigDecimal.ZERO
        for (index in ordered.indices) {
            val from = ordered[index].fromAmount
            if (sales <= from) break
            val to = ordered.getOrNull(index + 1)?.fromAmount ?: sales
            val portion = sales.min(to).subtract(from)
            if (portion.signum() > 0) {
                total = total.add(Money.percent(portion, ordered[index].percent))
            }
        }
        return Money.round(total)
    }
}

// ---------------------------------------------------------------------------
// Horas de trabajo
// ---------------------------------------------------------------------------

data class ShiftBreakdown(
    val totalMinutes: Int,
    val workedMinutes: Int,
    val nightMinutes: Int,
    val regularMinutes: Int,
    val overtimeMinutes: Int,
    val crossesMidnight: Boolean
)

data class PayBreakdown(
    val hourlyRate: BigDecimal,
    val regularHours: BigDecimal,
    val regularPay: BigDecimal,
    val overtimeFirstHours: BigDecimal,
    val overtimeFirstPay: BigDecimal,
    val overtimeRestHours: BigDecimal,
    val overtimeRestPay: BigDecimal,
    val nightHours: BigDecimal,
    val nightExtraPay: BigDecimal,
    val holidayExtraPay: BigDecimal,
    val total: BigDecimal
)

object TimeEngine {

    const val NIGHT_START = 22 * 60
    const val NIGHT_END = 6 * 60

    fun minutesOf(hour: Int, minute: Int): Int = (hour.coerceIn(0, 23) * 60) + minute.coerceIn(0, 59)

    fun formatMinutes(minutes: Int): String {
        val safe = minutes.coerceAtLeast(0)
        return "${safe / 60} h ${(safe % 60).toString().padStart(2, '0')} min"
    }

    fun formatClock(minutes: Int): String {
        val normalized = ((minutes % 1440) + 1440) % 1440
        return "${(normalized / 60).toString().padStart(2, '0')}:${(normalized % 60).toString().padStart(2, '0')}"
    }

    /**
     * Analiza una jornada. Si la hora de salida es menor que la de entrada se
     * entiende que el turno cruza la medianoche, que es lo normal en vigilancia,
     * salud o producción.
     */
    fun analyzeShift(
        startMinutes: Int,
        endMinutes: Int,
        breakMinutes: Int,
        journeyHours: Double = FiscalData.Peru.JORNADA_HORAS_DIA,
        roundToMinutes: Int = 1
    ): ShiftBreakdown {
        val crosses = endMinutes <= startMinutes
        val rawTotal = if (crosses) endMinutes + 1440 - startMinutes else endMinutes - startMinutes
        val worked = (rawTotal - breakMinutes.coerceAtLeast(0)).coerceAtLeast(0)
        val rounded = roundMinutes(worked, roundToMinutes)
        val journeyMinutes = (journeyHours * 60).toInt()
        val regular = minOf(rounded, journeyMinutes)
        val overtime = (rounded - journeyMinutes).coerceAtLeast(0)
        return ShiftBreakdown(
            totalMinutes = rawTotal,
            workedMinutes = rounded,
            nightMinutes = nightMinutesOf(startMinutes, rawTotal),
            regularMinutes = regular,
            overtimeMinutes = overtime,
            crossesMidnight = crosses
        )
    }

    /** Redondeo de marcaciones, por ejemplo al bloque de 5, 10 o 15 minutos más cercano. */
    fun roundMinutes(minutes: Int, block: Int): Int {
        if (block <= 1) return minutes
        val remainder = minutes % block
        return if (remainder * 2 >= block) minutes + (block - remainder) else minutes - remainder
    }

    /** Minutos trabajados dentro del horario nocturno (22:00 a 06:00). */
    fun nightMinutesOf(startMinutes: Int, durationMinutes: Int): Int {
        var night = 0
        for (offset in 0 until durationMinutes) {
            val point = (startMinutes + offset) % 1440
            if (point >= NIGHT_START || point < NIGHT_END) night++
        }
        return night
    }

    fun hourlyFromMonthly(monthlySalary: BigDecimal, hoursPerDay: Double = FiscalData.Peru.JORNADA_HORAS_DIA): BigDecimal {
        require(monthlySalary.signum() >= 0) { "El sueldo no puede ser negativo." }
        require(hoursPerDay > 0) { "Las horas de jornada deben ser mayores que cero." }
        val daily = monthlySalary.divide(BigDecimal(30), Money.WORK_SCALE, RoundingMode.HALF_UP)
        return daily.divide(BigDecimal(hoursPerDay.toString()), Money.WORK_SCALE, RoundingMode.HALF_UP)
    }

    /**
     * Calcula el pago de una jornada con las reglas peruanas: 25 % de recargo las
     * dos primeras horas extra del día, 35 % desde la tercera, 35 % adicional por
     * las horas nocturnas y 100 % de sobretasa si es feriado o descanso trabajado.
     */
    fun computePay(
        hourlyRate: BigDecimal,
        regularMinutes: Int,
        overtimeMinutes: Int,
        nightMinutes: Int = 0,
        holiday: Boolean = false,
        days: Int = 1
    ): PayBreakdown {
        require(hourlyRate.signum() >= 0) { "El valor hora no puede ser negativo." }
        require(days > 0) { "Los días deben ser al menos 1." }

        fun hours(minutes: Int): BigDecimal =
            BigDecimal(minutes).divide(BigDecimal(60), Money.WORK_SCALE, RoundingMode.HALF_UP)
                .multiply(BigDecimal(days))

        val firstBlock = minOf(overtimeMinutes, (FiscalData.Peru.HORAS_PRIMER_TRAMO * 60).toInt())
        val restBlock = (overtimeMinutes - firstBlock).coerceAtLeast(0)

        val regularHours = hours(regularMinutes)
        val firstHours = hours(firstBlock)
        val restHours = hours(restBlock)
        val nightHours = hours(nightMinutes)

        val regularPay = hourlyRate.multiply(regularHours)
        val firstFactor = BigDecimal.ONE.add(
            FiscalData.Peru.HORA_EXTRA_PRIMERAS.divide(BigDecimal(100), Money.WORK_SCALE, RoundingMode.HALF_UP)
        )
        val restFactor = BigDecimal.ONE.add(
            FiscalData.Peru.HORA_EXTRA_SIGUIENTES.divide(BigDecimal(100), Money.WORK_SCALE, RoundingMode.HALF_UP)
        )
        val firstPay = hourlyRate.multiply(firstFactor).multiply(firstHours)
        val restPay = hourlyRate.multiply(restFactor).multiply(restHours)

        val nightExtra = Money.percent(hourlyRate.multiply(nightHours), FiscalData.Peru.RECARGO_NOCTURNO)

        val baseSum = regularPay.add(firstPay).add(restPay).add(nightExtra)
        val holidayExtra = if (holiday) {
            Money.percent(baseSum, FiscalData.Peru.SOBRETASA_FERIADO)
        } else BigDecimal.ZERO

        return PayBreakdown(
            hourlyRate = Money.round(hourlyRate),
            regularHours = regularHours.setScale(2, RoundingMode.HALF_UP),
            regularPay = Money.round(regularPay),
            overtimeFirstHours = firstHours.setScale(2, RoundingMode.HALF_UP),
            overtimeFirstPay = Money.round(firstPay),
            overtimeRestHours = restHours.setScale(2, RoundingMode.HALF_UP),
            overtimeRestPay = Money.round(restPay),
            nightHours = nightHours.setScale(2, RoundingMode.HALF_UP),
            nightExtraPay = Money.round(nightExtra),
            holidayExtraPay = Money.round(holidayExtra),
            total = Money.round(baseSum.add(holidayExtra))
        )
    }
}

// ---------------------------------------------------------------------------
// Honorarios, sueldo neto y beneficios
// ---------------------------------------------------------------------------

data class HonorariosResult(
    val gross: BigDecimal,
    val retention: BigDecimal,
    val net: BigDecimal,
    val retentionApplied: Boolean,
    val explanation: String
)

data class NetSalaryResult(
    val gross: BigDecimal,
    val familyAllowance: BigDecimal,
    val pensionName: String,
    val pensionAmount: BigDecimal,
    val incomeTax: BigDecimal,
    val totalDeductions: BigDecimal,
    val net: BigDecimal,
    val employerEsSalud: BigDecimal,
    val details: List<Pair<String, BigDecimal>>
)

object PayrollEngine {

    /**
     * Recibo por honorarios (renta de cuarta categoría).
     *
     * Solo se retiene el 8 % si el recibo pasa de S/ 1500 y quien paga es agente
     * de retención. Con constancia de suspensión vigente no se retiene nada.
     */
    fun honorarios(
        gross: BigDecimal,
        payerIsAgent: Boolean = true,
        hasSuspension: Boolean = false
    ): HonorariosResult {
        require(gross.signum() >= 0) { "El monto no puede ser negativo." }
        val overThreshold = gross > FiscalData.Peru.TOPE_SIN_RETENCION
        val applies = payerIsAgent && overThreshold && !hasSuspension
        val retention = if (applies) Money.percent(gross, FiscalData.Peru.RETENCION_CUARTA) else BigDecimal.ZERO
        val explanation = when {
            hasSuspension -> "No se retiene: tienes constancia de suspensión vigente."
            !payerIsAgent -> "No se retiene: quien te paga no es agente de retención."
            !overThreshold -> "No se retiene: el recibo no supera ${Money.format(FiscalData.Peru.TOPE_SIN_RETENCION)}."
            else -> "Se retiene el 8 % porque el recibo supera ${Money.format(FiscalData.Peru.TOPE_SIN_RETENCION)}."
        }
        return HonorariosResult(
            gross = Money.round(gross),
            retention = Money.round(retention),
            net = Money.round(gross.subtract(retention)),
            retentionApplied = applies,
            explanation = explanation
        )
    }

    /** Si te conviene pedir la suspensión de retenciones para el año. */
    fun suspensionAdvice(projectedAnnualIncome: BigDecimal, isDirector: Boolean = false): String {
        val limit = if (isDirector) FiscalData.Peru.SUSPENSION_ANUAL_DIRECTORES
        else FiscalData.Peru.SUSPENSION_ANUAL
        return if (projectedAnnualIncome <= limit) {
            "Proyectas ${Money.format(projectedAnnualIncome)} al año, por debajo del tope de ${Money.format(limit)}. " +
                "Puedes solicitar la suspensión de retenciones en SUNAT (Formulario 1609, gratuito)."
        } else {
            "Proyectas ${Money.format(projectedAnnualIncome)} al año, por encima del tope de ${Money.format(limit)}. " +
                "No corresponde la suspensión: te seguirán reteniendo el 8 %."
        }
    }

    /**
     * Impuesto anual de rentas de trabajo por la escala progresiva.
     * Cada tramo paga su propia tasa: no es que todo el sueldo pague la tasa mayor.
     */
    fun annualIncomeTax(netAnnualIncome: BigDecimal): BigDecimal {
        if (netAnnualIncome.signum() <= 0) return BigDecimal.ZERO
        val uit = FiscalData.Peru.UIT
        var remaining = netAnnualIncome
        var previousLimit = BigDecimal.ZERO
        var tax = BigDecimal.ZERO
        for (tramo in FiscalData.Peru.TRAMOS_RENTA) {
            val limit = tramo.hastaUit?.multiply(uit)
            val portion = if (limit == null) remaining else limit.subtract(previousLimit).min(remaining)
            if (portion.signum() > 0) {
                tax = tax.add(Money.percent(portion, tramo.tasa))
                remaining = remaining.subtract(portion)
            }
            if (limit != null) previousLimit = limit
            if (remaining.signum() <= 0) break
        }
        return Money.round(tax)
    }

    /**
     * Sueldo neto en planilla.
     *
     * Descuentos reales del trabajador: pensión (ONP 13 % o AFP) y quinta
     * categoría. EsSalud NO se descuenta: lo paga el empleador aparte, y por eso
     * aparece por separado en el resultado.
     */
    fun netSalary(
        monthlyGross: BigDecimal,
        useOnp: Boolean,
        afpCommissionPercent: BigDecimal = BigDecimal("1.55"),
        familyAllowance: Boolean = false
    ): NetSalaryResult {
        require(monthlyGross.signum() >= 0) { "El sueldo no puede ser negativo." }
        val allowance = if (familyAllowance) Money.round(FiscalData.Peru.ASIGNACION_FAMILIAR) else BigDecimal.ZERO
        val gross = monthlyGross.add(allowance)

        val details = mutableListOf<Pair<String, BigDecimal>>()
        val pensionName: String
        val pension: BigDecimal
        if (useOnp) {
            pensionName = "ONP (13 %)"
            pension = Money.percent(gross, FiscalData.Peru.ONP)
            details += "ONP 13 %" to Money.round(pension)
        } else {
            pensionName = "AFP"
            val aporte = Money.percent(gross, FiscalData.Peru.AFP_APORTE)
            val prima = Money.percent(gross, FiscalData.Peru.AFP_PRIMA_SEGURO)
            val comision = Money.percent(gross, afpCommissionPercent)
            pension = aporte.add(prima).add(comision)
            details += "AFP aporte 10 %" to Money.round(aporte)
            details += "AFP prima de seguro ${Money.formatPercent(FiscalData.Peru.AFP_PRIMA_SEGURO)}" to Money.round(prima)
            details += "AFP comisión ${Money.formatPercent(afpCommissionPercent)}" to Money.round(comision)
        }

        // Proyección anual: 12 sueldos + 2 gratificaciones = 14 remuneraciones.
        val projected = gross.multiply(BigDecimal(14))
        val taxableAnnual = projected.subtract(FiscalData.Peru.DEDUCCION_7_UIT).max(BigDecimal.ZERO)
        val annualTax = annualIncomeTax(taxableAnnual)
        val monthlyTax = annualTax.divide(BigDecimal(12), Money.WORK_SCALE, RoundingMode.HALF_UP)
        if (monthlyTax.signum() > 0) {
            details += "Renta de quinta categoría" to Money.round(monthlyTax)
        }

        val totalDeductions = pension.add(monthlyTax)
        return NetSalaryResult(
            gross = Money.round(gross),
            familyAllowance = allowance,
            pensionName = pensionName,
            pensionAmount = Money.round(pension),
            incomeTax = Money.round(monthlyTax),
            totalDeductions = Money.round(totalDeductions),
            net = Money.round(gross.subtract(totalDeductions)),
            employerEsSalud = Money.round(Money.percent(gross, FiscalData.Peru.ESSALUD_EMPLEADOR)),
            details = details
        )
    }

    data class BenefitResult(val amount: BigDecimal, val extra: BigDecimal, val total: BigDecimal, val note: String)

    /** Gratificación de julio o diciembre más la bonificación extraordinaria. */
    fun gratificacion(monthlySalary: BigDecimal, monthsWorked: Int, hasEps: Boolean = false): BenefitResult {
        require(monthsWorked in 0..6) { "Los meses del semestre van de 0 a 6." }
        val amount = monthlySalary.multiply(BigDecimal(monthsWorked))
            .divide(BigDecimal(6), Money.WORK_SCALE, RoundingMode.HALF_UP)
        val bonusPercent = if (hasEps) FiscalData.Peru.BONIFICACION_GRATIFICACION_EPS
        else FiscalData.Peru.BONIFICACION_GRATIFICACION
        val extra = Money.percent(amount, bonusPercent)
        return BenefitResult(
            amount = Money.round(amount),
            extra = Money.round(extra),
            total = Money.round(amount.add(extra)),
            note = "La gratificación no paga AFP ni ONP. La bonificación extraordinaria de " +
                "${Money.formatPercent(bonusPercent)} la entrega el empleador en lugar del aporte a EsSalud."
        )
    }

    /**
     * CTS del semestre. La remuneración computable incluye un sexto de la última
     * gratificación, que es lo que casi todos olvidan.
     */
    fun cts(
        monthlySalary: BigDecimal,
        lastGratificacion: BigDecimal,
        months: Int,
        days: Int = 0
    ): BenefitResult {
        require(months in 0..6) { "Los meses del semestre van de 0 a 6." }
        require(days in 0..30) { "Los días van de 0 a 30." }
        val computable = monthlySalary.add(
            lastGratificacion.divide(BigDecimal(6), Money.WORK_SCALE, RoundingMode.HALF_UP)
        )
        val byMonths = computable.divide(BigDecimal(12), Money.WORK_SCALE, RoundingMode.HALF_UP)
            .multiply(BigDecimal(months))
        val byDays = computable.divide(BigDecimal(360), Money.WORK_SCALE, RoundingMode.HALF_UP)
            .multiply(BigDecimal(days))
        val total = byMonths.add(byDays)
        return BenefitResult(
            amount = Money.round(total),
            extra = BigDecimal.ZERO,
            total = Money.round(total),
            note = "Remuneración computable ${Money.format(computable)} (sueldo + 1/6 de gratificación). " +
                "Se deposita hasta el 15 de mayo y el 15 de noviembre."
        )
    }

    /** Vacaciones truncas: proporcional a los meses efectivamente trabajados. */
    fun vacacionesTruncas(monthlySalary: BigDecimal, months: Int, days: Int = 0): BenefitResult {
        val byMonths = monthlySalary.divide(BigDecimal(12), Money.WORK_SCALE, RoundingMode.HALF_UP)
            .multiply(BigDecimal(months))
        val byDays = monthlySalary.divide(BigDecimal(360), Money.WORK_SCALE, RoundingMode.HALF_UP)
            .multiply(BigDecimal(days))
        val total = byMonths.add(byDays)
        return BenefitResult(
            amount = Money.round(total),
            extra = BigDecimal.ZERO,
            total = Money.round(total),
            note = "Por año completo corresponden 30 días de descanso pagado."
        )
    }
}

// ---------------------------------------------------------------------------
// Inventario
// ---------------------------------------------------------------------------

data class StockLayer(val quantity: BigDecimal, val unitCost: BigDecimal)

data class ValuationResult(
    val method: String,
    val units: BigDecimal,
    val totalValue: BigDecimal,
    val averageCost: BigDecimal
)

object InventoryEngine {

    /**
     * Costo promedio ponderado móvil: cada compra recalcula el costo promedio.
     * Es el método más usado en el comercio pequeño porque no obliga a llevar
     * lotes separados.
     */
    fun weightedAverage(
        currentQuantity: BigDecimal,
        currentAverageCost: BigDecimal,
        incomingQuantity: BigDecimal,
        incomingUnitCost: BigDecimal
    ): BigDecimal {
        val totalUnits = currentQuantity.add(incomingQuantity)
        if (totalUnits.signum() <= 0) return BigDecimal.ZERO.setScale(4)
        val totalValue = currentQuantity.multiply(currentAverageCost)
            .add(incomingQuantity.multiply(incomingUnitCost))
        return totalValue.divide(totalUnits, 4, RoundingMode.HALF_UP)
    }

    /** Valuación PEPS: lo primero que entra es lo primero que sale. */
    fun fifoValuation(layers: List<StockLayer>): ValuationResult {
        val units = layers.fold(BigDecimal.ZERO) { acc, layer -> acc.add(layer.quantity) }
        val value = layers.fold(BigDecimal.ZERO) { acc, layer ->
            acc.add(layer.quantity.multiply(layer.unitCost))
        }
        val average = if (units.signum() > 0) {
            value.divide(units, 4, RoundingMode.HALF_UP)
        } else BigDecimal.ZERO
        return ValuationResult("PEPS (FIFO)", units, Money.round(value), average)
    }

    /** Consume unidades por PEPS y devuelve el costo de lo vendido y las capas que quedan. */
    fun consumeFifo(layers: List<StockLayer>, quantity: BigDecimal): Pair<BigDecimal, List<StockLayer>> {
        var remaining = quantity
        var cost = BigDecimal.ZERO
        val rest = mutableListOf<StockLayer>()
        for (layer in layers) {
            if (remaining.signum() <= 0) {
                rest += layer
                continue
            }
            val taken = layer.quantity.min(remaining)
            cost = cost.add(taken.multiply(layer.unitCost))
            remaining = remaining.subtract(taken)
            val left = layer.quantity.subtract(taken)
            if (left.signum() > 0) rest += StockLayer(left, layer.unitCost)
        }
        require(remaining.signum() <= 0) { "No hay stock suficiente para esa salida." }
        return Money.round(cost) to rest
    }

    /**
     * Punto de reorden: cuándo volver a pedir para no quedarse sin stock.
     * Consumo diario promedio × días que tarda el proveedor + stock de seguridad.
     */
    fun reorderPoint(
        averageDailyUsage: BigDecimal,
        leadTimeDays: Int,
        safetyStock: BigDecimal = BigDecimal.ZERO
    ): BigDecimal =
        averageDailyUsage.multiply(BigDecimal(leadTimeDays.coerceAtLeast(0)))
            .add(safetyStock)
            .setScale(2, RoundingMode.CEILING)

    /** Cuántos días de venta cubre el stock actual. */
    fun daysOfCover(quantity: BigDecimal, averageDailyUsage: BigDecimal): BigDecimal? {
        if (averageDailyUsage.signum() <= 0) return null
        return quantity.divide(averageDailyUsage, 1, RoundingMode.DOWN)
    }
}
