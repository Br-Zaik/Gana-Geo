package com.ganageo.app.ui.tools

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.WorkChecklistStore
import com.ganageo.app.data.WorkLedgerStore
import com.ganageo.app.tools.CurrencyInfo
import com.ganageo.app.tools.Money
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

private val incomeCategories = listOf("Ventas", "Servicios", "Sueldo", "Préstamo", "Otros")
private val expenseCategories = listOf("Insumos", "Transporte", "Alquiler", "Servicios", "Sueldos", "Impuestos", "Otros")

/**
 * Ingresos y gastos.
 *
 * Los importes se guardan en céntimos enteros, no en decimales de coma flotante:
 * así el saldo cuadra siempre, por más movimientos que se registren.
 */
@Composable
fun IncomeExpenseTrackerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { WorkLedgerStore(context) }
    val entries by store.entries.collectAsState(initial = emptyList())
    val currency = CurrencyInfo.PEN

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var isIncome by rememberSaveable { mutableStateOf(true) }
    var description by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("Ventas") }
    var amount by rememberSaveable { mutableStateOf("") }
    var periodIndex by rememberSaveable { mutableIntStateOf(2) }
    var message by remember { mutableStateOf<String?>(null) }

    val now = System.currentTimeMillis()
    val periodStart = when (periodIndex) {
        0 -> now - 24L * 60 * 60 * 1000
        1 -> now - 7L * 24 * 60 * 60 * 1000
        2 -> now - 30L * 24 * 60 * 60 * 1000
        else -> 0L
    }
    val visible = entries.filter { it.createdAt >= periodStart }

    val income = visible.filter { it.type == "ingreso" }.sumOf { it.amountCents }
    val expense = visible.filter { it.type == "gasto" }.sumOf { it.amountCents }
    val balance = income - expense

    val csvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            val formatter = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "PE"))
            val csv = buildString {
                appendLine("Fecha,Tipo,Descripcion,Categoria,Monto")
                visible.forEach { entry ->
                    appendLine(
                        listOf(
                            csvCell(formatter.format(Date(entry.createdAt))),
                            csvCell(entry.type),
                            csvCell(entry.description),
                            csvCell(entry.category),
                            Money.fromCents(entry.amountCents).toPlainString()
                        ).joinToString(",")
                    )
                }
                appendLine()
                appendLine("Ingresos,,,,${Money.fromCents(income).toPlainString()}")
                appendLine("Gastos,,,,${Money.fromCents(expense).toPlainString()}")
                appendLine("Saldo,,,,${Money.fromCents(balance).toPlainString()}")
            }
            writeTextToUri(context, uri, csv)
        }.onSuccess { message = "Movimientos exportados." }
            .onFailure { message = it.message ?: "No se pudo exportar." }
    }

    ScienceShell(
        title = "Ingresos y gastos",
        subtitle = "Saldo ${Money.formatCents(balance, currency)}",
        onBack = onBack
    ) {
        StudioTabs(listOf("Registrar", "Movimientos", "Resumen"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Nuevo movimiento") {
                    StudioChipRow {
                        StudioChip("Ingreso", isIncome, onClick = {
                            isIncome = true
                            category = incomeCategories.first()
                        })
                        StudioChip("Gasto", !isIncome, onClick = {
                            isIncome = false
                            category = expenseCategories.first()
                        })
                    }
                    StudioTextField(description, { description = it }, "Descripción", modifier = Modifier.fillMaxWidth())
                    ScienceNumberField(amount, { amount = it }, "Monto", Modifier.fillMaxWidth())
                    StudioLabel("Categoría")
                    StudioChipRow {
                        (if (isIncome) incomeCategories else expenseCategories).forEach { option ->
                            StudioChip(option, category == option, onClick = { category = option })
                        }
                    }
                    WorkActionButton("Registrar", {
                        scope.launch {
                            runCatching {
                                store.add(
                                    type = if (isIncome) "ingreso" else "gasto",
                                    description = description,
                                    category = category,
                                    amount = Money.ofOrZero(amount).toDouble()
                                )
                            }.onSuccess {
                                description = ""
                                amount = ""
                                message = "Movimiento registrado."
                            }.onFailure { message = it.message ?: "No se pudo registrar." }
                        }
                    }, Icons.Rounded.Add)
                }

                WorkTotals(
                    rows = listOf(
                        "Ingresos" to Money.formatCents(income, currency),
                        "Gastos" to "− " + Money.formatCents(expense, currency)
                    ),
                    total = "Saldo del periodo" to Money.formatCents(balance, currency)
                )
            }

            1 -> {
                ScienceCard("Periodo") {
                    StudioChipRow {
                        listOf("Hoy", "7 días", "30 días", "Todo").forEachIndexed { index, label ->
                            StudioChip(label, periodIndex == index, onClick = { periodIndex = index })
                        }
                    }
                }
                val formatter = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "PE")) }
                if (visible.isEmpty()) {
                    StudioHint("No hay movimientos en este periodo.")
                }
                visible.take(120).forEach { entry ->
                    ScienceCard(null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    entry.description,
                                    color = StudioTheme.TextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    "${entry.category} · ${formatter.format(Date(entry.createdAt))}",
                                    color = StudioTheme.TextSecondary,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            Text(
                                (if (entry.type == "ingreso") "+ " else "− ") +
                                    Money.formatCents(entry.amountCents, currency),
                                color = if (entry.type == "ingreso") StudioTheme.Accent else Color(0xFFFF8A80),
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            IconButton(onClick = { scope.launch { store.delete(entry.id) } }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = StudioTheme.TextSecondary)
                            }
                        }
                    }
                }
            }

            else -> {
                val byCategory = visible.groupBy { it.category }
                    .map { (name, list) ->
                        Triple(
                            name,
                            list.filter { it.type == "gasto" }.sumOf { it.amountCents },
                            list.filter { it.type == "ingreso" }.sumOf { it.amountCents }
                        )
                    }
                    .sortedByDescending { it.second + it.third }

                WorkTotals(
                    rows = listOf(
                        "Movimientos" to visible.size.toString(),
                        "Ingresos" to Money.formatCents(income, currency),
                        "Gastos" to "− " + Money.formatCents(expense, currency)
                    ),
                    total = "Saldo" to Money.formatCents(balance, currency),
                    note = if (balance < 0) "Estás gastando más de lo que ingresa en este periodo." else null
                )

                ScienceCard("Por categoría") {
                    if (byCategory.isEmpty()) {
                        StudioHint("Sin datos en este periodo.")
                    }
                    val maxValue = byCategory.maxOfOrNull { it.second + it.third }?.coerceAtLeast(1L) ?: 1L
                    byCategory.forEach { (name, expenses, incomes) ->
                        val total = expenses + incomes
                        Column {
                            MoneyRow(name, Money.formatCents(total, currency))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(StudioTheme.Outline)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth((total.toFloat() / maxValue).coerceIn(0f, 1f))
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(if (incomes >= expenses) StudioTheme.Accent else Color(0xFFFF8A80))
                                )
                            }
                        }
                    }
                }

                WorkActionButton(
                    "Exportar en CSV",
                    { csvLauncher.launch("movimientos.csv") },
                    Icons.Rounded.Save,
                    enabled = visible.isNotEmpty()
                )
                StudioHint("Todo se guarda solo en este teléfono. Exporta de vez en cuando para tener respaldo.")
            }
        }

        message?.let { StudioHint(it) }
    }
}

/**
 * Checklist de trabajo.
 *
 * Pensado para las tareas de una jornada real: se agrupan por área para que en
 * obra, taller o tienda cada quien vea de un vistazo lo suyo.
 */
@Composable
fun WorkChecklistScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { WorkChecklistStore(context) }
    val items by store.items.collectAsState(initial = emptyList())

    var title by rememberSaveable { mutableStateOf("") }
    var area by rememberSaveable { mutableStateOf("") }
    var filterArea by rememberSaveable { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    val areas = items.map { it.area.ifBlank { "Sin área" } }.distinct().sorted()
    val visible = items.filter { filterArea == null || it.area.ifBlank { "Sin área" } == filterArea }
    val done = visible.count { it.completed }
    val progress = if (visible.isEmpty()) 0f else done.toFloat() / visible.size

    fun asText(): String = buildString {
        appendLine("Checklist de trabajo")
        appendLine("Avance: $done de ${visible.size}")
        appendLine()
        visible.groupBy { it.area.ifBlank { "Sin área" } }.forEach { (group, list) ->
            appendLine(group.uppercase())
            list.forEach { item ->
                appendLine("${if (item.completed) "[x]" else "[ ]"} ${item.title}")
            }
            appendLine()
        }
    }

    ScienceShell(
        title = "Checklist de trabajo",
        subtitle = "$done de ${visible.size} completadas",
        onBack = onBack,
        trailing = {
            IconButton(onClick = { shareText(context, "Checklist de trabajo", asText()) }) {
                Icon(Icons.Rounded.Share, contentDescription = "Compartir", tint = StudioTheme.TextPrimary)
            }
        }
    ) {
        ScienceCard("Nueva actividad") {
            StudioTextField(title, { title = it }, "¿Qué hay que hacer?", modifier = Modifier.fillMaxWidth())
            StudioTextField(area, { area = it }, "Área o responsable", modifier = Modifier.fillMaxWidth())
            WorkActionButton("Agregar", {
                scope.launch {
                    runCatching { store.add(title, area) }
                        .onSuccess {
                            title = ""
                            message = null
                        }
                        .onFailure { message = it.message ?: "No se pudo agregar." }
                }
            }, Icons.Rounded.Add)
        }

        if (visible.isNotEmpty()) {
            ScienceCard("Avance") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(StudioTheme.Outline)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progress)
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(StudioTheme.Accent)
                    )
                }
                MoneyRow("Completadas", "$done de ${visible.size}", highlight = done == visible.size)
            }
        }

        if (areas.size > 1) {
            ScienceCard("Filtrar por área") {
                StudioChipRow {
                    StudioChip("Todas", filterArea == null, onClick = { filterArea = null })
                    areas.forEach { name ->
                        StudioChip(name, filterArea == name, onClick = { filterArea = name })
                    }
                }
            }
        }

        visible.groupBy { it.area.ifBlank { "Sin área" } }.forEach { (group, list) ->
            ScienceCard(group) {
                list.forEach { item ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { scope.launch { store.toggle(item.id) } }) {
                            Icon(
                                if (item.completed) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                contentDescription = "Marcar",
                                tint = if (item.completed) StudioTheme.Accent else StudioTheme.TextSecondary
                            )
                        }
                        Text(
                            item.title,
                            color = if (item.completed) StudioTheme.TextSecondary else StudioTheme.TextPrimary,
                            textDecoration = if (item.completed) TextDecoration.LineThrough else null,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { scope.launch { store.delete(item.id) } }) {
                            Icon(
                                Icons.Rounded.Delete,
                                contentDescription = "Eliminar",
                                tint = StudioTheme.TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        if (items.isEmpty()) {
            StudioHint("Agrega la primera actividad de la jornada.")
        }

        if (items.any { it.completed }) {
            WorkActionButton(
                "Quitar las completadas",
                { scope.launch { store.clearCompleted() } },
                Icons.Rounded.Delete
            )
        }

        message?.let { ScienceError(it) }
    }
}
