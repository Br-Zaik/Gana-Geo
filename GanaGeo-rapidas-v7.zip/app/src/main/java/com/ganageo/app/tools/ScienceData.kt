package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

// ---------------------------------------------------------------------------
// Estadística
// ---------------------------------------------------------------------------

/** Los dos métodos habituales para los cuartiles. Dan resultados distintos. */
enum class QuartileMethod(val label: String, val description: String) {
    EXCLUSIVE(
        "Exclusivo",
        "Parte los datos por la mediana y la excluye de cada mitad. Es el método de Tukey."
    ),
    INCLUSIVE(
        "Inclusivo",
        "Interpola la posición (n−1)·p. Es el que usan Excel (CUARTIL.INC) y la mayoría de calculadoras."
    )
}

data class StatsSummary(
    val count: Int,
    val sum: Double,
    val mean: Double,
    val median: Double,
    val modes: List<Double>,
    val minimum: Double,
    val maximum: Double,
    val range: Double,
    val q1: Double,
    val q3: Double,
    val iqr: Double,
    val varianceSample: Double,
    val deviationSample: Double,
    val variancePopulation: Double,
    val deviationPopulation: Double,
    val coefficientOfVariation: Double,
    val skewness: Double,
    val outliers: List<Double>,
    val sorted: List<Double>
)

data class HistogramBin(val from: Double, val to: Double, val count: Int)

data class RegressionResult(
    val slope: Double,
    val intercept: Double,
    val correlation: Double,
    val determination: Double,
    val equation: String
)

object StatsLab {

    fun parseValues(raw: String): List<Double> {
        val values = raw.split(Regex("[,;\\s\\n\\t]+"))
            .filter { it.isNotBlank() }
            .map {
                it.replace(',', '.').toDoubleOrNull()
                    ?: throw IllegalArgumentException("«$it» no es un número válido.")
            }
        require(values.isNotEmpty()) { "Escribe o pega al menos un dato." }
        require(values.size <= 5000) { "Máximo 5000 datos." }
        require(values.all { it.isFinite() }) { "Hay datos fuera de rango." }
        return values
    }

    /** Lee pares x,y de un texto con dos columnas (pegado desde una hoja de cálculo). */
    fun parsePairs(raw: String): List<Pair<Double, Double>> {
        val rows = raw.lines().filter { it.isNotBlank() }
        val pairs = rows.mapNotNull { line ->
            val parts = line.split(Regex("[,;\\s\\t]+")).filter { it.isNotBlank() }
            if (parts.size < 2) return@mapNotNull null
            val x = parts[0].replace(',', '.').toDoubleOrNull()
            val y = parts[1].replace(',', '.').toDoubleOrNull()
            if (x == null || y == null) null else x to y
        }
        require(pairs.size >= 2) { "Escribe al menos dos pares de datos, uno por línea: «x  y»." }
        return pairs
    }

    fun summarize(values: List<Double>, method: QuartileMethod = QuartileMethod.INCLUSIVE): StatsSummary {
        require(values.isNotEmpty()) { "No hay datos." }
        val sorted = values.sorted()
        val n = sorted.size
        val sum = sorted.sum()
        val mean = sum / n
        val median = percentile(sorted, 0.5, QuartileMethod.INCLUSIVE)
        val q1 = quartile(sorted, 1, method)
        val q3 = quartile(sorted, 3, method)
        val iqr = q3 - q1

        val frequency = sorted.groupingBy { it }.eachCount()
        val maxFrequency = frequency.values.maxOrNull() ?: 0
        val modes = if (maxFrequency <= 1) emptyList()
        else frequency.filterValues { it == maxFrequency }.keys.sorted()

        val squaredDeviations = sorted.sumOf { (it - mean).pow(2) }
        val variancePopulation = squaredDeviations / n
        val varianceSample = if (n > 1) squaredDeviations / (n - 1) else 0.0
        val deviationPopulation = sqrt(variancePopulation)
        val deviationSample = sqrt(varianceSample)

        val skewness = if (n > 2 && deviationSample > 1e-12) {
            val factor = n.toDouble() / ((n - 1).toDouble() * (n - 2).toDouble())
            factor * sorted.sumOf { ((it - mean) / deviationSample).pow(3) }
        } else 0.0

        val lowerFence = q1 - 1.5 * iqr
        val upperFence = q3 + 1.5 * iqr
        val outliers = sorted.filter { it < lowerFence || it > upperFence }

        return StatsSummary(
            count = n,
            sum = sum,
            mean = mean,
            median = median,
            modes = modes,
            minimum = sorted.first(),
            maximum = sorted.last(),
            range = sorted.last() - sorted.first(),
            q1 = q1,
            q3 = q3,
            iqr = iqr,
            varianceSample = varianceSample,
            deviationSample = deviationSample,
            variancePopulation = variancePopulation,
            deviationPopulation = deviationPopulation,
            coefficientOfVariation = if (abs(mean) > 1e-12) deviationSample / abs(mean) * 100 else Double.NaN,
            skewness = skewness,
            outliers = outliers,
            sorted = sorted
        )
    }

    fun quartile(sorted: List<Double>, quarter: Int, method: QuartileMethod): Double {
        if (sorted.size == 1) return sorted.first()
        return when (method) {
            QuartileMethod.INCLUSIVE -> percentile(sorted, quarter / 4.0, method)
            QuartileMethod.EXCLUSIVE -> {
                val n = sorted.size
                val half = n / 2
                val lower = sorted.subList(0, half)
                val upper = if (n % 2 == 0) sorted.subList(half, n) else sorted.subList(half + 1, n)
                when (quarter) {
                    1 -> medianOf(lower)
                    3 -> medianOf(upper)
                    else -> medianOf(sorted)
                }
            }
        }
    }

    fun percentile(sorted: List<Double>, fraction: Double, method: QuartileMethod): Double {
        if (sorted.isEmpty()) return Double.NaN
        if (sorted.size == 1) return sorted.first()
        val p = fraction.coerceIn(0.0, 1.0)
        return when (method) {
            QuartileMethod.EXCLUSIVE -> quartile(sorted, (p * 4).toInt(), method)
            QuartileMethod.INCLUSIVE -> {
                val position = p * (sorted.size - 1)
                val low = floor(position).toInt()
                val high = ceil(position).toInt()
                if (low == high) sorted[low]
                else sorted[low] + (position - low) * (sorted[high] - sorted[low])
            }
        }
    }

    private fun medianOf(values: List<Double>): Double {
        if (values.isEmpty()) return Double.NaN
        val middle = values.size / 2
        return if (values.size % 2 == 0) (values[middle - 1] + values[middle]) / 2 else values[middle]
    }

    /** Número de clases por la regla de Sturges, acotado para que se vea bien. */
    fun suggestedBins(count: Int): Int =
        (1 + 3.322 * log10(count.toDouble().coerceAtLeast(1.0))).toInt().coerceIn(4, 16)

    fun histogram(values: List<Double>, bins: Int = suggestedBins(values.size)): List<HistogramBin> {
        if (values.isEmpty()) return emptyList()
        val minimum = values.min()
        val maximum = values.max()
        if (abs(maximum - minimum) < 1e-12) {
            return listOf(HistogramBin(minimum, maximum, values.size))
        }
        val safeBins = bins.coerceIn(2, 30)
        val width = (maximum - minimum) / safeBins
        return (0 until safeBins).map { index ->
            val from = minimum + index * width
            val to = from + width
            val count = values.count { value ->
                if (index == safeBins - 1) value >= from && value <= to + 1e-12
                else value >= from && value < to
            }
            HistogramBin(from, to, count)
        }
    }

    fun linearRegression(points: List<Pair<Double, Double>>): RegressionResult {
        require(points.size >= 2) { "Se necesitan al menos dos puntos." }
        val n = points.size
        val meanX = points.sumOf { it.first } / n
        val meanY = points.sumOf { it.second } / n
        var sxy = 0.0
        var sxx = 0.0
        var syy = 0.0
        points.forEach { (x, y) ->
            val dx = x - meanX
            val dy = y - meanY
            sxy += dx * dy
            sxx += dx * dx
            syy += dy * dy
        }
        require(sxx > 1e-12) { "Todos los valores de x son iguales: no se puede ajustar una recta." }
        val slope = sxy / sxx
        val intercept = meanY - slope * meanX
        val correlation = if (syy < 1e-12) 0.0 else sxy / sqrt(sxx * syy)
        val sign = if (intercept < 0) "−" else "+"
        return RegressionResult(
            slope = slope,
            intercept = intercept,
            correlation = correlation,
            determination = correlation * correlation,
            equation = "y = ${MathEngine.formatNumber(slope, 4)}x $sign ${MathEngine.formatNumber(abs(intercept), 4)}"
        )
    }
}

// ---------------------------------------------------------------------------
// Graficado
// ---------------------------------------------------------------------------

data class PlotPoint(val x: Double, val y: Double)

/**
 * Motor de muestreo para las gráficas.
 *
 * Devuelve la curva partida en trazos: cada vez que la función se sale del
 * dominio o pega un salto imposible (una asíntota, por ejemplo) se corta el
 * trazo y se empieza otro. Así nunca se dibuja la línea vertical falsa que
 * aparece en tan(x) o en 1/x cuando se unen todos los puntos a ciegas.
 */
object PlotEngine {

    fun sample(
        f: (Double) -> Double,
        xMin: Double,
        xMax: Double,
        yMin: Double,
        yMax: Double,
        samples: Int = 900
    ): List<List<PlotPoint>> {
        if (xMax <= xMin) return emptyList()
        val count = samples.coerceIn(120, 4000)
        val step = (xMax - xMin) / count
        val height = (yMax - yMin).takeIf { it > 0 } ?: 1.0
        // Un salto mayor que media pantalla entre dos muestras contiguas se trata
        // como discontinuidad y no se une con una línea.
        val jumpLimit = height * 0.5

        val segments = mutableListOf<List<PlotPoint>>()
        var current = mutableListOf<PlotPoint>()
        var previous: PlotPoint? = null

        for (i in 0..count) {
            val x = xMin + i * step
            val y = f(x)
            if (!y.isFinite()) {
                if (current.size > 1) segments += current
                current = mutableListOf()
                previous = null
                continue
            }
            val point = PlotPoint(x, y)
            val last = previous
            if (last != null) {
                val jump = abs(y - last.y)
                val crossesAxis = (last.y - yMin) * (y - yMin) < 0 || (last.y - yMax) * (y - yMax) < 0
                if (jump > jumpLimit && (crossesAxis || jump > height * 4)) {
                    if (current.size > 1) segments += current
                    current = mutableListOf()
                } else if (jump > height * 0.02) {
                    // Zona con curvatura fuerte: se añaden puntos intermedios para
                    // que la curva se vea suave y no en escalones.
                    refine(f, last, point, current, height, 0)
                }
            }
            current += point
            previous = point
        }
        if (current.size > 1) segments += current
        return segments
    }

    private fun refine(
        f: (Double) -> Double,
        a: PlotPoint,
        b: PlotPoint,
        output: MutableList<PlotPoint>,
        height: Double,
        depth: Int
    ) {
        if (depth >= 4) return
        val midX = (a.x + b.x) / 2
        val midY = f(midX)
        if (!midY.isFinite()) return
        val interpolated = (a.y + b.y) / 2
        if (abs(midY - interpolated) < height * 0.004) return
        val mid = PlotPoint(midX, midY)
        refine(f, a, mid, output, height, depth + 1)
        output += mid
        refine(f, mid, b, output, height, depth + 1)
    }

    /** Escala automática del eje Y descartando los valores extremos. */
    fun autoRangeY(f: (Double) -> Double, xMin: Double, xMax: Double, samples: Int = 400): Pair<Double, Double> {
        val values = mutableListOf<Double>()
        val step = (xMax - xMin) / samples
        for (i in 0..samples) {
            val y = f(xMin + i * step)
            if (y.isFinite()) values += y
        }
        if (values.isEmpty()) return -10.0 to 10.0
        values.sort()
        // Se ignora el 2 % de cada extremo para que una asíntota no aplaste la curva.
        val low = values[(values.size * 0.02).toInt().coerceIn(0, values.lastIndex)]
        val high = values[(values.size * 0.98).toInt().coerceIn(0, values.lastIndex)]
        if (abs(high - low) < 1e-9) return (low - 1) to (high + 1)
        val margin = (high - low) * 0.12
        return (low - margin) to (high + margin)
    }

    /** Paso de rejilla "bonito": 1, 2, 5 por potencia de diez. */
    fun niceStep(range: Double, targetLines: Int = 8): Double {
        if (range <= 0 || !range.isFinite()) return 1.0
        val rough = range / targetLines
        val magnitude = 10.0.pow(floor(log10(rough)))
        val normalized = rough / magnitude
        val nice = when {
            normalized < 1.5 -> 1.0
            normalized < 3.0 -> 2.0
            normalized < 7.0 -> 5.0
            else -> 10.0
        }
        return nice * magnitude
    }

    fun formatTick(value: Double, step: Double): String {
        if (abs(value) < step * 0.001) return "0"
        val decimals = when {
            step >= 1 -> 0
            step >= 0.1 -> 1
            step >= 0.01 -> 2
            else -> 3
        }
        return String.format("%.${decimals}f", value)
    }

    /** Puntos notables de la primera función: raíces, máximos y mínimos. */
    data class Highlights(
        val roots: List<Double>,
        val minima: List<PlotPoint>,
        val maxima: List<PlotPoint>,
        val yIntercept: Double?
    )

    fun highlights(f: (Double) -> Double, xMin: Double, xMax: Double): Highlights {
        val roots = NumericCalculus.rootsIn(f, xMin, xMax, 1500).take(12)
        val minima = mutableListOf<PlotPoint>()
        val maxima = mutableListOf<PlotPoint>()
        val samples = 900
        val step = (xMax - xMin) / samples
        var previous = f(xMin)
        var current = f(xMin + step)
        for (i in 2..samples) {
            val x = xMin + i * step
            val next = f(x)
            if (previous.isFinite() && current.isFinite() && next.isFinite()) {
                val cx = x - step
                if (current < previous && current < next) minima += PlotPoint(cx, current)
                if (current > previous && current > next) maxima += PlotPoint(cx, current)
            }
            previous = current
            current = next
        }
        val intercept = f(0.0).takeIf { it.isFinite() && 0.0 in xMin..xMax }
        return Highlights(
            roots = roots,
            minima = thin(minima).take(8),
            maxima = thin(maxima).take(8),
            yIntercept = intercept
        )
    }

    private fun thin(points: List<PlotPoint>): List<PlotPoint> {
        val result = mutableListOf<PlotPoint>()
        points.sortedBy { it.x }.forEach { point ->
            if (result.none { abs(it.x - point.x) < 1e-3 }) result += point
        }
        return result
    }

    fun intersections(
        f: (Double) -> Double,
        g: (Double) -> Double,
        xMin: Double,
        xMax: Double
    ): List<PlotPoint> {
        val difference: (Double) -> Double = { x ->
            val a = f(x)
            val b = g(x)
            if (a.isFinite() && b.isFinite()) a - b else Double.NaN
        }
        return NumericCalculus.rootsIn(difference, xMin, xMax, 1500)
            .mapNotNull { x -> f(x).takeIf { it.isFinite() }?.let { PlotPoint(x, it) } }
            .take(12)
    }

    /** Recta tangente a la curva en un punto, útil para explicar la derivada. */
    fun tangentAt(f: (Double) -> Double, x: Double): Pair<Double, Double>? {
        val y = f(x)
        if (!y.isFinite()) return null
        val slope = NumericCalculus.derivativeAt(f, x)
        if (!slope.isFinite()) return null
        return slope to (y - slope * x)
    }

    fun angleOf(slope: Double): Double = Math.toDegrees(atan(slope))

    fun clamp(value: Double, low: Double, high: Double): Double = max(low, min(high, value))
}
