package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.ImageStudioOps
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Piezas comunes de las seis herramientas de imagen.
 *
 * Todas las pantallas usan la misma estructura de tres zonas: barra superior con
 * cerrar, restablecer y guardar; lienzo grande con la imagen y sus gestos; y
 * panel inferior con los controles. Asi la app se siente como un solo editor y
 * no como seis formularios distintos.
 */

object StudioTheme {
    val Background = Color(0xFF10141C)
    val Surface = Color(0xFF171C26)
    val SurfaceHigh = Color(0xFF212736)
    val Canvas = Color(0xFF05070B)
    val Accent = Color(0xFFB7FF00)
    val OnAccent = Color(0xFF07210F)
    val TextPrimary = Color(0xFFF2F5FA)
    val TextSecondary = Color(0xFF9AA6BC)
    val Outline = Color(0xFF303849)
    val Warning = Color(0xFFFFC542)
}

// ---------------------------------------------------------------------------
// Estructura general
// ---------------------------------------------------------------------------

@Composable
fun StudioShell(
    title: String,
    subtitle: String?,
    saving: Boolean,
    saveLabel: String,
    saveEnabled: Boolean,
    onClose: () -> Unit,
    onReset: (() -> Unit)?,
    onSave: () -> Unit,
    canvas: @Composable BoxScope.() -> Unit,
    panel: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioTheme.Background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        StudioTopBar(
            title = title,
            subtitle = subtitle,
            saving = saving,
            saveLabel = saveLabel,
            saveEnabled = saveEnabled,
            onClose = onClose,
            onReset = onReset,
            onSave = onSave
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(StudioTheme.Canvas)
                .clipToBounds(),
            content = canvas
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioTheme.Surface)
                .imePadding(),
            content = panel
        )
    }
}

@Composable
private fun StudioTopBar(
    title: String,
    subtitle: String?,
    saving: Boolean,
    saveLabel: String,
    saveEnabled: Boolean,
    onClose: () -> Unit,
    onReset: (() -> Unit)?,
    onSave: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioTheme.Background)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) {
            Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = StudioTheme.TextPrimary)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title,
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (subtitle != null) {
                Text(
                    subtitle,
                    color = StudioTheme.TextSecondary,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (onReset != null) {
            IconButton(onClick = onReset, enabled = !saving) {
                Icon(
                    Icons.Rounded.Refresh,
                    contentDescription = "Restablecer",
                    tint = if (saving) StudioTheme.TextSecondary else StudioTheme.TextPrimary
                )
            }
        }
        Spacer(Modifier.width(4.dp))
        Button(
            onClick = onSave,
            enabled = saveEnabled && !saving,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = StudioTheme.Accent,
                contentColor = StudioTheme.OnAccent,
                disabledContainerColor = StudioTheme.SurfaceHigh,
                disabledContentColor = StudioTheme.TextSecondary
            ),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
        ) {
            if (saving) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = StudioTheme.TextSecondary,
                    strokeWidth = 2.dp
                )
                Spacer(Modifier.width(8.dp))
                Text("Guardando", fontWeight = FontWeight.Bold)
            } else {
                Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(saveLabel, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.width(4.dp))
    }
}

/** Panel inferior desplazable. Nunca ocupa mas de la mitad util de la pantalla. */
@Composable
fun StudioPanel(
    maxHeight: Dp = 260.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = maxHeight)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

/** Pestanas inferiores del editor. */
@Composable
fun StudioTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioTheme.Background)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        labels.forEachIndexed { index, label ->
            val active = index == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (active) StudioTheme.Accent else StudioTheme.SurfaceHigh)
                    .clickable { onSelect(index) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (active) StudioTheme.OnAccent else StudioTheme.TextPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun StudioChip(
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    caption: String? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(13.dp))
            .background(if (active) StudioTheme.Accent else StudioTheme.SurfaceHigh)
            .border(
                1.dp,
                if (active) StudioTheme.Accent else StudioTheme.Outline,
                RoundedCornerShape(13.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            label,
            color = if (active) StudioTheme.OnAccent else StudioTheme.TextPrimary,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1
        )
        if (caption != null) {
            Text(
                caption,
                color = if (active) StudioTheme.OnAccent.copy(alpha = 0.75f) else StudioTheme.TextSecondary,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1
            )
        }
    }
}

/** Fila de chips con desplazamiento horizontal. */
@Composable
fun StudioChipRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}

@Composable
fun StudioLabel(text: String, value: String? = null) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            text,
            color = StudioTheme.TextSecondary,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.weight(1f)
        )
        if (value != null) {
            Text(
                value,
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

@Composable
fun StudioSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        StudioLabel(label, valueText)
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = StudioTheme.Accent,
                activeTrackColor = StudioTheme.Accent,
                inactiveTrackColor = StudioTheme.Outline
            )
        )
    }
}

@Composable
fun StudioNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    decimal: Boolean = false,
    maxLength: Int = 6
) {
    OutlinedTextField(
        value = value,
        onValueChange = { input ->
            val filtered = if (decimal) {
                input.filter { it.isDigit() || it == '.' || it == ',' }
            } else {
                input.filter(Char::isDigit)
            }
            onValueChange(filtered.take(maxLength))
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number
        ),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = StudioTheme.TextPrimary,
            unfocusedTextColor = StudioTheme.TextPrimary,
            focusedBorderColor = StudioTheme.Accent,
            unfocusedBorderColor = StudioTheme.Outline,
            focusedLabelColor = StudioTheme.Accent,
            unfocusedLabelColor = StudioTheme.TextSecondary,
            cursorColor = StudioTheme.Accent
        ),
        modifier = modifier
    )
}

@Composable
fun StudioTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String? = null,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = placeholder?.let { { Text(it) } },
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = StudioTheme.TextPrimary,
            unfocusedTextColor = StudioTheme.TextPrimary,
            focusedBorderColor = StudioTheme.Accent,
            unfocusedBorderColor = StudioTheme.Outline,
            focusedLabelColor = StudioTheme.Accent,
            unfocusedLabelColor = StudioTheme.TextSecondary,
            cursorColor = StudioTheme.Accent
        ),
        modifier = modifier
    )
}

@Composable
fun StudioHint(text: String) {
    Text(
        text,
        color = StudioTheme.TextSecondary,
        style = MaterialTheme.typography.bodySmall
    )
}

/** Etiqueta flotante sobre el lienzo con las medidas y el peso estimado. */
@Composable
fun BoxScope.StudioBadge(text: String, alignment: Alignment = Alignment.BottomEnd) {
    Box(
        modifier = Modifier
            .align(alignment)
            .padding(10.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xCC0B0E14))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text,
            color = StudioTheme.TextPrimary,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold
        )
    }
}

// ---------------------------------------------------------------------------
// Lienzo
// ---------------------------------------------------------------------------

/**
 * Lienzo con pellizco para ampliar. El zoom es de imagen, nunca de interfaz: la
 * hoja se mantiene anclada y el contenido no se reacomoda.
 */
@Composable
fun StudioCanvas(
    bitmap: Bitmap,
    modifier: Modifier = Modifier,
    colorFilter: ColorFilter? = null,
    gesturesEnabled: Boolean = true,
    overlay: @Composable BoxScope.(imageWidth: Float, imageHeight: Float) -> Unit = { _, _ -> }
) {
    val zoomState = remember { mutableFloatStateOf(1f) }
    val panXState = remember { mutableFloatStateOf(0f) }
    val panYState = remember { mutableFloatStateOf(0f) }

    BoxWithConstraints(modifier = modifier.fillMaxSize().clipToBounds()) {
        val density = LocalDensity.current
        val viewportW = with(density) { maxWidth.toPx() }
        val viewportH = with(density) { maxHeight.toPx() }
        val ratio = bitmap.width.toFloat() / bitmap.height.toFloat().coerceAtLeast(1f)
        val boxRatio = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
        val displayWidth = if (ratio > boxRatio) maxWidth.value * 0.94f else maxHeight.value * 0.9f * ratio
        val displayHeight = displayWidth / ratio.coerceAtLeast(0.0001f)

        Box(
            modifier = Modifier
                .fillMaxSize()
                .then(
                    if (gesturesEnabled) {
                        Modifier.viewerPinchZoomGestures(
                            gestureKey = bitmap,
                            zoomState = zoomState,
                            panXState = panXState,
                            panYState = panYState,
                            minZoom = 1f,
                            maxZoom = 6f,
                            viewportWidthPx = viewportW,
                            viewportHeightPx = viewportH,
                            allowSingleFingerPan = true
                        )
                    } else Modifier
                ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(0f, 0f)
                        scaleX = zoomState.floatValue
                        scaleY = zoomState.floatValue
                        translationX = panXState.floatValue
                        translationY = panYState.floatValue
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(displayWidth.dp)
                        .height(displayHeight.dp)
                ) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Vista previa",
                        contentScale = ContentScale.Fit,
                        colorFilter = colorFilter,
                        modifier = Modifier.fillMaxSize()
                    )
                    overlay(displayWidth, displayHeight)
                }
            }
        }
    }
}

fun studioColorFilter(matrix: FloatArray): ColorFilter = ColorFilter.colorMatrix(ColorMatrix(matrix))

// ---------------------------------------------------------------------------
// Comparador antes / despues
// ---------------------------------------------------------------------------

/**
 * Comparador con divisor arrastrable, el mismo recurso que usan las webs de
 * compresion: a la izquierda queda el original y a la derecha el resultado.
 */
@Composable
fun StudioBeforeAfter(
    original: Bitmap,
    result: Bitmap,
    modifier: Modifier = Modifier,
    leftLabel: String = "Original",
    rightLabel: String = "Resultado"
) {
    var fraction by remember { mutableFloatStateOf(0.5f) }
    val comparable = abs(
        original.width.toFloat() / original.height.coerceAtLeast(1) -
            result.width.toFloat() / result.height.coerceAtLeast(1)
    ) < 0.02f

    if (!comparable) {
        StudioCanvas(bitmap = result, modifier = modifier)
        return
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(original, result) {
                detectDragGestures { _, drag ->
                    val width = size.width.toFloat().coerceAtLeast(1f)
                    fraction = (fraction + drag.x / width).coerceIn(0f, 1f)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Image(
            bitmap = original.asImageBitmap(),
            contentDescription = leftLabel,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().padding(12.dp)
        )
        Image(
            bitmap = result.asImageBitmap(),
            contentDescription = rightLabel,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .drawWithContent {
                    clipRect(left = size.width * fraction, right = size.width) {
                        this@drawWithContent.drawContent()
                    }
                }
        )
        Canvas(modifier = Modifier.fillMaxSize()) {
            val x = size.width * fraction
            drawLine(
                color = Color.White,
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = 3f
            )
            drawCircle(color = Color.White, radius = 22f, center = Offset(x, size.height / 2f))
            drawCircle(
                color = Color(0xFF10141C),
                radius = 16f,
                center = Offset(x, size.height / 2f)
            )
        }
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(14.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xCC0B0E14))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(leftLabel, color = StudioTheme.TextPrimary, style = MaterialTheme.typography.labelSmall)
        }
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(14.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xCC0B0E14))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(rightLabel, color = StudioTheme.Accent, style = MaterialTheme.typography.labelSmall)
        }
    }
}

// ---------------------------------------------------------------------------
// Recuadro de recorte
// ---------------------------------------------------------------------------

enum class StudioCropHandle { MOVE, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT, LEFT, RIGHT, TOP, BOTTOM }

/**
 * Recuadro de recorte libre con rejilla de tercios. El usuario arrastra esquinas,
 * bordes o el recuadro entero y decide que parte de la foto se queda. Nunca se
 * recorta por el centro sin preguntar.
 */
@Composable
fun StudioCropOverlay(
    left: Float,
    top: Float,
    right: Float,
    bottom: Float,
    lockedRatio: Float?,
    onChange: (Float, Float, Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentRect by rememberUpdatedState(listOf(left, top, right, bottom))
    val changeListener by rememberUpdatedState(onChange)
    val ratio by rememberUpdatedState(lockedRatio)

    BoxWithConstraints(modifier) {
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        var handle by remember { mutableStateOf<StudioCropHandle?>(null) }
        val grabRadius = 52f
        val minSize = 0.06f

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(widthPx, heightPx) {
                    detectDragGestures(
                        onDragStart = { point ->
                            val l = currentRect[0] * widthPx
                            val t = currentRect[1] * heightPx
                            val r = currentRect[2] * widthPx
                            val b = currentRect[3] * heightPx
                            val corners = listOf(
                                StudioCropHandle.TOP_LEFT to Offset(l, t),
                                StudioCropHandle.TOP_RIGHT to Offset(r, t),
                                StudioCropHandle.BOTTOM_LEFT to Offset(l, b),
                                StudioCropHandle.BOTTOM_RIGHT to Offset(r, b)
                            )
                            val nearestCorner = corners
                                .minByOrNull { (_, position) -> (point - position).getDistance() }
                                ?.takeIf { (_, position) -> (point - position).getDistance() <= grabRadius }
                                ?.first
                            handle = when {
                                nearestCorner != null -> nearestCorner
                                abs(point.x - l) <= grabRadius && point.y in t..b -> StudioCropHandle.LEFT
                                abs(point.x - r) <= grabRadius && point.y in t..b -> StudioCropHandle.RIGHT
                                abs(point.y - t) <= grabRadius && point.x in l..r -> StudioCropHandle.TOP
                                abs(point.y - b) <= grabRadius && point.x in l..r -> StudioCropHandle.BOTTOM
                                point.x in l..r && point.y in t..b -> StudioCropHandle.MOVE
                                else -> null
                            }
                        },
                        onDragEnd = { handle = null },
                        onDragCancel = { handle = null }
                    ) { _, drag ->
                        val active = handle ?: return@detectDragGestures
                        val l = currentRect[0]
                        val t = currentRect[1]
                        val r = currentRect[2]
                        val b = currentRect[3]
                        val dx = drag.x / widthPx
                        val dy = drag.y / heightPx
                        var nl = l
                        var nt = t
                        var nr = r
                        var nb = b

                        when (active) {
                            StudioCropHandle.MOVE -> {
                                val cw = r - l
                                val ch = b - t
                                nl = (l + dx).coerceIn(0f, 1f - cw)
                                nt = (t + dy).coerceIn(0f, 1f - ch)
                                nr = nl + cw
                                nb = nt + ch
                            }
                            StudioCropHandle.TOP_LEFT -> {
                                nl = (l + dx).coerceIn(0f, r - minSize)
                                nt = (t + dy).coerceIn(0f, b - minSize)
                            }
                            StudioCropHandle.TOP_RIGHT -> {
                                nr = (r + dx).coerceIn(l + minSize, 1f)
                                nt = (t + dy).coerceIn(0f, b - minSize)
                            }
                            StudioCropHandle.BOTTOM_LEFT -> {
                                nl = (l + dx).coerceIn(0f, r - minSize)
                                nb = (b + dy).coerceIn(t + minSize, 1f)
                            }
                            StudioCropHandle.BOTTOM_RIGHT -> {
                                nr = (r + dx).coerceIn(l + minSize, 1f)
                                nb = (b + dy).coerceIn(t + minSize, 1f)
                            }
                            StudioCropHandle.LEFT -> nl = (l + dx).coerceIn(0f, r - minSize)
                            StudioCropHandle.RIGHT -> nr = (r + dx).coerceIn(l + minSize, 1f)
                            StudioCropHandle.TOP -> nt = (t + dy).coerceIn(0f, b - minSize)
                            StudioCropHandle.BOTTOM -> nb = (b + dy).coerceIn(t + minSize, 1f)
                        }

                        val lockRatio = ratio
                        if (lockRatio != null && active != StudioCropHandle.MOVE) {
                            val targetHeight = ((nr - nl) * widthPx / lockRatio) / heightPx
                            when (active) {
                                StudioCropHandle.TOP_LEFT,
                                StudioCropHandle.TOP_RIGHT,
                                StudioCropHandle.TOP -> nt = (nb - targetHeight).coerceIn(0f, nb - minSize)
                                else -> nb = (nt + targetHeight).coerceIn(nt + minSize, 1f)
                            }
                        }

                        if (nr - nl >= minSize && nb - nt >= minSize) {
                            changeListener(nl, nt, nr, nb)
                        }
                    }
                }
        ) {
            val l = left * size.width
            val t = top * size.height
            val r = right * size.width
            val b = bottom * size.height
            val shade = Color.Black.copy(alpha = 0.55f)
            drawRect(shade, Offset(0f, 0f), Size(size.width, t.coerceAtLeast(0f)))
            drawRect(shade, Offset(0f, b), Size(size.width, (size.height - b).coerceAtLeast(0f)))
            drawRect(shade, Offset(0f, t), Size(l.coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))
            drawRect(
                shade,
                Offset(r, t),
                Size((size.width - r).coerceAtLeast(0f), (b - t).coerceAtLeast(0f))
            )

            val gridColor = Color.White.copy(alpha = 0.30f)
            for (i in 1..2) {
                val x = l + (r - l) * i / 3f
                val y = t + (b - t) * i / 3f
                drawLine(gridColor, Offset(x, t), Offset(x, b), strokeWidth = 1.5f)
                drawLine(gridColor, Offset(l, y), Offset(r, y), strokeWidth = 1.5f)
            }

            drawRect(
                color = Color.White,
                topLeft = Offset(l, t),
                size = Size((r - l).coerceAtLeast(1f), (b - t).coerceAtLeast(1f)),
                style = Stroke(width = 2.5f)
            )

            val arm = ((r - l).coerceAtMost(b - t) * 0.18f).coerceIn(20f, 60f)
            val thickness = 7f
            listOf(
                Triple(Offset(l, t), 1f, 1f),
                Triple(Offset(r, t), -1f, 1f),
                Triple(Offset(l, b), 1f, -1f),
                Triple(Offset(r, b), -1f, -1f)
            ).forEach { (corner, sx, sy) ->
                drawLine(Color.White, corner, Offset(corner.x + arm * sx, corner.y), strokeWidth = thickness)
                drawLine(Color.White, corner, Offset(corner.x, corner.y + arm * sy), strokeWidth = thickness)
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Pantalla inicial de seleccion
// ---------------------------------------------------------------------------

@Composable
fun StudioPicker(
    title: String,
    description: String,
    features: List<String>,
    creditCost: Int,
    multiple: Boolean,
    onBack: () -> Unit,
    onGallery: () -> Unit,
    onFiles: () -> Unit,
    onCamera: (() -> Unit)?
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioTheme.Background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.Close, contentDescription = "Volver", tint = StudioTheme.TextPrimary)
            }
            Text(
                title,
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(StudioTheme.Accent.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Image,
                    contentDescription = null,
                    tint = StudioTheme.Accent,
                    modifier = Modifier.size(44.dp)
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(
                if (multiple) "Elige tus imágenes" else "Elige una imagen",
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                description,
                color = StudioTheme.TextSecondary,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(22.dp))

            Button(
                onClick = onGallery,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudioTheme.Accent,
                    contentColor = StudioTheme.OnAccent
                )
            ) {
                Icon(Icons.Rounded.Image, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Abrir galería", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StudioSecondaryButton(
                    label = "Archivos",
                    icon = Icons.Rounded.Folder,
                    onClick = onFiles,
                    modifier = Modifier.weight(1f)
                )
                if (onCamera != null) {
                    StudioSecondaryButton(
                        label = "Cámara",
                        icon = Icons.Rounded.PhotoCamera,
                        onClick = onCamera,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (features.isNotEmpty()) {
                Spacer(Modifier.height(24.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(StudioTheme.Surface)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    Text(
                        "Qué puedes hacer aquí",
                        color = StudioTheme.TextPrimary,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    features.forEach { feature ->
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(
                                Icons.Rounded.Check,
                                contentDescription = null,
                                tint = StudioTheme.Accent,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(Modifier.width(9.dp))
                            Text(
                                feature,
                                color = StudioTheme.TextSecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "La imagen original nunca se modifica. Exportar cuesta $creditCost créditos.",
                color = StudioTheme.TextSecondary,
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
fun StudioSecondaryButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Row(
        modifier = modifier
            .height(50.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(StudioTheme.SurfaceHigh)
            .border(1.dp, StudioTheme.Outline, RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = if (enabled) StudioTheme.TextPrimary else StudioTheme.TextSecondary,
            modifier = Modifier.size(19.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            label,
            color = if (enabled) StudioTheme.TextPrimary else StudioTheme.TextSecondary,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

// ---------------------------------------------------------------------------
// Pantalla de resultado
// ---------------------------------------------------------------------------

data class StudioExportResult(
    val uri: Uri,
    val bytes: Long,
    val width: Int,
    val height: Int,
    val originalBytes: Long,
    val preview: Bitmap?,
    val originalPreview: Bitmap?,
    val locationLabel: String
)

@Composable
fun StudioResultScreen(
    result: StudioExportResult,
    onShare: () -> Unit,
    onOpen: () -> Unit,
    onContinueEditing: () -> Unit,
    onNewImage: () -> Unit,
    onClose: () -> Unit
) {
    val saved = result.originalBytes - result.bytes
    val savedPercent = if (result.originalBytes > 0L) {
        (saved * 100f / result.originalBytes).roundToInt()
    } else 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioTheme.Background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = "Cerrar", tint = StudioTheme.TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "Imagen guardada",
                    color = StudioTheme.TextPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    result.locationLabel,
                    color = StudioTheme.TextSecondary,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(StudioTheme.Canvas)
        ) {
            val preview = result.preview
            val originalPreview = result.originalPreview
            when {
                preview != null && originalPreview != null ->
                    StudioBeforeAfter(originalPreview, preview, Modifier.fillMaxSize())
                preview != null -> StudioCanvas(preview, Modifier.fillMaxSize())
                else -> Box(Modifier.fillMaxSize())
            }
            StudioBadge("${result.width} × ${result.height} px")
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioTheme.Surface)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StudioStat("Antes", ImageStudioOps.readableSize(result.originalBytes), Modifier.weight(1f))
                StudioStat("Ahora", ImageStudioOps.readableSize(result.bytes), Modifier.weight(1f))
                StudioStat(
                    if (saved >= 0) "Ahorro" else "Aumento",
                    if (result.originalBytes > 0L) "${abs(savedPercent)} %" else "—",
                    Modifier.weight(1f),
                    highlight = saved > 0
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StudioSecondaryButton("Compartir", Icons.Rounded.Share, onShare, Modifier.weight(1f))
                StudioSecondaryButton("Abrir", Icons.Rounded.OpenInNew, onOpen, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StudioSecondaryButton("Seguir editando", Icons.Rounded.Refresh, onContinueEditing, Modifier.weight(1f))
                StudioSecondaryButton("Otra imagen", Icons.Rounded.Image, onNewImage, Modifier.weight(1f))
            }
            Button(
                onClick = onClose,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudioTheme.Accent,
                    contentColor = StudioTheme.OnAccent
                )
            ) {
                Text("Listo", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StudioStat(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(StudioTheme.SurfaceHigh)
            .padding(vertical = 10.dp, horizontal = 12.dp)
    ) {
        Text(label, color = StudioTheme.TextSecondary, style = MaterialTheme.typography.labelSmall)
        Text(
            value,
            color = if (highlight) StudioTheme.Accent else StudioTheme.TextPrimary,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1
        )
    }
}

/** Barra de progreso sobre el lienzo mientras se procesa. */
@Composable
fun BoxScope.StudioProgressOverlay(text: String, progress: Float?) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xB305070B)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(StudioTheme.Surface)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text,
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            if (progress == null) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = StudioTheme.Accent,
                    trackColor = StudioTheme.Outline
                )
            } else {
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = StudioTheme.Accent,
                    trackColor = StudioTheme.Outline
                )
            }
            Text(
                "No cierres la aplicación.",
                color = StudioTheme.TextSecondary,
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}

/** Selector de posicion de 3x3 para la marca de agua. */
@Composable
fun StudioPositionGrid(
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(126.dp)
            .height(126.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(StudioTheme.SurfaceHigh)
            .border(1.dp, StudioTheme.Outline, RoundedCornerShape(12.dp))
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        for (row in 0 until 3) {
            Row(
                modifier = Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                for (column in 0 until 3) {
                    val index = row * 3 + column
                    val active = index == selected
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (active) StudioTheme.Accent else StudioTheme.Surface)
                            .clickable { onSelect(index) },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (active) StudioTheme.OnAccent else StudioTheme.Outline)
                        )
                    }
                }
            }
        }
    }
}
