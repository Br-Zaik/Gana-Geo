package com.ganageo.app.tools

import java.math.BigDecimal

/**
 * Datos fiscales y laborales.
 *
 * Todo lo que cambia por ley vive aquí y solo aquí, con su fecha de vigencia y
 * la norma que lo respalda. Cuando en enero cambie la UIT o suba el sueldo
 * mínimo se toca este archivo y el resto de la app se reajusta sola.
 *
 * Revisado en septiembre de 2026. Los valores marcados como REVISAR conviene
 * verificarlos cada año.
 */

data class TaxRate(
    val label: String,
    val percent: BigDecimal,
    val note: String = ""
)

data class CountryTax(
    val code: String,
    val name: String,
    /** IGV en Perú, IVA en la mayoría, ITBIS en República Dominicana, ITBMS en Panamá. */
    val taxName: String,
    val currency: CurrencyInfo,
    val rates: List<TaxRate>
) {
    val defaultRate: TaxRate get() = rates.first()
}

object FiscalData {

    private fun rate(label: String, percent: String, note: String = "") =
        TaxRate(label, BigDecimal(percent), note)

    val countries: List<CountryTax> = listOf(
        CountryTax(
            "PE", "Perú", "IGV", CurrencyInfo.PEN,
            listOf(
                rate("18 %", "18", "16 % IGV + 2 % IPM. Tasa general."),
                rate("10.5 %", "10.5", "MYPE de restaurantes, hoteles y alojamiento turístico (Ley 31556). Verifica su vigencia."),
                rate("0 %", "0", "Exportaciones y operaciones exoneradas o inafectas.")
            )
        ),
        CountryTax(
            "MX", "México", "IVA", CurrencyInfo.MXN,
            listOf(
                rate("16 %", "16", "Tasa general."),
                rate("8 %", "8", "Región fronteriza norte."),
                rate("0 %", "0", "Tasa cero y exentos.")
            )
        ),
        CountryTax(
            "CO", "Colombia", "IVA", CurrencyInfo.COP,
            listOf(rate("19 %", "19", "Tasa general."), rate("5 %", "5"), rate("0 %", "0"))
        ),
        CountryTax("CL", "Chile", "IVA", CurrencyInfo.CLP, listOf(rate("19 %", "19", "Tasa única."))),
        CountryTax(
            "AR", "Argentina", "IVA", CurrencyInfo.ARS,
            listOf(rate("21 %", "21", "Tasa general."), rate("10.5 %", "10.5"), rate("27 %", "27"))
        ),
        CountryTax(
            "ES", "España", "IVA", CurrencyInfo.EUR,
            listOf(
                rate("21 %", "21", "Tipo general."),
                rate("10 %", "10", "Tipo reducido."),
                rate("4 %", "4", "Tipo superreducido.")
            )
        ),
        CountryTax("EC", "Ecuador", "IVA", CurrencyInfo.USD, listOf(rate("15 %", "15"), rate("0 %", "0"))),
        CountryTax("BO", "Bolivia", "IVA", CurrencyInfo.BOB, listOf(rate("13 %", "13"))),
        CountryTax("UY", "Uruguay", "IVA", CurrencyInfo.USD, listOf(rate("22 %", "22"), rate("10 %", "10"))),
        CountryTax("CR", "Costa Rica", "IVA", CurrencyInfo.USD, listOf(rate("13 %", "13"))),
        CountryTax("DO", "Rep. Dominicana", "ITBIS", CurrencyInfo.USD, listOf(rate("18 %", "18"))),
        CountryTax("PA", "Panamá", "ITBMS", CurrencyInfo.USD, listOf(rate("7 %", "7"))),
        CountryTax("PY", "Paraguay", "IVA", CurrencyInfo.USD, listOf(rate("10 %", "10"), rate("5 %", "5"))),
        CountryTax("GT", "Guatemala", "IVA", CurrencyInfo.USD, listOf(rate("12 %", "12")))
    )

    fun country(code: String): CountryTax = countries.firstOrNull { it.code == code } ?: countries.first()

    // ------------------------------------------------------------------
    // Perú 2026
    // ------------------------------------------------------------------

    object Peru {
        const val YEAR = 2026
        const val SOURCE_NOTE = "Valores vigentes en 2026. Revisa cada enero: la UIT y el sueldo mínimo cambian."

        /** Unidad Impositiva Tributaria 2026 (D.S. 301-2025-EF). REVISAR cada diciembre. */
        val UIT: BigDecimal = BigDecimal("5500")

        /** Remuneración Mínima Vital (D.S. 006-2024-TR). REVISAR: hay anuncios de subida. */
        val RMV: BigDecimal = BigDecimal("1130")

        /** Asignación familiar: 10 % de la RMV, para quien tiene hijos menores o estudiando. */
        val ASIGNACION_FAMILIAR: BigDecimal = RMV.multiply(BigDecimal("0.10"))

        /** Retención de renta de cuarta categoría. */
        val RETENCION_CUARTA: BigDecimal = BigDecimal("8")

        /** Los recibos por honorarios de hasta este monto no sufren retención. */
        val TOPE_SIN_RETENCION: BigDecimal = BigDecimal("1500")

        /** Tope anual para pedir suspensión de retenciones de cuarta (R.S. 000390-2025/SUNAT). */
        val SUSPENSION_ANUAL: BigDecimal = BigDecimal("48125")

        /** Tope anual para directores, mandatarios y síndicos. */
        val SUSPENSION_ANUAL_DIRECTORES: BigDecimal = BigDecimal("38500")

        /** Tope mensual de referencia para la suspensión. */
        val SUSPENSION_MENSUAL: BigDecimal = BigDecimal("4010")

        /** Deducción de 7 UIT sobre las rentas de trabajo (art. 46 Ley del IR). */
        val DEDUCCION_7_UIT: BigDecimal = UIT.multiply(BigDecimal("7"))

        /** Deducción adicional de hasta 3 UIT por gastos, se recupera en la declaración anual. */
        val DEDUCCION_ADICIONAL_3_UIT: BigDecimal = UIT.multiply(BigDecimal("3"))

        /** Deducción del 20 % sobre la renta bruta de cuarta, con tope de 24 UIT. */
        val DEDUCCION_CUARTA_PORCENTAJE: BigDecimal = BigDecimal("20")
        val DEDUCCION_CUARTA_TOPE: BigDecimal = UIT.multiply(BigDecimal("24"))

        /** Sistema Nacional de Pensiones: 13 % fijo sobre la remuneración. */
        val ONP: BigDecimal = BigDecimal("13")

        /** Aporte obligatorio a la cuenta individual de la AFP. */
        val AFP_APORTE: BigDecimal = BigDecimal("10")

        /** Prima del seguro de invalidez y sobrevivencia. REVISAR cada trimestre en la SBS. */
        val AFP_PRIMA_SEGURO: BigDecimal = BigDecimal("1.37")

        /** EsSalud lo paga el empleador: NO se descuenta al trabajador. */
        val ESSALUD_EMPLEADOR: BigDecimal = BigDecimal("9")

        /** Bonificación extraordinaria sobre la gratificación (Ley 30334). */
        val BONIFICACION_GRATIFICACION: BigDecimal = BigDecimal("9")
        val BONIFICACION_GRATIFICACION_EPS: BigDecimal = BigDecimal("6.75")

        /** Sobretiempo: 25 % las dos primeras horas del día y 35 % desde la tercera. */
        val HORA_EXTRA_PRIMERAS: BigDecimal = BigDecimal("25")
        val HORA_EXTRA_SIGUIENTES: BigDecimal = BigDecimal("35")
        const val HORAS_PRIMER_TRAMO = 2.0

        /** Recargo mínimo por trabajo nocturno, entre las 22:00 y las 06:00. */
        val RECARGO_NOCTURNO: BigDecimal = BigDecimal("35")

        /** Feriado o descanso semanal trabajado sin descanso sustitutorio. */
        val SOBRETASA_FERIADO: BigDecimal = BigDecimal("100")

        const val JORNADA_HORAS_DIA = 8.0
        const val JORNADA_HORAS_SEMANA = 48.0

        /** Comisiones sobre el sueldo de las AFP. REVISAR: cambian por resolución SBS. */
        val AFP_COMISIONES: List<Pair<String, BigDecimal>> = listOf(
            "Habitat" to BigDecimal("1.47"),
            "Integra" to BigDecimal("1.55"),
            "Prima" to BigDecimal("1.60"),
            "Profuturo" to BigDecimal("1.69")
        )

        /** Escala progresiva anual de renta de trabajo (art. 53 Ley del IR), en UIT. */
        data class TramoRenta(val hastaUit: BigDecimal?, val tasa: BigDecimal)

        val TRAMOS_RENTA: List<TramoRenta> = listOf(
            TramoRenta(BigDecimal("5"), BigDecimal("8")),
            TramoRenta(BigDecimal("20"), BigDecimal("14")),
            TramoRenta(BigDecimal("35"), BigDecimal("17")),
            TramoRenta(BigDecimal("45"), BigDecimal("20")),
            TramoRenta(null, BigDecimal("30"))
        )

        /** Feriados nacionales 2026 (día del mes a nombre). REVISAR cada año. */
        val FERIADOS_2026: List<Pair<String, String>> = listOf(
            "01-01" to "Año Nuevo",
            "04-02" to "Jueves Santo",
            "04-03" to "Viernes Santo",
            "05-01" to "Día del Trabajo",
            "06-07" to "Día de la Bandera",
            "06-29" to "San Pedro y San Pablo",
            "07-23" to "Día de la Fuerza Aérea",
            "07-28" to "Fiestas Patrias",
            "07-29" to "Fiestas Patrias",
            "08-06" to "Batalla de Junín",
            "08-30" to "Santa Rosa de Lima",
            "10-08" to "Combate de Angamos",
            "11-01" to "Todos los Santos",
            "12-08" to "Inmaculada Concepción",
            "12-09" to "Batalla de Ayacucho",
            "12-25" to "Navidad"
        )
    }

    // ------------------------------------------------------------------
    // Validación de documentos
    // ------------------------------------------------------------------

    /**
     * Valida el dígito verificador del RUC por módulo 11.
     *
     * Ojo: esto solo comprueba que la aritmética del número cuadre, o sea que
     * atrapa errores de tecleo. NO confirma que el RUC exista ni que esté activo:
     * para eso hace falta consultar a SUNAT, y la app no tiene esa conexión.
     */
    fun isValidRuc(raw: String): Boolean {
        val ruc = raw.trim().filter(Char::isDigit)
        if (ruc.length != 11) return false
        val prefix = ruc.substring(0, 2)
        if (prefix !in listOf("10", "15", "16", "17", "20")) return false
        val weights = intArrayOf(5, 4, 3, 2, 7, 6, 5, 4, 3, 2)
        var sum = 0
        for (i in 0 until 10) {
            sum += (ruc[i] - '0') * weights[i]
        }
        val remainder = sum % 11
        val expected = when (val candidate = 11 - remainder) {
            10 -> 0
            11 -> 1
            else -> candidate
        }
        return expected == (ruc[10] - '0')
    }

    fun rucType(raw: String): String {
        val ruc = raw.trim().filter(Char::isDigit)
        return when {
            ruc.length != 11 -> "—"
            ruc.startsWith("10") -> "Persona natural con negocio"
            ruc.startsWith("15") || ruc.startsWith("16") || ruc.startsWith("17") -> "No domiciliado o caso especial"
            ruc.startsWith("20") -> "Persona jurídica (empresa)"
            else -> "Prefijo no reconocido"
        }
    }

    fun isValidDni(raw: String): Boolean {
        val dni = raw.trim().filter(Char::isDigit)
        return dni.length == 8
    }

    /** Leyenda obligatoria: la app no está integrada al sistema de SUNAT. */
    const val AVISO_NO_COMPROBANTE =
        "Este documento no es un comprobante de pago electrónico válido ante SUNAT. " +
            "Sirve como cotización o registro interno."

    const val AVISO_CALCULO_REFERENCIAL =
        "Cálculo referencial. No reemplaza a la liquidación oficial de tu empleador ni a la asesoría de un contador."
}
