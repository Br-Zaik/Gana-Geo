package com.ganageo.app.ui.tools

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.HistogramBin
import com.ganageo.app.tools.MathEngine
import com.ganageo.app.tools.QuartileMethod
import com.ganageo.app.tools.RegressionResult
import com.ganageo.app.tools.StatsLab
import com.ganageo.app.tools.StatsSummary
import kotlin.math.abs
import kotlin.math.max

/**
 * Estadística descriptiva.
 *
 * Dos decisiones de fondo que casi ninguna calculadora deja claras: los cuartiles
 * cambian según el método y la desviación no es la misma para una muestra que
 * para toda la población. Aquí las dos cosas se eligen y se muestran con nombre
 * propio en vez de dar un número suelto que el estudiante no sabe justificar.
 */
@Composable
fun StatisticsScreen(onBack: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var rawData by rememberSaveable { mutableStateOf("12, 15, 15, 18, 21, 24, 24, 24, 30, 45") }
    var method by rememberSaveable { mutableIntStateOf(QuartileMethod.INCLUSIVE.ordinal) }
    var pairedData by rememberSaveable {
        mutableStateOf("1 2.1\n2 4.3\n3 5.8\n4 8.2\n5 9.9")
    }
    var binsText by rememberSaveable { mutableStateOf("") }

    val quartileMethod = QuartileMethod.entries[method]
    val parsed = remember(rawData) { runCatching { StatsLab.parseValues(rawData) } }
    val summary: StatsSummary? = remember(parsed, quartileMethod) {
        parsed.getOrNull()?.let { runCatching { StatsLab.summarize(it, quartileMethod) }.getOrNull() }
    }
    val regression: Result<RegressionResult>? = remember(pairedData, tab) {
        if (tab != 2) null else runCatching { StatsLab.linearRegression(StatsLab.parsePairs(pairedData)) }
    }

    ScienceShell(
        title = "Estadística descriptiva",
        subtitle = summary?.let { "${it.count} datos analizados" } ?: "Escribe o pega tus datos",
        onBack = onBack
    ) {
        StudioTabs(listOf("Datos", "Gráficos", "Regresión"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Datos") {
                    ScienceTextArea(
                        value = rawData,
                        onValueChange = { rawData = it },
                        label = "Valores",
                        placeholder = "Separa con comas, espacios o saltos de línea",
                        minHeight = 120
                    )
                    StudioHint("Puedes pegar una columna copiada desde una hoja de cálculo.")
                    StudioChipRow {
                        StudioChip("Limpiar", false, onClick = { rawData = "" })
                        StudioChip("Ejemplo notas", false, onClick = {
                            rawData = "4.5, 5.0, 5.5, 6.0, 6.0, 6.5, 7.0, 3.8, 6.2, 5.9"
                        })
                        StudioChip("Ejemplo alturas", false, onClick = {
                            rawData = "163 170 158 175 168 172 181 165 169 174 160 177"
                        })
                    }
                }

                ScienceCard("Método de los cuartiles") {
                    StudioChipRow {
                        QuartileMethod.entries.forEachIndexed { index, entry ->
                            StudioChip(entry.label, method == index, onClick = { method = index })
                        }
                    }
                    StudioHint(quartileMethod.description)
                }

                parsed.exceptionOrNull()?.let { ScienceError(it.message ?: "Datos inválidos.") }

                summary?.let { data ->
                    ScienceResult(
                        headline = "Media = ${MathEngine.formatNumber(data.mean, 4)}",
                        caption = "Mediana ${MathEngine.formatNumber(data.median, 4)} · " +
                            "Desviación muestral ${MathEngine.formatNumber(data.deviationSample, 4)}",
                        onCopy = { clipboard.setText(androidx.compose.ui.text.AnnotatedString(summaryText(data))) }
                    )

                    ScienceCard("Medidas de centro") {
                        ScienceRow("Cantidad de datos (n)", data.count.toString())
                        ScienceRow("Suma", MathEngine.formatNumber(data.sum, 4))
                        ScienceRow("Media aritmética", MathEngine.formatNumber(data.mean, 4), highlight = true)
                        ScienceRow("Mediana", MathEngine.formatNumber(data.median, 4))
                        ScienceRow(
                            "Moda",
                            if (data.modes.isEmpty()) "no hay (todos distintos)"
                            else data.modes.joinToString(", ") { MathEngine.formatNumber(it, 4) }
                        )
                    }

                    ScienceCard("Dispersión") {
                        ScienceRow("Mínimo", MathEngine.formatNumber(data.minimum, 4))
                        ScienceRow("Máximo", MathEngine.formatNumber(data.maximum, 4))
                        ScienceRow("Rango", MathEngine.formatNumber(data.range, 4))
                        ScienceRow("Varianza muestral (n−1)", MathEngine.formatNumber(data.varianceSample, 4))
                        ScienceRow(
                            "Desviación muestral (n−1)",
                            MathEngine.formatNumber(data.deviationSample, 4),
                            highlight = true
                        )
                        ScienceRow("Varianza poblacional (n)", MathEngine.formatNumber(data.variancePopulation, 4))
                        ScienceRow("Desviación poblacional (n)", MathEngine.formatNumber(data.deviationPopulation, 4))
                        ScienceRow(
                            "Coeficiente de variación",
                            if (data.coefficientOfVariation.isNaN()) "—"
                            else "${MathEngine.formatNumber(data.coefficientOfVariation, 2)} %"
                        )
                        StudioHint(
                            "Usa la muestral (n−1) cuando tus datos son una muestra de algo mayor, " +
                                "y la poblacional (n) cuando son absolutamente todos los casos."
                        )
                    }

                    ScienceCard("Posición y forma") {
                        ScienceRow("Q1 (25 %)", MathEngine.formatNumber(data.q1, 4))
                        ScienceRow("Q2 (mediana)", MathEngine.formatNumber(data.median, 4))
                        ScienceRow("Q3 (75 %)", MathEngine.formatNumber(data.q3, 4))
                        ScienceRow("Rango intercuartílico", MathEngine.formatNumber(data.iqr, 4))
                        ScienceRow(
                            "Asimetría",
                            MathEngine.formatNumber(data.skewness, 3) + when {
                                data.skewness > 0.5 -> "  (cola a la derecha)"
                                data.skewness < -0.5 -> "  (cola a la izquierda)"
                                else -> "  (casi simétrica)"
                            }
                        )
                        ScienceRow(
                            "Valores atípicos",
                            if (data.outliers.isEmpty()) "ninguno"
                            else data.outliers.joinToString(", ") { MathEngine.formatNumber(it, 3) }
                        )
                        StudioHint("Se marca como atípico lo que queda a más de 1,5 veces el rango intercuartílico de Q1 o Q3.")
                    }
                }
            }

            1 -> {
                if (summary == null) {
                    ScienceError("Primero escribe datos válidos en la pestaña «Datos».")
                } else {
                    ScienceCard("Histograma") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ScienceNumberField(
                                binsText,
                                { binsText = it },
                                "Clases (vacío = automático)",
                                Modifier.fillMaxWidth()
                            )
                        }
                        val bins = binsText.trim().toIntOrNull()?.coerceIn(2, 30)
                            ?: StatsLab.suggestedBins(summary.count)
                        val histogram = remember(summary, bins) { StatsLab.histogram(summary.sorted, bins) }
                        HistogramChart(histogram)
                        StudioHint("Con $bins clases. Por defecto se usa la regla de Sturges.")
                    }

                    ScienceCard("Diagrama de caja") {
                        BoxPlotChart(summary)
                        StudioHint("La caja va de Q1 a Q3, la línea es la mediana y los puntos son los valores atípicos.")
                    }
                }
            }

            else -> {
                ScienceCard("Pares de datos") {
                    ScienceTextArea(
                        value = pairedData,
                        onValueChange = { pairedData = it },
                        label = "x  y  (uno por línea)",
                        placeholder = "1 2.1\n2 4.3\n3 5.8",
                        minHeight = 130
                    )
                    StudioHint("Pega dos columnas desde una hoja de cálculo: la primera es x y la segunda y.")
                }

                regression?.exceptionOrNull()?.let { ScienceError(it.message ?: "Datos inválidos.") }
                regression?.getOrNull()?.let { result ->
                    val points = remember(pairedData) {
                        runCatching { StatsLab.parsePairs(pairedData) }.getOrDefault(emptyList())
                    }
                    ScienceResult(
                        headline = result.equation,
                        caption = "r = ${MathEngine.formatNumber(result.correlation, 4)} · " +
                            "R² = ${MathEngine.formatNumber(result.determination, 4)}"
                    )
                    ScienceCard("Nube de puntos y recta de ajuste") {
                        ScatterChart(points, result)
                    }
                    ScienceCard("Interpretación") {
                        ScienceRow("Pendiente", MathEngine.formatNumber(result.slope, 5))
                        ScienceRow("Ordenada al origen", MathEngine.formatNumber(result.intercept, 5))
                        ScienceRow(
                            "Fuerza de la relación",
                            when {
                                abs(result.correlation) > 0.9 -> "Muy fuerte"
                                abs(result.correlation) > 0.7 -> "Fuerte"
                                abs(result.correlation) > 0.4 -> "Moderada"
                                else -> "Débil"
                            },
                            highlight = true
                        )
                        ScienceRow(
                            "Sentido",
                            if (result.slope >= 0) "Directa: al crecer x, crece y"
                            else "Inversa: al crecer x, decrece y"
                        )
                        StudioHint(
                            "R² indica qué parte de la variación de y explica la recta. " +
                                "Que dos variables estén correlacionadas no significa que una cause la otra."
                        )
                    }
                }
            }
        }
    }
}

private fun summaryText(data: StatsSummary): String = buildString {
    appendLine("n = ${data.count}")
    appendLine("Media = ${MathEngine.formatNumber(data.mean, 6)}")
    appendLine("Mediana = ${MathEngine.formatNumber(data.median, 6)}")
    appendLine("Q1 = ${MathEngine.formatNumber(data.q1, 6)}")
    appendLine("Q3 = ${MathEngine.formatNumber(data.q3, 6)}")
    appendLine("Desviación muestral = ${MathEngine.formatNumber(data.deviationSample, 6)}")
    append("Desviación poblacional = ${MathEngine.formatNumber(data.deviationPopulation, 6)}")
}

@Composable
private fun HistogramChart(bins: List<HistogramBin>) {
    if (bins.isEmpty()) return
    val maxCount = bins.maxOf { it.count }.coerceAtLeast(1)
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(StudioTheme.Canvas)
            .padding(8.dp)
    ) {
        val labelPaint = Paint().apply {
            color = android.graphics.Color.parseColor("#7A8AA5")
            textSize = 22f
            isAntiAlias = true
        }
        val bottom = size.height - 26f
        val barWidth = size.width / bins.size
        bins.forEachIndexed { index, bin ->
            val height = if (maxCount == 0) 0f else (bin.count.toFloat() / maxCount) * (bottom - 10f)
            val left = index * barWidth + barWidth * 0.12f
            val width = barWidth * 0.76f
            drawRect(
                color = Color(0xFFB7FF00).copy(alpha = 0.85f),
                topLeft = Offset(left, bottom - height),
                size = Size(width, height)
            )
            if (bin.count > 0) {
                drawContext.canvas.nativeCanvas.drawText(
                    bin.count.toString(),
                    left + width / 2 - 6f,
                    bottom - height - 6f,
                    labelPaint
                )
            }
            if (index == 0 || index == bins.lastIndex) {
                drawContext.canvas.nativeCanvas.drawText(
                    MathEngine.formatNumber(if (index == 0) bin.from else bin.to, 2),
                    if (index == 0) 0f else size.width - 70f,
                    size.height - 4f,
                    labelPaint
                )
            }
        }
        drawLine(
            Color(0xFF5C6B85),
            Offset(0f, bottom),
            Offset(size.width, bottom),
            strokeWidth = 2f
        )
    }
}

@Composable
private fun BoxPlotChart(data: StatsSummary) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(StudioTheme.Canvas)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        val lowerFence = data.q1 - 1.5 * data.iqr
        val upperFence = data.q3 + 1.5 * data.iqr
        val whiskerLow = data.sorted.firstOrNull { it >= lowerFence } ?: data.minimum
        val whiskerHigh = data.sorted.lastOrNull { it <= upperFence } ?: data.maximum

        val low = minOf(data.minimum, whiskerLow)
        val high = maxOf(data.maximum, whiskerHigh)
        val span = (high - low).takeIf { abs(it) > 1e-9 } ?: 1.0
        fun toX(value: Double) = ((value - low) / span * size.width).toFloat()

        val centerY = size.height / 2
        val boxHeight = size.height * 0.42f
        val accent = Color(0xFFB7FF00)

        // Bigotes
        drawLine(Color(0xFF7A8AA5), Offset(toX(whiskerLow), centerY), Offset(toX(data.q1), centerY), strokeWidth = 2f)
        drawLine(Color(0xFF7A8AA5), Offset(toX(data.q3), centerY), Offset(toX(whiskerHigh), centerY), strokeWidth = 2f)
        listOf(whiskerLow, whiskerHigh).forEach { value ->
            drawLine(
                Color(0xFF7A8AA5),
                Offset(toX(value), centerY - boxHeight / 3),
                Offset(toX(value), centerY + boxHeight / 3),
                strokeWidth = 2f
            )
        }

        // Caja
        val boxLeft = toX(data.q1)
        val boxRight = toX(data.q3)
        drawRect(
            color = accent.copy(alpha = 0.20f),
            topLeft = Offset(boxLeft, centerY - boxHeight / 2),
            size = Size(max(2f, boxRight - boxLeft), boxHeight)
        )
        drawRect(
            color = accent,
            topLeft = Offset(boxLeft, centerY - boxHeight / 2),
            size = Size(max(2f, boxRight - boxLeft), boxHeight),
            style = Stroke(width = 2f)
        )
        drawLine(
            accent,
            Offset(toX(data.median), centerY - boxHeight / 2),
            Offset(toX(data.median), centerY + boxHeight / 2),
            strokeWidth = 3.5f
        )

        // Atípicos
        data.outliers.forEach { value ->
            drawCircle(Color(0xFFFF7AB6), radius = 5f, center = Offset(toX(value), centerY))
        }

        val labelPaint = Paint().apply {
            color = android.graphics.Color.parseColor("#7A8AA5")
            textSize = 22f
            isAntiAlias = true
        }
        drawContext.canvas.nativeCanvas.drawText(
            MathEngine.formatNumber(low, 2), 0f, size.height, labelPaint
        )
        drawContext.canvas.nativeCanvas.drawText(
            MathEngine.formatNumber(high, 2), size.width - 70f, size.height, labelPaint
        )
    }
}

@Composable
private fun ScatterChart(points: List<Pair<Double, Double>>, regression: RegressionResult) {
    if (points.isEmpty()) return
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(StudioTheme.Canvas)
            .padding(12.dp)
    ) {
        val xs = points.map { it.first }
        val ys = points.map { it.second }
        val xLow = xs.min()
        val xHigh = xs.max()
        val yLow = ys.min()
        val yHigh = ys.max()
        val xSpan = (xHigh - xLow).takeIf { abs(it) > 1e-9 } ?: 1.0
        val ySpan = (yHigh - yLow).takeIf { abs(it) > 1e-9 } ?: 1.0
        val marginX = xSpan * 0.08
        val marginY = ySpan * 0.12

        fun toX(value: Double) = (((value - (xLow - marginX)) / (xSpan + 2 * marginX)) * size.width).toFloat()
        fun toY(value: Double) =
            (size.height - ((value - (yLow - marginY)) / (ySpan + 2 * marginY)) * size.height).toFloat()

        // Recta de ajuste
        val leftX = xLow - marginX
        val rightX = xHigh + marginX
        drawLine(
            Color(0xFFFFC542),
            Offset(toX(leftX), toY(regression.slope * leftX + regression.intercept)),
            Offset(toX(rightX), toY(regression.slope * rightX + regression.intercept)),
            strokeWidth = 3f
        )

        points.forEach { (x, y) ->
            drawCircle(Color(0xFFB7FF00), radius = 6f, center = Offset(toX(x), toY(y)))
        }
    }
}
