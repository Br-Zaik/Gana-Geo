package com.ganageo.app.ui.tools

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.WorkProfile
import com.ganageo.app.data.WorkProfileStore
import com.ganageo.app.tools.CurrencyInfo
import com.ganageo.app.tools.FiscalData
import com.ganageo.app.tools.Money
import com.ganageo.app.tools.OfficePdf
import com.ganageo.app.tools.QuoteEngine
import com.ganageo.app.tools.QuoteItem
import com.ganageo.app.tools.QuoteTotals
import com.ganageo.app.tools.TaxMode
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

private class QuoteLineState(
    description: String = "",
    quantity: String = "1",
    price: String = "",
    discount: String = ""
) {
    var description by mutableStateOf(description)
    var quantity by mutableStateOf(quantity)
    var price by mutableStateOf(price)
    var discount by mutableStateOf(discount)
}

/**
 * Cotización con impuesto.
 *
 * Dos cosas que casi ninguna calculadora hace bien y aquí sí: el precio se puede
 * escribir con el impuesto ya incluido (y se desagrega dividiendo, no restando
 * el porcentaje), y el impuesto se calcula una sola vez sobre el total, para que
 * la suma de los ítems cuadre exactamente con el total del documento.
 */
@Composable
fun QuoteIgvScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { WorkProfileStore(context) }
    val profile by store.profile.collectAsState(initial = WorkProfile())

    var tab by rememberSaveable { mutableIntStateOf(0) }
    val lines = remember { mutableStateListOf(QuoteLineState("Servicio o producto", "1", "100")) }

    var countryCode by rememberSaveable { mutableStateOf("PE") }
    var taxPercentText by rememberSaveable { mutableStateOf("18") }
    var taxModeIndex by rememberSaveable { mutableIntStateOf(0) }
    var globalDiscount by rememberSaveable { mutableStateOf("") }
    var currencyCode by rememberSaveable { mutableStateOf("PEN") }

    var clientName by rememberSaveable { mutableStateOf("") }
    var clientDocument by rememberSaveable { mutableStateOf("") }
    var clientAddress by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }

    var businessName by rememberSaveable { mutableStateOf("") }
    var businessDocument by rememberSaveable { mutableStateOf("") }
    var businessContact by rememberSaveable { mutableStateOf("") }
    var series by rememberSaveable { mutableStateOf("") }
    var number by rememberSaveable { mutableStateOf("") }
    var validityDays by rememberSaveable { mutableStateOf("") }
    var paymentTerms by rememberSaveable { mutableStateOf("") }
    var loadedProfile by rememberSaveable { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    // La primera vez se cargan los datos guardados del negocio.
    androidx.compose.runtime.LaunchedEffect(profile) {
        if (loadedProfile) return@LaunchedEffect
        if (profile.businessName.isNotBlank() || profile.taxId.isNotBlank()) {
            businessName = profile.businessName
            businessDocument = profile.taxId
            businessContact = listOf(profile.phone, profile.email, profile.address)
                .filter { it.isNotBlank() }.joinToString(" · ")
        }
        countryCode = profile.countryCode
        currencyCode = profile.currencyCode
        taxPercentText = profile.taxPercent
        series = profile.quoteSeries
        number = profile.nextQuoteNumber.toString()
        validityDays = profile.quoteValidityDays.toString()
        paymentTerms = profile.paymentTerms
        loadedProfile = true
    }

    val country = FiscalData.country(countryCode)
    val currency = CurrencyInfo.byCode(currencyCode)
    val taxMode = TaxMode.entries[taxModeIndex.coerceIn(0, 1)]
    val taxPercent = Money.parseOrNull(taxPercentText) ?: BigDecimal("18")

    val items = lines.mapNotNull { line ->
        val quantity = Money.parseOrNull(line.quantity) ?: return@mapNotNull null
        val price = Money.parseOrNull(line.price) ?: return@mapNotNull null
        if (quantity.signum() <= 0) return@mapNotNull null
        QuoteItem(
            description = line.description.ifBlank { "Ítem" },
            quantity = quantity,
            unitPrice = price,
            discountPercent = Money.parseOrNull(line.discount) ?: BigDecimal.ZERO
        )
    }

    val totals: QuoteTotals = QuoteEngine.compute(
        items = items,
        taxPercent = taxPercent,
        mode = taxMode,
        globalDiscountPercent = Money.parseOrNull(globalDiscount) ?: BigDecimal.ZERO,
        taxName = country.taxName,
        currency = currency
    )

    val documentNumber = QuoteEngine.documentNumber(series, number.toIntOrNull() ?: 1)
    val today = remember { SimpleDateFormat("dd/MM/yyyy", Locale("es", "PE")).format(Date()) }

    fun plainText(): String = buildString {
        appendLine("COTIZACIÓN $documentNumber")
        appendLine("Fecha: $today")
        if (businessName.isNotBlank()) appendLine("De: $businessName${if (businessDocument.isNotBlank()) " · $businessDocument" else ""}")
        if (clientName.isNotBlank()) appendLine("Para: $clientName${if (clientDocument.isNotBlank()) " · $clientDocument" else ""}")
        appendLine()
        totals.lines.forEach { line ->
            appendLine(
                "${Money.formatQuantity(line.item.quantity)} x ${line.item.description} — " +
                    Money.format(line.netAmount, currency)
            )
        }
        appendLine()
        appendLine("Valor de venta: ${Money.format(totals.base, currency)}")
        appendLine("${country.taxName} ${Money.formatPercent(taxPercent)}: ${Money.format(totals.tax, currency)}")
        appendLine("TOTAL: ${Money.format(totals.total, currency)}")
        appendLine("Son: ${totals.amountInWords}")
        val days = validityDays.toIntOrNull()
        if (days != null) appendLine("Validez de la oferta: $days días")
        if (paymentTerms.isNotBlank()) appendLine("Condiciones de pago: $paymentTerms")
        if (notes.isNotBlank()) appendLine("Notas: $notes")
        appendLine()
        append(FiscalData.AVISO_NO_COMPROBANTE)
    }

    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            runCatching {
                OfficePdf.write(context, uri) {
                    footerNote(FiscalData.AVISO_NO_COMPROBANTE)
                    title("COTIZACIÓN $documentNumber")
                    subtitle("Fecha: $today")
                    spacer(6f)
                    if (businessName.isNotBlank()) {
                        section("Emisor")
                        paragraph(businessName, bold = true)
                        if (businessDocument.isNotBlank()) paragraph("RUC / ID: $businessDocument")
                        if (businessContact.isNotBlank()) paragraph(businessContact, muted = true)
                    }
                    if (clientName.isNotBlank()) {
                        section("Cliente")
                        paragraph(clientName, bold = true)
                        if (clientDocument.isNotBlank()) paragraph("RUC / DNI: $clientDocument")
                        if (clientAddress.isNotBlank()) paragraph(clientAddress, muted = true)
                    }
                    section("Detalle")
                    table(
                        columns = listOf(
                            OfficePdf.Column("Descripción", 4f),
                            OfficePdf.Column("Cant.", 1f, OfficePdf.Align.RIGHT),
                            OfficePdf.Column("P. unit.", 1.4f, OfficePdf.Align.RIGHT),
                            OfficePdf.Column("Importe", 1.6f, OfficePdf.Align.RIGHT)
                        ),
                        rows = totals.lines.map { line ->
                            listOf(
                                line.item.description,
                                Money.formatQuantity(line.item.quantity),
                                Money.format(line.item.unitPrice, currency, withSymbol = false),
                                Money.format(line.netAmount, currency, withSymbol = false)
                            )
                        }
                    )
                    spacer(10f)
                    if (totals.lineDiscounts.signum() > 0) {
                        keyValue("Descuentos por ítem", Money.format(totals.lineDiscounts, currency))
                    }
                    if (totals.globalDiscount.signum() > 0) {
                        keyValue("Descuento global", Money.format(totals.globalDiscount, currency))
                    }
                    keyValue("Valor de venta", Money.format(totals.base, currency))
                    keyValue(
                        "${country.taxName} ${Money.formatPercent(taxPercent)}",
                        Money.format(totals.tax, currency)
                    )
                    keyValue("TOTAL", Money.format(totals.total, currency), bold = true)
                    spacer(4f)
                    paragraph("Son: ${totals.amountInWords}", muted = true)
                    section("Condiciones")
                    validityDays.toIntOrNull()?.let { paragraph("Validez de la oferta: $it días calendario.") }
                    if (paymentTerms.isNotBlank()) paragraph("Forma de pago: $paymentTerms")
                    if (notes.isNotBlank()) paragraph(notes)
                    spacer(6f)
                    paragraph(FiscalData.AVISO_NO_COMPROBANTE, muted = true)
                }
                store.consumeQuoteNumber()
            }.onSuccess {
                message = "Cotización exportada. El correlativo avanzó al siguiente número."
                number = ((number.toIntOrNull() ?: 1) + 1).toString()
            }.onFailure {
                message = it.message ?: "No se pudo generar el PDF."
            }
        }
    }

    ScienceShell(
        title = "Cotización e ${country.taxName}",
        subtitle = "$documentNumber · ${Money.format(totals.total, currency)}",
        onBack = onBack,
        trailing = {
            IconButton(onClick = {
                copyToClipboard(context, "Cotización", plainText())
                message = "Cotización copiada al portapapeles."
            }) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = "Copiar", tint = StudioTheme.TextPrimary)
            }
        }
    ) {
        StudioTabs(listOf("Ítems", "Impuesto", "Cliente", "Emisor"), tab) { tab = it }

        when (tab) {
            0 -> {
                lines.forEachIndexed { index, line ->
                    ScienceCard("Ítem ${index + 1}") {
                        StudioTextField(
                            value = line.description,
                            onValueChange = { line.description = it },
                            label = "Descripción",
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ScienceNumberField(line.quantity, { line.quantity = it }, "Cantidad", Modifier.weight(1f))
                            ScienceNumberField(line.price, { line.price = it }, "P. unitario", Modifier.weight(1.2f))
                            ScienceNumberField(line.discount, { line.discount = it }, "Dscto. %", Modifier.weight(0.9f))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Importe: " + Money.format(
                                    totals.lines.getOrNull(index)?.netAmount ?: BigDecimal.ZERO,
                                    currency
                                ),
                                color = StudioTheme.Accent,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                            if (lines.size > 1) {
                                IconButton(onClick = { lines.removeAt(index) }) {
                                    Icon(
                                        Icons.Rounded.Delete,
                                        contentDescription = "Quitar ítem",
                                        tint = StudioTheme.TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
                WorkActionButton("Agregar ítem", { lines.add(QuoteLineState()) }, Icons.Rounded.Add)
                ScienceNumberField(
                    globalDiscount,
                    { globalDiscount = it },
                    "Descuento global %",
                    Modifier.fillMaxWidth()
                )
            }

            1 -> {
                ScienceCard("País e impuesto") {
                    StudioChipRow {
                        FiscalData.countries.forEach { entry ->
                            StudioChip(
                                label = entry.name,
                                active = countryCode == entry.code,
                                onClick = {
                                    countryCode = entry.code
                                    taxPercentText = entry.defaultRate.percent.toPlainString()
                                    currencyCode = entry.currency.code
                                },
                                caption = entry.taxName
                            )
                        }
                    }
                    StudioLabel("Tasa de ${country.taxName}")
                    StudioChipRow {
                        country.rates.forEach { rate ->
                            StudioChip(
                                label = rate.label,
                                active = taxPercentText == rate.percent.toPlainString(),
                                onClick = { taxPercentText = rate.percent.toPlainString() }
                            )
                        }
                    }
                    ScienceNumberField(taxPercentText, { taxPercentText = it }, "Tasa %", Modifier.fillMaxWidth())
                    country.rates.firstOrNull { it.percent.toPlainString() == taxPercentText }?.note
                        ?.takeIf { it.isNotBlank() }?.let { StudioHint(it) }
                }

                ScienceCard("Cómo escribes los precios") {
                    StudioChipRow {
                        TaxMode.entries.forEachIndexed { index, mode ->
                            StudioChip(mode.label, taxModeIndex == index, onClick = { taxModeIndex = index })
                        }
                    }
                    StudioHint(taxMode.hint)
                    StudioHint(
                        "Cuando el precio ya incluye el impuesto, la base se obtiene dividiendo el total " +
                            "entre 1 más la tasa, no restándole el porcentaje. Con ${Money.formatPercent(taxPercent)}: " +
                            "un precio de 118 tiene base 100 e impuesto 18."
                    )
                }

                ScienceCard("Moneda") {
                    StudioChipRow {
                        CurrencyInfo.all.forEach { entry ->
                            StudioChip(
                                label = "${entry.symbol} ${entry.code}",
                                active = currencyCode == entry.code,
                                onClick = { currencyCode = entry.code }
                            )
                        }
                    }
                }
            }

            2 -> {
                ScienceCard("Datos del cliente") {
                    StudioTextField(clientName, { clientName = it }, "Nombre o razón social", modifier = Modifier.fillMaxWidth())
                    StudioTextField(clientDocument, { clientDocument = it }, "RUC o DNI", modifier = Modifier.fillMaxWidth())
                    if (clientDocument.isNotBlank()) {
                        val digits = clientDocument.filter(Char::isDigit)
                        when {
                            digits.length == 11 -> {
                                if (FiscalData.isValidRuc(digits)) {
                                    StudioHint("RUC con dígito verificador correcto · ${FiscalData.rucType(digits)}")
                                } else {
                                    ScienceError("El dígito verificador del RUC no cuadra. Revisa el número.")
                                }
                            }
                            digits.length == 8 -> StudioHint("DNI de 8 dígitos.")
                            else -> StudioHint("El RUC tiene 11 dígitos y el DNI 8.")
                        }
                    }
                    StudioTextField(clientAddress, { clientAddress = it }, "Dirección", modifier = Modifier.fillMaxWidth())
                }
                ScienceCard("Condiciones") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioTextField(series, { series = it }, "Serie", modifier = Modifier.weight(1f))
                        ScienceNumberField(number, { number = it }, "Número", Modifier.weight(1f))
                    }
                    ScienceNumberField(validityDays, { validityDays = it }, "Validez en días", Modifier.fillMaxWidth())
                    StudioTextField(paymentTerms, { paymentTerms = it }, "Forma de pago", modifier = Modifier.fillMaxWidth())
                    StudioTextField(notes, { notes = it }, "Notas", modifier = Modifier.fillMaxWidth())
                }
            }

            else -> {
                ScienceCard("Tus datos") {
                    StudioTextField(businessName, { businessName = it }, "Nombre o razón social", modifier = Modifier.fillMaxWidth())
                    StudioTextField(businessDocument, { businessDocument = it }, "Tu RUC", modifier = Modifier.fillMaxWidth())
                    if (businessDocument.filter(Char::isDigit).length == 11 &&
                        !FiscalData.isValidRuc(businessDocument)
                    ) {
                        ScienceError("Revisa tu RUC: el dígito verificador no cuadra.")
                    }
                    StudioTextField(businessContact, { businessContact = it }, "Teléfono, correo y dirección", modifier = Modifier.fillMaxWidth())
                    WorkActionButton("Guardar mis datos", {
                        scope.launch {
                            store.save(
                                WorkProfile(
                                    businessName = businessName,
                                    taxId = businessDocument,
                                    address = "",
                                    phone = businessContact,
                                    email = "",
                                    countryCode = countryCode,
                                    currencyCode = currencyCode,
                                    taxPercent = taxPercentText,
                                    quoteSeries = series,
                                    nextQuoteNumber = number.toIntOrNull() ?: 1,
                                    quoteValidityDays = validityDays.toIntOrNull() ?: 15,
                                    paymentTerms = paymentTerms
                                )
                            )
                            message = "Datos guardados. La próxima cotización ya los trae puestos."
                        }
                    }, Icons.Rounded.Save)
                    StudioHint("Se guardan solo en este teléfono. No se envían a ningún servidor.")
                }
            }
        }

        WorkTotals(
            rows = buildList {
                add("Subtotal bruto" to Money.format(totals.gross, currency))
                if (totals.lineDiscounts.signum() > 0) {
                    add("Descuentos por ítem" to "− " + Money.format(totals.lineDiscounts, currency))
                }
                if (totals.globalDiscount.signum() > 0) {
                    add("Descuento global" to "− " + Money.format(totals.globalDiscount, currency))
                }
                add("Valor de venta" to Money.format(totals.base, currency))
                add("${country.taxName} ${Money.formatPercent(taxPercent)}" to Money.format(totals.tax, currency))
            },
            total = "Total a pagar" to Money.format(totals.total, currency),
            note = "Son: ${totals.amountInWords}"
        )

        WorkActionButton(
            "Exportar cotización en PDF",
            { pdfLauncher.launch("${safeFileName(documentNumber, "cotizacion")}.pdf") },
            Icons.Rounded.PictureAsPdf,
            enabled = items.isNotEmpty()
        )

        message?.let { StudioHint(it) }
        LegalNote(FiscalData.AVISO_NO_COMPROBANTE)
    }
}
