package com.ganageo.app.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.AverageLab
import com.ganageo.app.tools.GeometryLab
import com.ganageo.app.tools.MathEngine
import com.ganageo.app.tools.PercentAnswer
import com.ganageo.app.tools.PercentLab

// ---------------------------------------------------------------------------
// Utilidad de presentación
// ---------------------------------------------------------------------------

@Composable
private fun PercentResult(answer: PercentAnswer, onCopy: (() -> Unit)? = null) {
    ScienceResult(answer.headline, onCopy = onCopy)
    ScienceCard("Cómo se resuelve") {
        answer.steps.forEachIndexed { index, step ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(StudioTheme.Canvas)
                    .padding(10.dp)
            ) {
                Text(
                    "${index + 1}. ${step.title}",
                    color = StudioTheme.Accent,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.labelLarge
                )
                FormulaText(step.expression, size = 14)
                if (step.explanation.isNotBlank()) {
                    Text(
                        step.explanation,
                        color = StudioTheme.TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
    if (answer.note.isNotBlank()) StudioHint(answer.note)
}

private fun num(text: String): Double? = text.replace(',', '.').trim().toDoubleOrNull()

// ---------------------------------------------------------------------------
// Porcentajes y regla de tres
// ---------------------------------------------------------------------------

private class DiscountRow(value: String = "") {
    var value by mutableStateOf(value)
}

private class MagnitudeRow(name: String = "", known: String = "", target: String = "", direct: Boolean = true) {
    var name by mutableStateOf(name)
    var known by mutableStateOf(known)
    var target by mutableStateOf(target)
    var direct by mutableStateOf(direct)
}

/**
 * Porcentajes y regla de tres.
 *
 * Muestra el desarrollo, no solo el número. Dos cosas que aquí sí salen bien:
 * el precio antes de un descuento se obtiene dividiendo, no sumando el mismo
 * porcentaje; y el IGV se saca de un precio dividiendo entre 1,18.
 */
@Composable
fun PercentRuleScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }

    var mode by rememberSaveable { mutableIntStateOf(0) }
    var valueA by rememberSaveable { mutableStateOf("200") }
    var valueB by rememberSaveable { mutableStateOf("15") }

    var basePrice by rememberSaveable { mutableStateOf("100") }
    var discount by rememberSaveable { mutableStateOf("20") }
    var discountMode by rememberSaveable { mutableIntStateOf(0) }
    val chain = remember { mutableStateListOf(DiscountRow("20"), DiscountRow("10")) }

    var taxAmount by rememberSaveable { mutableStateOf("118") }
    var taxRate by rememberSaveable { mutableStateOf("18") }
    var taxIncluded by rememberSaveable { mutableStateOf(true) }

    var ruleA by rememberSaveable { mutableStateOf("2") }
    var ruleB by rememberSaveable { mutableStateOf("10") }
    var ruleC by rememberSaveable { mutableStateOf("5") }
    var ruleDirect by rememberSaveable { mutableStateOf(true) }
    var compoundBase by rememberSaveable { mutableStateOf("5") }
    val magnitudes = remember {
        mutableStateListOf(
            MagnitudeRow("Obreros", "3", "5", false),
            MagnitudeRow("Horas por día", "6", "8", false)
        )
    }

    ScienceShell(
        title = "Porcentajes y regla de tres",
        subtitle = "Con el desarrollo paso a paso",
        onBack = onBack
    ) {
        StudioTabs(listOf("Porcentaje", "Descuento", "IGV", "Regla de tres"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Qué quieres calcular") {
                    StudioChipRow {
                        listOf(
                            "% de una cantidad",
                            "¿Qué % es A de B?",
                            "Variación entre dos valores"
                        ).forEachIndexed { index, label ->
                            StudioChip(label, mode == index, onClick = { mode = index })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(
                            valueA, { valueA = it },
                            when (mode) {
                                0 -> "Cantidad total"
                                1 -> "Parte (A)"
                                else -> "Valor inicial"
                            },
                            Modifier.weight(1f)
                        )
                        ScienceNumberField(
                            valueB, { valueB = it },
                            when (mode) {
                                0 -> "Porcentaje"
                                1 -> "Total (B)"
                                else -> "Valor final"
                            },
                            Modifier.weight(1f)
                        )
                    }
                }
                val a = num(valueA)
                val b = num(valueB)
                if (a == null || b == null) {
                    ScienceError("Escribe dos números válidos.")
                } else {
                    val answer = runCatching {
                        when (mode) {
                            0 -> PercentLab.percentOf(a, b)
                            1 -> PercentLab.whatPercent(a, b)
                            else -> PercentLab.change(a, b)
                        }
                    }
                    answer.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los datos.") }
                    answer.getOrNull()?.let {
                        PercentResult(it) { copyToClipboard(context, "Resultado", it.headline) }
                    }
                }
            }

            1 -> {
                ScienceCard("Tipo de cálculo") {
                    StudioChipRow {
                        listOf(
                            "Aplicar descuento",
                            "Aplicar aumento",
                            "Precio antes del descuento",
                            "Descuentos encadenados"
                        ).forEachIndexed { index, label ->
                            StudioChip(label, discountMode == index, onClick = { discountMode = index })
                        }
                    }
                    ScienceNumberField(
                        basePrice, { basePrice = it },
                        if (discountMode == 2) "Precio final (con descuento)" else "Precio base",
                        Modifier.fillMaxWidth()
                    )
                    if (discountMode == 3) {
                        chain.forEachIndexed { index, row ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ScienceNumberField(
                                    row.value, { row.value = it },
                                    "Descuento ${index + 1} %",
                                    Modifier.weight(1f)
                                )
                                if (chain.size > 1) {
                                    IconButton(onClick = { chain.removeAt(index) }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = StudioTheme.TextSecondary)
                                    }
                                }
                            }
                        }
                        WorkActionButton("Agregar descuento", { chain.add(DiscountRow()) }, Icons.Rounded.Add)
                    } else {
                        ScienceNumberField(discount, { discount = it }, "Porcentaje %", Modifier.fillMaxWidth())
                    }
                }

                val base = num(basePrice)
                val percent = num(discount)
                if (base == null) {
                    ScienceError("Escribe un precio válido.")
                } else {
                    val answer = runCatching {
                        when (discountMode) {
                            0 -> PercentLab.applyChange(base, percent ?: 0.0, increase = false)
                            1 -> PercentLab.applyChange(base, percent ?: 0.0, increase = true)
                            2 -> PercentLab.originalBeforeDiscount(base, percent ?: 0.0)
                            else -> PercentLab.chainedDiscounts(
                                base,
                                chain.mapNotNull { num(it.value) }
                            )
                        }
                    }
                    answer.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los datos.") }
                    answer.getOrNull()?.let {
                        PercentResult(it) { copyToClipboard(context, "Resultado", it.headline) }
                    }
                }
            }

            2 -> {
                ScienceCard("Impuesto") {
                    ScienceNumberField(taxAmount, { taxAmount = it }, "Monto", Modifier.fillMaxWidth())
                    StudioChipRow {
                        listOf("18" to "IGV Perú", "10.5" to "MYPE turismo", "16" to "IVA México", "19" to "IVA Chile/Colombia", "21" to "IVA España").forEach { (rate, label) ->
                            StudioChip(
                                label = label,
                                active = taxRate == rate,
                                onClick = { taxRate = rate },
                                caption = "$rate %"
                            )
                        }
                    }
                    ScienceNumberField(taxRate, { taxRate = it }, "Tasa %", Modifier.fillMaxWidth())
                    StudioChipRow {
                        StudioChip("El monto ya incluye impuesto", taxIncluded, onClick = { taxIncluded = true })
                        StudioChip("Hay que agregarlo", !taxIncluded, onClick = { taxIncluded = false })
                    }
                }
                val amount = num(taxAmount)
                val rate = num(taxRate)
                if (amount == null || rate == null) {
                    ScienceError("Escribe el monto y la tasa.")
                } else {
                    val answer = PercentLab.tax(amount, rate, taxIncluded)
                    PercentResult(answer) { copyToClipboard(context, "IGV", answer.headline) }
                }
            }

            else -> {
                ScienceCard("Regla de tres simple") {
                    StudioChipRow {
                        StudioChip("Directa", ruleDirect, onClick = { ruleDirect = true })
                        StudioChip("Inversa", !ruleDirect, onClick = { ruleDirect = false })
                    }
                    StudioHint(
                        if (ruleDirect) "A más, más: más kilos cuestan más dinero."
                        else "A más, menos: más obreros tardan menos días."
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(ruleA, { ruleA = it }, "Si A", Modifier.weight(1f))
                        ScienceNumberField(ruleB, { ruleB = it }, "es B", Modifier.weight(1f))
                        ScienceNumberField(ruleC, { ruleC = it }, "entonces C", Modifier.weight(1f))
                    }
                }
                val a = num(ruleA)
                val b = num(ruleB)
                val c = num(ruleC)
                if (a != null && b != null && c != null) {
                    val answer = runCatching { PercentLab.ruleOfThree(a, b, c, ruleDirect) }
                    answer.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los datos.") }
                    answer.getOrNull()?.let { PercentResult(it) }
                }

                ScienceCard("Regla de tres compuesta") {
                    ScienceNumberField(compoundBase, { compoundBase = it }, "Valor conocido del resultado", Modifier.fillMaxWidth())
                    magnitudes.forEachIndexed { index, row ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(StudioTheme.Canvas)
                                .padding(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StudioTextField(row.name, { row.name = it }, "Magnitud", modifier = Modifier.weight(1f))
                                if (magnitudes.size > 1) {
                                    IconButton(onClick = { magnitudes.removeAt(index) }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = StudioTheme.TextSecondary)
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ScienceNumberField(row.known, { row.known = it }, "Antes", Modifier.weight(1f))
                                ScienceNumberField(row.target, { row.target = it }, "Después", Modifier.weight(1f))
                            }
                            StudioChipRow {
                                StudioChip("Directa", row.direct, onClick = { row.direct = true })
                                StudioChip("Inversa", !row.direct, onClick = { row.direct = false })
                            }
                        }
                    }
                    WorkActionButton("Agregar magnitud", { magnitudes.add(MagnitudeRow()) }, Icons.Rounded.Add)
                    StudioHint(
                        "Pregúntate para cada una: si esta magnitud sube, ¿el resultado sube o baja? " +
                            "Si sube es directa, si baja es inversa."
                    )
                }
                val baseValue = num(compoundBase)
                if (baseValue != null) {
                    val list = magnitudes.mapNotNull { row ->
                        val known = num(row.known)
                        val target = num(row.target)
                        if (known == null || target == null) null
                        else PercentLab.CompoundMagnitude(
                            row.name.ifBlank { "Magnitud" }, known, target, row.direct
                        )
                    }
                    if (list.isNotEmpty()) {
                        val answer = runCatching { PercentLab.compoundRule(baseValue, list) }
                        answer.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los datos.") }
                        answer.getOrNull()?.let { PercentResult(it) }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Promedios y notas
// ---------------------------------------------------------------------------

/**
 * Promedios y notas.
 *
 * Además de la media de siempre calcula la geométrica y la armónica, que son las
 * correctas para tasas de crecimiento y para velocidades. Promediar dos
 * velocidades con la media aritmética es uno de los errores más repetidos.
 */
@Composable
fun GradesAverageScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var valuesText by rememberSaveable { mutableStateOf("14, 16, 11, 18") }
    var weightsText by rememberSaveable { mutableStateOf("") }
    var kindIndex by rememberSaveable { mutableIntStateOf(0) }
    var halfUp by rememberSaveable { mutableStateOf(true) }
    var dropCount by rememberSaveable { mutableStateOf("1") }

    var accumulated by rememberSaveable { mutableStateOf("13") }
    var doneWeight by rememberSaveable { mutableStateOf("60") }
    var target by rememberSaveable { mutableStateOf("11") }

    val values = valuesText.split(Regex("[,;\\s\\n]+")).mapNotNull { num(it) }
    val weights = weightsText.split(Regex("[,;\\s\\n]+")).mapNotNull { num(it) }.takeIf { it.isNotEmpty() }
    val kind = AverageLab.AverageKind.entries[kindIndex.coerceIn(0, AverageLab.AverageKind.entries.lastIndex)]

    ScienceShell(
        title = "Promedios y notas",
        subtitle = "${values.size} valores",
        onBack = onBack
    ) {
        StudioTabs(listOf("Promedios", "Notas"), tab) { tab = it }

        ScienceCard("Valores") {
            ScienceTextArea(valuesText, { valuesText = it }, "Notas o datos", "14, 16, 11, 18", minHeight = 80)
            if (kind == AverageLab.AverageKind.WEIGHTED) {
                ScienceTextArea(weightsText, { weightsText = it }, "Pesos", "30, 30, 40", minHeight = 70)
                StudioHint("Debe haber tantos pesos como valores.")
            }
        }

        if (values.isEmpty()) {
            ScienceError("Escribe al menos un valor.")
            return@ScienceShell
        }

        val analysis = runCatching { AverageLab.analyze(values, weights) }
        analysis.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los datos.") }
        val data = analysis.getOrNull() ?: return@ScienceShell

        if (tab == 0) {
            ScienceCard("Tipo de promedio") {
                StudioChipRow {
                    AverageLab.AverageKind.entries.forEachIndexed { index, entry ->
                        StudioChip(entry.label, kindIndex == index, onClick = { kindIndex = index })
                    }
                }
                StudioHint(AverageLab.advice(kind))
            }

            val chosen = when (kind) {
                AverageLab.AverageKind.SIMPLE -> data.arithmetic
                AverageLab.AverageKind.WEIGHTED -> data.weighted ?: data.arithmetic
                AverageLab.AverageKind.GEOMETRIC -> data.geometric
                AverageLab.AverageKind.HARMONIC -> data.harmonic
                AverageLab.AverageKind.MEDIAN -> data.median
            }

            if (chosen == null) {
                ScienceError("Ese promedio necesita que todos los valores sean mayores que cero.")
            } else {
                ScienceResult(
                    headline = "${kind.label}: ${MathEngine.formatNumber(chosen, 4)}",
                    caption = "Sobre ${data.count} valores",
                    onCopy = { copyToClipboard(context, "Promedio", MathEngine.formatNumber(chosen, 4)) }
                )
            }

            ScienceCard("Todos los promedios") {
                MoneyRow("Media aritmética", MathEngine.formatNumber(data.arithmetic, 4))
                data.weighted?.let { MoneyRow("Media ponderada", MathEngine.formatNumber(it, 4)) }
                data.geometric?.let { MoneyRow("Media geométrica", MathEngine.formatNumber(it, 4)) }
                data.harmonic?.let { MoneyRow("Media armónica", MathEngine.formatNumber(it, 4)) }
                MoneyRow("Mediana", MathEngine.formatNumber(data.median, 4))
                MoneyRow(
                    "Moda",
                    if (data.mode.isEmpty()) "no hay"
                    else data.mode.joinToString(", ") { MathEngine.formatNumber(it, 2) }
                )
                MoneyRow("Mínimo y máximo", "${MathEngine.formatNumber(data.minimum, 2)} — ${MathEngine.formatNumber(data.maximum, 2)}")
                if (data.geometric != null && data.harmonic != null) {
                    StudioHint(
                        "Siempre se cumple que la armónica ≤ geométrica ≤ aritmética. " +
                            "Si las tres son iguales, todos tus valores lo son."
                    )
                }
            }
        } else {
            ScienceCard("Redondeo") {
                StudioChipRow {
                    StudioChip("El medio punto sube", halfUp, onClick = { halfUp = true })
                    StudioChip("Se trunca", !halfUp, onClick = { halfUp = false })
                }
                val rounded = AverageLab.roundGrade(data.arithmetic, halfUp)
                MoneyRow("Promedio sin redondear", MathEngine.formatNumber(data.arithmetic, 4))
                MoneyRow("Nota final", MathEngine.formatNumber(rounded, 0), highlight = true)
                StudioHint(
                    "No todos los reglamentos redondean igual: en varias universidades el 10,5 sube a 11, " +
                        "en otras no. Confirma el tuyo antes de contar con ese punto."
                )
            }

            ScienceCard("Quitar la peor nota") {
                ScienceNumberField(dropCount, { dropCount = it }, "Cuántas eliminar", Modifier.fillMaxWidth())
                val count = dropCount.toIntOrNull() ?: 1
                val result = runCatching { AverageLab.dropLowest(values, count) }
                result.exceptionOrNull()?.let { StudioHint(it.message ?: "Revisa el dato.") }
                result.getOrNull()?.let {
                    MoneyRow("Promedio sin las $count peores", MathEngine.formatNumber(it, 4), highlight = true)
                    MoneyRow("Mejora", "+" + MathEngine.formatNumber(it - data.arithmetic, 4))
                }
            }

            ScienceCard("¿Qué nota necesito?") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ScienceNumberField(accumulated, { accumulated = it }, "Promedio actual", Modifier.weight(1f))
                    ScienceNumberField(doneWeight, { doneWeight = it }, "Peso evaluado %", Modifier.weight(1f))
                }
                ScienceNumberField(target, { target = it }, "Nota que quieres", Modifier.fillMaxWidth())
                val current = num(accumulated)
                val done = num(doneWeight)
                val objective = num(target)
                if (current != null && done != null && objective != null && done < 100) {
                    val needed = AverageLab.neededScore(current * done, 100 - done, objective)
                    MoneyRow(
                        "Necesitas en el ${MathEngine.formatNumber(100 - done, 0)} % restante",
                        MathEngine.formatNumber(needed, 2),
                        highlight = needed <= 20
                    )
                    if (needed > 20) {
                        ScienceError("Necesitarías más de 20: con lo que queda ya no alcanza ese objetivo.")
                    } else if (needed <= 0) {
                        StudioHint("Ya lo tienes asegurado aunque saques cero.")
                    }
                } else {
                    StudioHint("El peso evaluado debe ser menor que 100 %.")
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Geometría
// ---------------------------------------------------------------------------

/**
 * Geometría.
 *
 * Cada figura dice qué mide cada letra, que es la duda de siempre con las
 * pirámides y los conos. Incluye la fórmula del cordón para calcular el área de
 * un terreno a partir de las coordenadas de sus vértices.
 */
@Composable
fun GeometryScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var group by rememberSaveable { mutableStateOf(GeometryLab.GROUP_PLANE) }
    var shapeId by rememberSaveable { mutableStateOf("cuadrado") }
    var unit by rememberSaveable { mutableStateOf("m") }
    val inputs = remember { mutableStateListOf<Pair<String, String>>() }

    var sideA by rememberSaveable { mutableStateOf("3") }
    var sideB by rememberSaveable { mutableStateOf("4") }
    var sideC by rememberSaveable { mutableStateOf("5") }
    var triangleMode by rememberSaveable { mutableIntStateOf(0) }
    var angleC by rememberSaveable { mutableStateOf("60") }

    var pointsText by rememberSaveable { mutableStateOf("0 0\n10 0\n10 8\n0 8") }

    val shape = GeometryLab.byId(shapeId) ?: GeometryLab.shapes.first()

    fun valueFor(key: String): String = inputs.firstOrNull { it.first == key }?.second ?: ""
    fun setValue(key: String, value: String) {
        val index = inputs.indexOfFirst { it.first == key }
        if (index >= 0) inputs[index] = key to value else inputs.add(key to value)
    }

    ScienceShell(
        title = "Geometría",
        subtitle = shape.name,
        onBack = onBack
    ) {
        StudioTabs(listOf("Figuras", "Triángulos", "Coordenadas"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Figura") {
                    StudioChipRow {
                        listOf(GeometryLab.GROUP_PLANE, GeometryLab.GROUP_SOLID).forEach { name ->
                            StudioChip(
                                label = name,
                                active = group == name,
                                onClick = {
                                    group = name
                                    shapeId = GeometryLab.byGroup(name).first().id
                                    inputs.clear()
                                }
                            )
                        }
                    }
                    StudioChipRow {
                        GeometryLab.byGroup(group).forEach { item ->
                            StudioChip(
                                label = item.name,
                                active = item.id == shape.id,
                                onClick = {
                                    shapeId = item.id
                                    inputs.clear()
                                }
                            )
                        }
                    }
                    StudioHint(shape.diagramNote)
                }

                ScienceCard("Medidas") {
                    StudioLabel("Unidad de las medidas")
                    StudioChipRow {
                        listOf("mm", "cm", "m", "km", "in", "ft").forEach { symbol ->
                            StudioChip(symbol, unit == symbol, onClick = { unit = symbol })
                        }
                    }
                    shape.fields.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { field ->
                                ScienceNumberField(
                                    value = valueFor(field.key),
                                    onValueChange = { setValue(field.key, it) },
                                    label = field.label,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (pair.size == 1) {
                                androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                    StudioHint("Usa la misma unidad en todas las medidas de la figura.")
                }

                ScienceCard("Fórmulas") {
                    shape.formulas.forEach { FormulaText(it, size = 15) }
                }

                val parsed = shape.fields.associate { field -> field.key to num(valueFor(field.key)) }
                if (parsed.values.any { it == null }) {
                    StudioHint("Completa todas las medidas para ver el resultado.")
                } else {
                    val outcome = runCatching {
                        shape.compute(parsed.mapValues { it.value!! })
                    }
                    outcome.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa las medidas.") }
                    outcome.getOrNull()?.let { results ->
                        val main = results.first()
                        ScienceResult(
                            headline = "${main.label}: ${MathEngine.formatNumber(main.value, 4)}" +
                                GeometryLab.unitSuffix(main.dimension, unit),
                            onCopy = {
                                copyToClipboard(
                                    context, "Geometría",
                                    results.joinToString("\n") {
                                        "${it.label}: ${MathEngine.formatNumber(it.value, 4)}" +
                                            GeometryLab.unitSuffix(it.dimension, unit)
                                    }
                                )
                            }
                        )
                        ScienceCard("Resultados") {
                            results.forEach { output ->
                                MoneyRow(
                                    output.label + if (output.note.isBlank()) "" else " (${output.note})",
                                    MathEngine.formatNumber(output.value, 4) +
                                        GeometryLab.unitSuffix(output.dimension, unit)
                                )
                            }
                        }
                    }
                }
            }

            1 -> {
                ScienceCard("Datos conocidos") {
                    StudioChipRow {
                        listOf("Los tres lados", "Dos lados y el ángulo", "Pitágoras").forEachIndexed { index, label ->
                            StudioChip(label, triangleMode == index, onClick = { triangleMode = index })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(sideA, { sideA = it }, "Lado a", Modifier.weight(1f))
                        ScienceNumberField(sideB, { sideB = it }, "Lado b", Modifier.weight(1f))
                        when (triangleMode) {
                            0 -> ScienceNumberField(sideC, { sideC = it }, "Lado c", Modifier.weight(1f))
                            1 -> ScienceNumberField(angleC, { angleC = it }, "Ángulo C°", Modifier.weight(1f))
                            else -> ScienceNumberField(sideC, { sideC = it }, "Hipotenusa", Modifier.weight(1f))
                        }
                    }
                    if (triangleMode == 2) {
                        StudioHint("Deja en blanco el valor que quieres calcular.")
                    }
                }

                val a = num(sideA)
                val b = num(sideB)
                val c = num(sideC)
                val angle = num(angleC)

                when (triangleMode) {
                    0 -> if (a != null && b != null && c != null) {
                        val solution = runCatching { GeometryLab.solveSides(a, b, c) }
                        solution.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los lados.") }
                        solution.getOrNull()?.let { TriangleResult(it, unit) }
                    }
                    1 -> if (a != null && b != null && angle != null) {
                        val solution = runCatching { GeometryLab.solveTwoSidesAngle(a, b, angle) }
                        solution.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los datos.") }
                        solution.getOrNull()?.let { TriangleResult(it, unit) }
                    }
                    else -> {
                        val outcome = runCatching { GeometryLab.pythagoras(a, b, c) }
                        outcome.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa los datos.") }
                        outcome.getOrNull()?.let { (label, value) ->
                            ScienceResult("$label = ${MathEngine.formatNumber(value, 4)} $unit")
                            ScienceCard("Fórmula") {
                                FormulaText("c² = a² + b²", size = 16)
                                StudioHint("Solo vale en triángulos con un ángulo de 90°.")
                            }
                        }
                    }
                }
            }

            else -> {
                ScienceCard("Vértices del terreno") {
                    ScienceTextArea(
                        pointsText, { pointsText = it },
                        "Coordenadas (una por línea)",
                        "0 0\n10 0\n10 8\n0 8",
                        minHeight = 130
                    )
                    StudioHint(
                        "Escribe los vértices en orden, siguiendo el contorno. Es la fórmula del cordón, " +
                            "la que usa un topógrafo para sacar el área desde las coordenadas de los mojones."
                    )
                }
                val outcome = runCatching { GeometryLab.parsePoints(pointsText) }
                outcome.exceptionOrNull()?.let { ScienceError(it.message ?: "Revisa las coordenadas.") }
                outcome.getOrNull()?.let { points ->
                    val area = GeometryLab.shoelaceArea(points)
                    val perimeter = GeometryLab.polygonPerimeter(points)
                    ScienceResult(
                        headline = "Área: ${MathEngine.formatNumber(area, 4)} $unit²",
                        caption = "Perímetro ${MathEngine.formatNumber(perimeter, 4)} $unit · ${points.size} vértices",
                        onCopy = { copyToClipboard(context, "Área", MathEngine.formatNumber(area, 4)) }
                    )
                    ScienceCard("Otros datos") {
                        MoneyRow("Vértices", points.size.toString())
                        MoneyRow("Perímetro", "${MathEngine.formatNumber(perimeter, 4)} $unit")
                        MoneyRow("En hectáreas", MathEngine.formatNumber(area / 10000, 4))
                        val first = points.first()
                        val last = points.last()
                        MoneyRow(
                            "Distancia del último al primero",
                            MathEngine.formatNumber(GeometryLab.distance(last, first), 4) + " $unit"
                        )
                    }
                    ScienceCard("Entre dos puntos") {
                        val p = points[0]
                        val q = points[1]
                        MoneyRow("Distancia", MathEngine.formatNumber(GeometryLab.distance(p, q), 4))
                        val middle = GeometryLab.midpoint(p, q)
                        MoneyRow(
                            "Punto medio",
                            "(${MathEngine.formatNumber(middle.x, 3)}, ${MathEngine.formatNumber(middle.y, 3)})"
                        )
                        MoneyRow(
                            "Pendiente",
                            GeometryLab.slope(p, q)?.let { MathEngine.formatNumber(it, 4) } ?: "vertical"
                        )
                        FormulaText(GeometryLab.lineEquation(p, q), size = 14)
                        StudioHint("Se toman los dos primeros vértices de la lista.")
                    }
                }
            }
        }
    }
}

@Composable
private fun TriangleResult(solution: GeometryLab.TriangleSolution, unit: String) {
    ScienceResult(
        headline = "Área ${MathEngine.formatNumber(solution.area, 4)} $unit²",
        caption = "Triángulo ${solution.kind}"
    )
    ScienceCard("Lados y ángulos") {
        MoneyRow("Lado a", "${MathEngine.formatNumber(solution.sides.first, 4)} $unit")
        MoneyRow("Lado b", "${MathEngine.formatNumber(solution.sides.second, 4)} $unit")
        MoneyRow("Lado c", "${MathEngine.formatNumber(solution.sides.third, 4)} $unit")
        MoneyRow("Ángulo A", "${MathEngine.formatNumber(solution.angles.first, 2)}°")
        MoneyRow("Ángulo B", "${MathEngine.formatNumber(solution.angles.second, 2)}°")
        MoneyRow("Ángulo C", "${MathEngine.formatNumber(solution.angles.third, 2)}°")
        MoneyRow(
            "Perímetro",
            MathEngine.formatNumber(
                solution.sides.first + solution.sides.second + solution.sides.third, 4
            ) + " $unit"
        )
    }
    ScienceCard("Cómo se resolvió") {
        solution.steps.forEach { FormulaText(it, size = 14) }
    }
}
