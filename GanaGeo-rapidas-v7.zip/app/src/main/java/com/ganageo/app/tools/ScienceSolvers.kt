package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** Un paso del desarrollo: qué se hizo, cómo queda y por qué. */
data class SolveStep(
    val title: String,
    val expression: String,
    val explanation: String
)

data class StepSolution(
    val headline: String,
    val results: List<String>,
    val steps: List<SolveStep>,
    val method: String,
    val note: String? = null
)

/**
 * Resolución paso a paso.
 *
 * La idea no es soltar el resultado, sino mostrar el mismo desarrollo que haría
 * un profesor en la pizarra: cada paso trae la expresión resultante y una línea
 * que explica la regla aplicada.
 */
object AlgebraSteps {

    private fun n(value: Double) = MathEngine.formatNumber(value)

    /**
     * Lee una ecuación escrita por el usuario ("2(x+3)=5x-4") y devuelve los
     * coeficientes del polinomio equivalente igualado a cero.
     *
     * Se obtienen muestreando la expresión en varios puntos y resolviendo el
     * sistema de Vandermonde. Es exacto para polinomios y detecta solo el grado
     * que realmente hace falta.
     */
    fun polynomialFromEquation(raw: String, variable: String = "x", maxDegree: Int = 4): DoubleArray? {
        val text = raw.replace(" ", "")
        if (text.isBlank()) return null
        val sides = text.split("=")
        val difference: MathNode = when (sides.size) {
            1 -> MathEngine.tryParse(sides[0]) ?: return null
            2 -> {
                val left = MathEngine.tryParse(sides[0]) ?: return null
                val right = MathEngine.tryParse(sides[1]) ?: return null
                MathNode.Binary('-', left, right)
            }
            else -> return null
        }
        val key = variable.lowercase()
        if (MathEngine.variablesOf(difference).any { it != key }) return null
        val f = MathEngine.compileNode(difference, key)

        for (degree in 0..maxDegree) {
            val points = DoubleArray(degree + 1) { it.toDouble() - degree / 2.0 }
            val matrix = Array(degree + 1) { row ->
                DoubleArray(degree + 1) { column -> points[row].pow(column) }
            }
            val values = DoubleArray(degree + 1) { f(points[it]) }
            if (values.any { !it.isFinite() }) return null
            val coefficients = LinearAlgebraPro.solveSystem(matrix, values) ?: continue
            // Comprobación en puntos nuevos: si encaja, el grado es el correcto.
            val fits = listOf(3.7, -2.3, 5.1).all { x ->
                val expected = f(x)
                if (!expected.isFinite()) return@all false
                val got = coefficients.indices.sumOf { i -> coefficients[i] * x.pow(i) }
                abs(expected - got) <= 1e-6 * max(1.0, abs(expected))
            }
            if (fits) return coefficients
        }
        return null
    }

    /** ax + b = 0 */
    fun linear(a: Double, b: Double): StepSolution {
        if (abs(a) < 1e-12) {
            return if (abs(b) < 1e-12) {
                StepSolution(
                    headline = "Infinitas soluciones",
                    results = listOf("Cualquier valor de x cumple la igualdad"),
                    steps = listOf(
                        SolveStep("Identidad", "0 = 0", "Los dos lados son iguales para todo x.")
                    ),
                    method = "Ecuación lineal"
                )
            } else {
                StepSolution(
                    headline = "Sin solución",
                    results = listOf("No existe ningún x que cumpla la igualdad"),
                    steps = listOf(
                        SolveStep("Contradicción", "${n(b)} = 0", "El coeficiente de x es cero y el término independiente no.")
                    ),
                    method = "Ecuación lineal"
                )
            }
        }
        val x = -b / a
        val steps = listOf(
            SolveStep(
                "Ecuación ordenada",
                "${n(a)}x ${sign(b)} = 0",
                "Se pasa todo a un lado del igual y se agrupan términos semejantes."
            ),
            SolveStep(
                "Despejar el término con x",
                "${n(a)}x = ${n(-b)}",
                "Se resta ${n(b)} en ambos lados para dejar la x sola."
            ),
            SolveStep(
                "Dividir entre el coeficiente",
                "x = ${n(-b)} / ${n(a)}",
                "Se divide entre ${n(a)} para que el coeficiente de x sea 1."
            ),
            SolveStep(
                "Resultado",
                "x = ${n(x)}",
                "Comprobación: ${n(a)}·(${n(x)}) ${sign(b)} = ${n(a * x + b)}"
            )
        )
        return StepSolution(
            headline = "x = ${n(x)}",
            results = listOf("x = ${n(x)}"),
            steps = steps,
            method = "Ecuación lineal"
        )
    }

    /** ax² + bx + c = 0 */
    fun quadratic(a: Double, b: Double, c: Double): StepSolution {
        if (abs(a) < 1e-12) return linear(b, c)
        val discriminant = b * b - 4 * a * c
        val steps = mutableListOf<SolveStep>()
        steps += SolveStep(
            "Ecuación ordenada",
            "${n(a)}x² ${sign(b)}x ${sign(c)} = 0",
            "Forma general ax² + bx + c = 0 con a = ${n(a)}, b = ${n(b)}, c = ${n(c)}."
        )
        steps += SolveStep(
            "Discriminante",
            "Δ = b² − 4ac = ${n(b)}² − 4·${n(a)}·${n(c)} = ${n(discriminant)}",
            when {
                discriminant > 1e-12 -> "Δ > 0: hay dos soluciones reales distintas."
                discriminant < -1e-12 -> "Δ < 0: no hay soluciones reales, son dos complejas conjugadas."
                else -> "Δ = 0: hay una única solución real (raíz doble)."
            }
        )

        val vertexX = -b / (2 * a)
        val vertexY = a * vertexX * vertexX + b * vertexX + c

        return when {
            discriminant > 1e-12 -> {
                val root = sqrt(discriminant)
                val x1 = (-b + root) / (2 * a)
                val x2 = (-b - root) / (2 * a)
                steps += SolveStep(
                    "Fórmula general",
                    "x = (−b ± √Δ) / 2a = (${n(-b)} ± ${n(root)}) / ${n(2 * a)}",
                    "Se sustituye en la fórmula resolvente."
                )
                steps += SolveStep(
                    "Las dos raíces",
                    "x₁ = ${n(x1)}    x₂ = ${n(x2)}",
                    "Se resuelven por separado el signo + y el signo −."
                )
                steps += SolveStep(
                    "Factorización",
                    "${n(a)}(x ${sign(-x1)})(x ${sign(-x2)}) = 0",
                    "Con las raíces se puede escribir el polinomio factorizado."
                )
                steps += SolveStep(
                    "Vértice de la parábola",
                    "V(${n(vertexX)}, ${n(vertexY)})",
                    "x del vértice = −b/2a. Es el mínimo si a > 0 y el máximo si a < 0."
                )
                StepSolution(
                    headline = "x₁ = ${n(x1)}   ·   x₂ = ${n(x2)}",
                    results = listOf("x₁ = ${n(x1)}", "x₂ = ${n(x2)}"),
                    steps = steps,
                    method = "Fórmula general"
                )
            }
            discriminant < -1e-12 -> {
                val realPart = -b / (2 * a)
                val imaginary = sqrt(-discriminant) / (2 * a)
                steps += SolveStep(
                    "Raíz de un número negativo",
                    "√(${n(discriminant)}) = ${n(sqrt(-discriminant))}i",
                    "Se usa la unidad imaginaria i, con i² = −1."
                )
                steps += SolveStep(
                    "Soluciones complejas",
                    "x = ${n(realPart)} ± ${n(abs(imaginary))}i",
                    "Las dos raíces son conjugadas: misma parte real y parte imaginaria opuesta."
                )
                steps += SolveStep(
                    "Vértice de la parábola",
                    "V(${n(vertexX)}, ${n(vertexY)})",
                    "La parábola no corta el eje X, por eso no hay raíces reales."
                )
                StepSolution(
                    headline = "x = ${n(realPart)} ± ${n(abs(imaginary))}i",
                    results = listOf(
                        "x₁ = ${n(realPart)} + ${n(abs(imaginary))}i",
                        "x₂ = ${n(realPart)} − ${n(abs(imaginary))}i"
                    ),
                    steps = steps,
                    method = "Fórmula general (raíces complejas)",
                    note = "La parábola no toca el eje X, así que no hay solución en los números reales."
                )
            }
            else -> {
                val x = -b / (2 * a)
                steps += SolveStep(
                    "Raíz doble",
                    "x = −b / 2a = ${n(x)}",
                    "Con Δ = 0 la fórmula general da una sola solución, repetida dos veces."
                )
                steps += SolveStep(
                    "Factorización",
                    "${n(a)}(x ${sign(-x)})² = 0",
                    "El trinomio es un cuadrado perfecto."
                )
                StepSolution(
                    headline = "x = ${n(x)} (raíz doble)",
                    results = listOf("x₁ = x₂ = ${n(x)}"),
                    steps = steps,
                    method = "Fórmula general"
                )
            }
        }
    }

    /** Sistema 2×2: a1x + b1y = c1 ; a2x + b2y = c2 */
    fun system2x2(a1: Double, b1: Double, c1: Double, a2: Double, b2: Double, c2: Double): StepSolution {
        val determinant = a1 * b2 - a2 * b1
        val steps = mutableListOf<SolveStep>()
        steps += SolveStep(
            "Sistema",
            "${n(a1)}x ${sign(b1)}y = ${n(c1)}\n${n(a2)}x ${sign(b2)}y = ${n(c2)}",
            "Dos ecuaciones con dos incógnitas."
        )
        steps += SolveStep(
            "Determinante principal",
            "Δ = ${n(a1)}·${n(b2)} − ${n(a2)}·${n(b1)} = ${n(determinant)}",
            if (abs(determinant) < 1e-12) "Δ = 0: el sistema no tiene solución única."
            else "Δ ≠ 0: el sistema tiene solución única."
        )
        if (abs(determinant) < 1e-12) {
            val proportional = abs(a1 * c2 - a2 * c1) < 1e-9 && abs(b1 * c2 - b2 * c1) < 1e-9
            return StepSolution(
                headline = if (proportional) "Infinitas soluciones" else "Sin solución",
                results = listOf(
                    if (proportional) "Las dos rectas son la misma" else "Las rectas son paralelas y no se cortan"
                ),
                steps = steps,
                method = "Regla de Cramer"
            )
        }
        val dx = c1 * b2 - c2 * b1
        val dy = a1 * c2 - a2 * c1
        val x = dx / determinant
        val y = dy / determinant
        steps += SolveStep(
            "Determinante de x",
            "Δx = ${n(c1)}·${n(b2)} − ${n(c2)}·${n(b1)} = ${n(dx)}",
            "Se reemplaza la columna de x por los términos independientes."
        )
        steps += SolveStep(
            "Determinante de y",
            "Δy = ${n(a1)}·${n(c2)} − ${n(a2)}·${n(c1)} = ${n(dy)}",
            "Se reemplaza la columna de y por los términos independientes."
        )
        steps += SolveStep(
            "Solución",
            "x = Δx/Δ = ${n(x)}\ny = Δy/Δ = ${n(y)}",
            "Comprobación en la primera ecuación: ${n(a1 * x + b1 * y)} = ${n(c1)}"
        )
        return StepSolution(
            headline = "x = ${n(x)}   ·   y = ${n(y)}",
            results = listOf("x = ${n(x)}", "y = ${n(y)}"),
            steps = steps,
            method = "Regla de Cramer",
            note = "El punto (${n(x)}, ${n(y)}) es donde se cortan las dos rectas."
        )
    }

    /** Sistema 3×3 por eliminación de Gauss con pivoteo. */
    fun system3x3(matrix: Array<DoubleArray>, constants: DoubleArray): StepSolution {
        val steps = mutableListOf<SolveStep>()
        steps += SolveStep(
            "Sistema",
            (0..2).joinToString("\n") { row ->
                "${n(matrix[row][0])}x ${sign(matrix[row][1])}y ${sign(matrix[row][2])}z = ${n(constants[row])}"
            },
            "Tres ecuaciones con tres incógnitas."
        )
        val determinant = LinearAlgebraPro.determinant(matrix)
        steps += SolveStep(
            "Determinante",
            "Δ = ${n(determinant)}",
            if (abs(determinant) < 1e-12) "Δ = 0: no hay solución única."
            else "Δ ≠ 0: hay una única solución."
        )
        val solution = LinearAlgebraPro.solveSystem(matrix, constants)
        if (solution == null) {
            return StepSolution(
                headline = "Sin solución única",
                results = listOf("El sistema es incompatible o tiene infinitas soluciones"),
                steps = steps,
                method = "Eliminación de Gauss"
            )
        }
        steps += SolveStep(
            "Eliminación de Gauss",
            "Se triangula la matriz y se sustituye hacia atrás",
            "Se elige como pivote el mayor elemento de cada columna para no perder precisión."
        )
        steps += SolveStep(
            "Solución",
            "x = ${n(solution[0])}\ny = ${n(solution[1])}\nz = ${n(solution[2])}",
            "Comprobación en la primera ecuación: " +
                n(matrix[0][0] * solution[0] + matrix[0][1] * solution[1] + matrix[0][2] * solution[2]) +
                " = ${n(constants[0])}"
        )
        return StepSolution(
            headline = "x = ${n(solution[0])} · y = ${n(solution[1])} · z = ${n(solution[2])}",
            results = listOf("x = ${n(solution[0])}", "y = ${n(solution[1])}", "z = ${n(solution[2])}"),
            steps = steps,
            method = "Eliminación de Gauss"
        )
    }

    /** Resuelve automáticamente lo que el usuario escribió. */
    fun solveEquation(raw: String, variable: String = "x"): StepSolution {
        val coefficients = polynomialFromEquation(raw, variable)
            ?: throw IllegalArgumentException("No se pudo interpretar la ecuación. Usa solo la variable $variable.")
        val degree = coefficients.indexOfLast { abs(it) > 1e-12 }
        return when {
            degree <= 0 -> {
                if (abs(coefficients.getOrElse(0) { 0.0 }) < 1e-12) {
                    StepSolution(
                        "Infinitas soluciones",
                        listOf("Cualquier valor cumple la igualdad"),
                        listOf(SolveStep("Identidad", "0 = 0", "Los dos lados son la misma expresión.")),
                        "Identidad"
                    )
                } else {
                    StepSolution(
                        "Sin solución",
                        listOf("La igualdad nunca se cumple"),
                        listOf(
                            SolveStep(
                                "Contradicción",
                                "${n(coefficients[0])} = 0",
                                "Al simplificar desaparece la variable y queda algo falso."
                            )
                        ),
                        "Sin incógnita"
                    )
                }
            }
            degree == 1 -> linear(coefficients[1], coefficients[0])
            degree == 2 -> quadratic(coefficients[2], coefficients[1], coefficients[0])
            else -> polynomialNumeric(coefficients)
        }
    }

    /** Grado 3 o más: raíces reales aproximadas por búsqueda y refinamiento. */
    private fun polynomialNumeric(coefficients: DoubleArray): StepSolution {
        val degree = coefficients.indexOfLast { abs(it) > 1e-12 }
        val f: (Double) -> Double = { x -> coefficients.indices.sumOf { i -> coefficients[i] * x.pow(i) } }
        val bound = 1.0 + (0 until degree).maxOf { abs(coefficients[it] / coefficients[degree]) }
        val roots = NumericCalculus.rootsIn(f, -bound, bound, 4000)
        val steps = mutableListOf(
            SolveStep(
                "Polinomio",
                describePolynomial(coefficients) + " = 0",
                "Grado $degree. Se buscan las raíces reales."
            ),
            SolveStep(
                "Cota de Cauchy",
                "|x| ≤ ${n(bound)}",
                "Todas las raíces reales están dentro de ese intervalo, así que se busca solo ahí."
            )
        )
        steps += if (roots.isEmpty()) {
            SolveStep("Sin raíces reales", "—", "La curva no corta el eje X en el intervalo analizado.")
        } else {
            SolveStep(
                "Raíces encontradas",
                roots.joinToString("\n") { "x = ${n(it)}" },
                "Se detecta el cambio de signo y se afina con bisección y Newton-Raphson."
            )
        }
        return StepSolution(
            headline = if (roots.isEmpty()) "Sin raíces reales" else roots.joinToString("  ·  ") { "x = ${n(it)}" },
            results = roots.map { "x = ${n(it)}" },
            steps = steps,
            method = "Búsqueda numérica de raíces",
            note = "En grado $degree las raíces se calculan de forma aproximada, no exacta."
        )
    }

    fun describePolynomial(coefficients: DoubleArray, variable: String = "x"): String {
        val parts = mutableListOf<String>()
        for (i in coefficients.indices.reversed()) {
            val c = coefficients[i]
            if (abs(c) < 1e-12) continue
            val body = when (i) {
                0 -> n(abs(c))
                1 -> if (abs(abs(c) - 1.0) < 1e-12) variable else "${n(abs(c))}$variable"
                else -> if (abs(abs(c) - 1.0) < 1e-12) "$variable^$i" else "${n(abs(c))}$variable^$i"
            }
            parts += if (parts.isEmpty()) {
                if (c < 0) "-$body" else body
            } else {
                if (c < 0) " - $body" else " + $body"
            }
        }
        return if (parts.isEmpty()) "0" else parts.joinToString("")
    }

    private fun sign(value: Double): String =
        if (value < 0) "− ${n(abs(value))}" else "+ ${n(value)}"
}

/**
 * Álgebra lineal con pivoteo. Todo lo que necesita la herramienta de matrices
 * y, de paso, el balanceo de ecuaciones químicas.
 */
object LinearAlgebraPro {

    fun identity(size: Int): Array<DoubleArray> =
        Array(size) { row -> DoubleArray(size) { column -> if (row == column) 1.0 else 0.0 } }

    fun add(a: Array<DoubleArray>, b: Array<DoubleArray>, subtract: Boolean = false): Array<DoubleArray> {
        require(a.size == b.size && a[0].size == b[0].size) { "Las matrices deben tener el mismo tamaño." }
        return Array(a.size) { row ->
            DoubleArray(a[0].size) { column ->
                if (subtract) a[row][column] - b[row][column] else a[row][column] + b[row][column]
            }
        }
    }

    fun scale(a: Array<DoubleArray>, factor: Double): Array<DoubleArray> =
        Array(a.size) { row -> DoubleArray(a[0].size) { column -> a[row][column] * factor } }

    fun multiply(a: Array<DoubleArray>, b: Array<DoubleArray>): Array<DoubleArray> {
        require(a[0].size == b.size) {
            "Para multiplicar, las columnas de la primera (${a[0].size}) deben coincidir con las filas de la segunda (${b.size})."
        }
        return Array(a.size) { row ->
            DoubleArray(b[0].size) { column ->
                var sum = 0.0
                for (k in b.indices) sum += a[row][k] * b[k][column]
                sum
            }
        }
    }

    fun transpose(a: Array<DoubleArray>): Array<DoubleArray> =
        Array(a[0].size) { row -> DoubleArray(a.size) { column -> a[column][row] } }

    fun trace(a: Array<DoubleArray>): Double {
        require(a.size == a[0].size) { "La traza solo existe en matrices cuadradas." }
        return a.indices.sumOf { a[it][it] }
    }

    /** Determinante por eliminación con pivoteo parcial. */
    fun determinant(source: Array<DoubleArray>): Double {
        require(source.size == source[0].size) { "El determinante solo existe en matrices cuadradas." }
        val size = source.size
        val m = Array(size) { source[it].copyOf() }
        var result = 1.0
        for (column in 0 until size) {
            var pivot = column
            for (row in column until size) {
                if (abs(m[row][column]) > abs(m[pivot][column])) pivot = row
            }
            if (abs(m[pivot][column]) < 1e-14) return 0.0
            if (pivot != column) {
                val temp = m[pivot]
                m[pivot] = m[column]
                m[column] = temp
                result = -result
            }
            result *= m[column][column]
            for (row in column + 1 until size) {
                val factor = m[row][column] / m[column][column]
                for (k in column until size) m[row][k] -= factor * m[column][k]
            }
        }
        return result
    }

    /** Inversa por Gauss-Jordan. Devuelve null si la matriz es singular. */
    fun inverse(source: Array<DoubleArray>): Array<DoubleArray>? {
        require(source.size == source[0].size) { "Solo se puede invertir una matriz cuadrada." }
        val size = source.size
        val m = Array(size) { source[it].copyOf() }
        val inv = identity(size)
        for (column in 0 until size) {
            var pivot = column
            for (row in column until size) {
                if (abs(m[row][column]) > abs(m[pivot][column])) pivot = row
            }
            if (abs(m[pivot][column]) < 1e-12) return null
            if (pivot != column) {
                var temp = m[pivot]; m[pivot] = m[column]; m[column] = temp
                temp = inv[pivot]; inv[pivot] = inv[column]; inv[column] = temp
            }
            val divisor = m[column][column]
            for (k in 0 until size) {
                m[column][k] /= divisor
                inv[column][k] /= divisor
            }
            for (row in 0 until size) {
                if (row == column) continue
                val factor = m[row][column]
                if (abs(factor) < 1e-15) continue
                for (k in 0 until size) {
                    m[row][k] -= factor * m[column][k]
                    inv[row][k] -= factor * inv[column][k]
                }
            }
        }
        return inv
    }

    fun rank(source: Array<DoubleArray>): Int {
        val rows = source.size
        val columns = source[0].size
        val m = Array(rows) { source[it].copyOf() }
        var rank = 0
        var row = 0
        for (column in 0 until columns) {
            if (row >= rows) break
            var pivot = row
            for (r in row until rows) if (abs(m[r][column]) > abs(m[pivot][column])) pivot = r
            if (abs(m[pivot][column]) < 1e-12) continue
            val temp = m[pivot]; m[pivot] = m[row]; m[row] = temp
            for (r in 0 until rows) {
                if (r == row) continue
                val factor = m[r][column] / m[row][column]
                for (k in column until columns) m[r][k] -= factor * m[row][k]
            }
            row++
            rank++
        }
        return rank
    }

    /** Resuelve A·x = b. Devuelve null si no hay solución única. */
    fun solveSystem(source: Array<DoubleArray>, constants: DoubleArray): DoubleArray? {
        val size = source.size
        if (size == 0 || source[0].size != size || constants.size != size) return null
        val m = Array(size) { source[it].copyOf() }
        val b = constants.copyOf()
        for (column in 0 until size) {
            var pivot = column
            for (row in column until size) if (abs(m[row][column]) > abs(m[pivot][column])) pivot = row
            if (abs(m[pivot][column]) < 1e-12) return null
            if (pivot != column) {
                val temp = m[pivot]; m[pivot] = m[column]; m[column] = temp
                val tempB = b[pivot]; b[pivot] = b[column]; b[column] = tempB
            }
            for (row in column + 1 until size) {
                val factor = m[row][column] / m[column][column]
                if (abs(factor) < 1e-15) continue
                for (k in column until size) m[row][k] -= factor * m[column][k]
                b[row] -= factor * b[column]
            }
        }
        val x = DoubleArray(size)
        for (row in size - 1 downTo 0) {
            var sum = b[row]
            for (k in row + 1 until size) sum -= m[row][k] * x[k]
            x[row] = sum / m[row][row]
        }
        return if (x.all { it.isFinite() }) x else null
    }

    /** Valores propios reales de matrices 2×2 y 3×3. */
    fun eigenvalues(source: Array<DoubleArray>): List<Double> {
        val size = source.size
        if (size != source[0].size) return emptyList()
        return when (size) {
            1 -> listOf(source[0][0])
            2 -> {
                val trace = source[0][0] + source[1][1]
                val det = determinant(source)
                val disc = trace * trace - 4 * det
                if (disc < 0) emptyList()
                else listOf((trace + sqrt(disc)) / 2, (trace - sqrt(disc)) / 2).distinct()
            }
            3 -> {
                // Polinomio característico: -λ³ + tr·λ² - m·λ + det
                val trace = trace(source)
                val det = determinant(source)
                val minorSum =
                    (source[0][0] * source[1][1] - source[0][1] * source[1][0]) +
                        (source[0][0] * source[2][2] - source[0][2] * source[2][0]) +
                        (source[1][1] * source[2][2] - source[1][2] * source[2][1])
                cubicRealRoots(1.0, -trace, minorSum, -det)
            }
            else -> emptyList()
        }
    }

    /** Raíces reales de ax³ + bx² + cx + d (método trigonométrico de Cardano). */
    fun cubicRealRoots(a: Double, b: Double, c: Double, d: Double): List<Double> {
        if (abs(a) < 1e-14) return emptyList()
        val p = (3 * a * c - b * b) / (3 * a * a)
        val q = (2 * b * b * b - 9 * a * b * c + 27 * a * a * d) / (27 * a * a * a)
        val shift = -b / (3 * a)
        val discriminant = q * q / 4 + p * p * p / 27
        return when {
            abs(discriminant) < 1e-12 -> {
                if (abs(p) < 1e-12) listOf(shift)
                else listOf(3 * q / p + shift, -3 * q / (2 * p) + shift).distinct()
            }
            discriminant > 0 -> {
                val sq = sqrt(discriminant)
                val u = Math.cbrt(-q / 2 + sq)
                val v = Math.cbrt(-q / 2 - sq)
                listOf(u + v + shift)
            }
            else -> {
                val r = sqrt(-p * p * p / 27)
                val phi = acos((-q / 2) / r)
                val m = 2 * sqrt(-p / 3)
                (0..2).map { k -> m * cos((phi + 2 * Math.PI * k) / 3) + shift }
            }
        }.map { if (abs(it) < 1e-10) 0.0 else it }
    }

    fun parse(raw: String): Array<DoubleArray> {
        val rows = raw.trim().lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        require(rows.isNotEmpty()) { "Escribe al menos una fila." }
        val matrix = rows.map { line ->
            line.split(Regex("[,;\\s]+"))
                .filter { it.isNotBlank() }
                .map { it.replace(',', '.').toDoubleOrNull() ?: throw IllegalArgumentException("Valor inválido: $it") }
                .toDoubleArray()
        }
        val columns = matrix.first().size
        require(matrix.all { it.size == columns }) { "Todas las filas deben tener la misma cantidad de números." }
        return matrix.toTypedArray()
    }

    fun format(matrix: Array<DoubleArray>): String =
        matrix.joinToString("\n") { row -> row.joinToString("   ") { MathEngine.formatNumber(it, 4) } }
}

object VectorLab {
    fun parse(raw: String): DoubleArray {
        val parts = raw.trim().split(Regex("[,;\\s]+")).filter { it.isNotBlank() }
        require(parts.size in 2..3) { "Usa 2 o 3 componentes, por ejemplo 3 -1 2." }
        return parts.map {
            it.replace(',', '.').toDoubleOrNull() ?: throw IllegalArgumentException("Componente inválida: $it")
        }.toDoubleArray()
    }

    fun norm(v: DoubleArray): Double = sqrt(v.sumOf { it * it })

    fun dot(a: DoubleArray, b: DoubleArray): Double {
        require(a.size == b.size) { "Los vectores deben tener la misma cantidad de componentes." }
        return a.indices.sumOf { a[it] * b[it] }
    }

    fun cross(a: DoubleArray, b: DoubleArray): DoubleArray {
        val x = a.toSize3()
        val y = b.toSize3()
        return doubleArrayOf(
            x[1] * y[2] - x[2] * y[1],
            x[2] * y[0] - x[0] * y[2],
            x[0] * y[1] - x[1] * y[0]
        )
    }

    fun angleDegrees(a: DoubleArray, b: DoubleArray): Double {
        val denominator = norm(a) * norm(b)
        if (denominator < 1e-12) return Double.NaN
        val cosine = (dot(a, b) / denominator).coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(cosine))
    }

    fun projection(a: DoubleArray, b: DoubleArray): DoubleArray {
        val denominator = dot(b, b)
        if (abs(denominator) < 1e-12) return DoubleArray(b.size)
        val factor = dot(a, b) / denominator
        return DoubleArray(b.size) { b[it] * factor }
    }

    fun unit(v: DoubleArray): DoubleArray {
        val n = norm(v)
        return if (n < 1e-12) v.copyOf() else DoubleArray(v.size) { v[it] / n }
    }

    fun format(v: DoubleArray): String = v.joinToString(", ") { MathEngine.formatNumber(it, 4) }

    private fun DoubleArray.toSize3(): DoubleArray =
        if (size >= 3) this else doubleArrayOf(getOrElse(0) { 0.0 }, getOrElse(1) { 0.0 }, 0.0)
}

/** Derivadas, integrales, raíces y límites por métodos numéricos. */
object NumericCalculus {

    /** Derivada por diferencia central de cinco puntos. */
    fun derivativeAt(f: (Double) -> Double, x: Double): Double {
        val h = (abs(x).coerceAtLeast(1.0)) * 1e-5
        val a = f(x - 2 * h)
        val b = f(x - h)
        val c = f(x + h)
        val d = f(x + 2 * h)
        if (!a.isFinite() || !b.isFinite() || !c.isFinite() || !d.isFinite()) {
            val simple = (f(x + h) - f(x - h)) / (2 * h)
            return simple
        }
        return (a - 8 * b + 8 * c - d) / (12 * h)
    }

    fun secondDerivativeAt(f: (Double) -> Double, x: Double): Double {
        val h = (abs(x).coerceAtLeast(1.0)) * 1e-4
        return (f(x + h) - 2 * f(x) + f(x - h)) / (h * h)
    }

    /** Integral definida por Simpson compuesto con número par de intervalos. */
    fun integrate(f: (Double) -> Double, from: Double, to: Double, intervals: Int = 2000): Double {
        if (from == to) return 0.0
        val sign = if (to < from) -1.0 else 1.0
        val a = min(from, to)
        val b = max(from, to)
        val n = if (intervals % 2 == 0) intervals else intervals + 1
        val h = (b - a) / n
        var sum = 0.0
        var valid = 0
        for (i in 0..n) {
            val y = f(a + i * h)
            if (!y.isFinite()) continue
            valid++
            val weight = when {
                i == 0 || i == n -> 1.0
                i % 2 == 1 -> 4.0
                else -> 2.0
            }
            sum += weight * y
        }
        if (valid < n / 2) return Double.NaN
        return sign * sum * h / 3.0
    }

    /** Raíces reales dentro de un intervalo: cambio de signo + refinamiento. */
    fun rootsIn(f: (Double) -> Double, from: Double, to: Double, samples: Int = 2000): List<Double> {
        val found = mutableListOf<Double>()
        val step = (to - from) / samples
        var previousX = from
        var previousY = f(from)
        for (i in 1..samples) {
            val x = from + i * step
            val y = f(x)
            if (previousY.isFinite() && y.isFinite()) {
                if (previousY == 0.0) addRoot(found, previousX)
                else if (previousY * y < 0 && abs(previousY - y) < 1e9) {
                    addRoot(found, refine(f, previousX, x))
                }
            }
            previousX = x
            previousY = y
        }
        if (previousY == 0.0) addRoot(found, previousX)
        return found
    }

    private fun addRoot(list: MutableList<Double>, value: Double) {
        if (!value.isFinite()) return
        val rounded = if (abs(value) < 1e-9) 0.0 else value
        if (list.none { abs(it - rounded) < 1e-6 }) list += rounded
    }

    private fun refine(f: (Double) -> Double, low: Double, high: Double): Double {
        var a = low
        var b = high
        var fa = f(a)
        repeat(80) {
            val mid = (a + b) / 2
            val fm = f(mid)
            if (!fm.isFinite()) return mid
            if (fa * fm <= 0) {
                b = mid
            } else {
                a = mid
                fa = fm
            }
        }
        return (a + b) / 2
    }

    /** Límite aproximado acercándose por los dos lados. */
    fun limitAt(f: (Double) -> Double, x: Double): Triple<Double, Double, Double> {
        fun side(direction: Int): Double {
            var h = 0.1
            var last = Double.NaN
            repeat(12) {
                val value = f(x + direction * h)
                if (value.isFinite()) last = value
                h /= 4
            }
            return last
        }
        val left = side(-1)
        val right = side(1)
        val value = if (abs(left - right) < 1e-6 * max(1.0, abs(left))) (left + right) / 2 else Double.NaN
        return Triple(left, right, value)
    }
}

data class SequenceInfo(
    val terms: List<Double>,
    val generalTerm: String,
    val sum: Double,
    val note: String
)

object SequenceLab {
    fun arithmetic(first: Double, difference: Double, count: Int): SequenceInfo {
        val n = count.coerceIn(1, 200)
        val terms = List(n) { first + it * difference }
        val sum = n * (2 * first + (n - 1) * difference) / 2
        return SequenceInfo(
            terms = terms,
            generalTerm = "aₙ = ${MathEngine.formatNumber(first)} + (n − 1)·${MathEngine.formatNumber(difference)}",
            sum = sum,
            note = "Suma de los $n primeros términos: Sₙ = n·(a₁ + aₙ)/2"
        )
    }

    fun geometric(first: Double, ratio: Double, count: Int): SequenceInfo {
        val n = count.coerceIn(1, 200)
        val terms = List(n) { first * ratio.pow(it) }
        val sum = if (abs(ratio - 1.0) < 1e-12) first * n else first * (1 - ratio.pow(n)) / (1 - ratio)
        val note = if (abs(ratio) < 1) {
            "Como |r| < 1, la suma infinita converge a ${MathEngine.formatNumber(first / (1 - ratio))}"
        } else {
            "Con |r| ≥ 1 la suma infinita diverge."
        }
        return SequenceInfo(
            terms = terms,
            generalTerm = "aₙ = ${MathEngine.formatNumber(first)}·${MathEngine.formatNumber(ratio)}^(n−1)",
            sum = sum,
            note = note
        )
    }

    fun fibonacci(count: Int): SequenceInfo {
        val n = count.coerceIn(1, 90)
        val terms = mutableListOf(0.0, 1.0)
        while (terms.size < n) terms += terms[terms.size - 1] + terms[terms.size - 2]
        val list = terms.take(n)
        return SequenceInfo(
            terms = list,
            generalTerm = "aₙ = aₙ₋₁ + aₙ₋₂, con a₁ = 0 y a₂ = 1",
            sum = list.sum(),
            note = "El cociente entre términos consecutivos tiende al número áureo φ ≈ 1,618."
        )
    }
}
