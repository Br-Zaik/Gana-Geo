package com.ganageo.app.ui.tools

import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.GraphExportUtils
import com.ganageo.app.tools.MathEngine
import com.ganageo.app.tools.NumericCalculus
import com.ganageo.app.tools.PlotEngine
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

private val plotColors = listOf(
    Color(0xFFB7FF00),
    Color(0xFF4FC3F7),
    Color(0xFFFF7AB6)
)

/**
 * Graficador de funciones.
 *
 * La gráfica manda: ocupa toda la parte de arriba y se maneja con los dedos,
 * pellizcando para acercar y arrastrando para moverse. Los controles viven abajo
 * en pestañas para no robarle espacio a la curva.
 */
@Composable
fun FunctionGrapherScreen(onBack: () -> Unit) {
    var expressions by remember {
        mutableStateOf(listOf(TextFieldValue("sin(x)"), TextFieldValue(""), TextFieldValue("")))
    }
    var xMin by rememberSaveable { mutableStateOf(-10.0) }
    var xMax by rememberSaveable { mutableStateOf(10.0) }
    var yMin by rememberSaveable { mutableStateOf(-6.0) }
    var yMax by rememberSaveable { mutableStateOf(6.0) }
    var degrees by rememberSaveable { mutableStateOf(false) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var traceX by remember { mutableStateOf<Double?>(null) }
    var xMinText by rememberSaveable { mutableStateOf("-10") }
    var xMaxText by rememberSaveable { mutableStateOf("10") }
    var yMinText by rememberSaveable { mutableStateOf("-6") }
    var yMaxText by rememberSaveable { mutableStateOf("6") }
    var showTangent by rememberSaveable { mutableStateOf(false) }

    val active = expressions.map { it.text.trim() }.filter { it.isNotEmpty() }

    val compiled = remember(active, degrees) {
        active.map { text ->
            runCatching { MathEngine.compile(text, "x", degrees) }.getOrNull()
        }
    }
    val parseError = remember(active, degrees) {
        active.withIndex().firstOrNull { (index, _) -> compiled.getOrNull(index) == null }
            ?.let { "No se entiende «${it.value}». Revisa paréntesis y funciones." }
    }

    val segments = remember(compiled, xMin, xMax, yMin, yMax) {
        compiled.map { f ->
            if (f == null) emptyList() else PlotEngine.sample(f, xMin, xMax, yMin, yMax)
        }
    }

    val highlights = remember(compiled, xMin, xMax) {
        compiled.firstOrNull()?.let { PlotEngine.highlights(it, xMin, xMax) }
    }

    fun zoomBy(factor: Double) {
        val cx = (xMin + xMax) / 2
        val cy = (yMin + yMax) / 2
        val halfX = (xMax - xMin) / 2 * factor
        val halfY = (yMax - yMin) / 2 * factor
        xMin = cx - halfX
        xMax = cx + halfX
        yMin = cy - halfY
        yMax = cy + halfY
    }

    fun autoFitY() {
        val f = compiled.firstOrNull() ?: return
        val range = PlotEngine.autoRangeY(f, xMin, xMax)
        yMin = range.first
        yMax = range.second
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var exportMessage by remember { mutableStateOf<String?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("image/png")
    ) { destination ->
        if (destination == null) return@rememberLauncherForActivityResult
        scope.launch {
            runCatching {
                GraphExportUtils.exportPng(
                    context,
                    destination,
                    GraphExportUtils.Config(active, xMin, xMax, yMin, yMax, degrees)
                )
            }.onSuccess { exportMessage = "Gráfica guardada como imagen." }
                .onFailure { exportMessage = it.message ?: "No se pudo guardar la gráfica." }
        }
    }

    androidx.compose.runtime.LaunchedEffect(xMin, xMax, yMin, yMax) {
        xMinText = MathEngine.formatNumber(xMin, 3)
        xMaxText = MathEngine.formatNumber(xMax, 3)
        yMinText = MathEngine.formatNumber(yMin, 3)
        yMaxText = MathEngine.formatNumber(yMax, 3)
    }

    ScienceStage(
        title = "Graficador de funciones",
        subtitle = "Pellizca para acercar y arrastra para moverte",
        onBack = onBack,
        trailing = {
            if (active.isNotEmpty()) {
                IconButton(onClick = { exportLauncher.launch("grafica.png") }) {
                    Icon(
                        Icons.Rounded.Download,
                        contentDescription = "Guardar como imagen",
                        tint = StudioTheme.TextPrimary
                    )
                }
            }
        },
        stage = {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { centroid, pan, zoom, _ ->
                            val width = size.width.toFloat().coerceAtLeast(1f)
                            val height = size.height.toFloat().coerceAtLeast(1f)
                            val spanX = xMax - xMin
                            val spanY = yMax - yMin

                            // Arrastrar mueve la ventana en unidades de la gráfica.
                            val dx = -pan.x / width * spanX
                            val dy = pan.y / height * spanY
                            var newXMin = xMin + dx
                            var newXMax = xMax + dx
                            var newYMin = yMin + dy
                            var newYMax = yMax + dy

                            if (zoom != 1f) {
                                // El pellizco acerca respecto del punto que se toca,
                                // no del centro, que es lo que espera la mano.
                                val focusX = newXMin + centroid.x / width * (newXMax - newXMin)
                                val focusY = newYMax - centroid.y / height * (newYMax - newYMin)
                                val factor = (1f / zoom).toDouble().coerceIn(0.2, 5.0)
                                newXMin = focusX - (focusX - newXMin) * factor
                                newXMax = focusX + (newXMax - focusX) * factor
                                newYMin = focusY - (focusY - newYMin) * factor
                                newYMax = focusY + (newYMax - focusY) * factor
                            }
                            if (newXMax - newXMin > 1e-6 && newYMax - newYMin > 1e-6 &&
                                newXMax - newXMin < 1e9 && newYMax - newYMin < 1e9
                            ) {
                                xMin = newXMin
                                xMax = newXMax
                                yMin = newYMin
                                yMax = newYMax
                            }
                        }
                    }
                    .pointerInput(xMin, xMax) {
                        detectTapGestures { offset ->
                            val width = size.width.toFloat().coerceAtLeast(1f)
                            traceX = xMin + offset.x / width * (xMax - xMin)
                        }
                    }
            ) {
                drawGraph(
                    segments = segments,
                    xMin = xMin,
                    xMax = xMax,
                    yMin = yMin,
                    yMax = yMax,
                    highlights = highlights,
                    traceX = traceX,
                    traceFunction = compiled.firstOrNull(),
                    showTangent = showTangent
                )
            }

            if (active.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Escribe una función para empezar",
                        color = StudioTheme.TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                GraphMiniButton("−") { zoomBy(1.4) }
                GraphMiniButton("+") { zoomBy(0.7) }
                GraphMiniButton("⤢") {
                    xMin = -10.0; xMax = 10.0; yMin = -6.0; yMax = 6.0
                }
            }

            traceX?.let { x ->
                val f = compiled.firstOrNull()
                val y = f?.invoke(x)
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                        .background(Color(0xCC0B0E14))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        if (y != null && y.isFinite()) {
                            "x = ${MathEngine.formatNumber(x, 4)}   y = ${MathEngine.formatNumber(y, 4)}"
                        } else {
                            "x = ${MathEngine.formatNumber(x, 4)}   y indefinido"
                        },
                        color = StudioTheme.TextPrimary,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        },
        panel = {
            StudioPanel(maxHeight = 300.dp) {
                when (tab) {
                    0 -> {
                        expressions.forEachIndexed { index, value ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clip(CircleShape)
                                        .background(plotColors[index % plotColors.size])
                                )
                                Spacer(Modifier.width(10.dp))
                                Box(modifier = Modifier.weight(1f)) {
                                    MathInput(
                                        value = value,
                                        onValueChange = { updated ->
                                            expressions = expressions.toMutableList().also { it[index] = updated }
                                        },
                                        label = "f${index + 1}(x)",
                                        placeholder = if (index == 0) "sin(x)" else "opcional"
                                    )
                                }
                                if (value.text.isNotEmpty()) {
                                    IconButton(onClick = {
                                        expressions = expressions.toMutableList()
                                            .also { it[index] = TextFieldValue("") }
                                    }) {
                                        Icon(
                                            Icons.Rounded.Delete,
                                            contentDescription = "Quitar",
                                            tint = StudioTheme.TextSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                        parseError?.let { ScienceError(it) }
                        exportMessage?.let { StudioHint(it) }
                        StudioChipRow {
                            listOf(
                                "x^2", "sin(x)", "1/x", "tan(x)", "ln(x)", "e^x", "sqrt(x)", "abs(x)"
                            ).forEach { sample ->
                                StudioChip(sample, false, onClick = {
                                    val slot = expressions.indexOfFirst { it.text.isBlank() }
                                        .takeIf { it >= 0 } ?: 0
                                    expressions = expressions.toMutableList()
                                        .also { it[slot] = TextFieldValue(sample) }
                                })
                            }
                        }
                    }

                    1 -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ScienceNumberField(xMinText, { xMinText = it }, "x mínimo", Modifier.weight(1f))
                            ScienceNumberField(xMaxText, { xMaxText = it }, "x máximo", Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ScienceNumberField(yMinText, { yMinText = it }, "y mínimo", Modifier.weight(1f))
                            ScienceNumberField(yMaxText, { yMaxText = it }, "y máximo", Modifier.weight(1f))
                        }
                        StudioChipRow {
                            StudioChip("Aplicar vista", false, onClick = {
                                val nxMin = xMinText.toScienceDouble()
                                val nxMax = xMaxText.toScienceDouble()
                                val nyMin = yMinText.toScienceDouble()
                                val nyMax = yMaxText.toScienceDouble()
                                if (nxMin != null && nxMax != null && nxMax > nxMin) {
                                    xMin = nxMin
                                    xMax = nxMax
                                }
                                if (nyMin != null && nyMax != null && nyMax > nyMin) {
                                    yMin = nyMin
                                    yMax = nyMax
                                }
                            })
                            StudioChip("Ajustar Y a la curva", false, onClick = { autoFitY() })
                            StudioChip(
                                label = if (degrees) "Grados" else "Radianes",
                                active = degrees,
                                onClick = { degrees = !degrees }
                            )
                            StudioChip("Tangente", showTangent, onClick = { showTangent = !showTangent })
                            StudioChip("Quitar trazo", false, onClick = { traceX = null })
                        }
                        StudioHint("Toca la gráfica para leer un punto. Con «Tangente» activa se dibuja la recta tangente en ese punto.")
                    }

                    else -> {
                        val h = highlights
                        if (h == null) {
                            StudioHint("Escribe una función para ver su análisis.")
                        } else {
                            ScienceRow(
                                "Raíces (corta el eje X)",
                                if (h.roots.isEmpty()) "ninguna a la vista"
                                else h.roots.joinToString(", ") { MathEngine.formatNumber(it, 4) }
                            )
                            ScienceRow(
                                "Corte con el eje Y",
                                h.yIntercept?.let { MathEngine.formatNumber(it, 4) } ?: "—"
                            )
                            ScienceRow(
                                "Máximos locales",
                                if (h.maxima.isEmpty()) "—"
                                else h.maxima.joinToString(", ") {
                                    "(${MathEngine.formatNumber(it.x, 2)}, ${MathEngine.formatNumber(it.y, 2)})"
                                }
                            )
                            ScienceRow(
                                "Mínimos locales",
                                if (h.minima.isEmpty()) "—"
                                else h.minima.joinToString(", ") {
                                    "(${MathEngine.formatNumber(it.x, 2)}, ${MathEngine.formatNumber(it.y, 2)})"
                                }
                            )
                            val f = compiled.firstOrNull()
                            if (f != null && compiled.size >= 2) {
                                val g = compiled[1]
                                if (g != null) {
                                    val points = PlotEngine.intersections(f, g, xMin, xMax)
                                    ScienceRow(
                                        "Cortes entre f1 y f2",
                                        if (points.isEmpty()) "—"
                                        else points.joinToString(", ") {
                                            "(${MathEngine.formatNumber(it.x, 2)}, ${MathEngine.formatNumber(it.y, 2)})"
                                        }
                                    )
                                }
                            }
                            traceX?.let { x ->
                                if (f != null) {
                                    val slope = NumericCalculus.derivativeAt(f, x)
                                    ScienceRow(
                                        "Pendiente en x = ${MathEngine.formatNumber(x, 3)}",
                                        MathEngine.formatNumber(slope, 4),
                                        highlight = true
                                    )
                                }
                            }
                            if (f != null) {
                                val area = NumericCalculus.integrate(f, xMin, xMax, 1200)
                                ScienceRow(
                                    "Área bajo la curva en la vista",
                                    if (area.isFinite()) MathEngine.formatNumber(area, 4) else "—"
                                )
                            }
                            StudioHint("Los valores se calculan sobre el tramo visible: al moverte por la gráfica se actualizan.")
                        }
                    }
                }
            }
            StudioTabs(listOf("Funciones", "Vista", "Análisis"), tab) { tab = it }
        }
    )
}

@Composable
private fun GraphMiniButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
            .background(Color(0xCC0B0E14))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = StudioTheme.TextPrimary, fontWeight = FontWeight.Bold)
    }
}

/** Dibujo de la gráfica: rejilla, ejes, curvas y puntos notables. */
private fun DrawScope.drawGraph(
    segments: List<List<List<com.ganageo.app.tools.PlotPoint>>>,
    xMin: Double,
    xMax: Double,
    yMin: Double,
    yMax: Double,
    highlights: PlotEngine.Highlights?,
    traceX: Double?,
    traceFunction: ((Double) -> Double)?,
    showTangent: Boolean
) {
    val width = size.width
    val height = size.height
    val spanX = (xMax - xMin).takeIf { it > 0 } ?: return
    val spanY = (yMax - yMin).takeIf { it > 0 } ?: return

    fun toScreenX(x: Double) = ((x - xMin) / spanX * width).toFloat()
    fun toScreenY(y: Double) = (height - (y - yMin) / spanY * height).toFloat()

    val gridColor = Color(0xFF1E2634)
    val axisColor = Color(0xFF5C6B85)

    val stepX = PlotEngine.niceStep(spanX)
    val stepY = PlotEngine.niceStep(spanY, 6)

    val labelPaint = Paint().apply {
        color = android.graphics.Color.parseColor("#7A8AA5")
        textSize = 26f
        isAntiAlias = true
        typeface = Typeface.DEFAULT
    }

    // Rejilla vertical
    var gx = floor(xMin / stepX) * stepX
    while (gx <= xMax) {
        val screenX = toScreenX(gx)
        drawLine(gridColor, Offset(screenX, 0f), Offset(screenX, height), strokeWidth = 1f)
        if (abs(gx) > stepX * 0.001) {
            drawContext.canvas.nativeCanvas.drawText(
                PlotEngine.formatTick(gx, stepX),
                screenX + 4f,
                toScreenY(0.0).coerceIn(24f, height - 8f),
                labelPaint
            )
        }
        gx += stepX
    }

    // Rejilla horizontal
    var gy = floor(yMin / stepY) * stepY
    while (gy <= yMax) {
        val screenY = toScreenY(gy)
        drawLine(gridColor, Offset(0f, screenY), Offset(width, screenY), strokeWidth = 1f)
        if (abs(gy) > stepY * 0.001) {
            drawContext.canvas.nativeCanvas.drawText(
                PlotEngine.formatTick(gy, stepY),
                toScreenX(0.0).coerceIn(6f, width - 70f) + 6f,
                screenY - 6f,
                labelPaint
            )
        }
        gy += stepY
    }

    // Ejes
    if (0.0 in yMin..yMax) {
        val axisY = toScreenY(0.0)
        drawLine(axisColor, Offset(0f, axisY), Offset(width, axisY), strokeWidth = 2.5f)
    }
    if (0.0 in xMin..xMax) {
        val axisX = toScreenX(0.0)
        drawLine(axisColor, Offset(axisX, 0f), Offset(axisX, height), strokeWidth = 2.5f)
    }

    // Curvas
    segments.forEachIndexed { index, curve ->
        val color = plotColors[index % plotColors.size]
        curve.forEach { piece ->
            if (piece.size < 2) return@forEach
            val path = Path()
            piece.forEachIndexed { pointIndex, point ->
                val sx = toScreenX(point.x)
                val sy = toScreenY(point.y)
                if (pointIndex == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)
            }
            drawPath(path, color, style = Stroke(width = 3.5f))
        }
    }

    // Puntos notables de la primera función
    highlights?.let { h ->
        h.roots.forEach { x ->
            drawCircle(Color.White, radius = 7f, center = Offset(toScreenX(x), toScreenY(0.0)))
            drawCircle(Color(0xFF10141C), radius = 4f, center = Offset(toScreenX(x), toScreenY(0.0)))
        }
        (h.maxima + h.minima).forEach { point ->
            drawCircle(
                Color(0xFFFFC542),
                radius = 6f,
                center = Offset(toScreenX(point.x), toScreenY(point.y))
            )
        }
    }

    // Punto trazado y recta tangente
    if (traceX != null && traceFunction != null) {
        val y = traceFunction(traceX)
        val sx = toScreenX(traceX)
        drawLine(Color(0x66FFFFFF), Offset(sx, 0f), Offset(sx, height), strokeWidth = 1.5f)
        if (y.isFinite()) {
            val sy = toScreenY(y)
            if (showTangent) {
                val tangent = PlotEngine.tangentAt(traceFunction, traceX)
                if (tangent != null) {
                    val (slope, intercept) = tangent
                    val y1 = slope * xMin + intercept
                    val y2 = slope * xMax + intercept
                    drawLine(
                        Color(0xFFFFC542),
                        Offset(toScreenX(xMin), toScreenY(y1)),
                        Offset(toScreenX(xMax), toScreenY(y2)),
                        strokeWidth = 2f
                    )
                }
            }
            drawCircle(Color.White, radius = 8f, center = Offset(sx, sy))
            drawCircle(plotColors[0], radius = 5f, center = Offset(sx, sy))
        }
    }
}
