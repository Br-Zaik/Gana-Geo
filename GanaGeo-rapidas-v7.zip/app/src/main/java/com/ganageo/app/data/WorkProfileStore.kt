package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.workProfileDataStore by preferencesDataStore(name = "gana_geo_work_profile")
private val Context.inventoryMovesDataStore by preferencesDataStore(name = "gana_geo_inventory_moves")

/**
 * Datos del negocio del usuario.
 *
 * Se escriben una sola vez y se reutilizan en cada cotización y en cada reporte.
 * Todo queda en el teléfono: no se envía a ningún servidor.
 */
@Serializable
data class WorkProfile(
    val businessName: String = "",
    val taxId: String = "",
    val address: String = "",
    val phone: String = "",
    val email: String = "",
    val countryCode: String = "PE",
    val currencyCode: String = "PEN",
    val taxPercent: String = "18",
    val quoteSeries: String = "COT",
    val nextQuoteNumber: Int = 1,
    val quoteValidityDays: Int = 15,
    val paymentTerms: String = "50 % adelanto y 50 % contra entrega"
)

class WorkProfileStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val profile: Flow<WorkProfile> = context.workProfileDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            prefs[DATA_KEY]?.let { raw ->
                runCatching { json.decodeFromString<WorkProfile>(raw) }.getOrNull()
            } ?: WorkProfile()
        }

    suspend fun save(profile: WorkProfile) {
        context.workProfileDataStore.edit { prefs ->
            prefs[DATA_KEY] = json.encodeToString(
                profile.copy(
                    businessName = profile.businessName.trim().take(120),
                    taxId = profile.taxId.trim().take(20),
                    address = profile.address.trim().take(200),
                    phone = profile.phone.trim().take(40),
                    email = profile.email.trim().take(120),
                    quoteSeries = profile.quoteSeries.trim().uppercase().take(4).ifBlank { "COT" },
                    nextQuoteNumber = profile.nextQuoteNumber.coerceIn(1, 999_999)
                )
            )
        }
    }

    /** Avanza el correlativo tras generar una cotización. */
    suspend fun consumeQuoteNumber() {
        context.workProfileDataStore.edit { prefs ->
            val current = prefs[DATA_KEY]?.let {
                runCatching { json.decodeFromString<WorkProfile>(it) }.getOrNull()
            } ?: WorkProfile()
            prefs[DATA_KEY] = json.encodeToString(
                current.copy(nextQuoteNumber = (current.nextQuoteNumber + 1).coerceAtMost(999_999))
            )
        }
    }

    private companion object {
        val DATA_KEY = stringPreferencesKey("profile")
    }
}

/**
 * Movimiento de inventario (kardex).
 *
 * Guardar el historial es lo que permite valorizar el stock y saber cuánto costó
 * de verdad lo que se vendió, en vez de adivinar con el último precio de compra.
 */
@Serializable
data class InventoryMovement(
    val id: String = UUID.randomUUID().toString(),
    val itemId: String,
    val itemName: String,
    val type: String,
    val quantity: Double,
    val unitCostCents: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

class InventoryMovementStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val movements: Flow<List<InventoryMovement>> = context.inventoryMovesDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs -> decode(prefs[DATA_KEY]).sortedByDescending { it.createdAt } }

    suspend fun add(
        itemId: String,
        itemName: String,
        type: String,
        quantity: Double,
        unitCost: Double,
        note: String = ""
    ) {
        val cleanType = type.trim().lowercase()
        require(cleanType == "entrada" || cleanType == "salida" || cleanType == "ajuste") { "Tipo inválido" }
        require(quantity.isFinite() && quantity > 0) { "La cantidad debe ser mayor que cero" }
        require(unitCost.isFinite() && unitCost >= 0) { "Costo inválido" }
        update { current ->
            (current + InventoryMovement(
                itemId = itemId,
                itemName = itemName.take(160),
                type = cleanType,
                quantity = quantity,
                unitCostCents = kotlin.math.round(unitCost * 100.0).toLong(),
                note = note.trim().take(160)
            )).takeLast(MAX_MOVEMENTS)
        }
    }

    suspend fun deleteForItem(itemId: String) = update { current -> current.filterNot { it.itemId == itemId } }

    suspend fun clear() = update { emptyList() }

    private suspend fun update(transform: (List<InventoryMovement>) -> List<InventoryMovement>) {
        context.inventoryMovesDataStore.edit { prefs ->
            prefs[DATA_KEY] = json.encodeToString(transform(decode(prefs[DATA_KEY])))
        }
    }

    private fun decode(raw: String?): List<InventoryMovement> = raw?.let {
        runCatching { json.decodeFromString<List<InventoryMovement>>(it) }.getOrNull()
    }.orEmpty()

    private companion object {
        val DATA_KEY = stringPreferencesKey("movements")
        const val MAX_MOVEMENTS = 4000
    }
}
