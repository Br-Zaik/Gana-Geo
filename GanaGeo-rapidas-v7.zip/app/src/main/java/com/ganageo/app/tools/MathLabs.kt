package com.ganageo.app.tools

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow

// ---------------------------------------------------------------------------
// Conversor de unidades
// ---------------------------------------------------------------------------

/**
 * Unidad de medida.
 *
 * La conversión es afín: valor_base = valor · factor + desplazamiento. El
 * desplazamiento solo lo usan las escalas de temperatura, que no comparten el
 * cero. Por eso no se puede pasar de grados Celsius a Fahrenheit con un simple
 * factor, como sí se hace con metros y pies.
 */
data class MeasureUnit(
    val name: String,
    val symbol: String,
    val factor: Double,
    val offset: Double = 0.0,
    val note: String = "",
    val regional: String = ""
)

data class MeasureCategory(
    val name: String,
    val baseSymbol: String,
    val units: List<MeasureUnit>
)

object UnitLab {

    private fun u(name: String, symbol: String, factor: Double, note: String = "", regional: String = "") =
        MeasureUnit(name, symbol, factor, 0.0, note, regional)

    val categories: List<MeasureCategory> = listOf(
        MeasureCategory(
            "Longitud", "m",
            listOf(
                u("Metro", "m", 1.0),
                u("Kilómetro", "km", 1000.0),
                u("Centímetro", "cm", 0.01),
                u("Milímetro", "mm", 0.001),
                u("Micrómetro", "µm", 1e-6),
                u("Pulgada", "in", 0.0254, "Exacto: 1 pulgada = 25,4 mm"),
                u("Pie", "ft", 0.3048, "Exacto"),
                u("Yarda", "yd", 0.9144, "Exacto"),
                u("Milla", "mi", 1609.344, "Exacto"),
                u("Milla náutica", "nmi", 1852.0, "Exacto"),
                u("Vara", "vara", 0.8359, "Valor castellano", "Varía por país"),
                u("Cuadra", "cuadra", 86.6, "100 varas", "En Argentina, Chile y Bolivia son 150 varas ≈ 129,9 m"),
                u("Legua", "legua", 5572.7, "", "Varía por país")
            )
        ),
        MeasureCategory(
            "Superficie", "m²",
            listOf(
                u("Metro cuadrado", "m²", 1.0),
                u("Kilómetro cuadrado", "km²", 1e6),
                u("Centímetro cuadrado", "cm²", 1e-4),
                u("Hectárea", "ha", 10000.0),
                u("Área", "a", 100.0),
                u("Pie cuadrado", "ft²", 0.09290304, "Exacto"),
                u("Pulgada cuadrada", "in²", 0.00064516, "Exacto"),
                u("Acre", "ac", 4046.8564224, "Exacto"),
                u("Milla cuadrada", "mi²", 2589988.110336, "Exacto"),
                u("Topo", "topo", 2500.0, "Medida agraria", "Perú; varía por región"),
                u("Fanega", "fanega", 6666.0, "≈ 2/3 de hectárea", "Varía por región")
            )
        ),
        MeasureCategory(
            "Volumen", "L",
            listOf(
                u("Litro", "L", 1.0),
                u("Mililitro", "mL", 0.001),
                u("Metro cúbico", "m³", 1000.0),
                u("Centímetro cúbico", "cm³", 0.001),
                u("Galón EE. UU.", "gal US", 3.785411784, "Exacto: 231 pulgadas cúbicas"),
                u("Galón imperial", "gal imp", 4.54609, "Exacto. Es un 20 % mayor que el estadounidense"),
                u("Onza líquida EE. UU.", "fl oz US", 0.0295735295625, "Exacto"),
                u("Onza líquida imperial", "fl oz imp", 0.0284130625, "Exacto"),
                u("Pinta EE. UU.", "pt US", 0.473176473, "Exacto"),
                u("Barril de petróleo", "bbl", 158.987294928, "Exacto"),
                u("Pie cúbico", "ft³", 28.316846592, "Exacto"),
                u("Taza (cocina)", "taza", 0.24, "Taza métrica de 240 mL"),
                u("Cucharada", "cda", 0.015, "15 mL"),
                u("Cucharadita", "cdta", 0.005, "5 mL")
            )
        ),
        MeasureCategory(
            "Masa", "kg",
            listOf(
                u("Kilogramo", "kg", 1.0),
                u("Gramo", "g", 0.001),
                u("Miligramo", "mg", 1e-6),
                u("Tonelada métrica", "t", 1000.0),
                u("Libra", "lb", 0.45359237, "Exacto por acuerdo internacional de 1959"),
                u("Onza", "oz", 0.028349523125, "Exacto: 1/16 de libra"),
                u("Stone", "st", 6.35029318, "Exacto: 14 libras"),
                u("Tonelada corta", "ton US", 907.18474, "Exacto: 2000 libras"),
                u("Tonelada larga", "ton UK", 1016.0469088, "Exacto: 2240 libras"),
                u("Quintal métrico", "qm", 100.0),
                u("Quintal", "qq", 46.0, "Castellano: 4 arrobas", "Varía por país"),
                u("Arroba", "@", 11.502, "≈ 25 libras", "Varía por país")
            )
        ),
        MeasureCategory(
            "Temperatura", "K",
            listOf(
                MeasureUnit("Celsius", "°C", 1.0, 273.15, "El cero no coincide con el del kelvin"),
                MeasureUnit("Kelvin", "K", 1.0, 0.0, "Escala absoluta del SI"),
                MeasureUnit("Fahrenheit", "°F", 5.0 / 9.0, 459.67 * 5.0 / 9.0, "F = C × 9/5 + 32"),
                MeasureUnit("Rankine", "°R", 5.0 / 9.0, 0.0)
            )
        ),
        MeasureCategory(
            "Tiempo", "s",
            listOf(
                u("Segundo", "s", 1.0),
                u("Minuto", "min", 60.0),
                u("Hora", "h", 3600.0),
                u("Día", "d", 86400.0),
                u("Semana", "sem", 604800.0),
                u("Mes (30 días)", "mes", 2592000.0),
                u("Año (365 días)", "año", 31536000.0),
                u("Milisegundo", "ms", 0.001)
            )
        ),
        MeasureCategory(
            "Velocidad", "m/s",
            listOf(
                u("Metro por segundo", "m/s", 1.0),
                u("Kilómetro por hora", "km/h", 1.0 / 3.6),
                u("Milla por hora", "mph", 0.44704, "Exacto"),
                u("Nudo", "kn", 1852.0 / 3600.0, "Una milla náutica por hora"),
                u("Pie por segundo", "ft/s", 0.3048)
            )
        ),
        MeasureCategory(
            "Presión", "Pa",
            listOf(
                u("Pascal", "Pa", 1.0),
                u("Kilopascal", "kPa", 1000.0),
                u("Bar", "bar", 100000.0),
                u("Atmósfera", "atm", 101325.0, "Exacto"),
                u("Milímetro de mercurio", "mmHg", 133.322387415),
                u("Libra por pulgada cuadrada", "psi", 6894.757293168)
            )
        ),
        MeasureCategory(
            "Energía", "J",
            listOf(
                u("Julio", "J", 1.0),
                u("Kilojulio", "kJ", 1000.0),
                u("Caloría", "cal", 4.184, "Caloría termoquímica"),
                u("Kilocaloría", "kcal", 4184.0, "La «caloría» de los alimentos"),
                u("Vatio-hora", "Wh", 3600.0),
                u("Kilovatio-hora", "kWh", 3.6e6, "La unidad del recibo de luz"),
                u("BTU", "BTU", 1055.05585262),
                u("Electronvoltio", "eV", 1.602176634e-19, "Exacto desde la redefinición del SI")
            )
        ),
        MeasureCategory(
            "Potencia", "W",
            listOf(
                u("Vatio", "W", 1.0),
                u("Kilovatio", "kW", 1000.0),
                u("Caballo de vapor", "CV", 735.49875, "Métrico"),
                u("Horsepower", "hp", 745.6998715823, "Mecánico"),
                u("BTU por hora", "BTU/h", 0.29307107017)
            )
        ),
        MeasureCategory(
            "Datos digitales", "B",
            listOf(
                u("Byte", "B", 1.0),
                u("Kilobyte", "kB", 1000.0, "Decimal (SI): 1000 bytes"),
                u("Megabyte", "MB", 1e6, "Decimal (SI)"),
                u("Gigabyte", "GB", 1e9, "Decimal (SI). Es el que usan los fabricantes de discos"),
                u("Terabyte", "TB", 1e12, "Decimal (SI)"),
                u("Kibibyte", "KiB", 1024.0, "Binario (IEC): 1024 bytes"),
                u("Mebibyte", "MiB", 1048576.0, "Binario (IEC)"),
                u("Gibibyte", "GiB", 1073741824.0, "Binario (IEC). Es el que muestra Windows como «GB»"),
                u("Tebibyte", "TiB", 1.099511627776e12, "Binario (IEC)"),
                u("Bit", "bit", 0.125)
            )
        ),
        MeasureCategory(
            "Ángulo", "rad",
            listOf(
                u("Radián", "rad", 1.0),
                u("Grado", "°", PI / 180.0),
                u("Gradián", "gon", PI / 200.0),
                u("Vuelta", "vuelta", 2 * PI),
                u("Minuto de arco", "′", PI / 10800.0),
                u("Segundo de arco", "″", PI / 648000.0)
            )
        )
    )

    fun category(name: String): MeasureCategory =
        categories.firstOrNull { it.name == name } ?: categories.first()

    /** Convierte un valor absoluto entre dos unidades pasando por la base interna. */
    fun convert(value: Double, from: MeasureUnit, to: MeasureUnit): Double {
        val base = value * from.factor + from.offset
        return (base - to.offset) / to.factor
    }

    /**
     * Convierte una DIFERENCIA de temperatura.
     *
     * Aquí no se aplica el desplazamiento: una diferencia de 5 °C es una
     * diferencia de 9 °F, no de 41. Confundir el valor con la diferencia es el
     * error clásico al convertir temperaturas.
     */
    fun convertDifference(value: Double, from: MeasureUnit, to: MeasureUnit): Double =
        value * from.factor / to.factor

    /** Redondea a cifras significativas, que es lo que espera quien convierte medidas. */
    fun format(value: Double, significant: Int = 6): String {
        if (!value.isFinite()) return "—"
        if (value == 0.0) return "0"
        val magnitude = floor(log10(abs(value))).toInt()
        if (magnitude >= 12 || magnitude <= -6) {
            return String.format("%.4e", value).replace("e", " × 10^")
        }
        val decimals = (significant - 1 - magnitude).coerceIn(0, 10)
        var text = BigDecimal(value).setScale(decimals, RoundingMode.HALF_UP).toPlainString()
        if (text.contains('.')) text = text.trimEnd('0').trimEnd('.')
        return text
    }

    /** Aviso cuando la unidad cambia de valor según el país. */
    fun regionalWarning(from: MeasureUnit, to: MeasureUnit): String? {
        val notes = listOfNotNull(
            from.regional.takeIf { it.isNotBlank() }?.let { "${from.name}: $it" },
            to.regional.takeIf { it.isNotBlank() }?.let { "${to.name}: $it" }
        )
        return notes.takeIf { it.isNotEmpty() }?.joinToString(" · ")
    }
}

// ---------------------------------------------------------------------------
// Porcentajes y regla de tres
// ---------------------------------------------------------------------------

data class PercentStep(val title: String, val expression: String, val explanation: String)

data class PercentAnswer(val headline: String, val steps: List<PercentStep>, val note: String = "")

object PercentLab {

    private fun n(value: Double) = MathEngine.formatNumber(value, 4)

    fun percentOf(total: Double, percent: Double): PercentAnswer {
        val result = total * percent / 100
        return PercentAnswer(
            headline = "${n(percent)} % de ${n(total)} = ${n(result)}",
            steps = listOf(
                PercentStep(
                    "Fórmula",
                    "resultado = total × porcentaje ÷ 100",
                    "Un porcentaje es una parte de cien."
                ),
                PercentStep(
                    "Sustitución",
                    "${n(total)} × ${n(percent)} ÷ 100 = ${n(result)}",
                    "También puedes multiplicar por ${n(percent / 100)}."
                )
            )
        )
    }

    fun whatPercent(part: Double, total: Double): PercentAnswer {
        require(total != 0.0) { "El total no puede ser cero." }
        val result = part / total * 100
        return PercentAnswer(
            headline = "${n(part)} es el ${n(result)} % de ${n(total)}",
            steps = listOf(
                PercentStep("Fórmula", "porcentaje = parte ÷ total × 100", "Se compara la parte con el total."),
                PercentStep("Sustitución", "${n(part)} ÷ ${n(total)} × 100 = ${n(result)} %", "")
            )
        )
    }

    fun change(from: Double, to: Double): PercentAnswer {
        require(from != 0.0) { "El valor inicial no puede ser cero." }
        val diff = to - from
        val percent = diff / from * 100
        val direction = if (percent >= 0) "aumento" else "disminución"
        return PercentAnswer(
            headline = "${if (percent >= 0) "+" else ""}${n(percent)} % de $direction",
            steps = listOf(
                PercentStep("Fórmula", "variación = (nuevo − viejo) ÷ viejo × 100", "Siempre se compara con el valor inicial."),
                PercentStep("Sustitución", "(${n(to)} − ${n(from)}) ÷ ${n(from)} × 100 = ${n(percent)} %", ""),
                PercentStep("Diferencia absoluta", n(diff), "Es cuánto cambió en unidades, no en porcentaje.")
            ),
            note = "Ojo: si comparas dos porcentajes, la diferencia se mide en PUNTOS porcentuales. " +
                "Pasar de 40 % a 44 % son 4 puntos, pero un aumento relativo del 10 %."
        )
    }

    fun applyChange(base: Double, percent: Double, increase: Boolean): PercentAnswer {
        val factor = if (increase) 1 + percent / 100 else 1 - percent / 100
        val result = base * factor
        val label = if (increase) "aumento" else "descuento"
        return PercentAnswer(
            headline = "${n(base)} con $label del ${n(percent)} % = ${n(result)}",
            steps = listOf(
                PercentStep(
                    "Atajo",
                    "resultado = base × ${n(factor)}",
                    if (increase) "Sumar un ${n(percent)} % es multiplicar por ${n(factor)}."
                    else "Descontar un ${n(percent)} % es multiplicar por ${n(factor)}."
                ),
                PercentStep("Diferencia", n(abs(result - base)), "Es lo que se suma o se resta.")
            )
        )
    }

    /**
     * Precio antes del descuento.
     *
     * El error más común: si al precio le quitaron un 20 %, el original NO se
     * recupera sumándole un 20 %. Hay que dividir entre 0,80.
     */
    fun originalBeforeDiscount(finalPrice: Double, discountPercent: Double): PercentAnswer {
        val factor = 1 - discountPercent / 100
        require(factor > 0) { "El descuento debe ser menor que 100 %." }
        val original = finalPrice / factor
        return PercentAnswer(
            headline = "Precio original = ${n(original)}",
            steps = listOf(
                PercentStep(
                    "Razonamiento",
                    "el precio final es el ${n(factor * 100)} % del original",
                    "Con un ${n(discountPercent)} % de descuento pagas el ${n(factor * 100)} %."
                ),
                PercentStep("Fórmula", "original = final ÷ ${n(factor)}", "Se divide, no se multiplica."),
                PercentStep("Sustitución", "${n(finalPrice)} ÷ ${n(factor)} = ${n(original)}", ""),
                PercentStep(
                    "Comprobación",
                    "${n(original)} × ${n(factor)} = ${n(original * factor)}",
                    "Coincide con el precio final."
                )
            ),
            note = "Sumarle el ${n(discountPercent)} % al precio final daría " +
                "${n(finalPrice * (1 + discountPercent / 100))}, que es incorrecto."
        )
    }

    /** Descuentos encadenados: 20 % y luego 10 % no son 30 %. */
    fun chainedDiscounts(base: Double, discounts: List<Double>): PercentAnswer {
        var current = base
        val steps = mutableListOf<PercentStep>()
        var factor = 1.0
        discounts.forEachIndexed { index, discount ->
            val f = 1 - discount / 100
            factor *= f
            val before = current
            current *= f
            steps += PercentStep(
                "Descuento ${index + 1}: ${n(discount)} %",
                "${n(before)} × ${n(f)} = ${n(current)}",
                "Cada descuento se aplica sobre lo que quedó del anterior."
            )
        }
        val equivalent = (1 - factor) * 100
        val naive = discounts.sum()
        steps += PercentStep(
            "Descuento real",
            "${n(equivalent)} %",
            "Sumar los descuentos daría ${n(naive)} %, y eso está mal."
        )
        return PercentAnswer(
            headline = "Precio final ${n(current)} · descuento real ${n(equivalent)} %",
            steps = steps,
            note = "El orden de los descuentos no cambia el resultado."
        )
    }

    /**
     * Impuesto sobre las ventas.
     *
     * Para sacar el impuesto de un precio que ya lo incluye hay que DIVIDIR
     * entre 1 más la tasa. Restarle el 18 % al total es el error más frecuente
     * en el comercio.
     */
    fun tax(amount: Double, ratePercent: Double, included: Boolean, taxName: String = "IGV"): PercentAnswer {
        val factor = 1 + ratePercent / 100
        return if (included) {
            val base = amount / factor
            val tax = amount - base
            PercentAnswer(
                headline = "Valor de venta ${n(base)} · $taxName ${n(tax)}",
                steps = listOf(
                    PercentStep(
                        "Separar el impuesto",
                        "base = total ÷ ${n(factor)}",
                        "El precio con impuesto es el ${n(factor * 100)} % de la base."
                    ),
                    PercentStep("Sustitución", "${n(amount)} ÷ ${n(factor)} = ${n(base)}", ""),
                    PercentStep("Impuesto", "${n(amount)} − ${n(base)} = ${n(tax)}", "")
                ),
                note = "Restarle el ${n(ratePercent)} % al total daría " +
                    "${n(amount * (1 - ratePercent / 100))}, que no es la base imponible."
            )
        } else {
            val tax = amount * ratePercent / 100
            PercentAnswer(
                headline = "Total ${n(amount + tax)} · $taxName ${n(tax)}",
                steps = listOf(
                    PercentStep("Impuesto", "${n(amount)} × ${n(ratePercent / 100)} = ${n(tax)}", ""),
                    PercentStep("Total", "${n(amount)} + ${n(tax)} = ${n(amount + tax)}", "")
                )
            )
        }
    }

    /** Regla de tres simple. Directa: a más, más. Inversa: a más, menos. */
    fun ruleOfThree(a: Double, b: Double, c: Double, direct: Boolean): PercentAnswer {
        require(a != 0.0) { "El primer valor no puede ser cero." }
        val result = if (direct) b * c / a else a * b / c
        val steps = if (direct) {
            listOf(
                PercentStep(
                    "Planteamiento",
                    "$a → $b\n$c → x",
                    "Es directa: si el primer valor crece, el segundo también."
                ),
                PercentStep("Despeje", "x = ($b × $c) ÷ $a", "Se multiplica en cruz."),
                PercentStep("Resultado", "x = ${n(result)}", "")
            )
        } else {
            listOf(
                PercentStep(
                    "Planteamiento",
                    "$a → $b\n$c → x",
                    "Es inversa: si el primer valor crece, el segundo disminuye."
                ),
                PercentStep("Despeje", "x = ($a × $b) ÷ $c", "Se multiplica en línea, no en cruz."),
                PercentStep("Resultado", "x = ${n(result)}", "")
            )
        }
        return PercentAnswer(
            headline = "x = ${n(result)}",
            steps = steps,
            note = if (direct) "Ejemplo directo: si 2 kilos cuestan 10, 5 kilos cuestan 25."
            else "Ejemplo inverso: si 20 obreros tardan 10 días, 40 obreros tardan 5."
        )
    }

    data class CompoundMagnitude(
        val name: String,
        val known: Double,
        val target: Double,
        val direct: Boolean
    )

    /**
     * Regla de tres compuesta.
     *
     * Se decide magnitud por magnitud si es directa o inversa respecto de la
     * incógnita, y se van multiplicando las razones.
     */
    fun compoundRule(base: Double, magnitudes: List<CompoundMagnitude>): PercentAnswer {
        require(magnitudes.isNotEmpty()) { "Agrega al menos una magnitud." }
        var result = base
        val steps = mutableListOf<PercentStep>()
        steps += PercentStep(
            "Valor conocido",
            n(base),
            "Es el dato del que se parte."
        )
        magnitudes.forEach { magnitude ->
            require(magnitude.known != 0.0 && magnitude.target != 0.0) {
                "Los valores de ${magnitude.name} no pueden ser cero."
            }
            val ratio = if (magnitude.direct) magnitude.target / magnitude.known
            else magnitude.known / magnitude.target
            val before = result
            result *= ratio
            steps += PercentStep(
                "${magnitude.name} (${if (magnitude.direct) "directa" else "inversa"})",
                "${n(before)} × ${n(ratio)} = ${n(result)}",
                if (magnitude.direct)
                    "Al pasar de ${n(magnitude.known)} a ${n(magnitude.target)}, el resultado crece en la misma proporción."
                else
                    "Al pasar de ${n(magnitude.known)} a ${n(magnitude.target)}, el resultado cambia en proporción contraria."
            )
        }
        return PercentAnswer(
            headline = "Resultado = ${n(result)}",
            steps = steps,
            note = "Más obreros hacen la obra en menos días: esa magnitud es inversa. " +
                "Más días de trabajo producen más metros: esa es directa."
        )
    }

    /** Reparto proporcional de una cantidad según partes. */
    fun proportionalShare(total: Double, parts: List<Pair<String, Double>>): PercentAnswer {
        val sum = parts.sumOf { it.second }
        require(sum > 0) { "La suma de las partes debe ser mayor que cero." }
        val steps = parts.map { (name, weight) ->
            val amount = total * weight / sum
            PercentStep(
                name,
                "${n(total)} × ${n(weight)} ÷ ${n(sum)} = ${n(amount)}",
                "Le corresponde el ${n(weight / sum * 100)} % del total."
            )
        }
        return PercentAnswer(
            headline = "Repartido entre ${parts.size} partes",
            steps = steps
        )
    }
}

// ---------------------------------------------------------------------------
// Promedios
// ---------------------------------------------------------------------------

data class AverageSet(
    val arithmetic: Double,
    val weighted: Double?,
    val geometric: Double?,
    val harmonic: Double?,
    val median: Double,
    val mode: List<Double>,
    val minimum: Double,
    val maximum: Double,
    val count: Int
)

object AverageLab {

    fun analyze(values: List<Double>, weights: List<Double>? = null): AverageSet {
        require(values.isNotEmpty()) { "Escribe al menos un valor." }
        val sorted = values.sorted()
        val arithmetic = values.average()

        val weighted = if (weights != null && weights.size == values.size && weights.sum() > 0) {
            values.indices.sumOf { values[it] * weights[it] } / weights.sum()
        } else null

        val geometric = if (values.all { it > 0 }) {
            values.fold(1.0) { acc, value -> acc * value }.pow(1.0 / values.size)
        } else null

        val harmonic = if (values.all { it > 0 }) {
            values.size / values.sumOf { 1.0 / it }
        } else null

        val median = if (sorted.size % 2 == 0) {
            (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2
        } else sorted[sorted.size / 2]

        val frequency = values.groupingBy { it }.eachCount()
        val maxFrequency = frequency.values.maxOrNull() ?: 0
        val mode = if (maxFrequency <= 1) emptyList()
        else frequency.filterValues { it == maxFrequency }.keys.sorted()

        return AverageSet(
            arithmetic = arithmetic,
            weighted = weighted,
            geometric = geometric,
            harmonic = harmonic,
            median = median,
            mode = mode,
            minimum = sorted.first(),
            maximum = sorted.last(),
            count = values.size
        )
    }

    /**
     * Qué promedio corresponde según el tipo de dato.
     *
     * Es lo que casi ninguna app explica: promediar velocidades con la media
     * aritmética da mal, y promediar porcentajes de crecimiento también.
     */
    fun advice(kind: AverageKind): String = when (kind) {
        AverageKind.SIMPLE ->
            "Media aritmética: para valores que se suman, como notas del mismo peso."
        AverageKind.WEIGHTED ->
            "Media ponderada: cuando cada valor pesa distinto, como los créditos de un curso."
        AverageKind.GEOMETRIC ->
            "Media geométrica: para tasas de crecimiento. Crecer 100 % y luego caer 50 % " +
                "no promedia 25 %: en realidad quedas igual que al inicio."
        AverageKind.HARMONIC ->
            "Media armónica: para velocidades sobre la misma distancia. Ir a 40 km/h y " +
                "volver a 60 km/h da 48 km/h de promedio, no 50."
        AverageKind.MEDIAN ->
            "Mediana: el valor del medio. Aguanta mejor los datos extremos que la media."
    }

    enum class AverageKind(val label: String) {
        SIMPLE("Simple"),
        WEIGHTED("Ponderada"),
        GEOMETRIC("Geométrica"),
        HARMONIC("Armónica"),
        MEDIAN("Mediana")
    }

    /**
     * Redondeo de notas.
     *
     * En el sistema vigesimal peruano muchos reglamentos redondean el medio
     * punto hacia arriba, pero no todos: por eso es una opción y no una regla
     * fija de la app.
     */
    fun roundGrade(value: Double, halfUp: Boolean, decimals: Int = 0): Double {
        if (!halfUp) {
            return BigDecimal(value).setScale(decimals, RoundingMode.DOWN).toDouble()
        }
        return BigDecimal(value).setScale(decimals, RoundingMode.HALF_UP).toDouble()
    }

    /** Promedio quitando la peor nota, que muchos sílabos permiten. */
    fun dropLowest(values: List<Double>, howMany: Int = 1): Double {
        require(values.size > howMany) { "No puedes eliminar más notas de las que tienes." }
        return values.sorted().drop(howMany).average()
    }

    /** Nota necesaria en lo que falta para alcanzar el objetivo. */
    fun neededScore(currentPoints: Double, remainingWeight: Double, target: Double): Double {
        require(remainingWeight > 0) { "No queda evaluación pendiente." }
        return (target * 100 - currentPoints) / remainingWeight
    }
}

// ---------------------------------------------------------------------------
// Calculadora científica
// ---------------------------------------------------------------------------

object CalculatorEngine {

    /**
     * Aplica la semántica de porcentaje de las calculadoras de bolsillo.
     *
     * En ellas «50 + 10 %» da 55, no 50,1: el porcentaje se toma sobre lo que
     * hay a la izquierda. Es lo que espera quien calcula un descuento o el IGV
     * en el mostrador.
     */
    fun applyPercentSemantics(expression: String): String {
        var result = expression
        var guard = 0
        while (result.contains('%') && guard < 40) {
            guard++
            val percentIndex = result.indexOf('%')
            var start = percentIndex - 1
            while (start >= 0 && (result[start].isDigit() || result[start] == '.')) start--
            val number = result.substring(start + 1, percentIndex)
            if (number.isEmpty()) {
                result = result.removeRange(percentIndex, percentIndex + 1)
                continue
            }
            var operatorIndex = start
            while (operatorIndex >= 0 && result[operatorIndex] == ' ') operatorIndex--
            val operator = result.getOrNull(operatorIndex)
            val prefix = if (operatorIndex >= 0) result.substring(0, operatorIndex) else ""
            val balanced = prefix.count { it == '(' } == prefix.count { it == ')' }

            val replacement = if ((operator == '+' || operator == '-') && prefix.isNotBlank() && balanced) {
                "($prefix)*($number)/100"
            } else {
                "($number)/100"
            }
            result = result.substring(0, start + 1) + replacement + result.substring(percentIndex + 1)
        }
        return result
    }

    /** Evalúa la expresión y traduce cualquier problema a un mensaje claro. */
    fun evaluate(expression: String, degrees: Boolean): Result<Double> {
        if (expression.isBlank()) return Result.failure(IllegalArgumentException("Escribe una operación."))
        val open = expression.count { it == '(' }
        val close = expression.count { it == ')' }
        if (open > close) return Result.failure(IllegalArgumentException("Falta cerrar ${open - close} paréntesis."))
        if (close > open) return Result.failure(IllegalArgumentException("Sobra un paréntesis de cierre."))

        return runCatching {
            val prepared = applyPercentSemantics(expression)
            val node = MathEngine.parse(prepared)
            val value = MathEngine.eval(node, emptyMap(), degrees)
            when {
                value.isNaN() -> throw ArithmeticException(diagnose(expression))
                value.isInfinite() -> throw ArithmeticException("El resultado es demasiado grande.")
                else -> value
            }
        }
    }

    /** Intenta explicar por qué no salió el número, en vez de mostrar «NaN». */
    private fun diagnose(expression: String): String {
        val lower = expression.lowercase()
        return when {
            Regex("/\\s*0(?![.0-9])").containsMatchIn(lower) -> "No se puede dividir entre cero."
            lower.contains("sqrt(-") || lower.contains("√(-") -> "La raíz cuadrada de un número negativo no tiene solución real."
            lower.contains("ln(0") || lower.contains("log(0") -> "El logaritmo de cero no está definido."
            lower.contains("ln(-") || lower.contains("log(-") -> "El logaritmo de un número negativo no está definido."
            lower.contains("tan(") -> "La tangente no está definida en 90° ni en sus múltiplos impares."
            lower.contains("asin(") || lower.contains("acos(") -> "El seno y el coseno inversos solo aceptan valores entre −1 y 1."
            lower.contains("!") -> "El factorial solo funciona con números enteros desde 0 hasta 170."
            else -> "La operación no tiene un resultado real."
        }
    }

    /**
     * Formato de pantalla.
     *
     * Se recorta a doce cifras significativas para que 0,1 + 0,2 muestre 0,3 y
     * no el 0,30000000000000004 que devuelve la coma flotante.
     */
    fun format(value: Double, engineering: Boolean = false): String {
        if (value.isNaN()) return "indefinido"
        if (value.isInfinite()) return if (value > 0) "∞" else "-∞"
        if (value == 0.0) return "0"

        val magnitude = floor(log10(abs(value))).toInt()
        if (engineering || magnitude >= 12 || magnitude <= -10) {
            val exponent = if (engineering) (floor(magnitude / 3.0) * 3).toInt() else magnitude
            val mantissa = value / 10.0.pow(exponent.toDouble())
            return "${trim(BigDecimal(mantissa).setScale(6, RoundingMode.HALF_UP).toPlainString())} × 10^$exponent"
        }
        val decimals = (12 - 1 - magnitude).coerceIn(0, 12)
        return trim(BigDecimal(value).setScale(decimals, RoundingMode.HALF_UP).toPlainString())
    }

    private fun trim(text: String): String =
        if (text.contains('.')) text.trimEnd('0').trimEnd('.') else text

    /** Convierte un decimal a fracción exacta cuando es razonable (tecla S↔D). */
    fun toFraction(value: Double, maxDenominator: Int = 10000): String? {
        if (!value.isFinite() || abs(value) > 1e9) return null
        if (abs(value - Math.round(value)) < 1e-12) return null
        var bestNumerator = 1L
        var bestDenominator = 1L
        var bestError = Double.MAX_VALUE
        for (denominator in 1..maxDenominator) {
            val numerator = Math.round(value * denominator)
            val error = abs(value - numerator.toDouble() / denominator)
            if (error < bestError - 1e-15) {
                bestError = error
                bestNumerator = numerator
                bestDenominator = denominator.toLong()
                if (error < 1e-12) break
            }
        }
        if (bestError > 1e-9) return null
        return "$bestNumerator/$bestDenominator"
    }
}
