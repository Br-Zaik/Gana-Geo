package com.ganageo.app.tools

import java.text.BreakIterator
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.roundToLong

/**
 * Motor del contador de palabras.
 *
 * Dos decisiones de fondo:
 *
 * 1. Se segmenta con BreakIterator (reglas Unicode) en vez de partir por
 *    espacios. Un split por espacios cuenta mal "10,000", "EE.UU.", los
 *    enlaces, los apostrofes y no separa nada en chino o japones.
 * 2. Los tiempos de lectura salen de datos reales (meta-analisis de Brysbaert,
 *    2019: 238 ppm de lectura silenciosa y 183 ppm en voz alta en ingles),
 *    ajustados al espanol, que tiene palabras mas largas.
 *
 * La legibilidad reutiliza el contador de silabas de TextLab para no tener dos
 * algoritmos distintos midiendo lo mismo en la misma app.
 */

data class WordFrequency(val word: String, val count: Int, val density: Double)

data class SmsInfo(
    val encoding: String,
    val units: Int,
    val perSegment: Int,
    val segments: Int,
    val note: String
)

data class ReadingTime(val label: String, val wordsPerMinute: Double, val seconds: Long)

data class PlatformLimitStatus(
    val group: String,
    val name: String,
    val limit: Int,
    val used: Int
) {
    val remaining: Int get() = limit - used
    val exceeded: Boolean get() = used > limit
    val ratio: Float get() = if (limit <= 0) 0f else (used.toFloat() / limit).coerceIn(0f, 1f)
}

data class DetailedTextMetrics(
    val words: Int,
    val uniqueWords: Int,
    val charactersWithSpaces: Int,
    val charactersNoSpaces: Int,
    val utf16Units: Int,
    val sentences: Int,
    val paragraphs: Int,
    val lines: Int,
    val syllables: Int,
    val longestWord: String,
    val averageWordLength: Double,
    val averageSentenceWords: Double,
    val averageSyllablesPerWord: Double,
    val fleschSzigriszt: Double,
    val fernandezHuerta: Double,
    val infleszLabel: String,
    val infleszAdvice: String,
    val topWords: List<WordFrequency>,
    val readingTimes: List<ReadingTime>,
    val sms: SmsInfo
) {
    val isEmpty: Boolean get() = words == 0 && charactersWithSpaces == 0

    companion object {
        val EMPTY = DetailedTextMetrics(
            words = 0,
            uniqueWords = 0,
            charactersWithSpaces = 0,
            charactersNoSpaces = 0,
            utf16Units = 0,
            sentences = 0,
            paragraphs = 0,
            lines = 0,
            syllables = 0,
            longestWord = "",
            averageWordLength = 0.0,
            averageSentenceWords = 0.0,
            averageSyllablesPerWord = 0.0,
            fleschSzigriszt = 0.0,
            fernandezHuerta = 0.0,
            infleszLabel = "—",
            infleszAdvice = "Escribe o pega un texto para analizarlo.",
            topWords = emptyList(),
            readingTimes = emptyList(),
            sms = SmsInfo("GSM-7", 0, 160, 0, "")
        )
    }
}

object TextMetricsEngine {

    /** Lectura silenciosa. 238 ppm del ingles, ajustado a la palabra espanola. */
    const val WPM_SILENT = 215.0

    /** Lectura en voz alta. 183 ppm del ingles, ajustado. */
    const val WPM_ALOUD = 160.0

    /** Exposicion oral tranquila, el ritmo que se recomienda al presentar. */
    const val WPM_SPEECH = 130.0

    /** Locucion tipo podcast o video, algo mas rapida que una exposicion. */
    const val WPM_PODCAST = 150.0

    private val SPANISH = Locale("es", "ES")

    private val stopWords = setOf(
        "el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "al", "a", "ante",
        "bajo", "con", "contra", "desde", "durante", "en", "entre", "hacia", "hasta", "mediante",
        "para", "por", "segun", "según", "sin", "sobre", "tras", "y", "e", "o", "u", "ni", "que",
        "qué", "como", "cómo", "cuando", "cuándo", "donde", "dónde", "porque", "pero", "aunque",
        "si", "sí", "no", "se", "su", "sus", "mi", "mis", "tu", "tus", "lo", "le", "les", "me",
        "te", "nos", "es", "son", "era", "ser", "fue", "han", "ha", "hay", "este", "esta", "estos",
        "estas", "ese", "esa", "eso", "aquel", "más", "mas", "muy", "ya", "también", "tambien",
        "todo", "toda", "todos", "todas", "otro", "otra", "cada", "the", "of", "and", "to", "in"
    )

    // GSM-7 basico (GSM 03.38). Ojo: las minusculas acentuadas del espanol
    // (a, e, i, o, u con tilde) NO estan aqui, y por eso una sola tilde
    // convierte todo el SMS a UCS-2 y recorta el mensaje de 160 a 70.
    private val gsm7Basic: Set<Char> =
        ("@£\$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?¡" +
            "ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà").toSet()

    // Caracteres que existen en GSM-7 pero ocupan dos unidades.
    private val gsm7Extended: Set<Char> = setOf('^', '{', '}', '\\', '[', '~', ']', '|', '€', '\u000C')

    /** Segmentacion de palabras por reglas Unicode. */
    fun words(text: String, locale: Locale = SPANISH): List<String> {
        if (text.isBlank()) return emptyList()
        val iterator = BreakIterator.getWordInstance(locale)
        iterator.setText(text)
        val result = mutableListOf<String>()
        var start = iterator.first()
        var end = iterator.next()
        while (end != BreakIterator.DONE) {
            val segment = text.substring(start, end)
            if (segment.any { it.isLetterOrDigit() }) result += segment
            start = end
            end = iterator.next()
        }
        return result
    }

    /** Oraciones por reglas Unicode: respeta abreviaturas y puntos suspensivos. */
    fun sentences(text: String, locale: Locale = SPANISH): Int {
        if (text.isBlank()) return 0
        val iterator = BreakIterator.getSentenceInstance(locale)
        iterator.setText(text)
        var count = 0
        var start = iterator.first()
        var end = iterator.next()
        while (end != BreakIterator.DONE) {
            if (text.substring(start, end).any { it.isLetterOrDigit() }) count++
            start = end
            end = iterator.next()
        }
        return count
    }

    fun paragraphs(text: String): Int =
        if (text.isBlank()) 0 else text.split(Regex("\\n\\s*\\n")).count { it.isNotBlank() }

    /** Caracteres tal como los ve una persona: un emoji cuenta como uno. */
    fun visibleCharacters(text: String): Int =
        if (text.isEmpty()) 0 else text.codePointCount(0, text.length)

    /** Segmentos de SMS segun GSM 03.38. */
    fun smsInfo(text: String): SmsInfo {
        if (text.isEmpty()) return SmsInfo("GSM-7", 0, 160, 0, "")
        var units = 0
        var forcedBy: Char? = null
        text.forEach { char ->
            when {
                gsm7Basic.contains(char) -> units += 1
                gsm7Extended.contains(char) -> units += 2
                else -> if (forcedBy == null) forcedBy = char
            }
        }
        val offender = forcedBy
        return if (offender != null) {
            val ucsUnits = text.length
            val perSegment = if (ucsUnits <= 70) 70 else 67
            val segments = if (ucsUnits <= 70) 1 else ceil(ucsUnits / 67.0).toInt()
            val label = if (offender.isWhitespace()) "un caracter especial" else "«$offender»"
            SmsInfo(
                encoding = "UCS-2",
                units = ucsUnits,
                perSegment = perSegment,
                segments = segments,
                note = "$label obliga a UCS-2: el SMS baja de 160 a 70 caracteres por envio."
            )
        } else {
            val perSegment = if (units <= 160) 160 else 153
            val segments = if (units <= 160) 1 else ceil(units / 153.0).toInt()
            SmsInfo(
                encoding = "GSM-7",
                units = units,
                perSegment = perSegment,
                segments = segments,
                note = if (segments > 1) "Se envia partido en $segments mensajes." else ""
            )
        }
    }

    /** Limites reales de las plataformas donde se suele pegar el texto. */
    fun platformLimits(text: String): List<PlatformLimitStatus> {
        val used = visibleCharacters(text)
        return listOf(
            PlatformLimitStatus("Redes", "X / Twitter (gratis)", 280, used),
            PlatformLimitStatus("Redes", "Instagram (descripcion)", 2200, used),
            PlatformLimitStatus("Redes", "Instagram (biografia)", 150, used),
            PlatformLimitStatus("Redes", "TikTok (descripcion)", 2200, used),
            PlatformLimitStatus("Redes", "LinkedIn (publicacion)", 3000, used),
            PlatformLimitStatus("Redes", "LinkedIn (titular)", 220, used),
            PlatformLimitStatus("Redes", "YouTube (titulo)", 100, used),
            PlatformLimitStatus("Redes", "YouTube (descripcion)", 5000, used),
            PlatformLimitStatus("SEO", "Titulo SEO (meta title)", 60, used),
            PlatformLimitStatus("SEO", "Descripcion SEO (meta description)", 160, used),
            PlatformLimitStatus("Academico", "Resumen / abstract corto", 250, used)
        )
    }

    fun topWords(words: List<String>, limit: Int = 8): List<WordFrequency> {
        if (words.isEmpty()) return emptyList()
        val total = words.size
        return words
            .map { it.lowercase(SPANISH).trim('\'', '’', '-') }
            .filter { it.length > 2 && it !in stopWords && it.any(Char::isLetter) }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(limit)
            .map { WordFrequency(it.key, it.value, it.value * 100.0 / total) }
    }

    fun readingSeconds(words: Int, wordsPerMinute: Double): Long =
        if (words <= 0) 0L else (words / wordsPerMinute * 60.0).roundToLong().coerceAtLeast(1L)

    /** Escala INFLESZ aplicada al indice de perspicuidad de Szigriszt-Pazos. */
    fun infleszLabel(score: Double): String = when {
        score > 80 -> "Muy facil"
        score > 65 -> "Bastante facil"
        score > 55 -> "Normal"
        score > 40 -> "Algo dificil"
        else -> "Muy dificil"
    }

    private fun infleszAdvice(score: Double, wordsPerSentence: Double): String = when {
        score > 80 -> "Nivel de lectura muy comodo, apto para cualquier publico."
        score > 65 -> "Se lee sin esfuerzo. Buen registro para divulgacion."
        score > 55 -> "Nivel estandar, parecido al de un periodico."
        score > 40 ->
            "Denso. Tus frases promedian ${String.format(Locale.US, "%.0f", wordsPerSentence)} palabras: " +
                "cortando las mas largas ganas varios puntos."
        else ->
            "Muy exigente. Divide las frases y cambia las palabras largas por otras mas comunes."
    }

    /** Analisis completo. Pensado para correr fuera del hilo principal. */
    fun analyze(text: String, locale: Locale = SPANISH): DetailedTextMetrics {
        if (text.isEmpty()) return DetailedTextMetrics.EMPTY

        val wordList = words(text, locale)
        val wordCount = wordList.size
        val sentenceCount = sentences(text, locale).coerceAtLeast(if (wordCount > 0) 1 else 0)
        val syllables = wordList.sumOf { TextLab.countSyllables(it) }
        val syllablesPerWord = if (wordCount == 0) 0.0 else syllables.toDouble() / wordCount
        val wordsPerSentence = if (sentenceCount == 0) 0.0 else wordCount.toDouble() / sentenceCount

        val szigriszt = if (wordCount == 0) 0.0 else 206.835 - 62.3 * syllablesPerWord - wordsPerSentence
        val fernandez = if (wordCount == 0) 0.0 else 206.84 - 60.0 * syllablesPerWord - 1.02 * wordsPerSentence

        return DetailedTextMetrics(
            words = wordCount,
            uniqueWords = wordList.map { it.lowercase(locale) }.toSet().size,
            charactersWithSpaces = visibleCharacters(text),
            charactersNoSpaces = text.count { !it.isWhitespace() },
            utf16Units = text.length,
            sentences = sentenceCount,
            paragraphs = paragraphs(text),
            lines = if (text.isEmpty()) 0 else text.lines().size,
            syllables = syllables,
            longestWord = wordList.maxByOrNull { it.length }.orEmpty(),
            averageWordLength = if (wordCount == 0) 0.0 else wordList.sumOf { it.length }.toDouble() / wordCount,
            averageSentenceWords = wordsPerSentence,
            averageSyllablesPerWord = syllablesPerWord,
            fleschSzigriszt = szigriszt,
            fernandezHuerta = fernandez,
            infleszLabel = if (wordCount == 0) "—" else infleszLabel(szigriszt),
            infleszAdvice = if (wordCount == 0) "Escribe o pega un texto para analizarlo."
            else infleszAdvice(szigriszt, wordsPerSentence),
            topWords = topWords(wordList),
            readingTimes = listOf(
                ReadingTime("Lectura silenciosa", WPM_SILENT, readingSeconds(wordCount, WPM_SILENT)),
                ReadingTime("Lectura en voz alta", WPM_ALOUD, readingSeconds(wordCount, WPM_ALOUD)),
                ReadingTime("Exposicion oral", WPM_SPEECH, readingSeconds(wordCount, WPM_SPEECH)),
                ReadingTime("Locucion / video", WPM_PODCAST, readingSeconds(wordCount, WPM_PODCAST))
            ),
            sms = smsInfo(text)
        )
    }
}
