package com.ganageo.app.tools

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Generador de documentos PDF.
 *
 * Escribe texto real, no una imagen del texto. Eso importa por dos razones: el
 * archivo pesa poquísimo y, sobre todo, un CV en PDF con texto seleccionable es
 * el que pueden leer los sistemas de reclutamiento (ATS). Un PDF rasterizado se
 * ve igual en pantalla pero para esos filtros está en blanco.
 */
object OfficePdf {

    const val PAGE_WIDTH = 595
    const val PAGE_HEIGHT = 842

    enum class Align { LEFT, RIGHT, CENTER }

    data class Column(val title: String, val weight: Float, val align: Align = Align.LEFT)

    class Builder internal constructor(
        private val document: PdfDocument,
        private val margin: Float,
        private val accentColor: Int
    ) {
        private val contentWidth = PAGE_WIDTH - margin * 2
        private var page: PdfDocument.Page? = null
        private var canvas: Canvas? = null
        private var pageNumber = 0
        private var y = margin
        private var footer: String? = null

        private val sans = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        private val sansBold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)

        private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(20, 20, 20); textSize = 22f; typeface = sansBold
        }
        private val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor; textSize = 12.5f; typeface = sansBold
        }
        private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 30, 30); textSize = 10.5f; typeface = sans
        }
        private val bodyBoldPaint = Paint(bodyPaint).apply { typeface = sansBold }
        private val mutedPaint = Paint(bodyPaint).apply {
            color = Color.rgb(105, 110, 115); textSize = 9.3f
        }
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(210, 214, 218); strokeWidth = 1f
        }

        internal fun finish() {
            page?.let {
                drawFooter()
                document.finishPage(it)
            }
            page = null
        }

        private fun startPage() {
            page?.let {
                drawFooter()
                document.finishPage(it)
            }
            pageNumber++
            val info = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            val newPage = document.startPage(info)
            newPage.canvas.drawColor(Color.WHITE)
            page = newPage
            canvas = newPage.canvas
            y = margin
        }

        private fun drawFooter() {
            val text = footer ?: return
            val c = canvas ?: return
            c.drawText(text, margin, PAGE_HEIGHT - margin / 2, mutedPaint)
        }

        private fun ensure(space: Float) {
            if (page == null) startPage()
            if (y + space > PAGE_HEIGHT - margin) startPage()
        }

        fun footerNote(text: String) {
            footer = text
        }

        fun title(text: String) {
            if (text.isBlank()) return
            ensure(30f)
            canvas?.drawText(text, margin, y + 20f, titlePaint)
            y += 28f
        }

        fun subtitle(text: String) {
            if (text.isBlank()) return
            ensure(16f)
            canvas?.drawText(text, margin, y + 11f, mutedPaint)
            y += 16f
        }

        fun section(text: String) {
            if (text.isBlank()) return
            ensure(26f)
            y += 8f
            canvas?.drawText(text.uppercase(), margin, y + 10f, sectionPaint)
            y += 14f
            canvas?.drawLine(margin, y, margin + contentWidth, y, linePaint)
            y += 8f
        }

        fun paragraph(text: String, bold: Boolean = false, muted: Boolean = false) {
            if (text.isBlank()) return
            val paint = when {
                bold -> bodyBoldPaint
                muted -> mutedPaint
                else -> bodyPaint
            }
            wrap(text, paint, contentWidth).forEach { line ->
                ensure(paint.textSize + 4f)
                canvas?.drawText(line, margin, y + paint.textSize, paint)
                y += paint.textSize + 4f
            }
        }

        fun bullet(text: String) {
            if (text.isBlank()) return
            val indent = 12f
            val lines = wrap(text, bodyPaint, contentWidth - indent)
            lines.forEachIndexed { index, line ->
                ensure(bodyPaint.textSize + 4f)
                if (index == 0) {
                    canvas?.drawText("•", margin, y + bodyPaint.textSize, bodyPaint)
                }
                canvas?.drawText(line, margin + indent, y + bodyPaint.textSize, bodyPaint)
                y += bodyPaint.textSize + 4f
            }
        }

        /** Fila de etiqueta a la izquierda y valor a la derecha, para totales y fichas. */
        fun keyValue(label: String, value: String, bold: Boolean = false) {
            val paint = if (bold) bodyBoldPaint else bodyPaint
            ensure(paint.textSize + 6f)
            canvas?.drawText(label, margin, y + paint.textSize, paint)
            val width = paint.measureText(value)
            canvas?.drawText(value, margin + contentWidth - width, y + paint.textSize, paint)
            y += paint.textSize + 6f
        }

        fun divider() {
            ensure(10f)
            canvas?.drawLine(margin, y + 4f, margin + contentWidth, y + 4f, linePaint)
            y += 10f
        }

        fun spacer(height: Float = 8f) {
            ensure(height)
            y += height
        }

        fun table(columns: List<Column>, rows: List<List<String>>) {
            if (columns.isEmpty()) return
            val totalWeight = columns.sumOf { it.weight.toDouble() }.toFloat()
            val widths = columns.map { contentWidth * it.weight / totalWeight }

            fun drawRow(values: List<String>, paint: Paint, background: Boolean) {
                val cellLines = values.mapIndexed { index, value ->
                    wrap(value, paint, widths[index] - 8f)
                }
                val rowHeight = (cellLines.maxOfOrNull { it.size } ?: 1) * (paint.textSize + 3f) + 8f
                ensure(rowHeight)
                if (background) {
                    val fill = Paint().apply { color = Color.rgb(243, 245, 247) }
                    canvas?.drawRect(margin, y, margin + contentWidth, y + rowHeight, fill)
                }
                var x = margin
                cellLines.forEachIndexed { index, lines ->
                    val column = columns[index]
                    lines.forEachIndexed { lineIndex, line ->
                        val textWidth = paint.measureText(line)
                        val drawX = when (column.align) {
                            Align.LEFT -> x + 4f
                            Align.RIGHT -> x + widths[index] - textWidth - 4f
                            Align.CENTER -> x + (widths[index] - textWidth) / 2
                        }
                        canvas?.drawText(line, drawX, y + 4f + paint.textSize + lineIndex * (paint.textSize + 3f), paint)
                    }
                    x += widths[index]
                }
                y += rowHeight
                canvas?.drawLine(margin, y, margin + contentWidth, y, linePaint)
            }

            drawRow(columns.map { it.title }, bodyBoldPaint, background = true)
            rows.forEach { drawRow(it, bodyPaint, background = false) }
        }

        private fun wrap(text: String, paint: Paint, maxWidth: Float): List<String> {
            val output = mutableListOf<String>()
            text.split('\n').forEach { paragraph ->
                if (paragraph.isBlank()) {
                    output += ""
                    return@forEach
                }
                var current = ""
                paragraph.trim().split(Regex("\\s+")).forEach { word ->
                    val candidate = if (current.isEmpty()) word else "$current $word"
                    if (paint.measureText(candidate) <= maxWidth || current.isEmpty()) {
                        current = candidate
                    } else {
                        output += current
                        current = word
                    }
                }
                if (current.isNotEmpty()) output += current
            }
            return output
        }
    }

    suspend fun write(
        context: Context,
        output: Uri,
        margin: Float = 48f,
        accentColor: Int = Color.rgb(18, 92, 62),
        block: Builder.() -> Unit
    ) = withContext(Dispatchers.IO) {
        val document = PdfDocument()
        try {
            val builder = Builder(document, margin, accentColor)
            builder.block()
            builder.finish()
            context.contentResolver.openOutputStream(output, "w")?.use { stream ->
                document.writeTo(stream)
            } ?: error("No se pudo escribir el archivo.")
        } finally {
            document.close()
        }
    }
}
