package com.ganageo.app.tools

import kotlin.math.E
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cbrt
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.cosh
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.pow
import kotlin.math.roundToLong
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sinh
import kotlin.math.sqrt
import kotlin.math.tan
import kotlin.math.tanh

/**
 * Motor matematico del bloque de Ciencias.
 *
 * A diferencia del evaluador antiguo, aqui la expresion se analiza UNA sola vez y
 * queda convertida en un arbol. Ese arbol se evalua miles de veces por segundo al
 * graficar sin volver a leer texto, admite multiplicacion implicita (2x, 3sin(x))
 * y devuelve NaN en los puntos fuera de dominio en vez de lanzar una excepcion,
 * que es justo lo que necesita una grafica para levantar el lapiz en lugar de
 * dibujar una linea vertical falsa.
 */
sealed class MathNode {
    data class Num(val value: Double) : MathNode()
    data class Var(val name: String) : MathNode()
    data class Neg(val child: MathNode) : MathNode()
    data class Binary(val op: Char, val left: MathNode, val right: MathNode) : MathNode()
    data class Call(val name: String, val args: List<MathNode>) : MathNode()
}

class MathParseException(message: String) : IllegalArgumentException(message)

object MathEngine {

    val functions: Set<String> = setOf(
        "sin", "cos", "tan", "asin", "acos", "atan", "sinh", "cosh", "tanh",
        "sqrt", "cbrt", "abs", "ln", "log", "log2", "exp",
        "floor", "ceil", "round", "sign", "min", "max", "atan2", "raiz", "nroot"
    )

    private val constants: Map<String, Double> = mapOf(
        "pi" to PI,
        "π" to PI,
        "e" to E,
        "tau" to 2 * PI,
        "phi" to 1.618033988749895
    )

    // ------------------------------------------------------------------
    // Analisis
    // ------------------------------------------------------------------

    fun parse(input: String): MathNode {
        val normalized = normalize(input)
        if (normalized.isBlank()) throw MathParseException("Escribe una expresión.")
        val parser = Parser(normalized)
        val node = parser.parseExpression()
        parser.expectEnd()
        return node
    }

    fun tryParse(input: String): MathNode? = runCatching { parse(input) }.getOrNull()

    private fun normalize(raw: String): String = raw
        .replace('×', '*')
        .replace('·', '*')
        .replace('÷', '/')
        .replace('−', '-')
        .replace('–', '-')
        .replace('^', '^')
        .replace("²", "^2")
        .replace("³", "^3")
        .replace("√", "sqrt")
        .replace(",", ".")
        .trim()

    private class Parser(private val text: String) {
        private var index = 0

        fun expectEnd() {
            skip()
            if (index < text.length) {
                throw MathParseException("No se entiende «${text.substring(index).take(12)}».")
            }
        }

        private fun skip() {
            while (index < text.length && text[index].isWhitespace()) index++
        }

        private fun peek(): Char? {
            skip()
            return text.getOrNull(index)
        }

        fun parseExpression(): MathNode {
            var left = parseTerm()
            while (true) {
                val c = peek() ?: return left
                if (c == '+' || c == '-') {
                    index++
                    left = MathNode.Binary(c, left, parseTerm())
                } else {
                    return left
                }
            }
        }

        private fun parseTerm(): MathNode {
            var left = parseUnary()
            while (true) {
                val c = peek() ?: return left
                when {
                    c == '*' || c == '/' -> {
                        index++
                        left = MathNode.Binary(c, left, parseUnary())
                    }
                    // Multiplicacion implicita: 2x, 3(x+1), 2sin(x), x y.
                    startsFactor(c) -> left = MathNode.Binary('*', left, parseUnary())
                    else -> return left
                }
            }
        }

        private fun startsFactor(c: Char): Boolean =
            c.isDigit() || c == '(' || c.isLetter()

        private fun parseUnary(): MathNode {
            val c = peek() ?: throw MathParseException("Falta un valor.")
            if (c == '-') {
                index++
                return MathNode.Neg(parseUnary())
            }
            if (c == '+') {
                index++
                return parseUnary()
            }
            return parsePower()
        }

        private fun parsePower(): MathNode {
            val base = parsePostfix()
            val c = peek() ?: return base
            if (c == '^') {
                index++
                // El exponente es asociativo por la derecha y admite signo: 2^-x.
                return MathNode.Binary('^', base, parseUnary())
            }
            return base
        }

        private fun parsePostfix(): MathNode {
            var node = parsePrimary()
            while (true) {
                val c = peek() ?: return node
                if (c == '!') {
                    index++
                    node = MathNode.Call("factorial", listOf(node))
                } else if (c == '%') {
                    index++
                    node = MathNode.Binary('/', node, MathNode.Num(100.0))
                } else {
                    return node
                }
            }
        }

        private fun parsePrimary(): MathNode {
            val c = peek() ?: throw MathParseException("Falta un valor.")
            if (c == '(') {
                index++
                val inner = parseExpression()
                expect(')')
                return inner
            }
            if (c == '|') {
                index++
                val inner = parseExpression()
                expect('|')
                return MathNode.Call("abs", listOf(inner))
            }
            if (c.isDigit() || c == '.') return parseNumber()
            if (c.isLetter()) return parseIdentifier()
            throw MathParseException("Carácter inesperado «$c».")
        }

        private fun parseNumber(): MathNode {
            skip()
            val start = index
            var seenExponent = false
            while (index < text.length) {
                val c = text[index]
                when {
                    c.isDigit() || c == '.' -> index++
                    (c == 'e' || c == 'E') && !seenExponent && index > start &&
                        text.getOrNull(index + 1)?.let { it.isDigit() || it == '+' || it == '-' } == true -> {
                        seenExponent = true
                        index++
                        if (text.getOrNull(index) == '+' || text.getOrNull(index) == '-') index++
                    }
                    else -> break
                }
            }
            val value = text.substring(start, index).toDoubleOrNull()
                ?: throw MathParseException("Número inválido.")
            return MathNode.Num(value)
        }

        private fun parseIdentifier(): MathNode {
            skip()
            val start = index
            while (index < text.length && (text[index].isLetter() || text[index] == '_')) index++
            val name = text.substring(start, index)
            val lower = name.lowercase()

            if (lower in functions || lower == "factorial") {
                skip()
                if (text.getOrNull(index) == '(') {
                    index++
                    val args = mutableListOf(parseExpression())
                    while (peek() == ';' || peek() == ',') {
                        index++
                        args += parseExpression()
                    }
                    expect(')')
                    return MathNode.Call(lower, args)
                }
                // sin x  ->  sin(x)
                return MathNode.Call(lower, listOf(parseUnary()))
            }

            constants[lower]?.let { return MathNode.Num(it) }

            // Una cadena de letras sueltas son variables multiplicadas: xy -> x*y.
            if (name.length > 1 && name.all { it.isLetter() }) {
                var node: MathNode = MathNode.Var(name.first().lowercase())
                for (i in 1 until name.length) {
                    node = MathNode.Binary('*', node, MathNode.Var(name[i].lowercase()))
                }
                return node
            }
            return MathNode.Var(lower)
        }

        private fun expect(expected: Char) {
            skip()
            if (text.getOrNull(index) != expected) {
                throw MathParseException("Falta «$expected».")
            }
            index++
        }
    }

    // ------------------------------------------------------------------
    // Evaluacion
    // ------------------------------------------------------------------

    /**
     * Evalua el arbol. Devuelve NaN si el punto queda fuera del dominio
     * (raiz de negativo, log de cero, division por cero) para que quien grafica
     * pueda simplemente saltarse ese punto.
     */
    fun eval(node: MathNode, variables: Map<String, Double>, degrees: Boolean = false): Double =
        when (node) {
            is MathNode.Num -> node.value
            is MathNode.Var -> variables[node.name.lowercase()] ?: Double.NaN
            is MathNode.Neg -> -eval(node.child, variables, degrees)
            is MathNode.Binary -> {
                val a = eval(node.left, variables, degrees)
                val b = eval(node.right, variables, degrees)
                when (node.op) {
                    '+' -> a + b
                    '-' -> a - b
                    '*' -> a * b
                    '/' -> if (b == 0.0) Double.NaN else a / b
                    '^' -> power(a, b)
                    else -> Double.NaN
                }
            }
            is MathNode.Call -> {
                val args = node.args.map { eval(it, variables, degrees) }
                applyFunction(node.name, args, degrees)
            }
        }

    private fun power(base: Double, exponent: Double): Double {
        if (base < 0 && exponent != floor(exponent)) return Double.NaN
        return base.pow(exponent)
    }

    private fun applyFunction(name: String, args: List<Double>, degrees: Boolean): Double {
        val a = args.firstOrNull() ?: return Double.NaN
        fun toRad(v: Double) = if (degrees) v * PI / 180.0 else v
        fun fromRad(v: Double) = if (degrees) v * 180.0 / PI else v
        return when (name) {
            "sin" -> sin(toRad(a))
            "cos" -> cos(toRad(a))
            "tan" -> {
                val r = toRad(a)
                // Cerca de pi/2 la tangente se dispara: se marca como indefinido.
                if (abs(cos(r)) < 1e-12) Double.NaN else tan(r)
            }
            "asin" -> if (a < -1 || a > 1) Double.NaN else fromRad(asin(a))
            "acos" -> if (a < -1 || a > 1) Double.NaN else fromRad(acos(a))
            "atan" -> fromRad(atan(a))
            "atan2" -> if (args.size < 2) Double.NaN else fromRad(atan2(a, args[1]))
            "sinh" -> sinh(a)
            "cosh" -> cosh(a)
            "tanh" -> tanh(a)
            "sqrt" -> if (a < 0) Double.NaN else sqrt(a)
            "cbrt" -> cbrt(a)
            "abs" -> abs(a)
            "ln" -> if (a <= 0) Double.NaN else ln(a)
            "log" -> when {
                args.size >= 2 -> if (a <= 0 || args[1] <= 0 || args[1] == 1.0) Double.NaN else ln(args[1]) / ln(a)
                a <= 0 -> Double.NaN
                else -> log10(a)
            }
            "log2" -> if (a <= 0) Double.NaN else log2(a)
            "exp" -> exp(a)
            "floor" -> floor(a)
            "ceil" -> ceil(a)
            "round" -> Math.round(a).toDouble()
            "sign" -> sign(a)
            "min" -> args.minOrNull() ?: Double.NaN
            "max" -> args.maxOrNull() ?: Double.NaN
            "raiz", "nroot" -> if (args.size < 2) sqrt(a) else nthRoot(args[1], a)
            "factorial" -> factorial(a)
            else -> Double.NaN
        }
    }

    private fun nthRoot(value: Double, degree: Double): Double {
        if (degree == 0.0) return Double.NaN
        if (value < 0) {
            val n = degree.roundToLong()
            if (n.toDouble() != degree || n % 2L == 0L) return Double.NaN
            return -(-value).pow(1.0 / degree)
        }
        return value.pow(1.0 / degree)
    }

    fun factorial(value: Double): Double {
        if (value < 0 || value != floor(value) || value > 170) return Double.NaN
        var result = 1.0
        var i = 2
        while (i <= value.toInt()) {
            result *= i
            i++
        }
        return result
    }

    /** Compila una funcion de una variable lista para graficar. */
    fun compile(expression: String, variable: String = "x", degrees: Boolean = false): (Double) -> Double {
        val node = parse(expression)
        val key = variable.lowercase()
        val holder = HashMap<String, Double>(2)
        return { x ->
            holder[key] = x
            eval(node, holder, degrees)
        }
    }

    fun compileNode(node: MathNode, variable: String = "x", degrees: Boolean = false): (Double) -> Double {
        val key = variable.lowercase()
        val holder = HashMap<String, Double>(2)
        return { x ->
            holder[key] = x
            eval(node, holder, degrees)
        }
    }

    fun variablesOf(node: MathNode): Set<String> {
        val found = linkedSetOf<String>()
        fun walk(n: MathNode) {
            when (n) {
                is MathNode.Var -> found += n.name
                is MathNode.Neg -> walk(n.child)
                is MathNode.Binary -> {
                    walk(n.left)
                    walk(n.right)
                }
                is MathNode.Call -> n.args.forEach(::walk)
                is MathNode.Num -> Unit
            }
        }
        walk(node)
        return found
    }

    // ------------------------------------------------------------------
    // Derivada simbolica
    // ------------------------------------------------------------------

    private val zero = MathNode.Num(0.0)
    private val one = MathNode.Num(1.0)

    /** Derivada simbolica respecto de [variable], ya simplificada. */
    fun derivative(node: MathNode, variable: String = "x"): MathNode =
        simplify(rawDerivative(simplify(node), variable.lowercase()))

    private fun rawDerivative(node: MathNode, v: String): MathNode = when (node) {
        is MathNode.Num -> zero
        is MathNode.Var -> if (node.name == v) one else zero
        is MathNode.Neg -> MathNode.Neg(rawDerivative(node.child, v))
        is MathNode.Binary -> when (node.op) {
            '+' -> MathNode.Binary('+', rawDerivative(node.left, v), rawDerivative(node.right, v))
            '-' -> MathNode.Binary('-', rawDerivative(node.left, v), rawDerivative(node.right, v))
            '*' -> MathNode.Binary(
                '+',
                MathNode.Binary('*', rawDerivative(node.left, v), node.right),
                MathNode.Binary('*', node.left, rawDerivative(node.right, v))
            )
            '/' -> MathNode.Binary(
                '/',
                MathNode.Binary(
                    '-',
                    MathNode.Binary('*', rawDerivative(node.left, v), node.right),
                    MathNode.Binary('*', node.left, rawDerivative(node.right, v))
                ),
                MathNode.Binary('^', node.right, MathNode.Num(2.0))
            )
            '^' -> derivativeOfPower(node, v)
            else -> zero
        }
        is MathNode.Call -> derivativeOfCall(node, v)
    }

    private fun derivativeOfPower(node: MathNode.Binary, v: String): MathNode {
        val base = node.left
        val exponent = node.right
        val exponentIsConstant = !variablesOf(exponent).contains(v)
        if (exponentIsConstant) {
            // n·u^(n-1)·u'
            val reduced = MathNode.Binary('^', base, MathNode.Binary('-', exponent, one))
            return MathNode.Binary(
                '*',
                MathNode.Binary('*', exponent, reduced),
                rawDerivative(base, v)
            )
        }
        val baseIsConstant = !variablesOf(base).contains(v)
        if (baseIsConstant) {
            // a^u · ln(a) · u'
            return MathNode.Binary(
                '*',
                MathNode.Binary('*', node, MathNode.Call("ln", listOf(base))),
                rawDerivative(exponent, v)
            )
        }
        // Caso general: u^w = exp(w·ln u)
        val rewritten = MathNode.Call(
            "exp",
            listOf(MathNode.Binary('*', exponent, MathNode.Call("ln", listOf(base))))
        )
        return rawDerivative(rewritten, v)
    }

    private fun derivativeOfCall(node: MathNode.Call, v: String): MathNode {
        val u = node.args.firstOrNull() ?: return zero
        val du = rawDerivative(u, v)
        val outer: MathNode = when (node.name) {
            "sin" -> MathNode.Call("cos", listOf(u))
            "cos" -> MathNode.Neg(MathNode.Call("sin", listOf(u)))
            "tan" -> MathNode.Binary('/', one, MathNode.Binary('^', MathNode.Call("cos", listOf(u)), MathNode.Num(2.0)))
            "asin" -> MathNode.Binary(
                '/', one,
                MathNode.Call("sqrt", listOf(MathNode.Binary('-', one, MathNode.Binary('^', u, MathNode.Num(2.0)))))
            )
            "acos" -> MathNode.Neg(
                MathNode.Binary(
                    '/', one,
                    MathNode.Call("sqrt", listOf(MathNode.Binary('-', one, MathNode.Binary('^', u, MathNode.Num(2.0)))))
                )
            )
            "atan" -> MathNode.Binary(
                '/', one,
                MathNode.Binary('+', one, MathNode.Binary('^', u, MathNode.Num(2.0)))
            )
            "sinh" -> MathNode.Call("cosh", listOf(u))
            "cosh" -> MathNode.Call("sinh", listOf(u))
            "tanh" -> MathNode.Binary('/', one, MathNode.Binary('^', MathNode.Call("cosh", listOf(u)), MathNode.Num(2.0)))
            "exp" -> node
            "ln" -> MathNode.Binary('/', one, u)
            "log" -> MathNode.Binary('/', one, MathNode.Binary('*', u, MathNode.Call("ln", listOf(MathNode.Num(10.0)))))
            "log2" -> MathNode.Binary('/', one, MathNode.Binary('*', u, MathNode.Call("ln", listOf(MathNode.Num(2.0)))))
            "sqrt" -> MathNode.Binary('/', one, MathNode.Binary('*', MathNode.Num(2.0), MathNode.Call("sqrt", listOf(u))))
            "cbrt" -> MathNode.Binary(
                '/', one,
                MathNode.Binary('*', MathNode.Num(3.0), MathNode.Binary('^', MathNode.Call("cbrt", listOf(u)), MathNode.Num(2.0)))
            )
            "abs" -> MathNode.Call("sign", listOf(u))
            else -> return zero
        }
        return MathNode.Binary('*', outer, du)
    }

    // ------------------------------------------------------------------
    // Simplificacion
    // ------------------------------------------------------------------

    fun simplify(node: MathNode): MathNode = when (node) {
        is MathNode.Num, is MathNode.Var -> node
        is MathNode.Neg -> {
            val child = simplify(node.child)
            when {
                child is MathNode.Num -> MathNode.Num(-child.value)
                child is MathNode.Neg -> child.child
                else -> MathNode.Neg(child)
            }
        }
        is MathNode.Call -> {
            val args = node.args.map(::simplify)
            if (args.all { it is MathNode.Num } && node.name != "sign") {
                val value = applyFunction(node.name, args.map { (it as MathNode.Num).value }, false)
                if (value.isFinite()) MathNode.Num(value) else MathNode.Call(node.name, args)
            } else {
                MathNode.Call(node.name, args)
            }
        }
        is MathNode.Binary -> simplifyBinary(node.op, simplify(node.left), simplify(node.right))
    }

    private fun simplifyBinary(op: Char, left: MathNode, right: MathNode): MathNode {
        val lv = (left as? MathNode.Num)?.value
        val rv = (right as? MathNode.Num)?.value
        if (lv != null && rv != null) {
            val value = when (op) {
                '+' -> lv + rv
                '-' -> lv - rv
                '*' -> lv * rv
                '/' -> if (rv == 0.0) return MathNode.Binary(op, left, right) else lv / rv
                '^' -> power(lv, rv)
                else -> return MathNode.Binary(op, left, right)
            }
            if (value.isFinite()) return MathNode.Num(value)
        }
        return when (op) {
            '+' -> when {
                lv == 0.0 -> right
                rv == 0.0 -> left
                right is MathNode.Neg -> simplifyBinary('-', left, right.child)
                else -> MathNode.Binary('+', left, right)
            }
            '-' -> when {
                rv == 0.0 -> left
                lv == 0.0 -> MathNode.Neg(right)
                right is MathNode.Neg -> simplifyBinary('+', left, right.child)
                else -> MathNode.Binary('-', left, right)
            }
            '*' -> when {
                lv == 0.0 || rv == 0.0 -> zero
                lv == 1.0 -> right
                rv == 1.0 -> left
                lv == -1.0 -> MathNode.Neg(right)
                rv == -1.0 -> MathNode.Neg(left)
                // Deja el numero delante: 2·x en vez de x·2.
                rv != null && lv == null -> MathNode.Binary('*', right, left)
                else -> MathNode.Binary('*', left, right)
            }
            '/' -> when {
                lv == 0.0 -> zero
                rv == 1.0 -> left
                else -> MathNode.Binary('/', left, right)
            }
            '^' -> when {
                rv == 0.0 -> one
                rv == 1.0 -> left
                lv == 1.0 -> one
                else -> MathNode.Binary('^', left, right)
            }
            else -> MathNode.Binary(op, left, right)
        }
    }

    // ------------------------------------------------------------------
    // Formato
    // ------------------------------------------------------------------

    fun format(node: MathNode): String = render(node, 0)

    private fun precedenceOf(node: MathNode): Int = when (node) {
        is MathNode.Num, is MathNode.Var, is MathNode.Call -> 5
        is MathNode.Neg -> 2
        is MathNode.Binary -> when (node.op) {
            '+', '-' -> 1
            '*', '/' -> 2
            else -> 4
        }
    }

    private fun render(node: MathNode, parentPrecedence: Int): String {
        val text = when (node) {
            is MathNode.Num -> formatNumber(node.value)
            is MathNode.Var -> node.name
            is MathNode.Neg -> "-" + render(node.child, 3)
            is MathNode.Call -> {
                if (node.name == "factorial") {
                    render(node.args.first(), 5) + "!"
                } else {
                    node.name + "(" + node.args.joinToString(", ") { render(it, 0) } + ")"
                }
            }
            is MathNode.Binary -> {
                val precedence = precedenceOf(node)
                val symbol = when (node.op) {
                    '*' -> "·"
                    '/' -> "/"
                    else -> node.op.toString()
                }
                val left = render(node.left, precedence)
                val right = render(node.right, precedence + 1)
                if (node.op == '+' || node.op == '-') "$left $symbol $right" else "$left$symbol$right"
            }
        }
        return if (precedenceOf(node) < parentPrecedence) "($text)" else text
    }

    /** Formato numerico compacto y legible, sin ceros de relleno. */
    fun formatNumber(value: Double, decimals: Int = 6): String {
        if (value.isNaN()) return "indefinido"
        if (value.isInfinite()) return if (value > 0) "∞" else "-∞"
        if (abs(value) < 1e-12) return "0"
        if (abs(value - Math.round(value)) < 1e-10 && abs(value) < 1e15) {
            return Math.round(value).toString()
        }
        if (abs(value) >= 1e9 || abs(value) < 1e-5) {
            return String.format("%.4e", value).replace("e", "×10^")
        }
        var text = String.format("%.${decimals}f", value)
        if (text.contains('.')) text = text.trimEnd('0').trimEnd('.')
        return text
    }
}
