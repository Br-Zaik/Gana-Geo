package com.ganageo.app.ui.tools

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ganageo.app.MainActivity
import com.ganageo.app.tools.BarcodeCheck
import com.ganageo.app.tools.BarcodeEngine
import com.ganageo.app.tools.BarcodeKind
import com.ganageo.app.tools.DetailedTextMetrics
import com.ganageo.app.tools.FocusLab
import com.ganageo.app.tools.FocusPhase
import com.ganageo.app.tools.QrContent
import com.ganageo.app.tools.QrErrorCorrection
import com.ganageo.app.tools.QrPayloadKind
import com.ganageo.app.tools.ScannedContentAnalyzer
import com.ganageo.app.tools.ScannedInfo
import com.ganageo.app.tools.TextMetricsEngine
import com.ganageo.app.tools.TimeAnchor
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.tools.WifiSecurity
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.Danger
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import com.google.zxing.BarcodeFormat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

// ===========================================================================
// Piezas de UI compartidas por las tres herramientas rapidas
// ===========================================================================

@Composable
private fun QuickTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        labels.forEachIndexed { index, label ->
            val active = index == selected
            Box(
                modifier = Modifier
                    .background(
                        if (active) NeonGreen else CardGreen,
                        RoundedCornerShape(14.dp)
                    )
                    .clickable { onSelect(index) }
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            ) {
                Text(
                    label,
                    color = if (active) DeepGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun QuickChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (active) NeonGreen.copy(alpha = 0.22f) else CardGreen, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            label,
            color = if (active) NeonGreen else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
private fun QuickCard(title: String? = null, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (title != null) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            content()
        }
    }
}

@Composable
private fun StatRow(label: String, value: String, highlight: Color = NeonGreen) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold, color = highlight)
    }
}

@Composable
private fun NoteLine(text: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant, warning: Boolean = false) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(
            if (warning) Icons.Rounded.Warning else Icons.Rounded.Check,
            contentDescription = null,
            tint = if (warning) Gold else NeonGreen,
            modifier = Modifier.size(18.dp)
        )
        Text(text, style = MaterialTheme.typography.bodySmall, color = color)
    }
}

/**
 * Digitos grandes con tipografia de ancho fijo.
 *
 * Con una fuente normal cada digito mide distinto y el cronometro "salta" en
 * cada centesima. Monoespaciada + tnum deja las cifras alineadas.
 */
@Composable
private fun BigDigits(value: String, color: Color) {
    Text(
        text = value,
        style = MaterialTheme.typography.displaySmall.copy(
            fontFamily = FontFamily.Monospace,
            fontFeatureSettings = "tnum"
        ),
        color = color,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        maxLines = 1
    )
}

@Composable
private fun CircularCountdown(
    progress: Float,
    color: Color,
    content: @Composable () -> Unit
) {
    Box(modifier = Modifier.size(226.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val inset = stroke / 2f
            val arcSize = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = color.copy(alpha = 0.16f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = 360f * progress.coerceIn(0f, 1f),
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }
        content()
    }
}

private fun copyToClipboard(context: Context, label: String, value: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, value))
}

// ===========================================================================
// 1) QR y códigos de barras
// ===========================================================================

private fun BarcodeKind.zxingFormat(): BarcodeFormat = when (this) {
    BarcodeKind.QR -> BarcodeFormat.QR_CODE
    BarcodeKind.CODE_128 -> BarcodeFormat.CODE_128
    BarcodeKind.EAN_13 -> BarcodeFormat.EAN_13
    BarcodeKind.EAN_8 -> BarcodeFormat.EAN_8
    BarcodeKind.UPC_A -> BarcodeFormat.UPC_A
    BarcodeKind.ITF -> BarcodeFormat.ITF
}

@Composable
fun QrToolScreen(onBack: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tab by rememberSaveable { mutableIntStateOf(0) }

    // ---- estado del generador ----
    var kindIndex by rememberSaveable { mutableIntStateOf(0) }
    var payloadIndex by rememberSaveable { mutableIntStateOf(0) }
    var eccIndex by rememberSaveable { mutableIntStateOf(1) }
    val kind = BarcodeKind.entries[kindIndex]
    val payloadKind = QrPayloadKind.entries[payloadIndex]
    val ecc = QrErrorCorrection.entries[eccIndex]

    var freeText by rememberSaveable { mutableStateOf("") }
    var fieldA by rememberSaveable { mutableStateOf("") }
    var fieldB by rememberSaveable { mutableStateOf("") }
    var fieldC by rememberSaveable { mutableStateOf("") }
    var wifiSecurityIndex by rememberSaveable { mutableIntStateOf(0) }
    var wifiHidden by rememberSaveable { mutableStateOf(false) }

    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var validation by remember { mutableStateOf(BarcodeCheck(false, "", "Escribe el contenido del codigo.")) }
    var rendering by remember { mutableStateOf(false) }

    // ---- estado del lector ----
    var scanned by rememberSaveable { mutableStateOf("") }
    var scannedFormat by rememberSaveable { mutableStateOf("") }
    var history by rememberSaveable { mutableStateOf(listOf<String>()) }
    val analysis: ScannedInfo? = remember(scanned) {
        if (scanned.isBlank()) null else ScannedContentAnalyzer.analyze(scanned)
    }

    // El contenido final depende de la plantilla elegida: la sintaxis exacta la
    // arma el motor, no la pantalla.
    val payload: String = remember(
        kind, payloadKind, freeText, fieldA, fieldB, fieldC, wifiSecurityIndex, wifiHidden
    ) {
        if (kind != BarcodeKind.QR) freeText
        else when (payloadKind) {
            QrPayloadKind.TEXTO -> freeText
            QrPayloadKind.ENLACE -> QrContent.url(freeText)
            QrPayloadKind.WIFI -> QrContent.wifi(
                fieldA, fieldB, WifiSecurity.entries[wifiSecurityIndex], wifiHidden
            )
            QrPayloadKind.CONTACTO -> QrContent.meCard(fieldA, fieldB, fieldC, "", "", "")
            QrPayloadKind.SMS -> QrContent.sms(fieldA, freeText)
            QrPayloadKind.EMAIL -> QrContent.email(fieldA, fieldB, freeText)
            QrPayloadKind.TELEFONO -> QrContent.phone(fieldA)
            QrPayloadKind.WHATSAPP -> QrContent.whatsapp(fieldA, freeText)
            QrPayloadKind.UBICACION -> QrContent.geo(fieldA, fieldB, fieldC)
            QrPayloadKind.EVENTO -> QrContent.event(fieldA, fieldB, fieldC, "")
        }
    }

    // Vista previa en vivo: no hay boton "generar", el codigo se rehace solo.
    LaunchedEffect(payload, kind, ecc) {
        val check = BarcodeEngine.validate(kind, payload)
        validation = check
        if (!check.valid) {
            preview = null
            return@LaunchedEffect
        }
        rendering = true
        delay(220)
        val bitmap = withContext(Dispatchers.Default) {
            runCatching {
                if (kind == BarcodeKind.QR) {
                    ToolFileUtils.generateQr(check.normalized, 880, ecc.zxing)
                } else {
                    ToolFileUtils.generateBarcode(check.normalized, kind.zxingFormat())
                }
            }.getOrNull()
        }
        preview = bitmap
        rendering = false
        if (bitmap == null) validation = check.copy(valid = false, message = "ZXing no pudo dibujar este contenido.")
    }

    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("image/png")
    ) { uri ->
        val bitmap = preview
        if (uri != null && bitmap != null) {
            scope.launch {
                runCatching { ToolFileUtils.writeBitmap(context, bitmap, uri, Bitmap.CompressFormat.PNG, 100) }
                    .onSuccess { onMessage("Codigo guardado correctamente.") }
                    .onFailure { onMessage(it.message ?: "No se pudo guardar el codigo.") }
            }
        }
    }

    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val bitmap = ToolFileUtils.loadBitmap(context, uri)
                    try {
                        ToolFileUtils.decodeAnyCode(bitmap)
                    } finally {
                        if (!bitmap.isRecycled) bitmap.recycle()
                    }
                }.onSuccess { result ->
                    scanned = result.first
                    scannedFormat = result.second
                    history = (listOf(result.first) + history).distinct().take(20)
                    tab = 1
                }.onFailure { onMessage("No se encontro un codigo legible en la imagen.") }
            }
        }
    }

    val scanLauncher = rememberLauncherForActivityResult(ScanContract()) { scanResult ->
        val contents = scanResult.contents
        if (!contents.isNullOrBlank()) {
            scanned = contents
            scannedFormat = scanResult.formatName.orEmpty().replace('_', '-')
            history = (listOf(contents) + history).distinct().take(20)
            tab = 1
        }
    }

    fun launchScanner() {
        scanLauncher.launch(
            ScanOptions()
                .setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES)
                .setPrompt("Apunta la camara al codigo")
                .setBeepEnabled(false)
                .setOrientationLocked(false)
        )
    }

    fun openAction(uri: String, sendTo: Boolean) {
        runCatching {
            val intent = Intent(if (sendTo) Intent.ACTION_SENDTO else Intent.ACTION_VIEW, Uri.parse(uri))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }.onFailure { onMessage("Ninguna app del telefono puede abrir este contenido.") }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("QR y codigos de barras", "Todo se genera y se lee en el telefono", onBack)
        QuickTabs(listOf("Crear", "Leer", "Historial"), tab) { tab = it }

        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (tab == 0) {
                item {
                    QuickCard("Tipo de codigo") {
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            BarcodeKind.entries.forEachIndexed { index, option ->
                                QuickChip(option.label, index == kindIndex) {
                                    kindIndex = index
                                    preview = null
                                }
                            }
                        }
                        Text(
                            kind.inputHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (kind == BarcodeKind.QR) {
                    item {
                        QuickCard("Contenido") {
                            SimpleDropdown(
                                "Plantilla",
                                QrPayloadKind.entries.map { it.label },
                                payloadIndex
                            ) { payloadIndex = it }

                            when (payloadKind) {
                                QrPayloadKind.TEXTO -> OutlinedTextField(
                                    value = freeText,
                                    onValueChange = { freeText = it.take(1200) },
                                    label = { Text("Texto") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 3
                                )

                                QrPayloadKind.ENLACE -> OutlinedTextField(
                                    value = freeText,
                                    onValueChange = { freeText = it.take(600) },
                                    label = { Text("Direccion web") },
                                    placeholder = { Text("ganageo.app/promo") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                QrPayloadKind.WIFI -> {
                                    OutlinedTextField(
                                        value = fieldA,
                                        onValueChange = { fieldA = it.take(64) },
                                        label = { Text("Nombre de la red (SSID)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = fieldB,
                                        onValueChange = { fieldB = it.take(64) },
                                        label = { Text("Clave") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true,
                                        enabled = WifiSecurity.entries[wifiSecurityIndex] != WifiSecurity.ABIERTA
                                    )
                                    SimpleDropdown(
                                        "Seguridad",
                                        WifiSecurity.entries.map { it.label },
                                        wifiSecurityIndex
                                    ) { wifiSecurityIndex = it }
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Red oculta", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Switch(checked = wifiHidden, onCheckedChange = { wifiHidden = it })
                                    }
                                }

                                QrPayloadKind.CONTACTO -> {
                                    OutlinedTextField(
                                        value = fieldA,
                                        onValueChange = { fieldA = it.take(80) },
                                        label = { Text("Nombre") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = fieldB,
                                        onValueChange = { fieldB = it.take(20) },
                                        label = { Text("Telefono") },
                                        modifier = Modifier.fillMaxWidth(),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = fieldC,
                                        onValueChange = { fieldC = it.take(80) },
                                        label = { Text("Correo") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                }

                                QrPayloadKind.SMS -> {
                                    OutlinedTextField(
                                        value = fieldA,
                                        onValueChange = { fieldA = it.take(20) },
                                        label = { Text("Numero") },
                                        modifier = Modifier.fillMaxWidth(),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = freeText,
                                        onValueChange = { freeText = it.take(300) },
                                        label = { Text("Mensaje") },
                                        modifier = Modifier.fillMaxWidth(),
                                        minLines = 2
                                    )
                                }

                                QrPayloadKind.EMAIL -> {
                                    OutlinedTextField(
                                        value = fieldA,
                                        onValueChange = { fieldA = it.take(80) },
                                        label = { Text("Para") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = fieldB,
                                        onValueChange = { fieldB = it.take(120) },
                                        label = { Text("Asunto") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = freeText,
                                        onValueChange = { freeText = it.take(600) },
                                        label = { Text("Mensaje") },
                                        modifier = Modifier.fillMaxWidth(),
                                        minLines = 2
                                    )
                                }

                                QrPayloadKind.TELEFONO -> OutlinedTextField(
                                    value = fieldA,
                                    onValueChange = { fieldA = it.take(20) },
                                    label = { Text("Numero") },
                                    modifier = Modifier.fillMaxWidth(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    singleLine = true
                                )

                                QrPayloadKind.WHATSAPP -> {
                                    OutlinedTextField(
                                        value = fieldA,
                                        onValueChange = { fieldA = it.filter(Char::isDigit).take(15) },
                                        label = { Text("Numero con codigo de pais (51…)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = freeText,
                                        onValueChange = { freeText = it.take(400) },
                                        label = { Text("Mensaje inicial") },
                                        modifier = Modifier.fillMaxWidth(),
                                        minLines = 2
                                    )
                                }

                                QrPayloadKind.UBICACION -> {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(
                                            value = fieldA,
                                            onValueChange = { fieldA = it.take(14) },
                                            label = { Text("Latitud") },
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )
                                        OutlinedTextField(
                                            value = fieldB,
                                            onValueChange = { fieldB = it.take(14) },
                                            label = { Text("Longitud") },
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )
                                    }
                                    OutlinedTextField(
                                        value = fieldC,
                                        onValueChange = { fieldC = it.take(60) },
                                        label = { Text("Etiqueta (opcional)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                }

                                QrPayloadKind.EVENTO -> {
                                    OutlinedTextField(
                                        value = fieldA,
                                        onValueChange = { fieldA = it.take(80) },
                                        label = { Text("Titulo") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = fieldB,
                                        onValueChange = { fieldB = it.take(80) },
                                        label = { Text("Lugar") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = fieldC,
                                        onValueChange = { fieldC = it.take(15) },
                                        label = { Text("Inicio (20260315T090000)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                }
                            }

                            SimpleDropdown(
                                "Correccion de error",
                                QrErrorCorrection.entries.map { it.label },
                                eccIndex
                            ) { eccIndex = it }
                            Text(
                                ecc.recovery,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    item {
                        QuickCard("Contenido") {
                            OutlinedTextField(
                                value = freeText,
                                onValueChange = { freeText = it.take(200) },
                                label = { Text(kind.inputHint) },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = if (kind.numericOnly) KeyboardType.Number else KeyboardType.Text
                                ),
                                singleLine = true
                            )
                            if (validation.suggestion != null && validation.suggestion != freeText) {
                                TextButton(onClick = { freeText = validation.suggestion.orEmpty() }) {
                                    Icon(Icons.Rounded.Bolt, contentDescription = null, tint = Gold)
                                    Text(" Usar ${validation.suggestion}")
                                }
                            }
                        }
                    }
                }

                item {
                    QuickCard {
                        Text(
                            validation.message,
                            color = if (validation.valid) NeonGreen else Danger,
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        validation.notes.forEach { NoteLine(it) }

                        val bitmap = preview
                        if (bitmap != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White, RoundedCornerShape(16.dp))
                                    .padding(10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = "Codigo generado",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(if (kind == BarcodeKind.QR) 300.dp else 170.dp)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        val name = if (kind == BarcodeKind.QR) "qr_gana_geo.png" else "codigo_gana_geo.png"
                                        saveLauncher.launch(name)
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NeonGreen,
                                        contentColor = DeepGreen
                                    )
                                ) {
                                    Icon(Icons.Rounded.Save, contentDescription = null)
                                    Text(" Guardar PNG")
                                }
                                OutlinedButton(
                                    onClick = {
                                        copyToClipboard(context, "Contenido del codigo", validation.normalized)
                                        onMessage("Contenido copiado.")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Rounded.ContentCopy, contentDescription = null)
                                    Text(" Copiar")
                                }
                            }
                        } else if (rendering) {
                            Text(
                                "Dibujando…",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            if (tab == 1) {
                item {
                    QuickCard("Leer un codigo") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { launchScanner() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonGreen,
                                    contentColor = DeepGreen
                                )
                            ) {
                                Icon(Icons.Rounded.QrCodeScanner, contentDescription = null)
                                Text(" Camara")
                            }
                            FilledTonalButton(
                                onClick = { imageLauncher.launch(arrayOf("image/*")) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.Photo, contentDescription = null)
                                Text(" Imagen")
                            }
                        }
                        Text(
                            "La lectura desde imagen reintenta con el contraste invertido, " +
                                "asi tambien entran los codigos claros sobre fondo oscuro.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (analysis != null) {
                    item {
                        QuickCard(analysis.kind) {
                            if (scannedFormat.isNotBlank()) {
                                Text(
                                    "Formato: $scannedFormat",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                analysis.summary,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            analysis.details.forEach { StatRow(it.first, it.second) }
                            analysis.warnings.forEach { NoteLine(it, warning = true) }

                            val action = analysis.action
                            if (action != null) {
                                Button(
                                    onClick = { openAction(action.uri, action.sendTo) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (analysis.warnings.isEmpty()) NeonGreen else Gold,
                                        contentColor = DeepGreen
                                    )
                                ) {
                                    Icon(Icons.Rounded.OpenInNew, contentDescription = null)
                                    Text(" ${action.label}")
                                }
                            }

                            OutlinedTextField(
                                value = scanned,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Contenido leido") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        copyToClipboard(context, "Codigo leido", scanned)
                                        onMessage("Contenido copiado.")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Rounded.ContentCopy, contentDescription = null)
                                    Text(" Copiar")
                                }
                                OutlinedButton(
                                    onClick = { scanned = ""; scannedFormat = "" },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Limpiar") }
                            }
                        }
                    }
                }
            }

            if (tab == 2) {
                if (history.isEmpty()) {
                    item {
                        QuickCard {
                            Text(
                                "Todavia no has leido ningun codigo en esta sesion.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    item {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${history.size} lecturas guardadas", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            TextButton(onClick = { history = emptyList() }) {
                                Icon(Icons.Rounded.Delete, contentDescription = null, tint = Danger)
                                Text(" Vaciar", color = Danger)
                            }
                        }
                    }
                    items(history.size) { index ->
                        val entry = history[index]
                        val info = remember(entry) { ScannedContentAnalyzer.analyze(entry) }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CardGreen),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().clickable {
                                scanned = entry
                                scannedFormat = ""
                                tab = 1
                            }
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    info.kind,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = NeonGreen,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    entry.take(140),
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ===========================================================================
// 2) Contador de palabras
// ===========================================================================

@Composable
fun WordCounterScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var text by rememberSaveable { mutableStateOf("") }
    var goalInput by rememberSaveable { mutableStateOf("") }
    var metrics by remember { mutableStateOf(DetailedTextMetrics.EMPTY) }
    var status by remember { mutableStateOf("") }

    // El analisis corre fuera del hilo principal y con un respiro de 180 ms:
    // con textos largos, calcular en cada tecla congelaria la escritura.
    LaunchedEffect(text) {
        if (text.isEmpty()) {
            metrics = DetailedTextMetrics.EMPTY
            return@LaunchedEffect
        }
        delay(180)
        metrics = withContext(Dispatchers.Default) { TextMetricsEngine.analyze(text) }
    }

    LaunchedEffect(status) {
        if (status.isNotBlank()) {
            delay(1800)
            status = ""
        }
    }

    val goal = goalInput.toIntOrNull() ?: 0

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Contador de palabras", "Metricas, legibilidad y limites reales", onBack)

        // Cinta fija: lo que la persona mira mientras escribe.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(Modifier.weight(1f)) {
                Text("${metrics.words}", style = MaterialTheme.typography.headlineSmall, color = NeonGreen, fontWeight = FontWeight.Bold)
                Text("palabras", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(Modifier.weight(1f)) {
                Text("${metrics.charactersWithSpaces}", style = MaterialTheme.typography.headlineSmall, color = NeonGreen, fontWeight = FontWeight.Bold)
                Text("caracteres", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    FocusLab.formatDuration(metrics.readingTimes.firstOrNull()?.seconds ?: 0L),
                    style = MaterialTheme.typography.headlineSmall,
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold
                )
                Text("lectura", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        QuickTabs(listOf("Escribir", "Metricas", "Legibilidad", "Limites"), tab) { tab = it }

        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (tab == 0) {
                item {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it.take(200_000) },
                        label = { Text("Pega o escribe tu texto") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 320.dp)
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                copyToClipboard(context, "Texto", text)
                                status = "Texto copiado."
                            },
                            enabled = text.isNotBlank(),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = null)
                            Text(" Copiar")
                        }
                        OutlinedButton(
                            onClick = { text = "" },
                            enabled = text.isNotEmpty(),
                            modifier = Modifier.weight(1f)
                        ) { Text("Limpiar") }
                    }
                }
                item {
                    QuickCard("Objetivo de palabras") {
                        OutlinedTextField(
                            value = goalInput,
                            onValueChange = { goalInput = it.filter(Char::isDigit).take(6) },
                            label = { Text("Meta (por ejemplo 500)") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )
                        if (goal > 0) {
                            LinearProgressIndicator(
                                progress = { (metrics.words.toFloat() / goal).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                if (metrics.words >= goal) "Meta cumplida: ${metrics.words} de $goal."
                                else "Faltan ${goal - metrics.words} palabras.",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (metrics.words >= goal) NeonGreen else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                if (status.isNotBlank()) {
                    item { NoteLine(status) }
                }
            }

            if (tab == 1) {
                item {
                    QuickCard("Recuento") {
                        StatRow("Palabras", "${metrics.words}")
                        StatRow("Palabras unicas", "${metrics.uniqueWords}")
                        StatRow("Caracteres", "${metrics.charactersWithSpaces}")
                        StatRow("Sin espacios", "${metrics.charactersNoSpaces}")
                        StatRow("Oraciones", "${metrics.sentences}")
                        StatRow("Parrafos", "${metrics.paragraphs}")
                        StatRow("Lineas", "${metrics.lines}")
                        StatRow("Silabas", "${metrics.syllables}")
                        StatRow(
                            "Palabra mas larga",
                            metrics.longestWord.ifBlank { "—" }
                        )
                        StatRow(
                            "Media por palabra",
                            if (metrics.words == 0) "—" else String.format(Locale.US, "%.1f letras", metrics.averageWordLength)
                        )
                        StatRow(
                            "Media por oracion",
                            if (metrics.sentences == 0) "—" else String.format(Locale.US, "%.1f palabras", metrics.averageSentenceWords)
                        )
                    }
                }
                item {
                    QuickCard("Tiempos") {
                        metrics.readingTimes.forEach { time ->
                            StatRow(
                                "${time.label} (${time.wordsPerMinute.toInt()} ppm)",
                                FocusLab.formatDuration(time.seconds)
                            )
                        }
                        Text(
                            "Velocidades del meta-analisis de Brysbaert (2019) ajustadas al espanol, " +
                                "cuyas palabras son mas largas que las inglesas.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (metrics.topWords.isNotEmpty()) {
                    item {
                        QuickCard("Palabras mas repetidas") {
                            metrics.topWords.forEach { entry ->
                                StatRow(
                                    entry.word,
                                    "${entry.count}  ·  ${String.format(Locale.US, "%.1f%%", entry.density)}"
                                )
                            }
                            Text(
                                "Se ignoran articulos y preposiciones. Por encima del 3% una palabra empieza a sonar repetitiva.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            if (tab == 2) {
                item {
                    QuickCard("Legibilidad en espanol") {
                        Text(
                            metrics.infleszLabel,
                            style = MaterialTheme.typography.headlineSmall,
                            color = NeonGreen,
                            fontWeight = FontWeight.Bold
                        )
                        LinearProgressIndicator(
                            progress = { (metrics.fleschSzigriszt.toFloat() / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        StatRow(
                            "Perspicuidad (Szigriszt-Pazos)",
                            String.format(Locale.US, "%.1f", metrics.fleschSzigriszt)
                        )
                        StatRow(
                            "Fernandez-Huerta",
                            String.format(Locale.US, "%.1f", metrics.fernandezHuerta)
                        )
                        StatRow(
                            "Silabas por palabra",
                            String.format(Locale.US, "%.2f", metrics.averageSyllablesPerWord)
                        )
                        Text(
                            metrics.infleszAdvice,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                item {
                    QuickCard("Como leer la escala") {
                        StatRow("Mas de 80", "Muy facil", Gold)
                        StatRow("65 a 80", "Bastante facil", Gold)
                        StatRow("55 a 65", "Normal (prensa)", Gold)
                        StatRow("40 a 55", "Algo dificil", Gold)
                        StatRow("Menos de 40", "Muy dificil", Danger)
                        Text(
                            "Escala INFLESZ, validada para textos en castellano. Las formulas de Flesch " +
                                "en ingles no sirven aqui: penalizan de mas nuestras palabras largas.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (tab == 3) {
                item {
                    QuickCard("SMS") {
                        StatRow("Codificacion", metrics.sms.encoding)
                        StatRow("Unidades", "${metrics.sms.units} de ${metrics.sms.perSegment}")
                        StatRow("Mensajes a enviar", "${metrics.sms.segments}")
                        if (metrics.sms.note.isNotBlank()) NoteLine(metrics.sms.note, warning = metrics.sms.encoding == "UCS-2")
                    }
                }
                item {
                    val limits = remember(text) { TextMetricsEngine.platformLimits(text) }
                    QuickCard("Limites por plataforma") {
                        limits.forEach { limit ->
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(limit.name, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        if (limit.exceeded) "+${-limit.remaining} de mas" else "quedan ${limit.remaining}",
                                        fontWeight = FontWeight.Bold,
                                        color = if (limit.exceeded) Danger else NeonGreen
                                    )
                                }
                                LinearProgressIndicator(
                                    progress = { limit.ratio },
                                    modifier = Modifier.fillMaxWidth(),
                                    color = if (limit.exceeded) Danger else NeonGreen
                                )
                                Spacer(Modifier.height(4.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ===========================================================================
// 3) Cronómetro y temporizador
// ===========================================================================

private const val TIMER_CHANNEL_ID = "ganageo_timer_v1"
private const val TIMER_NOTIFICATION_ID = 4021

private fun ensureTimerChannel(context: Context) {
    val manager = context.getSystemService(NotificationManager::class.java) ?: return
    if (manager.getNotificationChannel(TIMER_CHANNEL_ID) != null) return
    val channel = NotificationChannel(
        TIMER_CHANNEL_ID,
        "Temporizador y enfoque",
        NotificationManager.IMPORTANCE_HIGH
    ).apply {
        description = "Aviso cuando termina una cuenta regresiva o una sesion de estudio."
        enableVibration(true)
        setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
    }
    manager.createNotificationChannel(channel)
}

private fun notifyTimerDone(context: Context, title: String, body: String) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
        PackageManager.PERMISSION_GRANTED
    ) {
        return
    }
    ensureTimerChannel(context)
    val intent = Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val pending = PendingIntent.getActivity(
        context,
        0,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val notification = NotificationCompat.Builder(context, TIMER_CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle(title)
        .setContentText(body)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setCategory(NotificationCompat.CATEGORY_ALARM)
        .setAutoCancel(true)
        .setContentIntent(pending)
        .build()
    runCatching { NotificationManagerCompat.from(context).notify(TIMER_NOTIFICATION_ID, notification) }
}

private fun vibratorOf(context: Context): Vibrator? = runCatching {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }
}.getOrNull()

@Composable
fun StopwatchTimerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var notifyEnabled by rememberSaveable { mutableStateOf(false) }

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> notifyEnabled = granted }

    // ---- alarma sonora ----
    val ringtoneHolder = remember { mutableStateOf<Ringtone?>(null) }
    var alarmRinging by remember { mutableStateOf(false) }

    fun stopAlarm() {
        runCatching { ringtoneHolder.value?.stop() }
        ringtoneHolder.value = null
        runCatching { vibratorOf(context)?.cancel() }
        alarmRinging = false
    }

    fun startAlarm() {
        stopAlarm()
        runCatching {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val tone = RingtoneManager.getRingtone(context, uri)
            if (tone != null) {
                // USAGE_ALARM: suena por el canal de alarma, no por el de
                // notificaciones, que es el que la gente silencia.
                tone.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) tone.isLooping = true
                tone.play()
                ringtoneHolder.value = tone
            }
        }
        runCatching {
            vibratorOf(context)?.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400, 200, 700), -1)
            )
        }
        alarmRinging = true
    }

    // ---- cronómetro ----
    var swRunning by rememberSaveable { mutableStateOf(false) }
    var swAnchorRealtime by rememberSaveable { mutableLongStateOf(0L) }
    var swAnchorWall by rememberSaveable { mutableLongStateOf(0L) }
    var swAccumulated by rememberSaveable { mutableLongStateOf(0L) }
    var swLive by remember { mutableLongStateOf(0L) }
    var laps by rememberSaveable { mutableStateOf(listOf<Long>()) }
    val swElapsed = if (swRunning) swLive else swAccumulated

    // ---- temporizador ----
    var tmRunning by rememberSaveable { mutableStateOf(false) }
    var tmEndsRealtime by rememberSaveable { mutableLongStateOf(0L) }
    var tmEndsWall by rememberSaveable { mutableLongStateOf(0L) }
    var tmPaused by rememberSaveable { mutableLongStateOf(25 * 60_000L) }
    var tmTotal by rememberSaveable { mutableLongStateOf(25 * 60_000L) }
    var tmLive by remember { mutableLongStateOf(25 * 60_000L) }
    var tmFinished by remember { mutableStateOf(false) }
    var hoursInput by rememberSaveable { mutableStateOf("0") }
    var minutesInput by rememberSaveable { mutableStateOf("25") }
    var secondsInput by rememberSaveable { mutableStateOf("0") }
    val tmRemaining = if (tmRunning) tmLive else tmPaused

    // ---- sesiones de enfoque ----
    var presetIndex by rememberSaveable { mutableIntStateOf(0) }
    val preset = FocusLab.presets[presetIndex]
    var focusRunning by rememberSaveable { mutableStateOf(false) }
    var focusPhaseName by rememberSaveable { mutableStateOf(FocusPhase.FOCUS.name) }
    var focusEndsRealtime by rememberSaveable { mutableLongStateOf(0L) }
    var focusEndsWall by rememberSaveable { mutableLongStateOf(0L) }
    var focusPaused by rememberSaveable { mutableLongStateOf(0L) }
    var focusLive by remember { mutableLongStateOf(0L) }
    var completedFocus by rememberSaveable { mutableIntStateOf(0) }
    var focusTotalMillis by rememberSaveable { mutableLongStateOf(0L) }
    val focusPhase = runCatching { FocusPhase.valueOf(focusPhaseName) }.getOrDefault(FocusPhase.FOCUS)
    val focusPhaseTotal = preset.millisFor(focusPhase)
    val focusRemaining = if (focusRunning) focusLive else focusPaused.takeIf { it > 0L } ?: focusPhaseTotal

    fun readConfigured(): Long {
        val h = hoursInput.toLongOrNull() ?: 0L
        val m = minutesInput.toLongOrNull() ?: 0L
        val s = secondsInput.toLongOrNull() ?: 0L
        return ((h * 3600) + (m * 60) + s) * 1000L
    }

    // Un solo bucle de refresco para las tres modalidades. El valor siempre se
    // recalcula contra el reloj monotonico; este bucle solo repinta.
    LaunchedEffect(swRunning, tmRunning, focusRunning) {
        while (swRunning || tmRunning || focusRunning) {
            val nowRealtime = SystemClock.elapsedRealtime()
            val nowWall = System.currentTimeMillis()

            if (swRunning) {
                swLive = swAccumulated + FocusLab.elapsedSince(
                    TimeAnchor(swAnchorRealtime, swAnchorWall), nowRealtime, nowWall
                )
            }

            if (tmRunning) {
                val remaining = FocusLab.remainingUntil(
                    TimeAnchor(tmEndsRealtime, tmEndsWall), nowRealtime, nowWall
                )
                tmLive = remaining
                if (remaining <= 0L) {
                    tmRunning = false
                    tmPaused = 0L
                    tmFinished = true
                    startAlarm()
                    if (notifyEnabled) {
                        notifyTimerDone(context, "Tiempo cumplido", "Termino la cuenta regresiva.")
                    }
                }
            }

            if (focusRunning) {
                val remaining = FocusLab.remainingUntil(
                    TimeAnchor(focusEndsRealtime, focusEndsWall), nowRealtime, nowWall
                )
                focusLive = remaining
                if (remaining <= 0L) {
                    // Se releen fase y preset del estado: el bucle no se reinicia
                    // al cambiar de fase, y una copia capturada quedaria vieja.
                    val livePreset = FocusLab.presets[presetIndex]
                    val finishedPhase = runCatching { FocusPhase.valueOf(focusPhaseName) }
                        .getOrDefault(FocusPhase.FOCUS)
                    if (finishedPhase == FocusPhase.FOCUS) {
                        completedFocus += 1
                        focusTotalMillis += livePreset.focusMillis
                    }
                    val next = FocusLab.nextPhase(finishedPhase, completedFocus, livePreset)
                    val nextTotal = livePreset.millisFor(next)
                    focusPhaseName = next.name
                    focusEndsRealtime = SystemClock.elapsedRealtime() + nextTotal
                    focusEndsWall = System.currentTimeMillis() + nextTotal
                    focusLive = nextTotal
                    focusPaused = 0L
                    startAlarm()
                    if (notifyEnabled) {
                        notifyTimerDone(
                            context,
                            if (next == FocusPhase.FOCUS) "A estudiar" else "Descanso",
                            "Termino ${finishedPhase.label.lowercase(Locale.getDefault())}. Ahora toca ${next.label.lowercase(Locale.getDefault())}."
                        )
                    }
                }
            }

            delay(50)
        }
    }

    // Pantalla encendida solo mientras algo corre y estamos en la herramienta.
    DisposableEffect(swRunning, tmRunning, focusRunning) {
        view.keepScreenOn = swRunning || tmRunning || focusRunning
        onDispose { view.keepScreenOn = false }
    }

    DisposableEffect(Unit) {
        onDispose { stopAlarm() }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Cronometro y temporizador", "Mide sesiones de estudio y descansos", onBack)
        QuickTabs(listOf("Cronometro", "Temporizador", "Enfoque"), tab) { tab = it }

        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (alarmRinging) {
                item {
                    Button(
                        onClick = { stopAlarm() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepGreen)
                    ) {
                        Icon(Icons.Rounded.Stop, contentDescription = null)
                        Text(" Detener alarma")
                    }
                }
            }

            if (tab == 0) {
                item {
                    QuickCard {
                        Column(
                            Modifier.fillMaxWidth().padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(18.dp)
                        ) {
                            BigDigits(FocusLab.formatStopwatch(swElapsed), NeonGreen)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        if (swRunning) {
                                            swAccumulated = swElapsed
                                            swRunning = false
                                        } else {
                                            swAnchorRealtime = SystemClock.elapsedRealtime()
                                            swAnchorWall = System.currentTimeMillis()
                                            swLive = swAccumulated
                                            swRunning = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NeonGreen,
                                        contentColor = DeepGreen
                                    )
                                ) {
                                    Icon(
                                        if (swRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = null
                                    )
                                    Text(if (swRunning) " Pausar" else " Iniciar")
                                }
                                OutlinedButton(
                                    onClick = { laps = laps + swElapsed },
                                    enabled = swRunning
                                ) {
                                    Icon(Icons.Rounded.Flag, contentDescription = null)
                                    Text(" Vuelta")
                                }
                                OutlinedButton(onClick = {
                                    swRunning = false
                                    swAccumulated = 0L
                                    swLive = 0L
                                    laps = emptyList()
                                }) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null)
                                    Text(" Cero")
                                }
                            }
                        }
                    }
                }
                if (laps.isNotEmpty()) {
                    item {
                        QuickCard("Vueltas") {
                            laps.asReversed().forEachIndexed { indexFromEnd, total ->
                                val number = laps.size - indexFromEnd
                                val previous = if (number >= 2) laps[number - 2] else 0L
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Vuelta $number", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        FocusLab.formatStopwatch(total - previous),
                                        fontWeight = FontWeight.Bold,
                                        color = NeonGreen,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        FocusLab.formatStopwatch(total),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (tab == 1) {
                item {
                    QuickCard {
                        Column(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            CircularCountdown(
                                progress = FocusLab.progress(tmRemaining, tmTotal),
                                color = if (tmFinished) Gold else NeonGreen
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    BigDigits(FocusLab.formatTimer(tmRemaining), if (tmFinished) Gold else NeonGreen)
                                    if (tmFinished) {
                                        Text("Tiempo cumplido", color = Gold, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        if (tmRunning) {
                                            tmPaused = tmRemaining
                                            tmRunning = false
                                        } else {
                                            val base = if (tmPaused > 0L) tmPaused else readConfigured()
                                            if (base > 0L) {
                                                stopAlarm()
                                                if (tmTotal <= 0L || tmPaused <= 0L) tmTotal = base
                                                tmEndsRealtime = SystemClock.elapsedRealtime() + base
                                                tmEndsWall = System.currentTimeMillis() + base
                                                tmLive = base
                                                tmFinished = false
                                                tmRunning = true
                                            }
                                        }
                                    },
                                    enabled = tmRunning || tmPaused > 0L || readConfigured() > 0L,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NeonGreen,
                                        contentColor = DeepGreen
                                    )
                                ) {
                                    Icon(
                                        if (tmRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = null
                                    )
                                    Text(if (tmRunning) " Pausar" else " Iniciar")
                                }
                                OutlinedButton(onClick = {
                                    stopAlarm()
                                    tmRunning = false
                                    tmFinished = false
                                    val base = readConfigured()
                                    tmPaused = base
                                    tmTotal = base
                                    tmLive = base
                                }) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null)
                                    Text(" Reiniciar")
                                }
                            }
                        }
                    }
                }

                if (!tmRunning) {
                    item {
                        QuickCard("Duracion") {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = hoursInput,
                                    onValueChange = {
                                        hoursInput = it.filter(Char::isDigit).take(2)
                                        tmPaused = readConfigured()
                                        tmTotal = tmPaused
                                        tmLive = tmPaused
                                    },
                                    label = { Text("Horas") },
                                    modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = minutesInput,
                                    onValueChange = {
                                        minutesInput = it.filter(Char::isDigit).take(2)
                                        tmPaused = readConfigured()
                                        tmTotal = tmPaused
                                        tmLive = tmPaused
                                    },
                                    label = { Text("Min") },
                                    modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = secondsInput,
                                    onValueChange = {
                                        secondsInput = it.filter(Char::isDigit).take(2)
                                        tmPaused = readConfigured()
                                        tmTotal = tmPaused
                                        tmLive = tmPaused
                                    },
                                    label = { Text("Seg") },
                                    modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(1, 3, 5, 10, 15, 25, 45).forEach { minutes ->
                                    QuickChip("$minutes m", minutesInput == minutes.toString() && hoursInput == "0") {
                                        hoursInput = "0"
                                        minutesInput = minutes.toString()
                                        secondsInput = "0"
                                        tmPaused = minutes * 60_000L
                                        tmTotal = tmPaused
                                        tmLive = tmPaused
                                        tmFinished = false
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (tab == 2) {
                item {
                    QuickCard("Ritmo de estudio") {
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FocusLab.presets.forEachIndexed { index, option ->
                                QuickChip(option.name, index == presetIndex) {
                                    if (!focusRunning) {
                                        presetIndex = index
                                        focusPhaseName = FocusPhase.FOCUS.name
                                        focusPaused = 0L
                                        focusLive = FocusLab.presets[index].focusMillis
                                    }
                                }
                            }
                        }
                        Text(
                            preset.note,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "${preset.focusMinutes} min de enfoque · ${preset.breakMinutes} min de descanso · " +
                                "descanso largo de ${preset.longBreakMinutes} min cada ${preset.cyclesBeforeLongBreak} vueltas",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                item {
                    QuickCard {
                        Column(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text(
                                focusPhase.label.uppercase(Locale.getDefault()),
                                style = MaterialTheme.typography.labelLarge,
                                color = if (focusPhase == FocusPhase.FOCUS) NeonGreen else Gold,
                                fontWeight = FontWeight.Bold
                            )
                            CircularCountdown(
                                progress = FocusLab.progress(focusRemaining, focusPhaseTotal),
                                color = if (focusPhase == FocusPhase.FOCUS) NeonGreen else Gold
                            ) {
                                BigDigits(
                                    FocusLab.formatTimer(focusRemaining),
                                    if (focusPhase == FocusPhase.FOCUS) NeonGreen else Gold
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        if (focusRunning) {
                                            focusPaused = focusRemaining
                                            focusRunning = false
                                        } else {
                                            stopAlarm()
                                            val base = if (focusPaused > 0L) focusPaused else focusPhaseTotal
                                            focusEndsRealtime = SystemClock.elapsedRealtime() + base
                                            focusEndsWall = System.currentTimeMillis() + base
                                            focusLive = base
                                            focusPaused = 0L
                                            focusRunning = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NeonGreen,
                                        contentColor = DeepGreen
                                    )
                                ) {
                                    Icon(
                                        if (focusRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = null
                                    )
                                    Text(if (focusRunning) " Pausar" else " Iniciar")
                                }
                                OutlinedButton(onClick = {
                                    stopAlarm()
                                    focusRunning = false
                                    focusPhaseName = FocusPhase.FOCUS.name
                                    focusPaused = 0L
                                    focusLive = preset.focusMillis
                                }) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null)
                                    Text(" Reiniciar")
                                }
                            }
                        }
                    }
                }

                item {
                    QuickCard("Hoy") {
                        StatRow("Enfoques completados", "$completedFocus")
                        StatRow("Tiempo de estudio", FocusLab.formatAccumulated(focusTotalMillis))
                        StatRow(
                            "Siguiente descanso largo",
                            if (preset.cyclesBeforeLongBreak <= 0) "—"
                            else "en ${preset.cyclesBeforeLongBreak - (completedFocus % preset.cyclesBeforeLongBreak)} enfoques"
                        )
                        TextButton(onClick = { completedFocus = 0; focusTotalMillis = 0L }) {
                            Text("Reiniciar el conteo del dia", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item {
                QuickCard("Aviso al terminar") {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Avisarme aunque salga de la herramienta",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = notifyEnabled,
                            onCheckedChange = { wanted ->
                                if (!wanted) {
                                    notifyEnabled = false
                                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                    ContextCompat.checkSelfPermission(
                                        context, Manifest.permission.POST_NOTIFICATIONS
                                    ) != PackageManager.PERMISSION_GRANTED
                                ) {
                                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    notifyEnabled = true
                                }
                            }
                        )
                    }
                    NoteLine(
                        "El tiempo se mide con el reloj interno del telefono, asi que no se " +
                            "desfasa aunque apagues la pantalla."
                    )
                    NoteLine(
                        "Si tu telefono es Xiaomi, Huawei, Oppo o Vivo, quita a Gana Geo de la " +
                            "optimizacion de bateria o el sistema puede cerrar la app y cortar el aviso.",
                        warning = true
                    )
                }
            }
        }
    }
}
