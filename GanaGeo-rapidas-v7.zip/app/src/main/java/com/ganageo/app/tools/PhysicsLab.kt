package com.ganageo.app.tools

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

enum class PhysicsBlock(val label: String) {
    KINEMATICS("Cinemática"),
    DYNAMICS("Dinámica"),
    ENERGY("Trabajo y energía"),
    MOMENTUM("Cantidad de movimiento"),
    FLUIDS("Fluidos"),
    THERMAL("Termodinámica"),
    WAVES("Ondas y sonido"),
    ELECTRICITY("Electricidad y magnetismo"),
    OPTICS("Óptica"),
    GRAVITY("Gravitación")
}

data class PhysicsVariable(
    val symbol: String,
    val name: String,
    val unit: String
)

data class PhysicsFormula(
    val id: String,
    val title: String,
    val expression: String,
    val block: PhysicsBlock,
    val variables: List<PhysicsVariable>,
    val explanation: String,
    private val solver: (String, Map<String, Double>) -> Double
) {
    /**
     * Despeja la variable pedida a partir de las demás.
     * Si el despeje no existe o los datos no lo permiten devuelve NaN.
     */
    fun solve(target: String, values: Map<String, Double>): Double =
        runCatching { solver(target, values) }.getOrDefault(Double.NaN)

    fun canSolve(target: String): Boolean = target in variables.map { it.symbol }
}

/**
 * Catálogo de fórmulas de física de secundaria y primeros cursos.
 *
 * Cada fórmula sabe despejar cualquiera de sus variables, así que el usuario
 * escribe lo que conoce y deja en blanco lo que busca, en vez de tener una
 * pantalla distinta por cada despeje.
 */
object PhysicsLab {

    private fun v(symbol: String, name: String, unit: String) = PhysicsVariable(symbol, name, unit)

    private fun get(values: Map<String, Double>, key: String): Double =
        values[key] ?: Double.NaN

    val formulas: List<PhysicsFormula> = listOf(

        // ---------------- Cinemática ----------------
        PhysicsFormula(
            "mru", "Movimiento rectilíneo uniforme", "v = d / t", PhysicsBlock.KINEMATICS,
            listOf(
                v("v", "Velocidad", "m/s"),
                v("d", "Distancia", "m"),
                v("t", "Tiempo", "s")
            ),
            "Velocidad constante: la distancia crece de forma proporcional al tiempo."
        ) { target, x ->
            when (target) {
                "v" -> get(x, "d") / get(x, "t")
                "d" -> get(x, "v") * get(x, "t")
                else -> get(x, "d") / get(x, "v")
            }
        },

        PhysicsFormula(
            "mruv_v", "Velocidad con aceleración", "v = v₀ + a·t", PhysicsBlock.KINEMATICS,
            listOf(
                v("v", "Velocidad final", "m/s"),
                v("v0", "Velocidad inicial", "m/s"),
                v("a", "Aceleración", "m/s²"),
                v("t", "Tiempo", "s")
            ),
            "Movimiento con aceleración constante."
        ) { target, x ->
            when (target) {
                "v" -> get(x, "v0") + get(x, "a") * get(x, "t")
                "v0" -> get(x, "v") - get(x, "a") * get(x, "t")
                "a" -> (get(x, "v") - get(x, "v0")) / get(x, "t")
                else -> (get(x, "v") - get(x, "v0")) / get(x, "a")
            }
        },

        PhysicsFormula(
            "mruv_x", "Posición con aceleración", "x = x₀ + v₀·t + ½·a·t²", PhysicsBlock.KINEMATICS,
            listOf(
                v("x", "Posición final", "m"),
                v("x0", "Posición inicial", "m"),
                v("v0", "Velocidad inicial", "m/s"),
                v("a", "Aceleración", "m/s²"),
                v("t", "Tiempo", "s")
            ),
            "Ecuación de posición del movimiento uniformemente acelerado."
        ) { target, x ->
            val t = get(x, "t")
            when (target) {
                "x" -> get(x, "x0") + get(x, "v0") * t + 0.5 * get(x, "a") * t * t
                "x0" -> get(x, "x") - get(x, "v0") * t - 0.5 * get(x, "a") * t * t
                "v0" -> (get(x, "x") - get(x, "x0") - 0.5 * get(x, "a") * t * t) / t
                "a" -> 2 * (get(x, "x") - get(x, "x0") - get(x, "v0") * t) / (t * t)
                else -> {
                    // Resolver ½a·t² + v₀·t + (x₀ − x) = 0
                    val a = 0.5 * get(x, "a")
                    val b = get(x, "v0")
                    val c = get(x, "x0") - get(x, "x")
                    if (abs(a) < 1e-12) -c / b
                    else {
                        val disc = b * b - 4 * a * c
                        if (disc < 0) Double.NaN
                        else {
                            val r1 = (-b + sqrt(disc)) / (2 * a)
                            val r2 = (-b - sqrt(disc)) / (2 * a)
                            listOf(r1, r2).filter { it >= 0 }.minOrNull() ?: Double.NaN
                        }
                    }
                }
            }
        },

        PhysicsFormula(
            "torricelli", "Ecuación sin tiempo", "v² = v₀² + 2·a·Δx", PhysicsBlock.KINEMATICS,
            listOf(
                v("v", "Velocidad final", "m/s"),
                v("v0", "Velocidad inicial", "m/s"),
                v("a", "Aceleración", "m/s²"),
                v("dx", "Desplazamiento", "m")
            ),
            "Útil cuando no se conoce el tiempo."
        ) { target, x ->
            when (target) {
                "v" -> sqrt(get(x, "v0").pow(2) + 2 * get(x, "a") * get(x, "dx"))
                "v0" -> sqrt(get(x, "v").pow(2) - 2 * get(x, "a") * get(x, "dx"))
                "a" -> (get(x, "v").pow(2) - get(x, "v0").pow(2)) / (2 * get(x, "dx"))
                else -> (get(x, "v").pow(2) - get(x, "v0").pow(2)) / (2 * get(x, "a"))
            }
        },

        PhysicsFormula(
            "tiro", "Tiro parabólico: alcance", "R = v₀²·sen(2θ) / g", PhysicsBlock.KINEMATICS,
            listOf(
                v("R", "Alcance horizontal", "m"),
                v("v0", "Velocidad inicial", "m/s"),
                v("th", "Ángulo", "grados"),
                v("g", "Gravedad", "m/s²")
            ),
            "Alcance de un proyectil lanzado y recibido a la misma altura."
        ) { target, x ->
            val g = if (get(x, "g").isNaN()) 9.80665 else get(x, "g")
            when (target) {
                "R" -> get(x, "v0").pow(2) * sin(2 * get(x, "th") * PI / 180) / g
                "v0" -> sqrt(get(x, "R") * g / sin(2 * get(x, "th") * PI / 180))
                "th" -> asin((get(x, "R") * g / get(x, "v0").pow(2)).coerceIn(-1.0, 1.0)) * 180 / PI / 2
                else -> get(x, "v0").pow(2) * sin(2 * get(x, "th") * PI / 180) / get(x, "R")
            }
        },

        // ---------------- Dinámica ----------------
        PhysicsFormula(
            "newton2", "Segunda ley de Newton", "F = m·a", PhysicsBlock.DYNAMICS,
            listOf(
                v("F", "Fuerza", "N"),
                v("m", "Masa", "kg"),
                v("a", "Aceleración", "m/s²")
            ),
            "La fuerza neta es igual a masa por aceleración."
        ) { target, x ->
            when (target) {
                "F" -> get(x, "m") * get(x, "a")
                "m" -> get(x, "F") / get(x, "a")
                else -> get(x, "F") / get(x, "m")
            }
        },

        PhysicsFormula(
            "peso", "Peso", "P = m·g", PhysicsBlock.DYNAMICS,
            listOf(
                v("P", "Peso", "N"),
                v("m", "Masa", "kg"),
                v("g", "Gravedad", "m/s²")
            ),
            "El peso es la fuerza con que la gravedad atrae al cuerpo. No es lo mismo que la masa."
        ) { target, x ->
            val g = if (get(x, "g").isNaN()) 9.80665 else get(x, "g")
            when (target) {
                "P" -> get(x, "m") * g
                "m" -> get(x, "P") / g
                else -> get(x, "P") / get(x, "m")
            }
        },

        PhysicsFormula(
            "friccion", "Fuerza de rozamiento", "f = μ·N", PhysicsBlock.DYNAMICS,
            listOf(
                v("f", "Fuerza de rozamiento", "N"),
                v("mu", "Coeficiente μ", "—"),
                v("N", "Fuerza normal", "N")
            ),
            "El rozamiento se opone al movimiento y depende de la fuerza normal."
        ) { target, x ->
            when (target) {
                "f" -> get(x, "mu") * get(x, "N")
                "mu" -> get(x, "f") / get(x, "N")
                else -> get(x, "f") / get(x, "mu")
            }
        },

        PhysicsFormula(
            "centripeta", "Fuerza centrípeta", "Fc = m·v² / r", PhysicsBlock.DYNAMICS,
            listOf(
                v("Fc", "Fuerza centrípeta", "N"),
                v("m", "Masa", "kg"),
                v("v", "Velocidad", "m/s"),
                v("r", "Radio", "m")
            ),
            "Fuerza que mantiene a un cuerpo girando; apunta al centro de la curva."
        ) { target, x ->
            when (target) {
                "Fc" -> get(x, "m") * get(x, "v").pow(2) / get(x, "r")
                "m" -> get(x, "Fc") * get(x, "r") / get(x, "v").pow(2)
                "v" -> sqrt(get(x, "Fc") * get(x, "r") / get(x, "m"))
                else -> get(x, "m") * get(x, "v").pow(2) / get(x, "Fc")
            }
        },

        // ---------------- Trabajo y energía ----------------
        PhysicsFormula(
            "trabajo", "Trabajo", "W = F·d·cos(θ)", PhysicsBlock.ENERGY,
            listOf(
                v("W", "Trabajo", "J"),
                v("F", "Fuerza", "N"),
                v("d", "Distancia", "m"),
                v("th", "Ángulo", "grados")
            ),
            "Solo la componente de la fuerza en la dirección del movimiento hace trabajo."
        ) { target, x ->
            val angle = if (get(x, "th").isNaN()) 0.0 else get(x, "th")
            val cosine = cos(angle * PI / 180)
            when (target) {
                "W" -> get(x, "F") * get(x, "d") * cosine
                "F" -> get(x, "W") / (get(x, "d") * cosine)
                "d" -> get(x, "W") / (get(x, "F") * cosine)
                else -> Double.NaN
            }
        },

        PhysicsFormula(
            "cinetica", "Energía cinética", "Ec = ½·m·v²", PhysicsBlock.ENERGY,
            listOf(
                v("Ec", "Energía cinética", "J"),
                v("m", "Masa", "kg"),
                v("v", "Velocidad", "m/s")
            ),
            "Energía asociada al movimiento. Crece con el cuadrado de la velocidad."
        ) { target, x ->
            when (target) {
                "Ec" -> 0.5 * get(x, "m") * get(x, "v").pow(2)
                "m" -> 2 * get(x, "Ec") / get(x, "v").pow(2)
                else -> sqrt(2 * get(x, "Ec") / get(x, "m"))
            }
        },

        PhysicsFormula(
            "potencial", "Energía potencial gravitatoria", "Ep = m·g·h", PhysicsBlock.ENERGY,
            listOf(
                v("Ep", "Energía potencial", "J"),
                v("m", "Masa", "kg"),
                v("g", "Gravedad", "m/s²"),
                v("h", "Altura", "m")
            ),
            "Energía almacenada por la posición respecto de un nivel de referencia."
        ) { target, x ->
            val g = if (get(x, "g").isNaN()) 9.80665 else get(x, "g")
            when (target) {
                "Ep" -> get(x, "m") * g * get(x, "h")
                "m" -> get(x, "Ep") / (g * get(x, "h"))
                "h" -> get(x, "Ep") / (get(x, "m") * g)
                else -> get(x, "Ep") / (get(x, "m") * get(x, "h"))
            }
        },

        PhysicsFormula(
            "elastica", "Energía elástica", "Ee = ½·k·x²", PhysicsBlock.ENERGY,
            listOf(
                v("Ee", "Energía elástica", "J"),
                v("k", "Constante del resorte", "N/m"),
                v("x", "Deformación", "m")
            ),
            "Energía guardada en un resorte comprimido o estirado."
        ) { target, x ->
            when (target) {
                "Ee" -> 0.5 * get(x, "k") * get(x, "x").pow(2)
                "k" -> 2 * get(x, "Ee") / get(x, "x").pow(2)
                else -> sqrt(2 * get(x, "Ee") / get(x, "k"))
            }
        },

        PhysicsFormula(
            "potencia", "Potencia", "P = W / t", PhysicsBlock.ENERGY,
            listOf(
                v("P", "Potencia", "W"),
                v("W", "Trabajo o energía", "J"),
                v("t", "Tiempo", "s")
            ),
            "Rapidez con que se realiza trabajo. 1 W = 1 J/s."
        ) { target, x ->
            when (target) {
                "P" -> get(x, "W") / get(x, "t")
                "W" -> get(x, "P") * get(x, "t")
                else -> get(x, "W") / get(x, "P")
            }
        },

        // ---------------- Cantidad de movimiento ----------------
        PhysicsFormula(
            "momento", "Cantidad de movimiento", "p = m·v", PhysicsBlock.MOMENTUM,
            listOf(
                v("p", "Momento lineal", "kg·m/s"),
                v("m", "Masa", "kg"),
                v("v", "Velocidad", "m/s")
            ),
            "En un choque, la suma de los momentos se conserva."
        ) { target, x ->
            when (target) {
                "p" -> get(x, "m") * get(x, "v")
                "m" -> get(x, "p") / get(x, "v")
                else -> get(x, "p") / get(x, "m")
            }
        },

        PhysicsFormula(
            "impulso", "Impulso", "J = F·Δt = Δp", PhysicsBlock.MOMENTUM,
            listOf(
                v("J", "Impulso", "N·s"),
                v("F", "Fuerza media", "N"),
                v("t", "Tiempo de contacto", "s")
            ),
            "El impulso es igual al cambio de la cantidad de movimiento."
        ) { target, x ->
            when (target) {
                "J" -> get(x, "F") * get(x, "t")
                "F" -> get(x, "J") / get(x, "t")
                else -> get(x, "J") / get(x, "F")
            }
        },

        // ---------------- Fluidos ----------------
        PhysicsFormula(
            "densidad", "Densidad", "ρ = m / V", PhysicsBlock.FLUIDS,
            listOf(
                v("ro", "Densidad", "kg/m³"),
                v("m", "Masa", "kg"),
                v("V", "Volumen", "m³")
            ),
            "Cuánta masa hay en cada unidad de volumen."
        ) { target, x ->
            when (target) {
                "ro" -> get(x, "m") / get(x, "V")
                "m" -> get(x, "ro") * get(x, "V")
                else -> get(x, "m") / get(x, "ro")
            }
        },

        PhysicsFormula(
            "presion", "Presión", "P = F / A", PhysicsBlock.FLUIDS,
            listOf(
                v("P", "Presión", "Pa"),
                v("F", "Fuerza", "N"),
                v("A", "Área", "m²")
            ),
            "La misma fuerza sobre menos área produce más presión."
        ) { target, x ->
            when (target) {
                "P" -> get(x, "F") / get(x, "A")
                "F" -> get(x, "P") * get(x, "A")
                else -> get(x, "F") / get(x, "P")
            }
        },

        PhysicsFormula(
            "hidrostatica", "Presión hidrostática", "P = ρ·g·h", PhysicsBlock.FLUIDS,
            listOf(
                v("P", "Presión", "Pa"),
                v("ro", "Densidad del fluido", "kg/m³"),
                v("g", "Gravedad", "m/s²"),
                v("h", "Profundidad", "m")
            ),
            "La presión de un líquido depende solo de la profundidad, no de la forma del recipiente."
        ) { target, x ->
            val g = if (get(x, "g").isNaN()) 9.80665 else get(x, "g")
            when (target) {
                "P" -> get(x, "ro") * g * get(x, "h")
                "ro" -> get(x, "P") / (g * get(x, "h"))
                "h" -> get(x, "P") / (get(x, "ro") * g)
                else -> get(x, "P") / (get(x, "ro") * get(x, "h"))
            }
        },

        PhysicsFormula(
            "arquimedes", "Empuje de Arquímedes", "E = ρ·V·g", PhysicsBlock.FLUIDS,
            listOf(
                v("E", "Empuje", "N"),
                v("ro", "Densidad del fluido", "kg/m³"),
                v("V", "Volumen sumergido", "m³"),
                v("g", "Gravedad", "m/s²")
            ),
            "Todo cuerpo sumergido recibe un empuje igual al peso del fluido que desaloja."
        ) { target, x ->
            val g = if (get(x, "g").isNaN()) 9.80665 else get(x, "g")
            when (target) {
                "E" -> get(x, "ro") * get(x, "V") * g
                "ro" -> get(x, "E") / (get(x, "V") * g)
                "V" -> get(x, "E") / (get(x, "ro") * g)
                else -> get(x, "E") / (get(x, "ro") * get(x, "V"))
            }
        },

        PhysicsFormula(
            "caudal", "Ecuación de continuidad", "A₁·v₁ = A₂·v₂", PhysicsBlock.FLUIDS,
            listOf(
                v("A1", "Área 1", "m²"),
                v("v1", "Velocidad 1", "m/s"),
                v("A2", "Área 2", "m²"),
                v("v2", "Velocidad 2", "m/s")
            ),
            "Al estrecharse una tubería el fluido acelera: el caudal se conserva."
        ) { target, x ->
            when (target) {
                "A1" -> get(x, "A2") * get(x, "v2") / get(x, "v1")
                "v1" -> get(x, "A2") * get(x, "v2") / get(x, "A1")
                "A2" -> get(x, "A1") * get(x, "v1") / get(x, "v2")
                else -> get(x, "A1") * get(x, "v1") / get(x, "A2")
            }
        },

        // ---------------- Termodinámica ----------------
        PhysicsFormula(
            "calor", "Calor sensible", "Q = m·c·ΔT", PhysicsBlock.THERMAL,
            listOf(
                v("Q", "Calor", "J"),
                v("m", "Masa", "kg"),
                v("c", "Calor específico", "J/(kg·K)"),
                v("dT", "Variación de temperatura", "K")
            ),
            "Calor necesario para cambiar la temperatura sin cambiar de estado. Agua: c = 4186 J/(kg·K)."
        ) { target, x ->
            when (target) {
                "Q" -> get(x, "m") * get(x, "c") * get(x, "dT")
                "m" -> get(x, "Q") / (get(x, "c") * get(x, "dT"))
                "c" -> get(x, "Q") / (get(x, "m") * get(x, "dT"))
                else -> get(x, "Q") / (get(x, "m") * get(x, "c"))
            }
        },

        PhysicsFormula(
            "latente", "Calor latente", "Q = m·L", PhysicsBlock.THERMAL,
            listOf(
                v("Q", "Calor", "J"),
                v("m", "Masa", "kg"),
                v("L", "Calor latente", "J/kg")
            ),
            "Calor del cambio de estado: la temperatura no sube mientras se funde o hierve."
        ) { target, x ->
            when (target) {
                "Q" -> get(x, "m") * get(x, "L")
                "m" -> get(x, "Q") / get(x, "L")
                else -> get(x, "Q") / get(x, "m")
            }
        },

        PhysicsFormula(
            "gasideal", "Ley de los gases ideales", "P·V = n·R·T", PhysicsBlock.THERMAL,
            listOf(
                v("P", "Presión", "Pa"),
                v("V", "Volumen", "m³"),
                v("n", "Moles", "mol"),
                v("T", "Temperatura", "K")
            ),
            "R = 8,314462618 J/(mol·K). La temperatura va siempre en kelvin."
        ) { target, x ->
            val r = 8.314462618
            when (target) {
                "P" -> get(x, "n") * r * get(x, "T") / get(x, "V")
                "V" -> get(x, "n") * r * get(x, "T") / get(x, "P")
                "n" -> get(x, "P") * get(x, "V") / (r * get(x, "T"))
                else -> get(x, "P") * get(x, "V") / (r * get(x, "n"))
            }
        },

        PhysicsFormula(
            "dilatacion", "Dilatación lineal", "ΔL = α·L₀·ΔT", PhysicsBlock.THERMAL,
            listOf(
                v("dL", "Variación de longitud", "m"),
                v("al", "Coeficiente α", "1/K"),
                v("L0", "Longitud inicial", "m"),
                v("dT", "Variación de temperatura", "K")
            ),
            "Los materiales se alargan al calentarse. Acero: α ≈ 1,2×10⁻⁵ 1/K."
        ) { target, x ->
            when (target) {
                "dL" -> get(x, "al") * get(x, "L0") * get(x, "dT")
                "al" -> get(x, "dL") / (get(x, "L0") * get(x, "dT"))
                "L0" -> get(x, "dL") / (get(x, "al") * get(x, "dT"))
                else -> get(x, "dL") / (get(x, "al") * get(x, "L0"))
            }
        },

        // ---------------- Ondas ----------------
        PhysicsFormula(
            "onda", "Velocidad de una onda", "v = f·λ", PhysicsBlock.WAVES,
            listOf(
                v("v", "Velocidad", "m/s"),
                v("f", "Frecuencia", "Hz"),
                v("la", "Longitud de onda", "m")
            ),
            "Sonido en aire ≈ 343 m/s. Luz en vacío = 3×10⁸ m/s."
        ) { target, x ->
            when (target) {
                "v" -> get(x, "f") * get(x, "la")
                "f" -> get(x, "v") / get(x, "la")
                else -> get(x, "v") / get(x, "f")
            }
        },

        PhysicsFormula(
            "periodo", "Periodo y frecuencia", "T = 1 / f", PhysicsBlock.WAVES,
            listOf(
                v("T", "Periodo", "s"),
                v("f", "Frecuencia", "Hz")
            ),
            "El periodo es lo que tarda una oscilación completa."
        ) { target, x ->
            when (target) {
                "T" -> 1 / get(x, "f")
                else -> 1 / get(x, "T")
            }
        },

        PhysicsFormula(
            "pendulo", "Péndulo simple", "T = 2π·√(L/g)", PhysicsBlock.WAVES,
            listOf(
                v("T", "Periodo", "s"),
                v("L", "Longitud", "m"),
                v("g", "Gravedad", "m/s²")
            ),
            "Para oscilaciones pequeñas el periodo no depende de la masa."
        ) { target, x ->
            val g = if (get(x, "g").isNaN()) 9.80665 else get(x, "g")
            when (target) {
                "T" -> 2 * PI * sqrt(get(x, "L") / g)
                "L" -> g * (get(x, "T") / (2 * PI)).pow(2)
                else -> get(x, "L") / (get(x, "T") / (2 * PI)).pow(2)
            }
        },

        // ---------------- Electricidad ----------------
        PhysicsFormula(
            "ohm", "Ley de Ohm", "V = I·R", PhysicsBlock.ELECTRICITY,
            listOf(
                v("V", "Voltaje", "V"),
                v("I", "Corriente", "A"),
                v("R", "Resistencia", "Ω")
            ),
            "La base de todos los circuitos."
        ) { target, x ->
            when (target) {
                "V" -> get(x, "I") * get(x, "R")
                "I" -> get(x, "V") / get(x, "R")
                else -> get(x, "V") / get(x, "I")
            }
        },

        PhysicsFormula(
            "potenciaelec", "Potencia eléctrica", "P = V·I", PhysicsBlock.ELECTRICITY,
            listOf(
                v("P", "Potencia", "W"),
                v("V", "Voltaje", "V"),
                v("I", "Corriente", "A")
            ),
            "También P = I²·R = V²/R."
        ) { target, x ->
            when (target) {
                "P" -> get(x, "V") * get(x, "I")
                "V" -> get(x, "P") / get(x, "I")
                else -> get(x, "P") / get(x, "V")
            }
        },

        PhysicsFormula(
            "coulomb", "Ley de Coulomb", "F = k·q₁·q₂ / r²", PhysicsBlock.ELECTRICITY,
            listOf(
                v("F", "Fuerza", "N"),
                v("q1", "Carga 1", "C"),
                v("q2", "Carga 2", "C"),
                v("r", "Distancia", "m")
            ),
            "k = 8,988×10⁹ N·m²/C². Cargas iguales se repelen."
        ) { target, x ->
            val k = 8.9875517862e9
            when (target) {
                "F" -> k * get(x, "q1") * get(x, "q2") / get(x, "r").pow(2)
                "q1" -> get(x, "F") * get(x, "r").pow(2) / (k * get(x, "q2"))
                "q2" -> get(x, "F") * get(x, "r").pow(2) / (k * get(x, "q1"))
                else -> sqrt(k * get(x, "q1") * get(x, "q2") / get(x, "F"))
            }
        },

        PhysicsFormula(
            "lorentz", "Fuerza magnética sobre una carga", "F = q·v·B·sen(θ)", PhysicsBlock.ELECTRICITY,
            listOf(
                v("F", "Fuerza", "N"),
                v("q", "Carga", "C"),
                v("v", "Velocidad", "m/s"),
                v("B", "Campo magnético", "T"),
                v("th", "Ángulo", "grados")
            ),
            "La fuerza es máxima cuando la velocidad es perpendicular al campo."
        ) { target, x ->
            val angle = if (get(x, "th").isNaN()) 90.0 else get(x, "th")
            val s = sin(angle * PI / 180)
            when (target) {
                "F" -> get(x, "q") * get(x, "v") * get(x, "B") * s
                "q" -> get(x, "F") / (get(x, "v") * get(x, "B") * s)
                "v" -> get(x, "F") / (get(x, "q") * get(x, "B") * s)
                "B" -> get(x, "F") / (get(x, "q") * get(x, "v") * s)
                else -> Double.NaN
            }
        },

        // ---------------- Óptica ----------------
        PhysicsFormula(
            "snell", "Ley de Snell", "n₁·sen(θ₁) = n₂·sen(θ₂)", PhysicsBlock.OPTICS,
            listOf(
                v("n1", "Índice medio 1", "—"),
                v("th1", "Ángulo incidente", "grados"),
                v("n2", "Índice medio 2", "—"),
                v("th2", "Ángulo refractado", "grados")
            ),
            "Aire ≈ 1,00; agua ≈ 1,33; vidrio ≈ 1,50."
        ) { target, x ->
            when (target) {
                "th2" -> asin(
                    (get(x, "n1") * sin(get(x, "th1") * PI / 180) / get(x, "n2")).coerceIn(-1.0, 1.0)
                ) * 180 / PI
                "th1" -> asin(
                    (get(x, "n2") * sin(get(x, "th2") * PI / 180) / get(x, "n1")).coerceIn(-1.0, 1.0)
                ) * 180 / PI
                "n1" -> get(x, "n2") * sin(get(x, "th2") * PI / 180) / sin(get(x, "th1") * PI / 180)
                else -> get(x, "n1") * sin(get(x, "th1") * PI / 180) / sin(get(x, "th2") * PI / 180)
            }
        },

        PhysicsFormula(
            "lentes", "Ecuación de lentes y espejos", "1/f = 1/o + 1/i", PhysicsBlock.OPTICS,
            listOf(
                v("f", "Distancia focal", "cm"),
                v("o", "Distancia al objeto", "cm"),
                v("i", "Distancia a la imagen", "cm")
            ),
            "Con el criterio de signos habitual: f > 0 en lentes convergentes."
        ) { target, x ->
            when (target) {
                "f" -> 1 / (1 / get(x, "o") + 1 / get(x, "i"))
                "o" -> 1 / (1 / get(x, "f") - 1 / get(x, "i"))
                else -> 1 / (1 / get(x, "f") - 1 / get(x, "o"))
            }
        },

        // ---------------- Gravitación ----------------
        PhysicsFormula(
            "gravitacion", "Gravitación universal", "F = G·m₁·m₂ / r²", PhysicsBlock.GRAVITY,
            listOf(
                v("F", "Fuerza", "N"),
                v("m1", "Masa 1", "kg"),
                v("m2", "Masa 2", "kg"),
                v("r", "Distancia entre centros", "m")
            ),
            "G = 6,674 30×10⁻¹¹ m³/(kg·s²), la constante fundamental peor conocida."
        ) { target, x ->
            val g = 6.67430e-11
            when (target) {
                "F" -> g * get(x, "m1") * get(x, "m2") / get(x, "r").pow(2)
                "m1" -> get(x, "F") * get(x, "r").pow(2) / (g * get(x, "m2"))
                "m2" -> get(x, "F") * get(x, "r").pow(2) / (g * get(x, "m1"))
                else -> sqrt(g * get(x, "m1") * get(x, "m2") / get(x, "F"))
            }
        }
    )

    fun byBlock(block: PhysicsBlock): List<PhysicsFormula> = formulas.filter { it.block == block }

    fun byId(id: String): PhysicsFormula? = formulas.firstOrNull { it.id == id }

    /** Conversiones habituales que hacen falta antes de aplicar una fórmula. */
    data class Conversion(val label: String, val toBase: Double, val baseUnit: String)

    val conversions: Map<String, List<Conversion>> = mapOf(
        "longitud" to listOf(
            Conversion("m", 1.0, "m"),
            Conversion("km", 1000.0, "m"),
            Conversion("cm", 0.01, "m"),
            Conversion("mm", 0.001, "m")
        ),
        "masa" to listOf(
            Conversion("kg", 1.0, "kg"),
            Conversion("g", 0.001, "kg"),
            Conversion("t", 1000.0, "kg")
        ),
        "tiempo" to listOf(
            Conversion("s", 1.0, "s"),
            Conversion("min", 60.0, "s"),
            Conversion("h", 3600.0, "s")
        ),
        "velocidad" to listOf(
            Conversion("m/s", 1.0, "m/s"),
            Conversion("km/h", 1 / 3.6, "m/s")
        ),
        "presión" to listOf(
            Conversion("Pa", 1.0, "Pa"),
            Conversion("kPa", 1000.0, "Pa"),
            Conversion("atm", 101325.0, "Pa"),
            Conversion("bar", 100000.0, "Pa"),
            Conversion("mmHg", 133.322, "Pa")
        )
    )

    fun celsiusToKelvin(celsius: Double) = celsius + 273.15
    fun kelvinToCelsius(kelvin: Double) = kelvin - 273.15
    fun fahrenheitToCelsius(f: Double) = (f - 32) * 5 / 9
}
