package com.ganageo.app.tools

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

data class ShapeField(val key: String, val label: String, val hint: String = "")

/** dimension 1 = longitud, 2 = área, 3 = volumen, 0 = sin unidad (ángulos, cantidades). */
data class ShapeOutput(val label: String, val value: Double, val dimension: Int, val note: String = "")

data class GeometryShape(
    val id: String,
    val name: String,
    val group: String,
    val fields: List<ShapeField>,
    val formulas: List<String>,
    val diagramNote: String,
    val compute: (Map<String, Double>) -> List<ShapeOutput>
)

/**
 * Catálogo de geometría.
 *
 * Cada figura declara qué medidas pide y qué fórmula usa, y la nota del diagrama
 * aclara la duda de siempre: si «h» es la altura del cuerpo o la de la cara.
 */
object GeometryLab {

    private fun f(key: String, label: String, hint: String = "") = ShapeField(key, label, hint)
    private fun get(values: Map<String, Double>, key: String): Double =
        values[key] ?: throw IllegalArgumentException("Falta el dato: $key")

    private fun requirePositive(value: Double, name: String): Double {
        require(value > 0) { "$name debe ser mayor que cero." }
        return value
    }

    const val GROUP_PLANE = "Figuras planas"
    const val GROUP_SOLID = "Cuerpos"

    val shapes: List<GeometryShape> = listOf(

        // ---------------- Figuras planas ----------------
        GeometryShape(
            "cuadrado", "Cuadrado", GROUP_PLANE,
            listOf(f("l", "Lado")),
            listOf("A = l²", "P = 4·l", "diagonal = l·√2"),
            "Los cuatro lados miden lo mismo."
        ) { v ->
            val l = requirePositive(get(v, "l"), "El lado")
            listOf(
                ShapeOutput("Área", l * l, 2),
                ShapeOutput("Perímetro", 4 * l, 1),
                ShapeOutput("Diagonal", l * sqrt(2.0), 1)
            )
        },

        GeometryShape(
            "rectangulo", "Rectángulo", GROUP_PLANE,
            listOf(f("b", "Base"), f("h", "Altura")),
            listOf("A = b·h", "P = 2(b + h)", "diagonal = √(b² + h²)"),
            "La altura es el lado perpendicular a la base."
        ) { v ->
            val b = requirePositive(get(v, "b"), "La base")
            val h = requirePositive(get(v, "h"), "La altura")
            listOf(
                ShapeOutput("Área", b * h, 2),
                ShapeOutput("Perímetro", 2 * (b + h), 1),
                ShapeOutput("Diagonal", sqrt(b * b + h * h), 1)
            )
        },

        GeometryShape(
            "triangulo", "Triángulo", GROUP_PLANE,
            listOf(f("b", "Base"), f("h", "Altura", "Perpendicular a la base")),
            listOf("A = b·h ÷ 2"),
            "La altura va desde el vértice opuesto y cae perpendicular a la base, no es un lado."
        ) { v ->
            val b = requirePositive(get(v, "b"), "La base")
            val h = requirePositive(get(v, "h"), "La altura")
            listOf(ShapeOutput("Área", b * h / 2, 2))
        },

        GeometryShape(
            "triangulo_heron", "Triángulo por sus tres lados", GROUP_PLANE,
            listOf(f("a", "Lado a"), f("b", "Lado b"), f("c", "Lado c")),
            listOf("s = (a + b + c) ÷ 2", "A = √(s(s−a)(s−b)(s−c))"),
            "Fórmula de Herón: sirve cuando conoces los tres lados pero no la altura."
        ) { v ->
            val a = requirePositive(get(v, "a"), "El lado a")
            val b = requirePositive(get(v, "b"), "El lado b")
            val c = requirePositive(get(v, "c"), "El lado c")
            require(a + b > c && a + c > b && b + c > a) {
                "Con esos lados no se puede formar un triángulo: un lado no puede medir más que la suma de los otros dos."
            }
            val s = (a + b + c) / 2
            val area = sqrt(s * (s - a) * (s - b) * (s - c))
            val angleA = Math.toDegrees(acos((b * b + c * c - a * a) / (2 * b * c)))
            val angleB = Math.toDegrees(acos((a * a + c * c - b * b) / (2 * a * c)))
            listOf(
                ShapeOutput("Área", area, 2),
                ShapeOutput("Perímetro", a + b + c, 1),
                ShapeOutput("Semiperímetro", s, 1),
                ShapeOutput("Ángulo A", angleA, 0, "grados"),
                ShapeOutput("Ángulo B", angleB, 0, "grados"),
                ShapeOutput("Ángulo C", 180 - angleA - angleB, 0, "grados")
            )
        },

        GeometryShape(
            "paralelogramo", "Paralelogramo", GROUP_PLANE,
            listOf(f("b", "Base"), f("h", "Altura"), f("l", "Lado oblicuo")),
            listOf("A = b·h", "P = 2(b + l)"),
            "La altura es la distancia perpendicular entre las bases, no el lado inclinado."
        ) { v ->
            val b = requirePositive(get(v, "b"), "La base")
            val h = requirePositive(get(v, "h"), "La altura")
            val l = requirePositive(get(v, "l"), "El lado")
            listOf(
                ShapeOutput("Área", b * h, 2),
                ShapeOutput("Perímetro", 2 * (b + l), 1)
            )
        },

        GeometryShape(
            "rombo", "Rombo", GROUP_PLANE,
            listOf(f("D", "Diagonal mayor"), f("d", "Diagonal menor")),
            listOf("A = (D·d) ÷ 2", "lado = √((D/2)² + (d/2)²)"),
            "Las diagonales se cruzan en el centro formando ángulo recto."
        ) { v ->
            val big = requirePositive(get(v, "D"), "La diagonal mayor")
            val small = requirePositive(get(v, "d"), "La diagonal menor")
            val side = sqrt((big / 2).let { it * it } + (small / 2).let { it * it })
            listOf(
                ShapeOutput("Área", big * small / 2, 2),
                ShapeOutput("Lado", side, 1),
                ShapeOutput("Perímetro", 4 * side, 1)
            )
        },

        GeometryShape(
            "trapecio", "Trapecio", GROUP_PLANE,
            listOf(f("B", "Base mayor"), f("b", "Base menor"), f("h", "Altura")),
            listOf("A = ((B + b) ÷ 2)·h"),
            "Las dos bases son los lados paralelos; la altura es la distancia entre ellas."
        ) { v ->
            val big = requirePositive(get(v, "B"), "La base mayor")
            val small = requirePositive(get(v, "b"), "La base menor")
            val h = requirePositive(get(v, "h"), "La altura")
            listOf(
                ShapeOutput("Área", (big + small) / 2 * h, 2),
                ShapeOutput("Mediana", (big + small) / 2, 1)
            )
        },

        GeometryShape(
            "circulo", "Círculo", GROUP_PLANE,
            listOf(f("r", "Radio")),
            listOf("A = π·r²", "C = 2·π·r"),
            "El radio va del centro al borde; el diámetro es el doble."
        ) { v ->
            val r = requirePositive(get(v, "r"), "El radio")
            listOf(
                ShapeOutput("Área", PI * r * r, 2),
                ShapeOutput("Circunferencia", 2 * PI * r, 1),
                ShapeOutput("Diámetro", 2 * r, 1)
            )
        },

        GeometryShape(
            "corona", "Corona circular", GROUP_PLANE,
            listOf(f("R", "Radio exterior"), f("r", "Radio interior")),
            listOf("A = π(R² − r²)"),
            "Es el anillo que queda entre dos círculos con el mismo centro."
        ) { v ->
            val big = requirePositive(get(v, "R"), "El radio exterior")
            val small = requirePositive(get(v, "r"), "El radio interior")
            require(big > small) { "El radio exterior debe ser mayor que el interior." }
            listOf(
                ShapeOutput("Área", PI * (big * big - small * small), 2),
                ShapeOutput("Perímetro total", 2 * PI * (big + small), 1),
                ShapeOutput("Ancho del anillo", big - small, 1)
            )
        },

        GeometryShape(
            "sector", "Sector circular", GROUP_PLANE,
            listOf(f("r", "Radio"), f("a", "Ángulo en grados")),
            listOf("A = (α ÷ 360)·π·r²", "arco = π·r·α ÷ 180"),
            "Es la porción de círculo, como una rebanada de pizza."
        ) { v ->
            val r = requirePositive(get(v, "r"), "El radio")
            val angle = get(v, "a")
            require(angle > 0 && angle <= 360) { "El ángulo debe estar entre 0 y 360 grados." }
            val rad = angle * PI / 180
            listOf(
                ShapeOutput("Área", 0.5 * r * r * rad, 2),
                ShapeOutput("Longitud del arco", r * rad, 1),
                ShapeOutput("Perímetro", r * rad + 2 * r, 1)
            )
        },

        GeometryShape(
            "segmento", "Segmento circular", GROUP_PLANE,
            listOf(f("r", "Radio"), f("a", "Ángulo en grados")),
            listOf("A = 0,5·r²(θ − sen θ)", "cuerda = 2·r·sen(θ/2)"),
            "Es la parte que queda entre una cuerda y el arco."
        ) { v ->
            val r = requirePositive(get(v, "r"), "El radio")
            val angle = get(v, "a")
            require(angle > 0 && angle <= 360) { "El ángulo debe estar entre 0 y 360 grados." }
            val rad = angle * PI / 180
            listOf(
                ShapeOutput("Área", 0.5 * r * r * (rad - sin(rad)), 2),
                ShapeOutput("Cuerda", 2 * r * sin(rad / 2), 1),
                ShapeOutput("Flecha (sagita)", r * (1 - cos(rad / 2)), 1)
            )
        },

        GeometryShape(
            "elipse", "Elipse", GROUP_PLANE,
            listOf(f("a", "Semieje mayor"), f("b", "Semieje menor")),
            listOf("A = π·a·b", "P ≈ π(a+b)(1 + 3h/(10 + √(4−3h)))"),
            "Los semiejes se miden desde el centro. El perímetro es aproximado."
        ) { v ->
            val a = requirePositive(get(v, "a"), "El semieje mayor")
            val b = requirePositive(get(v, "b"), "El semieje menor")
            val h = ((a - b) / (a + b)).let { it * it }
            val perimeter = PI * (a + b) * (1 + 3 * h / (10 + sqrt(4 - 3 * h)))
            listOf(
                ShapeOutput("Área", PI * a * b, 2),
                ShapeOutput("Perímetro", perimeter, 1, "aproximación de Ramanujan")
            )
        },

        GeometryShape(
            "poligono", "Polígono regular", GROUP_PLANE,
            listOf(f("n", "Número de lados"), f("l", "Longitud del lado")),
            listOf("a = l ÷ (2·tan(180/n))", "A = (n·l²) ÷ (4·tan(180/n))"),
            "Todos los lados y todos los ángulos son iguales. La apotema va del centro al punto medio de un lado."
        ) { v ->
            val n = get(v, "n")
            require(n >= 3 && n == Math.floor(n)) { "El número de lados debe ser un entero de 3 o más." }
            val l = requirePositive(get(v, "l"), "El lado")
            val sides = n.toInt()
            val apothem = l / (2 * tan(PI / sides))
            val perimeter = sides * l
            listOf(
                ShapeOutput("Área", perimeter * apothem / 2, 2),
                ShapeOutput("Perímetro", perimeter, 1),
                ShapeOutput("Apotema", apothem, 1),
                ShapeOutput("Ángulo interior", (sides - 2) * 180.0 / sides, 0, "grados"),
                ShapeOutput("Ángulo central", 360.0 / sides, 0, "grados")
            )
        },

        // ---------------- Cuerpos ----------------
        GeometryShape(
            "cubo", "Cubo", GROUP_SOLID,
            listOf(f("l", "Arista")),
            listOf("V = l³", "A = 6·l²"),
            "Las doce aristas miden lo mismo."
        ) { v ->
            val l = requirePositive(get(v, "l"), "La arista")
            listOf(
                ShapeOutput("Volumen", l * l * l, 3),
                ShapeOutput("Área total", 6 * l * l, 2),
                ShapeOutput("Diagonal", l * sqrt(3.0), 1)
            )
        },

        GeometryShape(
            "ortoedro", "Prisma rectangular", GROUP_SOLID,
            listOf(f("a", "Largo"), f("b", "Ancho"), f("c", "Alto")),
            listOf("V = a·b·c", "A = 2(ab + ac + bc)"),
            "Es una caja: tres medidas perpendiculares entre sí."
        ) { v ->
            val a = requirePositive(get(v, "a"), "El largo")
            val b = requirePositive(get(v, "b"), "El ancho")
            val c = requirePositive(get(v, "c"), "El alto")
            listOf(
                ShapeOutput("Volumen", a * b * c, 3),
                ShapeOutput("Área total", 2 * (a * b + a * c + b * c), 2),
                ShapeOutput("Diagonal", sqrt(a * a + b * b + c * c), 1)
            )
        },

        GeometryShape(
            "cilindro", "Cilindro", GROUP_SOLID,
            listOf(f("r", "Radio de la base"), f("h", "Altura")),
            listOf("V = π·r²·h", "A_lateral = 2·π·r·h", "A_total = 2·π·r(r + h)"),
            "La altura es la distancia entre las dos tapas."
        ) { v ->
            val r = requirePositive(get(v, "r"), "El radio")
            val h = requirePositive(get(v, "h"), "La altura")
            listOf(
                ShapeOutput("Volumen", PI * r * r * h, 3),
                ShapeOutput("Área lateral", 2 * PI * r * h, 2),
                ShapeOutput("Área total", 2 * PI * r * (r + h), 2)
            )
        },

        GeometryShape(
            "cono", "Cono", GROUP_SOLID,
            listOf(f("r", "Radio de la base"), f("h", "Altura")),
            listOf("g = √(r² + h²)", "V = π·r²·h ÷ 3", "A_total = π·r(r + g)"),
            "La altura va del vértice al centro de la base; la generatriz va del vértice al borde."
        ) { v ->
            val r = requirePositive(get(v, "r"), "El radio")
            val h = requirePositive(get(v, "h"), "La altura")
            val g = sqrt(r * r + h * h)
            listOf(
                ShapeOutput("Volumen", PI * r * r * h / 3, 3),
                ShapeOutput("Generatriz", g, 1),
                ShapeOutput("Área lateral", PI * r * g, 2),
                ShapeOutput("Área total", PI * r * (r + g), 2)
            )
        },

        GeometryShape(
            "tronco_cono", "Tronco de cono", GROUP_SOLID,
            listOf(f("R", "Radio mayor"), f("r", "Radio menor"), f("h", "Altura")),
            listOf("V = (π·h ÷ 3)(R² + r² + R·r)", "g = √((R−r)² + h²)"),
            "Es un cono al que se le cortó la punta con un corte paralelo a la base."
        ) { v ->
            val big = requirePositive(get(v, "R"), "El radio mayor")
            val small = requirePositive(get(v, "r"), "El radio menor")
            val h = requirePositive(get(v, "h"), "La altura")
            require(big > small) { "El radio mayor debe ser mayor que el menor." }
            val g = sqrt((big - small) * (big - small) + h * h)
            val lateral = PI * (big + small) * g
            listOf(
                ShapeOutput("Volumen", PI * h / 3 * (big * big + small * small + big * small), 3),
                ShapeOutput("Generatriz", g, 1),
                ShapeOutput("Área lateral", lateral, 2),
                ShapeOutput("Área total", lateral + PI * (big * big + small * small), 2)
            )
        },

        GeometryShape(
            "esfera", "Esfera", GROUP_SOLID,
            listOf(f("r", "Radio")),
            listOf("V = (4 ÷ 3)·π·r³", "A = 4·π·r²"),
            "Todos los puntos están a la misma distancia del centro."
        ) { v ->
            val r = requirePositive(get(v, "r"), "El radio")
            listOf(
                ShapeOutput("Volumen", 4.0 / 3.0 * PI * r * r * r, 3),
                ShapeOutput("Área", 4 * PI * r * r, 2)
            )
        },

        GeometryShape(
            "casquete", "Casquete esférico", GROUP_SOLID,
            listOf(f("R", "Radio de la esfera"), f("h", "Altura del casquete")),
            listOf("V = (π·h² ÷ 3)(3R − h)", "A_curva = 2·π·R·h"),
            "Es el trozo que queda al cortar una esfera con un plano, como la cúpula de un tanque."
        ) { v ->
            val big = requirePositive(get(v, "R"), "El radio de la esfera")
            val h = requirePositive(get(v, "h"), "La altura del casquete")
            require(h <= 2 * big) { "La altura del casquete no puede superar el diámetro de la esfera." }
            listOf(
                ShapeOutput("Volumen", PI * h * h / 3 * (3 * big - h), 3),
                ShapeOutput("Área curva", 2 * PI * big * h, 2),
                ShapeOutput("Radio del corte", sqrt(h * (2 * big - h)), 1)
            )
        },

        GeometryShape(
            "piramide", "Pirámide de base cuadrada", GROUP_SOLID,
            listOf(f("l", "Lado de la base"), f("h", "Altura del cuerpo")),
            listOf("V = l²·h ÷ 3", "apotema de la cara = √(h² + (l/2)²)"),
            "Ojo: la altura del cuerpo va del vértice al centro de la base. La apotema de la cara es distinta y sube por el triángulo lateral."
        ) { v ->
            val l = requirePositive(get(v, "l"), "El lado")
            val h = requirePositive(get(v, "h"), "La altura")
            val faceApothem = sqrt(h * h + (l / 2) * (l / 2))
            val lateral = 2 * l * faceApothem
            listOf(
                ShapeOutput("Volumen", l * l * h / 3, 3),
                ShapeOutput("Apotema de la cara", faceApothem, 1),
                ShapeOutput("Área lateral", lateral, 2),
                ShapeOutput("Área total", lateral + l * l, 2)
            )
        },

        GeometryShape(
            "tronco_piramide", "Tronco de pirámide", GROUP_SOLID,
            listOf(f("A1", "Área de la base mayor"), f("A2", "Área de la base menor"), f("h", "Altura")),
            listOf("V = (h ÷ 3)(A₁ + A₂ + √(A₁·A₂))"),
            "Se le cortó la punta a una pirámide. Aquí se piden las ÁREAS de las bases, no los lados."
        ) { v ->
            val a1 = requirePositive(get(v, "A1"), "El área mayor")
            val a2 = requirePositive(get(v, "A2"), "El área menor")
            val h = requirePositive(get(v, "h"), "La altura")
            listOf(ShapeOutput("Volumen", h / 3 * (a1 + a2 + sqrt(a1 * a2)), 3))
        },

        GeometryShape(
            "toro", "Toro (dona)", GROUP_SOLID,
            listOf(f("R", "Radio del centro al tubo"), f("r", "Radio del tubo")),
            listOf("V = 2·π²·R·r²", "A = 4·π²·R·r"),
            "R va del centro de la dona al centro del tubo; r es el grosor del tubo."
        ) { v ->
            val big = requirePositive(get(v, "R"), "El radio mayor")
            val small = requirePositive(get(v, "r"), "El radio del tubo")
            require(big > small) { "El radio del tubo debe ser menor que el radio mayor." }
            listOf(
                ShapeOutput("Volumen", 2 * PI * PI * big * small * small, 3),
                ShapeOutput("Área", 4 * PI * PI * big * small, 2)
            )
        }
    )

    fun byId(id: String): GeometryShape? = shapes.firstOrNull { it.id == id }

    fun byGroup(group: String): List<GeometryShape> = shapes.filter { it.group == group }

    // ------------------------------------------------------------------
    // Resolución de triángulos
    // ------------------------------------------------------------------

    data class TriangleSolution(
        val sides: Triple<Double, Double, Double>,
        val angles: Triple<Double, Double, Double>,
        val area: Double,
        val kind: String,
        val steps: List<String>
    )

    /** Conocidos los tres lados: ley de cosenos. */
    fun solveSides(a: Double, b: Double, c: Double): TriangleSolution {
        require(a > 0 && b > 0 && c > 0) { "Los lados deben ser mayores que cero." }
        require(a + b > c && a + c > b && b + c > a) {
            "Con esos lados no se forma un triángulo."
        }
        val angleA = Math.toDegrees(acos((b * b + c * c - a * a) / (2 * b * c)))
        val angleB = Math.toDegrees(acos((a * a + c * c - b * b) / (2 * a * c)))
        val angleC = 180 - angleA - angleB
        val s = (a + b + c) / 2
        return TriangleSolution(
            sides = Triple(a, b, c),
            angles = Triple(angleA, angleB, angleC),
            area = sqrt(s * (s - a) * (s - b) * (s - c)),
            kind = classify(a, b, c, angleA, angleB, angleC),
            steps = listOf(
                "Ley de cosenos: cos A = (b² + c² − a²) ÷ (2·b·c)",
                "A = ${MathEngine.formatNumber(angleA, 2)}°",
                "B = ${MathEngine.formatNumber(angleB, 2)}°",
                "C = 180° − A − B = ${MathEngine.formatNumber(angleC, 2)}°",
                "Área por Herón con s = ${MathEngine.formatNumber(s, 4)}"
            )
        )
    }

    /** Conocidos dos lados y el ángulo entre ellos. */
    fun solveTwoSidesAngle(a: Double, b: Double, angleCDegrees: Double): TriangleSolution {
        require(a > 0 && b > 0) { "Los lados deben ser mayores que cero." }
        require(angleCDegrees > 0 && angleCDegrees < 180) { "El ángulo debe estar entre 0 y 180 grados." }
        val angleC = angleCDegrees * PI / 180
        val c = sqrt(a * a + b * b - 2 * a * b * cos(angleC))
        val solution = solveSides(a, b, c)
        return solution.copy(
            steps = listOf(
                "Ley de cosenos: c² = a² + b² − 2·a·b·cos C",
                "c = ${MathEngine.formatNumber(c, 4)}"
            ) + solution.steps
        )
    }

    private fun classify(a: Double, b: Double, c: Double, angleA: Double, angleB: Double, angleC: Double): String {
        val maxAngle = maxOf(angleA, angleB, angleC)
        val byAngle = when {
            abs(maxAngle - 90) < 0.01 -> "rectángulo"
            maxAngle > 90 -> "obtusángulo"
            else -> "acutángulo"
        }
        val bySides = when {
            abs(a - b) < 1e-9 && abs(b - c) < 1e-9 -> "equilátero"
            abs(a - b) < 1e-9 || abs(b - c) < 1e-9 || abs(a - c) < 1e-9 -> "isósceles"
            else -> "escaleno"
        }
        return "$bySides y $byAngle"
    }

    /** Teorema de Pitágoras: halla la hipotenusa o el cateto que falte. */
    fun pythagoras(legA: Double?, legB: Double?, hypotenuse: Double?): Pair<String, Double> = when {
        legA != null && legB != null -> "Hipotenusa" to sqrt(legA * legA + legB * legB)
        legA != null && hypotenuse != null -> {
            require(hypotenuse > legA) { "La hipotenusa debe ser mayor que el cateto." }
            "Cateto" to sqrt(hypotenuse * hypotenuse - legA * legA)
        }
        legB != null && hypotenuse != null -> {
            require(hypotenuse > legB) { "La hipotenusa debe ser mayor que el cateto." }
            "Cateto" to sqrt(hypotenuse * hypotenuse - legB * legB)
        }
        else -> throw IllegalArgumentException("Deja en blanco solo el valor que quieres calcular.")
    }

    // ------------------------------------------------------------------
    // Geometría analítica
    // ------------------------------------------------------------------

    data class Point(val x: Double, val y: Double)

    fun distance(p: Point, q: Point): Double = sqrt((q.x - p.x).let { it * it } + (q.y - p.y).let { it * it })

    fun midpoint(p: Point, q: Point): Point = Point((p.x + q.x) / 2, (p.y + q.y) / 2)

    fun slope(p: Point, q: Point): Double? =
        if (abs(q.x - p.x) < 1e-12) null else (q.y - p.y) / (q.x - p.x)

    fun lineEquation(p: Point, q: Point): String {
        val m = slope(p, q) ?: return "x = ${MathEngine.formatNumber(p.x, 4)} (recta vertical)"
        val b = p.y - m * p.x
        val sign = if (b < 0) "−" else "+"
        return "y = ${MathEngine.formatNumber(m, 4)}x $sign ${MathEngine.formatNumber(abs(b), 4)}"
    }

    /**
     * Área de un polígono a partir de las coordenadas de sus vértices.
     *
     * Es la fórmula del cordón, la misma que usa un topógrafo para calcular el
     * área de un terreno con las coordenadas de los mojones. Solo vale para
     * polígonos que no se cruzan a sí mismos.
     */
    fun shoelaceArea(points: List<Point>): Double {
        require(points.size >= 3) { "Se necesitan al menos tres vértices." }
        var sum = 0.0
        for (i in points.indices) {
            val current = points[i]
            val next = points[(i + 1) % points.size]
            sum += current.x * next.y - next.x * current.y
        }
        return abs(sum) / 2
    }

    fun polygonPerimeter(points: List<Point>): Double {
        require(points.size >= 3) { "Se necesitan al menos tres vértices." }
        var total = 0.0
        for (i in points.indices) {
            total += distance(points[i], points[(i + 1) % points.size])
        }
        return total
    }

    /** Lee coordenadas escritas como «10 20» o «10,20», una por línea. */
    fun parsePoints(raw: String): List<Point> {
        val points = raw.lines().mapNotNull { line ->
            val parts = line.trim().split(Regex("[,;\\s]+")).filter { it.isNotBlank() }
            if (parts.size < 2) return@mapNotNull null
            val x = parts[0].replace(',', '.').toDoubleOrNull()
            val y = parts[1].replace(',', '.').toDoubleOrNull()
            if (x == null || y == null) null else Point(x, y)
        }
        require(points.size >= 3) { "Escribe al menos tres puntos, uno por línea: «10 20»." }
        return points
    }

    /** Sufijo de unidad según la dimensión del resultado. */
    fun unitSuffix(dimension: Int, unit: String): String = when (dimension) {
        1 -> " $unit"
        2 -> " $unit²"
        3 -> " $unit³"
        else -> ""
    }
}
