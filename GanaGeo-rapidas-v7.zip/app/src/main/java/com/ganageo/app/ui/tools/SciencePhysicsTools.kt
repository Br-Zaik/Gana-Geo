package com.ganageo.app.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.MathEngine
import com.ganageo.app.tools.PhysicsBlock
import com.ganageo.app.tools.PhysicsConstants
import com.ganageo.app.tools.PhysicsFormula
import com.ganageo.app.tools.PhysicsLab
import com.ganageo.app.tools.SolveStep

/**
 * Calculadora de física.
 *
 * En vez de una pantalla por despeje, cada fórmula sabe despejar cualquiera de
 * sus variables: se rellena lo que se conoce, se deja en blanco lo que se busca
 * y la app hace el resto. Así una sola fórmula cubre todos los ejercicios que
 * suelen aparecer con ella.
 */
@Composable
fun PhysicsCalculatorScreen(onBack: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var blockIndex by rememberSaveable { mutableIntStateOf(0) }
    var formulaId by rememberSaveable { mutableStateOf(PhysicsLab.formulas.first().id) }
    val values = remember { mutableStateMapOf<String, String>() }
    var result by remember { mutableStateOf<Triple<String, Double, String>?>(null) }
    var steps by remember { mutableStateOf<List<SolveStep>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    val block = PhysicsBlock.entries[blockIndex]
    val formulasInBlock = PhysicsLab.byBlock(block)
    val formula = PhysicsLab.byId(formulaId) ?: formulasInBlock.first()

    fun selectFormula(next: PhysicsFormula) {
        formulaId = next.id
        values.clear()
        result = null
        steps = emptyList()
        error = null
    }

    fun compute() {
        val filled = formula.variables.mapNotNull { variable ->
            val text = values[variable.symbol]?.trim().orEmpty()
            if (text.isEmpty()) null else {
                val number = text.toScienceDouble()
                    ?: return run { error = "Revisa el valor de ${variable.symbol}." }
                variable.symbol to number
            }
        }.toMap()

        val missing = formula.variables.filter { it.symbol !in filled.keys }
        if (missing.isEmpty()) {
            error = "Deja en blanco la variable que quieres calcular."
            result = null
            return
        }
        if (missing.size > 1) {
            // Algunas fórmulas traen constantes con valor por defecto (la gravedad).
            val optional = missing.filter { it.symbol == "g" || it.symbol == "th" }
            if (missing.size - optional.size != 1) {
                error = "Faltan datos: deja en blanco solo la variable que buscas."
                result = null
                return
            }
        }
        val target = missing.first { it.symbol != "g" || missing.size == 1 }
        val value = formula.solve(target.symbol, filled)
        if (!value.isFinite()) {
            error = "Con esos datos no se puede calcular ${target.name.lowercase()}. Revisa las unidades y que no haya divisiones por cero."
            result = null
            return
        }
        error = null
        result = Triple(target.name, value, target.unit)
        steps = listOf(
            SolveStep(
                "Fórmula",
                formula.expression,
                formula.explanation
            ),
            SolveStep(
                "Datos conocidos",
                filled.entries.joinToString("\n") { (symbol, number) ->
                    val variable = formula.variables.first { it.symbol == symbol }
                    "${variable.symbol} = ${MathEngine.formatNumber(number, 6)} ${variable.unit}"
                },
                "Todos los datos deben estar en las mismas unidades del sistema internacional."
            ),
            SolveStep(
                "Despeje y resultado",
                "${target.symbol} = ${MathEngine.formatNumber(value, 6)} ${target.unit}",
                "Se despeja ${target.name.lowercase()} y se sustituyen los valores."
            )
        )
    }

    ScienceShell(
        title = "Calculadora de física",
        subtitle = "${PhysicsLab.formulas.size} fórmulas con despeje automático",
        onBack = onBack
    ) {
        StudioTabs(listOf("Fórmulas", "Constantes", "Conversor"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard("Tema") {
                    StudioChipRow {
                        PhysicsBlock.entries.forEachIndexed { index, entry ->
                            StudioChip(entry.label, blockIndex == index, onClick = {
                                blockIndex = index
                                PhysicsLab.byBlock(entry).firstOrNull()?.let { selectFormula(it) }
                            })
                        }
                    }
                    StudioChipRow {
                        formulasInBlock.forEach { item ->
                            StudioChip(
                                label = item.title,
                                active = item.id == formula.id,
                                onClick = { selectFormula(item) }
                            )
                        }
                    }
                }

                ScienceCard(formula.title, accent = true) {
                    FormulaText(formula.expression, size = 18, color = StudioTheme.Accent)
                    Text(
                        formula.explanation,
                        color = StudioTheme.TextSecondary,
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                    )
                }

                ScienceCard("Datos") {
                    formula.variables.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { variable ->
                                ScienceNumberField(
                                    value = values[variable.symbol] ?: "",
                                    onValueChange = { values[variable.symbol] = it },
                                    label = "${variable.name} (${variable.unit})",
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (row.size == 1) androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                        }
                    }
                    StudioHint("Deja en blanco la casilla del dato que quieres obtener. La gravedad se toma como 9,80665 m/s² si no la escribes.")
                }

                PhysicsActionButton("Calcular") { compute() }

                error?.let { ScienceError(it) }
                result?.let { (name, value, unit) ->
                    ScienceResult(
                        headline = "$name = ${MathEngine.formatNumber(value, 6)} $unit",
                        onCopy = { clipboard.setText(AnnotatedString(MathEngine.formatNumber(value, 8))) }
                    )
                    StepsSection(steps, formula.title)
                }
            }

            1 -> {
                ScienceCard("Constantes fundamentales (CODATA 2022)") {
                    StudioHint(
                        "Desde la redefinición del SI de 2019 varias constantes son exactas por definición: " +
                            "no tienen incertidumbre porque son las que definen las unidades."
                    )
                }
                PhysicsConstants.all.forEach { constant ->
                    ScienceCard(null) {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "${constant.symbol} — ${constant.name}",
                                    color = StudioTheme.TextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium
                                )
                                FormulaText(
                                    PhysicsConstants.format(constant),
                                    color = StudioTheme.Accent,
                                    size = 14
                                )
                                if (constant.note.isNotEmpty()) {
                                    Text(
                                        constant.note,
                                        color = StudioTheme.TextSecondary,
                                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                            StudioChip(
                                label = if (constant.exact) "Exacta" else "Medida",
                                active = constant.exact,
                                onClick = {
                                    clipboard.setText(AnnotatedString(constant.value.toString()))
                                }
                            )
                        }
                    }
                }
            }

            else -> UnitConverterSection()
        }
    }
}

@Composable
private fun UnitConverterSection() {
    var category by rememberSaveable { mutableStateOf("longitud") }
    var fromIndex by rememberSaveable { mutableIntStateOf(0) }
    var toIndex by rememberSaveable { mutableIntStateOf(1) }
    var input by rememberSaveable { mutableStateOf("1") }

    val units = PhysicsLab.conversions[category].orEmpty()
    val safeFrom = units.getOrNull(fromIndex) ?: units.first()
    val safeTo = units.getOrNull(toIndex) ?: units.last()
    val value = input.toScienceDouble()
    val converted = value?.let { it * safeFrom.toBase / safeTo.toBase }

    ScienceCard("Magnitud") {
        StudioChipRow {
            PhysicsLab.conversions.keys.forEach { key ->
                StudioChip(
                    label = key.replaceFirstChar { it.uppercase() },
                    active = category == key,
                    onClick = {
                        category = key
                        fromIndex = 0
                        toIndex = 1
                    }
                )
            }
        }
    }
    ScienceCard("Conversión") {
        ScienceNumberField(input, { input = it }, "Valor", Modifier.fillMaxWidth())
        StudioLabel("De")
        StudioChipRow {
            units.forEachIndexed { index, unit ->
                StudioChip(unit.label, fromIndex == index, onClick = { fromIndex = index })
            }
        }
        StudioLabel("A")
        StudioChipRow {
            units.forEachIndexed { index, unit ->
                StudioChip(unit.label, toIndex == index, onClick = { toIndex = index })
            }
        }
    }
    if (converted != null) {
        ScienceResult(
            headline = "${MathEngine.formatNumber(converted, 6)} ${safeTo.label}",
            caption = "${MathEngine.formatNumber(value, 6)} ${safeFrom.label} equivalen a ese valor"
        )
    }

    ScienceCard("Temperatura") {
        var celsius by rememberSaveable { mutableStateOf("25") }
        ScienceNumberField(celsius, { celsius = it }, "Grados Celsius", Modifier.fillMaxWidth())
        val c = celsius.toScienceDouble()
        if (c != null) {
            ScienceRow("Kelvin", MathEngine.formatNumber(PhysicsLab.celsiusToKelvin(c), 2), highlight = true)
            ScienceRow("Fahrenheit", MathEngine.formatNumber(c * 9 / 5 + 32, 2))
        }
        StudioHint("En las fórmulas de gases la temperatura va siempre en kelvin.")
    }
}

@Composable
private fun PhysicsActionButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = StudioTheme.Accent,
            contentColor = StudioTheme.OnAccent
        )
    ) {
        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
        Text("  $text", fontWeight = FontWeight.Bold)
    }
}
