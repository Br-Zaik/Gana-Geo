package com.ganageo.app.ui.tools

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.RotateLeft
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.ImageStudioOps
import com.ganageo.app.tools.ImageStudioPresets
import com.ganageo.app.tools.ToolFileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private const val PREVIEW_EDGE = 1400
private const val EXPORT_EDGE = 4096
private const val RESULT_PREVIEW_EDGE = 1100

/**
 * Editor de imagen a pantalla completa.
 *
 * Cinco herramientas comparten la misma estructura: se elige la foto, se ajusta
 * viendo el resultado en vivo y se guarda. No hay tarjetas sueltas con
 * deslizadores: manda el lienzo y los controles viven abajo.
 */
@Composable
fun ImageToolScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var inputUriText by rememberSaveable { mutableStateOf<String?>(null) }
    val input = inputUriText?.let(Uri::parse)
    var sourcePreview by remember { mutableStateOf<Bitmap?>(null) }
    var sourceWidth by rememberSaveable { mutableIntStateOf(0) }
    var sourceHeight by rememberSaveable { mutableIntStateOf(0) }
    var originalBytes by rememberSaveable { mutableLongStateOf(0L) }
    var loading by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var estimatedBytes by remember { mutableLongStateOf(0L) }
    var exportResult by remember { mutableStateOf<StudioExportResult?>(null) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    // --- Compresion ---
    var compressPreset by rememberSaveable { mutableIntStateOf(2) }
    var quality by rememberSaveable { mutableFloatStateOf(80f) }
    var targetKbText by rememberSaveable { mutableStateOf("") }
    var useTargetWeight by rememberSaveable { mutableStateOf(false) }

    // --- Formato de salida ---
    var formatIndex by rememberSaveable { mutableIntStateOf(0) }
    var backgroundIndex by rememberSaveable { mutableIntStateOf(0) }

    // --- Tamano ---
    var resizeMode by rememberSaveable { mutableIntStateOf(0) }
    var resizePercent by rememberSaveable { mutableFloatStateOf(100f) }
    var widthText by rememberSaveable { mutableStateOf("") }
    var heightText by rememberSaveable { mutableStateOf("") }
    var keepAspect by rememberSaveable { mutableStateOf(true) }
    var fitIndex by rememberSaveable { mutableIntStateOf(0) }
    var unitIndex by rememberSaveable { mutableIntStateOf(0) }
    var dpiText by rememberSaveable { mutableStateOf("300") }
    var presetLabel by rememberSaveable { mutableStateOf("") }

    // --- Recorte y giro ---
    var cropLeft by rememberSaveable { mutableFloatStateOf(0f) }
    var cropTop by rememberSaveable { mutableFloatStateOf(0f) }
    var cropRight by rememberSaveable { mutableFloatStateOf(1f) }
    var cropBottom by rememberSaveable { mutableFloatStateOf(1f) }
    var aspectIndex by rememberSaveable { mutableIntStateOf(0) }
    var quarterTurns by rememberSaveable { mutableIntStateOf(0) }
    var fineRotation by rememberSaveable { mutableFloatStateOf(0f) }
    var flipH by rememberSaveable { mutableStateOf(false) }
    var flipV by rememberSaveable { mutableStateOf(false) }

    // --- Ajustes de color ---
    var brightness by rememberSaveable { mutableFloatStateOf(0f) }
    var contrast by rememberSaveable { mutableFloatStateOf(1f) }
    var saturation by rememberSaveable { mutableFloatStateOf(1f) }
    var filterIndex by rememberSaveable { mutableIntStateOf(0) }

    // --- Marca de agua ---
    var watermarkText by rememberSaveable { mutableStateOf("") }
    var fontIndex by rememberSaveable { mutableIntStateOf(1) }
    var colorIndex by rememberSaveable { mutableIntStateOf(0) }
    var opacity by rememberSaveable { mutableFloatStateOf(55f) }
    var markSize by rememberSaveable { mutableFloatStateOf(7f) }
    var markRotation by rememberSaveable { mutableFloatStateOf(0f) }
    var markX by rememberSaveable { mutableFloatStateOf(0.82f) }
    var markY by rememberSaveable { mutableFloatStateOf(0.90f) }
    var tileMark by rememberSaveable { mutableStateOf(false) }
    var tileSpacing by rememberSaveable { mutableFloatStateOf(1.6f) }
    var shadowMark by rememberSaveable { mutableStateOf(true) }
    var positionIndex by rememberSaveable { mutableIntStateOf(8) }
    var logoUriText by rememberSaveable { mutableStateOf<String?>(null) }
    var logoBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var logoSize by rememberSaveable { mutableFloatStateOf(22f) }
    var logoOpacity by rememberSaveable { mutableFloatStateOf(70f) }
    var logoX by rememberSaveable { mutableFloatStateOf(0.82f) }
    var logoY by rememberSaveable { mutableFloatStateOf(0.82f) }
    var logoRotation by rememberSaveable { mutableFloatStateOf(0f) }

    val formats = when (tool) {
        ToolId.COMPRESS_IMAGE -> listOf("JPG", "WebP")
        else -> listOf("JPG", "PNG", "WebP")
    }
    val backgroundColors = listOf(
        "Blanco" to android.graphics.Color.WHITE,
        "Negro" to android.graphics.Color.BLACK,
        "Gris" to android.graphics.Color.LTGRAY
    )
    val markColors = listOf(
        "Blanco" to android.graphics.Color.WHITE,
        "Negro" to android.graphics.Color.BLACK,
        "Neón" to 0xFFB7FF00.toInt(),
        "Rojo" to 0xFFE53935.toInt(),
        "Azul" to 0xFF1E88E5.toInt(),
        "Dorado" to 0xFFFFC542.toInt()
    )

    fun compressFormat(): Bitmap.CompressFormat =
        when (formats.getOrNull(formatIndex)) {
            "PNG" -> Bitmap.CompressFormat.PNG
            "WebP" -> Bitmap.CompressFormat.WEBP
            else -> Bitmap.CompressFormat.JPEG
        }

    /** Medidas reales que tendra el archivo antes de cambiar el tamano. */
    fun exportBaseSize(): Pair<Int, Int> {
        if (sourceWidth <= 0 || sourceHeight <= 0) return 0 to 0
        val scale = min(1f, EXPORT_EDGE.toFloat() / max(sourceWidth, sourceHeight))
        return max(1, (sourceWidth * scale).roundToInt()) to max(1, (sourceHeight * scale).roundToInt())
    }

    fun dpi(): Int = dpiText.toIntOrNull()?.coerceIn(72, 1200) ?: 300

    fun unitToPixels(value: Float): Int = when (unitIndex) {
        1 -> (value / 25.4f * 10f * dpi()).roundToInt()
        2 -> (value * dpi()).roundToInt()
        else -> value.roundToInt()
    }

    /** Proporcion del lienzo de recorte, ya girado y enderezado. */
    fun stageRatio(): Float {
        if (sourceWidth <= 0 || sourceHeight <= 0) return 1f
        val swapped = quarterTurns % 2 == 1
        val w = if (swapped) sourceHeight.toFloat() else sourceWidth.toFloat()
        val h = if (swapped) sourceWidth.toFloat() else sourceHeight.toFloat()
        val straight = ImageStudioOps.straightenedSize(w, h, fineRotation)
        return (straight.first / straight.second.coerceAtLeast(0.001f)).coerceAtLeast(0.01f)
    }

    /** Medidas de salida segun la herramienta y los ajustes actuales. */
    fun outputSize(): Pair<Int, Int> {
        val base = exportBaseSize()
        val baseW = base.first
        val baseH = base.second
        if (baseW <= 0) return 0 to 0
        return when (tool) {
            ToolId.RESIZE_IMAGE -> when (resizeMode) {
                0 -> {
                    val factor = resizePercent / 100f
                    max(1, (baseW * factor).roundToInt()) to max(1, (baseH * factor).roundToInt())
                }
                1, 2 -> {
                    val w = widthText.replace(',', '.').toFloatOrNull()?.let { unitToPixels(it) } ?: baseW
                    val h = heightText.replace(',', '.').toFloatOrNull()?.let { unitToPixels(it) } ?: baseH
                    val safeW = w.coerceIn(1, ImageStudioOps.MAX_OUTPUT_EDGE)
                    val safeH = h.coerceIn(1, ImageStudioOps.MAX_OUTPUT_EDGE)
                    if (ImageStudioOps.FitMode.entries[fitIndex] == ImageStudioOps.FitMode.FIT) {
                        val scale = min(safeW.toFloat() / baseW, safeH.toFloat() / baseH)
                        max(1, (baseW * scale).roundToInt()) to max(1, (baseH * scale).roundToInt())
                    } else {
                        safeW to safeH
                    }
                }
                else -> baseW to baseH
            }
            ToolId.CROP_ROTATE_IMAGE -> {
                val swapped = quarterTurns % 2 == 1
                val rotatedW = if (swapped) baseH else baseW
                val rotatedH = if (swapped) baseW else baseH
                val straight = ImageStudioOps.straightenedSize(
                    rotatedW.toFloat(),
                    rotatedH.toFloat(),
                    fineRotation
                )
                val w = (straight.first * (cropRight - cropLeft)).roundToInt()
                val h = (straight.second * (cropBottom - cropTop)).roundToInt()
                max(1, w) to max(1, h)
            }
            else -> baseW to baseH
        }
    }

    fun watermarkSpec(): ImageStudioOps.WatermarkSpec = ImageStudioOps.WatermarkSpec(
        text = watermarkText,
        font = ImageStudioOps.WatermarkFont.entries[fontIndex.coerceIn(0, 3)],
        colorArgb = markColors[colorIndex.coerceIn(0, markColors.lastIndex)].second,
        opacityPercent = opacity.roundToInt(),
        sizePercent = markSize,
        rotationDegrees = markRotation,
        centerX = markX,
        centerY = markY,
        tile = tileMark,
        tileSpacing = tileSpacing,
        shadow = shadowMark,
        logoSizePercent = logoSize,
        logoCenterX = logoX,
        logoCenterY = logoY,
        logoOpacityPercent = logoOpacity.roundToInt(),
        logoRotationDegrees = logoRotation
    )

    fun currentFilter(): DocumentImageFilter =
        DocumentImageFilter.entries[filterIndex.coerceIn(0, DocumentImageFilter.entries.lastIndex)]

    fun adjustmentMatrix(): FloatArray = ImageStudioOps.adjustmentMatrix(
        currentFilter(),
        brightness.roundToInt(),
        contrast,
        saturation
    )

    fun neutralAdjustments(): Boolean = ImageStudioOps.isNeutralAdjustment(
        currentFilter(),
        brightness.roundToInt(),
        contrast,
        saturation
    )

    fun resetSettings() {
        tab = 0
        compressPreset = 2
        quality = 80f
        targetKbText = ""
        useTargetWeight = false
        formatIndex = 0
        backgroundIndex = 0
        resizeMode = 0
        resizePercent = 100f
        keepAspect = true
        fitIndex = 0
        unitIndex = 0
        dpiText = "300"
        presetLabel = ""
        val base = exportBaseSize()
        widthText = if (base.first > 0) base.first.toString() else ""
        heightText = if (base.second > 0) base.second.toString() else ""
        cropLeft = 0f
        cropTop = 0f
        cropRight = 1f
        cropBottom = 1f
        aspectIndex = 0
        quarterTurns = 0
        fineRotation = 0f
        flipH = false
        flipV = false
        brightness = 0f
        contrast = 1f
        saturation = 1f
        filterIndex = 0
        markX = 0.82f
        markY = 0.90f
        markRotation = 0f
        markSize = 7f
        opacity = 55f
        tileMark = false
        shadowMark = true
        positionIndex = 8
    }

    fun clearSource() {
        val old = sourcePreview
        sourcePreview = null
        inputUriText = null
        sourceWidth = 0
        sourceHeight = 0
        originalBytes = 0L
        estimatedBytes = 0L
        exportResult = null
        old?.takeIf { !it.isRecycled }?.recycle()
    }

    fun useSource(uri: Uri) {
        val old = sourcePreview
        sourcePreview = null
        exportResult = null
        inputUriText = uri.toString()
        old?.takeIf { !it.isRecycled }?.recycle()
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) useSource(uri) }

    val filesLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            useSource(uri)
        }
    }

    val logoLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) logoUriText = uri.toString() }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) useSource(uri)
        pendingCameraUri = null
    }

    fun launchCamera() {
        runCatching { ToolFileUtils.createCameraImageUri(context) }
            .onSuccess {
                pendingCameraUri = it
                cameraLauncher.launch(it)
            }
            .onFailure { onMessage(it.message ?: "No se pudo abrir la cámara.") }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchCamera() else onMessage("Se necesita permiso de cámara para tomar la foto.")
    }

    // Carga la copia de trabajo y las medidas reales del archivo.
    LaunchedEffect(inputUriText) {
        val uri = inputUriText?.let(Uri::parse) ?: return@LaunchedEffect
        if (sourcePreview != null) return@LaunchedEffect
        loading = true
        runCatching {
            val bounds = withContext(Dispatchers.IO) { ImageStudioOps.sourceBounds(context, uri) }
            val size = withContext(Dispatchers.IO) { ToolFileUtils.fileSize(context, uri) }
            val bitmap = ToolFileUtils.loadBitmap(context, uri, maxEdge = PREVIEW_EDGE)
            Triple(bitmap, bounds, size)
        }.onSuccess { loaded ->
            sourcePreview = loaded.first
            sourceWidth = loaded.second.first
            sourceHeight = loaded.second.second
            originalBytes = loaded.third
            if (widthText.isBlank() || presetLabel.isBlank()) {
                val scale = min(
                    1f,
                    EXPORT_EDGE.toFloat() / max(loaded.second.first, loaded.second.second)
                )
                widthText = max(1, (loaded.second.first * scale).roundToInt()).toString()
                heightText = max(1, (loaded.second.second * scale).roundToInt()).toString()
            }
        }.onFailure {
            onMessage(it.message ?: "No se pudo abrir la imagen.")
            inputUriText = null
        }
        loading = false
    }

    LaunchedEffect(logoUriText) {
        val uri = logoUriText?.let(Uri::parse)
        val old = logoBitmap
        if (uri == null) {
            logoBitmap = null
        } else {
            runCatching { ToolFileUtils.loadBitmap(context, uri, maxEdge = 720) }
                .onSuccess { logoBitmap = it }
                .onFailure { onMessage("No se pudo abrir el logo.") }
        }
        if (old != null && old !== logoBitmap && !old.isRecycled) old.recycle()
    }

    // Peso aproximado del archivo final. Se recalcula con una pequena espera para
    // que arrastrar un deslizador no dispare decenas de compresiones seguidas.
    val outputSizePair = outputSize()
    LaunchedEffect(
        sourcePreview,
        quality,
        formatIndex,
        outputSizePair.first,
        outputSizePair.second,
        useTargetWeight,
        targetKbText
    ) {
        val preview = sourcePreview
        if (preview == null || outputSizePair.first <= 0) {
            estimatedBytes = 0L
            return@LaunchedEffect
        }
        delay(220)
        val target = targetKbText.toIntOrNull()
        estimatedBytes = if (useTargetWeight && target != null && target > 0) {
            target * 1024L
        } else {
            withContext(Dispatchers.Default) {
                runCatching {
                    ImageStudioOps.estimateBytes(
                        preview,
                        compressFormat(),
                        quality.roundToInt(),
                        outputSizePair.first,
                        outputSizePair.second
                    )
                }.getOrDefault(0L)
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            sourcePreview?.takeIf { !it.isRecycled }?.recycle()
            logoBitmap?.takeIf { !it.isRecycled }?.recycle()
        }
    }

    /** Construye el resultado final a resolucion de exportacion. */
    fun buildResult(source: Bitmap): Bitmap {
        var current = source
        fun replace(next: Bitmap) {
            if (next !== current && current !== source && !current.isRecycled) current.recycle()
            current = next
        }
        when (tool) {
            ToolId.RESIZE_IMAGE -> {
                val target = outputSize()
                if (target.first > 0 && target.second > 0) {
                    replace(
                        ImageStudioOps.resizeTo(
                            current,
                            target.first,
                            target.second,
                            ImageStudioOps.FitMode.entries[fitIndex],
                            backgroundColors[backgroundIndex.coerceIn(0, backgroundColors.lastIndex)].second
                        )
                    )
                }
            }
            ToolId.CROP_ROTATE_IMAGE -> {
                replace(ImageStudioOps.quarterTurnAndFlip(current, quarterTurns * 90, flipH, flipV))
                replace(ImageStudioOps.straighten(current, fineRotation))
                replace(ImageStudioOps.crop(current, cropLeft, cropTop, cropRight, cropBottom))
                if (!neutralAdjustments()) {
                    replace(ImageStudioOps.applyAdjustments(current, adjustmentMatrix()))
                }
            }
            ToolId.WATERMARK_IMAGE -> {
                replace(ImageStudioOps.applyWatermark(current, watermarkSpec(), logoBitmap))
            }
            else -> Unit
        }
        if (compressFormat() == Bitmap.CompressFormat.JPEG && current.hasAlpha()) {
            replace(
                ImageStudioOps.flattenOn(
                    current,
                    backgroundColors[backgroundIndex.coerceIn(0, backgroundColors.lastIndex)].second
                )
            )
        }
        return current
    }

    fun outputQuality(bitmap: Bitmap): Int {
        val format = compressFormat()
        if (format == Bitmap.CompressFormat.PNG) return 100
        val target = targetKbText.toIntOrNull()
        if (useTargetWeight && target != null && target > 0) {
            return ImageStudioOps.qualityForTargetBytes(bitmap, format, target * 1024L)
        }
        return when (tool) {
            ToolId.COMPRESS_IMAGE, ToolId.CONVERT_IMAGE -> quality.roundToInt()
            else -> 92
        }
    }

    fun namePrefix(): String = when (tool) {
        ToolId.COMPRESS_IMAGE -> "comprimida"
        ToolId.RESIZE_IMAGE -> "tamano"
        ToolId.CONVERT_IMAGE -> "convertida"
        ToolId.CROP_ROTATE_IMAGE -> "recortada"
        ToolId.WATERMARK_IMAGE -> "marca_agua"
        else -> "imagen"
    }

    fun loadEdgeForExport(): Int = if (tool == ToolId.RESIZE_IMAGE) {
        val target = outputSize()
        max(EXPORT_EDGE, max(target.first, target.second))
            .coerceIn(256, ImageStudioOps.MAX_OUTPUT_EDGE)
    } else EXPORT_EDGE

    /**
     * Escribe el archivo. En Android 10 o superior va directo a Imagenes/GanaGeo;
     * en versiones anteriores el sistema pide elegir la carpeta.
     */
    suspend fun runExport(destination: Uri?) {
        val uri = input ?: return
        val format = compressFormat()
        var savedUri: Uri? = null
        var savedBytes = 0L
        var resultPreview: Bitmap? = null
        var originalPreview: Bitmap? = null
        var outWidth = 0
        var outHeight = 0

        val outcome = runPaidTool(viewModel, tool) {
            val source = ToolFileUtils.loadBitmap(context, uri, maxEdge = loadEdgeForExport())
            var finalBitmap: Bitmap = source
            try {
                finalBitmap = withContext(Dispatchers.Default) { buildResult(source) }
                val exportQuality = withContext(Dispatchers.Default) { outputQuality(finalBitmap) }
                outWidth = finalBitmap.width
                outHeight = finalBitmap.height
                val name = ImageStudioOps.timestampedName(namePrefix(), format)
                val target = if (destination != null) {
                    ToolFileUtils.writeBitmap(context, finalBitmap, destination, format, exportQuality)
                    destination
                } else {
                    ImageStudioOps.saveToGallery(context, finalBitmap, name, format, exportQuality)
                }
                savedUri = target
                savedBytes = withContext(Dispatchers.IO) { ToolFileUtils.fileSize(context, target) }
                if (savedBytes <= 0L) {
                    savedBytes = withContext(Dispatchers.Default) {
                        ImageStudioOps.encodedBytes(finalBitmap, format, exportQuality)
                    }
                }
                resultPreview = withContext(Dispatchers.Default) {
                    scaledPreview(finalBitmap, RESULT_PREVIEW_EDGE)
                }
                originalPreview = sourcePreview?.let { preview ->
                    withContext(Dispatchers.Default) {
                        runCatching { preview.copy(Bitmap.Config.ARGB_8888, false) }.getOrNull()
                    }
                }
            } finally {
                if (finalBitmap !== source && !finalBitmap.isRecycled) finalBitmap.recycle()
                if (!source.isRecycled) source.recycle()
            }
        }

        outcome
            .onSuccess { awarded ->
                val target = savedUri
                if (target != null) {
                    exportResult = StudioExportResult(
                        uri = target,
                        bytes = savedBytes,
                        width = outWidth,
                        height = outHeight,
                        originalBytes = originalBytes,
                        preview = resultPreview,
                        originalPreview = originalPreview,
                        locationLabel = if (destination == null) {
                            "Guardada en Imágenes › GanaGeo"
                        } else {
                            "Guardada en la carpeta que elegiste"
                        }
                    )
                }
                if (awarded > 0) onMessage(successMessage("Imagen guardada.", awarded))
            }
            .onFailure { error ->
                resultPreview?.takeIf { bitmap -> !bitmap.isRecycled }?.recycle()
                originalPreview?.takeIf { bitmap -> !bitmap.isRecycled }?.recycle()
                onMessage(error.message ?: "No se pudo procesar la imagen.")
            }
    }

    val saveAsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("image/*")
    ) { destination ->
        if (destination == null) return@rememberLauncherForActivityResult
        saving = true
        scope.launch {
            runExport(destination)
            saving = false
        }
    }

    fun onSaveRequested() {
        if (input == null) return
        if (tool == ToolId.WATERMARK_IMAGE && watermarkText.isBlank() && logoBitmap == null) {
            onMessage("Escribe un texto o elige un logo para la marca de agua.")
            return
        }
        if (tool == ToolId.RESIZE_IMAGE) {
            val target = outputSize()
            if (target.first <= 0 || target.second <= 0) {
                onMessage("Revisa las medidas de salida.")
                return
            }
            if (target.first.toLong() * target.second.toLong() > ImageStudioOps.MAX_OUTPUT_PIXELS) {
                onMessage("La medida pedida supera el límite seguro de 32 megapíxeles.")
                return
            }
        }
        launchPaidExport(viewModel, tool, onMessage) {
            if (ImageStudioOps.canSaveToGallery()) {
                saving = true
                scope.launch {
                    runExport(null)
                    saving = false
                }
            } else {
                saveAsLauncher.launch(ImageStudioOps.timestampedName(namePrefix(), compressFormat()))
            }
        }
    }

    BackHandler(enabled = exportResult != null) { exportResult = null }

    // ---------------------------------------------------------------
    // Pantallas
    // ---------------------------------------------------------------

    val result = exportResult
    if (result != null) {
        StudioResultScreen(
            result = result,
            onShare = {
                runCatching {
                    val share = Intent(Intent.ACTION_SEND).apply {
                        type = "image/*"
                        putExtra(Intent.EXTRA_STREAM, result.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(share, "Compartir imagen"))
                }.onFailure { onMessage("No se pudo compartir la imagen.") }
            },
            onOpen = {
                runCatching {
                    val open = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(result.uri, "image/*")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(open)
                }.onFailure { onMessage("No se encontró una app para abrir la imagen.") }
            },
            onContinueEditing = { exportResult = null },
            onNewImage = {
                exportResult = null
                clearSource()
            },
            onClose = {
                exportResult = null
                onBack()
            }
        )
        return
    }

    if (input == null) {
        StudioPicker(
            title = tool.title,
            description = pickerDescription(tool),
            features = pickerFeatures(tool),
            creditCost = tool.creditCost,
            multiple = false,
            onBack = onBack,
            onGallery = {
                galleryLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onFiles = { filesLauncher.launch(arrayOf("image/*")) },
            onCamera = {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    launchCamera()
                } else {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                }
            }
        )
        return
    }

    val preview = sourcePreview
    val badge = buildString {
        if (outputSizePair.first > 0) {
            append("${outputSizePair.first} × ${outputSizePair.second} px")
        }
        if (estimatedBytes > 0L) {
            append("  ·  ")
            append(if (useTargetWeight) "objetivo " else "≈ ")
            append(ImageStudioOps.readableSize(estimatedBytes))
        }
        if (originalBytes > 0L && estimatedBytes > 0L) {
            val diff = ((originalBytes - estimatedBytes) * 100f / originalBytes).roundToInt()
            if (diff > 0) append("  ·  −$diff %")
        }
    }

    StudioShell(
        title = editorTitle(tool),
        subtitle = if (originalBytes > 0L) {
            "Original ${sourceWidth}×${sourceHeight} · ${ImageStudioOps.readableSize(originalBytes)}"
        } else null,
        saving = saving,
        saveLabel = "Guardar",
        saveEnabled = preview != null,
        onClose = onBack,
        onReset = { resetSettings() },
        onSave = { onSaveRequested() },
        canvas = {
            val current = preview
            if (current != null) {
            when {
                tool == ToolId.CROP_ROTATE_IMAGE -> CropStage(
                    base = current,
                    quarterTurns = quarterTurns,
                    flipH = flipH,
                    flipV = flipV,
                    angle = fineRotation,
                    matrix = if (neutralAdjustments()) null else adjustmentMatrix(),
                    cropLeft = cropLeft,
                    cropTop = cropTop,
                    cropRight = cropRight,
                    cropBottom = cropBottom,
                    lockedRatio = ImageStudioPresets.aspects.getOrNull(aspectIndex)?.ratio,
                    showCrop = tab == 0,
                    onCropChange = { l, t, r, b ->
                        cropLeft = l
                        cropTop = t
                        cropRight = r
                        cropBottom = b
                    }
                )
                tool == ToolId.WATERMARK_IMAGE -> StudioCanvas(
                    bitmap = current,
                    gesturesEnabled = false
                ) { _, _ ->
                    val spec = watermarkSpec()
                    val logo = logoBitmap
                    val movingLogo = tab == 3 && logo != null
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(tileMark, movingLogo) {
                                detectDragGestures { _, drag ->
                                    val w = size.width.toFloat().coerceAtLeast(1f)
                                    val h = size.height.toFloat().coerceAtLeast(1f)
                                    if (movingLogo) {
                                        logoX = (logoX + drag.x / w).coerceIn(0f, 1f)
                                        logoY = (logoY + drag.y / h).coerceIn(0f, 1f)
                                    } else if (!tileMark) {
                                        markX = (markX + drag.x / w).coerceIn(0f, 1f)
                                        markY = (markY + drag.y / h).coerceIn(0f, 1f)
                                        positionIndex = -1
                                    }
                                }
                            }
                    ) {
                        drawIntoCanvas { canvas ->
                            ImageStudioOps.drawWatermark(
                                canvas.nativeCanvas,
                                size.width.roundToInt(),
                                size.height.roundToInt(),
                                spec,
                                logo
                            )
                        }
                    }
                }
                else -> StudioCanvas(bitmap = current)
            }
            if (badge.isNotEmpty()) StudioBadge(badge)
            }
            if (current == null || loading) StudioProgressOverlay("Abriendo la imagen", null)
            if (saving) StudioProgressOverlay("Procesando la imagen", null)
        },
        panel = {
            when (tool) {
                ToolId.COMPRESS_IMAGE -> {
                    StudioPanel {
                        when (tab) {
                            0 -> {
                                StudioLabel("Ajustes rápidos")
                                StudioChipRow {
                                    ImageStudioPresets.compressPresets.forEachIndexed { index, preset ->
                                        StudioChip(
                                            label = preset.label,
                                            active = compressPreset == index && !useTargetWeight,
                                            onClick = {
                                                compressPreset = index
                                                quality = preset.quality.toFloat()
                                                useTargetWeight = false
                                            },
                                            caption = "${preset.quality} %"
                                        )
                                    }
                                }
                                StudioHint(
                                    ImageStudioPresets.compressPresets
                                        .getOrNull(compressPreset)?.hint.orEmpty()
                                )
                            }
                            1 -> {
                                StudioSlider(
                                    label = "Calidad",
                                    valueText = "${quality.roundToInt()} %",
                                    value = quality,
                                    range = 20f..100f
                                ) {
                                    quality = it
                                    useTargetWeight = false
                                }
                                StudioLabel("Peso objetivo")
                                StudioChipRow {
                                    ImageStudioPresets.targetWeights.forEach { weight ->
                                        StudioChip(
                                            label = weight.label,
                                            active = useTargetWeight &&
                                                targetKbText == weight.kilobytes.toString(),
                                            onClick = {
                                                targetKbText = weight.kilobytes.toString()
                                                useTargetWeight = true
                                            }
                                        )
                                    }
                                }
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    StudioNumberField(
                                        value = targetKbText,
                                        onValueChange = {
                                            targetKbText = it
                                            useTargetWeight = it.isNotBlank()
                                        },
                                        label = "Peso en KB",
                                        modifier = Modifier.weight(1f)
                                    )
                                    StudioChip(
                                        label = "Quitar",
                                        active = !useTargetWeight,
                                        onClick = {
                                            useTargetWeight = false
                                            targetKbText = ""
                                        }
                                    )
                                }
                                StudioHint("Con peso objetivo se busca la calidad que más se acerque sin pasarse.")
                            }
                            else -> OutputSection(
                                formats = formats,
                                formatIndex = formatIndex,
                                onFormatChange = { formatIndex = it },
                                showQuality = compressFormat() != Bitmap.CompressFormat.PNG,
                                quality = quality,
                                onQualityChange = { quality = it },
                                backgroundColors = backgroundColors,
                                backgroundIndex = backgroundIndex,
                                onBackgroundChange = { backgroundIndex = it },
                                showBackground = false
                            )
                        }
                    }
                    StudioTabs(listOf("Rápido", "Manual", "Salida"), tab) { tab = it }
                }

                ToolId.RESIZE_IMAGE -> {
                    StudioPanel {
                        when (tab) {
                            0 -> {
                                StudioSlider(
                                    label = "Escala",
                                    valueText = "${resizePercent.roundToInt()} %",
                                    value = resizePercent,
                                    range = 10f..200f
                                ) { resizePercent = it }
                                StudioChipRow {
                                    ImageStudioPresets.percentShortcuts.forEach { value ->
                                        StudioChip(
                                            label = "${value.roundToInt()} %",
                                            active = abs(resizePercent - value) < 0.5f,
                                            onClick = { resizePercent = value }
                                        )
                                    }
                                }
                                StudioHint("En este modo la proporción se mantiene siempre.")
                            }
                            1 -> {
                                StudioChipRow {
                                    listOf("px", "cm", "pulgadas").forEachIndexed { index, label ->
                                        StudioChip(
                                            label = label,
                                            active = unitIndex == index,
                                            onClick = { unitIndex = index }
                                        )
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    StudioNumberField(
                                        value = widthText,
                                        onValueChange = { value ->
                                            widthText = value
                                            presetLabel = ""
                                            if (keepAspect && sourceWidth > 0 && sourceHeight > 0) {
                                                val w = value.replace(',', '.').toFloatOrNull()
                                                if (w != null) {
                                                    val ratio = sourceHeight.toFloat() / sourceWidth
                                                    heightText = formatMeasure(w * ratio)
                                                }
                                            }
                                        },
                                        label = "Ancho",
                                        modifier = Modifier.weight(1f),
                                        decimal = unitIndex != 0
                                    )
                                    StudioNumberField(
                                        value = heightText,
                                        onValueChange = { value ->
                                            heightText = value
                                            presetLabel = ""
                                            if (keepAspect && sourceWidth > 0 && sourceHeight > 0) {
                                                val h = value.replace(',', '.').toFloatOrNull()
                                                if (h != null) {
                                                    val ratio = sourceWidth.toFloat() / sourceHeight
                                                    widthText = formatMeasure(h * ratio)
                                                }
                                            }
                                        },
                                        label = "Alto",
                                        modifier = Modifier.weight(1f),
                                        decimal = unitIndex != 0
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    StudioChip(
                                        label = if (keepAspect) "Proporción bloqueada" else "Proporción libre",
                                        active = keepAspect,
                                        onClick = { keepAspect = !keepAspect }
                                    )
                                    if (unitIndex != 0) {
                                        StudioNumberField(
                                            value = dpiText,
                                            onValueChange = { dpiText = it },
                                            label = "DPI",
                                            modifier = Modifier.width(112.dp),
                                            maxLength = 4
                                        )
                                    }
                                }
                                StudioLabel("Cómo encaja")
                                StudioChipRow {
                                    ImageStudioOps.FitMode.entries.forEachIndexed { index, mode ->
                                        StudioChip(
                                            label = mode.label,
                                            active = fitIndex == index,
                                            onClick = { fitIndex = index }
                                        )
                                    }
                                }
                                StudioHint(
                                    when (ImageStudioOps.FitMode.entries[fitIndex]) {
                                        ImageStudioOps.FitMode.FIT ->
                                            "Ajustar: entra completa sin deformarse."
                                        ImageStudioOps.FitMode.FILL ->
                                            "Rellenar: cubre la medida exacta y recorta el sobrante."
                                        ImageStudioOps.FitMode.STRETCH ->
                                            "Estirar: usa la medida exacta aunque deforme."
                                    }
                                )
                            }
                            2 -> {
                                StudioLabel("Redes sociales")
                                StudioChipRow {
                                    ImageStudioPresets.socialSizes.forEach { preset ->
                                        StudioChip(
                                            label = preset.label,
                                            active = presetLabel == preset.label,
                                            onClick = {
                                                presetLabel = preset.label
                                                unitIndex = 0
                                                keepAspect = false
                                                widthText = preset.width.toString()
                                                heightText = preset.height.toString()
                                            },
                                            caption = "${preset.width}×${preset.height}"
                                        )
                                    }
                                }
                                StudioLabel("Pantalla y correo")
                                StudioChipRow {
                                    ImageStudioPresets.screenSizes.forEach { preset ->
                                        StudioChip(
                                            label = preset.label,
                                            active = presetLabel == preset.label,
                                            onClick = {
                                                presetLabel = preset.label
                                                unitIndex = 0
                                                keepAspect = false
                                                widthText = preset.width.toString()
                                                heightText = preset.height.toString()
                                            },
                                            caption = "${preset.width}×${preset.height}"
                                        )
                                    }
                                }
                                StudioLabel("Foto carnet")
                                StudioChipRow {
                                    ImageStudioPresets.idPhotos.forEach { preset ->
                                        val pixels = preset.pixels(300)
                                        StudioChip(
                                            label = preset.label,
                                            active = presetLabel == preset.label,
                                            onClick = {
                                                presetLabel = preset.label
                                                unitIndex = 0
                                                keepAspect = false
                                                fitIndex = ImageStudioOps.FitMode.FILL.ordinal
                                                widthText = pixels.first.toString()
                                                heightText = pixels.second.toString()
                                            },
                                            caption = "${pixels.first}×${pixels.second}"
                                        )
                                    }
                                }
                                StudioHint(
                                    "Verifica siempre el requisito oficial: la medida y el peso máximo cambian según el país y el trámite."
                                )
                            }
                            else -> OutputSection(
                                formats = formats,
                                formatIndex = formatIndex,
                                onFormatChange = { formatIndex = it },
                                showQuality = compressFormat() != Bitmap.CompressFormat.PNG,
                                quality = quality,
                                onQualityChange = { quality = it },
                                backgroundColors = backgroundColors,
                                backgroundIndex = backgroundIndex,
                                onBackgroundChange = { backgroundIndex = it },
                                showBackground = ImageStudioOps.FitMode.entries[fitIndex] ==
                                    ImageStudioOps.FitMode.FILL
                            )
                        }
                    }
                    StudioTabs(listOf("Escala", "Medidas", "Presets", "Salida"), tab) { selected ->
                        tab = selected
                        if (selected <= 2) resizeMode = selected
                    }
                }

                ToolId.CONVERT_IMAGE -> {
                    StudioPanel {
                        StudioLabel("Formato de salida")
                        StudioChipRow {
                            formats.forEachIndexed { index, label ->
                                StudioChip(
                                    label = label,
                                    active = formatIndex == index,
                                    onClick = { formatIndex = index },
                                    caption = when (label) {
                                        "PNG" -> "sin pérdida"
                                        "WebP" -> "más liviano"
                                        else -> "compatible"
                                    }
                                )
                            }
                        }
                        if (compressFormat() != Bitmap.CompressFormat.PNG) {
                            StudioSlider(
                                label = "Calidad",
                                valueText = "${quality.roundToInt()} %",
                                value = quality,
                                range = 40f..100f
                            ) { quality = it }
                        }
                        if (compressFormat() == Bitmap.CompressFormat.JPEG) {
                            StudioLabel("Fondo al quitar transparencia")
                            StudioChipRow {
                                backgroundColors.forEachIndexed { index, entry ->
                                    StudioChip(
                                        label = entry.first,
                                        active = backgroundIndex == index,
                                        onClick = { backgroundIndex = index }
                                    )
                                }
                            }
                        }
                        StudioHint(
                            when (compressFormat()) {
                                Bitmap.CompressFormat.PNG ->
                                    "PNG conserva la transparencia y no pierde calidad, pero pesa más."
                                Bitmap.CompressFormat.JPEG ->
                                    "JPG es el más compatible. La transparencia se reemplaza por el fondo elegido."
                                else ->
                                    "WebP suele pesar bastante menos que JPG con la misma calidad visual."
                            }
                        )
                    }
                }

                ToolId.CROP_ROTATE_IMAGE -> {
                    StudioPanel {
                        when (tab) {
                            0 -> {
                                StudioHint("Arrastra las esquinas o los bordes. Toca dentro para mover el recuadro.")
                                StudioChipRow {
                                    ImageStudioPresets.aspects.forEachIndexed { index, aspect ->
                                        StudioChip(
                                            label = aspect.label,
                                            active = aspectIndex == index,
                                            onClick = {
                                                aspectIndex = index
                                                val ratio = aspect.ratio
                                                if (ratio != null) {
                                                    val rect = centeredRect(ratio, stageRatio())
                                                    cropLeft = rect[0]
                                                    cropTop = rect[1]
                                                    cropRight = rect[2]
                                                    cropBottom = rect[3]
                                                }
                                            }
                                        )
                                    }
                                }
                                StudioChipRow {
                                    StudioChip(
                                        label = "Toda la foto",
                                        active = false,
                                        onClick = {
                                            cropLeft = 0f
                                            cropTop = 0f
                                            cropRight = 1f
                                            cropBottom = 1f
                                            aspectIndex = 0
                                        }
                                    )
                                    StudioChip(
                                        label = "Centrar recuadro",
                                        active = false,
                                        onClick = {
                                            val w = cropRight - cropLeft
                                            val h = cropBottom - cropTop
                                            cropLeft = (1f - w) / 2f
                                            cropTop = (1f - h) / 2f
                                            cropRight = cropLeft + w
                                            cropBottom = cropTop + h
                                        }
                                    )
                                }
                            }
                            1 -> {
                                StudioSlider(
                                    label = "Enderezar",
                                    valueText = String.format("%.1f°", fineRotation),
                                    value = fineRotation,
                                    range = -45f..45f
                                ) { fineRotation = it }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    StudioSecondaryButton(
                                        label = "90° izq.",
                                        icon = Icons.Rounded.RotateLeft,
                                        onClick = { quarterTurns = (quarterTurns + 3) % 4 },
                                        modifier = Modifier.weight(1f)
                                    )
                                    StudioSecondaryButton(
                                        label = "90° der.",
                                        icon = Icons.Rounded.RotateRight,
                                        onClick = { quarterTurns = (quarterTurns + 1) % 4 },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                StudioChipRow {
                                    StudioChip("Espejo ↔", flipH, onClick = { flipH = !flipH })
                                    StudioChip("Espejo ↕", flipV, onClick = { flipV = !flipV })
                                    StudioChip(
                                        label = "Sin giro",
                                        active = quarterTurns == 0 && abs(fineRotation) < 0.05f,
                                        onClick = {
                                            quarterTurns = 0
                                            fineRotation = 0f
                                        }
                                    )
                                }
                                StudioHint("Al enderezar se recorta lo justo para que no queden esquinas vacías.")
                            }
                            else -> {
                                StudioChipRow {
                                    DocumentImageFilter.entries.forEachIndexed { index, filter ->
                                        StudioChip(
                                            label = filter.label,
                                            active = filterIndex == index,
                                            onClick = { filterIndex = index }
                                        )
                                    }
                                }
                                StudioSlider(
                                    label = "Brillo",
                                    valueText = brightness.roundToInt().toString(),
                                    value = brightness,
                                    range = -80f..80f
                                ) { brightness = it }
                                StudioSlider(
                                    label = "Contraste",
                                    valueText = String.format("%.2f", contrast),
                                    value = contrast,
                                    range = 0.5f..1.8f
                                ) { contrast = it }
                                StudioSlider(
                                    label = "Saturación",
                                    valueText = String.format("%.2f", saturation),
                                    value = saturation,
                                    range = 0f..2f
                                ) { saturation = it }
                                StudioChipRow {
                                    StudioChip(
                                        label = "Restablecer color",
                                        active = false,
                                        onClick = {
                                            brightness = 0f
                                            contrast = 1f
                                            saturation = 1f
                                            filterIndex = 0
                                        }
                                    )
                                }
                            }
                        }
                    }
                    StudioTabs(listOf("Recortar", "Girar", "Color"), tab) { tab = it }
                }

                ToolId.WATERMARK_IMAGE -> {
                    StudioPanel {
                        when (tab) {
                            0 -> {
                                StudioTextField(
                                    value = watermarkText,
                                    onValueChange = { watermarkText = it.take(80) },
                                    label = "Texto",
                                    placeholder = "Nombre, curso, fecha…",
                                    modifier = Modifier.fillMaxWidth()
                                )
                                StudioLabel("Tipografía")
                                StudioChipRow {
                                    ImageStudioOps.WatermarkFont.entries.forEachIndexed { index, font ->
                                        StudioChip(
                                            label = font.label,
                                            active = fontIndex == index,
                                            onClick = { fontIndex = index }
                                        )
                                    }
                                }
                                StudioLabel("Color")
                                StudioChipRow {
                                    markColors.forEachIndexed { index, entry ->
                                        StudioChip(
                                            label = entry.first,
                                            active = colorIndex == index,
                                            onClick = { colorIndex = index }
                                        )
                                    }
                                }
                                StudioHint("Arrastra la marca sobre la imagen para colocarla donde quieras.")
                            }
                            1 -> {
                                StudioSlider(
                                    label = "Opacidad",
                                    valueText = "${opacity.roundToInt()} %",
                                    value = opacity,
                                    range = 5f..100f
                                ) { opacity = it }
                                StudioSlider(
                                    label = "Tamaño",
                                    valueText = String.format("%.1f %%", markSize),
                                    value = markSize,
                                    range = 2f..30f
                                ) { markSize = it }
                                StudioSlider(
                                    label = "Rotación",
                                    valueText = "${markRotation.roundToInt()}°",
                                    value = markRotation,
                                    range = -90f..90f
                                ) { markRotation = it }
                                StudioChipRow {
                                    StudioChip("Con sombra", shadowMark, onClick = { shadowMark = !shadowMark })
                                    StudioChip(
                                        label = "Recto",
                                        active = abs(markRotation) < 0.5f,
                                        onClick = { markRotation = 0f }
                                    )
                                    StudioChip(
                                        label = "Diagonal",
                                        active = abs(markRotation + 30f) < 0.5f,
                                        onClick = { markRotation = -30f }
                                    )
                                }
                            }
                            2 -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                    StudioPositionGrid(
                                        selected = positionIndex,
                                        onSelect = { index ->
                                            positionIndex = index
                                            val position = ImageStudioPresets.watermarkPositions[index].second
                                            markX = position.first
                                            markY = position.second
                                        }
                                    )
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        StudioChip(
                                            label = if (tileMark) "Mosaico activado" else "Mosaico desactivado",
                                            active = tileMark,
                                            onClick = { tileMark = !tileMark },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        if (tileMark) {
                                            StudioSlider(
                                                label = "Separación",
                                                valueText = String.format("%.1f×", tileSpacing),
                                                value = tileSpacing,
                                                range = 1.1f..3.5f
                                            ) { tileSpacing = it }
                                        } else {
                                            StudioHint("Elige una de las nueve posiciones o arrastra la marca en la imagen.")
                                        }
                                    }
                                }
                            }
                            else -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    StudioSecondaryButton(
                                        label = if (logoBitmap == null) "Elegir logo" else "Cambiar logo",
                                        icon = Icons.Rounded.Image,
                                        onClick = {
                                            logoLauncher.launch(
                                                PickVisualMediaRequest(
                                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                                )
                                            )
                                        },
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (logoBitmap != null) {
                                        StudioSecondaryButton(
                                            label = "Quitar",
                                            icon = Icons.Rounded.Delete,
                                            onClick = { logoUriText = null },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                                if (logoBitmap != null) {
                                    StudioSlider(
                                        label = "Tamaño del logo",
                                        valueText = "${logoSize.roundToInt()} %",
                                        value = logoSize,
                                        range = 5f..70f
                                    ) { logoSize = it }
                                    StudioSlider(
                                        label = "Opacidad del logo",
                                        valueText = "${logoOpacity.roundToInt()} %",
                                        value = logoOpacity,
                                        range = 10f..100f
                                    ) { logoOpacity = it }
                                    StudioSlider(
                                        label = "Rotación del logo",
                                        valueText = "${logoRotation.roundToInt()}°",
                                        value = logoRotation,
                                        range = -90f..90f
                                    ) { logoRotation = it }
                                    StudioHint("Con esta pestaña abierta, arrastra sobre la imagen para mover el logo.")
                                } else {
                                    StudioHint("Puedes usar un logo o una firma en PNG con transparencia además del texto.")
                                }
                            }
                        }
                    }
                    StudioTabs(listOf("Texto", "Estilo", "Posición", "Logo"), tab) { tab = it }
                }

                else -> Unit
            }
        }
    )
}

// ---------------------------------------------------------------------------
// Piezas auxiliares
// ---------------------------------------------------------------------------

@Composable
private fun OutputSection(
    formats: List<String>,
    formatIndex: Int,
    onFormatChange: (Int) -> Unit,
    showQuality: Boolean,
    quality: Float,
    onQualityChange: (Float) -> Unit,
    backgroundColors: List<Pair<String, Int>>,
    backgroundIndex: Int,
    onBackgroundChange: (Int) -> Unit,
    showBackground: Boolean
) {
    StudioLabel("Formato")
    StudioChipRow {
        formats.forEachIndexed { index, label ->
            StudioChip(
                label = label,
                active = formatIndex == index,
                onClick = { onFormatChange(index) }
            )
        }
    }
    if (showQuality) {
        StudioSlider(
            label = "Calidad",
            valueText = "${quality.roundToInt()} %",
            value = quality,
            range = 20f..100f,
            onValueChange = onQualityChange
        )
    }
    if (showBackground) {
        StudioLabel("Color de relleno")
        StudioChipRow {
            backgroundColors.forEachIndexed { index, entry ->
                StudioChip(
                    label = entry.first,
                    active = backgroundIndex == index,
                    onClick = { onBackgroundChange(index) }
                )
            }
        }
    }
    StudioHint("Se guarda una copia nueva sin datos EXIF; la imagen original no se toca.")
}

/**
 * Lienzo de recorte. La imagen se gira con la propia capa de dibujo y el
 * recuadro visible es exactamente el que se exporta, sin bordes vacios.
 */
@Composable
private fun CropStage(
    base: Bitmap,
    quarterTurns: Int,
    flipH: Boolean,
    flipV: Boolean,
    angle: Float,
    matrix: FloatArray?,
    cropLeft: Float,
    cropTop: Float,
    cropRight: Float,
    cropBottom: Float,
    lockedRatio: Float?,
    showCrop: Boolean,
    onCropChange: (Float, Float, Float, Float) -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        // Los giros, los espejos y el enderezado se aplican con la capa de dibujo.
        // No se crea ningun bitmap intermedio, asi que girar es instantaneo y no
        // gasta memoria aunque se toque muchas veces seguidas.
        val swapped = quarterTurns % 2 == 1
        val turnedW = if (swapped) base.height.toFloat() else base.width.toFloat()
        val turnedH = if (swapped) base.width.toFloat() else base.height.toFloat()
        val straight = ImageStudioOps.straightenedSize(turnedW, turnedH, angle)
        val stageW = straight.first.coerceAtLeast(1f)
        val stageH = straight.second.coerceAtLeast(1f)
        val stageRatio = (stageW / stageH).coerceAtLeast(0.01f)
        val boxRatio = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
        val displayW =
            if (stageRatio > boxRatio) maxWidth.value * 0.92f else maxHeight.value * 0.88f * stageRatio
        val displayH = displayW / stageRatio
        val scale = displayW / stageW
        val imageW = base.width * scale
        val imageH = base.height * scale

        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .width(displayW.dp)
                .height(displayH.dp)
                .clipToBounds()
        ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Image(
                    bitmap = base.asImageBitmap(),
                    contentDescription = "Vista previa",
                    contentScale = ContentScale.FillBounds,
                    colorFilter = matrix?.let { studioColorFilter(it) },
                    modifier = Modifier
                        .width(imageW.dp)
                        .height(imageH.dp)
                        .graphicsLayer {
                            rotationZ = quarterTurns * 90f + angle
                            scaleX = if (flipH) -1f else 1f
                            scaleY = if (flipV) -1f else 1f
                        }
                )
            }
            if (showCrop) {
                StudioCropOverlay(
                    left = cropLeft,
                    top = cropTop,
                    right = cropRight,
                    bottom = cropBottom,
                    lockedRatio = lockedRatio,
                    onChange = onCropChange,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

/** Rectangulo centrado con la proporcion pedida dentro del lienzo 0..1. */
private fun centeredRect(targetRatio: Float, stageRatio: Float): FloatArray {
    val relative = targetRatio / stageRatio.coerceAtLeast(0.001f)
    return if (relative >= 1f) {
        val height = (1f / relative).coerceIn(0.05f, 1f)
        floatArrayOf(0f, (1f - height) / 2f, 1f, (1f + height) / 2f)
    } else {
        val width = relative.coerceIn(0.05f, 1f)
        floatArrayOf((1f - width) / 2f, 0f, (1f + width) / 2f, 1f)
    }
}

private fun formatMeasure(value: Float): String =
    if (abs(value - value.roundToInt()) < 0.01f) value.roundToInt().toString()
    else String.format("%.2f", value)

private fun scaledPreview(bitmap: Bitmap, maxEdge: Int): Bitmap? = runCatching {
    val longest = max(bitmap.width, bitmap.height)
    if (longest <= maxEdge) {
        bitmap.copy(Bitmap.Config.ARGB_8888, false)
    } else {
        val scale = maxEdge.toFloat() / longest
        Bitmap.createScaledBitmap(
            bitmap,
            max(1, (bitmap.width * scale).roundToInt()),
            max(1, (bitmap.height * scale).roundToInt()),
            true
        )
    }
}.getOrNull()

private fun editorTitle(tool: ToolId): String = when (tool) {
    ToolId.COMPRESS_IMAGE -> "Comprimir imagen"
    ToolId.RESIZE_IMAGE -> "Cambiar tamaño"
    ToolId.CONVERT_IMAGE -> "Convertir formato"
    ToolId.CROP_ROTATE_IMAGE -> "Recortar y girar"
    ToolId.WATERMARK_IMAGE -> "Marca de agua"
    else -> tool.title
}

private fun pickerDescription(tool: ToolId): String = when (tool) {
    ToolId.COMPRESS_IMAGE -> "Reduce el peso de una foto sin que se note, comparando antes y después."
    ToolId.RESIZE_IMAGE -> "Cambia las medidas por porcentaje, por píxeles exactos o con un tamaño listo para usar."
    ToolId.CONVERT_IMAGE -> "Pasa una imagen a JPG, PNG o WebP eligiendo calidad y fondo."
    ToolId.CROP_ROTATE_IMAGE -> "Recorta a mano, endereza, gira y ajusta el color de tu foto."
    ToolId.WATERMARK_IMAGE -> "Pon tu nombre o tu logo sobre la imagen y colócalo donde quieras."
    else -> "Elige una imagen para empezar."
}

private fun pickerFeatures(tool: ToolId): List<String> = when (tool) {
    ToolId.COMPRESS_IMAGE -> listOf(
        "Ajustes rápidos para WhatsApp, correo y web",
        "Peso objetivo en KB: la app busca la calidad que entra",
        "Comparación antes y después con el ahorro real",
        "Salida en JPG o WebP"
    )
    ToolId.RESIZE_IMAGE -> listOf(
        "Escala por porcentaje o medidas exactas",
        "Presets de Instagram, historias, YouTube y más",
        "Medidas de foto carnet en milímetros con DPI",
        "Modos ajustar, rellenar y estirar con proporción bloqueada"
    )
    ToolId.CONVERT_IMAGE -> listOf(
        "JPG, PNG y WebP con control de calidad",
        "Elige el color de fondo al quitar la transparencia",
        "Peso estimado antes de guardar"
    )
    ToolId.CROP_ROTATE_IMAGE -> listOf(
        "Recuadro libre con rejilla de tercios: tú eliges qué se queda",
        "Proporciones 1:1, 4:5, 16:9, A4 y más",
        "Enderezado fino con dial y giros de 90°",
        "Brillo, contraste, saturación y filtros"
    )
    ToolId.WATERMARK_IMAGE -> listOf(
        "Texto o logo, arrastrables sobre la imagen",
        "Nueve posiciones rápidas y modo mosaico",
        "Opacidad, tamaño, rotación, color y sombra",
        "Lo que ves en pantalla es lo que se guarda"
    )
    else -> emptyList()
}
