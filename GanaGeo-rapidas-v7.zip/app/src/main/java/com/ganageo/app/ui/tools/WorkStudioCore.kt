package com.ganageo.app.ui.tools

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ganageo.app.tools.CurrencyInfo
import com.ganageo.app.tools.Money
import java.math.BigDecimal

/**
 * Piezas comunes de las herramientas de trabajo.
 *
 * Comparten la estructura y la paleta con el resto de la app, pero aquí el
 * protagonista no es un lienzo sino el documento o la lista: cotización,
 * inventario, planilla. Por eso todo gira alrededor de tarjetas de datos y una
 * barra de totales siempre visible.
 */

@Composable
fun WorkActionButton(
    text: String,
    onClick: () -> Unit,
    icon: ImageVector = Icons.Rounded.PlayArrow,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = StudioTheme.Accent,
            contentColor = StudioTheme.OnAccent,
            disabledContainerColor = StudioTheme.SurfaceHigh,
            disabledContentColor = StudioTheme.TextSecondary
        )
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Text("  $text", fontWeight = FontWeight.Bold)
    }
}

/** Aviso legal. Se usa para dejar clarísimo qué NO es el documento generado. */
@Composable
fun LegalNote(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(StudioTheme.Warning.copy(alpha = 0.12f))
            .border(1.dp, StudioTheme.Warning.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            Icons.Rounded.Info,
            contentDescription = null,
            tint = StudioTheme.Warning,
            modifier = Modifier.size(17.dp)
        )
        Spacer(Modifier.width(9.dp))
        Text(
            text,
            color = StudioTheme.TextSecondary,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

/** Barra de totales, con el importe final destacado. */
@Composable
fun WorkTotals(
    rows: List<Pair<String, String>>,
    total: Pair<String, String>,
    note: String? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(StudioTheme.Accent.copy(alpha = 0.10f))
            .border(1.dp, StudioTheme.Accent.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        rows.forEach { (label, value) ->
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    label,
                    color = StudioTheme.TextSecondary,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    value,
                    color = StudioTheme.TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(StudioTheme.Accent.copy(alpha = 0.3f))
        )
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                total.first,
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.weight(1f)
            )
            Text(
                total.second,
                color = StudioTheme.Accent,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp
            )
        }
        if (note != null) {
            Text(
                note,
                color = StudioTheme.TextSecondary,
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Default
            )
        }
    }
}

/** Tarjeta que simula la hoja del documento, para la vista previa. */
@Composable
fun DocumentSheet(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFF7F8FA))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        content = content
    )
}

@Composable
fun SheetTitle(text: String) {
    Text(
        text,
        color = Color(0xFF15181C),
        fontWeight = FontWeight.Bold,
        fontSize = 17.sp
    )
}

@Composable
fun SheetLabel(text: String) {
    Text(
        text.uppercase(),
        color = Color(0xFF12603E),
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp
    )
}

@Composable
fun SheetText(text: String, bold: Boolean = false) {
    Text(
        text,
        color = Color(0xFF2A2F35),
        fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
        fontSize = 12.sp
    )
}

/** Fila con etiqueta a la izquierda e importe alineado a la derecha. */
@Composable
fun MoneyRow(label: String, value: String, highlight: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            color = StudioTheme.TextSecondary,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.weight(1f)
        )
        Text(
            value,
            color = if (highlight) StudioTheme.Accent else StudioTheme.TextPrimary,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.SemiBold,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Monospace
        )
    }
}

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------

fun workMoney(raw: String): BigDecimal = Money.ofOrZero(raw)

fun workMoneyOrNull(raw: String): BigDecimal? = Money.parseOrNull(raw)

fun formatMoney(value: BigDecimal, currency: CurrencyInfo): String = Money.format(value, currency)

fun copyToClipboard(context: Context, label: String, text: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    manager.setPrimaryClip(ClipData.newPlainText(label, text))
}

fun shareText(context: Context, subject: String, text: String) {
    runCatching {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, subject))
    }
}

fun writeTextToUri(context: Context, uri: android.net.Uri, text: String) {
    context.contentResolver.openOutputStream(uri, "w")?.use { stream ->
        stream.write(text.toByteArray(Charsets.UTF_8))
    } ?: error("No se pudo escribir el archivo.")
}

fun csvCell(value: String): String {
    val needsQuotes = value.contains(',') || value.contains('"') || value.contains('\n')
    val escaped = value.replace("\"", "\"\"")
    return if (needsQuotes) "\"$escaped\"" else escaped
}

fun safeFileName(value: String, fallback: String): String {
    val clean = value.trim().replace(Regex("[^A-Za-z0-9 _-]"), "").replace(" ", "_")
    return clean.ifBlank { fallback }.take(60)
}
