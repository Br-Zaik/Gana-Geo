package com.ganageo.app.tools

/**
 * Motor de referencias bibliográficas.
 *
 * Las cursivas se marcan con asteriscos (*así*). El texto plano para copiar se
 * obtiene con [CitationEngine.plain] y la interfaz las convierte en cursiva de
 * verdad. Es la forma más simple de que la misma referencia sirva para mostrar,
 * copiar y exportar sin duplicar plantillas.
 */

enum class CitationStyle(val label: String, val description: String) {
    APA7("APA 7", "Psicología, educación, ciencias sociales. Autor-fecha."),
    VANCOUVER("Vancouver", "Salud y medicina. Numérica por orden de aparición."),
    IEEE("IEEE", "Ingeniería y computación. Numérica entre corchetes."),
    MLA9("MLA 9", "Humanidades y letras. Autor-página."),
    ISO690("ISO 690", "Muy usada en universidades peruanas y españolas.")
}

enum class SourceType(val label: String) {
    BOOK("Libro"),
    CHAPTER("Capítulo de libro"),
    ARTICLE("Artículo de revista"),
    WEBSITE("Página web"),
    THESIS("Tesis"),
    REPORT("Informe"),
    VIDEO("Video"),
    CONFERENCE("Ponencia"),
    LAW("Ley o norma")
}

data class CitationAuthor(
    val lastName: String,
    val firstNames: String = "",
    val isOrganization: Boolean = false
)

data class SourceData(
    val type: SourceType = SourceType.BOOK,
    val authors: List<CitationAuthor> = emptyList(),
    val year: String = "",
    val date: String = "",
    val title: String = "",
    val containerTitle: String = "",
    val editors: List<CitationAuthor> = emptyList(),
    val edition: String = "",
    val volume: String = "",
    val issue: String = "",
    val pages: String = "",
    val publisher: String = "",
    val siteName: String = "",
    val doi: String = "",
    val url: String = "",
    val accessed: String = "",
    val university: String = "",
    val thesisKind: String = "Tesis de licenciatura",
    val city: String = "",
    val identifier: String = ""
)

object CitationEngine {

    /** Campos que hay que pedir sí o sí para poder armar la referencia. */
    fun requiredFields(type: SourceType): List<String> = when (type) {
        SourceType.BOOK -> listOf("Autores", "Año", "Título", "Editorial")
        SourceType.CHAPTER -> listOf("Autores", "Año", "Título del capítulo", "Editores", "Título del libro", "Páginas", "Editorial")
        SourceType.ARTICLE -> listOf("Autores", "Año", "Título", "Revista", "Volumen", "Páginas")
        SourceType.WEBSITE -> listOf("Autor", "Fecha", "Título", "Sitio", "URL")
        SourceType.THESIS -> listOf("Autor", "Año", "Título", "Universidad")
        SourceType.REPORT -> listOf("Autor o institución", "Año", "Título", "Editorial")
        SourceType.VIDEO -> listOf("Autor o canal", "Fecha", "Título", "Plataforma", "URL")
        SourceType.CONFERENCE -> listOf("Autores", "Año", "Título", "Nombre del congreso")
        SourceType.LAW -> listOf("Título de la norma", "Número", "Año", "Publicación oficial")
    }

    fun missingFields(data: SourceData): List<String> {
        val missing = mutableListOf<String>()
        fun check(condition: Boolean, label: String) {
            if (!condition) missing += label
        }
        if (data.type != SourceType.LAW) check(data.authors.isNotEmpty(), "Autores")
        check(data.title.isNotBlank(), "Título")
        when (data.type) {
            SourceType.BOOK, SourceType.REPORT -> check(data.publisher.isNotBlank(), "Editorial")
            SourceType.CHAPTER -> {
                check(data.containerTitle.isNotBlank(), "Título del libro")
                check(data.publisher.isNotBlank(), "Editorial")
            }
            SourceType.ARTICLE -> check(data.containerTitle.isNotBlank(), "Revista")
            SourceType.WEBSITE, SourceType.VIDEO -> check(data.url.isNotBlank(), "URL")
            SourceType.THESIS -> check(data.university.isNotBlank(), "Universidad")
            SourceType.CONFERENCE -> check(data.containerTitle.isNotBlank(), "Nombre del congreso")
            SourceType.LAW -> check(data.publisher.isNotBlank(), "Publicación oficial")
        }
        if (data.year.isBlank() && data.date.isBlank()) missing += "Año"
        return missing
    }

    /**
     * Lee los autores escritos por el usuario.
     *
     * Acepta "García Márquez, Gabriel; Vargas Llosa, Mario" y también
     * "Gabriel García Márquez, Mario Vargas Llosa". En español los dos apellidos
     * forman una unidad: nunca se abrevia el segundo y la referencia alfabetiza
     * por el primero.
     */
    fun parseAuthors(raw: String): List<CitationAuthor> {
        if (raw.isBlank()) return emptyList()
        val chunks = raw.split(';', '\n').map { it.trim() }.filter { it.isNotBlank() }
        val useCommaSplit = chunks.size == 1 && raw.count { it == ',' } > 1 && !raw.contains(';')
        val parts = if (useCommaSplit) raw.split(',').map { it.trim() }.filter { it.isNotBlank() } else chunks
        return parts.mapNotNull { parseSingleAuthor(it) }
    }

    private fun parseSingleAuthor(raw: String): CitationAuthor? {
        val text = raw.trim()
        if (text.isBlank()) return null
        // Una institución no tiene nombre de pila: se detecta porque trae
        // palabras como "Universidad", "Ministerio" o va en mayúsculas.
        val organizationWords = listOf(
            "universidad", "ministerio", "instituto", "organización", "organizacion",
            "asociación", "asociacion", "colegio", "banco", "fondo", "comisión", "comision",
            "gobierno", "consejo", "sociedad", "fundación", "fundacion", "s.a.", "inc"
        )
        if (organizationWords.any { text.lowercase().contains(it) }) {
            return CitationAuthor(lastName = text, isOrganization = true)
        }
        if (text.contains(',')) {
            val pieces = text.split(',', limit = 2)
            return CitationAuthor(pieces[0].trim(), pieces.getOrElse(1) { "" }.trim())
        }
        val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size == 1) return CitationAuthor(words.first())
        // Sin coma: se asume que los dos últimos son apellidos si hay 3 palabras o más.
        val particles = setOf("de", "del", "la", "las", "los", "van", "von", "da", "di")
        return if (words.size >= 3) {
            var cut = words.size - 2
            while (cut > 1 && words[cut - 1].lowercase() in particles) cut--
            CitationAuthor(
                lastName = words.drop(cut).joinToString(" "),
                firstNames = words.take(cut).joinToString(" ")
            )
        } else {
            CitationAuthor(lastName = words.last(), firstNames = words.dropLast(1).joinToString(" "))
        }
    }

    private fun initials(firstNames: String): String =
        firstNames.split(Regex("[\\s.-]+"))
            .filter { it.isNotBlank() }
            .joinToString(" ") { "${it.first().uppercaseChar()}." }

    private fun initialsNoDots(firstNames: String): String =
        firstNames.split(Regex("[\\s.-]+"))
            .filter { it.isNotBlank() }
            .joinToString("") { it.first().uppercaseChar().toString() }

    // ------------------------------------------------------------------
    // Autores por estilo
    // ------------------------------------------------------------------

    private fun apaAuthors(authors: List<CitationAuthor>, spanish: Boolean): String {
        if (authors.isEmpty()) return ""
        val connector = if (spanish) "y" else "&"
        val formatted = authors.map { author ->
            if (author.isOrganization) author.lastName
            else listOf(author.lastName, initials(author.firstNames)).filter { it.isNotBlank() }.joinToString(", ")
        }
        return when {
            formatted.size == 1 -> formatted.first()
            formatted.size == 2 -> "${formatted[0]}, $connector ${formatted[1]}"
            formatted.size <= 20 ->
                formatted.dropLast(1).joinToString(", ") + ", $connector " + formatted.last()
            // Con 21 o más autores: los 19 primeros, puntos suspensivos y el último.
            else -> formatted.take(19).joinToString(", ") + ", . . . " + formatted.last()
        }
    }

    private fun vancouverAuthors(authors: List<CitationAuthor>): String {
        if (authors.isEmpty()) return ""
        val formatted = authors.map { author ->
            if (author.isOrganization) author.lastName
            else "${author.lastName} ${initialsNoDots(author.firstNames)}".trim()
        }
        // Hasta seis autores; a partir del séptimo se cortan en seis y se añade et al.
        return if (formatted.size > 6) formatted.take(6).joinToString(", ") + ", et al."
        else formatted.joinToString(", ")
    }

    private fun ieeeAuthors(authors: List<CitationAuthor>): String {
        if (authors.isEmpty()) return ""
        val formatted = authors.map { author ->
            if (author.isOrganization) author.lastName
            else listOf(initials(author.firstNames), author.lastName).filter { it.isNotBlank() }.joinToString(" ")
        }
        return when {
            formatted.size > 6 -> formatted.take(6).joinToString(", ") + ", et al."
            formatted.size == 1 -> formatted.first()
            else -> formatted.dropLast(1).joinToString(", ") + ", and " + formatted.last()
        }
    }

    private fun mlaAuthors(authors: List<CitationAuthor>): String {
        if (authors.isEmpty()) return ""
        val first = authors.first().let { author ->
            if (author.isOrganization) author.lastName
            else listOf(author.lastName, author.firstNames).filter { it.isNotBlank() }.joinToString(", ")
        }
        return when {
            authors.size == 1 -> first
            // Con tres o más autores, MLA usa el primero y et al.
            authors.size >= 3 -> "$first, et al."
            else -> {
                val second = authors[1].let { "${it.firstNames} ${it.lastName}".trim() }
                "$first, and $second"
            }
        }
    }

    private fun isoAuthors(authors: List<CitationAuthor>): String {
        if (authors.isEmpty()) return ""
        return authors.joinToString("; ") { author ->
            if (author.isOrganization) author.lastName.uppercase()
            else listOf(author.lastName.uppercase(), author.firstNames).filter { it.isNotBlank() }.joinToString(", ")
        }
    }

    // ------------------------------------------------------------------
    // Referencias
    // ------------------------------------------------------------------

    fun reference(style: CitationStyle, data: SourceData, spanish: Boolean = true): String = when (style) {
        CitationStyle.APA7 -> apa(data, spanish)
        CitationStyle.VANCOUVER -> vancouver(data)
        CitationStyle.IEEE -> ieee(data)
        CitationStyle.MLA9 -> mla(data)
        CitationStyle.ISO690 -> iso(data)
    }.replace(Regex("\\s+([,.;])"), "$1")
        .replace(Regex("\\s{2,}"), " ")
        .trim()

    private fun yearOrNoDate(data: SourceData): String =
        when {
            data.date.isNotBlank() -> data.date
            data.year.isNotBlank() -> data.year
            else -> "s.f."
        }

    private fun link(data: SourceData): String = when {
        data.doi.isNotBlank() -> normalizeDoi(data.doi)
        data.url.isNotBlank() -> data.url.trim()
        else -> ""
    }

    /** Normaliza el DOI al formato actual: https://doi.org/… y sin punto final. */
    fun normalizeDoi(raw: String): String {
        val clean = raw.trim()
            .removePrefix("doi:")
            .removePrefix("DOI:")
            .removePrefix("http://dx.doi.org/")
            .removePrefix("https://dx.doi.org/")
            .removePrefix("http://doi.org/")
            .removePrefix("https://doi.org/")
            .trim()
            .trimEnd('.')
        return if (clean.isBlank()) "" else "https://doi.org/$clean"
    }

    private fun apa(data: SourceData, spanish: Boolean): String {
        val authors = apaAuthors(data.authors, spanish)
        val year = yearOrNoDate(data)
        val head = if (authors.isBlank()) "" else "$authors "
        val edition = if (data.edition.isBlank()) "" else " (${data.edition} ed.)"
        val url = link(data)
        val tail = if (url.isBlank()) "" else " $url"

        return when (data.type) {
            SourceType.BOOK ->
                "$head($year). *${data.title}*$edition. ${data.publisher}.$tail"
            SourceType.CHAPTER -> {
                val editors = data.editors.joinToString(", ") {
                    "${initials(it.firstNames)} ${it.lastName}".trim()
                }
                val editorLabel = if (data.editors.size > 1) "Eds." else "Ed."
                val pages = if (data.pages.isBlank()) "" else " (pp. ${data.pages})"
                "$head($year). ${data.title}. En $editors ($editorLabel), *${data.containerTitle}*$pages. ${data.publisher}.$tail"
            }
            SourceType.ARTICLE -> {
                val issue = if (data.issue.isBlank()) "" else "(${data.issue})"
                val pages = if (data.pages.isBlank()) "" else ", ${data.pages}"
                "$head($year). ${data.title}. *${data.containerTitle}*, *${data.volume}*$issue$pages.$tail"
            }
            SourceType.WEBSITE -> {
                val site = if (data.siteName.isBlank()) "" else " ${data.siteName}."
                val retrieved = if (data.accessed.isBlank()) "" else
                    " Recuperado el ${data.accessed}, de ${data.url}"
                if (data.accessed.isBlank()) "$head($year). *${data.title}*.$site$tail"
                else "$head($year). *${data.title}*.$site$retrieved"
            }
            SourceType.THESIS ->
                "$head($year). *${data.title}* [${data.thesisKind}, ${data.university}]." +
                    (if (data.publisher.isBlank()) "" else " ${data.publisher}.") + tail
            SourceType.REPORT -> {
                val number = if (data.identifier.isBlank()) "" else " (${data.identifier})"
                "$head($year). *${data.title}*$number. ${data.publisher}.$tail"
            }
            SourceType.VIDEO -> {
                val platform = data.siteName.ifBlank { "YouTube" }
                "$head($year). *${data.title}* [Video]. $platform.$tail"
            }
            SourceType.CONFERENCE ->
                "$head($year). *${data.title}* [Ponencia]. ${data.containerTitle}, ${data.city}.$tail"
            SourceType.LAW ->
                "${data.title}, ${data.identifier} ($year). ${data.publisher}.$tail"
        }
    }

    private fun vancouver(data: SourceData): String {
        val authors = vancouverAuthors(data.authors)
        val head = if (authors.isBlank()) "" else "$authors. "
        val year = yearOrNoDate(data)
        val url = link(data)
        val tail = if (url.isBlank()) "" else " Disponible en: $url"

        return when (data.type) {
            SourceType.ARTICLE -> {
                val issue = if (data.issue.isBlank()) "" else "(${data.issue})"
                val pages = if (data.pages.isBlank()) "" else ":${data.pages}"
                "$head${data.title}. ${data.containerTitle}. $year;${data.volume}$issue$pages.$tail"
            }
            SourceType.BOOK -> {
                val edition = if (data.edition.isBlank()) "" else " ${data.edition} ed."
                val city = if (data.city.isBlank()) "" else "${data.city}: "
                "$head${data.title}.$edition $city${data.publisher}; $year.$tail"
            }
            SourceType.CHAPTER -> {
                val editors = data.editors.joinToString(", ") {
                    "${it.lastName} ${initialsNoDots(it.firstNames)}".trim()
                }
                val pages = if (data.pages.isBlank()) "" else " p. ${data.pages}."
                "$head${data.title}. En: $editors, editores. ${data.containerTitle}. ${data.publisher}; $year.$pages$tail"
            }
            SourceType.WEBSITE, SourceType.VIDEO -> {
                val accessed = if (data.accessed.isBlank()) "" else " [citado ${data.accessed}]."
                "$head${data.title} [Internet]. ${data.siteName}; $year$accessed$tail"
            }
            SourceType.THESIS ->
                "$head${data.title} [tesis]. ${data.city}: ${data.university}; $year.$tail"
            else ->
                "$head${data.title}. ${data.publisher}; $year.$tail"
        }
    }

    private fun ieee(data: SourceData): String {
        val authors = ieeeAuthors(data.authors)
        val head = if (authors.isBlank()) "" else "$authors, "
        val year = yearOrNoDate(data)
        val url = link(data)
        val tail = if (url.isBlank()) "" else " [Online]. Available: $url"

        return when (data.type) {
            SourceType.ARTICLE -> {
                val issue = if (data.issue.isBlank()) "" else ", no. ${data.issue}"
                val pages = if (data.pages.isBlank()) "" else ", pp. ${data.pages}"
                "$head\"${data.title},\" *${data.containerTitle}*, vol. ${data.volume}$issue$pages, $year.$tail"
            }
            SourceType.BOOK -> {
                val edition = if (data.edition.isBlank()) "" else "${data.edition} ed. "
                "$head*${data.title}*. $edition${data.city}: ${data.publisher}, $year.$tail"
            }
            SourceType.CONFERENCE -> {
                val pages = if (data.pages.isBlank()) "" else ", pp. ${data.pages}"
                "$head\"${data.title},\" in *${data.containerTitle}*, ${data.city}, $year$pages.$tail"
            }
            SourceType.WEBSITE, SourceType.VIDEO -> {
                val accessed = if (data.accessed.isBlank()) "" else " (accessed ${data.accessed})"
                "$head\"${data.title}.\" ${data.siteName}. $year.$tail$accessed."
            }
            SourceType.THESIS ->
                "$head\"${data.title},\" ${data.thesisKind}, ${data.university}, ${data.city}, $year.$tail"
            else ->
                "$head\"${data.title},\" ${data.publisher}, $year.$tail"
        }
    }

    private fun mla(data: SourceData): String {
        val authors = mlaAuthors(data.authors)
        val head = if (authors.isBlank()) "" else "$authors. "
        val year = yearOrNoDate(data)
        val url = link(data)
        val tail = if (url.isBlank()) "" else " $url."

        return when (data.type) {
            SourceType.BOOK -> "$head*${data.title}*. ${data.publisher}, $year.$tail"
            SourceType.ARTICLE -> {
                val issue = if (data.issue.isBlank()) "" else ", no. ${data.issue}"
                val pages = if (data.pages.isBlank()) "" else ", pp. ${data.pages}"
                "$head\"${data.title}.\" *${data.containerTitle}*, vol. ${data.volume}$issue, $year$pages.$tail"
            }
            SourceType.CHAPTER -> {
                val editors = data.editors.joinToString(", ") { "${it.firstNames} ${it.lastName}".trim() }
                val pages = if (data.pages.isBlank()) "" else ", pp. ${data.pages}"
                "$head\"${data.title}.\" *${data.containerTitle}*, edited by $editors, ${data.publisher}, $year$pages.$tail"
            }
            SourceType.WEBSITE, SourceType.VIDEO -> {
                val site = if (data.siteName.isBlank()) "" else "*${data.siteName}*, "
                "$head\"${data.title}.\" $site$year.$tail"
            }
            else -> "$head*${data.title}*. ${data.publisher}, $year.$tail"
        }
    }

    private fun iso(data: SourceData): String {
        val authors = isoAuthors(data.authors)
        val head = if (authors.isBlank()) "" else "$authors. "
        val year = yearOrNoDate(data)
        val url = link(data)
        val tail = if (url.isBlank()) "" else " Disponible en: $url"
        val identifier = if (data.identifier.isBlank()) "" else " ${data.identifier}."

        return when (data.type) {
            SourceType.ARTICLE -> {
                val issue = if (data.issue.isBlank()) "" else ", n.º ${data.issue}"
                val pages = if (data.pages.isBlank()) "" else ", pp. ${data.pages}"
                "$head${data.title}. En: *${data.containerTitle}*. $year, vol. ${data.volume}$issue$pages.$identifier$tail"
            }
            SourceType.BOOK -> {
                val edition = if (data.edition.isBlank()) "" else " ${data.edition} ed."
                val city = if (data.city.isBlank()) "" else "${data.city}: "
                "$head*${data.title}*.$edition $city${data.publisher}, $year.$identifier$tail"
            }
            SourceType.WEBSITE, SourceType.VIDEO -> {
                val accessed = if (data.accessed.isBlank()) "" else " [consulta: ${data.accessed}]."
                "$head*${data.title}* [en línea]. ${data.siteName}, $year.$accessed$tail"
            }
            SourceType.THESIS ->
                "$head*${data.title}*. ${data.thesisKind}. ${data.city}: ${data.university}, $year.$tail"
            else -> "$head*${data.title}*. ${data.publisher}, $year.$identifier$tail"
        }
    }

    // ------------------------------------------------------------------
    // Cita dentro del texto
    // ------------------------------------------------------------------

    /**
     * Cita en el texto. En APA, desde tres autores se usa «et al.» ya en la
     * primera cita: eso cambió respecto de APA 6 y es el error más frecuente.
     */
    fun inText(
        style: CitationStyle,
        data: SourceData,
        number: Int = 1,
        page: String = "",
        narrative: Boolean = false,
        spanish: Boolean = true
    ): String {
        val year = yearOrNoDate(data)
        val names = data.authors.map { if (it.isOrganization) it.lastName else it.lastName }
        return when (style) {
            CitationStyle.APA7 -> {
                val connector = if (spanish) "y" else "&"
                val body = when {
                    names.isEmpty() -> data.title.take(40)
                    names.size == 1 -> names.first()
                    names.size == 2 -> if (narrative) "${names[0]} $connector ${names[1]}"
                    else "${names[0]} $connector ${names[1]}"
                    else -> "${names.first()} et al."
                }
                val pageText = if (page.isBlank()) "" else ", p. $page"
                if (narrative) "$body ($year$pageText)" else "($body, $year$pageText)"
            }
            CitationStyle.VANCOUVER -> "($number)"
            CitationStyle.IEEE -> "[$number]"
            CitationStyle.MLA9 -> {
                val body = when {
                    names.isEmpty() -> data.title.take(40)
                    names.size >= 3 -> "${names.first()} et al."
                    names.size == 2 -> "${names[0]} and ${names[1]}"
                    else -> names.first()
                }
                if (page.isBlank()) "($body)" else "($body $page)"
            }
            CitationStyle.ISO690 -> {
                val body = names.firstOrNull()?.uppercase() ?: data.title.take(40)
                if (page.isBlank()) "($body, $year)" else "($body, $year, p. $page)"
            }
        }
    }

    /** Ordena la bibliografía como corresponde a cada estilo. */
    fun sortReferences(style: CitationStyle, references: List<String>): List<String> = when (style) {
        CitationStyle.VANCOUVER, CitationStyle.IEEE -> references
        else -> references.sortedBy { plain(it).lowercase() }
    }

    fun plain(text: String): String = text.replace("*", "")

    // ------------------------------------------------------------------
    // Exportación para gestores bibliográficos
    // ------------------------------------------------------------------

    fun toRis(data: SourceData): String {
        val type = when (data.type) {
            SourceType.BOOK -> "BOOK"
            SourceType.CHAPTER -> "CHAP"
            SourceType.ARTICLE -> "JOUR"
            SourceType.WEBSITE -> "ELEC"
            SourceType.THESIS -> "THES"
            SourceType.REPORT -> "RPRT"
            SourceType.VIDEO -> "VIDEO"
            SourceType.CONFERENCE -> "CONF"
            SourceType.LAW -> "STAT"
        }
        return buildString {
            appendLine("TY  - $type")
            data.authors.forEach { author ->
                appendLine("AU  - ${author.lastName}${if (author.firstNames.isBlank()) "" else ", ${author.firstNames}"}")
            }
            if (data.year.isNotBlank()) appendLine("PY  - ${data.year}")
            if (data.title.isNotBlank()) appendLine("TI  - ${data.title}")
            if (data.containerTitle.isNotBlank()) appendLine("T2  - ${data.containerTitle}")
            if (data.volume.isNotBlank()) appendLine("VL  - ${data.volume}")
            if (data.issue.isNotBlank()) appendLine("IS  - ${data.issue}")
            if (data.pages.isNotBlank()) appendLine("SP  - ${data.pages}")
            if (data.publisher.isNotBlank()) appendLine("PB  - ${data.publisher}")
            if (data.doi.isNotBlank()) appendLine("DO  - ${data.doi.removePrefix("https://doi.org/")}")
            if (data.url.isNotBlank()) appendLine("UR  - ${data.url}")
            append("ER  - ")
        }
    }

    fun toBibTeX(data: SourceData): String {
        val entry = when (data.type) {
            SourceType.BOOK -> "book"
            SourceType.CHAPTER -> "incollection"
            SourceType.ARTICLE -> "article"
            SourceType.THESIS -> "phdthesis"
            SourceType.REPORT -> "techreport"
            SourceType.CONFERENCE -> "inproceedings"
            else -> "misc"
        }
        val key = (data.authors.firstOrNull()?.lastName?.filter { it.isLetter() }?.lowercase() ?: "ref") +
            data.year.filter { it.isDigit() }
        val fields = mutableListOf<Pair<String, String>>()
        if (data.authors.isNotEmpty()) {
            fields += "author" to data.authors.joinToString(" and ") {
                if (it.firstNames.isBlank()) it.lastName else "${it.lastName}, ${it.firstNames}"
            }
        }
        if (data.title.isNotBlank()) fields += "title" to data.title
        if (data.year.isNotBlank()) fields += "year" to data.year
        if (data.containerTitle.isNotBlank()) {
            fields += (if (data.type == SourceType.ARTICLE) "journal" else "booktitle") to data.containerTitle
        }
        if (data.volume.isNotBlank()) fields += "volume" to data.volume
        if (data.issue.isNotBlank()) fields += "number" to data.issue
        if (data.pages.isNotBlank()) fields += "pages" to data.pages
        if (data.publisher.isNotBlank()) fields += "publisher" to data.publisher
        if (data.doi.isNotBlank()) fields += "doi" to data.doi.removePrefix("https://doi.org/")
        if (data.url.isNotBlank()) fields += "url" to data.url
        return buildString {
            appendLine("@$entry{$key,")
            fields.forEachIndexed { index, (name, value) ->
                append("  $name = {$value}")
                appendLine(if (index == fields.lastIndex) "" else ",")
            }
            append("}")
        }
    }
}
