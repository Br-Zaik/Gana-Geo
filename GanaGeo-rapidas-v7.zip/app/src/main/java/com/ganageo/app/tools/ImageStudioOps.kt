package com.ganageo.app.tools

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Motor comun del estudio de imagenes.
 *
 * Todo lo que se ve en pantalla y todo lo que se escribe en el archivo final sale
 * de las mismas funciones y de las mismas matrices. La vista previa usa una copia
 * reducida y la exportacion la resolucion completa, pero la geometria siempre va
 * en valores relativos (0..1 o porcentajes), asi que el resultado guardado es el
 * mismo que el usuario estaba viendo.
 */
object ImageStudioOps {

    const val MAX_OUTPUT_EDGE = 8192
    const val MAX_OUTPUT_PIXELS = 32_000_000L

    /** Como encaja la imagen dentro del tamano pedido al cambiar dimensiones. */
    enum class FitMode(val label: String) {
        FIT("Ajustar"),
        FILL("Rellenar"),
        STRETCH("Estirar")
    }

    enum class WatermarkFont(val label: String) {
        SANS("Sans"),
        SANS_BOLD("Sans negrita"),
        SERIF("Serif"),
        MONO("Mono")
    }

    /**
     * Marca de agua. Las medidas son relativas al ancho de la imagen, por eso la
     * vista previa y el archivo exportado quedan identicos aunque tengan tamanos
     * distintos en pixeles.
     */
    data class WatermarkSpec(
        val text: String = "",
        val font: WatermarkFont = WatermarkFont.SANS_BOLD,
        val colorArgb: Int = android.graphics.Color.WHITE,
        val opacityPercent: Int = 55,
        val sizePercent: Float = 7f,
        val rotationDegrees: Float = 0f,
        val centerX: Float = 0.82f,
        val centerY: Float = 0.9f,
        val tile: Boolean = false,
        val tileSpacing: Float = 1.6f,
        val shadow: Boolean = true,
        val logoSizePercent: Float = 22f,
        val logoCenterX: Float = 0.82f,
        val logoCenterY: Float = 0.82f,
        val logoOpacityPercent: Int = 70,
        val logoRotationDegrees: Float = 0f
    )

    // ------------------------------------------------------------------
    // Ajustes de color
    // ------------------------------------------------------------------

    /**
     * Devuelve la matriz 4x5 de brillo, contraste, saturacion y filtro.
     * La misma matriz alimenta el ColorFilter de la vista previa en Compose y el
     * Paint del bitmap exportado, para que no exista diferencia entre lo que se
     * ve y lo que se guarda.
     */
    fun adjustmentMatrix(
        filter: DocumentImageFilter,
        brightness: Int,
        contrast: Float,
        saturation: Float
    ): FloatArray {
        val safeContrast = when (filter) {
            DocumentImageFilter.DOCUMENT -> max(1.28f, contrast)
            DocumentImageFilter.ENHANCE -> max(1.08f, contrast)
            else -> contrast
        }.coerceIn(0.4f, 2.2f)
        val safeBrightness = brightness.coerceIn(-100, 100).toFloat()
        val baseSaturation = when (filter) {
            DocumentImageFilter.GRAYSCALE, DocumentImageFilter.DOCUMENT -> 0f
            DocumentImageFilter.ENHANCE -> 1.18f
            else -> 1f
        }
        val sat = (baseSaturation * saturation.coerceIn(0f, 2.5f)).coerceIn(0f, 2.5f)

        val lumR = 0.213f
        val lumG = 0.715f
        val lumB = 0.072f
        val inv = 1f - sat
        val sr = inv * lumR
        val sg = inv * lumG
        val sb = inv * lumB
        val saturationMatrix = floatArrayOf(
            sr + sat, sg, sb, 0f, 0f,
            sr, sg + sat, sb, 0f, 0f,
            sr, sg, sb + sat, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )

        val translate = (-0.5f * safeContrast + 0.5f) * 255f + safeBrightness
        val contrastMatrix = floatArrayOf(
            safeContrast, 0f, 0f, 0f, translate,
            0f, safeContrast, 0f, 0f, translate,
            0f, 0f, safeContrast, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        )

        return concatMatrix(contrastMatrix, saturationMatrix)
    }

    fun isNeutralAdjustment(
        filter: DocumentImageFilter,
        brightness: Int,
        contrast: Float,
        saturation: Float
    ): Boolean = filter == DocumentImageFilter.ORIGINAL &&
        brightness == 0 &&
        abs(contrast - 1f) < 0.001f &&
        abs(saturation - 1f) < 0.001f

    /** Aplica primero [second] y despues [first], igual que ColorMatrix.setConcat. */
    private fun concatMatrix(first: FloatArray, second: FloatArray): FloatArray {
        val out = FloatArray(20)
        var index = 0
        for (row in 0 until 4) {
            for (col in 0 until 5) {
                var sum = 0f
                for (k in 0 until 4) {
                    sum += first[row * 5 + k] * second[k * 5 + col]
                }
                if (col == 4) sum += first[row * 5 + 4]
                out[index++] = sum
            }
        }
        return out
    }

    fun applyAdjustments(source: Bitmap, matrix: FloatArray): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(android.graphics.ColorMatrix(matrix))
        }
        Canvas(result).drawBitmap(source, 0f, 0f, paint)
        return result
    }

    // ------------------------------------------------------------------
    // Geometria
    // ------------------------------------------------------------------

    /** Lee el tamano real del archivo sin decodificar los pixeles. */
    fun sourceBounds(context: Context, uri: Uri): Pair<Int, Int> {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        }
        return max(1, options.outWidth) to max(1, options.outHeight)
    }

    /**
     * Rectangulo mas grande sin bordes vacios que cabe dentro de una imagen
     * girada. Es lo que permite enderezar una foto sin que aparezcan esquinas
     * negras: en vez de agrandar el lienzo se recorta lo justo.
     */
    fun straightenedSize(width: Float, height: Float, degrees: Float): Pair<Float, Float> {
        if (width <= 0f || height <= 0f) return width to height
        val angle = Math.toRadians(abs(degrees.toDouble()) % 180.0)
        val normalized = if (angle > Math.PI / 2) Math.PI - angle else angle
        val sinA = abs(sin(normalized))
        val cosA = abs(cos(normalized))
        if (sinA < 1e-6) return width to height

        val widthIsLonger = width >= height
        val longSide = if (widthIsLonger) width.toDouble() else height.toDouble()
        val shortSide = if (widthIsLonger) height.toDouble() else width.toDouble()

        return if (shortSide <= 2.0 * sinA * cosA * longSide || abs(sinA - cosA) < 1e-10) {
            val half = 0.5 * shortSide
            val a = (half / sinA).toFloat()
            val b = (half / cosA).toFloat()
            if (widthIsLonger) a to b else b to a
        } else {
            val cos2a = cosA * cosA - sinA * sinA
            val w = ((width * cosA - height * sinA) / cos2a).toFloat()
            val h = ((height * cosA - width * sinA) / cos2a).toFloat()
            max(1f, w) to max(1f, h)
        }
    }

    /** Gira 90/180/270 y voltea. No pierde pixeles. */
    fun quarterTurnAndFlip(source: Bitmap, quarterDegrees: Int, flipH: Boolean, flipV: Boolean): Bitmap {
        val normalized = ((quarterDegrees % 360) + 360) % 360
        if (normalized == 0 && !flipH && !flipV) return source
        val matrix = Matrix().apply {
            postScale(if (flipH) -1f else 1f, if (flipV) -1f else 1f)
            postRotate(normalized.toFloat())
        }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    /** Endereza un angulo fino recortando al rectangulo util, sin esquinas vacias. */
    fun straighten(source: Bitmap, degrees: Float): Bitmap {
        if (abs(degrees) < 0.05f) return source
        val (targetW, targetH) = straightenedSize(source.width.toFloat(), source.height.toFloat(), degrees)
        val outW = max(1, targetW.roundToInt())
        val outH = max(1, targetH.roundToInt())
        val result = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.translate(outW / 2f, outH / 2f)
        canvas.rotate(degrees)
        canvas.translate(-source.width / 2f, -source.height / 2f)
        canvas.drawBitmap(source, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return result
    }

    /** Recorte con rectangulo normalizado 0..1. */
    fun crop(source: Bitmap, left: Float, top: Float, right: Float, bottom: Float): Bitmap {
        val l = left.coerceIn(0f, 1f)
        val t = top.coerceIn(0f, 1f)
        val r = right.coerceIn(0f, 1f)
        val b = bottom.coerceIn(0f, 1f)
        if (l >= r || t >= b) return source
        val x = (l * source.width).roundToInt().coerceIn(0, source.width - 1)
        val y = (t * source.height).roundToInt().coerceIn(0, source.height - 1)
        val w = ((r - l) * source.width).roundToInt().coerceIn(1, source.width - x)
        val h = ((b - t) * source.height).roundToInt().coerceIn(1, source.height - y)
        if (x == 0 && y == 0 && w == source.width && h == source.height) return source
        return Bitmap.createBitmap(source, x, y, w, h)
    }

    /**
     * Cambia el tamano respetando el modo elegido.
     * FIT no deforma y devuelve el mayor tamano que cabe dentro de la medida.
     * FILL rellena la medida exacta recortando el sobrante.
     * STRETCH usa la medida exacta aunque deforme.
     */
    fun resizeTo(
        source: Bitmap,
        width: Int,
        height: Int,
        mode: FitMode,
        backgroundColor: Int = android.graphics.Color.WHITE
    ): Bitmap {
        require(width > 0 && height > 0) { "Las medidas deben ser mayores que cero." }
        require(width <= MAX_OUTPUT_EDGE && height <= MAX_OUTPUT_EDGE) {
            "El maximo por lado es $MAX_OUTPUT_EDGE px."
        }
        require(width.toLong() * height.toLong() <= MAX_OUTPUT_PIXELS) {
            "La imagen resultante supera el limite seguro de 32 megapixeles."
        }
        if (source.width == width && source.height == height) return source

        return when (mode) {
            FitMode.STRETCH -> Bitmap.createScaledBitmap(source, width, height, true)
            FitMode.FIT -> {
                val scale = min(width.toFloat() / source.width, height.toFloat() / source.height)
                val w = max(1, (source.width * scale).roundToInt())
                val h = max(1, (source.height * scale).roundToInt())
                Bitmap.createScaledBitmap(source, w, h, true)
            }
            FitMode.FILL -> {
                val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(result)
                canvas.drawColor(backgroundColor)
                val scale = max(width.toFloat() / source.width, height.toFloat() / source.height)
                val drawW = source.width * scale
                val drawH = source.height * scale
                val destination = RectF(
                    (width - drawW) / 2f,
                    (height - drawH) / 2f,
                    (width + drawW) / 2f,
                    (height + drawH) / 2f
                )
                canvas.drawBitmap(
                    source,
                    Rect(0, 0, source.width, source.height),
                    destination,
                    Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                )
                result
            }
        }
    }

    fun resizeByPercent(source: Bitmap, percent: Float): Bitmap {
        val safe = percent.coerceIn(5f, 400f)
        val w = max(1, (source.width * safe / 100f).roundToInt())
        val h = max(1, (source.height * safe / 100f).roundToInt())
        return resizeTo(source, w, h, FitMode.STRETCH)
    }

    /** Quita el canal alfa pintando el fondo elegido. Necesario al pasar PNG a JPG. */
    fun flattenOn(source: Bitmap, backgroundColor: Int): Bitmap {
        if (!source.hasAlpha()) return source
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(backgroundColor)
        canvas.drawBitmap(source, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return result
    }

    // ------------------------------------------------------------------
    // Marca de agua
    // ------------------------------------------------------------------

    private fun typefaceFor(font: WatermarkFont): Typeface = when (font) {
        WatermarkFont.SANS -> Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        WatermarkFont.SANS_BOLD -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        WatermarkFont.SERIF -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
        WatermarkFont.MONO -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }

    /**
     * Dibuja la marca de agua sobre cualquier lienzo del tamano indicado.
     *
     * Es la unica funcion de dibujo: la vista previa la llama sobre el lienzo de
     * Compose y la exportacion sobre el bitmap final. Por eso lo que se arrastra
     * en pantalla queda exactamente igual en el archivo.
     */
    fun drawWatermark(
        canvas: Canvas,
        width: Int,
        height: Int,
        spec: WatermarkSpec,
        logo: Bitmap?
    ) {
        if (width <= 0 || height <= 0) return

        if (logo != null && !logo.isRecycled) {
            val logoWidth = width * (spec.logoSizePercent.coerceIn(3f, 100f) / 100f)
            val logoHeight = logoWidth * logo.height / max(1, logo.width)
            val cx = spec.logoCenterX.coerceIn(0f, 1f) * width
            val cy = spec.logoCenterY.coerceIn(0f, 1f) * height
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = (255 * spec.logoOpacityPercent.coerceIn(5, 100) / 100f).roundToInt()
            }
            canvas.save()
            canvas.translate(cx, cy)
            canvas.rotate(spec.logoRotationDegrees)
            val destination = RectF(-logoWidth / 2f, -logoHeight / 2f, logoWidth / 2f, logoHeight / 2f)
            canvas.drawBitmap(logo, Rect(0, 0, logo.width, logo.height), destination, paint)
            canvas.restore()
        }

        val text = spec.text.trim()
        if (text.isEmpty()) return

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = spec.colorArgb
            alpha = (255 * spec.opacityPercent.coerceIn(5, 100) / 100f).roundToInt()
            textSize = max(8f, width * spec.sizePercent.coerceIn(1f, 40f) / 100f)
            typeface = typefaceFor(spec.font)
        }
        if (spec.shadow) {
            val shadowColor = if (isLightColor(spec.colorArgb)) {
                android.graphics.Color.argb(140, 0, 0, 0)
            } else {
                android.graphics.Color.argb(140, 255, 255, 255)
            }
            paint.setShadowLayer(paint.textSize * 0.08f + 2f, 0f, paint.textSize * 0.04f, shadowColor)
        }

        val textWidth = paint.measureText(text)
        val metrics = paint.fontMetrics
        val textHeight = metrics.descent - metrics.ascent
        val baselineOffset = -metrics.ascent - textHeight / 2f

        if (spec.tile) {
            val stepX = max(textWidth * spec.tileSpacing.coerceIn(1.05f, 4f), 24f)
            val stepY = max(textHeight * spec.tileSpacing.coerceIn(1.05f, 4f), 24f)
            canvas.save()
            canvas.rotate(spec.rotationDegrees, width / 2f, height / 2f)
            val reach = max(width, height).toFloat()
            var y = -reach
            var row = 0
            while (y < height + reach) {
                val offsetX = if (row % 2 == 0) 0f else stepX / 2f
                var x = -reach + offsetX
                while (x < width + reach) {
                    canvas.drawText(text, x, y + baselineOffset, paint)
                    x += stepX
                }
                y += stepY
                row++
            }
            canvas.restore()
            return
        }

        val cx = spec.centerX.coerceIn(0f, 1f) * width
        val cy = spec.centerY.coerceIn(0f, 1f) * height
        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(spec.rotationDegrees)
        canvas.drawText(text, -textWidth / 2f, baselineOffset, paint)
        canvas.restore()
    }

    fun applyWatermark(source: Bitmap, spec: WatermarkSpec, logo: Bitmap?): Bitmap {
        if (spec.text.isBlank() && logo == null) return source
        val result = source.copy(Bitmap.Config.ARGB_8888, true)
        drawWatermark(Canvas(result), result.width, result.height, spec, logo)
        return result
    }

    private fun isLightColor(color: Int): Boolean {
        val r = android.graphics.Color.red(color)
        val g = android.graphics.Color.green(color)
        val b = android.graphics.Color.blue(color)
        return (0.299 * r + 0.587 * g + 0.114 * b) > 140
    }

    // ------------------------------------------------------------------
    // Compresion y guardado
    // ------------------------------------------------------------------

    fun encodedBytes(bitmap: Bitmap, format: Bitmap.CompressFormat, quality: Int): Long =
        ByteArrayOutputStream().use { out ->
            bitmap.compress(format, quality.coerceIn(1, 100), out)
            out.size().toLong()
        }

    /**
     * Peso aproximado del archivo final. Se comprime la copia de vista previa y
     * se escala por la cantidad de pixeles reales, que es mucho mas rapido que
     * comprimir la imagen completa en cada movimiento del deslizador.
     */
    fun estimateBytes(
        previewBitmap: Bitmap,
        format: Bitmap.CompressFormat,
        quality: Int,
        outputWidth: Int,
        outputHeight: Int
    ): Long {
        val previewPixels = previewBitmap.width.toLong() * previewBitmap.height.toLong()
        if (previewPixels <= 0L) return 0L
        val outputPixels = outputWidth.toLong() * outputHeight.toLong()
        val base = encodedBytes(previewBitmap, format, quality)
        val ratio = outputPixels.toDouble() / previewPixels.toDouble()
        return (base * ratio).toLong().coerceAtLeast(1L)
    }

    /** Busca por biseccion la calidad que deja el archivo bajo el peso pedido. */
    fun qualityForTargetBytes(
        bitmap: Bitmap,
        format: Bitmap.CompressFormat,
        targetBytes: Long
    ): Int {
        if (targetBytes <= 0L) return 90
        var low = 5
        var high = 98
        var best = 5
        repeat(8) {
            if (low > high) return@repeat
            val mid = (low + high) / 2
            val size = encodedBytes(bitmap, format, mid)
            if (size <= targetBytes) {
                best = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return best
    }

    fun mimeFor(format: Bitmap.CompressFormat): String = when (format) {
        Bitmap.CompressFormat.PNG -> "image/png"
        Bitmap.CompressFormat.JPEG -> "image/jpeg"
        else -> "image/webp"
    }

    fun extensionFor(format: Bitmap.CompressFormat): String = when (format) {
        Bitmap.CompressFormat.PNG -> "png"
        Bitmap.CompressFormat.JPEG -> "jpg"
        else -> "webp"
    }

    /** En Android 10 o superior se puede escribir en la galeria sin pedir permisos. */
    fun canSaveToGallery(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    /**
     * Guarda en Imagenes/GanaGeo. Nunca toca el archivo original: crea uno nuevo,
     * igual que hacen las apps de redimension conocidas.
     */
    suspend fun saveToGallery(
        context: Context,
        bitmap: Bitmap,
        displayName: String,
        format: Bitmap.CompressFormat,
        quality: Int
    ): Uri = withContext(Dispatchers.IO) {
        check(canSaveToGallery()) { "Esta version de Android necesita elegir la carpeta a mano." }
        val resolver = context.contentResolver
        val modern = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Images.Media.MIME_TYPE, mimeFor(format))
            if (modern) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GanaGeo")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val collection = if (modern) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        val uri = resolver.insert(collection, values) ?: error("No se pudo crear el archivo.")
        try {
            resolver.openOutputStream(uri, "w")?.use { stream ->
                check(bitmap.compress(format, quality.coerceIn(1, 100), stream)) {
                    "No se pudo escribir la imagen."
                }
            } ?: error("No se pudo abrir el archivo de destino.")
            if (modern) {
                val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            }
        } catch (error: Throwable) {
            runCatching { resolver.delete(uri, null, null) }
            throw error
        }
        uri
    }

    /** Copia temporal para compartir por WhatsApp, correo u otra app. */
    suspend fun writeShareCopy(
        context: Context,
        bitmap: Bitmap,
        displayName: String,
        format: Bitmap.CompressFormat,
        quality: Int
    ): Uri = withContext(Dispatchers.IO) {
        val directory = File(context.cacheDir, "shared").apply { mkdirs() }
        directory.listFiles()?.forEach { file ->
            if (System.currentTimeMillis() - file.lastModified() > 6 * 60 * 60 * 1000L) file.delete()
        }
        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val file = File(directory, "${System.currentTimeMillis()}_$safeName")
        FileOutputStream(file).use { stream ->
            check(bitmap.compress(format, quality.coerceIn(1, 100), stream)) {
                "No se pudo preparar la imagen para compartir."
            }
        }
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun timestampedName(prefix: String, format: Bitmap.CompressFormat): String {
        val stamp = android.text.format.DateFormat.format("yyyyMMdd_HHmmss", System.currentTimeMillis())
        return "${prefix}_$stamp.${extensionFor(format)}"
    }

    fun readableSize(bytes: Long): String = when {
        bytes <= 0L -> "—"
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> String.format("%.0f KB", bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L -> String.format("%.2f MB", bytes / (1024.0 * 1024.0))
        else -> String.format("%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    }
}
