package com.ganageo.app.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ganageo.app.tools.CalculatorEngine
import com.ganageo.app.tools.MeasureUnit
import com.ganageo.app.tools.UnitLab

// ---------------------------------------------------------------------------
// Calculadora científica
// ---------------------------------------------------------------------------

private enum class KeyAction { INSERT, EQUALS, CLEAR, BACKSPACE, ANSWER, MEMORY_ADD, MEMORY_READ, MEMORY_CLEAR, ANGLE }

private data class CalcKey(
    val label: String,
    val insert: String = "",
    val action: KeyAction = KeyAction.INSERT,
    val accent: Boolean = false
)

/**
 * Calculadora científica.
 *
 * Funciona como las Casio de colegio: escribes la expresión completa y ves el
 * resultado al pulsar igual, respetando la jerarquía de operaciones. El
 * porcentaje se interpreta como en las calculadoras de mostrador, donde
 * «50 + 10 %» da 55, que es lo que espera quien calcula un recargo.
 */
@Composable
fun ScientificCalculatorScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var expression by rememberSaveable { mutableStateOf("") }
    var result by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var degrees by rememberSaveable { mutableStateOf(true) }
    var memory by rememberSaveable { mutableStateOf(0.0) }
    var lastAnswer by rememberSaveable { mutableStateOf(0.0) }
    var layer by rememberSaveable { mutableIntStateOf(0) }
    var engineering by rememberSaveable { mutableStateOf(false) }
    val history = remember { mutableStateListOf<Pair<String, String>>() }

    fun compute() {
        val outcome = CalculatorEngine.evaluate(expression.replace("ANS", lastAnswer.toString()), degrees)
        outcome
            .onSuccess { value ->
                lastAnswer = value
                result = CalculatorEngine.format(value, engineering)
                error = null
                history.add(0, expression to result)
                if (history.size > 30) history.removeAt(history.lastIndex)
            }
            .onFailure {
                result = ""
                error = it.message ?: "No se pudo calcular."
            }
    }

    fun press(key: CalcKey) {
        when (key.action) {
            KeyAction.INSERT -> {
                expression += key.insert
                error = null
            }
            KeyAction.EQUALS -> compute()
            KeyAction.CLEAR -> {
                expression = ""
                result = ""
                error = null
            }
            KeyAction.BACKSPACE -> {
                if (expression.isNotEmpty()) expression = expression.dropLast(1)
                error = null
            }
            KeyAction.ANSWER -> expression += "ANS"
            KeyAction.MEMORY_ADD -> {
                val value = result.takeIf { it.isNotBlank() }?.let { lastAnswer }
                if (value != null) memory += value
            }
            KeyAction.MEMORY_READ -> expression += CalculatorEngine.format(memory)
            KeyAction.MEMORY_CLEAR -> memory = 0.0
            KeyAction.ANGLE -> degrees = !degrees
        }
    }

    val layers: List<List<List<CalcKey>>> = listOf(
        // Básico
        listOf(
            listOf(
                CalcKey("AC", action = KeyAction.CLEAR),
                CalcKey("( ", "("),
                CalcKey(" )", ")"),
                CalcKey("÷", "/"),
                CalcKey("⌫", action = KeyAction.BACKSPACE)
            ),
            listOf(
                CalcKey("7", "7"), CalcKey("8", "8"), CalcKey("9", "9"),
                CalcKey("×", "*"), CalcKey("%", "%")
            ),
            listOf(
                CalcKey("4", "4"), CalcKey("5", "5"), CalcKey("6", "6"),
                CalcKey("−", "-"), CalcKey("x²", "^2")
            ),
            listOf(
                CalcKey("1", "1"), CalcKey("2", "2"), CalcKey("3", "3"),
                CalcKey("+", "+"), CalcKey("√", "sqrt(")
            ),
            listOf(
                CalcKey("0", "0"), CalcKey(".", "."), CalcKey("ANS", action = KeyAction.ANSWER),
                CalcKey("=", action = KeyAction.EQUALS, accent = true), CalcKey("π", "pi")
            )
        ),
        // Funciones
        listOf(
            listOf(
                CalcKey("xʸ", "^"), CalcKey("ⁿ√", "raiz("), CalcKey("∛", "cbrt("),
                CalcKey("1/x", "1/("), CalcKey("|x|", "abs(")
            ),
            listOf(
                CalcKey("ln", "ln("), CalcKey("log", "log("), CalcKey("log₂", "log2("),
                CalcKey("eˣ", "exp("), CalcKey("e", "e")
            ),
            listOf(
                CalcKey("n!", "!"), CalcKey("mín", "min("), CalcKey("máx", "max("),
                CalcKey("redondear", "round("), CalcKey("signo", "sign(")
            ),
            listOf(
                CalcKey("M+", action = KeyAction.MEMORY_ADD), CalcKey("MR", action = KeyAction.MEMORY_READ),
                CalcKey("MC", action = KeyAction.MEMORY_CLEAR), CalcKey("⌫", action = KeyAction.BACKSPACE),
                CalcKey("=", action = KeyAction.EQUALS, accent = true)
            )
        ),
        // Trigonometría
        listOf(
            listOf(
                CalcKey("sin", "sin("), CalcKey("cos", "cos("), CalcKey("tan", "tan("),
                CalcKey("(", "("), CalcKey(")", ")")
            ),
            listOf(
                CalcKey("sin⁻¹", "asin("), CalcKey("cos⁻¹", "acos("), CalcKey("tan⁻¹", "atan("),
                CalcKey("π", "pi"), CalcKey("⌫", action = KeyAction.BACKSPACE)
            ),
            listOf(
                CalcKey("sinh", "sinh("), CalcKey("cosh", "cosh("), CalcKey("tanh", "tanh("),
                CalcKey(if (degrees) "DEG" else "RAD", action = KeyAction.ANGLE),
                CalcKey("=", action = KeyAction.EQUALS, accent = true)
            )
        )
    )

    ScienceStage(
        title = "Calculadora científica",
        subtitle = if (degrees) "Grados · memoria ${CalculatorEngine.format(memory)}" else "Radianes · memoria ${CalculatorEngine.format(memory)}",
        onBack = onBack,
        trailing = {
            IconButton(onClick = {
                copyToClipboard(context, "Resultado", result.ifBlank { expression })
            }) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = "Copiar", tint = StudioTheme.TextPrimary)
            }
        },
        stage = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    StudioChip(
                        label = if (degrees) "DEG" else "RAD",
                        active = true,
                        onClick = { degrees = !degrees }
                    )
                    Spacer(Modifier.size(8.dp))
                    StudioChip(
                        label = if (engineering) "ENG" else "NORM",
                        active = engineering,
                        onClick = { engineering = !engineering }
                    )
                    Spacer(Modifier.weight(1f))
                    if (memory != 0.0) {
                        StudioChip("M", true, onClick = { memory = 0.0 })
                    }
                }

                if (history.isNotEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .verticalScroll(rememberScrollState())
                    ) {
                        history.take(6).reversed().forEach { (past, value) ->
                            Text(
                                "$past = $value",
                                color = StudioTheme.TextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                textAlign = TextAlign.End,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { expression = past }
                                    .padding(vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    expression.ifBlank { "0" },
                    color = StudioTheme.TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 26.sp,
                    lineHeight = 32.sp,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
                if (result.isNotBlank()) {
                    Text(
                        "= $result",
                        color = StudioTheme.Accent,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 34.sp,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                    CalculatorEngine.toFraction(lastAnswer)?.let { fraction ->
                        Text(
                            "= $fraction",
                            color = StudioTheme.TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 14.sp,
                            textAlign = TextAlign.End,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                error?.let {
                    Text(
                        it,
                        color = Color(0xFFFF8A80),
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    )
                }
            }
        },
        panel = {
            StudioTabs(listOf("Básico", "Funciones", "Trigonometría"), layer) { layer = it }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                layers[layer].forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        row.forEach { key ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        when {
                                            key.accent -> StudioTheme.Accent
                                            key.action != KeyAction.INSERT -> StudioTheme.Surface
                                            else -> StudioTheme.SurfaceHigh
                                        }
                                    )
                                    .clickable { press(key) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    key.label,
                                    color = if (key.accent) StudioTheme.OnAccent else StudioTheme.TextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    )
}

// ---------------------------------------------------------------------------
// Conversor de unidades
// ---------------------------------------------------------------------------

/**
 * Conversor de unidades.
 *
 * Todos los valores pasan por una unidad base interna, así no se acumulan
 * errores de redondeo al encadenar conversiones. Los factores son los oficiales:
 * la pulgada mide exactamente 25,4 mm y la libra exactamente 0,45359237 kg.
 */
@Composable
fun UnitConverterScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var categoryIndex by rememberSaveable { mutableIntStateOf(0) }
    var fromIndex by rememberSaveable { mutableIntStateOf(0) }
    var toIndex by rememberSaveable { mutableIntStateOf(1) }
    var input by rememberSaveable { mutableStateOf("1") }
    var difference by rememberSaveable { mutableStateOf(false) }

    val category = UnitLab.categories[categoryIndex.coerceIn(0, UnitLab.categories.lastIndex)]
    val from: MeasureUnit = category.units.getOrElse(fromIndex) { category.units.first() }
    val to: MeasureUnit = category.units.getOrElse(toIndex) { category.units.last() }
    val isTemperature = category.name == "Temperatura"

    val value = input.replace(',', '.').toDoubleOrNull()
    val converted = value?.let {
        if (isTemperature && difference) UnitLab.convertDifference(it, from, to)
        else UnitLab.convert(it, from, to)
    }

    ScienceShell(
        title = "Conversor de unidades",
        subtitle = "${category.name} · ${from.symbol} → ${to.symbol}",
        onBack = onBack,
        trailing = {
            IconButton(onClick = {
                val temp = fromIndex
                fromIndex = toIndex
                toIndex = temp
            }) {
                Icon(Icons.Rounded.SwapVert, contentDescription = "Invertir", tint = StudioTheme.TextPrimary)
            }
        }
    ) {
        ScienceCard("Magnitud") {
            StudioChipRow {
                UnitLab.categories.forEachIndexed { index, entry ->
                    StudioChip(
                        label = entry.name,
                        active = categoryIndex == index,
                        onClick = {
                            categoryIndex = index
                            fromIndex = 0
                            toIndex = 1
                            difference = false
                        }
                    )
                }
            }
        }

        ScienceCard("Valor") {
            ScienceNumberField(input, { input = it }, "Cantidad", Modifier.fillMaxWidth())
            SimpleDropdown(
                label = "De",
                options = category.units.map { "${it.name} (${it.symbol})" },
                selectedIndex = fromIndex
            ) { fromIndex = it }
            SimpleDropdown(
                label = "A",
                options = category.units.map { "${it.name} (${it.symbol})" },
                selectedIndex = toIndex
            ) { toIndex = it }
            if (isTemperature) {
                StudioChipRow {
                    StudioChip("Valor de temperatura", !difference, onClick = { difference = false })
                    StudioChip("Diferencia (Δ)", difference, onClick = { difference = true })
                }
                StudioHint(
                    if (difference)
                        "En una diferencia no se aplica el desfase: 5 °C de diferencia son 9 °F de diferencia."
                    else
                        "Las escalas no comparten el cero, por eso la conversión no es una simple multiplicación."
                )
            }
        }

        if (converted == null) {
            ScienceError("Escribe una cantidad válida.")
        } else {
            ScienceResult(
                headline = "${UnitLab.format(converted)} ${to.symbol}",
                caption = "${UnitLab.format(value!!)} ${from.symbol} equivalen a eso",
                onCopy = { copyToClipboard(context, "Conversión", UnitLab.format(converted)) }
            )

            ScienceCard("Equivalencias frecuentes") {
                category.units.filter { it != from }.take(8).forEach { unit ->
                    val other = if (isTemperature && difference) UnitLab.convertDifference(value, from, unit)
                    else UnitLab.convert(value, from, unit)
                    MoneyRow(unit.name, "${UnitLab.format(other)} ${unit.symbol}")
                }
            }
        }

        val notes = listOfNotNull(
            from.note.takeIf { it.isNotBlank() }?.let { "${from.name}: $it" },
            to.note.takeIf { it.isNotBlank() }?.let { "${to.name}: $it" }
        )
        if (notes.isNotEmpty()) {
            ScienceCard("Sobre estas unidades") {
                notes.forEach { StudioHint(it) }
            }
        }

        UnitLab.regionalWarning(from, to)?.let { warning ->
            LegalNote("Medida tradicional: $warning. Verifica el valor que se usa en tu zona.")
        }

        if (category.name == "Datos digitales") {
            ScienceCard("Por qué tu disco de 1 TB muestra 931 GB") {
                StudioHint(
                    "El fabricante vende 1 TB = 1 000 000 000 000 bytes, en sistema decimal. " +
                        "Windows divide entre 1024 tres veces y lo llama «GB», pero en realidad son GiB. " +
                        "El disco no perdió nada: son dos formas de contar lo mismo."
                )
            }
        }
    }
}
