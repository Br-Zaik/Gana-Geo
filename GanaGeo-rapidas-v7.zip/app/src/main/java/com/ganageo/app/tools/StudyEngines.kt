package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.random.Random

// ---------------------------------------------------------------------------
// Repetición espaciada (SM-2)
// ---------------------------------------------------------------------------

data class CardSchedule(
    val easeFactor: Double = Sm2Scheduler.INITIAL_EASE,
    val intervalDays: Int = 0,
    val repetitions: Int = 0,
    val lapses: Int = 0,
    val dueAt: Long = 0L,
    val lastReviewedAt: Long = 0L
)

/**
 * Algoritmo SM-2 de SuperMemo, el mismo que popularizó Anki.
 *
 * La idea es simple: cada tarjeta guarda un factor de facilidad que sube cuando
 * la recuerdas sin esfuerzo y baja cuando te cuesta. El intervalo hasta el
 * siguiente repaso se multiplica por ese factor, así que lo que dominas
 * reaparece cada vez menos y lo difícil vuelve pronto.
 */
object Sm2Scheduler {

    const val INITIAL_EASE = 2.5
    const val MIN_EASE = 1.3
    const val FIRST_INTERVAL = 1
    const val SECOND_INTERVAL = 6
    const val LEECH_THRESHOLD = 8
    const val MAX_INTERVAL_DAYS = 365 * 5
    private const val DAY_MILLIS = 86_400_000L

    /** Los cuatro botones de la práctica traducidos a la escala 0-5 de SM-2. */
    enum class Answer(val label: String, val quality: Int, val hint: String) {
        AGAIN("Otra vez", 1, "No la recordaste: vuelve hoy mismo."),
        HARD("Difícil", 3, "La sacaste con esfuerzo."),
        GOOD("Bien", 4, "La recordaste con una pausa normal."),
        EASY("Fácil", 5, "Salió al instante.")
    }

    /**
     * Calcula el nuevo estado de la tarjeta.
     *
     * Con calidad menor que 3 la tarjeta se reinicia y vuelve al día siguiente,
     * pero el factor de facilidad nunca baja de 1.3: si bajara más, la tarjeta
     * quedaría atrapada repitiéndose para siempre.
     */
    fun review(
        current: CardSchedule,
        quality: Int,
        now: Long = System.currentTimeMillis(),
        applyFuzz: Boolean = true
    ): CardSchedule {
        val q = quality.coerceIn(0, 5)

        val updatedEase = (current.easeFactor + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)))
            .coerceAtLeast(MIN_EASE)

        if (q < 3) {
            // Fallo: se reinician las repeticiones y la tarjeta vuelve mañana.
            return current.copy(
                easeFactor = updatedEase,
                intervalDays = FIRST_INTERVAL,
                repetitions = 0,
                lapses = current.lapses + 1,
                dueAt = now + FIRST_INTERVAL * DAY_MILLIS,
                lastReviewedAt = now
            )
        }

        val repetitions = current.repetitions + 1
        val rawInterval = when (repetitions) {
            1 -> FIRST_INTERVAL
            2 -> SECOND_INTERVAL
            else -> ceil(current.intervalDays * updatedEase).toInt()
        }.coerceIn(1, MAX_INTERVAL_DAYS)

        val interval = if (applyFuzz) fuzz(rawInterval) else rawInterval

        return current.copy(
            easeFactor = updatedEase,
            intervalDays = interval,
            repetitions = repetitions,
            dueAt = now + interval * DAY_MILLIS,
            lastReviewedAt = now
        )
    }

    /**
     * Reparte los repasos unos días arriba o abajo.
     *
     * Sin esto, todas las tarjetas creadas el mismo día caen juntas para siempre
     * y el estudiante se encuentra con jornadas de 200 repasos de golpe.
     */
    fun fuzz(intervalDays: Int, random: Random = Random.Default): Int {
        if (intervalDays < 3) return intervalDays
        val margin = max(1, (intervalDays * 0.05).roundToInt())
        return (intervalDays + random.nextInt(-margin, margin + 1)).coerceAtLeast(1)
    }

    /** Tarjeta problemática: se falla una y otra vez y conviene reformularla. */
    fun isLeech(schedule: CardSchedule): Boolean = schedule.lapses >= LEECH_THRESHOLD

    fun isDue(schedule: CardSchedule, now: Long = System.currentTimeMillis()): Boolean =
        schedule.dueAt <= now

    fun isNew(schedule: CardSchedule): Boolean = schedule.repetitions == 0 && schedule.lastReviewedAt == 0L

    /** Tarjeta madura: intervalo de 21 días o más, el umbral clásico de Anki. */
    fun isMature(schedule: CardSchedule): Boolean = schedule.intervalDays >= 21

    fun describeNext(schedule: CardSchedule): String = when {
        schedule.intervalDays <= 0 -> "hoy"
        schedule.intervalDays == 1 -> "mañana"
        schedule.intervalDays < 30 -> "en ${schedule.intervalDays} días"
        schedule.intervalDays < 365 -> "en ${(schedule.intervalDays / 30.0).roundToInt()} meses"
        else -> "en ${(schedule.intervalDays / 365.0 * 10).roundToInt() / 10.0} años"
    }

    /** Porcentaje de aciertos sobre el total de repasos hechos. */
    fun retention(correct: Int, total: Int): Double =
        if (total <= 0) 0.0 else correct * 100.0 / total
}

// ---------------------------------------------------------------------------
// Notas, promedios y asistencia
// ---------------------------------------------------------------------------

data class GradingScale(
    val code: String,
    val label: String,
    val minimum: Double,
    val maximum: Double,
    val passing: Double,
    val decimals: Int = 1,
    val note: String = ""
)

data class GradeItem(val name: String, val score: Double, val weight: Double)

data class GradeSummary(
    val average: Double,
    val accumulatedWeight: Double,
    val passing: Boolean,
    val missingWeight: Double
)

object GradeEngine {

    val scales: List<GradingScale> = listOf(
        GradingScale("PE20", "Perú 0-20", 0.0, 20.0, 11.0, 0,
            "Nota aprobatoria 11 en educación superior. Algunos programas exigen 13 o 14."),
        GradingScale("PE20_SEC", "Perú escolar 0-20", 0.0, 20.0, 11.0, 0,
            "En secundaria se aprueba con 11."),
        GradingScale("CL7", "Chile 1-7", 1.0, 7.0, 4.0, 1, "Se aprueba con 4,0."),
        GradingScale("ES10", "España y México 0-10", 0.0, 10.0, 5.0, 1, "Se aprueba con 5."),
        GradingScale("CO5", "Colombia 0-5", 0.0, 5.0, 3.0, 1, "Se aprueba con 3,0."),
        GradingScale("US4", "GPA 4.0", 0.0, 4.0, 2.0, 2, "Escala estadounidense.")
    )

    fun scale(code: String): GradingScale = scales.firstOrNull { it.code == code } ?: scales.first()

    /** Promedio ponderado por pesos de evaluación. */
    fun weightedAverage(items: List<GradeItem>, scale: GradingScale): GradeSummary {
        val valid = items.filter { it.weight > 0 }
        val totalWeight = valid.sumOf { it.weight }
        if (totalWeight <= 0) {
            return GradeSummary(0.0, 0.0, false, 100.0)
        }
        val sum = valid.sumOf { it.score * it.weight }
        val average = sum / totalWeight
        return GradeSummary(
            average = average,
            accumulatedWeight = totalWeight,
            passing = average >= scale.passing,
            missingWeight = (100.0 - totalWeight).coerceAtLeast(0.0)
        )
    }

    /** Promedio ponderado por créditos, el que aparece en el récord académico. */
    fun creditWeightedAverage(courses: List<Pair<Double, Double>>): Double {
        val credits = courses.sumOf { it.second }
        if (credits <= 0) return 0.0
        return courses.sumOf { it.first * it.second } / credits
    }

    data class NeededScore(val value: Double, val achievable: Boolean, val message: String)

    /**
     * Qué nota hace falta en lo que queda para llegar al objetivo.
     *
     * Es la pregunta que todo estudiante se hace antes del examen final, y la
     * respuesta honesta a veces es "ya no alcanza": la app lo dice en vez de
     * mostrar un número imposible.
     */
    fun neededScore(
        done: List<GradeItem>,
        remainingWeight: Double,
        target: Double,
        scale: GradingScale
    ): NeededScore {
        if (remainingWeight <= 0) {
            return NeededScore(0.0, false, "No queda ninguna evaluación pendiente.")
        }
        val accumulated = done.sumOf { it.score * it.weight }
        val needed = (target * 100.0 - accumulated) / remainingWeight
        return when {
            needed <= scale.minimum -> NeededScore(
                scale.minimum, true,
                "Ya tienes el objetivo asegurado: con la nota mínima te alcanza."
            )
            needed > scale.maximum -> NeededScore(
                needed, false,
                "Necesitarías ${format(needed, scale)} y el máximo es ${format(scale.maximum, scale)}. " +
                    "Con lo que queda ya no da para ese objetivo."
            )
            else -> NeededScore(
                needed, true,
                "Necesitas ${format(needed, scale)} en lo que falta (${format(remainingWeight, scale)} % del curso)."
            )
        }
    }

    fun format(value: Double, scale: GradingScale): String =
        String.format("%.${scale.decimals}f", value)

    data class AttendanceStatus(
        val missedPercent: Double,
        val remainingAllowed: Int,
        val disqualified: Boolean,
        val warning: Boolean,
        val message: String
    )

    /**
     * Control de asistencia.
     *
     * En muchas universidades peruanas acumular el 30 % de inasistencias
     * inhabilita para rendir el examen final. El límite se puede cambiar porque
     * cada reglamento pone el suyo.
     */
    fun attendance(
        missedSessions: Int,
        totalSessions: Int,
        limitPercent: Double = 30.0
    ): AttendanceStatus {
        if (totalSessions <= 0) {
            return AttendanceStatus(0.0, 0, false, false, "Indica cuántas sesiones tiene el curso.")
        }
        val percent = missedSessions * 100.0 / totalSessions
        val maxMissed = kotlin.math.floor(totalSessions * limitPercent / 100.0).toInt()
        val remaining = (maxMissed - missedSessions).coerceAtLeast(0)
        val disqualified = percent >= limitPercent
        val warning = !disqualified && percent >= limitPercent * 2 / 3
        val message = when {
            disqualified -> "Llegaste al ${format1(percent)} % de inasistencias: según el reglamento habitual quedas inhabilitado."
            remaining == 0 -> "Estás al límite: una falta más y quedas inhabilitado."
            warning -> "Vas ${format1(percent)} %. Te quedan $remaining faltas antes del límite del ${format1(limitPercent)} %."
            else -> "Vas ${format1(percent)} % de inasistencias. Puedes faltar $remaining veces más."
        }
        return AttendanceStatus(percent, remaining, disqualified, warning, message)
    }

    private fun format1(value: Double) = String.format("%.1f", value)
}

// ---------------------------------------------------------------------------
// Exámenes y cuestionarios
// ---------------------------------------------------------------------------

data class QuizQuestion(
    val text: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String = ""
) {
    val isValid: Boolean get() = text.isNotBlank() && options.size >= 2 && correctIndex in options.indices
}

data class ItemAnalysis(
    val difficulty: Double,
    val discrimination: Double,
    val verdict: String,
    val advice: String
)

object QuizEngine {

    /**
     * Formato Aiken de Moodle.
     *
     * Una línea con la pregunta, cada alternativa con su letra y una línea final
     * con ANSWER seguida de la letra correcta.
     */
    fun parseAiken(raw: String): List<QuizQuestion> {
        val questions = mutableListOf<QuizQuestion>()
        var currentText: String? = null
        val options = mutableListOf<String>()

        raw.lines().map { it.trim() }.forEach { line ->
            when {
                line.isBlank() -> Unit
                line.uppercase().startsWith("ANSWER:") -> {
                    val letter = line.substringAfter(":").trim().firstOrNull()?.uppercaseChar()
                    val index = letter?.let { it - 'A' } ?: -1
                    val text = currentText
                    if (text != null && index in options.indices) {
                        questions += QuizQuestion(text, options.toList(), index)
                    }
                    currentText = null
                    options.clear()
                }
                Regex("^[A-Za-z][.)]\\s+.+").matches(line) -> {
                    options += line.substring(2).trim()
                }
                else -> {
                    if (currentText != null && options.isEmpty()) {
                        currentText = "${currentText} $line"
                    } else {
                        currentText = line
                        options.clear()
                    }
                }
            }
        }
        return questions
    }

    fun toAiken(questions: List<QuizQuestion>): String = buildString {
        questions.filter { it.isValid }.forEach { question ->
            appendLine(question.text)
            question.options.forEachIndexed { index, option ->
                appendLine("${('A' + index)}. $option")
            }
            appendLine("ANSWER: ${('A' + question.correctIndex)}")
            appendLine()
        }
    }.trim()

    /**
     * Formato GIFT de Moodle.
     * ::Título:: Enunciado {=correcta ~incorrecta ~incorrecta}
     */
    fun parseGift(raw: String): List<QuizQuestion> {
        val questions = mutableListOf<QuizQuestion>()
        val blocks = raw.split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotBlank() }
        blocks.forEach { block ->
            val body = block.substringAfter("::", block).let { text ->
                if (block.startsWith("::")) text.substringAfter("::") else text
            }.trim()
            val stem = body.substringBefore("{").trim()
            val answersPart = body.substringAfter("{", "").substringBeforeLast("}")
            if (stem.isBlank() || answersPart.isBlank()) return@forEach

            val options = mutableListOf<String>()
            var correct = -1
            Regex("[=~][^=~]*").findAll(answersPart).forEach { match ->
                val chunk = match.value
                val isCorrect = chunk.startsWith("=")
                val label = chunk.drop(1).substringBefore("#").trim()
                if (label.isNotBlank()) {
                    if (isCorrect) correct = options.size
                    options += label
                }
            }
            if (options.size >= 2 && correct >= 0) {
                questions += QuizQuestion(stem, options, correct)
            }
        }
        return questions
    }

    fun toGift(questions: List<QuizQuestion>): String = buildString {
        questions.filter { it.isValid }.forEachIndexed { index, question ->
            append("::Pregunta ${index + 1}:: ${question.text} {")
            question.options.forEachIndexed { optionIndex, option ->
                append(if (optionIndex == question.correctIndex) "=" else "~")
                append(option)
                if (optionIndex != question.options.lastIndex) append(" ")
            }
            appendLine("}")
            appendLine()
        }
    }.trim()

    fun toCsv(questions: List<QuizQuestion>): String = buildString {
        appendLine("Pregunta,Opcion1,Opcion2,Opcion3,Opcion4,Correcta,Explicacion")
        questions.filter { it.isValid }.forEach { question ->
            val cells = mutableListOf(question.text)
            repeat(4) { index -> cells += question.options.getOrElse(index) { "" } }
            cells += ('A' + question.correctIndex).toString()
            cells += question.explanation
            appendLine(cells.joinToString(",") { cell ->
                if (cell.contains(',') || cell.contains('"')) "\"${cell.replace("\"", "\"\"")}\"" else cell
            })
        }
    }.trim()

    /**
     * Puntuación con corrección por adivinación.
     * Se resta el número de errores dividido entre las alternativas menos una,
     * que es lo que estadísticamente se acierta al azar.
     */
    fun score(correct: Int, wrong: Int, optionsPerQuestion: Int, penalize: Boolean): Double {
        if (!penalize || optionsPerQuestion <= 1) return correct.toDouble()
        return (correct - wrong.toDouble() / (optionsPerQuestion - 1)).coerceAtLeast(0.0)
    }

    fun scoreOn20(rawScore: Double, totalQuestions: Int): Double =
        if (totalQuestions <= 0) 0.0 else (rawScore / totalQuestions * 20).coerceIn(0.0, 20.0)

    /** Índice de dificultad: proporción de estudiantes que acertaron. */
    fun difficultyIndex(correctAnswers: Int, totalAnswers: Int): Double =
        if (totalAnswers <= 0) 0.0 else correctAnswers.toDouble() / totalAnswers

    /**
     * Índice de discriminación: cuánto separa la pregunta a quienes dominan el
     * tema de quienes no. Se compara el tercio superior con el inferior.
     */
    fun discriminationIndex(upperCorrect: Int, lowerCorrect: Int, groupSize: Int): Double =
        if (groupSize <= 0) 0.0 else (upperCorrect - lowerCorrect).toDouble() / groupSize

    fun analyze(difficulty: Double, discrimination: Double): ItemAnalysis {
        val verdict = when {
            discrimination < 0 -> "Revisar con urgencia"
            difficulty < 0.3 -> "Muy difícil"
            difficulty > 0.9 -> "Muy fácil"
            discrimination < 0.2 -> "Discrimina poco"
            else -> "Buena pregunta"
        }
        val advice = when {
            discrimination < 0 ->
                "Los que más saben la fallan más: probablemente la clave está mal o el enunciado confunde."
            difficulty < 0.3 ->
                "Casi nadie acierta. Revisa si el tema se enseñó o si hay dos alternativas defendibles."
            difficulty > 0.9 ->
                "Casi todos aciertan. Sirve para dar confianza al inicio, pero no mide nada."
            discrimination < 0.2 ->
                "Distingue poco entre quien sabe y quien no. Mejora los distractores."
            else ->
                "Dificultad y discriminación están en rango sano."
        }
        return ItemAnalysis(difficulty, discrimination, verdict, advice)
    }

    /** Revisa la redacción de una pregunta y avisa de los errores clásicos. */
    fun reviewWriting(question: QuizQuestion): List<String> {
        val warnings = mutableListOf<String>()
        val lower = question.options.map { it.lowercase() }
        if (lower.any { it.contains("todas las anteriores") || it.contains("ninguna de las anteriores") }) {
            warnings += "Evita «todas las anteriores»: se responde por descarte y no mide conocimiento."
        }
        if (question.options.size < 3) {
            warnings += "Con menos de tres alternativas el azar pesa demasiado."
        }
        if (question.options.size > 5) {
            warnings += "Más de cinco alternativas obliga a inventar distractores poco creíbles."
        }
        val correctLength = question.options.getOrNull(question.correctIndex)?.length ?: 0
        val othersAverage = question.options.filterIndexed { index, _ -> index != question.correctIndex }
            .map { it.length }.average().takeIf { !it.isNaN() } ?: 0.0
        if (correctLength > othersAverage * 1.6 && question.options.size > 2) {
            warnings += "La alternativa correcta es bastante más larga que las demás: se nota."
        }
        if (question.text.length < 12) {
            warnings += "El enunciado es muy corto: asegúrate de que la pregunta se entienda sola."
        }
        if (question.options.distinct().size != question.options.size) {
            warnings += "Hay alternativas repetidas."
        }
        return warnings
    }

    /** Baraja preguntas y alternativas manteniendo cuál es la correcta. */
    fun shuffle(questions: List<QuizQuestion>, random: Random = Random.Default): List<QuizQuestion> =
        questions.shuffled(random).map { question ->
            val indexed = question.options.withIndex().shuffled(random)
            val newCorrect = indexed.indexOfFirst { it.index == question.correctIndex }
            question.copy(options = indexed.map { it.value }, correctIndex = newCorrect)
        }

    fun approximatelyEqual(a: Double, b: Double, tolerance: Double = 1e-9): Boolean = abs(a - b) < tolerance
}
