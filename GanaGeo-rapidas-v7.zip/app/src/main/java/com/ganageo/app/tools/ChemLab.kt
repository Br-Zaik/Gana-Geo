package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.pow

/** Fracción exacta para balancear sin errores de redondeo. */
private data class Frac(val numerator: Long, val denominator: Long = 1L) {
    init {
        require(denominator != 0L)
    }

    companion object {
        val ZERO = Frac(0L)
        val ONE = Frac(1L)
        private fun gcd(a: Long, b: Long): Long {
            var x = abs(a)
            var y = abs(b)
            while (y != 0L) {
                val t = y
                y = x % y
                x = t
            }
            return if (x == 0L) 1L else x
        }

        fun of(value: Int) = Frac(value.toLong())
    }

    fun reduced(): Frac {
        val g = gcd(numerator, denominator)
        val sign = if (denominator < 0) -1 else 1
        return Frac(sign * numerator / g, sign * denominator / g)
    }

    operator fun plus(other: Frac) =
        Frac(numerator * other.denominator + other.numerator * denominator, denominator * other.denominator).reduced()

    operator fun minus(other: Frac) =
        Frac(numerator * other.denominator - other.numerator * denominator, denominator * other.denominator).reduced()

    operator fun times(other: Frac) = Frac(numerator * other.numerator, denominator * other.denominator).reduced()

    operator fun div(other: Frac) = Frac(numerator * other.denominator, denominator * other.numerator).reduced()

    fun isZero() = numerator == 0L
}

data class FormulaAnalysis(
    val formula: String,
    val counts: Map<String, Int>,
    val molarMass: Double,
    val composition: List<Triple<String, Double, Double>>,
    val totalAtoms: Int
)

data class BalancedEquation(
    val reactants: List<Pair<Int, String>>,
    val products: List<Pair<Int, String>>,
    val steps: List<SolveStep>
) {
    val text: String
        get() = reactants.joinToString(" + ") { format(it) } + " → " + products.joinToString(" + ") { format(it) }

    private fun format(pair: Pair<Int, String>) =
        if (pair.first == 1) pair.second else "${pair.first} ${pair.second}"
}

object ChemLab {

    // ------------------------------------------------------------------
    // Fórmulas
    // ------------------------------------------------------------------

    /** Lee una fórmula con paréntesis e hidratos: Ca(OH)2, CuSO4·5H2O */
    fun parseFormula(raw: String): Map<String, Int> {
        val normalized = raw.trim()
            .replace(" ", "")
            .replace("·", "*")
            .replace("•", "*")
        require(normalized.isNotEmpty()) { "Escribe una fórmula química." }

        val total = LinkedHashMap<String, Int>()
        normalized.split("*").forEach { part ->
            if (part.isEmpty()) return@forEach
            var index = 0
            var multiplier = 1
            while (index < part.length && part[index].isDigit()) index++
            if (index > 0) {
                multiplier = part.substring(0, index).toIntOrNull() ?: 1
            }
            val counts = FormulaParser(part.substring(index)).parse()
            counts.forEach { (symbol, count) ->
                total[symbol] = (total[symbol] ?: 0) + count * multiplier
            }
        }
        require(total.isNotEmpty()) { "No se reconoció ningún elemento en «$raw»." }
        return total
    }

    fun analyze(raw: String): FormulaAnalysis {
        val counts = parseFormula(raw)
        var molarMass = 0.0
        counts.forEach { (symbol, count) ->
            val element = ElementsCatalog.bySymbol(symbol)
                ?: throw IllegalArgumentException("El símbolo «$symbol» no existe en la tabla periódica.")
            molarMass += element.mass * count
        }
        val composition = counts.map { (symbol, count) ->
            val element = ElementsCatalog.bySymbol(symbol)!!
            val mass = element.mass * count
            Triple(symbol, mass, if (molarMass > 0) mass / molarMass * 100 else 0.0)
        }.sortedByDescending { it.third }
        return FormulaAnalysis(
            formula = raw.trim(),
            counts = counts,
            molarMass = molarMass,
            composition = composition,
            totalAtoms = counts.values.sum()
        )
    }

    fun molarMass(raw: String): Double = analyze(raw).molarMass

    private class FormulaParser(private val text: String) {
        private var index = 0

        fun parse(): Map<String, Int> {
            val counts = parseGroup(false)
            require(index >= text.length) { "Sobra «${text.substring(index)}» en la fórmula." }
            return counts
        }

        private fun parseGroup(insideParenthesis: Boolean): MutableMap<String, Int> {
            val counts = LinkedHashMap<String, Int>()
            while (index < text.length) {
                val c = text[index]
                when {
                    c == '(' || c == '[' -> {
                        index++
                        val inner = parseGroup(true)
                        val multiplier = parseNumber()
                        inner.forEach { (symbol, count) ->
                            counts[symbol] = (counts[symbol] ?: 0) + count * multiplier
                        }
                    }
                    c == ')' || c == ']' -> {
                        require(insideParenthesis) { "Hay un paréntesis de cierre sin abrir." }
                        index++
                        return counts
                    }
                    c.isUpperCase() -> {
                        val start = index
                        index++
                        while (index < text.length && text[index].isLowerCase()) index++
                        val symbol = text.substring(start, index)
                        val count = parseNumber()
                        counts[symbol] = (counts[symbol] ?: 0) + count
                    }
                    else -> throw IllegalArgumentException("Carácter inesperado «$c» en la fórmula.")
                }
            }
            require(!insideParenthesis) { "Falta cerrar un paréntesis." }
            return counts
        }

        private fun parseNumber(): Int {
            val start = index
            while (index < text.length && text[index].isDigit()) index++
            if (start == index) return 1
            return text.substring(start, index).toIntOrNull()?.takeIf { it > 0 } ?: 1
        }
    }

    // ------------------------------------------------------------------
    // Balanceo por álgebra lineal
    // ------------------------------------------------------------------

    /**
     * Balancea una ecuación resolviendo el espacio nulo de la matriz de
     * composición con aritmética exacta de fracciones. Es el mismo método que se
     * usa en química computacional: nunca se "prueba y tantea".
     */
    fun balance(raw: String): BalancedEquation {
        val normalized = raw.replace("→", "=").replace("->", "=").replace("=>", "=")
        val sides = normalized.split("=")
        require(sides.size == 2) { "Escribe la ecuación con una flecha: H2 + O2 → H2O" }

        val reactants = sides[0].split("+").map { it.trim() }.filter { it.isNotEmpty() }
        val products = sides[1].split("+").map { it.trim() }.filter { it.isNotEmpty() }
        require(reactants.isNotEmpty() && products.isNotEmpty()) { "Faltan sustancias a un lado de la flecha." }
        val species = reactants + products
        require(species.size <= 12) { "Máximo 12 sustancias." }

        val parsed = species.map { parseFormula(it) }
        val elements = parsed.flatMap { it.keys }.distinct()

        val leftElements = parsed.take(reactants.size).flatMap { it.keys }.toSet()
        val rightElements = parsed.drop(reactants.size).flatMap { it.keys }.toSet()
        require(leftElements == rightElements) {
            val missing = (leftElements - rightElements) + (rightElements - leftElements)
            "No se puede balancear: ${missing.joinToString(", ")} aparece en un solo lado."
        }

        // Filas = elementos, columnas = sustancias. Productos con signo negativo.
        val matrix = elements.map { element ->
            Array(species.size) { column ->
                val count = parsed[column][element] ?: 0
                val signed = if (column < reactants.size) count else -count
                Frac.of(signed)
            }
        }.toMutableList()

        val coefficients = nullSpaceVector(matrix, species.size)
            ?: throw IllegalArgumentException("Esta ecuación no se puede balancear tal como está escrita.")

        val steps = listOf(
            SolveStep(
                "Contar átomos",
                elements.joinToString("\n") { element ->
                    element + ": " + species.indices.joinToString(" | ") { column ->
                        "${species[column]}=${parsed[column][element] ?: 0}"
                    }
                },
                "Se cuenta cada elemento en cada sustancia. Debe haber los mismos átomos a los dos lados."
            ),
            SolveStep(
                "Plantear el sistema",
                elements.joinToString("\n") { element ->
                    val terms = species.indices.map { column ->
                        val count = parsed[column][element] ?: 0
                        val sign = if (column < reactants.size) "+" else "−"
                        "$sign$count·x${column + 1}"
                    }
                    "$element:  ${terms.joinToString(" ")} = 0"
                },
                "Cada elemento da una ecuación. Las incógnitas son los coeficientes."
            ),
            SolveStep(
                "Resolver con fracciones exactas",
                coefficients.mapIndexed { index, value -> "x${index + 1} = $value  (${species[index]})" }
                    .joinToString("\n"),
                "Se reduce la matriz por Gauss usando fracciones y se ajusta al menor conjunto de enteros."
            ),
            SolveStep(
                "Comprobación",
                elements.joinToString("\n") { element ->
                    val left = reactants.indices.sumOf { coefficients[it] * (parsed[it][element] ?: 0) }
                    val right = products.indices.sumOf {
                        coefficients[reactants.size + it] * (parsed[reactants.size + it][element] ?: 0)
                    }
                    "$element: $left = $right"
                },
                "Los átomos de cada elemento coinciden a ambos lados."
            )
        )

        return BalancedEquation(
            reactants = reactants.mapIndexed { index, formula -> coefficients[index] to formula },
            products = products.mapIndexed { index, formula -> coefficients[reactants.size + index] to formula },
            steps = steps
        )
    }

    private fun nullSpaceVector(matrix: MutableList<Array<Frac>>, columns: Int): List<Int>? {
        val rows = matrix.size
        var pivotRow = 0
        val pivotColumns = mutableListOf<Int>()

        for (column in 0 until columns) {
            var candidate = -1
            for (row in pivotRow until rows) {
                if (!matrix[row][column].isZero()) {
                    candidate = row
                    break
                }
            }
            if (candidate == -1) continue
            val temp = matrix[pivotRow]
            matrix[pivotRow] = matrix[candidate]
            matrix[candidate] = temp

            val pivot = matrix[pivotRow][column]
            for (k in 0 until columns) matrix[pivotRow][k] = matrix[pivotRow][k] / pivot

            for (row in 0 until rows) {
                if (row == pivotRow) continue
                val factor = matrix[row][column]
                if (factor.isZero()) continue
                for (k in 0 until columns) {
                    matrix[row][k] = matrix[row][k] - factor * matrix[pivotRow][k]
                }
            }
            pivotColumns += column
            pivotRow++
            if (pivotRow == rows) break
        }

        val freeColumns = (0 until columns).filter { it !in pivotColumns }
        if (freeColumns.size != 1) return null

        val free = freeColumns.first()
        val solution = Array(columns) { Frac.ZERO }
        solution[free] = Frac.ONE
        pivotColumns.forEachIndexed { index, column ->
            solution[column] = Frac.ZERO - matrix[index][free]
        }

        // Se pasa a enteros: multiplicar por el mínimo común múltiplo de los denominadores.
        var lcm = 1L
        solution.forEach { lcm = lcmOf(lcm, it.denominator) }
        val integers = solution.map { (it.numerator * (lcm / it.denominator)) }
        var gcd = 0L
        integers.forEach { gcd = gcdOf(gcd, abs(it)) }
        if (gcd == 0L) return null
        val normalized = integers.map { (it / gcd).toInt() }
        val sign = if (normalized.first() < 0) -1 else 1
        val result = normalized.map { it * sign }
        return if (result.all { it > 0 }) result else null
    }

    private fun gcdOf(a: Long, b: Long): Long {
        var x = abs(a)
        var y = abs(b)
        while (y != 0L) {
            val t = y
            y = x % y
            x = t
        }
        return x
    }

    private fun lcmOf(a: Long, b: Long): Long {
        if (a == 0L || b == 0L) return 1L
        return abs(a / gcdOf(a, b) * b)
    }

    // ------------------------------------------------------------------
    // Estequiometría y disoluciones
    // ------------------------------------------------------------------

    fun moles(grams: Double, molarMass: Double): Double {
        require(molarMass > 0) { "La masa molar debe ser mayor que cero." }
        return grams / molarMass
    }

    fun grams(moles: Double, molarMass: Double): Double = moles * molarMass

    fun particles(moles: Double): Double = moles * 6.02214076e23

    /** A partir de una sustancia conocida calcula todas las demás de la ecuación. */
    fun stoichiometry(
        equation: BalancedEquation,
        knownFormula: String,
        knownMoles: Double
    ): List<Triple<String, Double, Double>> {
        val all = equation.reactants + equation.products
        val known = all.firstOrNull { it.second.equals(knownFormula, ignoreCase = true) }
            ?: throw IllegalArgumentException("«$knownFormula» no está en la ecuación.")
        val factor = knownMoles / known.first
        return all.map { (coefficient, formula) ->
            val mol = coefficient * factor
            Triple(formula, mol, mol * molarMass(formula))
        }
    }

    fun molarity(moles: Double, liters: Double): Double {
        require(liters > 0) { "El volumen debe ser mayor que cero." }
        return moles / liters
    }

    fun molality(moles: Double, kilogramsOfSolvent: Double): Double {
        require(kilogramsOfSolvent > 0) { "La masa del disolvente debe ser mayor que cero." }
        return moles / kilogramsOfSolvent
    }

    /** C₁V₁ = C₂V₂ */
    fun dilution(c1: Double, v1: Double, c2: Double): Double {
        require(c2 > 0) { "La concentración final debe ser mayor que cero." }
        return c1 * v1 / c2
    }

    /** PV = nRT con presión en atm, volumen en litros y temperatura en kelvin. */
    fun idealGas(pressureAtm: Double?, volumeL: Double?, moles: Double?, temperatureK: Double?): Pair<String, Double> {
        val r = 0.0820573660809596
        val missing = listOf(pressureAtm, volumeL, moles, temperatureK).count { it == null }
        require(missing == 1) { "Deja exactamente un dato en blanco para poder calcularlo." }
        return when {
            pressureAtm == null -> "Presión (atm)" to (moles!! * r * temperatureK!! / volumeL!!)
            volumeL == null -> "Volumen (L)" to (moles!! * r * temperatureK!! / pressureAtm)
            moles == null -> "Moles" to (pressureAtm * volumeL / (r * temperatureK!!))
            else -> "Temperatura (K)" to (pressureAtm * volumeL / (r * moles))
        }
    }

    data class PhResult(
        val ph: Double,
        val poh: Double,
        val hydrogen: Double,
        val hydroxide: Double,
        val nature: String
    )

    fun fromConcentration(concentration: Double, isAcid: Boolean): PhResult {
        require(concentration > 0) { "La concentración debe ser mayor que cero." }
        val ph = if (isAcid) -log10(concentration) else 14 + log10(concentration)
        return buildPh(ph)
    }

    fun fromPh(ph: Double): PhResult = buildPh(ph)

    private fun buildPh(ph: Double): PhResult {
        val poh = 14 - ph
        return PhResult(
            ph = ph,
            poh = poh,
            hydrogen = 10.0.pow(-ph),
            hydroxide = 10.0.pow(-poh),
            nature = when {
                ph < 6.9 -> "Ácida"
                ph > 7.1 -> "Básica"
                else -> "Neutra"
            }
        )
    }

    fun percentYield(real: Double, theoretical: Double): Double {
        require(theoretical > 0) { "El rendimiento teórico debe ser mayor que cero." }
        return real / theoretical * 100
    }
}
