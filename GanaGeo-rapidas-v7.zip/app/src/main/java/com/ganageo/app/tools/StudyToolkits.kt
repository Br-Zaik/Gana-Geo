package com.ganageo.app.tools

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------
// Finanzas para estudiantes
// ---------------------------------------------------------------------------

data class AmortizationRow(
    val period: Int,
    val installment: BigDecimal,
    val interest: BigDecimal,
    val principal: BigDecimal,
    val balance: BigDecimal
)

data class LoanSummary(
    val installment: BigDecimal,
    val totalPaid: BigDecimal,
    val totalInterest: BigDecimal,
    val rows: List<AmortizationRow>
)

/**
 * Calculadora financiera para estudiantes.
 *
 * Todo va en BigDecimal. En dinero, un céntimo mal redondeado repetido doce
 * veces al año es una cuota que no cuadra con la del banco.
 */
object StudentFinanceLab {

    private val mc = MathContext(16, RoundingMode.HALF_UP)

    fun simpleInterest(capital: BigDecimal, ratePercent: BigDecimal, periods: BigDecimal): BigDecimal =
        Money.round(capital.multiply(ratePercent).multiply(periods).divide(BigDecimal(100), mc))

    fun compoundAmount(capital: BigDecimal, ratePercent: BigDecimal, periods: Int): BigDecimal {
        val rate = ratePercent.divide(BigDecimal(100), mc)
        val factor = BigDecimal.ONE.add(rate).pow(periods.coerceIn(0, 1200), mc)
        return Money.round(capital.multiply(factor, mc))
    }

    fun presentValue(future: BigDecimal, ratePercent: BigDecimal, periods: Int): BigDecimal {
        val rate = ratePercent.divide(BigDecimal(100), mc)
        val factor = BigDecimal.ONE.add(rate).pow(periods.coerceIn(0, 1200), mc)
        return Money.round(future.divide(factor, mc))
    }

    /** Cuota fija del sistema francés: C = P·i / (1 − (1+i)^−n). */
    fun frenchInstallment(principal: BigDecimal, ratePercentPerPeriod: BigDecimal, periods: Int): BigDecimal {
        require(periods > 0) { "El número de cuotas debe ser mayor que cero." }
        val rate = ratePercentPerPeriod.divide(BigDecimal(100), mc)
        if (rate.compareTo(BigDecimal.ZERO) == 0) {
            return Money.round(principal.divide(BigDecimal(periods), mc))
        }
        val factor = BigDecimal.ONE.add(rate).pow(periods, mc)
        val numerator = principal.multiply(rate, mc).multiply(factor, mc)
        val denominator = factor.subtract(BigDecimal.ONE)
        return Money.round(numerator.divide(denominator, mc))
    }

    /**
     * Tabla de amortización. En el sistema francés la cuota es fija y al inicio
     * casi todo es interés; en el alemán se amortiza siempre lo mismo y la cuota
     * va bajando.
     */
    fun amortization(
        principal: BigDecimal,
        ratePercentPerPeriod: BigDecimal,
        periods: Int,
        german: Boolean = false
    ): LoanSummary {
        require(periods in 1..600) { "Usa entre 1 y 600 cuotas." }
        val rate = ratePercentPerPeriod.divide(BigDecimal(100), mc)
        val rows = mutableListOf<AmortizationRow>()
        var balance = principal
        var totalPaid = BigDecimal.ZERO
        var totalInterest = BigDecimal.ZERO
        val fixedInstallment = if (german) BigDecimal.ZERO else frenchInstallment(principal, ratePercentPerPeriod, periods)
        val fixedPrincipal = principal.divide(BigDecimal(periods), Money.WORK_SCALE, RoundingMode.HALF_UP)

        for (period in 1..periods) {
            val interest = Money.round(balance.multiply(rate, mc))
            val principalPart: BigDecimal
            val installment: BigDecimal
            if (german) {
                principalPart = if (period == periods) balance else Money.round(fixedPrincipal)
                installment = Money.round(principalPart.add(interest))
            } else {
                installment = fixedInstallment
                principalPart = if (period == periods) balance else Money.round(installment.subtract(interest))
            }
            balance = Money.round(balance.subtract(principalPart))
            if (balance.signum() < 0) balance = Money.ZERO
            totalPaid = totalPaid.add(installment)
            totalInterest = totalInterest.add(interest)
            rows += AmortizationRow(period, installment, interest, principalPart, balance)
        }
        return LoanSummary(
            installment = if (german) rows.first().installment else fixedInstallment,
            totalPaid = Money.round(totalPaid),
            totalInterest = Money.round(totalInterest),
            rows = rows
        )
    }

    /** Tasa nominal a efectiva: TEA = (1 + TNA/m)^m − 1. */
    fun nominalToEffective(nominalPercent: BigDecimal, capitalizationsPerYear: Int): BigDecimal {
        require(capitalizationsPerYear > 0) { "Indica cuántas veces al año capitaliza." }
        val nominal = nominalPercent.divide(BigDecimal(100), mc)
        val perPeriod = nominal.divide(BigDecimal(capitalizationsPerYear), mc)
        val factor = BigDecimal.ONE.add(perPeriod).pow(capitalizationsPerYear, mc)
        return factor.subtract(BigDecimal.ONE).multiply(BigDecimal(100), mc).setScale(4, RoundingMode.HALF_UP)
    }

    /**
     * Tasa efectiva anual a mensual: TEM = (1 + TEA)^(1/12) − 1.
     * Dividir la TEA entre 12 es el error más común y da una cuota más baja de
     * la real.
     */
    fun effectiveAnnualToMonthly(teaPercent: BigDecimal): BigDecimal {
        val tea = teaPercent.toDouble() / 100.0
        val tem = (1.0 + tea).pow(1.0 / 12.0) - 1.0
        return BigDecimal(tem * 100.0).setScale(6, RoundingMode.HALF_UP)
    }

    fun effectiveMonthlyToAnnual(temPercent: BigDecimal): BigDecimal {
        val tem = temPercent.toDouble() / 100.0
        val tea = (1.0 + tem).pow(12.0) - 1.0
        return BigDecimal(tea * 100.0).setScale(4, RoundingMode.HALF_UP)
    }

    /**
     * Costo total del crédito a partir de la cuota real.
     *
     * Encuentra por bisección la tasa que iguala el préstamo con el flujo de
     * cuotas. Si la cuota incluye seguros y comisiones, esta tasa es la TCEA:
     * el número que de verdad sirve para comparar créditos.
     */
    fun effectiveRateFromInstallment(
        principal: BigDecimal,
        installment: BigDecimal,
        periods: Int
    ): BigDecimal {
        require(periods > 0) { "Indica el número de cuotas." }
        val p = principal.toDouble()
        val c = installment.toDouble()
        require(p > 0 && c > 0) { "El préstamo y la cuota deben ser mayores que cero." }
        if (c * periods <= p) return BigDecimal.ZERO.setScale(4)

        fun presentValueAt(rate: Double): Double =
            if (rate == 0.0) c * periods else c * (1 - (1 + rate).pow(-periods)) / rate

        var low = 0.0
        var high = 1.0
        repeat(200) {
            val mid = (low + high) / 2
            if (presentValueAt(mid) > p) low = mid else high = mid
        }
        val monthly = (low + high) / 2
        val annual = ((1 + monthly).pow(12.0) - 1) * 100
        return BigDecimal(annual).setScale(4, RoundingMode.HALF_UP)
    }

    data class MinimumPaymentPlan(
        val months: Int,
        val totalPaid: BigDecimal,
        val totalInterest: BigDecimal,
        val warning: String
    )

    /** Cuánto cuesta pagar solo el mínimo de la tarjeta. */
    fun minimumPaymentPlan(
        balance: BigDecimal,
        monthlyRatePercent: BigDecimal,
        minimumPercent: BigDecimal,
        floorPayment: BigDecimal = BigDecimal("25")
    ): MinimumPaymentPlan {
        var current = balance
        val rate = monthlyRatePercent.divide(BigDecimal(100), mc)
        var months = 0
        var paid = BigDecimal.ZERO
        var interest = BigDecimal.ZERO
        while (current.signum() > 0 && months < 600) {
            val monthInterest = Money.round(current.multiply(rate, mc))
            val minimum = Money.round(current.multiply(minimumPercent).divide(BigDecimal(100), mc))
                .max(floorPayment)
            val payment = minimum.min(current.add(monthInterest))
            if (payment <= monthInterest) {
                return MinimumPaymentPlan(
                    months = -1,
                    totalPaid = Money.round(paid),
                    totalInterest = Money.round(interest),
                    warning = "Con ese pago mínimo la deuda nunca se termina: el interés del mes supera lo que pagas."
                )
            }
            current = Money.round(current.add(monthInterest).subtract(payment))
            paid = paid.add(payment)
            interest = interest.add(monthInterest)
            months++
        }
        return MinimumPaymentPlan(
            months = months,
            totalPaid = Money.round(paid),
            totalInterest = Money.round(interest),
            warning = "Pagando solo el mínimo tardarías $months meses y los intereses suman " +
                "${Money.format(Money.round(interest))}."
        )
    }

    data class Settlement(val from: String, val to: String, val amount: BigDecimal)

    /**
     * Liquidación de gastos compartidos.
     *
     * Se calcula el saldo de cada persona y se emparejan deudores con
     * acreedores empezando por los montos mayores, así salen pocas
     * transferencias en vez de que todos le paguen a todos.
     */
    fun settleBalances(balances: Map<String, BigDecimal>): List<Settlement> {
        val debtors = balances.filter { it.value.signum() < 0 }
            .map { it.key to it.value.abs() }
            .sortedByDescending { it.second }
            .toMutableList()
        val creditors = balances.filter { it.value.signum() > 0 }
            .map { it.key to it.value }
            .sortedByDescending { it.second }
            .toMutableList()

        val settlements = mutableListOf<Settlement>()
        var guard = 0
        while (debtors.isNotEmpty() && creditors.isNotEmpty() && guard < 500) {
            guard++
            val (debtorName, debtorAmount) = debtors.first()
            val (creditorName, creditorAmount) = creditors.first()
            val amount = Money.round(debtorAmount.min(creditorAmount))
            if (amount.signum() <= 0) break
            settlements += Settlement(debtorName, creditorName, amount)

            val debtorLeft = debtorAmount.subtract(amount)
            val creditorLeft = creditorAmount.subtract(amount)
            debtors.removeAt(0)
            creditors.removeAt(0)
            if (debtorLeft.signum() > 0) debtors.add(0, debtorName to debtorLeft)
            if (creditorLeft.signum() > 0) creditors.add(0, creditorName to creditorLeft)
            debtors.sortByDescending { it.second }
            creditors.sortByDescending { it.second }
        }
        return settlements
    }

    /** Saldo de cada persona: lo que puso menos lo que le tocaba. */
    fun balancesFrom(paid: Map<String, BigDecimal>, shares: Map<String, BigDecimal>): Map<String, BigDecimal> {
        val people = (paid.keys + shares.keys).distinct()
        return people.associateWith { person ->
            Money.round(
                (paid[person] ?: BigDecimal.ZERO).subtract(shares[person] ?: BigDecimal.ZERO)
            )
        }
    }

    /** Reparto en partes iguales de un gasto total. */
    fun equalShares(total: BigDecimal, people: List<String>): Map<String, BigDecimal> {
        if (people.isEmpty()) return emptyMap()
        val each = total.divide(BigDecimal(people.size), Money.WORK_SCALE, RoundingMode.HALF_UP)
        val rounded = people.map { Money.round(each) }
        val adjusted = Money.distributeResidue(rounded, total)
        return people.mapIndexed { index, person -> person to adjusted[index] }.toMap()
    }

    /** Regla 50/30/20 sobre el ingreso mensual. */
    fun budget503020(income: BigDecimal): Triple<BigDecimal, BigDecimal, BigDecimal> = Triple(
        Money.round(Money.percent(income, BigDecimal(50))),
        Money.round(Money.percent(income, BigDecimal(30))),
        Money.round(Money.percent(income, BigDecimal(20)))
    )
}

// ---------------------------------------------------------------------------
// Herramientas de texto
// ---------------------------------------------------------------------------

data class TextStats(
    val characters: Int,
    val charactersNoSpaces: Int,
    val words: Int,
    val sentences: Int,
    val paragraphs: Int,
    val syllables: Int,
    val readingMinutes: Double,
    val averageWordsPerSentence: Double,
    val averageSyllablesPerWord: Double
)

data class ReadabilityResult(
    val fernandezHuerta: Double,
    val szigriszt: Double,
    val level: String,
    val advice: String
)

object TextLab {

    /** Velocidad media de lectura en español, en palabras por minuto. */
    const val WORDS_PER_MINUTE = 200.0

    fun stats(text: String): TextStats {
        val trimmed = text.trim()
        val words = wordList(trimmed)
        val sentences = trimmed.split(Regex("[.!?…]+")).count { it.trim().isNotBlank() }.coerceAtLeast(if (words.isEmpty()) 0 else 1)
        val paragraphs = trimmed.split(Regex("\\n\\s*\\n")).count { it.isNotBlank() }.coerceAtLeast(if (trimmed.isBlank()) 0 else 1)
        val syllables = words.sumOf { countSyllables(it) }
        return TextStats(
            characters = text.length,
            charactersNoSpaces = text.count { !it.isWhitespace() },
            words = words.size,
            sentences = sentences,
            paragraphs = paragraphs,
            syllables = syllables,
            readingMinutes = words.size / WORDS_PER_MINUTE,
            averageWordsPerSentence = if (sentences == 0) 0.0 else words.size.toDouble() / sentences,
            averageSyllablesPerWord = if (words.isEmpty()) 0.0 else syllables.toDouble() / words.size
        )
    }

    fun wordList(text: String): List<String> =
        text.split(Regex("[^\\p{L}\\p{N}áéíóúüñÁÉÍÓÚÜÑ']+")).filter { it.isNotBlank() }

    /**
     * Cuenta sílabas en español.
     *
     * Se cuentan los grupos de vocales, restando los diptongos y triptongos.
     * No es perfecto con las palabras raras, pero para medir legibilidad de un
     * texto completo el error se diluye.
     */
    fun countSyllables(word: String): Int {
        val clean = removeAccents(word.lowercase()).filter { it.isLetter() }
        if (clean.isEmpty()) return 0
        val vowels = "aeiou"
        val strong = "aeo"
        var count = 0
        var index = 0
        while (index < clean.length) {
            if (clean[index] in vowels) {
                count++
                // Diptongo: dos vocales seguidas cuentan como una sílaba salvo
                // que las dos sean fuertes (a, e, o).
                var lookahead = index + 1
                while (lookahead < clean.length && clean[lookahead] in vowels) {
                    val previous = clean[lookahead - 1]
                    val current = clean[lookahead]
                    if (previous in strong && current in strong) {
                        break
                    }
                    lookahead++
                }
                index = lookahead
            } else {
                index++
            }
        }
        return count.coerceAtLeast(1)
    }

    /**
     * Legibilidad adaptada al español.
     *
     * Las fórmulas de Flesch en inglés no sirven en castellano porque nuestras
     * palabras tienen más sílabas de media y el texto sale artificialmente
     * difícil. Fernández Huerta y Szigriszt-Pazos corrigen esa diferencia.
     */
    fun readability(text: String): ReadabilityResult {
        val data = stats(text)
        if (data.words == 0 || data.sentences == 0) {
            return ReadabilityResult(0.0, 0.0, "—", "Escribe un texto para analizarlo.")
        }
        val syllablesPerWord = data.averageSyllablesPerWord
        val wordsPerSentence = data.averageWordsPerSentence

        val fernandez = 206.84 - 60.0 * syllablesPerWord - 1.02 * wordsPerSentence
        val szigriszt = 206.835 - 62.3 * syllablesPerWord - wordsPerSentence

        val level = when {
            szigriszt > 80 -> "Muy fácil"
            szigriszt > 65 -> "Fácil"
            szigriszt > 55 -> "Normal"
            szigriszt > 40 -> "Algo difícil"
            szigriszt > 15 -> "Difícil"
            else -> "Muy difícil"
        }
        val advice = when {
            szigriszt >= 55 -> "Se lee sin esfuerzo. Buen nivel para un trabajo dirigido a cualquier lector."
            szigriszt >= 40 ->
                "Un poco denso. Prueba a partir las frases largas: llevas " +
                    "${wordsPerSentence.roundToInt()} palabras por oración."
            else ->
                "Muy denso. Acorta oraciones y cambia palabras largas por otras más comunes."
        }
        return ReadabilityResult(
            fernandezHuerta = round2(fernandez),
            szigriszt = round2(szigriszt),
            level = level,
            advice = advice
        )
    }

    private fun round2(value: Double) = (value * 100).roundToInt() / 100.0

    fun removeAccents(text: String): String =
        Normalizer.normalize(text, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace('ñ', 'n')
            .replace('Ñ', 'N')

    fun normalizeSpaces(text: String): String =
        text.replace(Regex("[ \\t]+"), " ")
            .replace(Regex(" ?\\n ?"), "\n")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()

    fun toSentenceCase(text: String): String {
        val lower = text.lowercase()
        val builder = StringBuilder(lower)
        var capitalizeNext = true
        for (index in builder.indices) {
            val char = builder[index]
            if (capitalizeNext && char.isLetter()) {
                builder[index] = char.uppercaseChar()
                capitalizeNext = false
            }
            if (char == '.' || char == '!' || char == '?' || char == '\n') capitalizeNext = true
        }
        return builder.toString()
    }

    fun toTitleCase(text: String): String {
        val minorWords = setOf("de", "del", "la", "las", "los", "el", "y", "e", "o", "u", "en", "a", "con", "por", "para")
        return text.lowercase().split(" ").mapIndexed { index, word ->
            if (word.isBlank()) word
            else if (index > 0 && word in minorWords) word
            else word.replaceFirstChar { it.uppercaseChar() }
        }.joinToString(" ")
    }

    fun sortLines(text: String, descending: Boolean = false): String {
        val lines = text.lines().filter { it.isNotBlank() }
        val sorted = if (descending) lines.sortedByDescending { it.trim().lowercase() }
        else lines.sortedBy { it.trim().lowercase() }
        return sorted.joinToString("\n")
    }

    fun removeDuplicateLines(text: String): String =
        text.lines().map { it.trim() }.filter { it.isNotBlank() }.distinct().joinToString("\n")

    fun reverseLines(text: String): String =
        text.lines().filter { it.isNotBlank() }.reversed().joinToString("\n")

    /**
     * Limpia el texto copiado de un PDF: une las palabras cortadas con guion al
     * final de línea y junta los saltos que parten una misma oración.
     */
    fun cleanPdfText(text: String): String {
        var result = text.replace(Regex("(\\p{L})-\\n(\\p{L})"), "$1$2")
        result = result.replace(Regex("(?<![.!?:;])\\n(?!\\n)"), " ")
        result = result.replace(Regex("[ \\t]{2,}"), " ")
        result = result.replace(Regex("\\n{3,}"), "\n\n")
        return result.trim()
    }

    fun toSlug(text: String): String =
        removeAccents(text.lowercase())
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
            .take(120)

    fun wordFrequency(text: String, top: Int = 15, ignoreCommon: Boolean = true): List<Pair<String, Int>> {
        val stopWords = setOf(
            "de", "la", "que", "el", "en", "y", "a", "los", "se", "del", "las", "un", "por",
            "con", "no", "una", "su", "para", "es", "al", "lo", "como", "más", "o", "pero",
            "sus", "le", "ha", "me", "si", "sin", "sobre", "este", "ya", "entre", "cuando",
            "todo", "esta", "ser", "son", "dos", "también", "fue", "había", "era", "muy"
        )
        return wordList(text.lowercase())
            .filter { it.length > 2 && (!ignoreCommon || it !in stopWords) }
            .groupingBy { it }
            .eachCount()
            .toList()
            .sortedByDescending { it.second }
            .take(top)
    }

    /** Avisa si el texto se pasa o se queda corto respecto de un límite de palabras. */
    fun limitStatus(words: Int, limit: Int, tolerancePercent: Int = 10): String {
        if (limit <= 0) return ""
        val difference = words - limit
        val margin = limit * tolerancePercent / 100
        return when {
            difference > margin -> "Te pasas por ${difference} palabras del límite de $limit."
            difference < -margin -> "Te faltan ${-difference} palabras para llegar a $limit."
            else -> "Estás dentro del límite de $limit palabras."
        }
    }
}

// ---------------------------------------------------------------------------
// Sistemas numéricos
// ---------------------------------------------------------------------------

object NumberLab {

    private const val DIGITS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    fun isValidIn(text: String, base: Int): Boolean {
        if (base !in 2..36) return false
        val clean = text.trim().removePrefix("-").uppercase()
        if (clean.isEmpty()) return false
        return clean.all { DIGITS.indexOf(it).let { index -> index in 0 until base } }
    }

    fun parse(text: String, base: Int): Long {
        require(base in 2..36) { "La base debe estar entre 2 y 36." }
        val clean = text.trim().uppercase().replace(" ", "")
        require(clean.isNotEmpty()) { "Escribe un número." }
        val negative = clean.startsWith("-")
        val body = clean.removePrefix("-")
        require(body.all { DIGITS.indexOf(it) in 0 until base }) {
            "«$text» no es válido en base $base."
        }
        val value = body.fold(0L) { acc, char ->
            val digit = DIGITS.indexOf(char)
            val next = acc * base + digit
            require(next >= acc || acc == 0L) { "El número es demasiado grande." }
            next
        }
        return if (negative) -value else value
    }

    fun format(value: Long, base: Int): String {
        require(base in 2..36) { "La base debe estar entre 2 y 36." }
        if (value == 0L) return "0"
        val negative = value < 0
        var remaining = kotlin.math.abs(value)
        val builder = StringBuilder()
        while (remaining > 0) {
            builder.append(DIGITS[(remaining % base).toInt()])
            remaining /= base
        }
        if (negative) builder.append('-')
        return builder.reverse().toString()
    }

    /** Agrupa el binario de cuatro en cuatro para que se pueda leer. */
    fun groupBinary(text: String, size: Int = 4): String {
        val clean = text.replace(" ", "")
        if (clean.length <= size) return clean
        return clean.reversed().chunked(size).joinToString(" ").reversed()
    }

    /**
     * Complemento a dos: así representan los computadores los números
     * negativos. Se invierten los bits y se suma uno.
     */
    fun twosComplement(value: Long, bits: Int): String {
        require(bits in 4..64) { "Usa entre 4 y 64 bits." }
        val limit = if (bits == 64) Long.MAX_VALUE else (1L shl (bits - 1)) - 1
        val minimum = -limit - 1
        require(value in minimum..limit) {
            "Con $bits bits el rango es de $minimum a $limit."
        }
        val mask = if (bits == 64) -1L else (1L shl bits) - 1
        val raw = value and mask
        return format(raw, 2).padStart(bits, '0')
    }

    fun fromTwosComplement(binary: String, bits: Int): Long {
        val clean = binary.trim().replace(" ", "")
        require(clean.length <= bits) { "El número tiene más de $bits bits." }
        require(clean.all { it == '0' || it == '1' }) { "Solo se aceptan ceros y unos." }
        val padded = clean.padStart(bits, '0')
        val unsigned = padded.fold(0L) { acc, char -> acc * 2 + (char - '0') }
        val signBit = 1L shl (bits - 1)
        return if (unsigned and signBit != 0L) unsigned - (1L shl bits) else unsigned
    }

    data class BitwiseResult(
        val and: Long,
        val or: Long,
        val xor: Long,
        val shiftLeft: Long,
        val shiftRight: Long
    )

    fun bitwise(a: Long, b: Long, shift: Int = 1): BitwiseResult = BitwiseResult(
        and = a and b,
        or = a or b,
        xor = a xor b,
        shiftLeft = a shl shift.coerceIn(0, 62),
        shiftRight = a shr shift.coerceIn(0, 62)
    )

    data class FloatBreakdown(
        val sign: String,
        val exponentBits: String,
        val mantissaBits: String,
        val exponentValue: Int,
        val reconstructed: Double
    )

    /** Descompone un decimal en la representación IEEE 754 de 32 bits. */
    fun ieee754(value: Double): FloatBreakdown {
        val bits = java.lang.Float.floatToIntBits(value.toFloat())
        val binary = java.lang.Integer.toBinaryString(bits).padStart(32, '0')
        val sign = binary.substring(0, 1)
        val exponent = binary.substring(1, 9)
        val mantissa = binary.substring(9)
        val exponentValue = Integer.parseInt(exponent, 2) - 127
        return FloatBreakdown(
            sign = sign,
            exponentBits = exponent,
            mantissaBits = mantissa,
            exponentValue = exponentValue,
            reconstructed = java.lang.Float.intBitsToFloat(bits).toDouble()
        )
    }

    /** Por qué 0.1 + 0.2 no da exactamente 0.3 en coma flotante. */
    fun floatingPointNote(value: Double): String {
        val asFloat = value.toFloat().toDouble()
        return if (abs(asFloat - value) < 1e-12) {
            "Este número se representa exacto en binario."
        } else {
            "En binario no cabe exacto: se guarda como ${"%.10f".format(asFloat)}. " +
                "Por eso el dinero nunca se calcula con decimales de coma flotante."
        }
    }
}
