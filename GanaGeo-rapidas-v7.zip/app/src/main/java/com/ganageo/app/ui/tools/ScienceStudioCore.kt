package com.ganageo.app.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Piezas comunes de las herramientas de Ciencias.
 *
 * Comparten paleta y estructura con el estudio de imágenes: barra superior fija,
 * contenido protagonista y controles agrupados abajo. Aquí se añaden dos cosas
 * propias de matemática y ciencia: un teclado con los símbolos que no están en
 * el teclado del teléfono y las tarjetas de desarrollo paso a paso.
 */

// ---------------------------------------------------------------------------
// Estructura de pantalla
// ---------------------------------------------------------------------------

@Composable
fun ScienceShell(
    title: String,
    subtitle: String?,
    onBack: () -> Unit,
    trailing: @Composable RowScope.() -> Unit = {},
    body: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioTheme.Background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScienceTopBar(title, subtitle, onBack, trailing)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(horizontal = 14.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = body
        )
    }
}

/** Variante con lienzo fijo arriba y panel de controles abajo (graficador, tabla periódica). */
@Composable
fun ScienceStage(
    title: String,
    subtitle: String?,
    onBack: () -> Unit,
    trailing: @Composable RowScope.() -> Unit = {},
    stage: @Composable BoxScope.() -> Unit,
    panel: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioTheme.Background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScienceTopBar(title, subtitle, onBack, trailing)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(StudioTheme.Canvas),
            content = stage
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioTheme.Surface)
                .imePadding(),
            content = panel
        )
    }
}

@Composable
private fun ScienceTopBar(
    title: String,
    subtitle: String?,
    onBack: () -> Unit,
    trailing: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = StudioTheme.TextPrimary)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title,
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (subtitle != null) {
                Text(
                    subtitle,
                    color = StudioTheme.TextSecondary,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        trailing()
        Spacer(Modifier.width(4.dp))
    }
}

@Composable
fun ScienceCard(
    title: String? = null,
    accent: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(if (accent) StudioTheme.Accent.copy(alpha = 0.10f) else StudioTheme.Surface)
            .border(
                1.dp,
                if (accent) StudioTheme.Accent.copy(alpha = 0.45f) else StudioTheme.Outline,
                RoundedCornerShape(18.dp)
            )
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (title != null) {
            Text(
                title,
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall
            )
        }
        content()
    }
}

/** Resultado principal, grande y copiable. */
@Composable
fun ScienceResult(
    headline: String,
    caption: String? = null,
    onCopy: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(StudioTheme.Accent.copy(alpha = 0.12f))
            .border(1.dp, StudioTheme.Accent.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                headline,
                color = StudioTheme.Accent,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                lineHeight = 28.sp,
                modifier = Modifier.weight(1f)
            )
            if (onCopy != null) {
                IconButton(onClick = onCopy, modifier = Modifier.size(34.dp)) {
                    Icon(
                        Icons.Rounded.ContentCopy,
                        contentDescription = "Copiar",
                        tint = StudioTheme.TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
        if (caption != null) {
            Text(caption, color = StudioTheme.TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

/** Texto de fórmula: monoespaciado para que los símbolos queden alineados. */
@Composable
fun FormulaText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = StudioTheme.TextPrimary,
    size: Int = 16
) {
    Text(
        text,
        modifier = modifier,
        color = color,
        fontFamily = FontFamily.Monospace,
        fontSize = size.sp,
        lineHeight = (size + 8).sp
    )
}

@Composable
fun ScienceRow(label: String, value: String, highlight: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = StudioTheme.TextSecondary,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.weight(1f)
        )
        Text(
            value,
            color = if (highlight) StudioTheme.Accent else StudioTheme.TextPrimary,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.SemiBold,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun ScienceError(message: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x33FF6B6B))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Close, contentDescription = null, tint = Color(0xFFFF9A9A), modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(message, color = Color(0xFFFFC9C9), style = MaterialTheme.typography.bodySmall)
    }
}

// ---------------------------------------------------------------------------
// Desarrollo paso a paso
// ---------------------------------------------------------------------------

/**
 * Lista de pasos colapsables. El primero viene abierto y el resto cerrados: se
 * ve el camino completo de un vistazo y se abre solo el paso que interesa.
 */
@Composable
fun StepsSection(
    steps: List<com.ganageo.app.tools.SolveStep>,
    method: String? = null
) {
    if (steps.isEmpty()) return
    var allOpen by rememberSaveable { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Paso a paso",
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.weight(1f)
            )
            if (method != null) {
                Text(method, color = StudioTheme.TextSecondary, style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                if (allOpen) "Cerrar todo" else "Abrir todo",
                color = StudioTheme.Accent,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { allOpen = !allOpen }
            )
        }
        steps.forEachIndexed { index, step ->
            StepCard(index + 1, step, startExpanded = allOpen || index == 0, key = allOpen)
        }
    }
}

@Composable
private fun StepCard(
    number: Int,
    step: com.ganageo.app.tools.SolveStep,
    startExpanded: Boolean,
    key: Boolean
) {
    var expanded by remember(key) { mutableStateOf(startExpanded) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(StudioTheme.Surface)
            .border(1.dp, StudioTheme.Outline, RoundedCornerShape(16.dp))
            .clickable { expanded = !expanded }
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(StudioTheme.Accent.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "$number",
                    color = StudioTheme.Accent,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            Spacer(Modifier.width(10.dp))
            Text(
                step.title,
                color = StudioTheme.TextPrimary,
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            )
            Icon(
                if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                contentDescription = null,
                tint = StudioTheme.TextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
        if (expanded) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(StudioTheme.Canvas)
                        .padding(12.dp)
                ) {
                    FormulaText(step.expression, color = StudioTheme.TextPrimary)
                }
                Text(
                    step.explanation,
                    color = StudioTheme.TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Entrada matemática
// ---------------------------------------------------------------------------

/**
 * Campo de expresión con paleta matemática.
 *
 * El teclado del teléfono sirve para números y letras, pero no tiene √, ^, π ni
 * las funciones. La paleta añade esas teclas e inserta el texto justo donde está
 * el cursor, dejándolo dentro del paréntesis cuando corresponde.
 */
@Composable
fun MathInput(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String? = null,
    showPalette: Boolean = true,
    paletteLayers: List<MathKeyLayer> = MathKeys.standard
) {
    var paletteOpen by rememberSaveable { mutableStateOf(false) }
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            placeholder = placeholder?.let { { Text(it) } },
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            shape = RoundedCornerShape(14.dp),
            trailingIcon = if (showPalette) {
                {
                    IconButton(onClick = { paletteOpen = !paletteOpen }) {
                        Icon(
                            Icons.Rounded.Keyboard,
                            contentDescription = "Símbolos",
                            tint = if (paletteOpen) StudioTheme.Accent else StudioTheme.TextSecondary
                        )
                    }
                }
            } else null,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = StudioTheme.TextPrimary,
                unfocusedTextColor = StudioTheme.TextPrimary,
                focusedBorderColor = StudioTheme.Accent,
                unfocusedBorderColor = StudioTheme.Outline,
                focusedLabelColor = StudioTheme.Accent,
                unfocusedLabelColor = StudioTheme.TextSecondary,
                cursorColor = StudioTheme.Accent
            ),
            modifier = Modifier.fillMaxWidth()
        )
        if (showPalette && paletteOpen) {
            MathPalette(
                layers = paletteLayers,
                onKey = { key -> onValueChange(insertKey(value, key)) },
                onBackspace = { onValueChange(deleteBackwards(value)) },
                onClear = { onValueChange(TextFieldValue("")) }
            )
        }
    }
}

data class MathKey(
    val label: String,
    val insert: String,
    /** Cuántas posiciones retroceder el cursor tras insertar (para quedar dentro del paréntesis). */
    val caretBack: Int = 0
)

data class MathKeyLayer(val name: String, val keys: List<MathKey>)

object MathKeys {
    private fun fn(label: String, name: String) = MathKey(label, "$name()", 1)

    val basic = MathKeyLayer(
        "123",
        listOf(
            MathKey("(", "("), MathKey(")", ")"), MathKey("+", " + "), MathKey("−", " - "),
            MathKey("×", "*"), MathKey("÷", "/"), MathKey("^", "^"), MathKey("x²", "^2"),
            MathKey("√", "sqrt()", 1), MathKey("π", "pi"), MathKey("e", "e"), MathKey("=", " = ")
        )
    )

    val algebra = MathKeyLayer(
        "f(x)",
        listOf(
            MathKey("x", "x"), MathKey("y", "y"), MathKey("|x|", "abs()", 1),
            MathKey("∛", "cbrt()", 1), MathKey("ⁿ√", "raiz(;)", 2),
            MathKey("ln", "ln()", 1), MathKey("log", "log()", 1), MathKey("log₂", "log2()", 1),
            MathKey("eˣ", "exp()", 1), MathKey("n!", "!"), MathKey("%", "%")
        )
    )

    val trig = MathKeyLayer(
        "Trig",
        listOf(
            fn("sin", "sin"), fn("cos", "cos"), fn("tan", "tan"),
            fn("asin", "asin"), fn("acos", "acos"), fn("atan", "atan"),
            fn("sinh", "sinh"), fn("cosh", "cosh"), fn("tanh", "tanh"),
            MathKey("π", "pi"), MathKey("τ", "tau")
        )
    )

    val greek = MathKeyLayer(
        "Símbolos",
        listOf(
            MathKey("α", "α"), MathKey("β", "β"), MathKey("θ", "θ"), MathKey("Δ", "Δ"),
            MathKey("μ", "μ"), MathKey("ρ", "ρ"), MathKey("σ", "σ"), MathKey("ω", "ω"),
            MathKey("→", " → "), MathKey("·", "·"), MathKey("±", "±")
        )
    )

    val standard = listOf(basic, algebra, trig)
    val withGreek = listOf(basic, algebra, trig, greek)
    val chemistry = listOf(
        MathKeyLayer(
            "Química",
            listOf(
                MathKey("→", " → "), MathKey("+", " + "), MathKey("(", "("), MathKey(")", ")"),
                MathKey("₁", "1"), MathKey("₂", "2"), MathKey("₃", "3"), MathKey("₄", "4"),
                MathKey("·", "·"), MathKey("H₂O", "H2O"), MathKey("SO₄", "SO4"), MathKey("NO₃", "NO3")
            )
        )
    )
}

@Composable
fun MathPalette(
    layers: List<MathKeyLayer>,
    onKey: (MathKey) -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit
) {
    var layerIndex by rememberSaveable { mutableIntStateOf(0) }
    val layer = layers.getOrElse(layerIndex) { layers.first() }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(StudioTheme.Surface)
            .border(1.dp, StudioTheme.Outline, RoundedCornerShape(16.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                layers.forEachIndexed { index, item ->
                    StudioChip(
                        label = item.name,
                        active = index == layerIndex,
                        onClick = { layerIndex = index }
                    )
                }
            }
            Spacer(Modifier.width(6.dp))
            IconButton(onClick = onBackspace, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.Rounded.Backspace,
                    contentDescription = "Borrar",
                    tint = StudioTheme.TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            IconButton(onClick = onClear, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.Rounded.Close,
                    contentDescription = "Limpiar",
                    tint = StudioTheme.TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        // Teclas en filas de cuatro, con altura cómoda para el dedo.
        layer.keys.chunked(4).forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                row.forEach { key ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(StudioTheme.SurfaceHigh)
                            .clickable { onKey(key) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            key.label,
                            color = StudioTheme.TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

fun insertKey(value: TextFieldValue, key: MathKey): TextFieldValue {
    val start = value.selection.start.coerceIn(0, value.text.length)
    val end = value.selection.end.coerceIn(0, value.text.length)
    val text = value.text.substring(0, start) + key.insert + value.text.substring(end)
    val caret = (start + key.insert.length - key.caretBack).coerceIn(0, text.length)
    return TextFieldValue(text, TextRange(caret))
}

fun deleteBackwards(value: TextFieldValue): TextFieldValue {
    val start = value.selection.start.coerceIn(0, value.text.length)
    val end = value.selection.end.coerceIn(0, value.text.length)
    if (start != end) {
        val text = value.text.substring(0, start) + value.text.substring(end)
        return TextFieldValue(text, TextRange(start))
    }
    if (start == 0) return value
    val text = value.text.substring(0, start - 1) + value.text.substring(start)
    return TextFieldValue(text, TextRange(start - 1))
}

/** Campo numérico compacto que acepta signo y decimales con coma o punto. */
@Composable
fun ScienceNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = { input ->
            onValueChange(input.filter { it.isDigit() || it == '.' || it == ',' || it == '-' || it == 'e' || it == 'E' }.take(16))
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = StudioTheme.TextPrimary,
            unfocusedTextColor = StudioTheme.TextPrimary,
            focusedBorderColor = StudioTheme.Accent,
            unfocusedBorderColor = StudioTheme.Outline,
            focusedLabelColor = StudioTheme.Accent,
            unfocusedLabelColor = StudioTheme.TextSecondary,
            cursorColor = StudioTheme.Accent
        ),
        modifier = modifier
    )
}

/** Área de texto para pegar listas de datos. */
@Composable
fun ScienceTextArea(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    modifier: Modifier = Modifier,
    minHeight: Int = 110
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        shape = RoundedCornerShape(14.dp),
        textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = StudioTheme.TextPrimary,
            unfocusedTextColor = StudioTheme.TextPrimary,
            focusedBorderColor = StudioTheme.Accent,
            unfocusedBorderColor = StudioTheme.Outline,
            focusedLabelColor = StudioTheme.Accent,
            unfocusedLabelColor = StudioTheme.TextSecondary,
            cursorColor = StudioTheme.Accent
        ),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = minHeight.dp)
    )
}

fun String.toScienceDouble(): Double? = replace(',', '.').trim().toDoubleOrNull()
