package com.ganageo.app.tools

import kotlin.math.roundToInt

/**
 * Ficha de un elemento químico.
 *
 * Las masas atómicas son los valores convencionales abreviados de la IUPAC
 * (revisión 2021 de la CIAAW). Algunos elementos no tienen un valor único porque
 * su composición isotópica varía en la naturaleza: en esos casos se usa el valor
 * convencional recomendado por la propia comisión y el intervalo queda anotado
 * en [massNote]. En los elementos sin isótopos estables la masa es la del isótopo
 * más estable conocido, por eso se marca con [massIsMostStable].
 */
data class ChemicalElement(
    val number: Int,
    val symbol: String,
    val name: String,
    val mass: Double,
    val category: ElementCategory,
    val group: Int?,
    val period: Int,
    val block: String,
    val electronegativity: Double?,
    val meltingPointK: Double?,
    val boilingPointK: Double?,
    val density: Double?,
    val use: String,
    val massIsMostStable: Boolean = false,
    val massNote: String? = null
) {
    val stateAt25C: String
        get() = when {
            meltingPointK == null -> "Sintético"
            meltingPointK > 298.15 -> "Sólido"
            boilingPointK != null && boilingPointK <= 298.15 -> "Gas"
            else -> "Líquido"
        }

    val electronConfiguration: String get() = ElementsCatalog.configurationOf(number)
}

enum class ElementCategory(val label: String, val colorArgb: Int) {
    ALKALI("Metal alcalino", 0xFFFF7043.toInt()),
    ALKALINE("Alcalinotérreo", 0xFFFFB74D.toInt()),
    TRANSITION("Metal de transición", 0xFF64B5F6.toInt()),
    POST_TRANSITION("Metal del bloque p", 0xFF4DB6AC.toInt()),
    METALLOID("Metaloide", 0xFF9575CD.toInt()),
    NONMETAL("No metal", 0xFF81C784.toInt()),
    HALOGEN("Halógeno", 0xFFF06292.toInt()),
    NOBLE("Gas noble", 0xFF4FC3F7.toInt()),
    LANTHANIDE("Lantánido", 0xFFBA68C8.toInt()),
    ACTINIDE("Actínido", 0xFFE57373.toInt()),
    UNKNOWN("Propiedades desconocidas", 0xFF90A4AE.toInt())
}

object ElementsCatalog {

    /**
     * Z|Símbolo|Nombre|Masa|Categoría|Electronegatividad|Fusión K|Ebullición K|Densidad|Uso
     * Un 0 en un dato numérico significa "no disponible" y la ficha lo muestra como «—».
     */
    private val raw = """
1|H|Hidrógeno|1.008|NONMETAL|2.20|13.99|20.27|0.00009|Combustible, amoniaco y refinerías
2|He|Helio|4.0026|NOBLE|0|0.95|4.22|0.00018|Globos, criogenia y resonancia magnética
3|Li|Litio|6.94|ALKALI|0.98|453.65|1603|0.534|Baterías recargables y cerámicas
4|Be|Berilio|9.0122|ALKALINE|1.57|1560|2742|1.85|Aleaciones ligeras y ventanas de rayos X
5|B|Boro|10.81|METALLOID|2.04|2349|4200|2.34|Vidrio borosilicato y detergentes
6|C|Carbono|12.011|NONMETAL|2.55|3823|4098|2.267|Base de la química orgánica, acero y grafito
7|N|Nitrógeno|14.007|NONMETAL|3.04|63.15|77.36|0.00125|Fertilizantes, atmósfera y conservación
8|O|Oxígeno|15.999|NONMETAL|3.44|54.36|90.20|0.00143|Respiración, combustión y siderurgia
9|F|Flúor|18.998|HALOGEN|3.98|53.53|85.03|0.0017|Pasta dental, teflón y refrigerantes
10|Ne|Neón|20.180|NOBLE|0|24.56|27.07|0.0009|Letreros luminosos y láseres
11|Na|Sodio|22.990|ALKALI|0.93|370.87|1156|0.968|Sal común, jabones y alumbrado
12|Mg|Magnesio|24.305|ALKALINE|1.31|923|1363|1.738|Aleaciones ligeras y clorofila
13|Al|Aluminio|26.982|POST_TRANSITION|1.61|933.47|2792|2.70|Envases, transporte y construcción
14|Si|Silicio|28.085|METALLOID|1.90|1687|3538|2.329|Chips, paneles solares y vidrio
15|P|Fósforo|30.974|NONMETAL|2.19|317.3|553.7|1.823|Fertilizantes, ADN y cerillas
16|S|Azufre|32.06|NONMETAL|2.58|388.36|717.87|2.07|Ácido sulfúrico y vulcanizado del caucho
17|Cl|Cloro|35.45|HALOGEN|3.16|171.6|239.11|0.0032|Potabilización del agua y PVC
18|Ar|Argón|39.95|NOBLE|0|83.80|87.30|0.00178|Soldadura y bombillas
19|K|Potasio|39.098|ALKALI|0.82|336.53|1032|0.862|Fertilizantes y función nerviosa
20|Ca|Calcio|40.078|ALKALINE|1.00|1115|1757|1.55|Huesos, cemento y cal
21|Sc|Escandio|44.956|TRANSITION|1.36|1814|3109|2.985|Aleaciones de aluminio para aviación
22|Ti|Titanio|47.867|TRANSITION|1.54|1941|3560|4.506|Prótesis, aviones y pigmento blanco
23|V|Vanadio|50.942|TRANSITION|1.63|2183|3680|6.11|Aceros de alta resistencia
24|Cr|Cromo|51.996|TRANSITION|1.66|2180|2944|7.15|Acero inoxidable y cromado
25|Mn|Manganeso|54.938|TRANSITION|1.55|1519|2334|7.21|Acero, pilas y enzimas
26|Fe|Hierro|55.845|TRANSITION|1.83|1811|3134|7.874|Acero, hemoglobina y construcción
27|Co|Cobalto|58.933|TRANSITION|1.88|1768|3200|8.90|Baterías, imanes y vitamina B12
28|Ni|Níquel|58.693|TRANSITION|1.91|1728|3186|8.908|Acero inoxidable y monedas
29|Cu|Cobre|63.546|TRANSITION|1.90|1357.77|2835|8.96|Cables eléctricos y tuberías
30|Zn|Zinc|65.38|TRANSITION|1.65|692.68|1180|7.14|Galvanizado y suplementos
31|Ga|Galio|69.723|POST_TRANSITION|1.81|302.91|2673|5.91|LED y semiconductores
32|Ge|Germanio|72.630|METALLOID|2.01|1211.4|3106|5.323|Fibra óptica e infrarrojos
33|As|Arsénico|74.922|METALLOID|2.18|1090|887|5.727|Semiconductores y pesticidas
34|Se|Selenio|78.971|NONMETAL|2.55|494|958|4.81|Fotocopiadoras y antioxidante
35|Br|Bromo|79.904|HALOGEN|2.96|265.8|332.0|3.1028|Retardantes de llama y fotografía
36|Kr|Kriptón|83.798|NOBLE|3.00|115.79|119.93|0.00375|Iluminación de alto rendimiento
37|Rb|Rubidio|85.468|ALKALI|0.82|312.46|961|1.532|Relojes atómicos y células fotoeléctricas
38|Sr|Estroncio|87.62|ALKALINE|0.95|1050|1655|2.64|Fuegos artificiales rojos e imanes
39|Y|Itrio|88.906|TRANSITION|1.22|1799|3609|4.472|LED, superconductores y láseres
40|Zr|Circonio|91.224|TRANSITION|1.33|2128|4682|6.52|Reactores nucleares y cerámica dental
41|Nb|Niobio|92.906|TRANSITION|1.6|2750|5017|8.57|Superconductores y aceros
42|Mo|Molibdeno|95.95|TRANSITION|2.16|2896|4912|10.28|Aceros y lubricantes
43|Tc|Tecnecio|97|TRANSITION|1.9|2430|4538|11|Medicina nuclear (gammagrafías)
44|Ru|Rutenio|101.07|TRANSITION|2.2|2607|4423|12.45|Contactos eléctricos y catálisis
45|Rh|Rodio|102.91|TRANSITION|2.28|2237|3968|12.41|Catalizadores de autos
46|Pd|Paladio|106.42|TRANSITION|2.20|1828.05|3236|12.023|Catalizadores y electrónica
47|Ag|Plata|107.87|TRANSITION|1.93|1234.93|2435|10.49|Joyería, espejos y electrónica
48|Cd|Cadmio|112.41|TRANSITION|1.69|594.22|1040|8.65|Baterías y pigmentos
49|In|Indio|114.82|POST_TRANSITION|1.78|429.75|2345|7.31|Pantallas táctiles (ITO)
50|Sn|Estaño|118.71|POST_TRANSITION|1.96|505.08|2875|7.287|Soldaduras y hojalata
51|Sb|Antimonio|121.76|METALLOID|2.05|903.78|1860|6.685|Retardantes de llama y aleaciones
52|Te|Telurio|127.60|METALLOID|2.1|722.66|1261|6.232|Paneles solares y aleaciones
53|I|Yodo|126.90|HALOGEN|2.66|386.85|457.4|4.93|Antiséptico y tiroides
54|Xe|Xenón|131.29|NOBLE|2.60|161.4|165.03|0.0059|Faros y propulsión iónica
55|Cs|Cesio|132.91|ALKALI|0.79|301.59|944|1.93|Relojes atómicos, define el segundo
56|Ba|Bario|137.33|ALKALINE|0.89|1000|2170|3.51|Radiografías de contraste
57|La|Lantano|138.91|LANTHANIDE|1.10|1193|3737|6.162|Lentes de cámara y baterías
58|Ce|Cerio|140.12|LANTHANIDE|1.12|1068|3716|6.770|Catalizadores y pulido de vidrio
59|Pr|Praseodimio|140.91|LANTHANIDE|1.13|1208|3793|6.77|Imanes y vidrios de soldador
60|Nd|Neodimio|144.24|LANTHANIDE|1.14|1297|3347|7.01|Imanes permanentes potentes
61|Pm|Prometio|145|LANTHANIDE|1.13|1315|3273|7.26|Pinturas luminosas y pilas nucleares
62|Sm|Samario|150.36|LANTHANIDE|1.17|1345|2067|7.52|Imanes resistentes al calor
63|Eu|Europio|151.96|LANTHANIDE|1.2|1099|1802|5.264|Fósforos rojos de pantallas y billetes
64|Gd|Gadolinio|157.25|LANTHANIDE|1.20|1585|3546|7.90|Contraste en resonancia magnética
65|Tb|Terbio|158.93|LANTHANIDE|1.2|1629|3503|8.23|Fósforos verdes y sensores
66|Dy|Disprosio|162.50|LANTHANIDE|1.22|1680|2840|8.540|Imanes de motores eléctricos
67|Ho|Holmio|164.93|LANTHANIDE|1.23|1734|2993|8.79|Láseres médicos e imanes
68|Er|Erbio|167.26|LANTHANIDE|1.24|1802|3141|9.066|Amplificadores de fibra óptica
69|Tm|Tulio|168.93|LANTHANIDE|1.25|1818|2223|9.32|Láseres portátiles y rayos X
70|Yb|Iterbio|173.05|LANTHANIDE|1.1|1097|1469|6.90|Relojes atómicos ópticos
71|Lu|Lutecio|174.97|LANTHANIDE|1.27|1925|3675|9.841|Detectores PET y catálisis
72|Hf|Hafnio|178.49|TRANSITION|1.3|2506|4876|13.31|Barras de control nuclear y chips
73|Ta|Tantalio|180.95|TRANSITION|1.5|3290|5731|16.69|Condensadores de móviles e implantes
74|W|Wolframio|183.84|TRANSITION|2.36|3695|5828|19.25|Filamentos y herramientas de corte
75|Re|Renio|186.21|TRANSITION|1.9|3459|5869|21.02|Turbinas de avión y catálisis
76|Os|Osmio|190.23|TRANSITION|2.2|3306|5285|22.59|El elemento más denso; puntas de pluma
77|Ir|Iridio|192.22|TRANSITION|2.20|2719|4701|22.56|Bujías y crisoles de alta temperatura
78|Pt|Platino|195.08|TRANSITION|2.28|2041.4|4098|21.45|Catalizadores, joyería y electrodos
79|Au|Oro|196.97|TRANSITION|2.54|1337.33|3129|19.3|Joyería, electrónica y reserva de valor
80|Hg|Mercurio|200.59|TRANSITION|2.00|234.32|629.88|13.534|Único metal líquido; termómetros antiguos
81|Tl|Talio|204.38|POST_TRANSITION|1.62|577|1746|11.85|Detectores de radiación
82|Pb|Plomo|207.2|POST_TRANSITION|2.33|600.61|2022|11.34|Baterías y blindaje de radiación
83|Bi|Bismuto|208.98|POST_TRANSITION|2.02|544.7|1837|9.78|Cosméticos y sustituto no tóxico del plomo
84|Po|Polonio|209|POST_TRANSITION|2.0|527|1235|9.196|Fuentes de calor en satélites
85|At|Astato|210|HALOGEN|2.2|575|610|0|Investigación en radioterapia
86|Rn|Radón|222|NOBLE|2.2|202|211.3|0.00973|Gas radiactivo natural del subsuelo
87|Fr|Francio|223|ALKALI|0.7|300|950|0|Solo investigación; extremadamente raro
88|Ra|Radio|226|ALKALINE|0.9|973|2010|5.5|Históricamente en pinturas luminosas
89|Ac|Actinio|227|ACTINIDE|1.1|1323|3471|10|Fuentes de neutrones y radioterapia
90|Th|Torio|232.04|ACTINIDE|1.3|2115|5061|11.7|Combustible nuclear alternativo
91|Pa|Protactinio|231.04|ACTINIDE|1.5|1841|4300|15.37|Solo investigación científica
92|U|Uranio|238.03|ACTINIDE|1.38|1405.3|4404|19.1|Combustible nuclear
93|Np|Neptunio|237|ACTINIDE|1.36|917|4273|20.45|Detectores de neutrones
94|Pu|Plutonio|244|ACTINIDE|1.28|912.5|3505|19.85|Reactores y sondas espaciales
95|Am|Americio|243|ACTINIDE|1.13|1449|2880|12|Detectores de humo
96|Cm|Curio|247|ACTINIDE|1.28|1613|3383|13.51|Fuentes de energía en sondas
97|Bk|Berkelio|247|ACTINIDE|1.3|1259|2900|14.78|Solo investigación
98|Cf|Californio|251|ACTINIDE|1.3|1173|1743|15.1|Fuente de neutrones y prospección
99|Es|Einstenio|252|ACTINIDE|1.3|1133|0|8.84|Solo investigación
100|Fm|Fermio|257|ACTINIDE|1.3|1800|0|0|Solo investigación
101|Md|Mendelevio|258|ACTINIDE|1.3|1100|0|0|Solo investigación
102|No|Nobelio|259|ACTINIDE|1.3|1100|0|0|Solo investigación
103|Lr|Lawrencio|266|ACTINIDE|1.3|1900|0|0|Solo investigación
104|Rf|Rutherfordio|267|TRANSITION|0|2400|5800|0|Sintético, vida media muy corta
105|Db|Dubnio|268|TRANSITION|0|0|0|0|Sintético, vida media muy corta
106|Sg|Seaborgio|269|TRANSITION|0|0|0|0|Sintético, vida media muy corta
107|Bh|Bohrio|270|TRANSITION|0|0|0|0|Sintético, vida media muy corta
108|Hs|Hasio|269|TRANSITION|0|0|0|0|Sintético, vida media muy corta
109|Mt|Meitnerio|278|UNKNOWN|0|0|0|0|Sintético, propiedades no medidas
110|Ds|Darmstatio|281|UNKNOWN|0|0|0|0|Sintético, propiedades no medidas
111|Rg|Roentgenio|282|UNKNOWN|0|0|0|0|Sintético, propiedades no medidas
112|Cn|Copernicio|285|TRANSITION|0|0|357|0|Sintético; se cree que es gas o líquido
113|Nh|Nihonio|286|UNKNOWN|0|700|1430|0|Sintético, propiedades estimadas
114|Fl|Flerovio|289|UNKNOWN|0|200|380|0|Sintético, propiedades estimadas
115|Mc|Moscovio|290|UNKNOWN|0|700|1400|0|Sintético, propiedades estimadas
116|Lv|Livermorio|293|UNKNOWN|0|700|1085|0|Sintético, propiedades estimadas
117|Ts|Teneso|294|UNKNOWN|0|700|883|0|Sintético, propiedades estimadas
118|Og|Oganesón|294|UNKNOWN|0|325|450|0|Sintético; el elemento más pesado conocido
    """.trimIndent()

    /** Elementos cuya masa es la del isótopo más estable, no un peso atómico estándar. */
    private val mostStableMass = setOf(43, 61) + (84..118)

    /**
     * Elementos con composición isotópica variable: la IUPAC publica un intervalo
     * y recomienda un valor convencional único para cálculo.
     */
    private val intervalNotes = mapOf(
        1 to "Intervalo IUPAC [1,00784; 1,00811]",
        3 to "Intervalo IUPAC [6,938; 6,997]",
        5 to "Intervalo IUPAC [10,806; 10,821]",
        6 to "Intervalo IUPAC [12,0096; 12,0116]",
        7 to "Intervalo IUPAC [14,00643; 14,00728]",
        8 to "Intervalo IUPAC [15,99903; 15,99977]",
        12 to "Intervalo IUPAC [24,304; 24,307]",
        14 to "Intervalo IUPAC [28,084; 28,086]",
        16 to "Intervalo IUPAC [32,059; 32,076]",
        17 to "Intervalo IUPAC [35,446; 35,457]",
        18 to "Intervalo IUPAC [39,792; 39,963]; valor convencional 39,95",
        35 to "Intervalo IUPAC [79,901; 79,907]",
        81 to "Intervalo IUPAC [204,382; 204,385]",
        82 to "Intervalo IUPAC [206,14; 207,94]; valor convencional 207,2 ± 1,1"
    )

    val elements: List<ChemicalElement> by lazy {
        raw.lines().filter { it.isNotBlank() }.map { line ->
            val p = line.split("|")
            val z = p[0].trim().toInt()
            ChemicalElement(
                number = z,
                symbol = p[1].trim(),
                name = p[2].trim(),
                mass = p[3].trim().toDouble(),
                category = ElementCategory.valueOf(p[4].trim()),
                group = groupOf(z),
                period = periodOf(z),
                block = blockOf(z),
                electronegativity = p[5].trim().toDouble().takeIf { it > 0 },
                meltingPointK = p[6].trim().toDouble().takeIf { it > 0 },
                boilingPointK = p[7].trim().toDouble().takeIf { it > 0 },
                density = p[8].trim().toDouble().takeIf { it > 0 },
                use = p[9].trim(),
                massIsMostStable = z in mostStableMass,
                massNote = intervalNotes[z]
            )
        }
    }

    private val bySymbol: Map<String, ChemicalElement> by lazy {
        elements.associateBy { it.symbol }
    }

    fun bySymbol(symbol: String): ChemicalElement? = bySymbol[symbol]

    fun byNumber(number: Int): ChemicalElement? = elements.getOrNull(number - 1)

    fun atomicMass(symbol: String): Double? = bySymbol[symbol]?.mass

    fun search(query: String): List<ChemicalElement> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return elements
        return elements.filter {
            it.symbol.lowercase() == q ||
                it.symbol.lowercase().startsWith(q) ||
                it.name.lowercase().contains(q) ||
                it.number.toString() == q
        }
    }

    fun periodOf(z: Int): Int = when {
        z <= 2 -> 1
        z <= 10 -> 2
        z <= 18 -> 3
        z <= 36 -> 4
        z <= 54 -> 5
        z <= 86 -> 6
        else -> 7
    }

    fun blockOf(z: Int): String = when {
        z in 57..70 || z in 89..102 -> "f"
        z in listOf(1, 2) || z in 3..4 || z in 11..12 || z in 19..20 ||
            z in 37..38 || z in 55..56 || z in 87..88 -> "s"
        z in 21..30 || z in 39..48 || z in 71..80 || z in 103..112 -> "d"
        else -> "p"
    }

    /** Columna en la tabla larga de 18 columnas. Null para lantánidos y actínidos. */
    fun groupOf(z: Int): Int? = when (z) {
        1 -> 1
        2 -> 18
        in 3..4 -> if (z == 3) 1 else 2
        in 5..10 -> z + 8
        in 11..12 -> if (z == 11) 1 else 2
        in 13..18 -> z
        in 19..20 -> if (z == 19) 1 else 2
        in 21..30 -> z - 18
        in 31..36 -> z - 18
        in 37..38 -> if (z == 37) 1 else 2
        in 39..48 -> z - 36
        in 49..54 -> z - 36
        in 55..56 -> if (z == 55) 1 else 2
        in 57..70 -> null
        in 71..80 -> z - 68
        in 81..86 -> z - 68
        in 87..88 -> if (z == 87) 1 else 2
        in 89..102 -> null
        in 103..112 -> z - 100
        in 113..118 -> z - 100
        else -> null
    }

    /** Fila y columna dentro de la cuadrícula de 18 columnas, incluidas las dos filas de abajo. */
    fun gridPosition(z: Int): Pair<Int, Int> {
        if (z in 57..70) return 9 to (z - 57 + 3)
        if (z in 89..102) return 10 to (z - 89 + 3)
        val group = groupOf(z) ?: return 9 to 3
        return periodOf(z) to group
    }

    // ------------------------------------------------------------------
    // Configuración electrónica
    // ------------------------------------------------------------------

    private val madelungOrder = listOf(
        "1s" to 2, "2s" to 2, "2p" to 6, "3s" to 2, "3p" to 6, "4s" to 2, "3d" to 10,
        "4p" to 6, "5s" to 2, "4d" to 10, "5p" to 6, "6s" to 2, "4f" to 14, "5d" to 10,
        "6p" to 6, "7s" to 2, "5f" to 14, "6d" to 10, "7p" to 6
    )

    /**
     * Excepciones reales a la regla de Madelung. La regla predice bien la mayoría
     * de los casos, pero unos veinte elementos se salen de ella porque un orbital
     * semilleno o lleno es más estable.
     */
    private val configurationExceptions = mapOf(
        24 to "[Ar] 3d⁵ 4s¹",
        29 to "[Ar] 3d¹⁰ 4s¹",
        41 to "[Kr] 4d⁴ 5s¹",
        42 to "[Kr] 4d⁵ 5s¹",
        44 to "[Kr] 4d⁷ 5s¹",
        45 to "[Kr] 4d⁸ 5s¹",
        46 to "[Kr] 4d¹⁰",
        47 to "[Kr] 4d¹⁰ 5s¹",
        57 to "[Xe] 5d¹ 6s²",
        58 to "[Xe] 4f¹ 5d¹ 6s²",
        64 to "[Xe] 4f⁷ 5d¹ 6s²",
        78 to "[Xe] 4f¹⁴ 5d⁹ 6s¹",
        79 to "[Xe] 4f¹⁴ 5d¹⁰ 6s¹",
        89 to "[Rn] 6d¹ 7s²",
        90 to "[Rn] 6d² 7s²",
        91 to "[Rn] 5f² 6d¹ 7s²",
        92 to "[Rn] 5f³ 6d¹ 7s²",
        93 to "[Rn] 5f⁴ 6d¹ 7s²",
        96 to "[Rn] 5f⁷ 6d¹ 7s²"
    )

    private val nobleCores = listOf(86 to "Rn", 54 to "Xe", 36 to "Kr", 18 to "Ar", 10 to "Ne", 2 to "He")

    fun configurationOf(atomicNumber: Int, abbreviated: Boolean = true): String {
        if (atomicNumber !in 1..118) return ""
        configurationExceptions[atomicNumber]?.let { if (abbreviated) return it }

        var remaining = atomicNumber
        val filled = mutableListOf<Pair<String, Int>>()
        for ((orbital, capacity) in madelungOrder) {
            if (remaining <= 0) break
            val electrons = minOf(remaining, capacity)
            filled += orbital to electrons
            remaining -= electrons
        }
        if (!abbreviated) return filled.joinToString(" ") { "${it.first}${superscript(it.second)}" }

        val core = nobleCores.firstOrNull { it.first < atomicNumber }
        if (core == null) return filled.joinToString(" ") { "${it.first}${superscript(it.second)}" }

        var coreElectrons = core.first
        val tail = mutableListOf<Pair<String, Int>>()
        for ((orbital, electrons) in filled) {
            if (coreElectrons >= electrons) {
                coreElectrons -= electrons
            } else {
                tail += orbital to (electrons - coreElectrons)
                coreElectrons = 0
            }
        }
        return "[${core.second}] " + tail.joinToString(" ") { "${it.first}${superscript(it.second)}" }
    }

    fun valenceElectrons(atomicNumber: Int): Int? {
        val element = byNumber(atomicNumber) ?: return null
        val group = element.group ?: return null
        return when {
            group <= 2 -> group
            group >= 13 -> group - 10
            else -> null
        }
    }

    private fun superscript(value: Int): String {
        val digits = "⁰¹²³⁴⁵⁶⁷⁸⁹"
        return value.toString().map { digits[it - '0'] }.joinToString("")
    }

    fun kelvinToCelsius(kelvin: Double): Double = kelvin - 273.15

    fun formatTemperature(kelvin: Double?): String =
        if (kelvin == null) "—"
        else "${MathEngine.formatNumber(kelvinToCelsius(kelvin), 1)} °C  ·  ${MathEngine.formatNumber(kelvin, 1)} K"

    /** Estado del elemento a la temperatura indicada, para el deslizador de la ficha. */
    fun stateAt(element: ChemicalElement, kelvin: Double): String {
        val melting = element.meltingPointK ?: return "Desconocido"
        val boiling = element.boilingPointK
        return when {
            kelvin < melting -> "Sólido"
            boiling != null && kelvin >= boiling -> "Gas"
            else -> "Líquido"
        }
    }
}

/**
 * Constantes físicas fundamentales (CODATA 2022).
 *
 * Tras la redefinición del SI de 2019, varias son EXACTAS por definición: no
 * tienen incertidumbre porque son las que definen las unidades. Las demás se
 * miden, y la peor conocida sigue siendo la constante de gravitación.
 */
data class PhysicalConstant(
    val symbol: String,
    val name: String,
    val value: Double,
    val unit: String,
    val exact: Boolean,
    val note: String = ""
)

object PhysicsConstants {
    val all: List<PhysicalConstant> = listOf(
        PhysicalConstant("c", "Velocidad de la luz en el vacío", 299_792_458.0, "m/s", true,
            "Exacta: define el metro."),
        PhysicalConstant("h", "Constante de Planck", 6.62607015e-34, "J·s", true,
            "Exacta: define el kilogramo."),
        PhysicalConstant("e", "Carga elemental", 1.602176634e-19, "C", true,
            "Exacta: define el amperio."),
        PhysicalConstant("k", "Constante de Boltzmann", 1.380649e-23, "J/K", true,
            "Exacta: define el kelvin."),
        PhysicalConstant("Nₐ", "Número de Avogadro", 6.02214076e23, "1/mol", true,
            "Exacta: define el mol."),
        PhysicalConstant("R", "Constante de los gases", 8.314462618, "J/(mol·K)", true,
            "R = Nₐ · k, por lo tanto también es exacta."),
        PhysicalConstant("G", "Constante de gravitación universal", 6.67430e-11, "m³/(kg·s²)", false,
            "Es la constante fundamental peor conocida: 22 partes por millón de incertidumbre."),
        PhysicalConstant("g", "Aceleración de la gravedad estándar", 9.80665, "m/s²", true,
            "Valor convencional acordado; varía con la latitud y la altura."),
        PhysicalConstant("mₑ", "Masa del electrón", 9.1093837139e-31, "kg", false),
        PhysicalConstant("mₚ", "Masa del protón", 1.67262192595e-27, "kg", false),
        PhysicalConstant("mₙ", "Masa del neutrón", 1.67492750056e-27, "kg", false),
        PhysicalConstant("ε₀", "Permitividad del vacío", 8.8541878188e-12, "F/m", false),
        PhysicalConstant("μ₀", "Permeabilidad del vacío", 1.25663706127e-6, "N/A²", false),
        PhysicalConstant("k_e", "Constante de Coulomb", 8.9875517862e9, "N·m²/C²", false,
            "k = 1/(4πε₀)"),
        PhysicalConstant("σ", "Constante de Stefan-Boltzmann", 5.670374419e-8, "W/(m²·K⁴)", true),
        PhysicalConstant("F", "Constante de Faraday", 96485.33212, "C/mol", true),
        PhysicalConstant("u", "Unidad de masa atómica", 1.66053906892e-27, "kg", false),
        PhysicalConstant("atm", "Presión atmosférica estándar", 101325.0, "Pa", true)
    )

    fun bySymbol(symbol: String): PhysicalConstant? = all.firstOrNull { it.symbol == symbol }

    fun format(constant: PhysicalConstant): String {
        val value = constant.value
        return if (value != 0.0 && (kotlin.math.abs(value) >= 1e5 || kotlin.math.abs(value) < 1e-3)) {
            val exponent = kotlin.math.floor(kotlin.math.log10(kotlin.math.abs(value))).roundToInt()
            val mantissa = value / Math.pow(10.0, exponent.toDouble())
            "${MathEngine.formatNumber(mantissa, 8)} × 10^$exponent ${constant.unit}"
        } else {
            "${MathEngine.formatNumber(value, 8)} ${constant.unit}"
        }
    }
}
