package com.ganageo.app.tools

import java.util.Locale

/**
 * Motor del cronometro, el temporizador y las sesiones de enfoque.
 *
 * La regla que evita el bug clasico de los cronometros: nunca se suma "+1
 * segundo" a un contador. Se guarda la marca del reloj monotonico
 * (SystemClock.elapsedRealtime) al arrancar y el tiempo mostrado siempre se
 * recalcula contra el reloj. Asi no se acumula desfase, no se congela con la
 * pantalla apagada y no se descuadra si el usuario cambia la hora del telefono.
 *
 * El reloj monotonico se reinicia a cero cuando se reinicia el telefono, asi
 * que se guarda tambien un ancla de hora normal para detectar ese caso.
 */

/** Fase de una sesion de enfoque. */
enum class FocusPhase(val label: String, val shortLabel: String) {
    FOCUS("Enfoque", "Enfoque"),
    SHORT_BREAK("Descanso", "Descanso"),
    LONG_BREAK("Descanso largo", "Descanso +")
}

/**
 * Preset de estudio.
 *
 * Pomodoro no es magia: el ensayo de Smits, Wenzel y De Bruin (2025) no
 * encontro ventaja frente a descansos autorregulados. Lo que si sostiene la
 * evidencia es que hacer pausas y repartir el estudio funciona mejor que una
 * maraton seguida, de ahi que haya varias duraciones y no solo 25/5.
 */
data class FocusPreset(
    val name: String,
    val focusMinutes: Int,
    val breakMinutes: Int,
    val cyclesBeforeLongBreak: Int,
    val longBreakMinutes: Int,
    val note: String
) {
    val focusMillis: Long get() = focusMinutes * 60_000L
    val breakMillis: Long get() = breakMinutes * 60_000L
    val longBreakMillis: Long get() = longBreakMinutes * 60_000L

    fun millisFor(phase: FocusPhase): Long = when (phase) {
        FocusPhase.FOCUS -> focusMillis
        FocusPhase.SHORT_BREAK -> breakMillis
        FocusPhase.LONG_BREAK -> longBreakMillis
    }
}

/** Ancla de tiempo: reloj monotonico + hora normal para sobrevivir reinicios. */
data class TimeAnchor(val realtime: Long, val wallClock: Long)

object FocusLab {

    val presets: List<FocusPreset> = listOf(
        FocusPreset(
            name = "Pomodoro 25/5",
            focusMinutes = 25,
            breakMinutes = 5,
            cyclesBeforeLongBreak = 4,
            longBreakMinutes = 15,
            note = "El clasico. Util para arrancar cuando cuesta empezar."
        ),
        FocusPreset(
            name = "Enfoque 50/10",
            focusMinutes = 50,
            breakMinutes = 10,
            cyclesBeforeLongBreak = 3,
            longBreakMinutes = 20,
            note = "Para temas que necesitan tomar impulso: menos cortes."
        ),
        FocusPreset(
            name = "Bloque 90/20",
            focusMinutes = 90,
            breakMinutes = 20,
            cyclesBeforeLongBreak = 2,
            longBreakMinutes = 30,
            note = "Sigue el ciclo natural de atencion de hora y media."
        ),
        FocusPreset(
            name = "Repaso 15/3",
            focusMinutes = 15,
            breakMinutes = 3,
            cyclesBeforeLongBreak = 4,
            longBreakMinutes = 12,
            note = "Tandas cortas para repasar tarjetas o formulas."
        )
    )

    val default: FocusPreset get() = presets.first()

    /** Cuanto tiempo paso realmente, aunque el telefono se haya reiniciado. */
    fun elapsedSince(anchor: TimeAnchor, nowRealtime: Long, nowWallClock: Long): Long {
        val monotonic = nowRealtime - anchor.realtime
        // Si el reloj monotonico va hacia atras, hubo reinicio: se cae al reloj normal.
        if (monotonic < 0) return (nowWallClock - anchor.wallClock).coerceAtLeast(0L)
        return monotonic
    }

    /**
     * Cuanto falta para una cuenta regresiva.
     *
     * Se prefiere el reloj monotonico, pero si el telefono se reinicio ese
     * reloj volvio a cero y el calculo daria un tiempo enorme: en ese caso se
     * usa la hora normal, que si sobrevive al reinicio.
     */
    fun remainingUntil(endsAt: TimeAnchor, nowRealtime: Long, nowWallClock: Long): Long {
        val byRealtime = endsAt.realtime - nowRealtime
        val byWallClock = endsAt.wallClock - nowWallClock
        val rebooted = byRealtime > byWallClock + 5_000L
        return (if (rebooted) byWallClock else byRealtime).coerceAtLeast(0L)
    }

    /** Que fase toca despues, y cuantos enfoques van completados. */
    fun nextPhase(current: FocusPhase, completedFocus: Int, preset: FocusPreset): FocusPhase =
        when (current) {
            FocusPhase.FOCUS ->
                if (preset.cyclesBeforeLongBreak > 0 && completedFocus % preset.cyclesBeforeLongBreak == 0) {
                    FocusPhase.LONG_BREAK
                } else {
                    FocusPhase.SHORT_BREAK
                }
            FocusPhase.SHORT_BREAK, FocusPhase.LONG_BREAK -> FocusPhase.FOCUS
        }

    /** hh:mm:ss.cc o mm:ss.cc, con ancho fijo para que los digitos no bailen. */
    fun formatStopwatch(millis: Long): String {
        val safe = millis.coerceAtLeast(0L)
        val totalSeconds = safe / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        val centis = (safe % 1000) / 10
        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d.%02d", hours, minutes, seconds, centis)
        } else {
            String.format(Locale.US, "%02d:%02d.%02d", minutes, seconds, centis)
        }
    }

    /** Cuenta regresiva: se redondea hacia arriba para que 0 signifique cero real. */
    fun formatTimer(millis: Long): String {
        val safe = millis.coerceAtLeast(0L)
        val totalSeconds = (safe + 999) / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatDuration(seconds: Long): String {
        val safe = seconds.coerceAtLeast(0L)
        val hours = safe / 3600
        val minutes = (safe % 3600) / 60
        val secs = safe % 60
        return if (hours > 0) String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, secs)
        else String.format(Locale.US, "%02d:%02d", minutes, secs)
    }

    /** "1 h 25 min" para totales acumulados. */
    fun formatAccumulated(millis: Long): String {
        val minutes = millis / 60_000L
        val hours = minutes / 60
        val rest = minutes % 60
        return when {
            minutes <= 0 -> "0 min"
            hours <= 0 -> "$rest min"
            rest == 0L -> "$hours h"
            else -> "$hours h $rest min"
        }
    }

    /** Progreso 0..1 de una cuenta regresiva. */
    fun progress(remaining: Long, total: Long): Float =
        if (total <= 0L) 0f else (1f - remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)
}
