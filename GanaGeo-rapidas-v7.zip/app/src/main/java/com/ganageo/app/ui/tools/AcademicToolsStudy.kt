package com.ganageo.app.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ganageo.app.data.AcademicPlannerStore
import com.ganageo.app.data.StudyDeckStore
import com.ganageo.app.data.StudyPlannerProStore
import com.ganageo.app.tools.CardSchedule
import com.ganageo.app.tools.GradeEngine
import com.ganageo.app.tools.GradeItem
import com.ganageo.app.tools.Sm2Scheduler
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ---------------------------------------------------------------------------
// Flashcards
// ---------------------------------------------------------------------------

/**
 * Flashcards con repetición espaciada.
 *
 * No muestra tarjetas al azar: cada respuesta ajusta el factor de facilidad de
 * esa tarjeta y el siguiente repaso se aleja o se acerca según lo bien que te
 * salió. Lo que dominas casi no vuelve a aparecer; lo que fallas vuelve mañana.
 */
@Composable
fun FlashcardsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { StudyDeckStore(context) }
    val cards by store.cards.collectAsState(initial = emptyList())

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var deck by rememberSaveable { mutableStateOf("General") }
    var question by rememberSaveable { mutableStateOf("") }
    var answer by rememberSaveable { mutableStateOf("") }
    var importText by rememberSaveable { mutableStateOf("") }
    var revealed by rememberSaveable { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    val decks = cards.map { it.deck }.distinct().sorted()
    val deckCards = cards.filter { it.deck == deck }
    val now = System.currentTimeMillis()
    val due = deckCards.filter { it.dueAt <= now }
    val current = due.firstOrNull()

    ScienceShell(
        title = "Flashcards",
        subtitle = "${due.size} por repasar en «$deck»",
        onBack = onBack
    ) {
        StudioTabs(listOf("Practicar", "Tarjetas", "Progreso"), tab) {
            tab = it
            revealed = false
        }

        if (decks.size > 1) {
            ScienceCard("Mazo") {
                StudioChipRow {
                    decks.forEach { name ->
                        StudioChip(
                            label = name,
                            active = deck == name,
                            onClick = {
                                deck = name
                                revealed = false
                            },
                            caption = "${cards.count { it.deck == name }}"
                        )
                    }
                }
            }
        }

        when (tab) {
            0 -> {
                if (current == null) {
                    ScienceCard("Todo repasado") {
                        StudioHint(
                            if (deckCards.isEmpty()) "Este mazo está vacío. Crea tarjetas en la pestaña «Tarjetas»."
                            else "No queda nada por repasar hoy. Vuelve mañana: así funciona la repetición espaciada."
                        )
                        val next = deckCards.minByOrNull { it.dueAt }
                        if (next != null && deckCards.isNotEmpty()) {
                            val days = ((next.dueAt - now) / 86_400_000L).coerceAtLeast(0)
                            ScienceRow("Próximo repaso", if (days == 0L) "hoy" else "en $days días")
                        }
                    }
                } else {
                    ScienceCard("Pregunta") {
                        Text(
                            current.question,
                            color = StudioTheme.TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 18.sp,
                            lineHeight = 24.sp
                        )
                        if (revealed) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(StudioTheme.Accent.copy(alpha = 0.12f))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    current.answer,
                                    color = StudioTheme.Accent,
                                    fontSize = 17.sp,
                                    lineHeight = 23.sp
                                )
                            }
                        }
                    }

                    if (!revealed) {
                        WorkActionButton("Ver respuesta", { revealed = true }, Icons.Rounded.PlayArrow)
                        StudioHint("Intenta recordarla antes de mirar: el esfuerzo es lo que fija el recuerdo.")
                    } else {
                        val schedule = CardSchedule(
                            easeFactor = current.easeFactor,
                            intervalDays = current.intervalDays,
                            repetitions = current.repetitions,
                            lapses = current.lapses,
                            dueAt = current.dueAt,
                            lastReviewedAt = current.lastReviewedAt
                        )
                        ScienceCard("¿Qué tal salió?") {
                            Sm2Scheduler.Answer.entries.forEach { option ->
                                val preview = Sm2Scheduler.review(schedule, option.quality, now, applyFuzz = false)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    StudioChip(
                                        label = option.label,
                                        active = false,
                                        onClick = {
                                            scope.launch {
                                                store.reviewWithSm2(current.id, option.quality)
                                                revealed = false
                                            }
                                        },
                                        caption = Sm2Scheduler.describeNext(preview)
                                    )
                                    androidx.compose.foundation.layout.Spacer(Modifier.size(10.dp))
                                    Text(
                                        option.hint,
                                        color = StudioTheme.TextSecondary,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                        if (Sm2Scheduler.isLeech(schedule)) {
                            LegalNote(
                                "Esta tarjeta ya la fallaste ${current.lapses} veces. Suele significar que pregunta " +
                                    "demasiadas cosas a la vez: pártela en dos más simples."
                            )
                        }
                    }
                }
            }

            1 -> {
                ScienceCard("Nueva tarjeta") {
                    ScienceTextArea(question, { question = it }, "Pregunta", "¿Qué mide el índice de discriminación?", minHeight = 80)
                    ScienceTextArea(answer, { answer = it }, "Respuesta", "Cuánto separa a quien domina el tema de quien no", minHeight = 80)
                    StudioTextField(deck, { deck = it }, "Mazo", modifier = Modifier.fillMaxWidth())
                    WorkActionButton("Guardar tarjeta", {
                        scope.launch {
                            runCatching { store.addCard(question, answer, deck) }
                                .onSuccess {
                                    question = ""
                                    answer = ""
                                    message = "Tarjeta guardada."
                                }
                                .onFailure { message = it.message ?: "No se pudo guardar." }
                        }
                    }, Icons.Rounded.Add)
                    StudioHint(
                        "Una idea por tarjeta. Las de tipo «enumera los diez países» casi siempre se fallan: " +
                            "conviene partirlas."
                    )
                }

                ScienceCard("Importar en bloque") {
                    ScienceTextArea(
                        importText, { importText = it },
                        "Pregunta ; Respuesta (una por línea)",
                        "Capital de Perú ; Lima\nAño de la independencia ; 1821",
                        minHeight = 100
                    )
                    WorkActionButton("Importar al mazo «$deck»", {
                        scope.launch {
                            runCatching { store.importDeck(importText, deck) }
                                .onSuccess {
                                    message = "Se importaron $it tarjetas."
                                    importText = ""
                                }
                                .onFailure { message = it.message ?: "No se pudo importar." }
                        }
                    }, Icons.Rounded.Add)
                }

                deckCards.take(50).forEach { card ->
                    ScienceCard(null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    card.question,
                                    color = StudioTheme.TextPrimary,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 2
                                )
                                Text(
                                    "Facilidad ${String.format("%.2f", card.easeFactor)} · " +
                                        "intervalo ${card.intervalDays} d · fallos ${card.lapses}",
                                    color = StudioTheme.TextSecondary,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            IconButton(onClick = { scope.launch { store.deleteCard(card.id) } }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = StudioTheme.TextSecondary)
                            }
                        }
                    }
                }
            }

            else -> {
                val newCards = deckCards.count { it.repetitions == 0 && it.lastReviewedAt == 0L }
                val mature = deckCards.count { it.intervalDays >= 21 }
                val reviews = deckCards.sumOf { it.reviews }
                val correct = deckCards.sumOf { it.correctReviews }
                val leeches = deckCards.count { it.lapses >= Sm2Scheduler.LEECH_THRESHOLD }

                WorkTotals(
                    rows = listOf(
                        "Tarjetas del mazo" to deckCards.size.toString(),
                        "Nuevas" to newCards.toString(),
                        "Maduras (21 días o más)" to mature.toString(),
                        "Repasos hechos" to reviews.toString()
                    ),
                    total = "Retención" to
                        if (reviews == 0) "—"
                        else "${Sm2Scheduler.retention(correct, reviews).toInt()} %",
                    note = if (reviews == 0) "Empieza a practicar para ver tu retención."
                    else "Una retención sana ronda el 85-90 %. Si es más alta, estás repasando de más."
                )

                if (leeches > 0) {
                    LegalNote("Tienes $leeches tarjetas problemáticas. Reescríbelas más simples.")
                }

                ScienceCard("Cómo funciona") {
                    StudioHint(
                        "Cada tarjeta arranca con un factor de facilidad de 2,5. Si respondes bien, el intervalo " +
                            "se multiplica por ese factor; si fallas, vuelve a empezar. Los intervalos se " +
                            "reparten unos días para que no te caigan todos los repasos el mismo día."
                    )
                }
            }
        }

        message?.let { StudioHint(it) }
    }
}

// ---------------------------------------------------------------------------
// Planificador de estudio
// ---------------------------------------------------------------------------

/**
 * Planificador de estudio.
 *
 * El pomodoro son 25 minutos de trabajo y 5 de descanso, con una pausa larga
 * cada cuatro ciclos. Lo importante no es el número exacto sino cerrar bloques
 * sin interrupciones.
 */
@Composable
fun StudyPlannerProScreen(onBack: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { StudyPlannerProStore(context) }
    val data by store.data.collectAsState(initial = com.ganageo.app.data.PlannerProData())

    var tab by rememberSaveable { mutableIntStateOf(0) }

    // Pomodoro
    var workMinutes by rememberSaveable { mutableIntStateOf(25) }
    var breakMinutes by rememberSaveable { mutableIntStateOf(5) }
    var longBreakMinutes by rememberSaveable { mutableIntStateOf(20) }
    var secondsLeft by rememberSaveable { mutableIntStateOf(25 * 60) }
    var running by rememberSaveable { mutableStateOf(false) }
    var onBreak by rememberSaveable { mutableStateOf(false) }
    var completed by rememberSaveable { mutableIntStateOf(0) }
    var pomodoroCourse by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(running, onBreak) {
        while (running && secondsLeft > 0) {
            delay(1000)
            secondsLeft -= 1
        }
        if (running && secondsLeft <= 0) {
            running = false
            if (!onBreak) {
                completed += 1
                if (pomodoroCourse.isNotBlank()) {
                    runCatching { store.logStudy(pomodoroCourse, workMinutes) }
                }
                onBreak = true
                secondsLeft = if (completed % 4 == 0) longBreakMinutes * 60 else breakMinutes * 60
                onMessage("Pomodoro completado. Toca descansar.")
            } else {
                onBreak = false
                secondsLeft = workMinutes * 60
                onMessage("Descanso terminado. A por el siguiente bloque.")
            }
        }
    }

    ScienceShell(
        title = "Planificador de estudio",
        subtitle = if (onBreak) "Descanso" else "$completed pomodoros hoy",
        onBack = onBack
    ) {
        StudioTabs(listOf("Pomodoro", "Horario", "Metas", "Asistencia"), tab) { tab = it }

        when (tab) {
            0 -> {
                ScienceCard(if (onBreak) "Descanso" else "Bloque de estudio", accent = true) {
                    Text(
                        "%02d:%02d".format(secondsLeft / 60, secondsLeft % 60),
                        color = StudioTheme.Accent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 52.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(StudioTheme.Outline)
                    ) {
                        val total = if (onBreak) {
                            (if (completed % 4 == 0) longBreakMinutes else breakMinutes) * 60
                        } else workMinutes * 60
                        val progress = if (total <= 0) 0f else 1f - secondsLeft.toFloat() / total
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progress.coerceIn(0f, 1f))
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(StudioTheme.Accent)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioChip(
                            label = if (running) "Pausar" else "Empezar",
                            active = running,
                            onClick = { running = !running }
                        )
                        StudioChip("Reiniciar", false, onClick = {
                            running = false
                            onBreak = false
                            secondsLeft = workMinutes * 60
                        })
                        StudioChip("Saltar", false, onClick = {
                            running = false
                            secondsLeft = 0
                        })
                    }
                    StudioTextField(pomodoroCourse, { pomodoroCourse = it }, "Curso o tema", modifier = Modifier.fillMaxWidth())
                }

                ScienceCard("Duraciones") {
                    StudioChipRow {
                        listOf(25 to 5, 50 to 10, 90 to 20).forEach { (work, rest) ->
                            StudioChip(
                                label = "$work/$rest",
                                active = workMinutes == work && breakMinutes == rest,
                                onClick = {
                                    workMinutes = work
                                    breakMinutes = rest
                                    if (!running) secondsLeft = work * 60
                                }
                            )
                        }
                    }
                    StudioHint(
                        "El pomodoro clásico es 25/5 con descanso largo de 15 a 30 minutos cada cuatro ciclos. " +
                            "Los bloques de 50 o 90 minutos funcionan mejor para trabajo profundo."
                    )
                    ScienceRow("Descanso largo", "$longBreakMinutes min")
                    StudioChipRow {
                        listOf(15, 20, 30).forEach { minutes ->
                            StudioChip(
                                label = "$minutes min",
                                active = longBreakMinutes == minutes,
                                onClick = { longBreakMinutes = minutes }
                            )
                        }
                    }
                }

                val todayMinutes = data.logs
                    .filter { System.currentTimeMillis() - it.timestamp < 86_400_000L }
                    .sumOf { it.minutes }
                WorkTotals(
                    rows = listOf(
                        "Pomodoros completados" to completed.toString(),
                        "Minutos registrados hoy" to todayMinutes.toString()
                    ),
                    total = "Tiempo enfocado" to "${todayMinutes / 60} h ${todayMinutes % 60} min"
                )
            }

            1 -> {
                var course by rememberSaveable { mutableStateOf("") }
                var day by rememberSaveable { mutableIntStateOf(1) }
                var start by rememberSaveable { mutableStateOf("08:00") }
                var end by rememberSaveable { mutableStateOf("10:00") }
                var room by rememberSaveable { mutableStateOf("") }
                val dayNames = listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")

                ScienceCard("Añadir clase") {
                    StudioTextField(course, { course = it }, "Curso", modifier = Modifier.fillMaxWidth())
                    StudioChipRow {
                        dayNames.forEachIndexed { index, name ->
                            StudioChip(name, day == index + 1, onClick = { day = index + 1 })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioTextField(start, { start = it }, "Inicio", modifier = Modifier.weight(1f))
                        StudioTextField(end, { end = it }, "Fin", modifier = Modifier.weight(1f))
                        StudioTextField(room, { room = it }, "Aula", modifier = Modifier.weight(1f))
                    }
                    WorkActionButton("Guardar", {
                        scope.launch {
                            runCatching { store.addSchedule(course, day, start, end, room) }
                                .onSuccess { course = "" }
                                .onFailure { onMessage(it.message ?: "No se pudo guardar.") }
                        }
                    }, Icons.Rounded.Add)
                }

                (1..7).forEach { dayIndex ->
                    val entries = data.schedule.filter { it.dayOfWeek == dayIndex }.sortedBy { it.startTime }
                    if (entries.isNotEmpty()) {
                        ScienceCard(dayNames[dayIndex - 1]) {
                            entries.forEach { entry ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            entry.course,
                                            color = StudioTheme.TextPrimary,
                                            fontWeight = FontWeight.SemiBold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            "${entry.startTime} - ${entry.endTime}" +
                                                if (entry.room.isBlank()) "" else " · ${entry.room}",
                                            color = StudioTheme.TextSecondary,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                    IconButton(onClick = { scope.launch { store.deleteSchedule(entry.id) } }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = StudioTheme.TextSecondary)
                                    }
                                }
                            }
                        }
                    }
                }
                if (data.schedule.isEmpty()) StudioHint("Aún no has cargado tu horario.")
            }

            2 -> {
                var goalTitle by rememberSaveable { mutableStateOf("") }
                var goalMinutes by rememberSaveable { mutableStateOf("120") }

                ScienceCard("Nueva meta") {
                    StudioTextField(goalTitle, { goalTitle = it }, "Meta", modifier = Modifier.fillMaxWidth())
                    ScienceNumberField(goalMinutes, { goalMinutes = it }, "Minutos objetivo", Modifier.fillMaxWidth())
                    WorkActionButton("Crear meta", {
                        scope.launch {
                            runCatching { store.addGoal(goalTitle, goalMinutes.toIntOrNull() ?: 60) }
                                .onSuccess { goalTitle = "" }
                                .onFailure { onMessage(it.message ?: "No se pudo crear.") }
                        }
                    }, Icons.Rounded.Add)
                }

                data.goals.forEach { goal ->
                    ScienceCard(goal.title) {
                        val progress = if (goal.targetMinutes <= 0) 0f
                        else (goal.completedMinutes.toFloat() / goal.targetMinutes).coerceIn(0f, 1f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(StudioTheme.Outline)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(progress)
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(StudioTheme.Accent)
                            )
                        }
                        ScienceRow(
                            "Avance",
                            "${goal.completedMinutes} / ${goal.targetMinutes} min",
                            highlight = progress >= 1f
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(15, 25, 50).forEach { minutes ->
                                StudioChip("+$minutes", false, onClick = {
                                    scope.launch { store.addGoalProgress(goal.id, minutes) }
                                })
                            }
                            StudioChip("Quitar", false, onClick = {
                                scope.launch { store.deleteGoal(goal.id) }
                            })
                        }
                    }
                }
                if (data.goals.isEmpty()) StudioHint("Ponte una meta concreta: «Cálculo, 3 horas esta semana».")
            }

            else -> {
                var attendanceCourse by rememberSaveable { mutableStateOf("") }
                var attended by rememberSaveable { mutableStateOf("") }
                var total by rememberSaveable { mutableStateOf("") }
                var limit by rememberSaveable { mutableStateOf("30") }

                ScienceCard("Registrar asistencia") {
                    StudioTextField(attendanceCourse, { attendanceCourse = it }, "Curso", modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(attended, { attended = it }, "Asistí", Modifier.weight(1f))
                        ScienceNumberField(total, { total = it }, "Sesiones", Modifier.weight(1f))
                        ScienceNumberField(limit, { limit = it }, "Límite %", Modifier.weight(1f))
                    }
                    WorkActionButton("Guardar", {
                        scope.launch {
                            runCatching {
                                store.saveAttendance(
                                    attendanceCourse,
                                    attended.toIntOrNull() ?: 0,
                                    total.toIntOrNull() ?: 0
                                )
                            }.onSuccess { attendanceCourse = "" }
                                .onFailure { onMessage(it.message ?: "No se pudo guardar.") }
                        }
                    }, Icons.Rounded.Add)
                    StudioHint(
                        "En muchas universidades peruanas acumular 30 % de inasistencias inhabilita para el examen " +
                            "final. Ajusta el límite según tu reglamento."
                    )
                }

                data.attendance.forEach { record ->
                    val missed = (record.total - record.attended).coerceAtLeast(0)
                    val status = GradeEngine.attendance(
                        missed,
                        record.total,
                        limit.toDoubleOrNull() ?: 30.0
                    )
                    ScienceCard(record.course) {
                        ScienceRow("Asistencias", "${record.attended} de ${record.total}")
                        ScienceRow(
                            "Inasistencias",
                            "$missed (${String.format("%.1f", status.missedPercent)} %)",
                            highlight = status.disqualified || status.warning
                        )
                        if (status.disqualified) {
                            ScienceError(status.message)
                        } else {
                            StudioHint(status.message)
                        }
                        Row {
                            androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                            IconButton(onClick = { scope.launch { store.deleteAttendance(record.id) } }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = StudioTheme.TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Agenda académica
// ---------------------------------------------------------------------------

private class GradeRow(name: String = "", score: String = "", weight: String = "") {
    var name by mutableStateOf(name)
    var score by mutableStateOf(score)
    var weight by mutableStateOf(weight)
}

/**
 * Agenda académica.
 *
 * Además de las tareas incluye la pregunta que todo estudiante se hace antes del
 * examen final: cuánto necesito para aprobar. Y responde honestamente cuando ya
 * no alcanza.
 */
@Composable
fun AcademicPlannerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { AcademicPlannerStore(context) }
    val tasks by store.tasks.collectAsState(initial = emptyList())

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var title by rememberSaveable { mutableStateOf("") }
    var course by rememberSaveable { mutableStateOf("") }
    var dueDate by rememberSaveable { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    var scaleIndex by rememberSaveable { mutableIntStateOf(0) }
    var target by rememberSaveable { mutableStateOf("11") }
    val gradeRows = remember { mutableStateListOf(GradeRow("Práctica 1", "", "30"), GradeRow("Examen parcial", "", "30")) }

    val pending = tasks.filter { !it.completed }
    val scale = GradeEngine.scales[scaleIndex.coerceIn(0, GradeEngine.scales.lastIndex)]

    ScienceShell(
        title = "Agenda académica",
        subtitle = "${pending.size} tareas pendientes",
        onBack = onBack
    ) {
        StudioTabs(listOf("Tareas", "Notas"), tab) { tab = it }

        if (tab == 0) {
            ScienceCard("Nueva tarea") {
                StudioTextField(title, { title = it }, "Tarea", modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StudioTextField(course, { course = it }, "Curso", modifier = Modifier.weight(1f))
                    StudioTextField(dueDate, { dueDate = it }, "Entrega", placeholder = "15/09", modifier = Modifier.weight(1f))
                }
                WorkActionButton("Agregar", {
                    scope.launch {
                        runCatching { store.addTask(title, course, dueDate) }
                            .onSuccess {
                                title = ""
                                message = null
                            }
                            .onFailure { message = it.message ?: "No se pudo agregar." }
                    }
                }, Icons.Rounded.Add)
            }

            tasks.groupBy { it.course.ifBlank { "Sin curso" } }.forEach { (group, list) ->
                ScienceCard(group) {
                    list.sortedBy { it.completed }.forEach { task ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StudioChip(
                                label = if (task.completed) "Hecha" else "Pendiente",
                                active = task.completed,
                                onClick = { scope.launch { store.toggleCompleted(task.id) } }
                            )
                            androidx.compose.foundation.layout.Spacer(Modifier.size(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    task.title,
                                    color = if (task.completed) StudioTheme.TextSecondary else StudioTheme.TextPrimary,
                                    textDecoration = if (task.completed) TextDecoration.LineThrough else null,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                if (task.dueDate.isNotBlank()) {
                                    Text(
                                        "Entrega ${task.dueDate}",
                                        color = StudioTheme.TextSecondary,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                            IconButton(onClick = { scope.launch { store.deleteTask(task.id) } }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = StudioTheme.TextSecondary)
                            }
                        }
                    }
                }
            }
            if (tasks.isEmpty()) StudioHint("Agrega tu primera tarea o entrega.")
            if (tasks.any { it.completed }) {
                WorkActionButton("Quitar las completadas", {
                    scope.launch { store.clearCompleted() }
                }, Icons.Rounded.Delete)
            }
            message?.let { ScienceError(it) }
        } else {
            ScienceCard("Escala de calificación") {
                StudioChipRow {
                    GradeEngine.scales.forEachIndexed { index, entry ->
                        StudioChip(entry.label, scaleIndex == index, onClick = { scaleIndex = index })
                    }
                }
                StudioHint(scale.note)
            }

            ScienceCard("Evaluaciones") {
                gradeRows.forEachIndexed { index, row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        StudioTextField(row.name, { row.name = it }, "Evaluación", modifier = Modifier.weight(1.4f))
                        ScienceNumberField(row.score, { row.score = it }, "Nota", Modifier.weight(1f))
                        ScienceNumberField(row.weight, { row.weight = it }, "Peso %", Modifier.weight(1f))
                        if (gradeRows.size > 1) {
                            IconButton(onClick = { gradeRows.removeAt(index) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = StudioTheme.TextSecondary)
                            }
                        }
                    }
                }
                WorkActionButton("Agregar evaluación", { gradeRows.add(GradeRow()) }, Icons.Rounded.Add)
            }

            val items = gradeRows.mapNotNull { row ->
                val score = row.score.replace(',', '.').toDoubleOrNull()
                val weight = row.weight.replace(',', '.').toDoubleOrNull()
                if (score == null || weight == null || weight <= 0) null
                else GradeItem(row.name.ifBlank { "Evaluación" }, score, weight)
            }
            val summary = GradeEngine.weightedAverage(items, scale)

            WorkTotals(
                rows = listOf(
                    "Evaluaciones registradas" to items.size.toString(),
                    "Peso acumulado" to "${summary.accumulatedWeight.toInt()} %",
                    "Falta por evaluar" to "${summary.missingWeight.toInt()} %"
                ),
                total = "Promedio actual" to GradeEngine.format(summary.average, scale),
                note = if (items.isEmpty()) "Escribe las notas que ya tienes con su peso."
                else if (summary.passing) "Con estas notas estás aprobando."
                else "Por debajo de ${GradeEngine.format(scale.passing, scale)}: aún puedes remontar."
            )

            ScienceCard("¿Qué nota necesito?") {
                ScienceNumberField(target, { target = it }, "Nota que quieres alcanzar", Modifier.fillMaxWidth())
                val objective = target.replace(',', '.').toDoubleOrNull() ?: scale.passing
                val needed = GradeEngine.neededScore(items, summary.missingWeight, objective, scale)
                if (summary.missingWeight <= 0) {
                    StudioHint("Los pesos ya suman 100 %: no queda nada por rendir.")
                } else {
                    ScienceRow(
                        "Necesitas en lo que falta",
                        GradeEngine.format(needed.value.coerceIn(scale.minimum, scale.maximum * 1.5), scale),
                        highlight = needed.achievable
                    )
                    if (needed.achievable) StudioHint(needed.message) else ScienceError(needed.message)
                }
            }
        }
    }
}
