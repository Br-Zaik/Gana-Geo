package com.ganageo.app.tools

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * Motor de dinero.
 *
 * Los importes NUNCA se manejan con Double: 0.1 + 0.2 no da 0.3 en coma flotante
 * y en dinero eso se convierte en céntimos que no cuadran. Todo pasa por
 * BigDecimal construido desde texto, con escala fija de 2 decimales y redondeo
 * comercial (HALF_UP), que es el que espera el usuario en una boleta.
 */
object Money {

    val ZERO: BigDecimal = BigDecimal.ZERO.setScale(2)

    /** Escala de trabajo interna: se calcula con más decimales y se redondea al final. */
    const val WORK_SCALE = 8
    const val MONEY_SCALE = 2

    fun of(value: String): BigDecimal =
        parseOrNull(value) ?: throw IllegalArgumentException("Monto inválido: «$value».")

    /** Acepta coma o punto decimal y separadores de miles. Devuelve null si no es número. */
    fun parseOrNull(raw: String?): BigDecimal? {
        if (raw.isNullOrBlank()) return null
        var text = raw.trim()
            .replace("S/", "")
            .replace("$", "")
            .replace("€", "")
            .replace(" ", "")
            .replace("\u00A0", "")
        if (text.isEmpty()) return null

        val lastComma = text.lastIndexOf(',')
        val lastDot = text.lastIndexOf('.')
        text = when {
            // 1.234,56 -> el separador decimal es la coma
            lastComma > lastDot -> text.replace(".", "").replace(',', '.')
            // 1,234.56 -> el separador decimal es el punto
            lastDot > lastComma -> text.replace(",", "")
            else -> text.replace(',', '.')
        }
        return runCatching { BigDecimal(text).setScale(WORK_SCALE, RoundingMode.HALF_UP) }.getOrNull()
    }

    fun ofOrZero(raw: String?): BigDecimal = parseOrNull(raw) ?: ZERO

    fun fromCents(cents: Long): BigDecimal =
        BigDecimal(cents).divide(BigDecimal(100), MONEY_SCALE, RoundingMode.HALF_UP)

    fun toCents(value: BigDecimal): Long = round(value).multiply(BigDecimal(100)).toLong()

    /** Redondeo comercial a dos decimales. Es el que se muestra y se cobra. */
    fun round(value: BigDecimal, scale: Int = MONEY_SCALE): BigDecimal =
        value.setScale(scale, RoundingMode.HALF_UP)

    /** Redondeo bancario, para contabilidad que necesita reducir el sesgo acumulado. */
    fun roundBankers(value: BigDecimal, scale: Int = MONEY_SCALE): BigDecimal =
        value.setScale(scale, RoundingMode.HALF_EVEN)

    fun percent(value: BigDecimal, percent: BigDecimal): BigDecimal =
        value.multiply(percent).divide(BigDecimal(100), WORK_SCALE, RoundingMode.HALF_UP)

    fun divide(a: BigDecimal, b: BigDecimal): BigDecimal {
        require(b.compareTo(BigDecimal.ZERO) != 0) { "No se puede dividir entre cero." }
        return a.divide(b, WORK_SCALE, RoundingMode.HALF_UP)
    }

    fun isZero(value: BigDecimal): Boolean = value.compareTo(BigDecimal.ZERO) == 0
    fun isPositive(value: BigDecimal): Boolean = value.compareTo(BigDecimal.ZERO) > 0

    /**
     * Reparte el céntimo que sobra o falta cuando se redondean varias líneas.
     *
     * Es el clásico descuadre: si sumas los totales de cada ítem ya redondeados,
     * el resultado puede diferir del total redondeado de la suma. Aquí el residuo
     * se le asigna a la línea de mayor importe, que es donde menos se nota.
     */
    fun distributeResidue(lines: List<BigDecimal>, expectedTotal: BigDecimal): List<BigDecimal> {
        if (lines.isEmpty()) return lines
        val rounded = lines.map { round(it) }.toMutableList()
        val sum = rounded.fold(BigDecimal.ZERO) { acc, value -> acc.add(value) }
        val residue = round(expectedTotal).subtract(sum)
        if (residue.compareTo(BigDecimal.ZERO) == 0) return rounded
        val biggest = rounded.indices.maxByOrNull { rounded[it].abs() } ?: 0
        rounded[biggest] = rounded[biggest].add(residue)
        return rounded
    }

    // ------------------------------------------------------------------
    // Formato
    // ------------------------------------------------------------------

    /**
     * Formatea con el símbolo de la moneda indicada. No se usa el formateador de
     * moneda del sistema porque el usuario puede estar cotizando en una moneda
     * distinta a la de su teléfono.
     */
    fun format(value: BigDecimal, currency: CurrencyInfo = CurrencyInfo.PEN, withSymbol: Boolean = true): String {
        val symbols = DecimalFormatSymbols(Locale("es", "PE")).apply {
            decimalSeparator = '.'
            groupingSeparator = ','
        }
        val formatter = DecimalFormat("#,##0.00", symbols)
        val text = formatter.format(round(value))
        return if (withSymbol) "${currency.symbol} $text" else text
    }

    fun formatCents(cents: Long, currency: CurrencyInfo = CurrencyInfo.PEN): String =
        format(fromCents(cents), currency)

    fun formatPercent(value: BigDecimal, decimals: Int = 2): String {
        val symbols = DecimalFormatSymbols(Locale("es", "PE")).apply { decimalSeparator = '.' }
        val pattern = if (decimals <= 0) "#,##0" else "#,##0." + "0".repeat(decimals)
        return DecimalFormat(pattern, symbols).format(value.setScale(decimals, RoundingMode.HALF_UP)) + " %"
    }

    fun formatQuantity(value: BigDecimal): String {
        val stripped = value.stripTrailingZeros()
        val symbols = DecimalFormatSymbols(Locale("es", "PE")).apply {
            decimalSeparator = '.'
            groupingSeparator = ','
        }
        return DecimalFormat("#,##0.###", symbols).format(stripped)
    }

    // ------------------------------------------------------------------
    // Monto en letras (necesario en cotizaciones y comprobantes)
    // ------------------------------------------------------------------

    private val units = arrayOf(
        "", "UNO", "DOS", "TRES", "CUATRO", "CINCO", "SEIS", "SIETE", "OCHO", "NUEVE",
        "DIEZ", "ONCE", "DOCE", "TRECE", "CATORCE", "QUINCE", "DIECISÉIS", "DIECISIETE",
        "DIECIOCHO", "DIECINUEVE", "VEINTE", "VEINTIUNO", "VEINTIDÓS", "VEINTITRÉS",
        "VEINTICUATRO", "VEINTICINCO", "VEINTISÉIS", "VEINTISIETE", "VEINTIOCHO", "VEINTINUEVE"
    )
    private val tens = arrayOf(
        "", "", "VEINTE", "TREINTA", "CUARENTA", "CINCUENTA",
        "SESENTA", "SETENTA", "OCHENTA", "NOVENTA"
    )
    private val hundreds = arrayOf(
        "", "CIENTO", "DOSCIENTOS", "TRESCIENTOS", "CUATROCIENTOS", "QUINIENTOS",
        "SEISCIENTOS", "SETECIENTOS", "OCHOCIENTOS", "NOVECIENTOS"
    )

    /** Ejemplo: 1234.50 -> "MIL DOSCIENTOS TREINTA Y CUATRO CON 50/100 SOLES". */
    fun toWords(value: BigDecimal, currency: CurrencyInfo = CurrencyInfo.PEN): String {
        val rounded = round(value.abs())
        val integerPart = rounded.toBigInteger().toLong()
        val cents = rounded.subtract(BigDecimal(integerPart)).multiply(BigDecimal(100))
            .setScale(0, RoundingMode.HALF_UP).toInt()
        val words = if (integerPart == 0L) "CERO" else numberToWords(integerPart)
        val centsText = cents.toString().padStart(2, '0')
        val sign = if (value.signum() < 0) "MENOS " else ""
        return "$sign$words CON $centsText/100 ${currency.wordPlural}"
    }

    private fun numberToWords(value: Long): String {
        if (value == 0L) return ""
        if (value < 30) return units[value.toInt()]
        if (value < 100) {
            val ten = (value / 10).toInt()
            val rest = (value % 10).toInt()
            return if (rest == 0) tens[ten] else "${tens[ten]} Y ${units[rest]}"
        }
        if (value == 100L) return "CIEN"
        if (value < 1000) {
            val hundred = (value / 100).toInt()
            val rest = value % 100
            return (hundreds[hundred] + " " + numberToWords(rest)).trim()
        }
        if (value < 1_000_000) {
            val thousands = value / 1000
            val rest = value % 1000
            val prefix = if (thousands == 1L) "MIL" else "${numberToWords(thousands)} MIL"
            return (prefix + " " + numberToWords(rest)).trim()
        }
        if (value < 1_000_000_000_000L) {
            val millions = value / 1_000_000
            val rest = value % 1_000_000
            val prefix = if (millions == 1L) "UN MILLÓN" else "${numberToWords(millions)} MILLONES"
            return (prefix + " " + numberToWords(rest)).trim()
        }
        return value.toString()
    }
}

/** Moneda con su símbolo y cómo se nombra en el monto en letras. */
data class CurrencyInfo(
    val code: String,
    val symbol: String,
    val name: String,
    val wordPlural: String
) {
    companion object {
        val PEN = CurrencyInfo("PEN", "S/", "Sol peruano", "SOLES")
        val USD = CurrencyInfo("USD", "$", "Dólar", "DÓLARES")
        val EUR = CurrencyInfo("EUR", "€", "Euro", "EUROS")
        val MXN = CurrencyInfo("MXN", "$", "Peso mexicano", "PESOS")
        val COP = CurrencyInfo("COP", "$", "Peso colombiano", "PESOS")
        val CLP = CurrencyInfo("CLP", "$", "Peso chileno", "PESOS")
        val ARS = CurrencyInfo("ARS", "$", "Peso argentino", "PESOS")
        val BOB = CurrencyInfo("BOB", "Bs", "Boliviano", "BOLIVIANOS")

        val all = listOf(PEN, USD, EUR, MXN, COP, CLP, ARS, BOB)

        fun byCode(code: String): CurrencyInfo = all.firstOrNull { it.code == code } ?: PEN
    }
}
