package com.ganageo.app.tools

import java.util.Locale

/**
 * Motor compartido de códigos de barras y QR.
 *
 * Todo lo que no dependa de Android vive aqui: validaciones, digitos
 * verificadores, sintaxis oficial de cada tipo de contenido QR y analisis de lo
 * que se acaba de leer. La UI solo pinta; el dibujo del bitmap sigue en
 * ToolFileUtils. Asi el generador y el lector usan exactamente las mismas
 * reglas y no se contradicen entre pantallas.
 */

/** Tipos de codigo que la herramienta sabe crear. */
enum class BarcodeKind(
    val label: String,
    val inputHint: String,
    val numericOnly: Boolean,
    /** Digitos del cuerpo sin contar el verificador. 0 = longitud libre. */
    val bodyDigits: Int
) {
    QR("QR", "Texto, enlace, Wi-Fi, contacto…", false, 0),
    CODE_128("Code 128", "Texto o numeros ASCII", false, 0),
    EAN_13("EAN-13", "12 digitos (+1 verificador)", true, 12),
    EAN_8("EAN-8", "7 digitos (+1 verificador)", true, 7),
    UPC_A("UPC-A", "11 digitos (+1 verificador)", true, 11),
    ITF("ITF-14", "Cantidad par de digitos", true, 0)
}

/** Nivel de correccion de error del QR (ISO/IEC 18004). */
enum class QrErrorCorrection(val label: String, val zxing: String, val recovery: String) {
    L("L — 7%", "L", "Solo para pantallas limpias."),
    M("M — 15%", "M", "Equilibrio recomendado para imprimir."),
    Q("Q — 25%", "Q", "Aguanta suciedad o pliegues."),
    H("H — 30%", "H", "Obligatorio si tapas el centro con un logo.")
}

/** Resultado de validar el contenido antes de generar. */
data class BarcodeCheck(
    val valid: Boolean,
    val normalized: String,
    val message: String,
    val notes: List<String> = emptyList(),
    /** Valor completo sugerido cuando solo falta el digito verificador. */
    val suggestion: String? = null
)

object BarcodeEngine {

    /**
     * Digito verificador GTIN (EAN-8, EAN-13, UPC-A, ITF-14).
     *
     * Se pondera 3 y 1 alternando desde el ultimo digito del cuerpo hacia la
     * izquierda, y el verificador es lo que falta para llegar a la decena.
     */
    fun gtinCheckDigit(body: String): Int {
        require(body.isNotEmpty() && body.all(Char::isDigit)) { "El cuerpo debe ser numerico." }
        var sum = 0
        var weight = 3
        for (index in body.length - 1 downTo 0) {
            sum += (body[index] - '0') * weight
            weight = if (weight == 3) 1 else 3
        }
        return (10 - (sum % 10)) % 10
    }

    /** Agrega el digito verificador a un cuerpo sin el. */
    fun appendCheckDigit(body: String): String = body + gtinCheckDigit(body).toString()

    /** Comprueba un GTIN completo (con su verificador incluido). */
    fun isGtinValid(full: String): Boolean {
        if (full.length < 2 || !full.all(Char::isDigit)) return false
        val body = full.dropLast(1)
        val check = full.last() - '0'
        return gtinCheckDigit(body) == check
    }

    /** UPC-A de 12 digitos equivale a un EAN-13 con un cero delante. */
    fun upcAToEan13(upcA: String): String? {
        val clean = upcA.filter(Char::isDigit)
        if (clean.length != 12) return null
        return "0$clean"
    }

    /** Un EAN-13 que empieza en cero se puede escribir como UPC-A. */
    fun ean13ToUpcA(ean13: String): String? {
        val clean = ean13.filter(Char::isDigit)
        if (clean.length != 13 || clean.first() != '0') return null
        return clean.drop(1)
    }

    /**
     * Checksum modulo 103 de Code 128 en conjunto B (ISO/IEC 15417).
     *
     * ZXing ya lo calcula al dibujar; se expone solo para mostrarlo al usuario
     * y para avisar si hay un caracter fuera del conjunto imprimible.
     */
    fun code128ChecksumB(text: String): Int? {
        if (text.isEmpty()) return null
        var sum = 104 // Start B
        text.forEachIndexed { index, char ->
            val code = char.code
            if (code < 32 || code > 126) return null
            sum += (code - 32) * (index + 1)
        }
        return sum % 103
    }

    /** Prefijo GS1 → pais o entidad emisora. No es el pais de fabricacion. */
    fun gs1Issuer(code: String): String? {
        val clean = code.filter(Char::isDigit)
        val gtin13 = when (clean.length) {
            13 -> clean
            12 -> "0$clean"
            14 -> clean.drop(1)
            else -> return null
        }
        val prefix = gtin13.take(3).toIntOrNull() ?: return null
        return when (prefix) {
            in 0..19 -> "Estados Unidos y Canada"
            in 20..29 -> "Uso interno de tienda"
            in 30..39 -> "Estados Unidos (medicamentos)"
            in 40..49 -> "Uso interno de empresa"
            in 50..59 -> "Cupones"
            in 60..139 -> "Estados Unidos y Canada"
            in 200..299 -> "Uso interno (peso variable)"
            in 300..379 -> "Francia y Monaco"
            380 -> "Bulgaria"
            383 -> "Eslovenia"
            385 -> "Croacia"
            387 -> "Bosnia y Herzegovina"
            389 -> "Montenegro"
            in 400..440 -> "Alemania"
            in 450..459, in 490..499 -> "Japon"
            in 460..469 -> "Rusia"
            470 -> "Kirguistan"
            471 -> "Taiwan"
            474 -> "Estonia"
            475 -> "Letonia"
            476 -> "Azerbaiyan"
            477 -> "Lituania"
            478 -> "Uzbekistan"
            479 -> "Sri Lanka"
            480 -> "Filipinas"
            481 -> "Bielorrusia"
            482 -> "Ucrania"
            484 -> "Moldavia"
            485 -> "Armenia"
            486 -> "Georgia"
            487 -> "Kazajistan"
            489 -> "Hong Kong"
            in 500..509 -> "Reino Unido"
            in 520..521 -> "Grecia"
            528 -> "Libano"
            529 -> "Chipre"
            531 -> "Macedonia del Norte"
            535 -> "Malta"
            539 -> "Irlanda"
            in 540..549 -> "Belgica y Luxemburgo"
            560 -> "Portugal"
            569 -> "Islandia"
            in 570..579 -> "Dinamarca"
            590 -> "Polonia"
            594 -> "Rumania"
            599 -> "Hungria"
            in 600..601 -> "Sudafrica"
            608 -> "Bahrein"
            609 -> "Mauricio"
            611 -> "Marruecos"
            613 -> "Argelia"
            in 615..616 -> "Nigeria / Georgia"
            619 -> "Tunez"
            621 -> "Siria"
            622 -> "Egipto"
            624 -> "Libia"
            625 -> "Jordania"
            626 -> "Iran"
            627 -> "Kuwait"
            628 -> "Arabia Saudita"
            629 -> "Emiratos Arabes Unidos"
            in 640..649 -> "Finlandia"
            in 690..699 -> "China"
            in 700..709 -> "Noruega"
            729 -> "Israel"
            in 730..739 -> "Suecia"
            740 -> "Guatemala"
            741 -> "El Salvador"
            742 -> "Honduras"
            743 -> "Nicaragua"
            744 -> "Costa Rica"
            745 -> "Panama"
            746 -> "Republica Dominicana"
            750 -> "Mexico"
            in 754..755 -> "Canada"
            759 -> "Venezuela"
            in 760..769 -> "Suiza"
            in 770..771 -> "Colombia"
            773 -> "Uruguay"
            775 -> "Peru"
            777 -> "Bolivia"
            in 778..779 -> "Argentina"
            780 -> "Chile"
            784 -> "Paraguay"
            786 -> "Ecuador"
            in 789..790 -> "Brasil"
            in 800..839 -> "Italia"
            in 840..849 -> "Espana"
            850 -> "Cuba"
            858 -> "Eslovaquia"
            859 -> "Republica Checa"
            860 -> "Serbia"
            865 -> "Mongolia"
            867 -> "Corea del Norte"
            in 868..869 -> "Turquia"
            in 870..879 -> "Paises Bajos"
            880 -> "Corea del Sur"
            883 -> "Myanmar"
            884 -> "Camboya"
            885 -> "Tailandia"
            888 -> "Singapur"
            890 -> "India"
            893 -> "Vietnam"
            896 -> "Pakistan"
            899 -> "Indonesia"
            in 900..919 -> "Austria"
            in 930..939 -> "Australia"
            in 940..949 -> "Nueva Zelanda"
            955 -> "Malasia"
            958 -> "Macao"
            in 960..969 -> "GS1 Global Office (GTIN-8)"
            in 977..977 -> "Publicacion periodica (ISSN)"
            in 978..979 -> "Libro (ISBN)"
            980 -> "Recibo de reembolso"
            in 981..984 -> "Cupon de moneda comun"
            in 990..999 -> "Cupon"
            else -> null
        }
    }

    /**
     * Valida el contenido para el tipo elegido y, cuando se puede, propone el
     * valor corregido en vez de limitarse a decir que esta mal.
     */
    fun validate(kind: BarcodeKind, raw: String): BarcodeCheck {
        val value = raw.trim()
        if (value.isBlank()) {
            return BarcodeCheck(false, "", "Escribe el contenido del codigo.")
        }

        return when (kind) {
            BarcodeKind.QR -> {
                val notes = mutableListOf<String>()
                val bytes = value.toByteArray(Charsets.UTF_8).size
                if (bytes > 1200) notes += "$bytes bytes: el QR saldra muy denso, conviene acortar el texto."
                BarcodeCheck(true, value, "Listo para generar.", notes)
            }

            BarcodeKind.CODE_128 -> {
                val invalid = value.filter { it.code < 32 || it.code > 126 }
                if (invalid.isNotEmpty()) {
                    return BarcodeCheck(
                        false,
                        value,
                        "Code 128 no admite estos caracteres: ${invalid.toSet().joinToString(" ")}",
                        listOf("Quita tildes y enes: el conjunto B solo llega hasta el ASCII 126.")
                    )
                }
                val notes = mutableListOf<String>()
                code128ChecksumB(value)?.let { notes += "Checksum modulo 103: $it (lo agrega el propio codigo)." }
                if (value.all(Char::isDigit) && value.length % 2 == 0) {
                    notes += "Al ser solo digitos pares, el conjunto C lo comprime a la mitad de ancho."
                }
                if (value.length > 48) notes += "Con ${value.length} caracteres el codigo queda largo y dificil de leer."
                BarcodeCheck(true, value, "Listo para generar.", notes)
            }

            BarcodeKind.ITF -> {
                val digits = value.filter(Char::isDigit)
                if (digits.length != value.length) {
                    return BarcodeCheck(false, value, "ITF solo acepta digitos.")
                }
                if (digits.length == 13) {
                    val full = appendCheckDigit(digits)
                    return BarcodeCheck(
                        true,
                        full,
                        "ITF-14 completado con el verificador.",
                        listOfNotNull(gs1Issuer(full)?.let { "Prefijo GS1: $it" }),
                        suggestion = full
                    )
                }
                if (digits.length % 2 != 0) {
                    return BarcodeCheck(
                        false,
                        digits,
                        "ITF necesita una cantidad par de digitos (tienes ${digits.length}).",
                        listOf("Agrega un cero delante para completar el par.")
                    )
                }
                BarcodeCheck(true, digits, "Listo para generar.")
            }

            else -> validateGtin(kind, value)
        }
    }

    private fun validateGtin(kind: BarcodeKind, value: String): BarcodeCheck {
        val digits = value.filter(Char::isDigit)
        if (digits.length != value.length) {
            return BarcodeCheck(false, value, "${kind.label} solo acepta digitos.")
        }
        val body = kind.bodyDigits
        val full = body + 1

        if (digits.length == body) {
            val completed = appendCheckDigit(digits)
            val notes = mutableListOf<String>()
            notes += "Verificador calculado: ${completed.last()}"
            gs1Issuer(completed)?.let { notes += "Prefijo GS1: $it" }
            extraGtinNotes(kind, completed).let { notes += it }
            return BarcodeCheck(true, completed, "Se agrego el digito verificador.", notes, suggestion = completed)
        }

        if (digits.length == full) {
            if (!isGtinValid(digits)) {
                val fixed = appendCheckDigit(digits.dropLast(1))
                return BarcodeCheck(
                    false,
                    digits,
                    "El digito verificador no cuadra: deberia terminar en ${fixed.last()}.",
                    listOf("Toca «Corregir» para usar $fixed."),
                    suggestion = fixed
                )
            }
            val notes = mutableListOf<String>()
            notes += "Digito verificador correcto."
            gs1Issuer(digits)?.let { notes += "Prefijo GS1: $it" }
            extraGtinNotes(kind, digits).let { notes += it }
            return BarcodeCheck(true, digits, "Codigo valido.", notes)
        }

        return BarcodeCheck(
            false,
            digits,
            "${kind.label} necesita $body digitos (o $full con verificador). Tienes ${digits.length}."
        )
    }

    private fun extraGtinNotes(kind: BarcodeKind, full: String): List<String> = when (kind) {
        BarcodeKind.UPC_A -> upcAToEan13(full)?.let { listOf("Como EAN-13: $it") }.orEmpty()
        BarcodeKind.EAN_13 -> ean13ToUpcA(full)?.let { listOf("Como UPC-A: $it") }.orEmpty()
        else -> emptyList()
    }
}

// ---------------------------------------------------------------------------
// Contenidos QR con la sintaxis exacta que esperan los lectores
// ---------------------------------------------------------------------------

/** Plantillas de contenido para el QR. */
enum class QrPayloadKind(val label: String) {
    TEXTO("Texto libre"),
    ENLACE("Enlace web"),
    WIFI("Wi-Fi"),
    CONTACTO("Contacto"),
    SMS("SMS"),
    EMAIL("Correo"),
    TELEFONO("Telefono"),
    WHATSAPP("WhatsApp"),
    UBICACION("Ubicacion"),
    EVENTO("Evento")
}

/** Seguridad de la red al compartir Wi-Fi por QR. */
enum class WifiSecurity(val label: String, val token: String) {
    WPA("WPA / WPA2", "WPA"),
    WPA3("WPA3", "SAE"),
    WEP("WEP", "WEP"),
    ABIERTA("Abierta", "nopass")
}

object QrContent {

    /** Escapa los caracteres reservados del formato WIFI: y MECARD:. */
    fun escape(value: String): String = buildString {
        value.forEach { char ->
            if (char == '\\' || char == ';' || char == ',' || char == ':' || char == '"') append('\\')
            append(char)
        }
    }

    fun url(raw: String): String {
        val value = raw.trim()
        if (value.isBlank()) return ""
        return if (value.startsWith("http://", true) || value.startsWith("https://", true)) value
        else "https://$value"
    }

    /** WIFI:S:red;T:WPA;P:clave;H:false;; — termina en doble punto y coma. */
    fun wifi(ssid: String, password: String, security: WifiSecurity, hidden: Boolean): String {
        if (ssid.isBlank()) return ""
        val builder = StringBuilder("WIFI:S:${escape(ssid.trim())};T:${security.token};")
        if (security != WifiSecurity.ABIERTA && password.isNotBlank()) {
            builder.append("P:${escape(password)};")
        }
        if (hidden) builder.append("H:true;")
        builder.append(";")
        return builder.toString()
    }

    /** MECARD: es mas corto que vCard y lo entienden Android e iOS. */
    fun meCard(
        name: String,
        phone: String,
        email: String,
        organization: String,
        url: String,
        note: String
    ): String {
        if (name.isBlank() && phone.isBlank() && email.isBlank()) return ""
        val builder = StringBuilder("MECARD:")
        if (name.isNotBlank()) builder.append("N:${escape(name.trim())};")
        if (phone.isNotBlank()) builder.append("TEL:${phone.filter { it.isDigit() || it == '+' }};")
        if (email.isNotBlank()) builder.append("EMAIL:${escape(email.trim())};")
        if (organization.isNotBlank()) builder.append("ORG:${escape(organization.trim())};")
        if (url.isNotBlank()) builder.append("URL:${escape(url(url))};")
        if (note.isNotBlank()) builder.append("NOTE:${escape(note.trim())};")
        builder.append(";")
        return builder.toString()
    }

    fun vCard(
        name: String,
        phone: String,
        email: String,
        organization: String,
        url: String,
        note: String
    ): String {
        if (name.isBlank() && phone.isBlank() && email.isBlank()) return ""
        return buildString {
            append("BEGIN:VCARD\nVERSION:3.0\n")
            if (name.isNotBlank()) append("FN:${name.trim()}\n")
            if (organization.isNotBlank()) append("ORG:${organization.trim()}\n")
            if (phone.isNotBlank()) append("TEL;TYPE=CELL:${phone.trim()}\n")
            if (email.isNotBlank()) append("EMAIL:${email.trim()}\n")
            if (url.isNotBlank()) append("URL:${url(url)}\n")
            if (note.isNotBlank()) append("NOTE:${note.trim()}\n")
            append("END:VCARD")
        }
    }

    fun sms(number: String, message: String): String {
        val clean = number.filter { it.isDigit() || it == '+' }
        if (clean.isBlank()) return ""
        return if (message.isBlank()) "SMSTO:$clean" else "SMSTO:$clean:${message.trim()}"
    }

    fun email(to: String, subject: String, body: String): String {
        val clean = to.trim()
        if (clean.isBlank()) return ""
        val params = mutableListOf<String>()
        if (subject.isNotBlank()) params += "subject=${encodeQuery(subject)}"
        if (body.isNotBlank()) params += "body=${encodeQuery(body)}"
        return if (params.isEmpty()) "mailto:$clean" else "mailto:$clean?${params.joinToString("&")}"
    }

    fun phone(number: String): String {
        val clean = number.filter { it.isDigit() || it == '+' }
        return if (clean.isBlank()) "" else "tel:$clean"
    }

    /** wa.me exige el numero internacional sin el signo mas. */
    fun whatsapp(number: String, message: String): String {
        val clean = number.filter(Char::isDigit)
        if (clean.isBlank()) return ""
        return if (message.isBlank()) "https://wa.me/$clean"
        else "https://wa.me/$clean?text=${encodeQuery(message)}"
    }

    fun geo(latitude: String, longitude: String, label: String): String {
        val lat = latitude.trim().replace(',', '.').toDoubleOrNull() ?: return ""
        val lon = longitude.trim().replace(',', '.').toDoubleOrNull() ?: return ""
        val base = "geo:${format6(lat)},${format6(lon)}"
        return if (label.isBlank()) base else "$base?q=${format6(lat)},${format6(lon)}(${encodeQuery(label)})"
    }

    /** VEVENT minimo: fechas en formato basico AAAAMMDDTHHMMSS. */
    fun event(title: String, place: String, start: String, end: String): String {
        if (title.isBlank() || start.isBlank()) return ""
        return buildString {
            append("BEGIN:VEVENT\n")
            append("SUMMARY:${title.trim()}\n")
            if (place.isNotBlank()) append("LOCATION:${place.trim()}\n")
            append("DTSTART:${start.trim()}\n")
            if (end.isNotBlank()) append("DTEND:${end.trim()}\n")
            append("END:VEVENT")
        }
    }

    private fun format6(value: Double): String = String.format(Locale.US, "%.6f", value)

    private fun encodeQuery(value: String): String = buildString {
        value.trim().toByteArray(Charsets.UTF_8).forEach { byte ->
            val code = byte.toInt() and 0xFF
            val char = code.toChar()
            when {
                char.isLetterOrDigit() && code < 128 -> append(char)
                char == '-' || char == '_' || char == '.' || char == '~' -> append(char)
                else -> append('%').append(String.format(Locale.US, "%02X", code))
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Analisis de lo leido
// ---------------------------------------------------------------------------

/** Accion sugerida para el contenido leido. */
data class ScanAction(val label: String, val uri: String, val sendTo: Boolean = false)

data class ScannedInfo(
    val kind: String,
    val summary: String,
    val details: List<Pair<String, String>> = emptyList(),
    val warnings: List<String> = emptyList(),
    val action: ScanAction? = null
)

object ScannedContentAnalyzer {

    private val shorteners = setOf(
        "bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "is.gd", "buff.ly",
        "cutt.ly", "rebrand.ly", "shorturl.at", "acortar.link", "n9.cl", "bit.do"
    )

    fun analyze(raw: String): ScannedInfo {
        val value = raw.trim()
        if (value.isBlank()) return ScannedInfo("Vacio", "No se leyo contenido.")

        val upper = value.uppercase(Locale.ROOT)

        if (upper.startsWith("WIFI:")) return wifi(value)
        if (upper.startsWith("MECARD:") || upper.startsWith("BEGIN:VCARD")) return contact(value)
        if (upper.startsWith("SMSTO:")) return sms(value)
        if (upper.startsWith("MAILTO:")) {
            val to = value.removePrefix("mailto:").removePrefix("MAILTO:").substringBefore("?")
            return ScannedInfo("Correo", to, action = ScanAction("Escribir correo", value, sendTo = true))
        }
        if (upper.startsWith("TEL:")) {
            val number = value.substring(4)
            return ScannedInfo("Telefono", number, action = ScanAction("Llamar", value))
        }
        if (upper.startsWith("GEO:")) {
            return ScannedInfo("Ubicacion", value.substring(4), action = ScanAction("Abrir en el mapa", value))
        }
        if (upper.startsWith("BEGIN:VEVENT")) {
            val title = lineValue(value, "SUMMARY") ?: "Evento"
            return ScannedInfo("Evento", title, details = eventDetails(value))
        }
        if (upper.startsWith("HTTP://") || upper.startsWith("HTTPS://")) return link(value)

        EmvQr.describe(value)?.let { return it }

        val digits = value.filter(Char::isDigit)
        if (digits.length == value.length && value.length in setOf(8, 12, 13, 14) && BarcodeEngine.isGtinValid(value)) {
            val issuer = BarcodeEngine.gs1Issuer(value)
            val details = buildList {
                add("Digito verificador" to "correcto")
                if (issuer != null) add("Prefijo GS1" to issuer)
                BarcodeEngine.upcAToEan13(value)?.let { add("EAN-13" to it) }
            }
            return ScannedInfo("Producto (GTIN)", value, details)
        }

        return ScannedInfo("Texto", value)
    }

    private fun link(value: String): ScannedInfo {
        val host = hostOf(value)
        return ScannedInfo(
            kind = "Enlace",
            summary = value,
            details = listOfNotNull(host?.let { "Dominio" to it }),
            warnings = urlWarnings(value),
            action = ScanAction("Abrir enlace", value)
        )
    }

    /**
     * Avisos antes de abrir un enlace escaneado.
     *
     * Un QR pegado en la calle es el vector clasico de phishing: el usuario no
     * ve la direccion hasta que ya esta dentro. Estas comprobaciones son
     * heuristicas, no un antivirus, pero cubren los enganos mas comunes.
     */
    fun urlWarnings(url: String): List<String> {
        val warnings = mutableListOf<String>()
        val host = hostOf(url) ?: return listOf("No se pudo interpretar la direccion.")
        val lower = host.lowercase(Locale.ROOT)

        if (url.startsWith("http://", true)) {
            warnings += "Va por http sin cifrar: no escribas contrasenas ni tarjetas."
        }
        val authority = url.substringAfter("://").substringBefore("/")
        if (authority.contains("@")) {
            warnings += "La direccion esconde un usuario antes del dominio real (@): tipico enganio."
        }
        if (lower.startsWith("xn--") || lower.contains(".xn--")) {
            warnings += "El dominio usa punycode: puede imitar letras de otro alfabeto."
        }
        if (Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(lower)) {
            warnings += "Apunta a una IP directa en vez de a un dominio."
        }
        if (lower in shorteners || shorteners.any { lower.endsWith(".$it") }) {
            warnings += "Es un acortador: el destino real esta oculto."
        }
        if (lower.count { it == '-' } >= 3 || lower.count { it == '.' } >= 4) {
            warnings += "El dominio tiene una estructura rara, revisalo con calma."
        }
        if (url.length > 300) {
            warnings += "Direccion larguisima (${url.length} caracteres)."
        }
        return warnings
    }

    private fun wifi(value: String): ScannedInfo {
        val fields = splitEscaped(value.removePrefix("WIFI:").removePrefix("wifi:"))
        val ssid = fields["S"].orEmpty()
        val type = when (fields["T"]?.uppercase(Locale.ROOT)) {
            "WPA" -> "WPA / WPA2"
            "SAE" -> "WPA3"
            "WEP" -> "WEP"
            "NOPASS", null, "" -> "Abierta"
            else -> fields["T"].orEmpty()
        }
        val details = buildList {
            add("Red" to ssid)
            add("Seguridad" to type)
            fields["P"]?.takeIf { it.isNotBlank() }?.let { add("Clave" to it) }
            if (fields["H"]?.equals("true", true) == true) add("Red oculta" to "si")
        }
        return ScannedInfo("Wi-Fi", ssid.ifBlank { "Red Wi-Fi" }, details)
    }

    private fun contact(value: String): ScannedInfo {
        return if (value.uppercase(Locale.ROOT).startsWith("MECARD:")) {
            val fields = splitEscaped(value.removePrefix("MECARD:").removePrefix("mecard:"))
            val name = fields["N"].orEmpty()
            val details = buildList {
                fields["N"]?.let { add("Nombre" to it) }
                fields["TEL"]?.let { add("Telefono" to it) }
                fields["EMAIL"]?.let { add("Correo" to it) }
                fields["ORG"]?.let { add("Empresa" to it) }
                fields["URL"]?.let { add("Web" to it) }
            }
            val phone = fields["TEL"]
            ScannedInfo(
                "Contacto",
                name.ifBlank { "Contacto" },
                details,
                action = phone?.let { ScanAction("Llamar", "tel:$it") }
            )
        } else {
            val name = lineValue(value, "FN") ?: "Contacto"
            val details = buildList {
                add("Nombre" to name)
                lineValue(value, "ORG")?.let { add("Empresa" to it) }
                lineValue(value, "TEL")?.let { add("Telefono" to it) }
                lineValue(value, "EMAIL")?.let { add("Correo" to it) }
            }
            val phone = lineValue(value, "TEL")
            ScannedInfo(
                "Contacto",
                name,
                details,
                action = phone?.let { ScanAction("Llamar", "tel:$it") }
            )
        }
    }

    private fun sms(value: String): ScannedInfo {
        val rest = value.substring(6)
        val number = rest.substringBefore(":")
        val message = rest.substringAfter(":", "")
        val details = buildList {
            add("Numero" to number)
            if (message.isNotBlank()) add("Mensaje" to message)
        }
        return ScannedInfo("SMS", number, details, action = ScanAction("Escribir SMS", "smsto:$number", sendTo = true))
    }

    private fun eventDetails(value: String): List<Pair<String, String>> = buildList {
        lineValue(value, "SUMMARY")?.let { add("Titulo" to it) }
        lineValue(value, "LOCATION")?.let { add("Lugar" to it) }
        lineValue(value, "DTSTART")?.let { add("Inicio" to it) }
        lineValue(value, "DTEND")?.let { add("Fin" to it) }
    }

    private fun lineValue(value: String, key: String): String? = value.lines()
        .firstOrNull { it.uppercase(Locale.ROOT).startsWith("$key:") || it.uppercase(Locale.ROOT).startsWith("$key;") }
        ?.substringAfter(":")
        ?.trim()
        ?.takeIf { it.isNotBlank() }

    fun hostOf(url: String): String? {
        val withoutScheme = url.substringAfter("://", "")
        if (withoutScheme.isBlank()) return null
        val authority = withoutScheme.substringBefore("/").substringBefore("?")
        val host = authority.substringAfterLast("@").substringBefore(":")
        return host.takeIf { it.isNotBlank() }
    }

    /** Separa campos tipo CLAVE:valor; respetando las barras de escape. */
    private fun splitEscaped(body: String): Map<String, String> {
        val result = mutableMapOf<String, String>()
        val current = StringBuilder()
        var escaped = false
        val parts = mutableListOf<String>()
        body.forEach { char ->
            when {
                escaped -> {
                    current.append(char)
                    escaped = false
                }
                char == '\\' -> escaped = true
                char == ';' -> {
                    parts += current.toString()
                    current.clear()
                }
                else -> current.append(char)
            }
        }
        if (current.isNotEmpty()) parts += current.toString()
        parts.filter { it.isNotBlank() }.forEach { part ->
            val key = part.substringBefore(":").uppercase(Locale.ROOT)
            val value = part.substringAfter(":", "")
            if (key.isNotBlank()) result[key] = value
        }
        return result
    }
}

// ---------------------------------------------------------------------------
// QR de pago EMVCo (Yape, Plin y el QR interoperable peruano)
// ---------------------------------------------------------------------------

/**
 * Solo lectura y validacion.
 *
 * El BCRP obliga a que los QR de pago en Peru sigan el estandar EMVCo
 * Merchant-Presented Mode: una cadena TLV (id de 2 digitos, longitud de 2
 * digitos, valor) que termina con un CRC-16. Gana Geo interpreta y verifica el
 * codigo para que el usuario vea a quien y cuanto va a pagar, pero no genera
 * codigos de cobro ni inicia pagos: eso solo lo puede hacer una entidad
 * regulada.
 */
object EmvQr {

    private val currencies = mapOf(
        "604" to "PEN (soles)",
        "840" to "USD (dolares)",
        "978" to "EUR (euros)",
        "032" to "ARS", "068" to "BOB", "152" to "CLP", "170" to "COP", "484" to "MXN"
    )

    /** CRC-16/CCITT-FALSE: polinomio 0x1021, valor inicial 0xFFFF. */
    fun crc16(data: String): Int {
        var crc = 0xFFFF
        data.toByteArray(Charsets.UTF_8).forEach { byte ->
            crc = crc xor ((byte.toInt() and 0xFF) shl 8)
            repeat(8) {
                crc = if (crc and 0x8000 != 0) ((crc shl 1) xor 0x1021) else (crc shl 1)
                crc = crc and 0xFFFF
            }
        }
        return crc and 0xFFFF
    }

    /** Recorre la cadena TLV. Devuelve null si la estructura no cuadra. */
    fun parse(payload: String): Map<String, String>? {
        if (payload.length < 8) return null
        val result = linkedMapOf<String, String>()
        var index = 0
        while (index + 4 <= payload.length) {
            val id = payload.substring(index, index + 2)
            if (!id.all(Char::isDigit)) return null
            val length = payload.substring(index + 2, index + 4).toIntOrNull() ?: return null
            val start = index + 4
            val end = start + length
            if (end > payload.length) return null
            result[id] = payload.substring(start, end)
            index = end
        }
        if (index != payload.length) return null
        return result.takeIf { it.isNotEmpty() }
    }

    fun isEmvPayload(payload: String): Boolean {
        val fields = parse(payload) ?: return false
        return fields["00"] != null && fields["63"] != null
    }

    fun describe(payload: String): ScannedInfo? {
        val fields = parse(payload) ?: return null
        val formatIndicator = fields["00"] ?: return null
        val crcField = fields["63"] ?: return null
        if (formatIndicator != "01") return null

        val crcStart = payload.lastIndexOf("6304")
        if (crcStart < 0) return null
        val computed = crc16(payload.substring(0, crcStart + 4))
        val crcOk = String.format(Locale.US, "%04X", computed).equals(crcField, ignoreCase = true)

        val dynamic = fields["01"] == "12"
        val merchant = fields["59"].orEmpty()
        val city = fields["60"].orEmpty()
        val amount = fields["54"]
        val currency = fields["53"]?.let { currencies[it] ?: it }

        val details = buildList {
            add("Tipo" to if (dynamic) "QR dinamico (un solo uso)" else "QR estatico (reutilizable)")
            if (merchant.isNotBlank()) add("Comercio" to merchant)
            if (city.isNotBlank()) add("Ciudad" to city)
            fields["58"]?.let { add("Pais" to it) }
            if (currency != null) add("Moneda" to currency)
            add("Monto" to (amount ?: "lo escribe quien paga"))
            fields["52"]?.let { add("Rubro (MCC)" to it) }
            add("CRC" to if (crcOk) "verificado" else "NO COINCIDE")
        }

        val warnings = buildList {
            if (!crcOk) add("El CRC no coincide: el codigo esta danado o alterado. No pagues con el.")
            add("Gana Geo solo lee el codigo. Confirma comercio y monto en tu app de pagos antes de aceptar.")
        }

        return ScannedInfo(
            kind = "QR de pago (EMVCo)",
            summary = merchant.ifBlank { "Codigo de pago" },
            details = details,
            warnings = warnings
        )
    }
}
