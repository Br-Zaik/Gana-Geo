package com.ganageo.app.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.CurrencyInfo
import com.ganageo.app.tools.FiscalData
import com.ganageo.app.tools.Money
import com.ganageo.app.tools.PayrollEngine
import com.ganageo.app.tools.TimeEngine
import java.math.BigDecimal

private class DayEntry(regular: String = "8", overtime: String = "") {
    var regular by mutableStateOf(regular)
    var overtime by mutableStateOf(overtime)
    var holiday by mutableStateOf(false)
}

/** Lee una hora escrita como 7:30, 07.30 o 0730. */
private fun parseClock(text: String): Int? {
    val clean = text.trim().replace(".", ":").replace(",", ":")
    if (clean.isBlank()) return null
    val parts = if (clean.contains(":")) clean.split(":") else {
        val digits = clean.filter(Char::isDigit)
        when (digits.length) {
            1, 2 -> listOf(digits, "0")
            3 -> listOf(digits.take(1), digits.drop(1))
            4 -> listOf(digits.take(2), digits.drop(2))
            else -> return null
        }
    }
    val hour = parts.getOrNull(0)?.filter(Char::isDigit)?.toIntOrNull() ?: return null
    val minute = parts.getOrNull(1)?.filter(Char::isDigit)?.toIntOrNull() ?: 0
    if (hour !in 0..23 || minute !in 0..59) return null
    return hour * 60 + minute
}

/**
 * Horas de trabajo y pago.
 *
 * Aplica las reglas peruanas de verdad: 25 % de recargo las dos primeras horas
 * extra de cada día y 35 % desde la tercera, 35 % adicional por las horas
 * nocturnas y 100 % de sobretasa si se trabajó feriado o día de descanso. El
 * conteo de las dos primeras horas se reinicia cada día, por eso se calcula por
 * jornada y no sobre el total de la semana.
 */
@Composable
fun WorkHoursScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val currency = CurrencyInfo.PEN

    // --- Base de cálculo ---
    var useMonthly by rememberSaveable { mutableStateOf(true) }
    var monthlySalary by rememberSaveable { mutableStateOf("1130") }
    var hourlyText by rememberSaveable { mutableStateOf("") }
    var journeyHours by rememberSaveable { mutableStateOf("8") }

    val journey = Money.parseOrNull(journeyHours)?.toDouble()?.takeIf { it > 0 } ?: 8.0
    val hourlyRate: BigDecimal = if (useMonthly) {
        TimeEngine.hourlyFromMonthly(Money.ofOrZero(monthlySalary), journey)
    } else {
        Money.ofOrZero(hourlyText)
    }

    ScienceShell(
        title = "Horas de trabajo",
        subtitle = "Valor hora ${Money.format(hourlyRate, currency)}",
        onBack = onBack
    ) {
        StudioTabs(listOf("Jornada", "Semana", "Sueldo", "Recibo"), tab) { tab = it }

        if (tab == 0 || tab == 1) {
            ScienceCard("Base de cálculo") {
                StudioChipRow {
                    StudioChip("Desde el sueldo mensual", useMonthly, onClick = { useMonthly = true })
                    StudioChip("Valor hora directo", !useMonthly, onClick = { useMonthly = false })
                }
                if (useMonthly) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScienceNumberField(monthlySalary, { monthlySalary = it }, "Sueldo mensual", Modifier.weight(1.4f))
                        ScienceNumberField(journeyHours, { journeyHours = it }, "Horas/día", Modifier.weight(1f))
                    }
                    StudioHint(
                        "Regla peruana: el valor día es el sueldo entre 30, y el valor hora es ese valor día " +
                            "entre las horas de la jornada. Resultado: ${Money.format(hourlyRate, currency)} por hora."
                    )
                } else {
                    ScienceNumberField(hourlyText, { hourlyText = it }, "Pago por hora", Modifier.fillMaxWidth())
                }
            }
        }

        when (tab) {
            0 -> ShiftTab(hourlyRate, journey, currency)
            1 -> WeekTab(hourlyRate, journey, currency)
            2 -> NetSalaryTab(currency)
            else -> HonorariosTab(currency, context)
        }
    }
}

@Composable
private fun ShiftTab(hourlyRate: BigDecimal, journey: Double, currency: CurrencyInfo) {
    var start by rememberSaveable { mutableStateOf("08:00") }
    var end by rememberSaveable { mutableStateOf("18:30") }
    var breakMinutes by rememberSaveable { mutableStateOf("60") }
    var roundBlock by rememberSaveable { mutableIntStateOf(1) }
    var holiday by rememberSaveable { mutableStateOf(false) }
    var countNight by rememberSaveable { mutableStateOf(true) }
    var days by rememberSaveable { mutableStateOf("1") }

    val startMinutes = parseClock(start)
    val endMinutes = parseClock(end)

    ScienceCard("Jornada") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StudioTextField(start, { start = it }, "Entrada", placeholder = "08:00", modifier = Modifier.weight(1f))
            StudioTextField(end, { end = it }, "Salida", placeholder = "18:30", modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ScienceNumberField(breakMinutes, { breakMinutes = it }, "Descanso (min)", Modifier.weight(1f))
            ScienceNumberField(days, { days = it }, "Días iguales", Modifier.weight(1f))
        }
        StudioLabel("Redondeo de marcaciones")
        StudioChipRow {
            listOf(1, 5, 10, 15).forEach { block ->
                StudioChip(
                    label = if (block == 1) "Exacto" else "$block min",
                    active = roundBlock == block,
                    onClick = { roundBlock = block }
                )
            }
        }
        StudioChipRow {
            StudioChip("Feriado o descanso", holiday, onClick = { holiday = !holiday })
            StudioChip("Contar nocturno", countNight, onClick = { countNight = !countNight })
        }
        StudioHint("Si la salida es menor que la entrada se entiende que el turno cruza la medianoche.")
    }

    if (startMinutes == null || endMinutes == null) {
        ScienceError("Escribe las horas en formato 24 h, por ejemplo 08:00 y 18:30.")
        return
    }

    val shift = TimeEngine.analyzeShift(
        startMinutes = startMinutes,
        endMinutes = endMinutes,
        breakMinutes = breakMinutes.toIntOrNull() ?: 0,
        journeyHours = journey,
        roundToMinutes = roundBlock
    )
    val dayCount = days.toIntOrNull()?.coerceAtLeast(1) ?: 1
    val pay = TimeEngine.computePay(
        hourlyRate = hourlyRate,
        regularMinutes = shift.regularMinutes,
        overtimeMinutes = shift.overtimeMinutes,
        nightMinutes = if (countNight) shift.nightMinutes else 0,
        holiday = holiday,
        days = dayCount
    )

    ScienceCard("Desglose de la jornada") {
        ScienceRow("Tiempo en el centro de trabajo", TimeEngine.formatMinutes(shift.totalMinutes))
        ScienceRow("Tiempo efectivo (sin descanso)", TimeEngine.formatMinutes(shift.workedMinutes))
        ScienceRow("Horas dentro de la jornada", TimeEngine.formatMinutes(shift.regularMinutes))
        ScienceRow(
            "Horas extra del día",
            TimeEngine.formatMinutes(shift.overtimeMinutes),
            highlight = shift.overtimeMinutes > 0
        )
        if (shift.nightMinutes > 0) {
            ScienceRow("Horas en horario nocturno", TimeEngine.formatMinutes(shift.nightMinutes))
        }
        if (shift.crossesMidnight) {
            StudioHint("El turno cruza la medianoche: se contó hasta la salida del día siguiente.")
        }
    }

    ScienceCard("Cómo se paga") {
        MoneyRow("Horas ordinarias (${pay.regularHours} h)", Money.format(pay.regularPay, currency))
        if (pay.overtimeFirstHours.signum() > 0) {
            MoneyRow(
                "Extra al 25 % (${pay.overtimeFirstHours} h)",
                Money.format(pay.overtimeFirstPay, currency)
            )
        }
        if (pay.overtimeRestHours.signum() > 0) {
            MoneyRow(
                "Extra al 35 % (${pay.overtimeRestHours} h)",
                Money.format(pay.overtimeRestPay, currency)
            )
        }
        if (pay.nightExtraPay.signum() > 0) {
            MoneyRow("Recargo nocturno 35 %", Money.format(pay.nightExtraPay, currency))
        }
        if (pay.holidayExtraPay.signum() > 0) {
            MoneyRow("Sobretasa por feriado 100 %", Money.format(pay.holidayExtraPay, currency))
        }
        StudioHint(
            "Las dos primeras horas extra de cada día van al 25 % y desde la tercera al 35 %. " +
                "El conteo se reinicia cada jornada."
        )
    }

    WorkTotals(
        rows = listOf(
            "Valor hora" to Money.format(pay.hourlyRate, currency),
            "Días calculados" to dayCount.toString()
        ),
        total = "Total a cobrar" to Money.format(pay.total, currency)
    )
}

@Composable
private fun WeekTab(hourlyRate: BigDecimal, journey: Double, currency: CurrencyInfo) {
    val dayNames = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
    val entries = remember { mutableStateListOf(*Array(7) { DayEntry() }) }

    var totalPay = BigDecimal.ZERO
    var totalRegular = BigDecimal.ZERO
    var totalOvertime = BigDecimal.ZERO

    entries.forEach { entry ->
        val regularHours = Money.parseOrNull(entry.regular) ?: BigDecimal.ZERO
        val overtimeHours = Money.parseOrNull(entry.overtime) ?: BigDecimal.ZERO
        val pay = TimeEngine.computePay(
            hourlyRate = hourlyRate,
            regularMinutes = (regularHours.toDouble() * 60).toInt(),
            overtimeMinutes = (overtimeHours.toDouble() * 60).toInt(),
            holiday = entry.holiday
        )
        totalPay = totalPay.add(pay.total)
        totalRegular = totalRegular.add(regularHours)
        totalOvertime = totalOvertime.add(overtimeHours)
    }

    ScienceCard("Semana") {
        entries.forEachIndexed { index, entry ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                androidx.compose.material3.Text(
                    dayNames[index].take(3),
                    color = StudioTheme.TextSecondary,
                    style = androidx.compose.material3.MaterialTheme.typography.labelLarge,
                    modifier = Modifier.weight(0.7f)
                )
                ScienceNumberField(entry.regular, { entry.regular = it }, "Normales", Modifier.weight(1f))
                ScienceNumberField(entry.overtime, { entry.overtime = it }, "Extra", Modifier.weight(1f))
                StudioChip(
                    label = "Fer.",
                    active = entry.holiday,
                    onClick = { entry.holiday = !entry.holiday }
                )
            }
        }
        StudioHint(
            "Jornada máxima legal: ${FiscalData.Peru.JORNADA_HORAS_DIA.toInt()} horas al día y " +
                "${FiscalData.Peru.JORNADA_HORAS_SEMANA.toInt()} a la semana."
        )
    }

    val weekHours = totalRegular.add(totalOvertime)
    if (weekHours > BigDecimal(FiscalData.Peru.JORNADA_HORAS_SEMANA)) {
        StudioHint(
            "Vas ${Money.formatQuantity(weekHours)} horas en la semana, por encima de las 48 legales. " +
                "El exceso debe pagarse como sobretiempo."
        )
    }

    WorkTotals(
        rows = listOf(
            "Horas ordinarias" to Money.formatQuantity(totalRegular),
            "Horas extra" to Money.formatQuantity(totalOvertime),
            "Valor hora" to Money.format(hourlyRate, currency)
        ),
        total = "Total de la semana" to Money.format(totalPay, currency)
    )
}

@Composable
private fun NetSalaryTab(currency: CurrencyInfo) {
    var gross by rememberSaveable { mutableStateOf("2500") }
    var useOnp by rememberSaveable { mutableStateOf(false) }
    var afpIndex by rememberSaveable { mutableIntStateOf(1) }
    var familyAllowance by rememberSaveable { mutableStateOf(false) }
    var monthsWorked by rememberSaveable { mutableStateOf("6") }

    val afp = FiscalData.Peru.AFP_COMISIONES.getOrElse(afpIndex) { FiscalData.Peru.AFP_COMISIONES[1] }
    val result = PayrollEngine.netSalary(
        monthlyGross = Money.ofOrZero(gross),
        useOnp = useOnp,
        afpCommissionPercent = afp.second,
        familyAllowance = familyAllowance
    )

    ScienceCard("Sueldo bruto") {
        ScienceNumberField(gross, { gross = it }, "Remuneración mensual", Modifier.fillMaxWidth())
        StudioChipRow {
            StudioChip("ONP 13 %", useOnp, onClick = { useOnp = true })
            StudioChip("AFP", !useOnp, onClick = { useOnp = false })
            StudioChip("Asignación familiar", familyAllowance, onClick = { familyAllowance = !familyAllowance })
        }
        if (!useOnp) {
            StudioLabel("Tu AFP")
            StudioChipRow {
                FiscalData.Peru.AFP_COMISIONES.forEachIndexed { index, entry ->
                    StudioChip(
                        label = entry.first,
                        active = afpIndex == index,
                        onClick = { afpIndex = index },
                        caption = "${entry.second.toPlainString()} %"
                    )
                }
            }
        }
        if (familyAllowance) {
            StudioHint(
                "La asignación familiar es el 10 % del sueldo mínimo: " +
                    "${Money.format(FiscalData.Peru.ASIGNACION_FAMILIAR, currency)} para quien tiene hijos menores o estudiando."
            )
        }
    }

    ScienceCard("Descuentos") {
        result.details.forEach { (label, amount) ->
            MoneyRow(label, "− " + Money.format(amount, currency))
        }
        if (result.details.isEmpty()) {
            StudioHint("Con este sueldo no hay descuentos que aplicar.")
        }
        StudioHint(
            "EsSalud (9 %) NO se te descuenta: lo paga tu empleador aparte, " +
                "${Money.format(result.employerEsSalud, currency)} en este caso. Si aparece como descuento en tu boleta, reclama."
        )
    }

    WorkTotals(
        rows = listOf(
            "Sueldo bruto" to Money.format(result.gross, currency),
            "Total de descuentos" to "− " + Money.format(result.totalDeductions, currency)
        ),
        total = "Sueldo neto" to Money.format(result.net, currency)
    )

    ScienceCard("Gratificación, CTS y vacaciones") {
        ScienceNumberField(monthsWorked, { monthsWorked = it }, "Meses del semestre trabajados", Modifier.fillMaxWidth())
        val months = monthsWorked.toIntOrNull()?.coerceIn(0, 6) ?: 6
        val grat = PayrollEngine.gratificacion(Money.ofOrZero(gross), months)
        val cts = PayrollEngine.cts(Money.ofOrZero(gross), grat.amount, months)
        val vacaciones = PayrollEngine.vacacionesTruncas(Money.ofOrZero(gross), months)
        MoneyRow("Gratificación", Money.format(grat.amount, currency))
        MoneyRow("Bonificación extraordinaria 9 %", Money.format(grat.extra, currency))
        MoneyRow("Total a recibir en gratificación", Money.format(grat.total, currency), highlight = true)
        MoneyRow("CTS del semestre", Money.format(cts.total, currency))
        MoneyRow("Vacaciones truncas", Money.format(vacaciones.total, currency))
        StudioHint(grat.note)
        StudioHint(cts.note)
    }

    LegalNote(FiscalData.AVISO_CALCULO_REFERENCIAL)
}

@Composable
private fun HonorariosTab(currency: CurrencyInfo, context: android.content.Context) {
    var amount by rememberSaveable { mutableStateOf("2000") }
    var payerIsAgent by rememberSaveable { mutableStateOf(true) }
    var hasSuspension by rememberSaveable { mutableStateOf(false) }
    var monthlyAverage by rememberSaveable { mutableStateOf("") }

    val result = PayrollEngine.honorarios(
        gross = Money.ofOrZero(amount),
        payerIsAgent = payerIsAgent,
        hasSuspension = hasSuspension
    )

    ScienceCard("Recibo por honorarios") {
        ScienceNumberField(amount, { amount = it }, "Monto del recibo", Modifier.fillMaxWidth())
        StudioChipRow {
            StudioChip("Quien paga retiene", payerIsAgent, onClick = { payerIsAgent = !payerIsAgent })
            StudioChip("Tengo suspensión", hasSuspension, onClick = { hasSuspension = !hasSuspension })
        }
        StudioHint(result.explanation)
    }

    WorkTotals(
        rows = listOf(
            "Monto del recibo" to Money.format(result.gross, currency),
            "Retención de cuarta 8 %" to "− " + Money.format(result.retention, currency)
        ),
        total = "Te depositan" to Money.format(result.net, currency)
    )

    ScienceCard("¿Te conviene pedir la suspensión?") {
        ScienceNumberField(monthlyAverage, { monthlyAverage = it }, "Promedio que facturas al mes", Modifier.fillMaxWidth())
        val monthly = Money.parseOrNull(monthlyAverage)
        if (monthly != null && monthly.signum() > 0) {
            val projected = monthly.multiply(BigDecimal(12))
            StudioHint(PayrollEngine.suspensionAdvice(projected))
            MoneyRow("Proyección anual", Money.format(projected, currency))
            MoneyRow(
                "Tope para la suspensión",
                Money.format(FiscalData.Peru.SUSPENSION_ANUAL, currency),
                highlight = true
            )
        } else {
            StudioHint(
                "El tope anual para pedir la suspensión de retenciones es " +
                    "${Money.format(FiscalData.Peru.SUSPENSION_ANUAL, currency)}. El trámite es gratuito y virtual."
            )
        }
    }

    ScienceCard("Datos vigentes") {
        ScienceRow("UIT ${FiscalData.Peru.YEAR}", Money.format(FiscalData.Peru.UIT, currency))
        ScienceRow("Sueldo mínimo", Money.format(FiscalData.Peru.RMV, currency))
        ScienceRow("Recibo sin retención hasta", Money.format(FiscalData.Peru.TOPE_SIN_RETENCION, currency))
        ScienceRow("Deducción de 7 UIT", Money.format(FiscalData.Peru.DEDUCCION_7_UIT, currency))
        StudioHint(FiscalData.Peru.SOURCE_NOTE)
    }

    WorkActionButton(
        "Copiar el detalle",
        {
            copyToClipboard(
                context,
                "Recibo por honorarios",
                buildString {
                    appendLine("Monto: ${Money.format(result.gross, currency)}")
                    appendLine("Retención 8 %: ${Money.format(result.retention, currency)}")
                    appendLine("Neto a recibir: ${Money.format(result.net, currency)}")
                    append(result.explanation)
                }
            )
        },
        Icons.Rounded.ContentCopy
    )

    LegalNote(
        "La app no emite recibos por honorarios electrónicos: eso se hace en SUNAT " +
            "Operaciones en Línea. Aquí solo se calcula el monto."
    )
}
