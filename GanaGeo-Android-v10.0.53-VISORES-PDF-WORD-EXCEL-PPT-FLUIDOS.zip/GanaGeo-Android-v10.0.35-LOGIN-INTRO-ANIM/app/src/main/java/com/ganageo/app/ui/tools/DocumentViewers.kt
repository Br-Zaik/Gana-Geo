package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Xml
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.InvertColors
import androidx.compose.material.icons.rounded.NavigateBefore
import androidx.compose.material.icons.rounded.NavigateNext
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.sp

@Composable
fun PdfViewerScreen(
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val horizontalScrollState = rememberScrollState()
    var uriText by rememberSaveable { mutableStateOf<String?>(null) }
    val uri = uriText?.let(Uri::parse)
    var pageCount by rememberSaveable { mutableIntStateOf(0) }
    var loadingDocument by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var localPdfPath by remember { mutableStateOf<String?>(null) }
    var retryToken by remember { mutableIntStateOf(0) }
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    var showOverview by rememberSaveable { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selected,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            localPdfPath?.let { runCatching { File(it).delete() } }
            localPdfPath = null
            uriText = selected.toString()
            pageCount = 0
            loadError = null
            zoom = 1f
            showOverview = false
        }
    }

    LaunchedEffect(uriText, retryToken) {
        val selected = uri ?: run {
            pageCount = 0
            loadError = null
            localPdfPath = null
            onImmersiveChanged(false)
            return@LaunchedEffect
        }
        onImmersiveChanged(true)
        horizontalScrollState.scrollTo(0)
        listState.scrollToItem(0)
        loadingDocument = true
        loadError = null
        pageCount = 0

        val previousPath = localPdfPath
        val result = runCatching {
            val copy = copyPdfToViewerCache(context, selected)
            val count = localPdfPageCount(copy)
            require(count > 0) { "El PDF no contiene páginas." }
            // Renderiza la primera página antes de dar el archivo por válido.
            renderLocalPdfPage(copy, 0, maxWidth = 420).recycle()
            copy to count
        }

        result.onSuccess { (copy, count) ->
            previousPath?.takeIf { it != copy.absolutePath }?.let { runCatching { File(it).delete() } }
            localPdfPath = copy.absolutePath
            pageCount = count
        }.onFailure { error ->
            localPdfPath = null
            pageCount = 0
            loadError = when {
                error.message?.contains("password", ignoreCase = true) == true ->
                    "Este PDF está protegido y Android no pudo abrirlo."
                else -> error.message ?: "No se pudo abrir este PDF."
            }
        }
        loadingDocument = false
    }


    DisposableEffect(Unit) {
        onDispose {
            onImmersiveChanged(false)
            localPdfPath?.let { path -> runCatching { File(path).delete() } }
        }
    }

    if (uri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Visor gratuito · el archivo no se modifica", onBack)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Ningún PDF seleccionado", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { launcher.launch(arrayOf("application/pdf")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                        Text(" Abrir PDF")
                    }
                }
            }
        }
        return
    }

    val fileName = remember(uriText) { ToolFileUtils.displayName(context, uri) }
    val currentPage by remember {
        derivedStateOf {
            if (pageCount <= 0) 0
            else (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding(),
            color = Color(0xFF202124),
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = Color.White)
                }
                Text(
                    fileName,
                    modifier = Modifier.weight(1f),
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = { shareDocumentFile(context, uri, "application/pdf") }) {
                    Icon(Icons.Rounded.Share, contentDescription = "Compartir PDF", tint = Color.White)
                }
                IconButton(onClick = { launcher.launch(arrayOf("application/pdf")) }) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = "Cambiar PDF", tint = Color.White)
                }
            }
        }

        if (loadingDocument) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = NeonGreen)
                    Spacer(Modifier.height(14.dp))
                    Text("Abriendo PDF…", color = Color.White.copy(alpha = 0.78f))
                }
            }
        } else if (loadError != null || pageCount <= 0 || localPdfPath == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF202124)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("No se pudo abrir el PDF", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(
                            loadError ?: "El archivo no contiene páginas compatibles.",
                            color = Color.White.copy(alpha = 0.72f)
                        )
                        OutlinedButton(onClick = { retryToken++ }, modifier = Modifier.fillMaxWidth()) {
                            Text("Reintentar")
                        }
                        OutlinedButton(
                            onClick = { launcher.launch(arrayOf("application/pdf")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                            Text(" Elegir otro PDF")
                        }
                    }
                }
            }
        } else if (showOverview) {
            PdfOverview(
                localPdfPath = localPdfPath!!,
                pageCount = pageCount,
                onSelectPage = { index ->
                    showOverview = false
                    zoom = 1f
                    scope.launch {
                        kotlinx.coroutines.yield()
                        horizontalScrollState.scrollTo(0)
                        listState.scrollToItem(index)
                    }
                },
                onMessage = onMessage
            )
        } else {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212))
            ) {
                val viewerWidth = maxWidth * zoom
                val renderWidth = when {
                    zoom >= 2.4f -> 2400
                    zoom >= 1.5f -> 1900
                    else -> 1300
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(uriText) {
                            awaitEachGesture {
                                do {
                                    val event = awaitPointerEvent()
                                    val pressed = event.changes.filter { it.pressed }
                                    if (pressed.size >= 2) {
                                        val gestureZoom = event.calculateZoom()
                                        val pan = event.calculatePan()
                                        val oldZoom = zoom
                                        val newZoom = (oldZoom * gestureZoom).coerceIn(1f, 4f)
                                        zoom = newZoom

                                        if (newZoom <= 1.01f) {
                                            horizontalScrollState.dispatchRawDelta(
                                                -horizontalScrollState.value.toFloat()
                                            )
                                        } else if (pan.x != 0f) {
                                            horizontalScrollState.dispatchRawDelta(-pan.x)
                                        }

                                        if (pan.y != 0f) {
                                            listState.dispatchRawDelta(-pan.y)
                                        }
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                        .pointerInput(uriText) {
                            detectTapGestures(
                                onDoubleTap = { tap ->
                                    val oldZoom = zoom
                                    val newZoom = if (oldZoom > 1.1f) 1f else 2f
                                    zoom = newZoom
                                    scope.launch {
                                        kotlinx.coroutines.yield()
                                        if (newZoom == 1f) {
                                            horizontalScrollState.animateScrollTo(0)
                                        } else {
                                            val scaleChange = newZoom / oldZoom.coerceAtLeast(1f)
                                            val target = (
                                                (horizontalScrollState.value + tap.x) * scaleChange - tap.x
                                            ).toInt().coerceIn(0, horizontalScrollState.maxValue)
                                            horizontalScrollState.animateScrollTo(target)
                                        }
                                    }
                                }
                            )
                        }
                        .horizontalScroll(horizontalScrollState)
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .width(viewerWidth)
                            .fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = 4.dp,
                            end = 4.dp,
                            top = 4.dp,
                            bottom = 20.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(
                            count = pageCount,
                            key = { index -> "pdf_page_$index" },
                            contentType = { "pdf_page" }
                        ) { index ->
                            ContinuousPdfPage(
                                localPdfPath = localPdfPath!!,
                                pageIndex = index,
                                renderWidth = renderWidth,
                                onMessage = onMessage
                            )
                        }
                    }
                }

                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 10.dp, end = 12.dp)
                        .clickable { showOverview = true },
                    color = Color.White.copy(alpha = 0.94f),
                    contentColor = Color(0xFF303134),
                    shape = RoundedCornerShape(18.dp),
                    shadowElevation = 3.dp
                ) {
                    Row(
                        modifier = Modifier.padding(start = 12.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            "$currentPage/$pageCount",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        PdfGridGlyph()
                    }
                }

                val progress = if (pageCount <= 1) 0f
                else (currentPage - 1).toFloat() / (pageCount - 1).toFloat()

                BoxWithConstraints(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxSize()
                        .padding(top = 54.dp, bottom = 18.dp)
                ) {
                    val thumbHeight = 48.dp
                    val travel = (maxHeight - thumbHeight).coerceAtLeast(0.dp)
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .width(28.dp)
                            .height(maxHeight)
                            .pointerInput(pageCount) {
                                fun jumpTo(y: Float) {
                                    if (pageCount <= 1 || size.height <= 0) return
                                    val fraction = (y / size.height.toFloat()).coerceIn(0f, 1f)
                                    val target = (fraction * (pageCount - 1)).toInt()
                                    scope.launch { listState.scrollToItem(target) }
                                }
                                detectVerticalDragGestures(
                                    onDragStart = { offset -> jumpTo(offset.y) },
                                    onVerticalDrag = { change, _ ->
                                        change.consume()
                                        jumpTo(change.position.y)
                                    }
                                )
                            }
                    ) {
                        Surface(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .offset(y = travel * progress)
                                .width(18.dp)
                                .height(thumbHeight),
                            color = Color(0xFF7A7A7A).copy(alpha = 0.86f),
                            shape = RoundedCornerShape(10.dp),
                            shadowElevation = 2.dp
                        ) {}
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfGridGlyph() {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(3) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                repeat(3) {
                    Box(
                        modifier = Modifier
                            .size(3.dp)
                            .background(Color(0xFF5F6368), RoundedCornerShape(1.dp))
                    )
                }
            }
        }
    }
}

@Composable
private fun PdfOverview(
    localPdfPath: String,
    pageCount: Int,
    onSelectPage: (Int) -> Unit,
    onMessage: (String) -> Unit
) {
    val rowCount = (pageCount + 2) / 3
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF171717)),
        contentPadding = PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(count = rowCount, key = { "pdf_overview_row_$it" }) { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                repeat(3) { column ->
                    val pageIndex = row * 3 + column
                    if (pageIndex < pageCount) {
                        PdfThumbnail(
                            localPdfPath = localPdfPath,
                            pageIndex = pageIndex,
                            modifier = Modifier.weight(1f),
                            onClick = { onSelectPage(pageIndex) },
                            onMessage = onMessage
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfThumbnail(
    localPdfPath: String,
    pageIndex: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var bitmap by remember(localPdfPath, pageIndex) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(localPdfPath, pageIndex) {
        runCatching {
            renderLocalPdfPage(File(localPdfPath), pageIndex, maxWidth = 360)
        }.onSuccess { fresh ->
            val previous = bitmap
            bitmap = fresh
            previous?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure {
            onMessage(it.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
        }
    }

    DisposableEffect(localPdfPath, pageIndex) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    Column(
        modifier = modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            val current = bitmap
            if (current != null) {
                Image(
                    bitmap = current.asImageBitmap(),
                    contentDescription = "Página ${pageIndex + 1}",
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = NeonGreen,
                        strokeWidth = 2.dp
                    )
                }
            }
        }
        Text(
            "${pageIndex + 1}",
            color = Color.White.copy(alpha = 0.78f),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun ContinuousPdfPage(
    localPdfPath: String,
    pageIndex: Int,
    renderWidth: Int,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var bitmap by remember(localPdfPath, pageIndex, renderWidth) { mutableStateOf<Bitmap?>(null) }
    var loading by remember(localPdfPath, pageIndex, renderWidth) { mutableStateOf(true) }

    LaunchedEffect(localPdfPath, pageIndex, renderWidth) {
        loading = true
        runCatching {
            renderLocalPdfPage(File(localPdfPath), pageIndex, maxWidth = renderWidth)
        }.onSuccess { fresh ->
            val previous = bitmap
            bitmap = fresh
            previous?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure {
            onMessage(it.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
        }
        loading = false
    }

    DisposableEffect(localPdfPath, pageIndex, renderWidth) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        val current = bitmap
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = "Página ${pageIndex + 1}",
                contentScale = ContentScale.FillWidth,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                if (loading) CircularProgressIndicator(color = NeonGreen)
            }
        }
    }
}


private suspend fun copyPdfToViewerCache(context: android.content.Context, source: Uri): File =
    withContext(Dispatchers.IO) {
        val directory = File(context.cacheDir, "pdf_viewer").apply { mkdirs() }
        directory.listFiles()?.forEach { old ->
            if (System.currentTimeMillis() - old.lastModified() > 6 * 60 * 60 * 1000L) {
                runCatching { old.delete() }
            }
        }
        val file = File(directory, "viewer_${System.currentTimeMillis()}_${kotlin.random.Random.nextInt(1000, 9999)}.pdf")
        try {
            context.contentResolver.openInputStream(source)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output, bufferSize = 128 * 1024) }
            } ?: error("No se pudo leer el archivo seleccionado.")
            require(file.length() > 0L) { "El archivo PDF está vacío." }
            file
        } catch (error: Throwable) {
            runCatching { file.delete() }
            throw error
        }
    }

private suspend fun localPdfPageCount(file: File): Int = withContext(Dispatchers.IO) {
    require(file.exists() && file.length() > 0L) { "El PDF no está disponible." }
    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
        PdfRenderer(descriptor).use { renderer -> renderer.pageCount }
    }
}

private suspend fun renderLocalPdfPage(
    file: File,
    pageIndex: Int,
    maxWidth: Int
): Bitmap = withContext(Dispatchers.IO) {
    require(file.exists() && file.length() > 0L) { "El PDF no está disponible." }
    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
        PdfRenderer(descriptor).use { renderer ->
            require(renderer.pageCount > 0) { "El PDF no contiene páginas." }
            require(pageIndex in 0 until renderer.pageCount) { "La página indicada no existe." }
            renderer.openPage(pageIndex).use { page ->
                var width = min(maxWidth, page.width * 2).coerceAtLeast(240)
                var height = (width.toFloat() / page.width.toFloat() * page.height.toFloat())
                    .roundToInt()
                    .coerceAtLeast(240)
                val pixels = width.toLong() * height.toLong()
                val maxPixels = 8_000_000L
                if (pixels > maxPixels) {
                    val scale = sqrt(maxPixels.toDouble() / pixels.toDouble()).toFloat()
                    width = (width * scale).roundToInt().coerceAtLeast(1)
                    height = (height * scale).roundToInt().coerceAtLeast(1)
                }
                Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
                    eraseColor(AndroidColor.WHITE)
                    page.render(this, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                }
            }
        }
    }
}

enum class OfficeViewerType(val label: String, val extensions: String, val mimeTypes: Array<String>) {
    WORD("Word", "DOCX", arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")),
    EXCEL("Excel", "XLSX", arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")),
    POWERPOINT("PowerPoint", "PPTX", arrayOf("application/vnd.openxmlformats-officedocument.presentationml.presentation"))
}

private sealed interface OfficeDocumentModel

private data class WordDocumentModel(val pages: List<WordPageModel>) : OfficeDocumentModel
private data class WordPageModel(val blocks: List<WordBlockModel>)
private sealed interface WordBlockModel {
    data class Paragraph(val text: String) : WordBlockModel
    data class Picture(val entryName: String) : WordBlockModel
    data class Table(val rows: List<List<String>>) : WordBlockModel
}

private data class ExcelWorkbookModel(
    val sharedStrings: List<String>,
    val sheets: List<ExcelSheetRef>,
    val styles: List<ExcelCellStyleModel>
) : OfficeDocumentModel
private data class ExcelSheetRef(val name: String, val entryName: String)
private data class ExcelSheetData(
    val rows: List<ExcelRowData>,
    val maxColumns: Int
)
private data class ExcelRowData(val rowNumber: Int, val cells: Map<Int, ExcelCellData>)
private data class ExcelCellData(val value: String, val styleIndex: Int)
private data class ExcelCellStyleModel(
    val fillArgb: Int? = null,
    val textArgb: Int? = null,
    val bold: Boolean = false
)

private data class PowerPointDeckModel(
    val widthEmu: Long,
    val heightEmu: Long,
    val slides: List<PowerPointSlideModel>
) : OfficeDocumentModel
private data class PowerPointSlideModel(
    val elements: List<PowerPointElementModel>,
    val transition: String?,
    val advanceAfterMs: Long?,
    val backgroundArgb: Int? = null
)
private sealed interface PowerPointElementModel {
    val x: Long
    val y: Long
    val width: Long
    val height: Long

    data class TextBox(
        val text: String,
        val textArgb: Int?,
        val fontSizePt: Float?,
        val bold: Boolean,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel

    data class Rectangle(
        val fillArgb: Int,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel

    data class Picture(
        val entryName: String,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel
}

@Composable
fun OfficeViewerScreen(
    tool: ToolId,
    type: OfficeViewerType,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    var uriText by rememberSaveable { mutableStateOf<String?>(null) }
    val uri = uriText?.let(Uri::parse)
    var localPath by remember { mutableStateOf<String?>(null) }
    var model by remember { mutableStateOf<OfficeDocumentModel?>(null) }
    var loading by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var retryToken by remember { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var searchVisible by rememberSaveable { mutableStateOf(false) }
    var inverted by rememberSaveable { mutableStateOf(false) }
    var presenting by rememberSaveable { mutableStateOf(false) }
    var presentationStart by rememberSaveable { mutableIntStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selected,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            localPath?.let { runCatching { File(it).delete() } }
            localPath = null
            model = null
            loadError = null
            query = ""
            presenting = false
            uriText = selected.toString()
        }
    }

    LaunchedEffect(uriText, retryToken) {
        val selected = uri ?: run {
            onImmersiveChanged(false)
            return@LaunchedEffect
        }
        onImmersiveChanged(true)
        loading = true
        loadError = null
        model = null
        val previous = localPath
        val result = runCatching {
            val copy = copyOfficeToViewerCache(context, selected, type)
            val parsed = withContext(Dispatchers.IO) {
                when (type) {
                    OfficeViewerType.WORD -> parseDocxModel(copy)
                    OfficeViewerType.EXCEL -> parseXlsxWorkbook(copy)
                    OfficeViewerType.POWERPOINT -> parsePptxDeck(copy)
                }
            }
            copy to parsed
        }
        result.onSuccess { (copy, parsed) ->
            previous?.takeIf { it != copy.absolutePath }?.let { runCatching { File(it).delete() } }
            localPath = copy.absolutePath
            model = parsed
        }.onFailure { error ->
            localPath = null
            model = null
            loadError = error.message ?: "No se pudo abrir el archivo ${type.extensions}."
        }
        loading = false
    }

    DisposableEffect(Unit) {
        onDispose {
            onImmersiveChanged(false)
            localPath?.let { runCatching { File(it).delete() } }
        }
    }

    androidx.activity.compose.BackHandler(enabled = presenting) { presenting = false }

    if (uri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Visor gratuito ${type.extensions} · sin edición", onBack)
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Ningún archivo seleccionado", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { launcher.launch(type.mimeTypes) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                        Text(" Abrir ${type.label}")
                    }
                    Text(
                        when (type) {
                            OfficeViewerType.WORD -> "Vista por páginas, zoom, búsqueda e invertir colores."
                            OfficeViewerType.EXCEL -> "Hojas, cuadrícula, zoom, búsqueda e invertir colores."
                            OfficeViewerType.POWERPOINT -> "Diapositivas, zoom, búsqueda, invertir colores y modo Presentar."
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        return
    }

    val fileName = remember(uriText) { ToolFileUtils.displayName(context, uri) }
    val path = localPath
    val currentModel = model

    if (presenting && type == OfficeViewerType.POWERPOINT && path != null && currentModel is PowerPointDeckModel) {
        PowerPointPresentation(
            localPath = path,
            deck = currentModel,
            initialSlide = presentationStart,
            inverted = inverted,
            onExit = { presenting = false }
        )
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF121212))
    ) {
        OfficeViewerTopBar(
            fileName = fileName,
            type = type,
            onBack = onBack,
            onOpen = { launcher.launch(type.mimeTypes) }
        )

        if (searchVisible) {
            ViewerSearchBar(
                query = query,
                onQueryChange = { query = it.take(120) },
                onClose = { query = ""; searchVisible = false }
            )
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when {
                loading -> ViewerLoading("Abriendo ${type.label}…")
                loadError != null || path == null || currentModel == null -> ViewerLoadError(
                    message = loadError ?: "No se pudo leer el archivo.",
                    onRetry = { retryToken++ },
                    onChooseOther = { launcher.launch(type.mimeTypes) }
                )
                type == OfficeViewerType.WORD && currentModel is WordDocumentModel -> WordDocumentViewer(
                    localPath = path,
                    document = currentModel,
                    query = query,
                    inverted = inverted,
                    onMessage = onMessage
                )
                type == OfficeViewerType.EXCEL && currentModel is ExcelWorkbookModel -> ExcelWorkbookViewer(
                    localPath = path,
                    workbook = currentModel,
                    query = query,
                    inverted = inverted,
                    onMessage = onMessage
                )
                type == OfficeViewerType.POWERPOINT && currentModel is PowerPointDeckModel -> PowerPointDeckViewer(
                    localPath = path,
                    deck = currentModel,
                    query = query,
                    inverted = inverted,
                    onMessage = onMessage,
                    onPresentFrom = { index -> presentationStart = index; presenting = true }
                )
            }
        }

        OfficeViewerBottomBar(
            type = type,
            inverted = inverted,
            onOpen = { launcher.launch(type.mimeTypes) },
            onSearch = { searchVisible = !searchVisible },
            onInvert = { inverted = !inverted },
            onShare = { shareDocumentFile(context, uri, type.mimeTypes.first()) },
            onPresent = if (type == OfficeViewerType.POWERPOINT && currentModel is PowerPointDeckModel) {
                { presentationStart = 0; presenting = true }
            } else null
        )
    }
}

@Composable
private fun OfficeViewerTopBar(
    fileName: String,
    type: OfficeViewerType,
    onBack: () -> Unit,
    onOpen: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth().statusBarsPadding(),
        color = Color(0xFF202124),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(54.dp).padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = Color.White)
            }
            Text(
                fileName,
                modifier = Modifier.weight(1f),
                color = Color.White,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = onOpen) {
                Icon(Icons.Rounded.FolderOpen, contentDescription = "Cambiar ${type.label}", tint = Color.White)
            }
        }
    }
}

@Composable
private fun OfficeViewerBottomBar(
    type: OfficeViewerType,
    inverted: Boolean,
    onOpen: () -> Unit,
    onSearch: () -> Unit,
    onInvert: () -> Unit,
    onShare: () -> Unit,
    onPresent: (() -> Unit)?
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFF202124),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            if (type == OfficeViewerType.POWERPOINT && onPresent != null) {
                ViewerBottomAction(
                    icon = Icons.Rounded.Slideshow,
                    label = "Presentar",
                    selected = false,
                    onClick = onPresent
                )
            } else {
                ViewerBottomAction(
                    icon = Icons.Rounded.FolderOpen,
                    label = if (type == OfficeViewerType.EXCEL) "Libro" else "Abrir",
                    selected = false,
                    onClick = onOpen
                )
            }
            ViewerBottomAction(Icons.Rounded.Search, "Buscar", false, onSearch)
            ViewerBottomAction(Icons.Rounded.InvertColors, "Invertir", inverted, onInvert)
            ViewerBottomAction(Icons.Rounded.Share, "Compartir", false, onShare)
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.ViewerBottomAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier.weight(1f).fillMaxHeight().clickable(onClick = onClick).padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (selected) NeonGreen else Color.White.copy(alpha = 0.88f),
            modifier = Modifier.size(20.dp)
        )
        Text(
            label,
            color = if (selected) NeonGreen else Color.White.copy(alpha = 0.82f),
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1
        )
    }
}

@Composable
private fun ViewerSearchBar(query: String, onQueryChange: (String) -> Unit, onClose: () -> Unit) {
    Surface(color = Color(0xFF292A2D), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Buscar en el archivo") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = "Cerrar búsqueda", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ViewerLoading(label: String) {
    Box(Modifier.fillMaxSize().background(Color(0xFF121212)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = NeonGreen)
            Spacer(Modifier.height(12.dp))
            Text(label, color = Color.White.copy(alpha = 0.78f))
        }
    }
}

@Composable
private fun ViewerLoadError(message: String, onRetry: () -> Unit, onChooseOther: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xFF121212)).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202124)), shape = RoundedCornerShape(20.dp)) {
            Column(
                Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("No se pudo abrir el archivo", color = Color.White, fontWeight = FontWeight.Bold)
                Text(message, color = Color.White.copy(alpha = 0.72f))
                OutlinedButton(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text("Reintentar") }
                OutlinedButton(onClick = onChooseOther, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                    Text(" Elegir otro archivo")
                }
            }
        }
    }
}

@Composable
private fun WordDocumentViewer(
    localPath: String,
    document: WordDocumentModel,
    query: String,
    inverted: Boolean,
    onMessage: (String) -> Unit
) {
    val listState = rememberLazyListState()
    val horizontalState = rememberScrollState()
    val scope = rememberCoroutineScope()
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    val matchingPages = remember(document, query) {
        if (query.isBlank()) emptySet()
        else document.pages.mapIndexedNotNull { index, page ->
            if (page.blocks.any { block -> wordBlockContains(block, query) }) index else null
        }.toSet()
    }
    val currentPage by remember(document.pages.size) {
        derivedStateOf { (listState.firstVisibleItemIndex + 1).coerceIn(1, document.pages.size.coerceAtLeast(1)) }
    }
    LaunchedEffect(query, matchingPages) {
        if (query.isNotBlank()) matchingPages.minOrNull()?.let { listState.animateScrollToItem(it) }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(if (inverted) Color.Black else Color(0xFF303030))) {
        val pageWidth = maxWidth * zoom
        val pageHeight = pageWidth * 1.294f
        Box(
            modifier = Modifier.fillMaxSize()
                .pointerInput(localPath) {
                    awaitEachGesture {
                        do {
                            val event = awaitPointerEvent()
                            if (event.changes.count { it.pressed } >= 2) {
                                val newZoom = (zoom * event.calculateZoom()).coerceIn(1f, 3.5f)
                                zoom = newZoom
                                val pan = event.calculatePan()
                                if (newZoom <= 1.01f) horizontalState.dispatchRawDelta(-horizontalState.value.toFloat())
                                else if (pan.x != 0f) horizontalState.dispatchRawDelta(-pan.x)
                                if (pan.y != 0f) listState.dispatchRawDelta(-pan.y)
                                event.changes.forEach { it.consume() }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
                .pointerInput(localPath) {
                    detectTapGestures(onDoubleTap = {
                        zoom = if (zoom > 1.1f) 1f else 2f
                        scope.launch { if (zoom == 1f) horizontalState.animateScrollTo(0) }
                    })
                }
                .horizontalScroll(horizontalState)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.width(pageWidth).fillMaxHeight(),
                contentPadding = PaddingValues(8.dp, 8.dp, 8.dp, 28.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(document.pages, key = { index, _ -> "word_page_$index" }) { index, page ->
                    WordPageCard(
                        localPath = localPath,
                        page = page,
                        pageHeight = pageHeight,
                        inverted = inverted,
                        matched = index in matchingPages,
                        onMessage = onMessage
                    )
                }
            }
        }
        Surface(
            modifier = Modifier.align(Alignment.TopEnd).padding(10.dp),
            color = Color.White.copy(alpha = 0.94f),
            contentColor = Color(0xFF303134),
            shape = RoundedCornerShape(18.dp),
            shadowElevation = 3.dp
        ) {
            Text(
                "$currentPage/${document.pages.size} · ${(zoom * 100).roundToInt()}%",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun WordPageCard(
    localPath: String,
    page: WordPageModel,
    pageHeight: androidx.compose.ui.unit.Dp,
    inverted: Boolean,
    matched: Boolean,
    onMessage: (String) -> Unit
) {
    val pageColor = if (inverted) Color(0xFF111111) else Color.White
    val textColor = if (inverted) Color(0xFFF1F1F1) else Color(0xFF181818)
    Column(
        modifier = Modifier.fillMaxWidth().height(pageHeight)
            .clip(RoundedCornerShape(2.dp))
            .background(pageColor)
            .then(if (matched) Modifier.border(3.dp, NeonGreen) else Modifier)
            .padding(horizontal = 28.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        page.blocks.forEach { block ->
            when (block) {
                is WordBlockModel.Paragraph -> if (block.text.isNotBlank()) {
                    Text(
                        block.text,
                        color = textColor,
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 20.sp
                    )
                }
                is WordBlockModel.Picture -> OfficeZipImage(
                    localPath = localPath,
                    entryName = block.entryName,
                    inverted = inverted,
                    modifier = Modifier.fillMaxWidth().heightIn(max = pageHeight * 0.34f),
                    onMessage = onMessage
                )
                is WordBlockModel.Table -> WordTableBlock(block, inverted)
            }
        }
    }
}

@Composable
private fun WordTableBlock(table: WordBlockModel.Table, inverted: Boolean) {
    val fg = if (inverted) Color(0xFFF1F1F1) else Color(0xFF202124)
    val grid = if (inverted) Color(0xFF686868) else Color(0xFFB7B7B7)
    Column(Modifier.fillMaxWidth().border(0.7.dp, grid)) {
        table.rows.take(12).forEach { row ->
            val columns = row.size.coerceAtLeast(1)
            Row(Modifier.fillMaxWidth()) {
                if (row.isEmpty()) {
                    Box(Modifier.weight(1f).height(28.dp).border(0.5.dp, grid))
                } else {
                    row.forEach { cell ->
                        Box(
                            Modifier.weight(1f).heightIn(min = 28.dp).border(0.5.dp, grid).padding(5.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(cell, color = fg, style = MaterialTheme.typography.bodySmall, maxLines = 4, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

private fun wordBlockContains(block: WordBlockModel, query: String): Boolean = when (block) {
    is WordBlockModel.Paragraph -> block.text.contains(query, true)
    is WordBlockModel.Picture -> false
    is WordBlockModel.Table -> block.rows.any { row -> row.any { it.contains(query, true) } }
}

@Composable
private fun ExcelWorkbookViewer(
    localPath: String,
    workbook: ExcelWorkbookModel,
    query: String,
    inverted: Boolean,
    onMessage: (String) -> Unit
) {
    var selectedSheet by rememberSaveable(localPath) { mutableIntStateOf(0) }
    var sheetData by remember(localPath, selectedSheet) { mutableStateOf<ExcelSheetData?>(null) }
    var loadingSheet by remember(localPath, selectedSheet) { mutableStateOf(true) }
    var sheetError by remember(localPath, selectedSheet) { mutableStateOf<String?>(null) }
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    val listState = rememberLazyListState()
    val horizontalState = rememberScrollState()
    var selectedCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    LaunchedEffect(localPath, selectedSheet) {
        loadingSheet = true
        sheetError = null
        sheetData = null
        runCatching {
            withContext(Dispatchers.IO) {
                parseXlsxSheet(File(localPath), workbook.sheets[selectedSheet], workbook.sharedStrings)
            }
        }.onSuccess { sheetData = it }
            .onFailure { sheetError = it.message ?: "No se pudo leer esta hoja."; onMessage(sheetError!!) }
        loadingSheet = false
    }

    Column(Modifier.fillMaxSize().background(if (inverted) Color.Black else Color(0xFFF3F3F3))) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .background(if (inverted) Color(0xFF161616) else Color(0xFFE7E7E7))
                .padding(horizontal = 8.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            workbook.sheets.forEachIndexed { index, sheet ->
                Surface(
                    modifier = Modifier.clickable {
                        selectedSheet = index
                        selectedCell = null
                    },
                    color = if (index == selectedSheet) NeonGreen.copy(alpha = 0.22f) else Color.Transparent,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        sheet.name,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        color = if (inverted) Color.White else Color(0xFF202124),
                        fontWeight = if (index == selectedSheet) FontWeight.Bold else FontWeight.Normal,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }
        if (loadingSheet) {
            ViewerLoading("Cargando hoja…")
            return@Column
        }
        val data = sheetData
        if (sheetError != null || data == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(sheetError ?: "Hoja no disponible", color = if (inverted) Color.White else Color.DarkGray)
            }
        } else {
            BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
                val cellWidth = 112.dp * zoom
                val rowHeight = 42.dp * zoom
                val rowHeaderWidth = 52.dp * zoom
                val totalWidth = rowHeaderWidth + cellWidth * data.maxColumns.coerceAtLeast(1).toFloat()
                Box(
                    modifier = Modifier.fillMaxSize()
                        .pointerInput(localPath, selectedSheet) {
                            awaitEachGesture {
                                do {
                                    val event = awaitPointerEvent()
                                    if (event.changes.count { it.pressed } >= 2) {
                                        zoom = (zoom * event.calculateZoom()).coerceIn(0.65f, 2.4f)
                                        val pan = event.calculatePan()
                                        if (pan.x != 0f) horizontalState.dispatchRawDelta(-pan.x)
                                        if (pan.y != 0f) listState.dispatchRawDelta(-pan.y)
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                        .horizontalScroll(horizontalState)
                ) {
                    Column(Modifier.width(totalWidth).fillMaxHeight()) {
                        ExcelColumnHeaders(data.maxColumns, rowHeaderWidth, cellWidth, rowHeight, inverted)
                        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth()) {
                            items(data.rows.size, key = { index -> "excel_row_${data.rows[index].rowNumber}" }) { index ->
                                val row = data.rows[index]
                                ExcelGridRow(
                                    row = row,
                                    maxColumns = data.maxColumns,
                                    rowHeaderWidth = rowHeaderWidth,
                                    cellWidth = cellWidth,
                                    rowHeight = rowHeight,
                                    query = query,
                                    inverted = inverted,
                                    styles = workbook.styles,
                                    selectedCell = selectedCell,
                                    onCellSelected = { col -> selectedCell = row.rowNumber to col }
                                )
                            }
                        }
                    }
                }
                Surface(
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                    color = Color(0xEFFFFFFF),
                    contentColor = Color(0xFF303134),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("${(zoom * 100).roundToInt()}%", Modifier.padding(horizontal = 10.dp, vertical = 5.dp), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ExcelColumnHeaders(
    maxColumns: Int,
    rowHeaderWidth: androidx.compose.ui.unit.Dp,
    cellWidth: androidx.compose.ui.unit.Dp,
    rowHeight: androidx.compose.ui.unit.Dp,
    inverted: Boolean
) {
    val bg = if (inverted) Color(0xFF252525) else Color(0xFFE6E6E6)
    val fg = if (inverted) Color.White else Color(0xFF333333)
    Row {
        Box(Modifier.width(rowHeaderWidth).height(rowHeight).background(bg).border(0.5.dp, Color.Gray.copy(alpha = 0.5f)))
        repeat(maxColumns) { col ->
            Box(
                Modifier.width(cellWidth).height(rowHeight).background(bg).border(0.5.dp, Color.Gray.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Text(excelColumnName(col), color = fg, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ExcelGridRow(
    row: ExcelRowData,
    maxColumns: Int,
    rowHeaderWidth: androidx.compose.ui.unit.Dp,
    cellWidth: androidx.compose.ui.unit.Dp,
    rowHeight: androidx.compose.ui.unit.Dp,
    query: String,
    inverted: Boolean,
    styles: List<ExcelCellStyleModel>,
    selectedCell: Pair<Int, Int>?,
    onCellSelected: (Int) -> Unit
) {
    val bg = if (inverted) Color(0xFF101010) else Color.White
    val headerBg = if (inverted) Color(0xFF252525) else Color(0xFFE6E6E6)
    val fg = if (inverted) Color(0xFFF1F1F1) else Color(0xFF202124)
    Row {
        Box(
            Modifier.width(rowHeaderWidth).height(rowHeight).background(headerBg).border(0.5.dp, Color.Gray.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) { Text(row.rowNumber.toString(), color = fg, style = MaterialTheme.typography.labelMedium) }
        repeat(maxColumns) { col ->
            val cell = row.cells[col]
            val value = cell?.value.orEmpty()
            val style = styles.getOrNull(cell?.styleIndex ?: 0)
            val styledBg = style?.fillArgb?.let { Color(if (inverted) invertArgb(it) else it) } ?: bg
            val styledFg = style?.textArgb?.let { Color(if (inverted) invertArgb(it) else it) } ?: fg
            val isMatch = query.isNotBlank() && value.contains(query, ignoreCase = true)
            val isSelected = selectedCell == (row.rowNumber to col)
            Box(
                modifier = Modifier.width(cellWidth).height(rowHeight).background(styledBg)
                    .border(
                        width = if (isSelected || isMatch) 2.dp else 0.5.dp,
                        color = if (isSelected || isMatch) NeonGreen else Color.Gray.copy(alpha = 0.42f)
                    )
                    .clickable { onCellSelected(col) }
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    value,
                    color = styledFg,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (style?.bold == true) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
private fun PowerPointDeckViewer(
    localPath: String,
    deck: PowerPointDeckModel,
    query: String,
    inverted: Boolean,
    onMessage: (String) -> Unit,
    onPresentFrom: (Int) -> Unit
) {
    val horizontalState = rememberScrollState()
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    val filteredIndices = remember(deck, query) {
        if (query.isBlank()) deck.slides.indices.toList()
        else deck.slides.indices.filter { index ->
            deck.slides[index].elements.any { element ->
                element is PowerPointElementModel.TextBox && element.text.contains(query, true)
            }
        }
    }

    if (filteredIndices.isEmpty()) {
        Box(Modifier.fillMaxSize().background(if (inverted) Color.Black else Color(0xFF252525)), contentAlignment = Alignment.Center) {
            Text("No hay coincidencias", color = Color.White)
        }
        return
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(if (inverted) Color.Black else Color(0xFF252525))) {
        val slideWidth = maxWidth * zoom
        val ratio = deck.widthEmu.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f)
        val slideHeight = slideWidth / ratio
        Box(
            Modifier.fillMaxSize()
                .pointerInput(localPath) {
                    awaitEachGesture {
                        do {
                            val event = awaitPointerEvent()
                            if (event.changes.count { it.pressed } >= 2) {
                                zoom = (zoom * event.calculateZoom()).coerceIn(1f, 3.2f)
                                val pan = event.calculatePan()
                                if (zoom <= 1.01f) horizontalState.dispatchRawDelta(-horizontalState.value.toFloat())
                                else if (pan.x != 0f) horizontalState.dispatchRawDelta(-pan.x)
                                if (pan.y != 0f) listState.dispatchRawDelta(-pan.y)
                                event.changes.forEach { it.consume() }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
                .pointerInput(localPath) {
                    detectTapGestures(onDoubleTap = {
                        zoom = if (zoom > 1.1f) 1f else 1.8f
                        scope.launch { if (zoom == 1f) horizontalState.animateScrollTo(0) }
                    })
                }
                .horizontalScroll(horizontalState)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.width(slideWidth).fillMaxHeight(),
                contentPadding = PaddingValues(8.dp, 8.dp, 8.dp, 30.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredIndices.size, key = { position -> "ppt_slide_${filteredIndices[position]}" }) { position ->
                    val slideIndex = filteredIndices[position]
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PowerPointSlideCanvas(
                            localPath = localPath,
                            deck = deck,
                            slide = deck.slides[slideIndex],
                            inverted = inverted,
                            modifier = Modifier.fillMaxWidth().height(slideHeight).clickable { onPresentFrom(slideIndex) },
                            onMessage = onMessage
                        )
                        Text(
                            "${slideIndex + 1}/${deck.slides.size}",
                            color = Color.White.copy(alpha = 0.78f),
                            modifier = Modifier.padding(start = 4.dp),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
        Surface(
            modifier = Modifier.align(Alignment.TopEnd).padding(10.dp),
            color = Color.White.copy(alpha = 0.94f),
            contentColor = Color(0xFF303134),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text("${(zoom * 100).roundToInt()}%", Modifier.padding(horizontal = 10.dp, vertical = 6.dp), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PowerPointPresentation(
    localPath: String,
    deck: PowerPointDeckModel,
    initialSlide: Int,
    inverted: Boolean,
    onExit: () -> Unit
) {
    var current by rememberSaveable(localPath, initialSlide) { mutableIntStateOf(initialSlide.coerceIn(0, deck.slides.lastIndex)) }
    var direction by remember { mutableIntStateOf(1) }
    var controlsVisible by remember { mutableStateOf(true) }
    var dragAmount by remember { mutableFloatStateOf(0f) }

    val goTo: (Int) -> Unit = { target ->
        val fixed = target.coerceIn(0, deck.slides.lastIndex)
        direction = if (fixed >= current) 1 else -1
        current = fixed
    }

    val autoMs = deck.slides[current].advanceAfterMs
    LaunchedEffect(current, autoMs) {
        if (autoMs != null && autoMs in 200L..120000L && current < deck.slides.lastIndex) {
            kotlinx.coroutines.delay(autoMs)
            goTo(current + 1)
        }
    }
    LaunchedEffect(controlsVisible, current) {
        if (controlsVisible) {
            kotlinx.coroutines.delay(1800L)
            controlsVisible = false
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(current) {
                detectHorizontalDragGestures(
                    onDragStart = { dragAmount = 0f },
                    onHorizontalDrag = { change, amount ->
                        change.consume()
                        dragAmount += amount
                    },
                    onDragEnd = {
                        when {
                            dragAmount < -80f && current < deck.slides.lastIndex -> goTo(current + 1)
                            dragAmount > 80f && current > 0 -> goTo(current - 1)
                        }
                        dragAmount = 0f
                    }
                )
            }
            .pointerInput(current) { detectTapGestures(onTap = { controlsVisible = !controlsVisible }) },
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.animation.AnimatedContent(
            targetState = current,
            transitionSpec = { powerPointTransition(deck.slides[targetState].transition, direction) },
            label = "ppt_transition"
        ) { index ->
            PowerPointSlideCanvas(
                localPath = localPath,
                deck = deck,
                slide = deck.slides[index],
                inverted = inverted,
                modifier = Modifier.fillMaxWidth().aspectRatio(deck.widthEmu.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f)),
                onMessage = {}
            )
        }

        if (controlsVisible) {
            Surface(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding(),
                color = Color(0xCC111111)
            ) {
                Row(Modifier.height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onExit) {
                        Icon(Icons.Rounded.Close, contentDescription = "Salir", tint = Color.White)
                    }
                    Text("Presentando", color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("${current + 1}/${deck.slides.size}", color = Color.White.copy(alpha = 0.85f), modifier = Modifier.padding(end = 14.dp))
                }
            }
            Row(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 22.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Surface(shape = RoundedCornerShape(24.dp), color = Color(0xCC202124)) {
                    IconButton(onClick = { if (current > 0) goTo(current - 1) }) {
                        Icon(Icons.Rounded.NavigateBefore, contentDescription = "Anterior", tint = Color.White)
                    }
                }
                Surface(shape = RoundedCornerShape(24.dp), color = Color(0xCC202124)) {
                    IconButton(onClick = { if (current < deck.slides.lastIndex) goTo(current + 1) }) {
                        Icon(Icons.Rounded.NavigateNext, contentDescription = "Siguiente", tint = Color.White)
                    }
                }
            }
        }
    }
}

private fun powerPointTransition(name: String?, direction: Int): androidx.compose.animation.ContentTransform {
    val normalized = name.orEmpty().lowercase()
    val enterOffset: (Int) -> Int = { width -> if (direction >= 0) width else -width }
    val exitOffset: (Int) -> Int = { width -> if (direction >= 0) -width else width }
    return when {
        normalized.contains("fade") || normalized.contains("dissolve") ->
            androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(280)) togetherWith
                androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(240))

        normalized.contains("zoom") || normalized.contains("newsflash") ||
            normalized.contains("wheel") || normalized.contains("wedge") ->
            (androidx.compose.animation.scaleIn(androidx.compose.animation.core.tween(320), initialScale = 0.88f) +
                androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(250))) togetherWith
                (androidx.compose.animation.scaleOut(androidx.compose.animation.core.tween(260), targetScale = 1.10f) +
                    androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(220)))

        normalized.contains("split") || normalized.contains("diamond") ||
            normalized.contains("circle") || normalized.contains("plus") ->
            (androidx.compose.animation.scaleIn(androidx.compose.animation.core.tween(280), initialScale = 0.96f) +
                androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220))) togetherWith
                (androidx.compose.animation.scaleOut(androidx.compose.animation.core.tween(240), targetScale = 0.96f) +
                    androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200)))

        normalized.contains("randombar") || normalized.contains("checker") || normalized.contains("blinds") ->
            androidx.compose.animation.slideInVertically(
                androidx.compose.animation.core.tween(300),
                initialOffsetY = { height -> if (direction >= 0) height / 3 else -height / 3 }
            ) togetherWith androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(240))

        normalized.contains("cut") || normalized.contains("none") ->
            androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(80)) togetherWith
                androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(80))

        else ->
            androidx.compose.animation.slideInHorizontally(
                androidx.compose.animation.core.tween(300),
                initialOffsetX = enterOffset
            ) togetherWith androidx.compose.animation.slideOutHorizontally(
                androidx.compose.animation.core.tween(300),
                targetOffsetX = exitOffset
            )
    }
}

@Composable
private fun PowerPointSlideCanvas(
    localPath: String,
    deck: PowerPointDeckModel,
    slide: PowerPointSlideModel,
    inverted: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    val rawBackground = slide.backgroundArgb ?: 0xFFFFFFFF.toInt()
    val background = Color(if (inverted) invertArgb(rawBackground) else rawBackground)
    val defaultForeground = if (pptIsDark(rawBackground) xor inverted) Color.White else Color(0xFF171717)
    BoxWithConstraints(
        modifier = modifier.clip(RoundedCornerShape(4.dp)).background(background)
    ) {
        slide.elements.forEach { element ->
            val left = maxWidth * (element.x.toFloat() / deck.widthEmu.toFloat().coerceAtLeast(1f))
            val top = maxHeight * (element.y.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f))
            val width = maxWidth * (element.width.toFloat() / deck.widthEmu.toFloat().coerceAtLeast(1f))
            val height = maxHeight * (element.height.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f))
            when (element) {
                is PowerPointElementModel.TextBox -> {
                    val rawText = element.textArgb
                    val textColor = if (rawText != null) Color(if (inverted) invertArgb(rawText) else rawText) else defaultForeground
                    val fontSp = (element.fontSizePt?.times(0.62f)
                        ?: if (element.height > deck.heightEmu / 7) 20f else 13f).coerceIn(8f, 28f)
                    Text(
                        element.text,
                        color = textColor,
                        modifier = Modifier.offset(left, top).width(width).height(height).padding(2.dp),
                        fontSize = fontSp.sp,
                        fontWeight = if (element.bold) FontWeight.Bold else FontWeight.Normal,
                        overflow = TextOverflow.Ellipsis,
                        maxLines = 10
                    )
                }
                is PowerPointElementModel.Rectangle -> {
                    val rawFill = element.fillArgb
                    Box(
                        Modifier.offset(left, top).width(width).height(height)
                            .background(Color(if (inverted) invertArgb(rawFill) else rawFill))
                    )
                }
                is PowerPointElementModel.Picture -> OfficeZipImage(
                    localPath = localPath,
                    entryName = element.entryName,
                    inverted = inverted,
                    modifier = Modifier.offset(left, top).width(width).height(height),
                    onMessage = onMessage
                )
            }
        }
    }
}

@Composable
private fun OfficeZipImage(
    localPath: String,
    entryName: String,
    inverted: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    var bitmap by remember(localPath, entryName) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(localPath, entryName) {
        runCatching {
            withContext(Dispatchers.IO) {
                java.util.zip.ZipFile(File(localPath)).use { zip ->
                    decodeOfficeZipBitmap(zip, entryName)
                }
            }
        }.onSuccess { fresh ->
            val old = bitmap
            bitmap = fresh
            old?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure { onMessage(it.message ?: "No se pudo mostrar una imagen del documento.") }
    }
    DisposableEffect(localPath, entryName) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }
    val current = bitmap
    if (current != null) {
        Image(
            bitmap = current.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = modifier,
            colorFilter = if (inverted) officeInvertColorFilter() else null
        )
    } else {
        Box(modifier.background(if (inverted) Color(0xFF1E1E1E) else Color(0xFFF1F1F1)), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = NeonGreen, strokeWidth = 2.dp)
        }
    }
}


private fun decodeOfficeZipBitmap(zip: java.util.zip.ZipFile, entryName: String): Bitmap {
    val entry = zip.getEntry(entryName) ?: error("Imagen no encontrada")
    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    zip.getInputStream(entry).use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    val largest = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
    while (largest / sample > 2200) sample *= 2
    val options = android.graphics.BitmapFactory.Options().apply {
        inSampleSize = sample.coerceAtLeast(1)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return zip.getInputStream(entry).use { input ->
        android.graphics.BitmapFactory.decodeStream(input, null, options)
    } ?: error("Imagen no compatible")
}

private fun officeInvertColorFilter(): androidx.compose.ui.graphics.ColorFilter =
    androidx.compose.ui.graphics.ColorFilter.colorMatrix(
        androidx.compose.ui.graphics.ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

private fun shareDocumentFile(context: android.content.Context, uri: Uri, mime: String) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = mime
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { context.startActivity(android.content.Intent.createChooser(intent, "Compartir archivo")) }
}

private suspend fun copyOfficeToViewerCache(
    context: android.content.Context,
    source: Uri,
    type: OfficeViewerType
): File = withContext(Dispatchers.IO) {
    val directory = File(context.cacheDir, "office_viewer").apply { mkdirs() }
    directory.listFiles()?.forEach { old ->
        if (System.currentTimeMillis() - old.lastModified() > 6 * 60 * 60 * 1000L) runCatching { old.delete() }
    }
    val extension = type.extensions.lowercase()
    val file = File(directory, "viewer_${System.currentTimeMillis()}_${kotlin.random.Random.nextInt(1000, 9999)}.$extension")
    try {
        context.contentResolver.openInputStream(source)?.use { input ->
            FileOutputStream(file).use { output -> input.copyTo(output, 128 * 1024) }
        } ?: error("No se pudo leer el archivo seleccionado.")
        require(file.length() > 0) { "El archivo está vacío." }
        java.util.zip.ZipFile(file).use { require(it.entries().hasMoreElements()) { "El archivo no tiene contenido OOXML válido." } }
        file
    } catch (error: Throwable) {
        runCatching { file.delete() }
        throw error
    }
}

private fun parseDocxModel(file: File): WordDocumentModel {
    java.util.zip.ZipFile(file).use { zip ->
        val documentEntry = zip.getEntry("word/document.xml") ?: error("El DOCX no contiene document.xml.")
        val relationships = parseZipRelationships(zip, "word/_rels/document.xml.rels", "word/document.xml")
        val rawPages = mutableListOf<MutableList<WordBlockModel>>(mutableListOf())
        var paragraphText = StringBuilder()
        var paragraphImages = mutableListOf<String>()
        var inParagraph = false
        var pageBreak = false
        var explicitBreakSeen = false
        var tableDepth = -1
        var rowDepth = -1
        var cellDepth = -1
        var tableRows = mutableListOf<MutableList<String>>()
        var currentRow = mutableListOf<String>()
        var currentCell = StringBuilder()

        val parser = Xml.newPullParser()
        zip.getInputStream(documentEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "tbl" -> if (tableDepth < 0) {
                            tableDepth = parser.depth
                            tableRows = mutableListOf()
                        }
                        "tr" -> if (tableDepth > 0 && rowDepth < 0) {
                            rowDepth = parser.depth
                            currentRow = mutableListOf()
                        }
                        "tc" -> if (tableDepth > 0 && cellDepth < 0) {
                            cellDepth = parser.depth
                            currentCell = StringBuilder()
                        }
                        "p" -> {
                            inParagraph = true
                            paragraphText = StringBuilder()
                            paragraphImages = mutableListOf()
                            pageBreak = false
                        }
                        "t" -> if (inParagraph) paragraphText.append(parser.nextText())
                        "tab" -> if (inParagraph) paragraphText.append('\t')
                        "br" -> if (inParagraph) {
                            val type = attributeByLocalName(parser, "type")
                            if (type == "page") { pageBreak = true; explicitBreakSeen = true } else paragraphText.append('\n')
                        }
                        "lastRenderedPageBreak" -> if (inParagraph) { pageBreak = true; explicitBreakSeen = true }
                        "blip" -> if (inParagraph) {
                            val relId = attributeByLocalName(parser, "embed")
                            relId?.let { relationships[it] }?.let(paragraphImages::add)
                        }
                    }
                    XmlPullParser.END_TAG -> when {
                        parser.name == "p" && inParagraph -> {
                            val text = paragraphText.toString().trim()
                            if (tableDepth > 0 && cellDepth > 0) {
                                if (text.isNotBlank()) {
                                    if (currentCell.isNotEmpty()) currentCell.append('\n')
                                    currentCell.append(text)
                                }
                            } else {
                                if (text.isNotBlank()) rawPages.last().add(WordBlockModel.Paragraph(text))
                                paragraphImages.distinct().forEach { rawPages.last().add(WordBlockModel.Picture(it)) }
                                if (pageBreak && rawPages.last().isNotEmpty()) rawPages.add(mutableListOf())
                            }
                            inParagraph = false
                        }
                        parser.name == "tc" && cellDepth > 0 && parser.depth == cellDepth -> {
                            currentRow += currentCell.toString().trim()
                            currentCell = StringBuilder()
                            cellDepth = -1
                        }
                        parser.name == "tr" && rowDepth > 0 && parser.depth == rowDepth -> {
                            tableRows += currentRow
                            currentRow = mutableListOf()
                            rowDepth = -1
                        }
                        parser.name == "tbl" && tableDepth > 0 && parser.depth == tableDepth -> {
                            if (tableRows.isNotEmpty()) rawPages.last().add(WordBlockModel.Table(tableRows.map { it.toList() }))
                            tableRows = mutableListOf()
                            tableDepth = -1
                        }
                    }
                }
                event = parser.next()
            }
        }
        if (rawPages.lastOrNull()?.isEmpty() == true && rawPages.size > 1) rawPages.removeAt(rawPages.lastIndex)
        val pages = if (explicitBreakSeen) {
            rawPages.filter { it.isNotEmpty() }.map { WordPageModel(it.toList()) }
        } else repaginateWord(rawPages)
        require(pages.isNotEmpty()) { "El DOCX no contiene contenido visible." }
        return WordDocumentModel(pages)
    }
}

private fun repaginateWord(rawPages: List<List<WordBlockModel>>): List<WordPageModel> {
    val result = mutableListOf<WordPageModel>()
    rawPages.forEach { raw ->
        var current = mutableListOf<WordBlockModel>()
        var cost = 0
        fun flush() {
            if (current.isNotEmpty()) {
                result += WordPageModel(current)
                current = mutableListOf()
                cost = 0
            }
        }
        raw.forEach { block ->
            val blockCost = when (block) {
                is WordBlockModel.Paragraph -> 1 + block.text.length / 95
                is WordBlockModel.Picture -> 7
                is WordBlockModel.Table -> 3 + block.rows.size * 2
            }
            if (cost + blockCost > 28 && current.isNotEmpty()) flush()
            current += block
            cost += blockCost
        }
        flush()
    }
    return result
}

private fun parseXlsxWorkbook(file: File): ExcelWorkbookModel {
    java.util.zip.ZipFile(file).use { zip ->
        val shared = zip.getEntry("xl/sharedStrings.xml")?.let { entry ->
            zip.getInputStream(entry).use(::parseSharedStringsStream)
        }.orEmpty()
        val styles = zip.getEntry("xl/styles.xml")?.let { entry ->
            zip.getInputStream(entry).use(::parseExcelStylesStream)
        }.orEmpty().ifEmpty { listOf(ExcelCellStyleModel()) }
        val relationships = parseZipRelationships(zip, "xl/_rels/workbook.xml.rels", "xl/workbook.xml")
        val workbookEntry = zip.getEntry("xl/workbook.xml") ?: error("El XLSX no contiene workbook.xml.")
        val sheets = mutableListOf<ExcelSheetRef>()
        val parser = Xml.newPullParser()
        zip.getInputStream(workbookEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name == "sheet") {
                    val name = parser.getAttributeValue(null, "name").orEmpty().ifBlank { "Hoja ${sheets.size + 1}" }
                    val relId = relationshipIdAttribute(parser)
                    val target = relId?.let { relationships[it] }
                    if (!target.isNullOrBlank()) sheets += ExcelSheetRef(name, target)
                }
                event = parser.next()
            }
        }
        require(sheets.isNotEmpty()) { "El XLSX no contiene hojas legibles." }
        return ExcelWorkbookModel(shared, sheets, styles)
    }
}

private fun parseXlsxSheet(file: File, ref: ExcelSheetRef, shared: List<String>): ExcelSheetData {
    java.util.zip.ZipFile(file).use { zip ->
        val entry = zip.getEntry(ref.entryName) ?: error("No se encontró la hoja ${ref.name}.")
        val rows = mutableListOf<ExcelRowData>()
        var rowNumber = 0
        var cells = linkedMapOf<Int, ExcelCellData>()
        var cellRef = ""
        var cellType: String? = null
        var cellStyleIndex = 0
        var value = StringBuilder()
        var inline = StringBuilder()
        var formula = StringBuilder()
        var captureValue = false
        var captureInline = false
        var captureFormula = false
        var maxColumn = 0
        val parser = Xml.newPullParser()
        zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "row" -> {
                            rowNumber = parser.getAttributeValue(null, "r")?.toIntOrNull() ?: (rows.lastOrNull()?.rowNumber?.plus(1) ?: 1)
                            cells = linkedMapOf()
                        }
                        "c" -> {
                            cellRef = parser.getAttributeValue(null, "r").orEmpty()
                            cellType = parser.getAttributeValue(null, "t")
                            cellStyleIndex = parser.getAttributeValue(null, "s")?.toIntOrNull() ?: 0
                            value = StringBuilder(); inline = StringBuilder(); formula = StringBuilder()
                        }
                        "v" -> captureValue = true
                        "t" -> captureInline = true
                        "f" -> captureFormula = true
                    }
                    XmlPullParser.TEXT -> {
                        if (captureValue) value.append(parser.text.orEmpty())
                        if (captureInline) inline.append(parser.text.orEmpty())
                        if (captureFormula) formula.append(parser.text.orEmpty())
                    }
                    XmlPullParser.END_TAG -> when (parser.name) {
                        "v" -> captureValue = false
                        "t" -> captureInline = false
                        "f" -> captureFormula = false
                        "c" -> {
                            val col = excelColumnIndex(cellRef)
                            if (col >= 0) {
                                val raw = value.toString()
                                val shown = when (cellType) {
                                    "s" -> shared.getOrNull(raw.toIntOrNull() ?: -1).orEmpty()
                                    "inlineStr", "str" -> inline.toString().ifBlank { raw }
                                    "b" -> if (raw == "1") "VERDADERO" else if (raw == "0") "FALSO" else raw
                                    else -> raw.ifBlank { formula.toString().takeIf { it.isNotBlank() }?.let { "=$it" }.orEmpty() }
                                }
                                if (shown.isNotBlank() || cellStyleIndex != 0) cells[col] = ExcelCellData(shown, cellStyleIndex)
                                maxColumn = maxOf(maxColumn, col + 1)
                            }
                        }
                        "row" -> rows += ExcelRowData(rowNumber, cells.toMap())
                    }
                }
                event = parser.next()
            }
        }
        if (rows.isEmpty()) rows += ExcelRowData(1, emptyMap())
        return ExcelSheetData(rows, maxColumn.coerceAtLeast(1).coerceAtMost(256))
    }
}

private fun parseExcelStylesStream(input: java.io.InputStream): List<ExcelCellStyleModel> {
    data class FontStyle(val color: Int?, val bold: Boolean)
    val fonts = mutableListOf<FontStyle>()
    val fills = mutableListOf<Int?>()
    val styles = mutableListOf<ExcelCellStyleModel>()
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    var fontsDepth = -1
    var fillsDepth = -1
    var cellXfsDepth = -1
    var fontDepth = -1
    var fillDepth = -1
    var fontColor: Int? = null
    var fontBold = false
    var fillColor: Int? = null
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> when (parser.name) {
                "fonts" -> fontsDepth = parser.depth
                "fills" -> fillsDepth = parser.depth
                "cellXfs" -> cellXfsDepth = parser.depth
                "font" -> if (fontsDepth > 0 && parser.depth == fontsDepth + 1) {
                    fontDepth = parser.depth
                    fontColor = null
                    fontBold = false
                }
                "b" -> if (fontDepth > 0) fontBold = true
                "color" -> if (fontDepth > 0) {
                    fontColor = parseExcelArgb(parser.getAttributeValue(null, "rgb")) ?: fontColor
                }
                "fill" -> if (fillsDepth > 0 && parser.depth == fillsDepth + 1) {
                    fillDepth = parser.depth
                    fillColor = null
                }
                "fgColor" -> if (fillDepth > 0) {
                    fillColor = parseExcelArgb(parser.getAttributeValue(null, "rgb")) ?: fillColor
                }
                "xf" -> if (cellXfsDepth > 0 && parser.depth == cellXfsDepth + 1) {
                    val fontId = parser.getAttributeValue(null, "fontId")?.toIntOrNull() ?: 0
                    val fillId = parser.getAttributeValue(null, "fillId")?.toIntOrNull() ?: 0
                    val font = fonts.getOrNull(fontId)
                    styles += ExcelCellStyleModel(
                        fillArgb = fills.getOrNull(fillId),
                        textArgb = font?.color,
                        bold = font?.bold == true
                    )
                }
            }
            XmlPullParser.END_TAG -> when {
                parser.name == "font" && parser.depth == fontDepth -> {
                    fonts += FontStyle(fontColor, fontBold)
                    fontDepth = -1
                }
                parser.name == "fill" && parser.depth == fillDepth -> {
                    fills += fillColor
                    fillDepth = -1
                }
                parser.name == "fonts" && parser.depth == fontsDepth -> fontsDepth = -1
                parser.name == "fills" && parser.depth == fillsDepth -> fillsDepth = -1
                parser.name == "cellXfs" && parser.depth == cellXfsDepth -> cellXfsDepth = -1
            }
        }
        event = parser.next()
    }
    return styles.ifEmpty { listOf(ExcelCellStyleModel()) }
}

private fun parseExcelArgb(value: String?): Int? {
    val clean = value?.trim()?.removePrefix("#") ?: return null
    val raw = clean.toLongOrNull(16) ?: return null
    return when (clean.length) {
        6 -> (0xFF000000L or raw).toInt()
        8 -> raw.toInt()
        else -> null
    }
}

private fun parsePptxDeck(file: File): PowerPointDeckModel {
    java.util.zip.ZipFile(file).use { zip ->
        val presentationEntry = zip.getEntry("ppt/presentation.xml") ?: error("El PPTX no contiene presentation.xml.")
        var width = 12192000L
        var height = 6858000L
        val slideRelIds = mutableListOf<String>()
        val parser = Xml.newPullParser()
        zip.getInputStream(presentationEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    when (parser.name) {
                        "sldSz" -> {
                            width = parser.getAttributeValue(null, "cx")?.toLongOrNull() ?: width
                            height = parser.getAttributeValue(null, "cy")?.toLongOrNull() ?: height
                        }
                        "sldId" -> relationshipIdAttribute(parser)?.let(slideRelIds::add)
                    }
                }
                event = parser.next()
            }
        }
        val presentationRels = parseZipRelationships(zip, "ppt/_rels/presentation.xml.rels", "ppt/presentation.xml")
        val orderedSlides = slideRelIds.mapNotNull { presentationRels[it] }.ifEmpty {
            zip.entries().asSequence().map { it.name }
                .filter { it.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
                .sortedBy { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
                .toList()
        }
        val slides = orderedSlides.mapIndexed { index, slideEntry ->
            parsePowerPointSlide(zip, slideEntry, width, height, index)
        }
        require(slides.isNotEmpty()) { "El PPTX no contiene diapositivas legibles." }
        return PowerPointDeckModel(width, height, slides)
    }
}

private fun parsePowerPointSlide(
    zip: java.util.zip.ZipFile,
    slideEntry: String,
    deckWidth: Long,
    deckHeight: Long,
    slideIndex: Int
): PowerPointSlideModel {
    val entry = zip.getEntry(slideEntry) ?: error("Diapositiva no encontrada.")
    val fileName = slideEntry.substringAfterLast('/')
    val relEntry = slideEntry.substringBeforeLast('/') + "/_rels/$fileName.rels"
    val rels = parseZipRelationships(zip, relEntry, slideEntry)
    val elements = mutableListOf<PowerPointElementModel>()
    var shapeKind: String? = null
    var shapeDepth = -1
    var text = StringBuilder()
    var relId: String? = null
    var x = 0L; var y = 0L; var w = 0L; var h = 0L
    var shapeFillArgb: Int? = null
    var textArgb: Int? = null
    var textFontSizePt: Float? = null
    var textBold = false
    var spPrDepth = -1
    var rPrDepth = -1
    var solidFillDepth = -1
    var lineDepth = -1
    var transition: String? = null
    var advanceAfterMs: Long? = null
    var transitionDepth = -1
    var backgroundArgb: Int? = null
    var bgDepth = -1
    var bgSolidFillDepth = -1

    val parser = Xml.newPullParser()
    zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    if (parser.name == "bg" && shapeKind == null) bgDepth = parser.depth
                    if (bgDepth > 0 && parser.name == "solidFill") bgSolidFillDepth = parser.depth
                    if (bgSolidFillDepth > 0 && parser.name == "srgbClr" && backgroundArgb == null) {
                        backgroundArgb = parseRgbArgb(parser.getAttributeValue(null, "val"))
                    }

                    if ((parser.name == "sp" || parser.name == "pic") && shapeKind == null) {
                        shapeKind = parser.name
                        shapeDepth = parser.depth
                        text = StringBuilder(); relId = null; x = 0; y = 0; w = 0; h = 0
                        shapeFillArgb = null; textArgb = null; textFontSizePt = null; textBold = false
                        spPrDepth = -1; rPrDepth = -1; solidFillDepth = -1; lineDepth = -1
                    } else if (parser.name == "transition" && shapeKind == null) {
                        transitionDepth = parser.depth
                        advanceAfterMs = parser.getAttributeValue(null, "advTm")?.toLongOrNull()
                    } else if (transitionDepth > 0 && parser.depth == transitionDepth + 1 && transition == null) {
                        transition = parser.name
                    }

                    if (shapeKind != null) {
                        when (parser.name) {
                            "spPr" -> spPrDepth = parser.depth
                            "rPr", "defRPr", "endParaRPr" -> {
                                rPrDepth = parser.depth
                                parser.getAttributeValue(null, "sz")?.toFloatOrNull()?.let { size ->
                                    if (textFontSizePt == null) textFontSizePt = size / 100f
                                }
                                val boldValue = parser.getAttributeValue(null, "b")
                                if (boldValue == "1" || boldValue.equals("true", true)) textBold = true
                            }
                            "ln" -> if (spPrDepth > 0) lineDepth = parser.depth
                            "solidFill" -> solidFillDepth = parser.depth
                            "srgbClr" -> {
                                val color = parseRgbArgb(parser.getAttributeValue(null, "val"))
                                if (color != null) {
                                    if (rPrDepth > 0) textArgb = textArgb ?: color
                                    else if (spPrDepth > 0 && solidFillDepth > 0 && lineDepth < 0) shapeFillArgb = shapeFillArgb ?: color
                                }
                            }
                            "t" -> text.append(parser.nextText())
                            "p" -> if (text.isNotEmpty() && text.last() != '\n') text.append('\n')
                            "off" -> {
                                x = parser.getAttributeValue(null, "x")?.toLongOrNull() ?: x
                                y = parser.getAttributeValue(null, "y")?.toLongOrNull() ?: y
                            }
                            "ext" -> {
                                w = parser.getAttributeValue(null, "cx")?.toLongOrNull() ?: w
                                h = parser.getAttributeValue(null, "cy")?.toLongOrNull() ?: h
                            }
                            "blip" -> relId = attributeByLocalName(parser, "embed") ?: relId
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "solidFill" -> {
                            if (parser.depth == solidFillDepth) solidFillDepth = -1
                            if (parser.depth == bgSolidFillDepth) bgSolidFillDepth = -1
                        }
                        "spPr" -> if (parser.depth == spPrDepth) spPrDepth = -1
                        "ln" -> if (parser.depth == lineDepth) lineDepth = -1
                        "rPr", "defRPr", "endParaRPr" -> if (parser.depth == rPrDepth) rPrDepth = -1
                        "bg" -> if (parser.depth == bgDepth) bgDepth = -1
                    }
                    if (transitionDepth > 0 && parser.name == "transition" && parser.depth == transitionDepth) transitionDepth = -1
                    if (shapeKind != null && parser.depth == shapeDepth && parser.name == shapeKind) {
                        val fallbackIndex = elements.size
                        val finalX = if (w > 0) x else deckWidth / 12
                        val finalY = if (h > 0) y else deckHeight / 12 + fallbackIndex * (deckHeight / 7)
                        val finalW = if (w > 0) w else deckWidth * 5 / 6
                        val finalH = if (h > 0) h else deckHeight / 6
                        when (shapeKind) {
                            "sp" -> {
                                shapeFillArgb?.let { elements += PowerPointElementModel.Rectangle(it, finalX, finalY, finalW, finalH) }
                                text.toString().trim().takeIf { it.isNotBlank() }?.let {
                                    elements += PowerPointElementModel.TextBox(it, textArgb, textFontSizePt, textBold, finalX, finalY, finalW, finalH)
                                }
                            }
                            "pic" -> relId?.let { rels[it] }?.let {
                                elements += PowerPointElementModel.Picture(it, finalX, finalY, finalW, finalH)
                            }
                        }
                        shapeKind = null
                        shapeDepth = -1
                    }
                }
            }
            event = parser.next()
        }
    }
    if (elements.isEmpty()) {
        elements += PowerPointElementModel.TextBox(
            "Diapositiva ${slideIndex + 1}", null, 24f, true,
            deckWidth / 10, deckHeight / 3, deckWidth * 4 / 5, deckHeight / 4
        )
    }
    return PowerPointSlideModel(elements, transition, advanceAfterMs, backgroundArgb)
}

private fun parseRgbArgb(value: String?): Int? {
    val clean = value?.trim()?.removePrefix("#") ?: return null
    if (clean.length != 6) return null
    val rgb = clean.toLongOrNull(16) ?: return null
    return (0xFF000000L or rgb).toInt()
}

private fun invertArgb(argb: Int): Int {
    val a = (argb ushr 24) and 0xFF
    val r = 255 - ((argb ushr 16) and 0xFF)
    val g = 255 - ((argb ushr 8) and 0xFF)
    val b = 255 - (argb and 0xFF)
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}

private fun pptIsDark(argb: Int): Boolean {
    val r = (argb ushr 16) and 0xFF
    val g = (argb ushr 8) and 0xFF
    val b = argb and 0xFF
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) < 145.0
}

private fun parseZipRelationships(
    zip: java.util.zip.ZipFile,
    relEntryName: String,
    sourceEntryName: String
): Map<String, String> {
    val entry = zip.getEntry(relEntryName) ?: return emptyMap()
    val result = linkedMapOf<String, String>()
    val parser = Xml.newPullParser()
    zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "Relationship") {
                val id = parser.getAttributeValue(null, "Id").orEmpty()
                val target = parser.getAttributeValue(null, "Target").orEmpty()
                val mode = parser.getAttributeValue(null, "TargetMode")
                if (id.isNotBlank() && target.isNotBlank() && !mode.equals("External", true)) {
                    result[id] = resolveZipTarget(sourceEntryName, target)
                }
            }
            event = parser.next()
        }
    }
    return result
}

private fun resolveZipTarget(sourceEntryName: String, target: String): String {
    if (target.startsWith('/')) return target.removePrefix("/")
    val base = sourceEntryName.substringBeforeLast('/', "")
    val combined = if (base.isBlank()) target else "$base/$target"
    val parts = mutableListOf<String>()
    combined.split('/').forEach { part ->
        when (part) {
            "", "." -> Unit
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
            else -> parts += part
        }
    }
    return parts.joinToString("/")
}

private fun attributeByLocalName(parser: XmlPullParser, localName: String): String? {
    for (index in 0 until parser.attributeCount) {
        if (parser.getAttributeName(index) == localName) return parser.getAttributeValue(index)
    }
    return null
}

private fun relationshipIdAttribute(parser: XmlPullParser): String? {
    // OOXML nodes such as p:sldId contain both a numeric `id` and an `r:id`.
    // Prefer the relationships namespace/prefix so slide/sheet ordering resolves correctly.
    for (index in 0 until parser.attributeCount) {
        val name = parser.getAttributeName(index)
        if (name != "id" && name != "r:id") continue
        val namespace = runCatching { parser.getAttributeNamespace(index) }.getOrNull().orEmpty()
        if (namespace.contains("relationships", ignoreCase = true) || name == "r:id") {
            return parser.getAttributeValue(index)
        }
    }
    // Most producers use rIdN. This fallback also works if namespace processing is disabled.
    for (index in 0 until parser.attributeCount) {
        val value = parser.getAttributeValue(index).orEmpty()
        if (value.startsWith("rId", ignoreCase = true)) return value
    }
    return null
}

private fun parseSharedStringsStream(input: java.io.InputStream): List<String> {
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    val values = mutableListOf<String>()
    var insideSi = false
    var current = StringBuilder()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> if (parser.name == "si") { insideSi = true; current = StringBuilder() }
            XmlPullParser.TEXT -> if (insideSi) current.append(parser.text.orEmpty())
            XmlPullParser.END_TAG -> if (parser.name == "si") { values += current.toString(); insideSi = false }
        }
        event = parser.next()
    }
    return values
}

private fun excelColumnIndex(cellRef: String): Int {
    var result = 0
    var found = false
    for (char in cellRef) {
        if (!char.isLetter()) break
        found = true
        result = result * 26 + (char.uppercaseChar() - 'A' + 1)
    }
    return if (found) result - 1 else -1
}

private fun excelColumnName(index: Int): String {
    var value = index + 1
    val out = StringBuilder()
    while (value > 0) {
        val rem = (value - 1) % 26
        out.append(('A'.code + rem).toChar())
        value = (value - 1) / 26
    }
    return out.reverse().toString()
}

