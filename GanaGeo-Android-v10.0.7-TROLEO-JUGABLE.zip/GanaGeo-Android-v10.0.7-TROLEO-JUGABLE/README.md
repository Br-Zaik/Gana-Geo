# Gana Geo Android v0.10.7 — Troleo jugable

Versión basada en v10.0.6. Mantiene intactos el inicio de sesión, Supabase, créditos, Geo Rewards, referidos, retiros y las herramientas ajenas a Geo Aventuras.

## Geo Aventuras

- Manzanas perseguidoras: caen primero y luego siguen a GEO lentamente como un proyectil volador. La persecución tiene duración y distancia máximas, y termina al chocar con una barrera o salir del área jugable.
- Pisos troll: las plataformas de proximidad ya no desaparecen desde lejos; se activan cuando GEO está realmente cerca o encima del tramo.
- Suelo que se abre: permanece integrado al piso y solo comienza cuando GEO llega a la sección. La apertura avanza un tramo corto sobre superficie continua.
- Pinchos retráctiles: algunos pinchos ocultos salen, se retraen y vuelven a aparecer. Los pinchos laterales y superiores se limitaron para no cerrar la única ruta.
- Nivel 2: se retiró el pincho que sellaba la plataforma corta, se redujo el pincho lateral suspendido y se añadieron trampas cíclicas con ventanas de paso.
- Ventiladores: se conservaron en los niveles, con fuerza limitada y ciclos de descanso. Los que coinciden con suelo abrible usan menor fuerza.
- Árboles troll: algunas trampas de fruta hacen caer el árbol después; otros árboles con manzanas son puramente decorativos y no hacen nada.
- Mecanismos: las antiguas barreras verdes/celestes ahora se dibujan como columnas de piedra con pinchos. Los aplastadores también usan acabado de piedra.
- Checkpoints: continúan distribuidos según la longitud y dificultad de cada nivel, siempre sobre plataformas sólidas y permanentes.
- Pantalla completa: se reforzó el fondo de ventana, edge-to-edge, soporte de recortes y actividad redimensionable para evitar franjas blancas u oscuras al rotar.

## Validación

- 20 pruebas puras de reglas y estructura superadas.
- 20 niveles generados.
- Todos los niveles conservan al menos un ventilador.
- Los checkpoints reales tienen plataforma sólida permanente.
- Los pinchos laterales/superiores ocultos quedan con altura limitada y ciclo de retracción.
- La compilación Android completa debe ejecutarse en GitHub Actions. En el entorno local no se pudo descargar Gradle 8.13 por falta de resolución DNS.
