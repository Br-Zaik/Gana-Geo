package com.ganageo.app.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object AdvancedFileUtils {
    data class TextPdfOptions(
        val title: String = "",
        val author: String = "",
        val fontSize: Float = 12f,
        val lineSpacing: Float = 1.35f,
        val paperSize: PdfPaperSize = PdfPaperSize.A4,
        val orientation: PdfOrientation = PdfOrientation.PORTRAIT,
        val margin: PdfMargin = PdfMargin.NORMAL,
        val pageNumbers: Boolean = true,
        val header: String = "",
        val bold: Boolean = false,
        val italic: Boolean = false,
        val underline: Boolean = false,
        val alignment: Int = 0
    )

    enum class WatermarkPosition(val label: String) {
        CENTER("Centro"), DIAGONAL("Diagonal"), TOP("Arriba"), BOTTOM("Abajo"), REPEAT("Repetida")
    }

    data class PdfWatermarkOptions(
        val text: String,
        val opacityPercent: Int = 25,
        val fontSize: Float = 42f,
        val position: WatermarkPosition = WatermarkPosition.DIAGONAL,
        val addPageNumbers: Boolean = false,
        val firstPageNumber: Int = 1,
        val pages: Set<Int> = emptySet()
    )

    enum class BatchImageMode(val label: String) {
        COMPRESS("Comprimir"),
        RESIZE("Cambiar tamaño"),
        CONVERT("Convertir formato"),
        REMOVE_METADATA("Quitar metadatos"),
        JOIN_VERTICAL("Unir vertical"),
        JOIN_HORIZONTAL("Unir horizontal"),
        COLLAGE("Crear collage"),
        PASSPORT_SHEET("Foto carnet"),
        SOLID_BACKGROUND("Fondo sólido"),
        FRAME("Marco y borde"),
        ZIP_ORIGINALS("Exportar ZIP")
    }

    data class BatchImageOptions(
        val mode: BatchImageMode,
        val outputFormat: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG,
        val quality: Int = 85,
        val maxEdge: Int = 1600,
        val backgroundColor: Int = Color.WHITE,
        val frameWidth: Int = 24,
        val columns: Int = 2,
        val passportWidthMm: Double = 35.0,
        val passportHeightMm: Double = 45.0,
        val passportCopies: Int = 8
    )

    suspend fun createScannedPdf(
        context: Context,
        pages: List<PdfImagePage>,
        output: Uri,
        options: ImagesToPdfOptions,
        autoCrop: Boolean,
        onProgress: (Int, Int) -> Unit = { _, _ -> }
    ) = withContext(Dispatchers.IO) {
        require(pages.isNotEmpty()) { "Agrega al menos una página" }
        require(pages.size <= ToolFileUtils.MAX_IMAGES_PER_PDF) { "Demasiadas páginas" }
        val tempFiles = mutableListOf<File>()
        try {
            val processed = pages.mapIndexed { index, page ->
                val source = ToolFileUtils.loadBitmap(context, page.uri, options.compression.maxImageEdge)
                try {
                    var current = if (autoCrop) autoDocumentCrop(source) else source.copy(Bitmap.Config.ARGB_8888, false)
                    if (page.rotationDegrees != 0) {
                        val rotated = ToolFileUtils.rotateFlip(current, page.rotationDegrees.toFloat(), false, false)
                        current.recycle()
                        current = rotated
                    }
                    val adjusted = ToolFileUtils.applyImageAdjustments(
                        current,
                        options.filter,
                        options.brightness,
                        options.contrast
                    )
                    if (adjusted !== current && !current.isRecycled) current.recycle()
                    val file = File(context.cacheDir, "scan_${UUID.randomUUID()}.jpg")
                    try {
                        FileOutputStream(file).use { outputStream ->
                            check(adjusted.compress(Bitmap.CompressFormat.JPEG, 94, outputStream))
                        }
                    } finally {
                        if (!adjusted.isRecycled) adjusted.recycle()
                    }
                    tempFiles += file
                    onProgress(index + 1, pages.size * 2)
                    PdfImagePage(Uri.fromFile(file))
                } finally {
                    source.recycle()
                }
            }
            ToolFileUtils.createPdfFromImages(
                context = context,
                pages = processed,
                output = output,
                options = options.copy(filter = DocumentImageFilter.ORIGINAL, brightness = 0, contrast = 1f),
                onProgress = { done, total -> onProgress(pages.size + done, pages.size + total) }
            )
        } finally {
            tempFiles.forEach(File::delete)
        }
    }

    suspend fun createTextPdf(
        context: Context,
        output: Uri,
        text: String,
        options: TextPdfOptions
    ) = withContext(Dispatchers.IO) {
        require(text.isNotBlank()) { "Escribe el contenido del documento" }
        require(text.length <= 300_000) { "El texto es demasiado largo" }
        require(options.fontSize in 8f..32f) { "Tamaño de letra inválido" }
        PDFBoxResourceLoader.init(context.applicationContext)
        val target = File(context.cacheDir, "text_pdf_${UUID.randomUUID()}.pdf")
        try {
            PDDocument().use { document ->
                val (width, height) = resolvePaper(options.paperSize, options.orientation)
                val margin = options.margin.points.toFloat().coerceAtLeast(20f)
                val usableWidth = width - margin * 2
                val lineHeight = options.fontSize * options.lineSpacing
                val bodyFont = when {
                    options.bold && options.italic -> PDType1Font.HELVETICA_BOLD_OBLIQUE
                    options.bold -> PDType1Font.HELVETICA_BOLD
                    options.italic -> PDType1Font.HELVETICA_OBLIQUE
                    else -> PDType1Font.HELVETICA
                }
                val boldFont = PDType1Font.HELVETICA_BOLD
                val paragraphs = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
                val lines = mutableListOf<String>()
                paragraphs.forEach { paragraph ->
                    if (paragraph.isBlank()) {
                        lines += ""
                    } else {
                        lines += wrapText(paragraph, bodyFont, options.fontSize, usableWidth)
                    }
                }
                val titleLines = if (options.title.isBlank()) emptyList() else wrapText(options.title, boldFont, options.fontSize + 5f, usableWidth)
                var lineIndex = 0
                var pageNumber = 1
                var titlePending = titleLines.isNotEmpty()
                while (lineIndex < lines.size || titlePending) {
                    val page = PDPage(PDRectangle(width, height))
                    document.addPage(page)
                    PDPageContentStream(document, page).use { stream ->
                        var y = height - margin
                        if (options.header.isNotBlank()) {
                            stream.beginText()
                            stream.setFont(PDType1Font.HELVETICA, 9f)
                            stream.newLineAtOffset(margin, y)
                            stream.showText(sanitizePdfText(options.header.take(180)))
                            stream.endText()
                            y -= 20f
                        }
                        if (titlePending) {
                            stream.setNonStrokingColor(20, 60, 35)
                            titleLines.forEach { line ->
                                stream.beginText()
                                stream.setFont(boldFont, options.fontSize + 5f)
                                stream.newLineAtOffset(margin, y)
                                stream.showText(sanitizePdfText(line))
                                stream.endText()
                                y -= (options.fontSize + 5f) * 1.25f
                            }
                            if (options.author.isNotBlank()) {
                                stream.beginText()
                                stream.setFont(PDType1Font.HELVETICA_OBLIQUE, 10f)
                                stream.newLineAtOffset(margin, y)
                                stream.showText(sanitizePdfText(options.author.take(160)))
                                stream.endText()
                                y -= 24f
                            }
                            y -= 10f
                            titlePending = false
                        }
                        stream.setNonStrokingColor(0, 0, 0)
                        while (lineIndex < lines.size && y > margin + 28f) {
                            val line = lines[lineIndex++]
                            if (line.isNotBlank()) {
                                val safeLine = sanitizePdfText(line)
                                val textWidth = bodyFont.getStringWidth(safeLine) / 1000f * options.fontSize
                                val x = when (options.alignment.coerceIn(0, 2)) {
                                    1 -> margin + ((usableWidth - textWidth) / 2f).coerceAtLeast(0f)
                                    2 -> margin + (usableWidth - textWidth).coerceAtLeast(0f)
                                    else -> margin
                                }
                                stream.beginText()
                                stream.setFont(bodyFont, options.fontSize)
                                stream.newLineAtOffset(x, y)
                                stream.showText(safeLine)
                                stream.endText()
                                if (options.underline) {
                                    stream.moveTo(x, y - 1.6f)
                                    stream.lineTo(x + textWidth.coerceAtMost(usableWidth), y - 1.6f)
                                    stream.setLineWidth(0.7f)
                                    stream.stroke()
                                }
                            }
                            y -= lineHeight
                        }
                        if (options.pageNumbers) {
                            val number = pageNumber.toString()
                            val widthNumber = PDType1Font.HELVETICA.getStringWidth(number) / 1000f * 9f
                            stream.beginText()
                            stream.setFont(PDType1Font.HELVETICA, 9f)
                            stream.newLineAtOffset((width - widthNumber) / 2f, 14f)
                            stream.showText(number)
                            stream.endText()
                        }
                    }
                    pageNumber++
                    require(pageNumber <= 500) { "El documento supera el límite de páginas" }
                }
                document.documentInformation.title = options.title
                document.documentInformation.author = options.author
                document.save(target)
            }
            copyFile(context, target, output)
        } finally {
            target.delete()
        }
    }

    suspend fun watermarkPdf(
        context: Context,
        input: Uri,
        output: Uri,
        options: PdfWatermarkOptions,
        password: String = ""
    ) = withContext(Dispatchers.IO) {
        require(options.text.isNotBlank() || options.addPageNumbers) { "Escribe una marca de agua o activa la numeración" }
        PDFBoxResourceLoader.init(context.applicationContext)
        val source = copyUriToTemp(context, input, ".pdf")
        val target = File(context.cacheDir, "watermark_${UUID.randomUUID()}.pdf")
        try {
            PDDocument.load(source, password).use { document ->
                require(document.numberOfPages in 1..ToolFileUtils.MAX_PDF_PAGES) { "PDF demasiado grande" }
                document.isAllSecurityToBeRemoved = true
                for (index in 0 until document.numberOfPages) {
                    val pageNumber = index + 1
                    if (options.pages.isNotEmpty() && pageNumber !in options.pages) continue
                    val page = document.getPage(index)
                    val box = page.mediaBox
                    PDPageContentStream(
                        document,
                        page,
                        PDPageContentStream.AppendMode.APPEND,
                        true,
                        true
                    ).use { stream ->
                        if (options.text.isNotBlank()) {
                            stream.setNonStrokingColor(90, 90, 90)
                            stream.setGraphicsStateParameters(
                                com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState().apply {
                                    setNonStrokingAlphaConstant(options.opacityPercent.coerceIn(5, 90) / 100f)
                                }
                            )
                            drawWatermark(stream, box, sanitizePdfText(options.text.take(120)), options)
                        }
                        if (options.addPageNumbers) {
                            val number = (options.firstPageNumber + index).toString()
                            val fontSize = 10f
                            val textWidth = PDType1Font.HELVETICA.getStringWidth(number) / 1000f * fontSize
                            stream.beginText()
                            stream.setFont(PDType1Font.HELVETICA, fontSize)
                            stream.setNonStrokingColor(40, 40, 40)
                            stream.newLineAtOffset((box.width - textWidth) / 2f, 16f)
                            stream.showText(number)
                            stream.endText()
                        }
                    }
                }
                document.save(target)
            }
            copyFile(context, target, output)
        } finally {
            source.delete()
            target.delete()
        }
    }

    suspend fun changePdfProtection(
        context: Context,
        input: Uri,
        output: Uri,
        currentPassword: String,
        newPassword: String?,
        allowPrinting: Boolean = true,
        allowCopying: Boolean = false
    ) = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(context.applicationContext)
        val source = copyUriToTemp(context, input, ".pdf")
        val target = File(context.cacheDir, "protected_${UUID.randomUUID()}.pdf")
        try {
            PDDocument.load(source, currentPassword).use { document ->
                document.isAllSecurityToBeRemoved = true
                val newValue = newPassword.orEmpty()
                if (newValue.isNotBlank()) {
                    require(newValue.length >= 4) { "La nueva contraseña debe tener al menos 4 caracteres" }
                    val permission = AccessPermission().apply {
                        setCanPrint(allowPrinting)
                        setCanExtractContent(allowCopying)
                        setCanModify(false)
                    }
                    document.protect(StandardProtectionPolicy(newValue, newValue, permission).apply {
                        setEncryptionKeyLength(128)
                        setPermissions(permission)
                    })
                }
                document.save(target)
            }
            copyFile(context, target, output)
        } finally {
            source.delete()
            target.delete()
        }
    }

    fun autoDocumentCrop(source: Bitmap): Bitmap {
        if (source.width < 80 || source.height < 80) return source.copy(source.config ?: Bitmap.Config.ARGB_8888, false)
        val sampleStep = max(1, min(source.width, source.height) / 300)
        val borderSamples = mutableListOf<Int>()
        for (x in 0 until source.width step sampleStep) {
            borderSamples += luminance(source.getPixel(x, 0))
            borderSamples += luminance(source.getPixel(x, source.height - 1))
        }
        for (y in 0 until source.height step sampleStep) {
            borderSamples += luminance(source.getPixel(0, y))
            borderSamples += luminance(source.getPixel(source.width - 1, y))
        }
        val borderAverage = borderSamples.average()
        val threshold = 28.0
        var minX = source.width
        var minY = source.height
        var maxX = 0
        var maxY = 0
        for (y in 0 until source.height step sampleStep) {
            for (x in 0 until source.width step sampleStep) {
                if (abs(luminance(source.getPixel(x, y)) - borderAverage) > threshold) {
                    minX = min(minX, x)
                    maxX = max(maxX, x)
                    minY = min(minY, y)
                    maxY = max(maxY, y)
                }
            }
        }
        if (minX >= maxX || minY >= maxY) return source.copy(source.config ?: Bitmap.Config.ARGB_8888, false)
        val paddingX = ((maxX - minX) * 0.02).roundToInt()
        val paddingY = ((maxY - minY) * 0.02).roundToInt()
        val left = (minX - paddingX).coerceAtLeast(0)
        val top = (minY - paddingY).coerceAtLeast(0)
        val right = (maxX + paddingX).coerceAtMost(source.width - 1)
        val bottom = (maxY + paddingY).coerceAtMost(source.height - 1)
        val cropWidth = right - left + 1
        val cropHeight = bottom - top + 1
        if (cropWidth < source.width * 0.25 || cropHeight < source.height * 0.25) {
            return source.copy(source.config ?: Bitmap.Config.ARGB_8888, false)
        }
        return Bitmap.createBitmap(source, left, top, cropWidth, cropHeight)
    }

    suspend fun processImageBatch(
        context: Context,
        inputs: List<Uri>,
        outputTree: Uri,
        options: BatchImageOptions,
        onProgress: (Int, Int) -> Unit = { _, _ -> }
    ): List<Uri> = withContext(Dispatchers.IO) {
        require(inputs.isNotEmpty()) { "Selecciona al menos una imagen" }
        require(inputs.size <= 50) { "Puedes procesar hasta 50 imágenes" }
        val folder = DocumentFile.fromTreeUri(context, outputTree) ?: error("No se pudo abrir la carpeta")
        if (options.mode == BatchImageMode.ZIP_ORIGINALS) {
            val zip = folder.createFile("application/zip", "imagenes_gana_geo_${System.currentTimeMillis()}.zip")
                ?: error("No se pudo crear el ZIP")
            context.contentResolver.openOutputStream(zip.uri, "w")?.use { raw ->
                ZipOutputStream(raw).use { zipOut ->
                    inputs.forEachIndexed { index, uri ->
                        val name = ToolFileUtils.displayName(context, uri).replace(Regex("[^A-Za-z0-9._-]"), "_")
                        zipOut.putNextEntry(ZipEntry("${(index + 1).toString().padStart(3, '0')}_$name"))
                        context.contentResolver.openInputStream(uri)?.use { it.copyTo(zipOut) }
                            ?: error("No se pudo leer $name")
                        zipOut.closeEntry()
                        onProgress(index + 1, inputs.size)
                    }
                }
            } ?: error("No se pudo escribir el ZIP")
            return@withContext listOf(zip.uri)
        }

        if (options.mode in listOf(BatchImageMode.JOIN_VERTICAL, BatchImageMode.JOIN_HORIZONTAL, BatchImageMode.COLLAGE, BatchImageMode.PASSPORT_SHEET)) {
            val bitmaps = inputs.map { ToolFileUtils.loadBitmap(context, it, options.maxEdge.coerceIn(600, 3200)) }
            try {
                val outputBitmap = when (options.mode) {
                    BatchImageMode.JOIN_VERTICAL -> joinBitmaps(bitmaps, vertical = true, options.backgroundColor)
                    BatchImageMode.JOIN_HORIZONTAL -> joinBitmaps(bitmaps, vertical = false, options.backgroundColor)
                    BatchImageMode.COLLAGE -> collage(bitmaps, options.columns.coerceIn(1, 5), options.backgroundColor)
                    BatchImageMode.PASSPORT_SHEET -> passportSheet(bitmaps.first(), options)
                    else -> error("Modo no válido")
                }
                try {
                    val file = createImageFile(folder, "resultado_${System.currentTimeMillis()}", options.outputFormat)
                    context.contentResolver.openOutputStream(file.uri, "w")?.use { output ->
                        check(outputBitmap.compress(options.outputFormat, options.quality.coerceIn(20, 100), output))
                    } ?: error("No se pudo guardar la imagen")
                    onProgress(inputs.size, inputs.size)
                    return@withContext listOf(file.uri)
                } finally {
                    outputBitmap.recycle()
                }
            } finally {
                bitmaps.forEach { if (!it.isRecycled) it.recycle() }
            }
        }

        val results = mutableListOf<Uri>()
        inputs.forEachIndexed { index, uri ->
            val source = ToolFileUtils.loadBitmap(context, uri, 4096)
            try {
                val transformed = when (options.mode) {
                    BatchImageMode.RESIZE -> scaleMaxEdge(source, options.maxEdge.coerceIn(256, 8192))
                    BatchImageMode.SOLID_BACKGROUND -> flatten(source, options.backgroundColor)
                    BatchImageMode.FRAME -> addFrame(source, options.frameWidth.coerceIn(1, 300), options.backgroundColor)
                    else -> source.copy(Bitmap.Config.ARGB_8888, false)
                }
                try {
                    val format = when (options.mode) {
                        BatchImageMode.REMOVE_METADATA -> Bitmap.CompressFormat.JPEG
                        else -> options.outputFormat
                    }
                    val base = ToolFileUtils.displayName(context, uri).substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_")
                    val file = createImageFile(folder, "${base}_gana_geo", format)
                    context.contentResolver.openOutputStream(file.uri, "w")?.use { output ->
                        check(transformed.compress(format, options.quality.coerceIn(20, 100), output))
                    } ?: error("No se pudo guardar ${base}")
                    results += file.uri
                } finally {
                    transformed.recycle()
                }
            } finally {
                source.recycle()
            }
            onProgress(index + 1, inputs.size)
        }
        results
    }

    private fun drawWatermark(stream: PDPageContentStream, box: PDRectangle, text: String, options: PdfWatermarkOptions) {
        val font = PDType1Font.HELVETICA_BOLD
        val fontSize = options.fontSize.coerceIn(10f, 120f)
        val textWidth = font.getStringWidth(text) / 1000f * fontSize
        when (options.position) {
            WatermarkPosition.CENTER -> drawText(stream, font, fontSize, text, (box.width - textWidth) / 2, box.height / 2, 0f)
            WatermarkPosition.DIAGONAL -> drawText(stream, font, fontSize, text, (box.width - textWidth) / 2, box.height / 2, 35f)
            WatermarkPosition.TOP -> drawText(stream, font, fontSize, text, (box.width - textWidth) / 2, box.height - fontSize - 20f, 0f)
            WatermarkPosition.BOTTOM -> drawText(stream, font, fontSize, text, (box.width - textWidth) / 2, 30f, 0f)
            WatermarkPosition.REPEAT -> {
                var y = 60f
                while (y < box.height) {
                    var x = 20f
                    while (x < box.width) {
                        drawText(stream, font, fontSize.coerceAtMost(28f), text, x, y, 30f)
                        x += max(170f, textWidth + 50f)
                    }
                    y += 120f
                }
            }
        }
    }

    private fun drawText(stream: PDPageContentStream, font: PDType1Font, size: Float, text: String, x: Float, y: Float, angle: Float) {
        stream.saveGraphicsState()
        if (angle != 0f) {
            stream.transform(com.tom_roush.pdfbox.util.Matrix.getRotateInstance(Math.toRadians(angle.toDouble()), x, y))
            stream.beginText()
            stream.setFont(font, size)
            stream.newLineAtOffset(0f, 0f)
        } else {
            stream.beginText()
            stream.setFont(font, size)
            stream.newLineAtOffset(x, y)
        }
        stream.showText(text)
        stream.endText()
        stream.restoreGraphicsState()
    }

    private fun resolvePaper(size: PdfPaperSize, orientation: PdfOrientation): Pair<Float, Float> {
        var width = if (size == PdfPaperSize.AUTOMATIC) PdfPaperSize.A4.widthPoints else size.widthPoints
        var height = if (size == PdfPaperSize.AUTOMATIC) PdfPaperSize.A4.heightPoints else size.heightPoints
        if (orientation == PdfOrientation.LANDSCAPE && height > width || orientation == PdfOrientation.PORTRAIT && width > height) {
            val temp = width
            width = height
            height = temp
        }
        return width.toFloat() to height.toFloat()
    }

    private fun wrapText(text: String, font: PDType1Font, fontSize: Float, maxWidth: Float): List<String> {
        val words = text.trim().split(Regex("\\s+"))
        val lines = mutableListOf<String>()
        var current = ""
        words.forEach { word ->
            val candidate = if (current.isBlank()) word else "$current $word"
            val width = font.getStringWidth(sanitizePdfText(candidate)) / 1000f * fontSize
            if (width <= maxWidth || current.isBlank()) current = candidate else {
                lines += current
                current = word
            }
        }
        if (current.isNotBlank()) lines += current
        return lines
    }

    private fun sanitizePdfText(value: String): String = value
        .replace('“', '"').replace('”', '"').replace('‘', '\'').replace('’', '\'')
        .replace('–', '-').replace('—', '-').replace('…', '.')
        .map { if (it.code in 32..255) it else '?' }.joinToString("")

    private fun luminance(color: Int): Int = ((Color.red(color) * 299 + Color.green(color) * 587 + Color.blue(color) * 114) / 1000)

    private fun scaleMaxEdge(source: Bitmap, maxEdge: Int): Bitmap {
        val sourceMax = max(source.width, source.height)
        if (sourceMax <= maxEdge) return source.copy(Bitmap.Config.ARGB_8888, false)
        val scale = maxEdge.toFloat() / sourceMax
        return Bitmap.createScaledBitmap(source, max(1, (source.width * scale).roundToInt()), max(1, (source.height * scale).roundToInt()), true)
    }

    private fun flatten(source: Bitmap, color: Int): Bitmap = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888).also { output ->
        Canvas(output).apply {
            drawColor(color)
            drawBitmap(source, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        }
    }

    private fun addFrame(source: Bitmap, frame: Int, color: Int): Bitmap {
        val output = Bitmap.createBitmap(source.width + frame * 2, source.height + frame * 2, Bitmap.Config.ARGB_8888)
        Canvas(output).apply {
            drawColor(color)
            drawBitmap(source, frame.toFloat(), frame.toFloat(), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        }
        return output
    }

    private fun joinBitmaps(bitmaps: List<Bitmap>, vertical: Boolean, background: Int): Bitmap {
        require(bitmaps.isNotEmpty()) { "No hay imágenes" }
        val gap = 12
        val width = if (vertical) bitmaps.maxOf { it.width } else bitmaps.sumOf { it.width } + gap * (bitmaps.size - 1)
        val height = if (vertical) bitmaps.sumOf { it.height } + gap * (bitmaps.size - 1) else bitmaps.maxOf { it.height }
        require(width.toLong() * height.toLong() <= 32_000_000L) { "El resultado es demasiado grande; reduce la resolución" }
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawColor(background)
        var cursor = 0
        bitmaps.forEach { bitmap ->
            val x = if (vertical) (width - bitmap.width) / 2 else cursor
            val y = if (vertical) cursor else (height - bitmap.height) / 2
            canvas.drawBitmap(bitmap, x.toFloat(), y.toFloat(), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            cursor += (if (vertical) bitmap.height else bitmap.width) + gap
        }
        return output
    }

    private fun collage(bitmaps: List<Bitmap>, columns: Int, background: Int): Bitmap {
        require(bitmaps.isNotEmpty()) { "No hay imágenes" }
        val cell = 700
        val gap = 12
        val rows = ceil(bitmaps.size.toDouble() / columns).toInt()
        val width = columns * cell + (columns + 1) * gap
        val height = rows * cell + (rows + 1) * gap
        require(width.toLong() * height.toLong() <= 32_000_000L) { "El collage es demasiado grande" }
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawColor(background)
        bitmaps.forEachIndexed { index, bitmap ->
            val column = index % columns
            val row = index / columns
            val left = gap + column * (cell + gap)
            val top = gap + row * (cell + gap)
            val sourceRatio = bitmap.width.toFloat() / bitmap.height
            val targetRatio = 1f
            val sourceRect = if (sourceRatio > targetRatio) {
                val cropWidth = (bitmap.height * targetRatio).roundToInt()
                Rect((bitmap.width - cropWidth) / 2, 0, (bitmap.width + cropWidth) / 2, bitmap.height)
            } else {
                val cropHeight = (bitmap.width / targetRatio).roundToInt()
                Rect(0, (bitmap.height - cropHeight) / 2, bitmap.width, (bitmap.height + cropHeight) / 2)
            }
            canvas.drawBitmap(bitmap, sourceRect, RectF(left.toFloat(), top.toFloat(), (left + cell).toFloat(), (top + cell).toFloat()), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        }
        return output
    }

    private fun passportSheet(source: Bitmap, options: BatchImageOptions): Bitmap {
        val dpi = 300.0
        val photoWidth = (options.passportWidthMm / 25.4 * dpi).roundToInt().coerceIn(200, 1000)
        val photoHeight = (options.passportHeightMm / 25.4 * dpi).roundToInt().coerceIn(250, 1300)
        val pageWidth = 2480
        val pageHeight = 3508
        val margin = 100
        val gap = 40
        val columns = max(1, (pageWidth - margin * 2 + gap) / (photoWidth + gap))
        val maxRows = max(1, (pageHeight - margin * 2 + gap) / (photoHeight + gap))
        val maxCopies = columns * maxRows
        val copies = options.passportCopies.coerceIn(1, maxCopies)
        val cropped = centerCrop(source, photoWidth.toFloat() / photoHeight)
        val output = Bitmap.createBitmap(pageWidth, pageHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawColor(Color.WHITE)
        repeat(copies) { index ->
            val column = index % columns
            val row = index / columns
            val left = margin + column * (photoWidth + gap)
            val top = margin + row * (photoHeight + gap)
            canvas.drawBitmap(cropped, null, Rect(left, top, left + photoWidth, top + photoHeight), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            canvas.drawRect(left.toFloat(), top.toFloat(), (left + photoWidth).toFloat(), (top + photoHeight).toFloat(), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 2f
                color = Color.LTGRAY
            })
        }
        cropped.recycle()
        return output
    }

    private fun centerCrop(source: Bitmap, targetRatio: Float): Bitmap {
        val ratio = source.width.toFloat() / source.height
        return if (ratio > targetRatio) {
            val width = (source.height * targetRatio).roundToInt()
            Bitmap.createBitmap(source, (source.width - width) / 2, 0, width, source.height)
        } else {
            val height = (source.width / targetRatio).roundToInt()
            Bitmap.createBitmap(source, 0, (source.height - height) / 2, source.width, height)
        }
    }

    private fun createImageFile(folder: DocumentFile, base: String, format: Bitmap.CompressFormat): DocumentFile {
        val (mime, extension) = when (format) {
            Bitmap.CompressFormat.PNG -> "image/png" to "png"
            Bitmap.CompressFormat.WEBP, Bitmap.CompressFormat.WEBP_LOSSLESS, Bitmap.CompressFormat.WEBP_LOSSY -> "image/webp" to "webp"
            else -> "image/jpeg" to "jpg"
        }
        return folder.createFile(mime, "$base.$extension") ?: error("No se pudo crear el archivo")
    }

    private fun copyUriToTemp(context: Context, uri: Uri, suffix: String): File {
        val file = File(context.cacheDir, "advanced_${UUID.randomUUID()}$suffix")
        context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(file).use(input::copyTo) }
            ?: error("No se pudo abrir el archivo")
        return file
    }

    private fun copyFile(context: Context, source: File, output: Uri) {
        context.contentResolver.openOutputStream(output, "w")?.use { stream -> source.inputStream().use { it.copyTo(stream) } }
            ?: error("No se pudo guardar el archivo")
    }
}
