package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer as AndroidPdfRenderer
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.rendering.PDFRenderer as PdfBoxRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.os.CancellationSignal
import android.util.Xml
import android.util.LruCache
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.flow.collect
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import java.io.Closeable
import java.util.zip.ZipInputStream
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.math.hypot
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.InvertColors
import androidx.compose.material.icons.rounded.NavigateBefore
import androidx.compose.material.icons.rounded.NavigateNext
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign

@Composable
fun PdfViewerScreen(
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    var uriText by rememberSaveable { mutableStateOf<String?>(null) }
    val uri = uriText?.let(Uri::parse)
    var pageCount by rememberSaveable { mutableIntStateOf(0) }
    var loadingDocument by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var localPdfPath by remember { mutableStateOf<String?>(null) }
    var pdfEngine by remember { mutableStateOf<PdfRenderEngine?>(null) }
    var retryToken by remember { mutableIntStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selected,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            localPdfPath?.let { old ->
                ViewerBitmapCache.clearPrefix("pdf|$old")
                PdfSessionRegistry.close(old)
                runCatching { File(old).delete() }
            }
            localPdfPath = null
            pdfEngine = null
            loadingDocument = true
            uriText = selected.toString()
            pageCount = 0
            loadError = null
        }
    }

    LaunchedEffect(uriText, retryToken) {
        val selected = uri ?: run {
            pageCount = 0
            loadError = null
            localPdfPath = null
            pdfEngine = null
            onImmersiveChanged(false)
            return@LaunchedEffect
        }
        onImmersiveChanged(true)
        loadingDocument = true
        loadError = null
        pageCount = 0

        val previousPath = localPdfPath
        var attemptedCopy: File? = null
        val result = runCatching {
            PDFBoxResourceLoader.init(context.applicationContext)

            // Siempre convertimos el URI SAF/Drive en un archivo local seekable antes de
            // abrir el documento. PdfRenderer necesita acceso aleatorio y algunos
            // proveedores content:// entregan pipes que funcionan en Drive pero no como
            // descriptor seekable directo.
            val copy = kotlinx.coroutines.withTimeout(25000L) {
                copyPdfToViewerCache(context, selected)
            }
            attemptedCopy = copy
            val openInfo = kotlinx.coroutines.withTimeout(20000L) {
                detectLocalPdf(copy)
            }
            require(openInfo.pageCount > 0) { "El PDF no contiene paginas." }
            Triple(copy, openInfo.pageCount, openInfo.engine)
        }

        result.onSuccess { (copy, count, engine) ->
            previousPath?.takeIf { it != copy.absolutePath }?.let { old ->
                PdfSessionRegistry.close(old)
                runCatching { File(old).delete() }
            }
            localPdfPath = copy.absolutePath
            pdfEngine = engine
            pageCount = count
        }.onFailure { error ->
            attemptedCopy?.let { failed ->
                PdfSessionRegistry.close(failed.absolutePath)
                runCatching { failed.delete() }
            }
            localPdfPath = null
            pdfEngine = null
            pageCount = 0
            loadError = when {
                error is kotlinx.coroutines.TimeoutCancellationException ->
                    "El PDF tardo demasiado en responder. Vuelve a intentarlo."
                error.message?.contains("password", ignoreCase = true) == true ->
                    "Este PDF esta protegido y no se pudo abrir."
                else -> error.message ?: "No se pudo abrir este PDF."
            }
        }
        loadingDocument = false
    }


    DisposableEffect(Unit) {
        onDispose {
            onImmersiveChanged(false)
            localPdfPath?.let { path ->
                ViewerBitmapCache.clearPrefix("pdf|$path")
                PdfSessionRegistry.close(path)
                runCatching { File(path).delete() }
            }
        }
    }

    if (uri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Visor gratuito · el archivo no se modifica", onBack)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Ningún PDF seleccionado", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { launcher.launch(arrayOf("application/pdf")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                        Text(" Abrir PDF")
                    }
                }
            }
        }
        return
    }

    val fileName = remember(uriText) { ToolFileUtils.displayName(context, uri) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding(),
            color = Color(0xFF202124),
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = Color.White)
                }
                Text(
                    fileName,
                    modifier = Modifier.weight(1f),
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = { shareDocumentFile(context, uri, "application/pdf") }) {
                    Icon(Icons.Rounded.Share, contentDescription = "Compartir PDF", tint = Color.White)
                }
                IconButton(onClick = { launcher.launch(arrayOf("application/pdf")) }) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = "Cambiar PDF", tint = Color.White)
                }
            }
        }

        if (loadingDocument) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = NeonGreen)
                    Spacer(Modifier.height(14.dp))
                    Text("Abriendo PDF…", color = Color.White.copy(alpha = 0.78f))
                }
            }
        } else if (loadError != null || pageCount <= 0 || pdfEngine == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF202124)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("No se pudo abrir el PDF", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(
                            loadError ?: "El archivo no contiene páginas compatibles.",
                            color = Color.White.copy(alpha = 0.72f)
                        )
                        OutlinedButton(onClick = { retryToken++ }, modifier = Modifier.fillMaxWidth()) {
                            Text("Reintentar")
                        }
                        OutlinedButton(
                            onClick = { launcher.launch(arrayOf("application/pdf")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                            Text(" Elegir otro PDF")
                        }
                    }
                }
            }
        } else {
            DrivePagedSurface(
                viewerKey = "pdf_${uriText.orEmpty()}",
                pageCount = pageCount,
                background = Color(0xFF121212),
                minZoom = 1f,
                maxZoom = 2.5f,
                onCurrentPageChanged = {},
                pageContent = { index, renderWidth, pageWidth ->
                    ContinuousPdfPage(
                        uri = uri,
                        localPdfPath = localPdfPath,
                        engine = pdfEngine!!,
                        pageIndex = index,
                        renderWidth = renderWidth,
                        modifier = Modifier.width(pageWidth),
                        onMessage = onMessage
                    )
                }
            )
        }
    }
}

@Composable
private fun PdfGridGlyph() {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(3) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                repeat(3) {
                    Box(
                        modifier = Modifier
                            .size(3.dp)
                            .background(Color(0xFF5F6368), RoundedCornerShape(1.dp))
                    )
                }
            }
        }
    }
}

@Composable
private fun ViewerSideCounter(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color.White.copy(alpha = 0.94f),
        contentColor = Color(0xFF303134),
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 3.dp
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun ViewerZoomBadge(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color(0xE6323440),
        contentColor = Color.White,
        shape = RoundedCornerShape(18.dp),
        shadowElevation = 3.dp
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

/**
 * Cache compartida para paginas/diapositivas ya renderizadas. Mantener unas cuantas
 * superficies listas evita volver a rasterizar al subir/bajar rapido o al regresar a
 * una pagina que el usuario acaba de ver.
 */
private object ViewerBitmapCache {
    private val maxKb = ((Runtime.getRuntime().maxMemory() / 8L) / 1024L)
        .coerceIn(24L * 1024L, 64L * 1024L)
        .toInt()
    private val cache = object : LruCache<String, Bitmap>(maxKb) {
        override fun sizeOf(key: String, value: Bitmap): Int =
            (value.allocationByteCount / 1024).coerceAtLeast(1)
    }

    @Synchronized
    fun get(key: String): Bitmap? = cache.get(key)?.takeIf { !it.isRecycled }

    @Synchronized
    fun put(key: String, bitmap: Bitmap): Bitmap {
        cache.put(key, bitmap)
        return bitmap
    }

    @Synchronized
    fun clearPrefix(prefix: String) {
        val keys = cache.snapshot().keys.filter { it.startsWith(prefix) }
        keys.forEach(cache::remove)
    }
}


/**
 * Visor paginado inspirado en el comportamiento del lector de Drive.
 *
 * Las páginas se mantienen como superficies completas: el gesto de zoom cambia el ancho
 * de la superficie, no el tamaño individual del texto. El control derecho permite saltar
 * rápidamente por documentos largos sin renderizar todas las páginas a la vez.
 */
@Composable
private fun DrivePagedSurface(
    viewerKey: String,
    pageCount: Int,
    background: Color,
    resetViewToken: Int = 0,
    jumpToPage: Int? = null,
    jumpRequestKey: Any? = null,
    minZoom: Float = 1f,
    maxZoom: Float = 2.25f,
    onCurrentPageChanged: (Int) -> Unit = {},
    onTap: () -> Unit = {},
    pageContent: @Composable (pageIndex: Int, renderWidth: Int, pageWidth: androidx.compose.ui.unit.Dp) -> Unit
) {
    val listState = rememberLazyListState()
    val horizontalState = rememberScrollState()
    val scope = rememberCoroutineScope()
    var zoom by rememberSaveable(viewerKey) { mutableFloatStateOf(1f) }
    var scrubbing by remember { mutableStateOf(false) }
    var scrubPage by remember { mutableIntStateOf(0) }

    // El pellizco se pinta primero con GPU y el cambio real de tamano se confirma al
    // soltar los dedos. Asi no reconstruimos/renderizamos las paginas en cada frame.
    var gestureScale by remember(viewerKey) { mutableFloatStateOf(1f) }
    var gesturePanX by remember(viewerKey) { mutableFloatStateOf(0f) }
    var gesturePanY by remember(viewerKey) { mutableFloatStateOf(0f) }
    var pivotX by remember(viewerKey) { mutableFloatStateOf(0.5f) }
    var pivotY by remember(viewerKey) { mutableFloatStateOf(0.5f) }

    val currentPageIndex by remember(pageCount) {
        derivedStateOf {
            if (pageCount <= 0) 0 else {
                val viewportStart = listState.layoutInfo.viewportStartOffset
                val viewportEnd = listState.layoutInfo.viewportEndOffset
                val best = listState.layoutInfo.visibleItemsInfo.maxByOrNull { item ->
                    val visibleStart = maxOf(item.offset, viewportStart)
                    val visibleEnd = minOf(item.offset + item.size, viewportEnd)
                    (visibleEnd - visibleStart).coerceAtLeast(0)
                }
                (best?.index ?: listState.firstVisibleItemIndex).coerceIn(0, pageCount - 1)
            }
        }
    }

    LaunchedEffect(currentPageIndex, pageCount) {
        if (pageCount > 0) onCurrentPageChanged(currentPageIndex)
    }

    LaunchedEffect(resetViewToken) {
        zoom = 1f
        gestureScale = 1f
        gesturePanX = 0f
        gesturePanY = 0f
        horizontalState.scrollTo(0)
    }

    LaunchedEffect(jumpRequestKey, jumpToPage, pageCount) {
        val target = jumpToPage
        if (target != null && pageCount > 0) {
            listState.animateScrollToItem(target.coerceIn(0, pageCount - 1))
        }
    }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(background)
    ) {
        if (pageCount <= 0) return@BoxWithConstraints

        val basePageWidth = (maxWidth - 8.dp).coerceAtLeast(180.dp)
        val pageWidth = basePageWidth * zoom
        val contentWidth = if (pageWidth < maxWidth) maxWidth else pageWidth
        // Una resolucion estable evita re-renderizar todas las paginas durante el pinch.
        // El escalado interactivo lo hace la GPU; la pagina no cambia su contenido.
        val renderWidth = 1600

        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(viewerKey, pageCount, minZoom, maxZoom) {
                    awaitEachGesture {
                        var active = false
                        var localScale = 1f
                        var panX = 0f
                        var panY = 0f
                        var centroidX = size.width / 2f
                        var centroidY = size.height / 2f
                        var anchorIndex = listState.firstVisibleItemIndex
                        var anchorLocalY = listState.firstVisibleItemScrollOffset.toFloat()
                        var anchorFraction = 0f
                        var startHorizontal = horizontalState.value.toFloat()

                        do {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.filter { it.pressed }
                            if (pressed.size >= 2) {
                                centroidX = pressed.sumOf { it.position.x.toDouble() }.toFloat() / pressed.size
                                centroidY = pressed.sumOf { it.position.y.toDouble() }.toFloat() / pressed.size

                                if (!active) {
                                    active = true
                                    startHorizontal = horizontalState.value.toFloat()
                                    val hit = listState.layoutInfo.visibleItemsInfo.firstOrNull { item ->
                                        centroidY >= item.offset && centroidY <= item.offset + item.size
                                    }
                                    if (hit != null) {
                                        anchorIndex = hit.index
                                        anchorLocalY = centroidY - hit.offset.toFloat()
                                        anchorFraction = (anchorLocalY / hit.size.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
                                    } else {
                                        val first = listState.layoutInfo.visibleItemsInfo.firstOrNull()
                                        anchorIndex = first?.index ?: listState.firstVisibleItemIndex
                                        anchorLocalY = listState.firstVisibleItemScrollOffset + centroidY
                                        anchorFraction = (anchorLocalY / (first?.size ?: 1).coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
                                    }
                                }

                                val stepZoom = event.calculateZoom()
                                val targetZoom = (zoom * localScale * stepZoom).coerceIn(minZoom, maxZoom)
                                localScale = (targetZoom / zoom.coerceAtLeast(0.001f)).coerceAtLeast(0.01f)
                                val pan = event.calculatePan()
                                panX += pan.x
                                panY += pan.y

                                gestureScale = localScale
                                gesturePanX = panX
                                gesturePanY = panY
                                pivotX = (centroidX / size.width.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
                                pivotY = (centroidY / size.height.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
                                event.changes.forEach { it.consume() }
                            }
                        } while (event.changes.any { it.pressed })

                        if (active) {
                            val oldZoom = zoom
                            val newZoom = (oldZoom * localScale).coerceIn(minZoom, maxZoom)
                            val ratio = newZoom / oldZoom.coerceAtLeast(0.001f)
                            val wantedHorizontal = ((startHorizontal + centroidX) * ratio - centroidX - panX)
                                .roundToInt()
                            val fallbackAnchorY = anchorLocalY * ratio

                            // Pedimos el nuevo anclaje en la misma re-medicion en la que cambia
                            // el zoom. Asi no hay un frame intermedio que mande el documento arriba.
                            val oldAnchorSize = listState.layoutInfo.visibleItemsInfo
                                .firstOrNull { it.index == anchorIndex }?.size?.toFloat()
                                ?: anchorLocalY.coerceAtLeast(1f)
                            val estimatedNewAnchorY = anchorFraction * oldAnchorSize * ratio
                            val estimatedOffset = (estimatedNewAnchorY - centroidY - panY)
                                .roundToInt()
                                .coerceAtLeast(0)

                            zoom = newZoom
                            listState.requestScrollToItem(
                                anchorIndex.coerceIn(0, pageCount - 1),
                                estimatedOffset
                            )
                            gestureScale = 1f
                            gesturePanX = 0f
                            gesturePanY = 0f

                            scope.launch {
                                androidx.compose.runtime.withFrameNanos { }
                                if (newZoom <= 1.01f) {
                                    horizontalState.scrollTo(0)
                                } else {
                                    horizontalState.scrollTo(wantedHorizontal.coerceIn(0, horizontalState.maxValue))
                                }
                                val relaid = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == anchorIndex }
                                if (relaid != null) {
                                    val anchorY = anchorFraction * relaid.size.toFloat()
                                    val wantedOffset = (anchorY - centroidY - panY).roundToInt().coerceAtLeast(0)
                                    listState.requestScrollToItem(
                                        anchorIndex.coerceIn(0, pageCount - 1),
                                        wantedOffset
                                    )
                                }
                            }
                        }
                    }
                }
                .pointerInput(viewerKey, pageCount, minZoom, maxZoom) {
                    detectTapGestures(
                        onTap = { onTap() },
                        onDoubleTap = { offset ->
                            val oldZoom = zoom
                            val newZoom = if (zoom > 1.12f) 1f else 1.9f.coerceAtMost(maxZoom)
                            val ratio = newZoom / oldZoom.coerceAtLeast(0.001f)
                            val hit = listState.layoutInfo.visibleItemsInfo.firstOrNull { item ->
                                offset.y >= item.offset && offset.y <= item.offset + item.size
                            }
                            val anchorIndex = hit?.index ?: listState.firstVisibleItemIndex
                            val localY = hit?.let { offset.y - it.offset.toFloat() }
                                ?: (listState.firstVisibleItemScrollOffset + offset.y)
                            val itemSize = hit?.size ?: listState.layoutInfo.visibleItemsInfo.firstOrNull()?.size ?: 1
                            val anchorFraction = (localY / itemSize.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
                            val startHorizontal = horizontalState.value
                            val wantedHorizontal = ((startHorizontal + offset.x) * ratio - offset.x).roundToInt()
                            val fallbackAnchorY = localY * ratio
                            val estimatedOffset = (anchorFraction * itemSize.toFloat() * ratio - offset.y)
                                .roundToInt()
                                .coerceAtLeast(0)
                            zoom = newZoom
                            listState.requestScrollToItem(
                                anchorIndex.coerceIn(0, pageCount - 1),
                                estimatedOffset
                            )
                            scope.launch {
                                androidx.compose.runtime.withFrameNanos { }
                                if (newZoom <= 1.01f) horizontalState.scrollTo(0)
                                else horizontalState.scrollTo(wantedHorizontal.coerceIn(0, horizontalState.maxValue))
                                val relaid = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == anchorIndex }
                                val anchorY = relaid?.let { anchorFraction * it.size.toFloat() } ?: fallbackAnchorY
                                val wantedOffset = (anchorY - offset.y).roundToInt().coerceAtLeast(0)
                                listState.requestScrollToItem(
                                    anchorIndex.coerceIn(0, pageCount - 1),
                                    wantedOffset
                                )
                            }
                        }
                    )
                }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = gestureScale
                        scaleY = gestureScale
                        translationX = gesturePanX
                        translationY = gesturePanY
                        transformOrigin = TransformOrigin(pivotX, pivotY)
                    }
                    .horizontalScroll(horizontalState)
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.width(contentWidth).fillMaxHeight(),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(
                        count = pageCount,
                        key = { index -> "${viewerKey}_page_$index" },
                        contentType = { "drive_page" }
                    ) { index ->
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            pageContent(index, renderWidth, pageWidth)
                        }
                    }
                }
            }
        }

        val shownPage = if (scrubbing) scrubPage else currentPageIndex
        val progress = if (pageCount <= 1) 0f else shownPage.toFloat() / (pageCount - 1).toFloat()

        BoxWithConstraints(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(92.dp)
                .padding(top = 8.dp, bottom = 10.dp)
        ) {
            val handleHeight = 50.dp
            val travel = (maxHeight - handleHeight).coerceAtLeast(0.dp)

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(pageCount) {
                        fun pageForY(y: Float): Int {
                            if (pageCount <= 1 || size.height <= 0) return 0
                            val fraction = (y / size.height.toFloat()).coerceIn(0f, 1f)
                            return (fraction * (pageCount - 1)).roundToInt().coerceIn(0, pageCount - 1)
                        }
                        fun jump(y: Float) {
                            scrubPage = pageForY(y)
                            listState.requestScrollToItem(scrubPage.coerceIn(0, pageCount - 1), 0)
                        }
                        detectVerticalDragGestures(
                            onDragStart = { offset ->
                                scrubbing = true
                                jump(offset.y)
                            },
                            onVerticalDrag = { change, _ ->
                                change.consume()
                                jump(change.position.y)
                            },
                            onDragEnd = { scrubbing = false },
                            onDragCancel = { scrubbing = false }
                        )
                    }
            )

            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(y = travel * progress)
                    .height(handleHeight)
                    .padding(end = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    color = Color.White.copy(alpha = 0.96f),
                    contentColor = Color(0xFF303134),
                    shape = RoundedCornerShape(16.dp),
                    shadowElevation = 3.dp
                ) {
                    Text(
                        text = "${shownPage + 1}/$pageCount",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Surface(
                    modifier = Modifier.width(28.dp).height(handleHeight),
                    color = Color.White.copy(alpha = 0.96f),
                    shape = RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp),
                    shadowElevation = 3.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        repeat(3) {
                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                repeat(2) {
                                    Box(
                                        Modifier.size(3.5.dp)
                                            .background(Color(0xFF5F6368), RoundedCornerShape(2.dp))
                                    )
                                }
                            }
                            if (it < 2) Spacer(Modifier.height(3.dp))
                        }
                    }
                }
            }
        }

    }
}

@Composable
private fun PdfOverview(
    uri: Uri,
    localPdfPath: String?,
    engine: PdfRenderEngine,
    pageCount: Int,
    onSelectPage: (Int) -> Unit,
    onMessage: (String) -> Unit
) {
    val rowCount = (pageCount + 2) / 3
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF171717)),
        contentPadding = PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(count = rowCount, key = { "pdf_overview_row_$it" }) { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                repeat(3) { column ->
                    val pageIndex = row * 3 + column
                    if (pageIndex < pageCount) {
                        PdfThumbnail(
                            uri = uri,
                            localPdfPath = localPdfPath,
                            engine = engine,
                            pageIndex = pageIndex,
                            modifier = Modifier.weight(1f),
                            onClick = { onSelectPage(pageIndex) },
                            onMessage = onMessage
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfThumbnail(
    uri: Uri,
    localPdfPath: String?,
    engine: PdfRenderEngine,
    pageIndex: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var bitmap by remember(localPdfPath, pageIndex) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(localPdfPath, pageIndex) {
        runCatching {
            if (localPdfPath != null) {
                renderLocalPdfPage(File(localPdfPath), pageIndex, maxWidth = 360, engine = engine)
            } else {
                ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = 360)
            }
        }.recoverCatching {
            ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = 360)
        }.onSuccess { fresh ->
            val previous = bitmap
            bitmap = fresh
            previous?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure {
            onMessage(it.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
        }
    }

    DisposableEffect(localPdfPath, pageIndex) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    Column(
        modifier = modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            val current = bitmap
            if (current != null) {
                Image(
                    bitmap = current.asImageBitmap(),
                    contentDescription = "Página ${pageIndex + 1}",
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = NeonGreen,
                        strokeWidth = 2.dp
                    )
                }
            }
        }
        Text(
            "${pageIndex + 1}",
            color = Color.White.copy(alpha = 0.78f),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun ContinuousPdfPage(
    uri: Uri,
    localPdfPath: String?,
    engine: PdfRenderEngine,
    pageIndex: Int,
    renderWidth: Int,
    modifier: Modifier = Modifier,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val sourceKey = localPdfPath ?: uri.toString()
    val cacheKey = remember(sourceKey, pageIndex, renderWidth) {
        "pdf|$sourceKey|$pageIndex|$renderWidth"
    }
    var bitmap by remember(cacheKey) { mutableStateOf(ViewerBitmapCache.get(cacheKey)) }

    LaunchedEffect(uri, localPdfPath, pageIndex, renderWidth) {
        ViewerBitmapCache.get(cacheKey)?.let {
            bitmap = it
            return@LaunchedEffect
        }
        val renderResult = runCatching {
            // La ruta normal siempre usa la copia local y una sesion persistente. Solo si no
            // existe copia (caso heredado) se consulta directamente el URI.
            if (localPdfPath != null) {
                renderLocalPdfPage(File(localPdfPath), pageIndex, maxWidth = renderWidth, engine = engine)
            } else {
                ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = renderWidth)
            }
        }
        val finalResult = if (localPdfPath == null) {
            renderResult.recoverCatching {
                ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = renderWidth)
            }
        } else renderResult
        finalResult.onSuccess { fresh ->
            bitmap = ViewerBitmapCache.put(cacheKey, fresh)
        }.onFailure {
            onMessage(it.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
        }
    }

    val current = bitmap
    val pageRatio = current?.let { image ->
        image.width.toFloat() / image.height.toFloat().coerceAtLeast(1f)
    } ?: 0.7071f
    Box(
        modifier = modifier
            .aspectRatio(pageRatio)
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = "Página ${pageIndex + 1}",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize().background(Color.White)
            )
        }
    }
}


private suspend fun copyPdfToViewerCache(context: android.content.Context, source: Uri): File =
    withContext(Dispatchers.IO) {
        val directory = File(context.cacheDir, "pdf_viewer").apply { mkdirs() }
        directory.listFiles()?.forEach { old ->
            if (System.currentTimeMillis() - old.lastModified() > 6 * 60 * 60 * 1000L) {
                PdfSessionRegistry.close(old.absolutePath)
                runCatching { old.delete() }
            }
        }
        val file = File(
            directory,
            "viewer_${System.currentTimeMillis()}_${kotlin.random.Random.nextInt(1000, 9999)}.pdf"
        )
        try {
            runInterruptible {
                // Para SAF/Drive el InputStream secuencial es mas compatible que asumir que
                // el FileDescriptor remoto es seekable. PdfRenderer se usa despues sobre
                // nuestra copia local real.
                val copiedFromStream = runCatching {
                    context.contentResolver.openInputStream(source)?.buffered(256 * 1024)?.use { input ->
                        FileOutputStream(file).buffered(256 * 1024).use { output ->
                            val buffer = ByteArray(256 * 1024)
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                            }
                            output.flush()
                        }
                        true
                    } ?: false
                }.getOrDefault(false)

                if (!copiedFromStream || file.length() <= 0L) {
                    runCatching { file.delete() }
                    val cancellationSignal = CancellationSignal()
                    val copiedFromDescriptor = context.contentResolver
                        .openFileDescriptor(source, "r", cancellationSignal)?.use { descriptor ->
                            FileInputStream(descriptor.fileDescriptor).buffered(256 * 1024).use { input ->
                                FileOutputStream(file).buffered(256 * 1024).use { output ->
                                    input.copyTo(output, 256 * 1024)
                                    output.flush()
                                }
                            }
                            true
                        } ?: false
                    require(copiedFromDescriptor) { "No se pudo leer el archivo seleccionado." }
                }
            }
            require(file.length() > 0L) { "El archivo PDF esta vacio." }
            file
        } catch (error: Throwable) {
            PdfSessionRegistry.close(file.absolutePath)
            runCatching { file.delete() }
            throw error
        }
    }

private enum class PdfRenderEngine { ANDROID, PDFBOX }
private data class PdfOpenInfo(val engine: PdfRenderEngine, val pageCount: Int)

/**
 * Mantiene el documento abierto durante toda la vida del visor. La v10.0.58 reabria el
 * PDF completo por cada pagina, lo que multiplicaba I/O y parsing al hacer scroll.
 */
private class PdfViewerSession private constructor(
    private val file: File,
    val engine: PdfRenderEngine,
    val pageCount: Int,
    private var descriptor: ParcelFileDescriptor?,
    private var androidRenderer: AndroidPdfRenderer?,
    private var pdfBoxDocument: PDDocument?
) : Closeable {
    private val renderLock = Any()
    private var preferPdfBox = false

    fun render(pageIndex: Int, requestedWidth: Int): Bitmap = synchronized(renderLock) {
        if (Thread.currentThread().isInterrupted) throw InterruptedException("Render cancelado")
        require(pageIndex in 0 until pageCount) { "La pagina indicada no existe." }
        when (engine) {
            PdfRenderEngine.ANDROID -> {
                if (preferPdfBox) {
                    renderWithPdfBox(pageIndex, requestedWidth)
                } else {
                    runCatching { renderWithAndroid(pageIndex, requestedWidth) }.getOrElse {
                        preferPdfBox = true
                        renderWithPdfBox(pageIndex, requestedWidth)
                    }
                }
            }
            PdfRenderEngine.PDFBOX -> renderWithPdfBox(pageIndex, requestedWidth)
        }
    }

    private fun renderWithAndroid(pageIndex: Int, requestedWidth: Int): Bitmap {
        val renderer = androidRenderer ?: error("PdfRenderer no esta disponible.")
        renderer.openPage(pageIndex).use { page ->
            var width = min(requestedWidth.coerceIn(520, 1900), page.width * 3).coerceAtLeast(320)
            var height = (width.toFloat() / page.width.toFloat().coerceAtLeast(1f) * page.height.toFloat())
                .roundToInt()
                .coerceAtLeast(320)
            val pixels = width.toLong() * height.toLong()
            val maxPixels = 4_800_000L
            if (pixels > maxPixels) {
                val scale = sqrt(maxPixels.toDouble() / pixels.toDouble()).toFloat()
                width = (width * scale).roundToInt().coerceAtLeast(1)
                height = (height * scale).roundToInt().coerceAtLeast(1)
            }
            return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
                eraseColor(AndroidColor.WHITE)
                page.render(this, null, null, AndroidPdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            }
        }
    }

    private fun renderWithPdfBox(pageIndex: Int, requestedWidth: Int): Bitmap {
        val document = pdfBoxDocument ?: PDDocument.load(file).also { pdfBoxDocument = it }
        require(pageIndex in 0 until document.numberOfPages) { "La pagina indicada no existe." }
        val page = document.getPage(pageIndex)
        val pageWidth = page.cropBox.width.coerceAtLeast(1f)
        val targetWidth = requestedWidth.coerceIn(520, 1900)
        val scale = (targetWidth.toFloat() / pageWidth).coerceIn(0.75f, 3f)
        val bitmap = PdfBoxRenderer(document).renderImage(pageIndex, scale)
        val pixels = bitmap.width.toLong() * bitmap.height.toLong()
        if (pixels <= 4_800_000L) return bitmap
        val reduce = sqrt(4_800_000.0 / pixels.toDouble()).toFloat()
        val targetW = (bitmap.width * reduce).roundToInt().coerceAtLeast(1)
        val targetH = (bitmap.height * reduce).roundToInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
        if (scaled !== bitmap && !bitmap.isRecycled) bitmap.recycle()
        return scaled
    }

    override fun close() {
        synchronized(renderLock) {
            runCatching { pdfBoxDocument?.close() }
            pdfBoxDocument = null
            runCatching { androidRenderer?.close() }
            androidRenderer = null
            runCatching { descriptor?.close() }
            descriptor = null
        }
    }

    companion object {
        fun open(file: File): PdfViewerSession {
            require(file.exists() && file.length() > 0L) { "El PDF no esta disponible." }

            val androidAttempt = runCatching {
                val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                try {
                    val renderer = AndroidPdfRenderer(descriptor)
                    require(renderer.pageCount > 0) { "El PDF no contiene paginas." }
                    PdfViewerSession(
                        file = file,
                        engine = PdfRenderEngine.ANDROID,
                        pageCount = renderer.pageCount,
                        descriptor = descriptor,
                        androidRenderer = renderer,
                        pdfBoxDocument = null
                    )
                } catch (error: Throwable) {
                    runCatching { descriptor.close() }
                    throw error
                }
            }
            androidAttempt.getOrNull()?.let { return it }

            val pdfBoxAttempt = runCatching {
                val document = PDDocument.load(file)
                require(document.numberOfPages > 0) { "El PDF no contiene paginas." }
                PdfViewerSession(
                    file = file,
                    engine = PdfRenderEngine.PDFBOX,
                    pageCount = document.numberOfPages,
                    descriptor = null,
                    androidRenderer = null,
                    pdfBoxDocument = document
                )
            }
            return pdfBoxAttempt.getOrElse { pdfBoxError ->
                val androidMessage = androidAttempt.exceptionOrNull()?.message.orEmpty()
                val pdfBoxMessage = pdfBoxError.message.orEmpty()
                error(
                    listOf(androidMessage, pdfBoxMessage)
                        .filter { it.isNotBlank() }
                        .distinct()
                        .joinToString(" · ")
                        .ifBlank { "No se pudo interpretar este PDF." }
                )
            }
        }
    }
}

private object PdfSessionRegistry {
    private val sessions = linkedMapOf<String, PdfViewerSession>()

    @Synchronized
    fun open(file: File): PdfViewerSession {
        close(file.absolutePath)
        return PdfViewerSession.open(file).also { sessions[file.absolutePath] = it }
    }

    @Synchronized
    fun getOrOpen(file: File): PdfViewerSession {
        return sessions[file.absolutePath] ?: PdfViewerSession.open(file).also {
            sessions[file.absolutePath] = it
        }
    }

    @Synchronized
    fun close(path: String) {
        sessions.remove(path)?.close()
    }
}

private suspend fun detectLocalPdf(file: File): PdfOpenInfo = runInterruptible(Dispatchers.IO) {
    try {
        val session = PdfSessionRegistry.open(file)
        PdfOpenInfo(session.engine, session.pageCount)
    } catch (error: Throwable) {
        PdfSessionRegistry.close(file.absolutePath)
        throw error
    }
}

private suspend fun renderLocalPdfPage(
    file: File,
    pageIndex: Int,
    maxWidth: Int,
    engine: PdfRenderEngine
): Bitmap = runInterruptible(Dispatchers.IO) {
    val session = PdfSessionRegistry.getOrOpen(file)
    if (Thread.currentThread().isInterrupted) throw InterruptedException("Render cancelado")
    // engine se conserva en la firma para no romper llamadas existentes; la sesion es la
    // fuente de verdad y puede caer automaticamente de PdfRenderer a PDFBox por pagina.
    @Suppress("UNUSED_VARIABLE") val requestedEngine = engine
    session.render(pageIndex, maxWidth)
}

enum class OfficeViewerType(val label: String, val extensions: String, val mimeTypes: Array<String>) {
    WORD("Word", "DOCX", arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")),
    EXCEL("Excel", "XLSX", arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")),
    POWERPOINT("PowerPoint", "PPTX", arrayOf("application/vnd.openxmlformats-officedocument.presentationml.presentation"))
}

private sealed interface OfficeDocumentModel

private data class WordDocumentModel(val pages: List<WordPageModel>) : OfficeDocumentModel
private data class WordPageModel(val blocks: List<WordBlockModel>)
private sealed interface WordBlockModel {
    data class Paragraph(val text: String) : WordBlockModel
    data class Picture(val entryName: String) : WordBlockModel
    data class Table(val rows: List<List<String>>) : WordBlockModel
}

private data class ExcelWorkbookModel(
    val sharedStrings: List<String>,
    val sheets: List<ExcelSheetRef>,
    val styles: List<ExcelCellStyleModel>
) : OfficeDocumentModel
private data class ExcelSheetRef(val name: String, val entryName: String)
private data class ExcelSheetData(
    val rows: Map<Int, ExcelRowData>,
    val maxColumns: Int,
    val maxRows: Int,
    val columnWidths: Map<Int, Float>,
    val totalRowsHint: Int = maxRows,
    val isComplete: Boolean = true
)
private data class ExcelRowData(
    val rowNumber: Int,
    val cells: Map<Int, ExcelCellData>,
    val heightPoints: Float? = null
)
private data class ExcelCellData(val value: String, val styleIndex: Int)
private data class ExcelCellStyleModel(
    val fillArgb: Int? = null,
    val textArgb: Int? = null,
    val bold: Boolean = false,
    val fontSizePt: Float? = null,
    val horizontal: String? = null,
    val numberFormatCode: String? = null
)

private data class PowerPointDeckModel(
    val widthEmu: Long,
    val heightEmu: Long,
    val slides: List<PowerPointSlideModel>
) : OfficeDocumentModel
private data class PowerPointSlideModel(
    val elements: List<PowerPointElementModel>,
    val transition: PowerPointTransitionModel?,
    val advanceAfterMs: Long?,
    val backgroundArgb: Int? = null
)
private data class PowerPointTransitionModel(
    val type: String,
    val direction: String? = null,
    val orientation: String? = null,
    val durationMs: Int = 360,
    val spokes: Int? = null
)
private sealed interface PowerPointElementModel {
    val x: Long
    val y: Long
    val width: Long
    val height: Long

    data class TextBox(
        val text: String,
        val textArgb: Int?,
        val fontSizePt: Float?,
        val bold: Boolean,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel

    data class Rectangle(
        val fillArgb: Int,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel

    data class Picture(
        val entryName: String,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel
}

@Composable
fun OfficeViewerScreen(
    tool: ToolId,
    type: OfficeViewerType,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    var uriText by rememberSaveable { mutableStateOf<String?>(null) }
    val uri = uriText?.let(Uri::parse)
    var localPath by remember { mutableStateOf<String?>(null) }
    var model by remember { mutableStateOf<OfficeDocumentModel?>(null) }
    var loading by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var retryToken by remember { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var searchVisible by rememberSaveable { mutableStateOf(false) }
    var inverted by rememberSaveable { mutableStateOf(false) }
    var presenting by rememberSaveable { mutableStateOf(false) }
    var presentationStart by rememberSaveable { mutableIntStateOf(0) }
    var powerPointCurrentSlide by rememberSaveable { mutableIntStateOf(0) }
    var resetViewToken by remember { mutableIntStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selected,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            localPath?.let { old ->
                ViewerBitmapCache.clearPrefix("word|$old")
                ViewerBitmapCache.clearPrefix("ppt|$old")
                runCatching { File(old).delete() }
            }
            localPath = null
            model = null
            loading = true
            loadError = null
            query = ""
            presenting = false
            powerPointCurrentSlide = 0
            uriText = selected.toString()
        }
    }

    LaunchedEffect(uriText, retryToken) {
        val selected = uri ?: run {
            onImmersiveChanged(false)
            return@LaunchedEffect
        }
        onImmersiveChanged(true)
        loading = true
        loadError = null
        model = null
        val previous = localPath
        var attemptedCopy: File? = null
        val result = runCatching {
            val copy = kotlinx.coroutines.withTimeout(25000L) {
                copyOfficeToViewerCache(context, selected, type)
            }
            attemptedCopy = copy
            val parsed = kotlinx.coroutines.withTimeout(30000L) {
                runInterruptible(Dispatchers.IO) {
                    when (type) {
                        OfficeViewerType.WORD -> parseDocxModel(copy)
                        OfficeViewerType.EXCEL -> parseXlsxWorkbook(copy)
                        OfficeViewerType.POWERPOINT -> parsePptxDeck(copy)
                    }
                }
            }
            copy to parsed
        }
        result.onSuccess { (copy, parsed) ->
            previous?.takeIf { it != copy.absolutePath }?.let { runCatching { File(it).delete() } }
            localPath = copy.absolutePath
            model = parsed
        }.onFailure { error ->
            attemptedCopy?.let { failed -> runCatching { failed.delete() } }
            localPath = null
            model = null
            loadError = if (error is kotlinx.coroutines.TimeoutCancellationException) {
                "El archivo tardo demasiado en responder. Vuelve a intentarlo."
            } else error.message ?: "No se pudo abrir el archivo ${type.extensions}."
        }
        loading = false
    }

    DisposableEffect(Unit) {
        onDispose {
            onImmersiveChanged(false)
            localPath?.let { path ->
                ViewerBitmapCache.clearPrefix("word|$path")
                ViewerBitmapCache.clearPrefix("ppt|$path")
                runCatching { File(path).delete() }
            }
        }
    }

    androidx.activity.compose.BackHandler(enabled = presenting) { presenting = false }

    if (uri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Visor gratuito ${type.extensions} · sin edición", onBack)
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Ningún archivo seleccionado", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { launcher.launch(type.mimeTypes) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                        Text(" Abrir ${type.label}")
                    }
                    Text(
                        when (type) {
                            OfficeViewerType.WORD -> "Vista por páginas, zoom, búsqueda e invertir colores."
                            OfficeViewerType.EXCEL -> "Hojas, cuadrícula, zoom, búsqueda e invertir colores."
                            OfficeViewerType.POWERPOINT -> "Diapositivas, zoom, búsqueda, invertir colores y modo Presentar."
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        return
    }

    val fileName = remember(uriText) { ToolFileUtils.displayName(context, uri) }
    val path = localPath
    val currentModel = model

    if (presenting && type == OfficeViewerType.POWERPOINT && path != null && currentModel is PowerPointDeckModel) {
        PowerPointPresentation(
            localPath = path,
            deck = currentModel,
            initialSlide = presentationStart,
            inverted = inverted,
            onExit = { presenting = false }
        )
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF121212))
    ) {
        OfficeViewerTopBar(
            fileName = fileName,
            type = type,
            onBack = onBack,
            onOpen = { launcher.launch(type.mimeTypes) }
        )

        if (searchVisible) {
            ViewerSearchBar(
                query = query,
                onQueryChange = { query = it.take(120) },
                onClose = { query = ""; searchVisible = false }
            )
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when {
                loading -> ViewerLoading("Abriendo ${type.label}…")
                loadError != null || path == null || currentModel == null -> ViewerLoadError(
                    message = loadError ?: "No se pudo leer el archivo.",
                    onRetry = { retryToken++ },
                    onChooseOther = { launcher.launch(type.mimeTypes) }
                )
                type == OfficeViewerType.WORD && currentModel is WordDocumentModel -> WordDocumentViewer(
                    localPath = path,
                    document = currentModel,
                    query = query,
                    inverted = inverted,
                    resetViewToken = resetViewToken,
                    onMessage = onMessage
                )
                type == OfficeViewerType.EXCEL && currentModel is ExcelWorkbookModel -> ExcelWorkbookViewer(
                    localPath = path,
                    workbook = currentModel,
                    query = query,
                    inverted = inverted,
                    onMessage = onMessage
                )
                type == OfficeViewerType.POWERPOINT && currentModel is PowerPointDeckModel -> PowerPointDeckViewer(
                    localPath = path,
                    deck = currentModel,
                    query = query,
                    inverted = inverted,
                    onMessage = onMessage,
                    onCurrentSlideChanged = { powerPointCurrentSlide = it }
                )
            }
        }

        OfficeViewerBottomBar(
            type = type,
            inverted = inverted,
            onOpen = { launcher.launch(type.mimeTypes) },
            onSearch = { searchVisible = !searchVisible },
            onInvert = { inverted = !inverted },
            onShare = { shareDocumentFile(context, uri, type.mimeTypes.first()) },
            onResetView = { resetViewToken++ },
            onPresent = if (type == OfficeViewerType.POWERPOINT && currentModel is PowerPointDeckModel) {
                { presentationStart = powerPointCurrentSlide; presenting = true }
            } else null
        )
    }
}

@Composable
private fun OfficeViewerTopBar(
    fileName: String,
    type: OfficeViewerType,
    onBack: () -> Unit,
    onOpen: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth().statusBarsPadding(),
        color = Color(0xFF202124),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(54.dp).padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = Color.White)
            }
            Text(
                fileName,
                modifier = Modifier.weight(1f),
                color = Color.White,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = onOpen) {
                Icon(Icons.Rounded.FolderOpen, contentDescription = "Cambiar ${type.label}", tint = Color.White)
            }
        }
    }
}

@Composable
private fun OfficeViewerBottomBar(
    type: OfficeViewerType,
    inverted: Boolean,
    onOpen: () -> Unit,
    onSearch: () -> Unit,
    onInvert: () -> Unit,
    onShare: () -> Unit,
    onResetView: () -> Unit,
    onPresent: (() -> Unit)?
) {
    Surface(
        modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
        color = Color(0xFF202124),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            when (type) {
                OfficeViewerType.WORD -> {
                    ViewerBottomAction(
                        icon = Icons.Rounded.ViewAgenda,
                        label = "Vertical",
                        selected = true,
                        onClick = onResetView
                    )
                }
                OfficeViewerType.EXCEL -> Unit
                OfficeViewerType.POWERPOINT -> if (onPresent != null) {
                    ViewerBottomAction(
                        icon = Icons.Rounded.Slideshow,
                        label = "Presentar",
                        selected = false,
                        onClick = onPresent
                    )
                }
            }
            ViewerBottomAction(Icons.Rounded.Search, "Buscar", false, onSearch)
            ViewerBottomAction(Icons.Rounded.InvertColors, "Invertir", inverted, onInvert)
            ViewerBottomAction(Icons.Rounded.Share, "Compartir", false, onShare)
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.ViewerBottomAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier.weight(1f).fillMaxHeight().clickable(onClick = onClick).padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (selected) NeonGreen else Color.White.copy(alpha = 0.88f),
            modifier = Modifier.size(20.dp)
        )
        Text(
            label,
            color = if (selected) NeonGreen else Color.White.copy(alpha = 0.82f),
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1
        )
    }
}

@Composable
private fun ViewerSearchBar(query: String, onQueryChange: (String) -> Unit, onClose: () -> Unit) {
    Surface(color = Color(0xFF292A2D), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Buscar en el archivo") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = "Cerrar búsqueda", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ViewerLoading(label: String) {
    Box(Modifier.fillMaxSize().background(Color(0xFF121212)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = NeonGreen)
            Spacer(Modifier.height(12.dp))
            Text(label, color = Color.White.copy(alpha = 0.78f))
        }
    }
}

@Composable
private fun ViewerLoadError(message: String, onRetry: () -> Unit, onChooseOther: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xFF121212)).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202124)), shape = RoundedCornerShape(20.dp)) {
            Column(
                Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("No se pudo abrir el archivo", color = Color.White, fontWeight = FontWeight.Bold)
                Text(message, color = Color.White.copy(alpha = 0.72f))
                OutlinedButton(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text("Reintentar") }
                OutlinedButton(onClick = onChooseOther, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                    Text(" Elegir otro archivo")
                }
            }
        }
    }
}

@Composable
private fun WordDocumentViewer(
    localPath: String,
    document: WordDocumentModel,
    query: String,
    inverted: Boolean,
    resetViewToken: Int,
    onMessage: (String) -> Unit
) {
    val matchingPages = remember(document, query) {
        if (query.isBlank()) emptySet()
        else document.pages.mapIndexedNotNull { index, page ->
            if (page.blocks.any { block -> wordBlockContains(block, query) }) index else null
        }.toSet()
    }
    val jumpTarget = matchingPages.minOrNull()

    DrivePagedSurface(
        viewerKey = "word_$localPath",
        pageCount = document.pages.size,
        background = if (inverted) Color.Black else Color(0xFF303030),
        resetViewToken = resetViewToken,
        jumpToPage = jumpTarget,
        jumpRequestKey = query,
        minZoom = 1f,
        maxZoom = 2.5f,
        pageContent = { index, renderWidth, pageWidth ->
            WordRenderedPage(
                localPath = localPath,
                page = document.pages[index],
                inverted = inverted,
                matched = index in matchingPages,
                renderWidth = renderWidth,
                modifier = Modifier.width(pageWidth),
                onMessage = onMessage
            )
        }
    )
}

@Composable
private fun WordPageCard(
    localPath: String,
    page: WordPageModel,
    inverted: Boolean,
    matched: Boolean,
    modifier: Modifier = Modifier,
    onMessage: (String) -> Unit
) {
    val pageColor = if (inverted) Color(0xFF111111) else Color.White
    val textColor = if (inverted) Color(0xFFF1F1F1) else Color(0xFF181818)
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(1.dp))
            .background(pageColor)
            .then(if (matched) Modifier.border(2.dp, NeonGreen) else Modifier)
            .padding(horizontal = 26.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        page.blocks.forEach { block ->
            when (block) {
                is WordBlockModel.Paragraph -> if (block.text.isNotBlank()) {
                    Text(
                        block.text,
                        color = textColor,
                        fontSize = 10.5.sp,
                        lineHeight = 14.2.sp
                    )
                }
                is WordBlockModel.Picture -> OfficeZipImage(
                    localPath = localPath,
                    entryName = block.entryName,
                    inverted = inverted,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 210.dp),
                    onMessage = onMessage
                )
                is WordBlockModel.Table -> WordTableBlock(block, inverted)
            }
        }
    }
}

@Composable
private fun WordTableBlock(table: WordBlockModel.Table, inverted: Boolean) {
    val fg = if (inverted) Color(0xFFF1F1F1) else Color(0xFF202124)
    val grid = if (inverted) Color(0xFF686868) else Color(0xFFB7B7B7)
    Column(Modifier.fillMaxWidth().border(0.7.dp, grid)) {
        table.rows.take(20).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                if (row.isEmpty()) {
                    Box(Modifier.weight(1f).height(24.dp).border(0.5.dp, grid))
                } else {
                    row.forEach { cell ->
                        Box(
                            Modifier.weight(1f)
                                .heightIn(min = 24.dp)
                                .border(0.5.dp, grid)
                                .padding(4.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                cell,
                                color = fg,
                                fontSize = 8.5.sp,
                                lineHeight = 11.sp,
                                maxLines = 4,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun wordBlockContains(block: WordBlockModel, query: String): Boolean = when (block) {
    is WordBlockModel.Paragraph -> block.text.contains(query, true)
    is WordBlockModel.Picture -> false
    is WordBlockModel.Table -> block.rows.any { row -> row.any { it.contains(query, true) } }
}


@Composable
private fun WordRenderedPage(
    localPath: String,
    page: WordPageModel,
    inverted: Boolean,
    matched: Boolean,
    renderWidth: Int,
    modifier: Modifier = Modifier,
    onMessage: (String) -> Unit
) {
    val stableRenderWidth = 1500
    val cacheKey = remember(localPath, page, inverted) {
        "word|$localPath|${page.hashCode()}|$inverted|$stableRenderWidth"
    }
    var bitmap by remember(cacheKey) { mutableStateOf(ViewerBitmapCache.get(cacheKey)) }

    LaunchedEffect(localPath, page, inverted) {
        ViewerBitmapCache.get(cacheKey)?.let {
            bitmap = it
            return@LaunchedEffect
        }
        runCatching {
            runInterruptible(Dispatchers.IO) {
                renderWordPageBitmap(File(localPath), page, stableRenderWidth, inverted)
            }
        }.onSuccess { fresh ->
            bitmap = ViewerBitmapCache.put(cacheKey, fresh)
        }.onFailure { error ->
            onMessage(error.message ?: "No se pudo renderizar una página de Word.")
        }
    }

    Box(
        modifier = modifier
            .aspectRatio(1f / 1.294f)
            .background(if (inverted) Color(0xFF111111) else Color.White)
            .then(if (matched) Modifier.border(2.dp, NeonGreen) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        val current = bitmap
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private fun renderWordPageBitmap(
    file: File,
    page: WordPageModel,
    requestedWidth: Int,
    inverted: Boolean
): Bitmap {
    val width = requestedWidth.coerceIn(600, 3000)
    val height = (width * 1.294f).roundToInt().coerceAtLeast(1)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    val background = if (inverted) AndroidColor.rgb(18, 18, 18) else AndroidColor.WHITE
    val foreground = if (inverted) AndroidColor.rgb(238, 238, 238) else AndroidColor.rgb(28, 28, 28)
    val gridColor = if (inverted) AndroidColor.rgb(100, 100, 100) else AndroidColor.rgb(175, 175, 175)
    canvas.drawColor(background)

    val margin = width * 0.075f
    val contentWidth = (width - margin * 2f).roundToInt().coerceAtLeast(1)
    val bottom = height - margin
    var y = margin

    val paragraphPaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = foreground
        textSize = width * 0.0215f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.NORMAL)
    }
    val tablePaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = foreground
        textSize = width * 0.0155f
    }
    val linePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = gridColor
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = (width / 1000f).coerceAtLeast(1f)
    }
    val imagePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG).apply {
        if (inverted) colorFilter = android.graphics.ColorMatrixColorFilter(
            android.graphics.ColorMatrix(
                floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }

    java.util.zip.ZipFile(file).use { zip ->
        for (block in page.blocks) {
            if (Thread.currentThread().isInterrupted) throw InterruptedException("Render cancelado")
            if (y >= bottom) break
            when (block) {
                is WordBlockModel.Paragraph -> {
                    val text = block.text.trim()
                    if (text.isNotEmpty()) {
                        val layout = buildStaticLayout(text, paragraphPaint, contentWidth)
                        if (y + layout.height > bottom) break
                        canvas.save()
                        canvas.translate(margin, y)
                        layout.draw(canvas)
                        canvas.restore()
                        y += layout.height + width * 0.010f
                    }
                }
                is WordBlockModel.Picture -> {
                    val image = runCatching { decodeOfficeZipBitmap(zip, block.entryName) }.getOrNull()
                    if (image != null) {
                        val maxImageHeight = min(width * 0.40f, bottom - y)
                        val scale = min(contentWidth.toFloat() / image.width.coerceAtLeast(1), maxImageHeight / image.height.coerceAtLeast(1))
                        val drawW = image.width * scale
                        val drawH = image.height * scale
                        val left = margin + (contentWidth - drawW) / 2f
                        val dst = android.graphics.RectF(left, y, left + drawW, y + drawH)
                        canvas.drawBitmap(image, null, dst, imagePaint)
                        if (!image.isRecycled) image.recycle()
                        y += drawH + width * 0.012f
                    }
                }
                is WordBlockModel.Table -> {
                    val rows = block.rows.take(24)
                    if (rows.isNotEmpty()) {
                        val columns = rows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
                        val cellWidth = contentWidth.toFloat() / columns
                        val rowHeight = (width * 0.038f).coerceAtLeast(22f)
                        for (row in rows) {
                            if (y + rowHeight > bottom) break
                            for (column in 0 until columns) {
                                val left = margin + column * cellWidth
                                val rect = android.graphics.RectF(left, y, left + cellWidth, y + rowHeight)
                                canvas.drawRect(rect, linePaint)
                                val cellText = row.getOrNull(column).orEmpty()
                                if (cellText.isNotBlank()) {
                                    val available = (cellWidth - width * 0.010f).roundToInt().coerceAtLeast(1)
                                    val layout = buildStaticLayout(cellText, tablePaint, available, maxLines = 2)
                                    canvas.save()
                                    canvas.clipRect(rect)
                                    canvas.translate(left + width * 0.005f, y + width * 0.004f)
                                    layout.draw(canvas)
                                    canvas.restore()
                                }
                            }
                            y += rowHeight
                        }
                        y += width * 0.012f
                    }
                }
            }
        }
    }
    return bitmap
}

private fun buildStaticLayout(
    text: String,
    paint: android.text.TextPaint,
    width: Int,
    maxLines: Int = Int.MAX_VALUE
): android.text.StaticLayout {
    return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
        android.text.StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(1))
            .setAlignment(android.text.Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.08f)
            .setMaxLines(maxLines)
            .setEllipsize(if (maxLines == Int.MAX_VALUE) null else android.text.TextUtils.TruncateAt.END)
            .build()
    } else {
        @Suppress("DEPRECATION")
        android.text.StaticLayout(
            text,
            paint,
            width.coerceAtLeast(1),
            android.text.Layout.Alignment.ALIGN_NORMAL,
            1.08f,
            0f,
            false
        )
    }
}

@Composable
private fun ExcelWorkbookViewer(
    localPath: String,
    workbook: ExcelWorkbookModel,
    query: String,
    inverted: Boolean,
    onMessage: (String) -> Unit
) {
    var selectedSheet by rememberSaveable(localPath) { mutableIntStateOf(0) }
    var sheetData by remember(localPath, selectedSheet) { mutableStateOf<ExcelSheetData?>(null) }
    var loadingSheet by remember(localPath, selectedSheet) { mutableStateOf(true) }
    var loadingMore by remember(localPath, selectedSheet) { mutableStateOf(false) }
    var loadedRowLimit by remember(localPath, selectedSheet) { mutableIntStateOf(0) }
    var sheetError by remember(localPath, selectedSheet) { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    val horizontalState = rememberScrollState()
    val density = LocalDensity.current
    var selectedCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    LaunchedEffect(localPath, selectedSheet) {
        loadingSheet = true
        loadingMore = false
        loadedRowLimit = 0
        sheetError = null
        sheetData = null
        horizontalState.scrollTo(0)
        try {
            // No se hace scrollToItem antes de que exista el LazyColumn: esa llamada podia
            // quedar suspendida esperando un layout inexistente y dejaba "Cargando hoja..."
            // para siempre. Primero leemos un bloque pequeno y lo mostramos enseguida.
            val firstLimit = 100
            val initial = kotlinx.coroutines.withTimeout(15000L) {
                withContext(Dispatchers.IO) {
                    parseXlsxSheet(
                        File(localPath),
                        workbook.sheets[selectedSheet],
                        workbook.sharedStrings,
                        workbook.styles,
                        rowLimit = firstLimit
                    )
                }
            }
            sheetData = initial
            loadedRowLimit = firstLimit
            listState.requestScrollToItem(0, 0)
        } catch (error: Throwable) {
            sheetError = if (error is kotlinx.coroutines.TimeoutCancellationException) {
                "La hoja tardo demasiado en abrir."
            } else error.message ?: "No se pudo leer esta hoja."
            onMessage(sheetError!!)
        } finally {
            loadingSheet = false
        }
    }

    // Se cargan mas filas solo al acercarse al final del bloque actual. El parser ahora
    // coopera con cancelacion para que un archivo pesado no deje el visor bloqueado.
    LaunchedEffect(localPath, selectedSheet, listState) {
        androidx.compose.runtime.snapshotFlow {
            listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
        }.collect { lastVisibleIndex ->
            val current = sheetData ?: return@collect
            if (loadingSheet || loadingMore || current.isComplete) return@collect
            val lastVisibleRow = lastVisibleIndex + 1
            if (lastVisibleRow < loadedRowLimit - 30) return@collect

            val totalHint = current.totalRowsHint.coerceAtLeast(current.maxRows)
            val nextLimit = maxOf(loadedRowLimit * 2, loadedRowLimit + 500, lastVisibleRow + 300)
                .coerceAtMost(totalHint.coerceAtLeast(loadedRowLimit + 1))
            if (nextLimit <= loadedRowLimit) return@collect

            loadingMore = true
            val expanded = runCatching {
                kotlinx.coroutines.withTimeout(15000L) {
                    withContext(Dispatchers.IO) {
                        parseXlsxSheet(
                            File(localPath),
                            workbook.sheets[selectedSheet],
                            workbook.sharedStrings,
                            workbook.styles,
                            rowLimit = nextLimit
                        )
                    }
                }
            }
            expanded.onSuccess { fresh ->
                sheetData = fresh
                loadedRowLimit = nextLimit
            }.onFailure { error ->
                if (error !is kotlinx.coroutines.CancellationException) {
                    onMessage(error.message ?: "No se pudieron cargar mas filas.")
                }
            }
            loadingMore = false
        }
    }

    val dataForSearch = sheetData
    LaunchedEffect(query, dataForSearch) {
        if (query.isNotBlank() && dataForSearch != null) {
            val firstMatch = dataForSearch.rows.entries.firstOrNull { (_, row) ->
                row.cells.values.any { it.value.contains(query, ignoreCase = true) }
            }?.key
            if (firstMatch != null && firstMatch > 0) {
                listState.animateScrollToItem((firstMatch - 1).coerceAtLeast(0))
            }
        }
    }

    Column(Modifier.fillMaxSize().background(if (inverted) Color.Black else Color.White)) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .background(if (inverted) Color(0xFF121212) else Color(0xFFF5F5F5))
                .padding(horizontal = 4.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            workbook.sheets.forEachIndexed { index, sheet ->
                val active = index == selectedSheet
                Surface(
                    modifier = Modifier.clickable {
                        selectedSheet = index
                        selectedCell = null
                    },
                    color = if (active) {
                        if (inverted) Color(0xFF0C5D32) else Color(0xFFDFF4E8)
                    } else Color.Transparent,
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text(
                        sheet.name,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        color = if (active) {
                            if (inverted) Color.White else Color(0xFF0B6B3A)
                        } else if (inverted) Color(0xFFD0D0D0) else Color(0xFF555555),
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
            }
        }

        if (loadingSheet) {
            ViewerLoading("Cargando hoja…")
            return@Column
        }
        val data = sheetData
        if (sheetError != null || data == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(sheetError ?: "Hoja no disponible", color = if (inverted) Color.White else Color.DarkGray)
            }
        } else {
            BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
                val rowHeaderWidth = 34.dp
                val headerHeight = 25.dp
                val columnWidths = remember(data) {
                    List(data.maxColumns) { col ->
                        val chars = data.columnWidths[col] ?: 9.0f
                        ((chars * 7.1f).coerceIn(38f, 260f)).dp
                    }
                }
                val prefixWidths = remember(columnWidths) {
                    FloatArray(columnWidths.size + 1).also { prefix ->
                        columnWidths.forEachIndexed { index, width ->
                            prefix[index + 1] = prefix[index] + width.value
                        }
                    }
                }
                val totalColumnsDp = prefixWidths.lastOrNull() ?: 0f
                val baseTotalWidth = rowHeaderWidth + totalColumnsDp.dp
                val contentWidth = if (baseTotalWidth < maxWidth) maxWidth else baseTotalWidth

                // Virtualizacion horizontal: solo se componen las columnas visibles y un
                // pequeno margen. Antes se creaban hasta 256 celdas por cada fila visible.
                val scrollDp = with(density) { horizontalState.value.toDp().value }
                val viewportDp = maxWidth.value
                val startInColumns = (scrollDp - rowHeaderWidth.value).coerceAtLeast(0f)
                val endInColumns = (scrollDp + viewportDp - rowHeaderWidth.value).coerceAtLeast(0f)
                var firstVisible = 0
                while (
                    firstVisible < data.maxColumns - 1 &&
                    prefixWidths[firstVisible + 1] < startInColumns
                ) firstVisible++
                var lastVisible = firstVisible
                while (
                    lastVisible < data.maxColumns - 1 &&
                    prefixWidths[lastVisible] <= endInColumns
                ) lastVisible++
                firstVisible = (firstVisible - 2).coerceAtLeast(0)
                lastVisible = (lastVisible + 2).coerceAtMost(data.maxColumns - 1)
                val leadingWidth = prefixWidths[firstVisible].dp
                val trailingWidth = (totalColumnsDp - prefixWidths[lastVisible + 1]).coerceAtLeast(0f).dp

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(horizontalState)
                ) {
                    Column(Modifier.width(contentWidth).fillMaxHeight()) {
                        ExcelColumnHeaders(
                            maxColumns = data.maxColumns,
                            rowHeaderWidth = rowHeaderWidth,
                            columnWidths = columnWidths,
                            rowHeight = headerHeight,
                            inverted = inverted,
                            visibleStart = firstVisible,
                            visibleEnd = lastVisible,
                            leadingColumnsWidth = leadingWidth,
                            trailingColumnsWidth = trailingWidth,
                            modifier = Modifier.width(baseTotalWidth).height(headerHeight)
                        )
                        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth()) {
                            items(data.maxRows, key = { index -> "excel_row_${index + 1}" }) { index ->
                                val rowNumber = index + 1
                                val row = data.rows[rowNumber] ?: ExcelRowData(rowNumber, emptyMap())
                                val rowHeight = (((row.heightPoints ?: 18f) * 1.15f).coerceIn(20f, 120f)).dp
                                ExcelGridRow(
                                    row = row,
                                    maxColumns = data.maxColumns,
                                    rowHeaderWidth = rowHeaderWidth,
                                    columnWidths = columnWidths,
                                    rowHeight = rowHeight,
                                    query = query,
                                    inverted = inverted,
                                    styles = workbook.styles,
                                    selectedCell = selectedCell,
                                    onCellSelected = { col -> selectedCell = row.rowNumber to col },
                                    visibleStart = firstVisible,
                                    visibleEnd = lastVisible,
                                    leadingColumnsWidth = leadingWidth,
                                    trailingColumnsWidth = trailingWidth,
                                    modifier = Modifier.width(baseTotalWidth).height(rowHeight)
                                )
                            }
                        }
                    }
                }

                ViewerSideCounter(
                    text = "${selectedSheet + 1}/${workbook.sheets.size}",
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun ExcelColumnHeaders(
    maxColumns: Int,
    rowHeaderWidth: androidx.compose.ui.unit.Dp,
    columnWidths: List<androidx.compose.ui.unit.Dp>,
    rowHeight: androidx.compose.ui.unit.Dp,
    inverted: Boolean,
    visibleStart: Int,
    visibleEnd: Int,
    leadingColumnsWidth: androidx.compose.ui.unit.Dp,
    trailingColumnsWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    val bg = if (inverted) Color(0xFF202020) else Color(0xFFEFEFEF)
    val fg = if (inverted) Color(0xFFEAEAEA) else Color(0xFF333333)
    val grid = if (inverted) Color(0xFF4A4A4A) else Color(0xFFC9C9C9)
    Row(modifier) {
        Box(Modifier.width(rowHeaderWidth).height(rowHeight).background(bg).border(0.5.dp, grid))
        if (leadingColumnsWidth > 0.dp) Spacer(Modifier.width(leadingColumnsWidth))
        if (maxColumns > 0 && visibleStart <= visibleEnd) {
            for (col in visibleStart..visibleEnd) {
                Box(
                    Modifier.width(columnWidths[col]).height(rowHeight).background(bg).border(0.5.dp, grid),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        excelColumnName(col),
                        color = fg,
                        fontWeight = FontWeight.Medium,
                        fontSize = 10.sp
                    )
                }
            }
        }
        if (trailingColumnsWidth > 0.dp) Spacer(Modifier.width(trailingColumnsWidth))
    }
}

@Composable
private fun ExcelGridRow(
    row: ExcelRowData,
    maxColumns: Int,
    rowHeaderWidth: androidx.compose.ui.unit.Dp,
    columnWidths: List<androidx.compose.ui.unit.Dp>,
    rowHeight: androidx.compose.ui.unit.Dp,
    query: String,
    inverted: Boolean,
    styles: List<ExcelCellStyleModel>,
    selectedCell: Pair<Int, Int>?,
    onCellSelected: (Int) -> Unit,
    visibleStart: Int,
    visibleEnd: Int,
    leadingColumnsWidth: androidx.compose.ui.unit.Dp,
    trailingColumnsWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    val bg = if (inverted) Color(0xFF0A0A0A) else Color.White
    val headerBg = if (inverted) Color(0xFF202020) else Color(0xFFEFEFEF)
    val fg = if (inverted) Color(0xFFF1F1F1) else Color(0xFF202124)
    val grid = if (inverted) Color(0xFF383838) else Color(0xFFD4D4D4)
    Row(modifier) {
        Box(
            Modifier.width(rowHeaderWidth).height(rowHeight).background(headerBg).border(0.5.dp, grid),
            contentAlignment = Alignment.Center
        ) {
            Text(row.rowNumber.toString(), color = fg, fontSize = 9.5.sp)
        }
        if (leadingColumnsWidth > 0.dp) Spacer(Modifier.width(leadingColumnsWidth))
        if (maxColumns > 0 && visibleStart <= visibleEnd) {
            for (col in visibleStart..visibleEnd) {
                val cell = row.cells[col]
                val value = cell?.value.orEmpty()
                val style = styles.getOrNull(cell?.styleIndex ?: 0)
                val styledBg = style?.fillArgb?.let { Color(if (inverted) invertArgb(it) else it) } ?: bg
                val styledFg = style?.textArgb?.let { Color(if (inverted) invertArgb(it) else it) } ?: fg
                val isMatch = query.isNotBlank() && value.contains(query, ignoreCase = true)
                val isSelected = selectedCell == (row.rowNumber to col)
                val contentAlignment = when (style?.horizontal?.lowercase()) {
                    "center" -> Alignment.Center
                    "right" -> Alignment.CenterEnd
                    else -> Alignment.CenterStart
                }
                Box(
                    modifier = Modifier.width(columnWidths[col]).height(rowHeight).background(styledBg)
                        .border(
                            width = if (isSelected || isMatch) 1.8.dp else 0.5.dp,
                            color = if (isSelected || isMatch) Color(0xFF16A765) else grid
                        )
                        .clickable { onCellSelected(col) }
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    contentAlignment = contentAlignment
                ) {
                    Text(
                        value,
                        color = styledFg,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = (style?.fontSizePt ?: 10f).sp,
                        lineHeight = ((style?.fontSizePt ?: 10f) * 1.15f).sp,
                        fontWeight = if (style?.bold == true) FontWeight.Bold else FontWeight.Normal,
                        textAlign = when (style?.horizontal?.lowercase()) {
                            "center" -> TextAlign.Center
                            "right" -> TextAlign.End
                            else -> TextAlign.Start
                        }
                    )
                }
            }
        }
        if (trailingColumnsWidth > 0.dp) Spacer(Modifier.width(trailingColumnsWidth))
    }
}

@Composable
private fun PowerPointDeckViewer(
    localPath: String,
    deck: PowerPointDeckModel,
    query: String,
    inverted: Boolean,
    onMessage: (String) -> Unit,
    onCurrentSlideChanged: (Int) -> Unit
) {
    val matchingSlides = remember(deck, query) {
        if (query.isBlank()) emptySet()
        else deck.slides.mapIndexedNotNull { index, slide ->
            val found = slide.elements.any { element ->
                element is PowerPointElementModel.TextBox && element.text.contains(query, true)
            }
            if (found) index else null
        }.toSet()
    }
    val jumpTarget = matchingSlides.minOrNull()

    DrivePagedSurface(
        viewerKey = "ppt_$localPath",
        pageCount = deck.slides.size,
        background = if (inverted) Color.Black else Color(0xFF252525),
        jumpToPage = jumpTarget,
        jumpRequestKey = query,
        minZoom = 1f,
        maxZoom = 2.5f,
        onCurrentPageChanged = onCurrentSlideChanged,
        pageContent = { index, renderWidth, pageWidth ->
            val ratio = deck.widthEmu.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f)
            PowerPointRenderedSlide(
                localPath = localPath,
                deck = deck,
                slide = deck.slides[index],
                inverted = inverted,
                renderWidth = renderWidth,
                matched = index in matchingSlides,
                modifier = Modifier.width(pageWidth).aspectRatio(ratio),
                onMessage = onMessage
            )
        }
    )
}

@Composable
private fun PowerPointPresentation(
    localPath: String,
    deck: PowerPointDeckModel,
    initialSlide: Int,
    inverted: Boolean,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    var current by rememberSaveable(localPath, initialSlide) {
        mutableIntStateOf(initialSlide.coerceIn(0, deck.slides.lastIndex))
    }
    var previous by remember(localPath, initialSlide) { mutableIntStateOf(current) }
    var direction by remember { mutableIntStateOf(1) }
    var controlsVisible by remember { mutableStateOf(false) }
    var transitionSerial by remember { mutableIntStateOf(0) }
    val transitionProgress = remember { androidx.compose.animation.core.Animatable(1f) }

    // Solo Presentar fuerza paisaje y entra en modo inmersivo real. No quedan hora,
    // bateria, barra de navegacion ni controles de la app sobre la diapositiva.
    DisposableEffect(activity) {
        val previousOrientation = activity?.requestedOrientation
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        if (window != null && controller != null) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            if (window != null && controller != null) {
                controller.show(WindowInsetsCompat.Type.systemBars())
                WindowCompat.setDecorFitsSystemWindows(window, true)
            }
            if (previousOrientation != null) activity?.requestedOrientation = previousOrientation
        }
    }

    val goTo: (Int) -> Unit = { target ->
        val fixed = target.coerceIn(0, deck.slides.lastIndex)
        if (fixed != current) {
            previous = current
            direction = if (fixed > current) 1 else -1
            current = fixed
            transitionSerial++
        }
    }

    LaunchedEffect(transitionSerial, current) {
        if (transitionSerial == 0) {
            transitionProgress.snapTo(1f)
            return@LaunchedEffect
        }
        val spec = deck.slides[current].transition
        if (spec == null || !isSupportedPowerPointTransition(spec.type)) {
            transitionProgress.snapTo(1f)
        } else {
            transitionProgress.snapTo(0f)
            transitionProgress.animateTo(
                targetValue = 1f,
                animationSpec = androidx.compose.animation.core.tween(
                    durationMillis = spec.durationMs.coerceIn(180, 900),
                    easing = androidx.compose.animation.core.FastOutSlowInEasing
                )
            )
        }
    }

    val autoMs = deck.slides[current].advanceAfterMs
    LaunchedEffect(current, autoMs) {
        if (autoMs != null && autoMs in 200L..120000L && current < deck.slides.lastIndex) {
            kotlinx.coroutines.delay(autoMs)
            goTo(current + 1)
        }
    }
    LaunchedEffect(controlsVisible, current) {
        if (controlsVisible) {
            kotlinx.coroutines.delay(1600L)
            controlsVisible = false
        }
    }

    // Precarga anterior/siguiente para que el cambio empiece con la imagen lista.
    LaunchedEffect(localPath, current, inverted) {
        val file = File(localPath)
        val neighbors = listOf(current - 2, current - 1, current + 1, current + 2)
            .filter { it in deck.slides.indices }
        withContext(Dispatchers.IO) {
            neighbors.forEach { index ->
                val slide = deck.slides[index]
                val key = "ppt|$localPath|${slide.hashCode()}|$inverted|1600"
                if (ViewerBitmapCache.get(key) == null) {
                    runCatching { renderPowerPointSlideBitmap(file, deck, slide, 1600, inverted) }
                        .onSuccess { ViewerBitmapCache.put(key, it) }
                }
            }
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(current, deck.slides.size) {
                detectTapGestures(
                    onTap = { offset ->
                        val leftLimit = size.width / 3f
                        val rightLimit = size.width * 2f / 3f
                        when {
                            offset.x <= leftLimit -> if (current > 0) goTo(current - 1)
                            offset.x >= rightLimit -> if (current < deck.slides.lastIndex) goTo(current + 1)
                            else -> controlsVisible = !controlsVisible
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        val slideRatio = deck.widthEmu.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f)
        val availableRatio = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
        val fittedWidth: androidx.compose.ui.unit.Dp
        val fittedHeight: androidx.compose.ui.unit.Dp
        if (availableRatio > slideRatio) {
            fittedHeight = maxHeight
            fittedWidth = fittedHeight * slideRatio
        } else {
            fittedWidth = maxWidth
            fittedHeight = fittedWidth / slideRatio
        }

        val progress = transitionProgress.value.coerceIn(0f, 1f)
        val spec = deck.slides[current].transition
        val type = spec?.type.orEmpty().lowercase()
        val storedDir = spec?.direction?.lowercase()
        val horizontalSign = when (storedDir) {
            "l", "left" -> 1f
            "r", "right" -> -1f
            else -> if (direction >= 0) 1f else -1f
        }
        val verticalSign = when (storedDir) {
            "u", "up" -> 1f
            "d", "down" -> -1f
            else -> if (direction >= 0) 1f else -1f
        }
        val isPush = type in setOf("push", "cover", "pull")
        val isVerticalPush = storedDir in setOf("u", "up", "d", "down")
        val isFade = type in setOf("fade", "dissolve")
        val isZoom = type in setOf("zoom", "newsflash")
        val transitioning = transitionSerial > 0 && progress < 0.999f && previous != current

        if (transitioning) {
            var oldModifier = Modifier.width(fittedWidth).height(fittedHeight)
            if (isPush) {
                oldModifier = if (isVerticalPush) {
                    oldModifier.offset(y = fittedHeight * (-verticalSign * progress))
                } else {
                    oldModifier.offset(x = fittedWidth * (-horizontalSign * progress))
                }
            }
            if (isFade) oldModifier = oldModifier.graphicsLayer { alpha = 1f - progress }
            if (isZoom) oldModifier = oldModifier.graphicsLayer {
                alpha = 1f - progress * 0.35f
                scaleX = 1f + progress * 0.025f
                scaleY = 1f + progress * 0.025f
            }
            PowerPointRenderedSlide(
                localPath = localPath,
                deck = deck,
                slide = deck.slides[previous],
                inverted = inverted,
                renderWidth = 1600,
                matched = false,
                modifier = oldModifier,
                onMessage = {}
            )
        }

        var incomingModifier = Modifier.width(fittedWidth).height(fittedHeight)
        if (transitioning && isPush) {
            incomingModifier = if (isVerticalPush) {
                incomingModifier.offset(y = fittedHeight * (verticalSign * (1f - progress)))
            } else {
                incomingModifier.offset(x = fittedWidth * (horizontalSign * (1f - progress)))
            }
        }
        if (transitioning && isFade) {
            incomingModifier = incomingModifier.graphicsLayer { alpha = progress }
        }
        if (transitioning && isZoom) {
            incomingModifier = incomingModifier.graphicsLayer {
                alpha = progress
                val s = 0.86f + 0.14f * progress
                scaleX = s
                scaleY = s
            }
        }
        if (transitioning && !isPush && !isFade && !isZoom) {
            incomingModifier = incomingModifier.powerPointRevealClip(spec, progress, direction)
        }

        PowerPointRenderedSlide(
            localPath = localPath,
            deck = deck,
            slide = deck.slides[current],
            inverted = inverted,
            renderWidth = 1600,
            matched = false,
            modifier = incomingModifier,
            onMessage = {}
        )

        // Presentacion limpia: no flechas, contador ni barras. El centro solo muestra
        // durante un instante el boton de salida; los costados cambian de diapositiva.
        if (controlsVisible) {
            Surface(
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
                color = Color(0xB3111111),
                shape = RoundedCornerShape(22.dp)
            ) {
                IconButton(onClick = onExit) {
                    Icon(Icons.Rounded.Close, contentDescription = "Salir de Presentar", tint = Color.White)
                }
            }
        }
    }
}

private fun isSupportedPowerPointTransition(type: String): Boolean =
    type.lowercase() in setOf(
        "fade", "dissolve", "push", "cover", "pull", "wipe", "split", "blinds",
        "randombar", "checker", "diamond", "circle", "plus", "zoom", "newsflash",
        "wheel", "wedge"
    )

private fun Modifier.powerPointRevealClip(
    spec: PowerPointTransitionModel?,
    progress: Float,
    navigationDirection: Int
): Modifier {
    if (spec == null || progress >= 0.999f) return this
    val type = spec.type.lowercase()
    val p = progress.coerceIn(0f, 1f)
    val dir = spec.direction?.lowercase()
    return drawWithContent {
        val contentScope = this
        when (type) {
            "wipe" -> {
                when (dir) {
                    "r", "right" -> clipRect(size.width * (1f - p), 0f, size.width, size.height) { contentScope.drawContent() }
                    "u", "up" -> clipRect(0f, size.height * (1f - p), size.width, size.height) { contentScope.drawContent() }
                    "d", "down" -> clipRect(0f, 0f, size.width, size.height * p) { contentScope.drawContent() }
                    else -> clipRect(0f, 0f, size.width * p, size.height) { contentScope.drawContent() }
                }
            }

            "split" -> {
                val vertical = spec.orientation?.equals("vert", true) == true || dir == "vert"
                if (vertical) {
                    val half = size.width * 0.5f * p
                    clipRect(size.width / 2f - half, 0f, size.width / 2f + half, size.height) { contentScope.drawContent() }
                } else {
                    val half = size.height * 0.5f * p
                    clipRect(0f, size.height / 2f - half, size.width, size.height / 2f + half) { contentScope.drawContent() }
                }
            }

            "blinds" -> {
                val vertical = dir == "vert" || spec.orientation?.equals("vert", true) == true
                val strips = 8
                val path = Path()
                if (vertical) {
                    val stripW = size.width / strips
                    repeat(strips) { i ->
                        val left = i * stripW
                        path.addRect(Rect(left, 0f, left + stripW * p, size.height))
                    }
                } else {
                    val stripH = size.height / strips
                    repeat(strips) { i ->
                        val top = i * stripH
                        path.addRect(Rect(0f, top, size.width, top + stripH * p))
                    }
                }
                clipPath(path) { contentScope.drawContent() }
            }

            "randombar" -> {
                val vertical = dir == "vert"
                val bars = 10
                val path = Path()
                if (vertical) {
                    val barW = size.width / bars
                    repeat(bars) { i ->
                        val threshold = ((i * 7) % bars).toFloat() / bars
                        val local = ((p - threshold * 0.45f) / 0.55f).coerceIn(0f, 1f)
                        val left = i * barW
                        path.addRect(Rect(left, 0f, left + barW, size.height * local))
                    }
                } else {
                    val barH = size.height / bars
                    repeat(bars) { i ->
                        val threshold = ((i * 7) % bars).toFloat() / bars
                        val local = ((p - threshold * 0.45f) / 0.55f).coerceIn(0f, 1f)
                        val top = i * barH
                        path.addRect(Rect(0f, top, size.width * local, top + barH))
                    }
                }
                clipPath(path) { contentScope.drawContent() }
            }

            "checker" -> {
                val cols = 8
                val rows = 6
                val cellW = size.width / cols
                val cellH = size.height / rows
                val path = Path()
                for (r in 0 until rows) {
                    for (c in 0 until cols) {
                        val order = ((r + c) % 2) * (cols * rows / 2) + (r * cols + c) / 2
                        val threshold = order.toFloat() / (cols * rows).toFloat()
                        if (p >= threshold) {
                            path.addRect(Rect(c * cellW, r * cellH, (c + 1) * cellW, (r + 1) * cellH))
                        }
                    }
                }
                clipPath(path) { contentScope.drawContent() }
            }

            "diamond" -> {
                val radius = (size.width + size.height) * 0.52f * p
                val cx = size.width / 2f
                val cy = size.height / 2f
                val path = Path().apply {
                    moveTo(cx, cy - radius)
                    lineTo(cx + radius, cy)
                    lineTo(cx, cy + radius)
                    lineTo(cx - radius, cy)
                    close()
                }
                clipPath(path) { contentScope.drawContent() }
            }

            "circle" -> {
                val radius = hypot(size.width.toDouble(), size.height.toDouble()).toFloat() * 0.55f * p
                val cx = size.width / 2f
                val cy = size.height / 2f
                val path = Path().apply { addOval(Rect(cx - radius, cy - radius, cx + radius, cy + radius)) }
                clipPath(path) { contentScope.drawContent() }
            }

            "plus" -> {
                val bandW = size.width * 0.5f * p
                val bandH = size.height * 0.5f * p
                val path = Path().apply {
                    addRect(Rect(size.width / 2f - bandW, 0f, size.width / 2f + bandW, size.height))
                    addRect(Rect(0f, size.height / 2f - bandH, size.width, size.height / 2f + bandH))
                }
                clipPath(path) { contentScope.drawContent() }
            }

            "wheel", "wedge" -> {
                val spokes = if (type == "wheel") (spec.spokes ?: 1).coerceIn(1, 8) else 1
                val cx = size.width / 2f
                val cy = size.height / 2f
                val radius = hypot(size.width.toDouble(), size.height.toDouble()).toFloat()
                val circle = Rect(cx - radius, cy - radius, cx + radius, cy + radius)
                val sector = 360f / spokes
                val path = Path()
                repeat(spokes) { i ->
                    val sweep = sector * p
                    val start = -90f + i * sector
                    path.moveTo(cx, cy)
                    path.arcTo(circle, start, sweep, false)
                    path.close()
                }
                clipPath(path) { contentScope.drawContent() }
            }

            else -> drawContent()
        }
    }
}

@Composable
private fun PowerPointRenderedSlide(
    localPath: String,
    deck: PowerPointDeckModel,
    slide: PowerPointSlideModel,
    inverted: Boolean,
    renderWidth: Int,
    matched: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    val stableRenderWidth = if (renderWidth >= 2200) 2200 else 1600
    val cacheKey = remember(localPath, slide, inverted, stableRenderWidth) {
        "ppt|$localPath|${slide.hashCode()}|$inverted|$stableRenderWidth"
    }
    var bitmap by remember(cacheKey) { mutableStateOf(ViewerBitmapCache.get(cacheKey)) }

    LaunchedEffect(localPath, slide, inverted, stableRenderWidth) {
        ViewerBitmapCache.get(cacheKey)?.let {
            bitmap = it
            return@LaunchedEffect
        }
        runCatching {
            runInterruptible(Dispatchers.IO) {
                renderPowerPointSlideBitmap(File(localPath), deck, slide, stableRenderWidth, inverted)
            }
        }.onSuccess { fresh ->
            bitmap = ViewerBitmapCache.put(cacheKey, fresh)
        }.onFailure { error ->
            onMessage(error.message ?: "No se pudo renderizar una diapositiva.")
        }
    }

    Box(
        modifier = modifier
            .background(if (inverted) Color.Black else Color.White)
            .then(if (matched) Modifier.border(2.dp, NeonGreen) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        val current = bitmap
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private fun renderPowerPointSlideBitmap(
    file: File,
    deck: PowerPointDeckModel,
    slide: PowerPointSlideModel,
    requestedWidth: Int,
    inverted: Boolean
): Bitmap {
    val width = requestedWidth.coerceIn(700, 3200)
    val deckWidth = deck.widthEmu.coerceAtLeast(1L)
    val deckHeight = deck.heightEmu.coerceAtLeast(1L)
    val height = (width.toDouble() * deckHeight.toDouble() / deckWidth.toDouble())
        .roundToInt()
        .coerceAtLeast(1)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    val rawBackground = slide.backgroundArgb ?: 0xFFFFFFFF.toInt()
    val background = if (inverted) invertArgb(rawBackground) else rawBackground
    canvas.drawColor(background)

    val scaleX = width.toFloat() / deckWidth.toFloat()
    val scaleY = height.toFloat() / deckHeight.toFloat()
    val imagePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG).apply {
        if (inverted) colorFilter = android.graphics.ColorMatrixColorFilter(
            android.graphics.ColorMatrix(
                floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }

    java.util.zip.ZipFile(file).use { zip ->
        slide.elements.forEach { element ->
            if (Thread.currentThread().isInterrupted) throw InterruptedException("Render cancelado")
            val left = element.x * scaleX
            val top = element.y * scaleY
            val right = (element.x + element.width) * scaleX
            val bottom = (element.y + element.height) * scaleY
            val rect = android.graphics.RectF(left, top, right, bottom)
            if (rect.width() <= 0f || rect.height() <= 0f) return@forEach

            when (element) {
                is PowerPointElementModel.Rectangle -> {
                    val fill = if (inverted) invertArgb(element.fillArgb) else element.fillArgb
                    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = fill
                        style = android.graphics.Paint.Style.FILL
                    }
                    canvas.drawRect(rect, paint)
                }
                is PowerPointElementModel.Picture -> {
                    val image = runCatching { decodeOfficeZipBitmap(zip, element.entryName) }.getOrNull()
                    if (image != null) {
                        canvas.drawBitmap(image, null, rect, imagePaint)
                        if (!image.isRecycled) image.recycle()
                    }
                }
                is PowerPointElementModel.TextBox -> {
                    val baseColor = element.textArgb ?: if (pptIsDark(rawBackground)) 0xFFFFFFFF.toInt() else 0xFF171717.toInt()
                    val textColor = if (inverted) invertArgb(baseColor) else baseColor
                    val textPaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = textColor
                        val pointSize = element.fontSizePt ?: if (element.height > deckHeight / 7) 24f else 16f
                        textSize = (pointSize * 12700f * scaleY).coerceIn(width * 0.012f, width * 0.12f)
                        typeface = android.graphics.Typeface.create(
                            android.graphics.Typeface.SANS_SERIF,
                            if (element.bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL
                        )
                    }
                    val padding = (width * 0.004f).coerceAtLeast(2f)
                    val textWidth = (rect.width() - padding * 2f).roundToInt().coerceAtLeast(1)
                    val layout = buildStaticLayout(element.text, textPaint, textWidth, maxLines = 30)
                    canvas.save()
                    canvas.clipRect(rect)
                    canvas.translate(rect.left + padding, rect.top + padding)
                    layout.draw(canvas)
                    canvas.restore()
                }
            }
        }
    }
    return bitmap
}

@Composable
private fun PowerPointSlideCanvas(
    localPath: String,
    deck: PowerPointDeckModel,
    slide: PowerPointSlideModel,
    inverted: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    val rawBackground = slide.backgroundArgb ?: 0xFFFFFFFF.toInt()
    val background = Color(if (inverted) invertArgb(rawBackground) else rawBackground)
    val defaultForeground = if (pptIsDark(rawBackground) xor inverted) Color.White else Color(0xFF171717)
    BoxWithConstraints(
        modifier = modifier.clip(RoundedCornerShape(3.dp)).background(background)
    ) {
        val displayScale = (maxWidth.value / 360f).coerceIn(0.55f, 4f)
        slide.elements.forEach { element ->
            val left = maxWidth * (element.x.toFloat() / deck.widthEmu.toFloat().coerceAtLeast(1f))
            val top = maxHeight * (element.y.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f))
            val width = maxWidth * (element.width.toFloat() / deck.widthEmu.toFloat().coerceAtLeast(1f))
            val height = maxHeight * (element.height.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f))
            when (element) {
                is PowerPointElementModel.TextBox -> {
                    val rawText = element.textArgb
                    val textColor = if (rawText != null) Color(if (inverted) invertArgb(rawText) else rawText) else defaultForeground
                    val baseFontSp = element.fontSizePt?.times(0.52f)
                        ?: if (element.height > deck.heightEmu / 7) 17f else 11.5f
                    val fontSp = (baseFontSp * displayScale).coerceIn(5.5f, 64f)
                    Text(
                        element.text,
                        color = textColor,
                        modifier = Modifier.offset(left, top).width(width).height(height).padding(1.dp * displayScale),
                        fontSize = fontSp.sp,
                        lineHeight = (fontSp * 1.08f).sp,
                        fontWeight = if (element.bold) FontWeight.Bold else FontWeight.Normal,
                        overflow = TextOverflow.Ellipsis,
                        maxLines = 24
                    )
                }
                is PowerPointElementModel.Rectangle -> {
                    val rawFill = element.fillArgb
                    Box(
                        Modifier.offset(left, top).width(width).height(height)
                            .background(Color(if (inverted) invertArgb(rawFill) else rawFill))
                    )
                }
                is PowerPointElementModel.Picture -> OfficeZipImage(
                    localPath = localPath,
                    entryName = element.entryName,
                    inverted = inverted,
                    modifier = Modifier.offset(left, top).width(width).height(height),
                    onMessage = onMessage
                )
            }
        }
    }
}

@Composable
private fun OfficeZipImage(
    localPath: String,
    entryName: String,
    inverted: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    var bitmap by remember(localPath, entryName) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(localPath, entryName) {
        runCatching {
            withContext(Dispatchers.IO) {
                java.util.zip.ZipFile(File(localPath)).use { zip ->
                    decodeOfficeZipBitmap(zip, entryName)
                }
            }
        }.onSuccess { fresh ->
            val old = bitmap
            bitmap = fresh
            old?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure { onMessage(it.message ?: "No se pudo mostrar una imagen del documento.") }
    }
    DisposableEffect(localPath, entryName) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }
    val current = bitmap
    if (current != null) {
        Image(
            bitmap = current.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = modifier,
            colorFilter = if (inverted) officeInvertColorFilter() else null
        )
    } else {
        Box(modifier.background(if (inverted) Color(0xFF1E1E1E) else Color(0xFFF1F1F1)), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = NeonGreen, strokeWidth = 2.dp)
        }
    }
}


private fun decodeOfficeZipBitmap(zip: java.util.zip.ZipFile, entryName: String): Bitmap {
    val entry = zip.getEntry(entryName) ?: error("Imagen no encontrada")
    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    zip.getInputStream(entry).use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    val largest = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
    while (largest / sample > 2200) sample *= 2
    val options = android.graphics.BitmapFactory.Options().apply {
        inSampleSize = sample.coerceAtLeast(1)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return zip.getInputStream(entry).use { input ->
        android.graphics.BitmapFactory.decodeStream(input, null, options)
    } ?: error("Imagen no compatible")
}

private fun officeInvertColorFilter(): androidx.compose.ui.graphics.ColorFilter =
    androidx.compose.ui.graphics.ColorFilter.colorMatrix(
        androidx.compose.ui.graphics.ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

private fun shareDocumentFile(context: android.content.Context, uri: Uri, mime: String) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = mime
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { context.startActivity(android.content.Intent.createChooser(intent, "Compartir archivo")) }
}

private suspend fun copyOfficeToViewerCache(
    context: android.content.Context,
    source: Uri,
    type: OfficeViewerType
): File = withContext(Dispatchers.IO) {
    val directory = File(context.cacheDir, "office_viewer").apply { mkdirs() }
    directory.listFiles()?.forEach { old ->
        if (System.currentTimeMillis() - old.lastModified() > 6 * 60 * 60 * 1000L) runCatching { old.delete() }
    }
    val extension = type.extensions.lowercase()
    val file = File(directory, "viewer_${System.currentTimeMillis()}_${kotlin.random.Random.nextInt(1000, 9999)}.$extension")
    try {
        runInterruptible {
            val cancellationSignal = CancellationSignal()
            val copiedFromDescriptor = runCatching {
                context.contentResolver.openFileDescriptor(source, "r", cancellationSignal)?.use { descriptor ->
                    FileInputStream(descriptor.fileDescriptor).use { input ->
                        FileOutputStream(file).use { output ->
                            val buffer = ByteArray(256 * 1024)
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                            }
                            output.fd.sync()
                        }
                    }
                    true
                } ?: false
            }.getOrDefault(false)

            if (!copiedFromDescriptor || file.length() <= 0L) {
                runCatching { file.delete() }
                val copiedFromStream = context.contentResolver.openInputStream(source)?.use { input ->
                    FileOutputStream(file).use { output ->
                        val buffer = ByteArray(256 * 1024)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            output.write(buffer, 0, count)
                        }
                        output.fd.sync()
                    }
                    true
                } ?: false
                require(copiedFromStream) { "No se pudo leer el archivo seleccionado." }
            }
        }
        require(file.length() > 0) { "El archivo está vacío." }
        java.util.zip.ZipFile(file).use { require(it.entries().hasMoreElements()) { "El archivo no tiene contenido OOXML válido." } }
        file
    } catch (error: Throwable) {
        runCatching { file.delete() }
        throw error
    }
}

private fun parseDocxModel(file: File): WordDocumentModel {
    java.util.zip.ZipFile(file).use { zip ->
        val documentEntry = zip.getEntry("word/document.xml") ?: error("El DOCX no contiene document.xml.")
        val relationships = parseZipRelationships(zip, "word/_rels/document.xml.rels", "word/document.xml")
        val rawPages = mutableListOf<MutableList<WordBlockModel>>(mutableListOf())
        var paragraphText = StringBuilder()
        var paragraphImages = mutableListOf<String>()
        var inParagraph = false
        var pageBreak = false
        var explicitBreakSeen = false
        var tableDepth = -1
        var rowDepth = -1
        var cellDepth = -1
        var tableRows = mutableListOf<MutableList<String>>()
        var currentRow = mutableListOf<String>()
        var currentCell = StringBuilder()

        val parser = Xml.newPullParser()
        zip.getInputStream(documentEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "tbl" -> if (tableDepth < 0) {
                            tableDepth = parser.depth
                            tableRows = mutableListOf()
                        }
                        "tr" -> if (tableDepth > 0 && rowDepth < 0) {
                            rowDepth = parser.depth
                            currentRow = mutableListOf()
                        }
                        "tc" -> if (tableDepth > 0 && cellDepth < 0) {
                            cellDepth = parser.depth
                            currentCell = StringBuilder()
                        }
                        "p" -> {
                            inParagraph = true
                            paragraphText = StringBuilder()
                            paragraphImages = mutableListOf()
                            pageBreak = false
                        }
                        "t" -> if (inParagraph) paragraphText.append(parser.nextText())
                        "tab" -> if (inParagraph) paragraphText.append('\t')
                        "br" -> if (inParagraph) {
                            val type = attributeByLocalName(parser, "type")
                            if (type == "page") { pageBreak = true; explicitBreakSeen = true } else paragraphText.append('\n')
                        }
                        "lastRenderedPageBreak" -> if (inParagraph) { pageBreak = true; explicitBreakSeen = true }
                        "blip" -> if (inParagraph) {
                            val relId = attributeByLocalName(parser, "embed")
                            relId?.let { relationships[it] }?.let(paragraphImages::add)
                        }
                    }
                    XmlPullParser.END_TAG -> when {
                        parser.name == "p" && inParagraph -> {
                            val text = paragraphText.toString().trim()
                            if (tableDepth > 0 && cellDepth > 0) {
                                if (text.isNotBlank()) {
                                    if (currentCell.isNotEmpty()) currentCell.append('\n')
                                    currentCell.append(text)
                                }
                            } else {
                                if (text.isNotBlank()) rawPages.last().add(WordBlockModel.Paragraph(text))
                                paragraphImages.distinct().forEach { rawPages.last().add(WordBlockModel.Picture(it)) }
                                if (pageBreak && rawPages.last().isNotEmpty()) rawPages.add(mutableListOf())
                            }
                            inParagraph = false
                        }
                        parser.name == "tc" && cellDepth > 0 && parser.depth == cellDepth -> {
                            currentRow += currentCell.toString().trim()
                            currentCell = StringBuilder()
                            cellDepth = -1
                        }
                        parser.name == "tr" && rowDepth > 0 && parser.depth == rowDepth -> {
                            tableRows += currentRow
                            currentRow = mutableListOf()
                            rowDepth = -1
                        }
                        parser.name == "tbl" && tableDepth > 0 && parser.depth == tableDepth -> {
                            if (tableRows.isNotEmpty()) rawPages.last().add(WordBlockModel.Table(tableRows.map { it.toList() }))
                            tableRows = mutableListOf()
                            tableDepth = -1
                        }
                    }
                }
                event = parser.next()
            }
        }
        if (rawPages.lastOrNull()?.isEmpty() == true && rawPages.size > 1) rawPages.removeAt(rawPages.lastIndex)
        val pages = if (explicitBreakSeen) {
            rawPages.filter { it.isNotEmpty() }.map { WordPageModel(it.toList()) }
        } else repaginateWord(rawPages)
        require(pages.isNotEmpty()) { "El DOCX no contiene contenido visible." }
        return WordDocumentModel(pages)
    }
}

private fun repaginateWord(rawPages: List<List<WordBlockModel>>): List<WordPageModel> {
    val result = mutableListOf<WordPageModel>()
    rawPages.forEach { raw ->
        var current = mutableListOf<WordBlockModel>()
        var cost = 0
        fun flush() {
            if (current.isNotEmpty()) {
                result += WordPageModel(current)
                current = mutableListOf()
                cost = 0
            }
        }
        raw.forEach { block ->
            val blockCost = when (block) {
                is WordBlockModel.Paragraph -> 1 + block.text.length / 95
                is WordBlockModel.Picture -> 7
                is WordBlockModel.Table -> 3 + block.rows.size * 2
            }
            if (cost + blockCost > 28 && current.isNotEmpty()) flush()
            current += block
            cost += blockCost
        }
        flush()
    }
    return result
}

private fun parseXlsxWorkbook(file: File): ExcelWorkbookModel {
    java.util.zip.ZipFile(file).use { zip ->
        val shared = zip.getEntry("xl/sharedStrings.xml")?.let { entry ->
            zip.getInputStream(entry).use(::parseSharedStringsStream)
        }.orEmpty()
        val themeColors = zip.getEntry("xl/theme/theme1.xml")?.let { entry ->
            zip.getInputStream(entry).use(::parseOfficeThemeColorsStream)
        }.orEmpty()
        val styles = zip.getEntry("xl/styles.xml")?.let { entry ->
            zip.getInputStream(entry).use { parseExcelStylesStream(it, themeColors) }
        }.orEmpty().ifEmpty { listOf(ExcelCellStyleModel()) }
        val relationships = parseZipRelationships(zip, "xl/_rels/workbook.xml.rels", "xl/workbook.xml")
        val workbookEntry = zip.getEntry("xl/workbook.xml") ?: error("El XLSX no contiene workbook.xml.")
        val sheets = mutableListOf<ExcelSheetRef>()
        val parser = Xml.newPullParser()
        zip.getInputStream(workbookEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name == "sheet") {
                    val name = parser.getAttributeValue(null, "name").orEmpty().ifBlank { "Hoja ${sheets.size + 1}" }
                    val relId = relationshipIdAttribute(parser)
                    val target = relId?.let { relationships[it] }
                    if (!target.isNullOrBlank()) sheets += ExcelSheetRef(name, target)
                }
                event = parser.next()
            }
        }
        require(sheets.isNotEmpty()) { "El XLSX no contiene hojas legibles." }
        return ExcelWorkbookModel(shared, sheets, styles)
    }
}

private suspend fun parseXlsxSheet(
    file: File,
    ref: ExcelSheetRef,
    shared: List<String>,
    styles: List<ExcelCellStyleModel>,
    rowLimit: Int? = null
): ExcelSheetData {
    java.util.zip.ZipFile(file).use { zip ->
        val entry = zip.getEntry(ref.entryName) ?: error("No se encontró la hoja ${ref.name}.")
        val rows = linkedMapOf<Int, ExcelRowData>()
        val columnWidths = mutableMapOf<Int, Float>()
        var rowNumber = 0
        var rowHeightPoints: Float? = null
        var cells = linkedMapOf<Int, ExcelCellData>()
        var cellRef = ""
        var cellType: String? = null
        var cellStyleIndex = 0
        var value = StringBuilder()
        var inline = StringBuilder()
        var formula = StringBuilder()
        var captureValue = false
        var captureInline = false
        var captureFormula = false
        var maxColumn = 0
        var maxRow = 1
        var declaredMaxColumn = 0
        var declaredMaxRow = 0
        var stoppedEarly = false
        val parser = Xml.newPullParser()
        zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            var eventCounter = 0
            while (event != XmlPullParser.END_DOCUMENT) {
                if (++eventCounter % 256 == 0) currentCoroutineContext().ensureActive()
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "dimension" -> {
                            val range = parser.getAttributeValue(null, "ref").orEmpty()
                            val lastCell = range.substringAfterLast(':', range)
                            declaredMaxColumn = maxOf(declaredMaxColumn, excelColumnIndex(lastCell) + 1)
                            declaredMaxRow = maxOf(
                                declaredMaxRow,
                                lastCell.filter { it.isDigit() }.toIntOrNull() ?: 0
                            )
                        }
                        "col" -> {
                            val minCol = parser.getAttributeValue(null, "min")?.toIntOrNull()?.minus(1) ?: -1
                            val maxCol = parser.getAttributeValue(null, "max")?.toIntOrNull()?.minus(1) ?: minCol
                            val width = parser.getAttributeValue(null, "width")?.toFloatOrNull()
                            if (minCol >= 0 && maxCol >= minCol && width != null) {
                                for (col in minCol..maxCol.coerceAtMost(255)) columnWidths[col] = width
                                maxColumn = maxOf(maxColumn, maxCol + 1)
                            }
                        }
                        "row" -> {
                            val nextRow = parser.getAttributeValue(null, "r")?.toIntOrNull()
                                ?: (rowNumber + 1).coerceAtLeast(1)
                            if (rowLimit != null && nextRow > rowLimit) {
                                stoppedEarly = true
                            } else {
                                rowNumber = nextRow
                                rowHeightPoints = parser.getAttributeValue(null, "ht")?.toFloatOrNull()
                                cells = linkedMapOf()
                                maxRow = maxOf(maxRow, rowNumber)
                            }
                        }
                        "c" -> {
                            cellRef = parser.getAttributeValue(null, "r").orEmpty()
                            cellType = parser.getAttributeValue(null, "t")
                            cellStyleIndex = parser.getAttributeValue(null, "s")?.toIntOrNull() ?: 0
                            value = StringBuilder()
                            inline = StringBuilder()
                            formula = StringBuilder()
                        }
                        "v" -> captureValue = true
                        "t" -> captureInline = true
                        "f" -> captureFormula = true
                    }
                    XmlPullParser.TEXT -> {
                        if (captureValue) value.append(parser.text.orEmpty())
                        if (captureInline) inline.append(parser.text.orEmpty())
                        if (captureFormula) formula.append(parser.text.orEmpty())
                    }
                    XmlPullParser.END_TAG -> when (parser.name) {
                        "v" -> captureValue = false
                        "t" -> captureInline = false
                        "f" -> captureFormula = false
                        "c" -> {
                            val col = excelColumnIndex(cellRef)
                            if (col >= 0) {
                                val raw = value.toString()
                                val style = styles.getOrNull(cellStyleIndex)
                                val shown = when (cellType) {
                                    "s" -> shared.getOrNull(raw.toIntOrNull() ?: -1).orEmpty()
                                    "inlineStr", "str" -> inline.toString().ifBlank { raw }
                                    "b" -> if (raw == "1") "VERDADERO" else if (raw == "0") "FALSO" else raw
                                    else -> {
                                        val base = raw.ifBlank {
                                            formula.toString().takeIf { it.isNotBlank() }?.let { "=$it" }.orEmpty()
                                        }
                                        if (raw.isNotBlank()) formatExcelNumericValue(raw, style?.numberFormatCode) else base
                                    }
                                }
                                if (shown.isNotBlank() || cellStyleIndex != 0) {
                                    cells[col] = ExcelCellData(shown, cellStyleIndex)
                                }
                                maxColumn = maxOf(maxColumn, col + 1)
                            }
                        }
                        "row" -> if (rowNumber > 0) {
                            rows[rowNumber] = ExcelRowData(rowNumber, cells.toMap(), rowHeightPoints)
                        }
                    }
                }
                if (stoppedEarly) break
                event = parser.next()
            }
        }
        val totalHint = maxOf(declaredMaxRow, maxRow)
        val visibleRows = maxOf(60, totalHint, maxRow).coerceAtMost(200_000)
        return ExcelSheetData(
            rows = rows,
            maxColumns = maxOf(maxColumn, declaredMaxColumn).coerceAtLeast(1).coerceAtMost(256),
            maxRows = visibleRows,
            columnWidths = columnWidths.toMap(),
            totalRowsHint = totalHint.coerceAtLeast(visibleRows),
            isComplete = !stoppedEarly
        )
    }
}

private fun parseExcelStylesStream(
    input: java.io.InputStream,
    themeColors: Map<Int, Int>
): List<ExcelCellStyleModel> {
    data class FontStyle(val color: Int?, val bold: Boolean, val sizePt: Float?)
    val fonts = mutableListOf<FontStyle>()
    val fills = mutableListOf<Int?>()
    val styles = mutableListOf<ExcelCellStyleModel>()
    val customNumFormats = mutableMapOf<Int, String>()
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    var fontsDepth = -1
    var fillsDepth = -1
    var cellXfsDepth = -1
    var fontDepth = -1
    var fillDepth = -1
    var xfDepth = -1
    var fontColor: Int? = null
    var fontBold = false
    var fontSizePt: Float? = null
    var fillColor: Int? = null
    var fillPattern: String? = null
    var xfFontId = 0
    var xfFillId = 0
    var xfNumFmtId = 0
    var xfHorizontal: String? = null
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> when (parser.name) {
                "numFmt" -> {
                    val id = parser.getAttributeValue(null, "numFmtId")?.toIntOrNull()
                    val code = parser.getAttributeValue(null, "formatCode")
                    if (id != null && !code.isNullOrBlank()) customNumFormats[id] = code
                }
                "fonts" -> fontsDepth = parser.depth
                "fills" -> fillsDepth = parser.depth
                "cellXfs" -> cellXfsDepth = parser.depth
                "font" -> if (fontsDepth > 0 && parser.depth == fontsDepth + 1) {
                    fontDepth = parser.depth
                    fontColor = null
                    fontBold = false
                    fontSizePt = null
                }
                "b" -> if (fontDepth > 0) fontBold = true
                "sz" -> if (fontDepth > 0) {
                    fontSizePt = parser.getAttributeValue(null, "val")?.toFloatOrNull() ?: fontSizePt
                }
                "color" -> if (fontDepth > 0) {
                    fontColor = parseExcelStyleColor(parser, themeColors) ?: fontColor
                }
                "fill" -> if (fillsDepth > 0 && parser.depth == fillsDepth + 1) {
                    fillDepth = parser.depth
                    fillColor = null
                    fillPattern = null
                }
                "patternFill" -> if (fillDepth > 0) {
                    fillPattern = parser.getAttributeValue(null, "patternType")
                }
                "fgColor" -> if (fillDepth > 0) {
                    fillColor = parseExcelStyleColor(parser, themeColors) ?: fillColor
                }
                "xf" -> if (cellXfsDepth > 0 && parser.depth == cellXfsDepth + 1) {
                    xfDepth = parser.depth
                    xfFontId = parser.getAttributeValue(null, "fontId")?.toIntOrNull() ?: 0
                    xfFillId = parser.getAttributeValue(null, "fillId")?.toIntOrNull() ?: 0
                    xfNumFmtId = parser.getAttributeValue(null, "numFmtId")?.toIntOrNull() ?: 0
                    xfHorizontal = null
                }
                "alignment" -> if (xfDepth > 0) {
                    xfHorizontal = parser.getAttributeValue(null, "horizontal") ?: xfHorizontal
                }
            }
            XmlPullParser.END_TAG -> when {
                parser.name == "font" && parser.depth == fontDepth -> {
                    fonts += FontStyle(fontColor, fontBold, fontSizePt)
                    fontDepth = -1
                }
                parser.name == "fill" && parser.depth == fillDepth -> {
                    fills += fillColor.takeIf { fillPattern == "solid" }
                    fillDepth = -1
                }
                parser.name == "xf" && parser.depth == xfDepth -> {
                    val font = fonts.getOrNull(xfFontId)
                    styles += ExcelCellStyleModel(
                        fillArgb = fills.getOrNull(xfFillId),
                        textArgb = font?.color,
                        bold = font?.bold == true,
                        fontSizePt = font?.sizePt,
                        horizontal = xfHorizontal,
                        numberFormatCode = customNumFormats[xfNumFmtId] ?: builtInExcelNumberFormat(xfNumFmtId)
                    )
                    xfDepth = -1
                }
                parser.name == "fonts" && parser.depth == fontsDepth -> fontsDepth = -1
                parser.name == "fills" && parser.depth == fillsDepth -> fillsDepth = -1
                parser.name == "cellXfs" && parser.depth == cellXfsDepth -> cellXfsDepth = -1
            }
        }
        event = parser.next()
    }
    return styles.ifEmpty { listOf(ExcelCellStyleModel()) }
}

private fun parseOfficeThemeColorsStream(input: java.io.InputStream): Map<Int, Int> {
    // Orden de índices de tema definido por OOXML/Excel.
    val themeIndex = mapOf(
        "lt1" to 0, "dk1" to 1, "lt2" to 2, "dk2" to 3,
        "accent1" to 4, "accent2" to 5, "accent3" to 6,
        "accent4" to 7, "accent5" to 8, "accent6" to 9,
        "hlink" to 10, "folHlink" to 11
    )
    val colors = mutableMapOf<Int, Int>()
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    var currentIndex: Int? = null
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> {
                themeIndex[parser.name]?.let { currentIndex = it }
                if (parser.name == "srgbClr" || parser.name == "sysClr") {
                    val value = if (parser.name == "sysClr") {
                        parser.getAttributeValue(null, "lastClr") ?: parser.getAttributeValue(null, "val")
                    } else parser.getAttributeValue(null, "val")
                    val color = parseExcelArgb(value)
                    val index = currentIndex
                    if (color != null && index != null) colors[index] = color
                }
            }
            XmlPullParser.END_TAG -> if (themeIndex.containsKey(parser.name)) currentIndex = null
        }
        event = parser.next()
    }
    return colors
}

private fun parseExcelStyleColor(parser: XmlPullParser, themeColors: Map<Int, Int>): Int? {
    val direct = parseExcelArgb(parser.getAttributeValue(null, "rgb"))
    val themed = parser.getAttributeValue(null, "theme")?.toIntOrNull()?.let(themeColors::get)
    val indexed = parser.getAttributeValue(null, "indexed")?.toIntOrNull()?.let(::excelIndexedColor)
    val base = direct ?: themed ?: indexed ?: return null
    val tint = parser.getAttributeValue(null, "tint")?.toFloatOrNull() ?: 0f
    return applyExcelTint(base, tint)
}

private fun applyExcelTint(argb: Int, tint: Float): Int {
    if (tint == 0f) return argb
    fun tintChannel(value: Int): Int {
        val result = if (tint < 0f) value * (1f + tint) else value * (1f - tint) + 255f * tint
        return result.roundToInt().coerceIn(0, 255)
    }
    val a = (argb ushr 24) and 0xFF
    val r = tintChannel((argb ushr 16) and 0xFF)
    val g = tintChannel((argb ushr 8) and 0xFF)
    val b = tintChannel(argb and 0xFF)
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}

private fun excelIndexedColor(index: Int): Int? {
    val palette = intArrayOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt(), 0xFF00FF00.toInt(),
        0xFF0000FF.toInt(), 0xFFFFFF00.toInt(), 0xFFFF00FF.toInt(), 0xFF00FFFF.toInt(),
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt(), 0xFF00FF00.toInt(),
        0xFF0000FF.toInt(), 0xFFFFFF00.toInt(), 0xFFFF00FF.toInt(), 0xFF00FFFF.toInt(),
        0xFF800000.toInt(), 0xFF008000.toInt(), 0xFF000080.toInt(), 0xFF808000.toInt(),
        0xFF800080.toInt(), 0xFF008080.toInt(), 0xFFC0C0C0.toInt(), 0xFF808080.toInt(),
        0xFF9999FF.toInt(), 0xFF993366.toInt(), 0xFFFFFFCC.toInt(), 0xFFCCFFFF.toInt(),
        0xFF660066.toInt(), 0xFFFF8080.toInt(), 0xFF0066CC.toInt(), 0xFFCCCCFF.toInt(),
        0xFF000080.toInt(), 0xFFFF00FF.toInt(), 0xFFFFFF00.toInt(), 0xFF00FFFF.toInt(),
        0xFF800080.toInt(), 0xFF800000.toInt(), 0xFF008080.toInt(), 0xFF0000FF.toInt(),
        0xFF00CCFF.toInt(), 0xFFCCFFFF.toInt(), 0xFFCCFFCC.toInt(), 0xFFFFFF99.toInt(),
        0xFF99CCFF.toInt(), 0xFFFF99CC.toInt(), 0xFFCC99FF.toInt(), 0xFFFFCC99.toInt(),
        0xFF3366FF.toInt(), 0xFF33CCCC.toInt(), 0xFF99CC00.toInt(), 0xFFFFCC00.toInt(),
        0xFFFF9900.toInt(), 0xFFFF6600.toInt(), 0xFF666699.toInt(), 0xFF969696.toInt(),
        0xFF003366.toInt(), 0xFF339966.toInt(), 0xFF003300.toInt(), 0xFF333300.toInt(),
        0xFF993300.toInt(), 0xFF993366.toInt(), 0xFF333399.toInt(), 0xFF333333.toInt()
    )
    return palette.getOrNull(index)
}

private fun builtInExcelNumberFormat(id: Int): String? = when (id) {
    1 -> "0"
    2 -> "0.00"
    3 -> "#,##0"
    4 -> "#,##0.00"
    9 -> "0%"
    10 -> "0.00%"
    14 -> "mm-dd-yy"
    15 -> "d-mmm-yy"
    16 -> "d-mmm"
    17 -> "mmm-yy"
    18 -> "h:mm AM/PM"
    19 -> "h:mm:ss AM/PM"
    20 -> "h:mm"
    21 -> "h:mm:ss"
    22 -> "m/d/yy h:mm"
    else -> null
}

private fun formatExcelNumericValue(raw: String, formatCode: String?): String {
    val value = raw.toDoubleOrNull() ?: return raw
    val code = formatCode?.lowercase().orEmpty()
    if (code.isBlank()) return raw

    if ('%' in code) {
        val decimalPart = code.substringAfter('.', "").takeWhile { it == '0' || it == '#' }
        val decimals = decimalPart.count { it == '0' }.coerceIn(0, 6)
        return java.lang.String.format(java.util.Locale.US, "%.${decimals}f%%", value * 100.0)
    }

    if ((code.contains('y') || code.contains('d')) && (code.contains('m') || code.contains('y'))) {
        return runCatching {
            val wholeDays = kotlin.math.floor(value).toLong()
            val date = java.time.LocalDate.of(1899, 12, 30).plusDays(wholeDays)
            when {
                code.startsWith("yyyy-mm-dd") -> date.toString()
                code.contains("dd/mm/yyyy") -> "%02d/%02d/%04d".format(date.dayOfMonth, date.monthValue, date.year)
                else -> "%02d/%02d/%04d".format(date.dayOfMonth, date.monthValue, date.year)
            }
        }.getOrElse { raw }
    }

    val dot = code.indexOf('.')
    if (dot >= 0) {
        val decimals = code.substring(dot + 1).takeWhile { it == '0' || it == '#' }.count { it == '0' }.coerceIn(0, 8)
        if (decimals > 0) return java.lang.String.format(java.util.Locale.US, "%.${decimals}f", value)
    }
    if (code == "0" || code.contains("#,##0")) {
        return if (value % 1.0 == 0.0) value.toLong().toString() else raw
    }
    return raw
}

private fun parseExcelArgb(value: String?): Int? {
    val clean = value?.trim()?.removePrefix("#") ?: return null
    val raw = clean.toLongOrNull(16) ?: return null
    return when (clean.length) {
        6 -> (0xFF000000L or raw).toInt()
        8 -> {
            val argb = raw.toInt()
            // Excel/OpenPyXL suele escribir 00RRGGBB aunque el color sea opaco.
            if (((argb ushr 24) and 0xFF) == 0) (argb or 0xFF000000.toInt()) else argb
        }
        else -> null
    }
}

private fun parsePptxDeck(file: File): PowerPointDeckModel {
    java.util.zip.ZipFile(file).use { zip ->
        val presentationEntry = zip.getEntry("ppt/presentation.xml") ?: error("El PPTX no contiene presentation.xml.")
        var width = 12192000L
        var height = 6858000L
        val slideRelIds = mutableListOf<String>()
        val parser = Xml.newPullParser()
        zip.getInputStream(presentationEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    when (parser.name) {
                        "sldSz" -> {
                            width = parser.getAttributeValue(null, "cx")?.toLongOrNull() ?: width
                            height = parser.getAttributeValue(null, "cy")?.toLongOrNull() ?: height
                        }
                        "sldId" -> relationshipIdAttribute(parser)?.let(slideRelIds::add)
                    }
                }
                event = parser.next()
            }
        }
        val presentationRels = parseZipRelationships(zip, "ppt/_rels/presentation.xml.rels", "ppt/presentation.xml")
        val orderedSlides = slideRelIds.mapNotNull { presentationRels[it] }.ifEmpty {
            zip.entries().asSequence().map { it.name }
                .filter { it.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
                .sortedBy { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
                .toList()
        }
        val slides = orderedSlides.mapIndexed { index, slideEntry ->
            parsePowerPointSlide(zip, slideEntry, width, height, index)
        }
        require(slides.isNotEmpty()) { "El PPTX no contiene diapositivas legibles." }
        return PowerPointDeckModel(width, height, slides)
    }
}

private fun parsePowerPointSlide(
    zip: java.util.zip.ZipFile,
    slideEntry: String,
    deckWidth: Long,
    deckHeight: Long,
    slideIndex: Int
): PowerPointSlideModel {
    val entry = zip.getEntry(slideEntry) ?: error("Diapositiva no encontrada.")
    val fileName = slideEntry.substringAfterLast('/')
    val relEntry = slideEntry.substringBeforeLast('/') + "/_rels/$fileName.rels"
    val rels = parseZipRelationships(zip, relEntry, slideEntry)
    val elements = mutableListOf<PowerPointElementModel>()
    var shapeKind: String? = null
    var shapeDepth = -1
    var text = StringBuilder()
    var relId: String? = null
    var x = 0L; var y = 0L; var w = 0L; var h = 0L
    var shapeFillArgb: Int? = null
    var textArgb: Int? = null
    var textFontSizePt: Float? = null
    var textBold = false
    var spPrDepth = -1
    var rPrDepth = -1
    var solidFillDepth = -1
    var lineDepth = -1
    var transitionType: String? = null
    var transitionDirection: String? = null
    var transitionOrientation: String? = null
    var transitionDurationMs = 360
    var transitionSpokes: Int? = null
    var advanceAfterMs: Long? = null
    var transitionDepth = -1
    var backgroundArgb: Int? = null
    var bgDepth = -1
    var bgSolidFillDepth = -1

    val parser = Xml.newPullParser()
    zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    if (parser.name == "bg" && shapeKind == null) bgDepth = parser.depth
                    if (bgDepth > 0 && parser.name == "solidFill") bgSolidFillDepth = parser.depth
                    if (bgSolidFillDepth > 0 && parser.name == "srgbClr" && backgroundArgb == null) {
                        backgroundArgb = parseRgbArgb(parser.getAttributeValue(null, "val"))
                    }

                    if ((parser.name == "sp" || parser.name == "pic") && shapeKind == null) {
                        shapeKind = parser.name
                        shapeDepth = parser.depth
                        text = StringBuilder(); relId = null; x = 0; y = 0; w = 0; h = 0
                        shapeFillArgb = null; textArgb = null; textFontSizePt = null; textBold = false
                        spPrDepth = -1; rPrDepth = -1; solidFillDepth = -1; lineDepth = -1
                    } else if (parser.name == "transition" && shapeKind == null) {
                        transitionDepth = parser.depth
                        advanceAfterMs = parser.getAttributeValue(null, "advTm")?.toLongOrNull()
                        transitionDurationMs = when (parser.getAttributeValue(null, "spd")?.lowercase()) {
                            "slow" -> 700
                            "fast" -> 240
                            else -> 380
                        }
                    } else if (transitionDepth > 0 && parser.depth == transitionDepth + 1 && transitionType == null) {
                        transitionType = parser.name
                        transitionDirection = parser.getAttributeValue(null, "dir")
                        transitionOrientation = parser.getAttributeValue(null, "orient")
                        transitionSpokes = parser.getAttributeValue(null, "spokes")?.toIntOrNull()
                    }

                    if (shapeKind != null) {
                        when (parser.name) {
                            "spPr" -> spPrDepth = parser.depth
                            "rPr", "defRPr", "endParaRPr" -> {
                                rPrDepth = parser.depth
                                parser.getAttributeValue(null, "sz")?.toFloatOrNull()?.let { size ->
                                    if (textFontSizePt == null) textFontSizePt = size / 100f
                                }
                                val boldValue = parser.getAttributeValue(null, "b")
                                if (boldValue == "1" || boldValue.equals("true", true)) textBold = true
                            }
                            "ln" -> if (spPrDepth > 0) lineDepth = parser.depth
                            "solidFill" -> solidFillDepth = parser.depth
                            "srgbClr" -> {
                                val color = parseRgbArgb(parser.getAttributeValue(null, "val"))
                                if (color != null) {
                                    if (rPrDepth > 0) textArgb = textArgb ?: color
                                    else if (spPrDepth > 0 && solidFillDepth > 0 && lineDepth < 0) shapeFillArgb = shapeFillArgb ?: color
                                }
                            }
                            "t" -> text.append(parser.nextText())
                            "p" -> if (text.isNotEmpty() && text.last() != '\n') text.append('\n')
                            "off" -> {
                                x = parser.getAttributeValue(null, "x")?.toLongOrNull() ?: x
                                y = parser.getAttributeValue(null, "y")?.toLongOrNull() ?: y
                            }
                            "ext" -> {
                                w = parser.getAttributeValue(null, "cx")?.toLongOrNull() ?: w
                                h = parser.getAttributeValue(null, "cy")?.toLongOrNull() ?: h
                            }
                            "blip" -> relId = attributeByLocalName(parser, "embed") ?: relId
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "solidFill" -> {
                            if (parser.depth == solidFillDepth) solidFillDepth = -1
                            if (parser.depth == bgSolidFillDepth) bgSolidFillDepth = -1
                        }
                        "spPr" -> if (parser.depth == spPrDepth) spPrDepth = -1
                        "ln" -> if (parser.depth == lineDepth) lineDepth = -1
                        "rPr", "defRPr", "endParaRPr" -> if (parser.depth == rPrDepth) rPrDepth = -1
                        "bg" -> if (parser.depth == bgDepth) bgDepth = -1
                    }
                    if (transitionDepth > 0 && parser.name == "transition" && parser.depth == transitionDepth) transitionDepth = -1
                    if (shapeKind != null && parser.depth == shapeDepth && parser.name == shapeKind) {
                        val fallbackIndex = elements.size
                        val finalX = if (w > 0) x else deckWidth / 12
                        val finalY = if (h > 0) y else deckHeight / 12 + fallbackIndex * (deckHeight / 7)
                        val finalW = if (w > 0) w else deckWidth * 5 / 6
                        val finalH = if (h > 0) h else deckHeight / 6
                        when (shapeKind) {
                            "sp" -> {
                                shapeFillArgb?.let { elements += PowerPointElementModel.Rectangle(it, finalX, finalY, finalW, finalH) }
                                text.toString().trim().takeIf { it.isNotBlank() }?.let {
                                    elements += PowerPointElementModel.TextBox(it, textArgb, textFontSizePt, textBold, finalX, finalY, finalW, finalH)
                                }
                            }
                            "pic" -> relId?.let { rels[it] }?.let {
                                elements += PowerPointElementModel.Picture(it, finalX, finalY, finalW, finalH)
                            }
                        }
                        shapeKind = null
                        shapeDepth = -1
                    }
                }
            }
            event = parser.next()
        }
    }
    if (elements.isEmpty()) {
        elements += PowerPointElementModel.TextBox(
            "Diapositiva ${slideIndex + 1}", null, 24f, true,
            deckWidth / 10, deckHeight / 3, deckWidth * 4 / 5, deckHeight / 4
        )
    }
    val transition = transitionType?.let {
        PowerPointTransitionModel(
            type = it,
            direction = transitionDirection,
            orientation = transitionOrientation,
            durationMs = transitionDurationMs,
            spokes = transitionSpokes
        )
    }
    return PowerPointSlideModel(elements, transition, advanceAfterMs, backgroundArgb)
}

private fun parseRgbArgb(value: String?): Int? {
    val clean = value?.trim()?.removePrefix("#") ?: return null
    if (clean.length != 6) return null
    val rgb = clean.toLongOrNull(16) ?: return null
    return (0xFF000000L or rgb).toInt()
}

private fun invertArgb(argb: Int): Int {
    val a = (argb ushr 24) and 0xFF
    val r = 255 - ((argb ushr 16) and 0xFF)
    val g = 255 - ((argb ushr 8) and 0xFF)
    val b = 255 - (argb and 0xFF)
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}

private fun pptIsDark(argb: Int): Boolean {
    val r = (argb ushr 16) and 0xFF
    val g = (argb ushr 8) and 0xFF
    val b = argb and 0xFF
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) < 145.0
}

private fun parseZipRelationships(
    zip: java.util.zip.ZipFile,
    relEntryName: String,
    sourceEntryName: String
): Map<String, String> {
    val entry = zip.getEntry(relEntryName) ?: return emptyMap()
    val result = linkedMapOf<String, String>()
    val parser = Xml.newPullParser()
    zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "Relationship") {
                val id = parser.getAttributeValue(null, "Id").orEmpty()
                val target = parser.getAttributeValue(null, "Target").orEmpty()
                val mode = parser.getAttributeValue(null, "TargetMode")
                if (id.isNotBlank() && target.isNotBlank() && !mode.equals("External", true)) {
                    result[id] = resolveZipTarget(sourceEntryName, target)
                }
            }
            event = parser.next()
        }
    }
    return result
}

private fun resolveZipTarget(sourceEntryName: String, target: String): String {
    if (target.startsWith('/')) return target.removePrefix("/")
    val base = sourceEntryName.substringBeforeLast('/', "")
    val combined = if (base.isBlank()) target else "$base/$target"
    val parts = mutableListOf<String>()
    combined.split('/').forEach { part ->
        when (part) {
            "", "." -> Unit
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
            else -> parts += part
        }
    }
    return parts.joinToString("/")
}

private fun attributeByLocalName(parser: XmlPullParser, localName: String): String? {
    for (index in 0 until parser.attributeCount) {
        if (parser.getAttributeName(index) == localName) return parser.getAttributeValue(index)
    }
    return null
}

private fun relationshipIdAttribute(parser: XmlPullParser): String? {
    // OOXML nodes such as p:sldId contain both a numeric `id` and an `r:id`.
    // Prefer the relationships namespace/prefix so slide/sheet ordering resolves correctly.
    for (index in 0 until parser.attributeCount) {
        val name = parser.getAttributeName(index)
        if (name != "id" && name != "r:id") continue
        val namespace = runCatching { parser.getAttributeNamespace(index) }.getOrNull().orEmpty()
        if (namespace.contains("relationships", ignoreCase = true) || name == "r:id") {
            return parser.getAttributeValue(index)
        }
    }
    // Most producers use rIdN. This fallback also works if namespace processing is disabled.
    for (index in 0 until parser.attributeCount) {
        val value = parser.getAttributeValue(index).orEmpty()
        if (value.startsWith("rId", ignoreCase = true)) return value
    }
    return null
}

private fun parseSharedStringsStream(input: java.io.InputStream): List<String> {
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    val values = mutableListOf<String>()
    var insideSi = false
    var current = StringBuilder()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> if (parser.name == "si") { insideSi = true; current = StringBuilder() }
            XmlPullParser.TEXT -> if (insideSi) current.append(parser.text.orEmpty())
            XmlPullParser.END_TAG -> if (parser.name == "si") { values += current.toString(); insideSi = false }
        }
        event = parser.next()
    }
    return values
}

private fun excelColumnIndex(cellRef: String): Int {
    var result = 0
    var found = false
    for (char in cellRef) {
        if (!char.isLetter()) break
        found = true
        result = result * 26 + (char.uppercaseChar() - 'A' + 1)
    }
    return if (found) result - 1 else -1
}

private fun excelColumnName(index: Int): String {
    var value = index + 1
    val out = StringBuilder()
    while (value > 0) {
        val rem = (value - 1) % 26
        out.append(('A'.code + rem).toChar())
        value = (value - 1) / 26
    }
    return out.reverse().toString()
}


private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
