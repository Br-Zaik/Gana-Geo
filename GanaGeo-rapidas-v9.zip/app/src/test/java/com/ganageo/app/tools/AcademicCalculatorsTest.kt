package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class AcademicCalculatorsTest {
    @Test
    fun statisticsCalculatesMainMeasures() {
        val result = StatisticsCalculator.calculate(listOf(1.0, 2.0, 2.0, 3.0, 4.0))
        assertEquals(5, result.count)
        assertEquals(2.4, result.mean, 0.000001)
        assertEquals(2.0, result.median, 0.000001)
        assertEquals(listOf(2.0), result.modes)
    }

    @Test
    fun quadraticEquationReturnsTwoRoots() {
        val result = EquationSolver.solveQuadratic(1.0, -3.0, 2.0)
        assertTrue(result.resultLines.any { it.contains("1") })
        assertTrue(result.resultLines.any { it.contains("2") })
    }

    @Test
    fun chemistrySupportsParenthesesAndHydrates() {
        val calciumHydroxide = ChemistryCalculator.analyzeFormula("Ca(OH)2")
        assertEquals(mapOf("Ca" to 1, "O" to 2, "H" to 2), calciumHydroxide.elementCounts)
        assertTrue(abs(calciumHydroxide.molarMass - 74.092) < 0.02)

        val hydrate = ChemistryCalculator.analyzeFormula("CuSO4·5H2O")
        assertEquals(10, hydrate.elementCounts["H"])
        assertEquals(9, hydrate.elementCounts["O"])
    }

    @Test
    fun convertsNumberBases() {
        val result = NumberBaseConverter.convert("FF", 16)
        assertEquals("255", result.decimal)
        assertEquals("11111111", result.binary)
    }
}

// La prueba del graficador se mantiene aquí porque utiliza el mismo evaluador local.
class ExpressionVariableTest {
    @Test
    fun expressionEvaluatorSupportsXVariable() {
        val value = ExpressionEvaluator(variables = mapOf("x" to 3.0))
            .evaluate("x^2 + 2*x + 1")
        assertEquals(16.0, value, 0.000001)
    }
}
