package com.ganageo.app.ui.tools

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.GeoGameRunStart
import com.ganageo.app.model.GeoGameStatus
import com.ganageo.app.tools.AdventureBiome
import com.ganageo.app.tools.AdventureLevel
import com.ganageo.app.tools.CheckpointKind
import com.ganageo.app.tools.ConduitDirection
import com.ganageo.app.tools.CrusherAxis
import com.ganageo.app.tools.CrusherStyle
import com.ganageo.app.tools.CratePayload
import com.ganageo.app.tools.FallingBehavior
import com.ganageo.app.tools.FallingObjectKind
import com.ganageo.app.tools.FallingTriggerMode
import com.ganageo.app.tools.GameEnemyKind
import com.ganageo.app.tools.GameHazard
import com.ganageo.app.tools.GamePickupKind
import com.ganageo.app.tools.GamePlatform
import com.ganageo.app.tools.GeoAdventureLevelFactory
import com.ganageo.app.tools.GeoGameRules
import com.ganageo.app.tools.GeoLifePackage
import com.ganageo.app.tools.HazardKind
import com.ganageo.app.tools.HazardTriggerMode
import com.ganageo.app.tools.HazardOrientation
import com.ganageo.app.tools.LevelExitKind
import com.ganageo.app.tools.LauncherDirection
import com.ganageo.app.tools.PlatformKind
import com.ganageo.app.tools.PlatformRole
import com.ganageo.app.tools.PlatformRevealMode
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
private fun <T> rememberGeoRuntimeVar(key1: Any?, key2: Any?, initial: T): GeoRuntimeVar<T> =
    remember(key1, key2) { GeoRuntimeVar(initial) }

@Composable
fun GeoAdventuresScreen(
    viewModel: GanaGeoViewModel,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {},
    guestMode: Boolean = false
) {
    val scope = rememberCoroutineScope()
    val screenContext = LocalContext.current
    fun enterGameImmersiveNow() {
        screenContext.findActivity()?.window?.let { window ->
            WindowCompat.setDecorFitsSystemWindows(window, false)
            WindowInsetsControllerCompat(window, window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
            @Suppress("DEPRECATION")
            run {
                window.decorView.systemUiVisibility =
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }
        }
    }
    var status by remember { mutableStateOf<GeoGameStatus?>(null) }
    var loading by remember { mutableStateOf(true) }
    var localMode by remember { mutableStateOf(guestMode) }
    var activeRun by remember { mutableStateOf<GeoGameRunStart?>(null) }
    var activeLevel by rememberSaveable { mutableIntStateOf(1) }
    var pendingPurchase by remember { mutableStateOf<GeoLifePackage?>(null) }
    var selectedLifeType by rememberSaveable { mutableStateOf("free") }
    var storyBeforeStart by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var pendingLifeType by remember { mutableStateOf("free") }
    var shownStories by remember { mutableStateOf(setOf<Int>()) }
    var countdownNowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var nextLifeDeadlineMs by remember { mutableLongStateOf(0L) }

    fun reload(preferLocal: Boolean = localMode) {
        scope.launch {
            loading = true
            viewModel.loadGeoGameStatus(preferLocal)
                .onSuccess {
                    status = it
                    localMode = it.isLocalTest
                    activeLevel = activeLevel.coerceAtMost(it.unlockedLevel.coerceAtLeast(1))
                }
                .onFailure { onMessage(it.message ?: "No se pudo cargar Geo Aventuras.") }
            loading = false
        }
    }

    fun startLevel(level: Int, lifeType: String, skipStory: Boolean = false) {
        val levelData = GeoAdventureLevelFactory.build(level)
        if (!skipStory && levelData.introStory != null && level !in shownStories) {
            pendingLifeType = lifeType
            storyBeforeStart = level to levelData.introStory
            shownStories = shownStories + level
            return
        }
        scope.launch {
            loading = true
            viewModel.startGeoGameRun(level, lifeType, localMode)
                .onSuccess {
                    enterGameImmersiveNow()
                    onImmersiveChanged(true)
                    activeLevel = level
                    activeRun = it
                }
                .onFailure { onMessage(it.message ?: "No se pudo iniciar el nivel.") }
            loading = false
        }
    }

    fun advanceLevel(level: Int, lifeType: String) {
        if (level > GeoGameRules.LEVEL_COUNT) {
            activeRun = null
            onImmersiveChanged(false)
            reload(if (guestMode) true else localMode)
            return
        }
        scope.launch {
            loading = true
            viewModel.startGeoGameRun(level, lifeType, localMode)
                .onSuccess {
                    enterGameImmersiveNow()
                    onImmersiveChanged(true)
                    activeLevel = level
                    activeRun = it
                }
                .onFailure {
                    onMessage(it.message ?: "No quedan vidas disponibles para continuar la aventura.")
                    activeRun = null
                    onImmersiveChanged(false)
                    reload(if (guestMode) true else localMode)
                }
            loading = false
        }
    }

    fun chooseLevel(level: Int) {
        val current = status ?: return
        if (level > current.unlockedLevel || loading) return
        val canUsePremium = !guestMode &&
            current.premiumLives > 0 &&
            current.premiumUsedToday < current.premiumDailyLimit
        val lifeType = if (selectedLifeType == "premium" && canUsePremium) "premium" else "free"
        if (lifeType == "free" && current.freeLives <= 0) {
            onMessage("No tienes vidas rojas disponibles. Espera la recuperación o inicia sesión para revisar tus opciones.")
            return
        }
        if (selectedLifeType == "premium" && !canUsePremium) selectedLifeType = "free"
        startLevel(level, lifeType)
    }

    fun buyPackage(packageInfo: GeoLifePackage) {
        scope.launch {
            loading = true
            viewModel.buyGeoGameLives(packageInfo.code)
                .onSuccess { purchase ->
                    localMode = purchase.isLocalTest
                    onMessage("Recibiste ${purchase.livesAdded} vida(s) dorada(s). Los Rewards se liberan tras 20 segundos activos.")
                    status = viewModel.loadGeoGameStatus(localMode).getOrNull() ?: status
                }
                .onFailure { onMessage(it.message ?: "No se pudieron comprar vidas.") }
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload(guestMode) }
    LaunchedEffect(status?.freeLives, status?.nextFreeLifeInSeconds) {
        val remainingSeconds = status?.nextFreeLifeInSeconds ?: 0L
        countdownNowMs = System.currentTimeMillis()
        nextLifeDeadlineMs = if (remainingSeconds > 0L) {
            countdownNowMs + remainingSeconds * 1_000L
        } else {
            0L
        }
        while (nextLifeDeadlineMs > 0L) {
            countdownNowMs = System.currentTimeMillis()
            if (countdownNowMs >= nextLifeDeadlineMs) {
                nextLifeDeadlineMs = 0L
                reload(localMode)
                break
            }
            delay(1_000L)
        }
    }

    DisposableEffect(activeRun) {
        onImmersiveChanged(activeRun != null)
        onDispose { if (activeRun != null) onImmersiveChanged(false) }
    }

    storyBeforeStart?.let { (level, story) ->
        StoryDialog(
            title = "${when (level) {
                in 1..4 -> "Acto 1 · Bosque de día"
                in 5..8 -> "Acto 2 · Descenso al atardecer"
                in 9..10 -> "Acto 3 · Subsuelo"
                in 11..15 -> "Acto 4 · Cavernas nocturnas"
                else -> "Acto 5 · Desierto del amanecer"
            }} · ${GeoAdventureLevelFactory.build(level).levelName}",
            story = story,
            onDismiss = { storyBeforeStart = null },
            onContinue = {
                storyBeforeStart = null
                startLevel(level, pendingLifeType)
            }
        )
    }


    pendingPurchase?.let { pack ->
        AlertDialog(
            onDismissRequest = { if (!loading) pendingPurchase = null },
            title = { Text("Confirmar compra de vidas") },
            text = { Text("Comprarás ${pack.lives} vida(s) dorada(s) por ${pack.creditCost} créditos.") },
            confirmButton = {
                Button(onClick = { pendingPurchase = null; buyPackage(pack) }, enabled = !loading) { Text("Comprar") }
            },
            dismissButton = { TextButton(onClick = { pendingPurchase = null }, enabled = !loading) { Text("Cancelar") } }
        )
    }

    activeRun?.let { run ->
        key(activeLevel, run.runId) {
            GeoAdventureGame(
                level = GeoAdventureLevelFactory.build(activeLevel),
                run = run,
                viewModel = viewModel,
                onMessage = onMessage,
                onExit = {
                    activeRun = null
                    onImmersiveChanged(false)
                    reload(if (guestMode) true else localMode)
                },
                onQuit = {
                    activeRun = null
                    onImmersiveChanged(false)
                    onBack()
                },
                onAdvance = { nextLevel, lifeType -> advanceLevel(nextLevel, lifeType) },
                guestMode = guestMode
            )
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Geo Aventuras", "20 laberintos troll · tensión constante", onBack)
        if (loading && status == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = NeonGreen) }
            return@Column
        }
        val current = status ?: GeoGameStatus(isLocalTest = true)
        val displayedNextLifeSeconds = when {
            current.freeLives >= GeoGameRules.MAX_FREE_LIVES -> 0L
            nextLifeDeadlineMs > 0L -> ((nextLifeDeadlineMs - countdownNowMs).coerceAtLeast(0L) + 999L) / 1_000L
            else -> current.nextFreeLifeInSeconds
        }
        val nextLifeText = if (current.freeLives >= GeoGameRules.MAX_FREE_LIVES || displayedNextLifeSeconds <= 0L) {
            "Vidas rojas completas"
        } else {
            val min = displayedNextLifeSeconds / 60
            val sec = displayedNextLifeSeconds % 60
            "Próxima vida en %02d:%02d".format(min, sec)
        }
        val premiumAvailable = !guestMode && current.premiumLives > 0 && current.premiumUsedToday < current.premiumDailyLimit
        LaunchedEffect(premiumAvailable) {
            if (!premiumAvailable && selectedLifeType == "premium") selectedLifeType = "free"
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF102E45)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("GEO contra un planeta tramposo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(
                            "Una aventura continua de 20 niveles: bosque, atardecer, profundidades, cavernas nocturnas y ruinas del desierto. Cada salida conecta con el siguiente nivel.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (guestMode) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                LifeInfo("❤️", current.freeLives.toString(), "Vidas rojas", Modifier.weight(1f))
                                LifeInfo("🏆", current.bestScore.toString(), "Mejor puntaje", Modifier.weight(1f))
                            }
                            Text("Modo invitado: juego básico sin compras ni vidas doradas.", color = NeonGreen, fontWeight = FontWeight.Bold)
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                LifeInfo("❤️", current.freeLives.toString(), "Rojas", Modifier.weight(1f))
                                LifeInfo("💛", current.premiumLives.toString(), "Doradas", Modifier.weight(1f))
                                LifeInfo("🏆", current.bestScore.toString(), "Mejor puntaje", Modifier.weight(1f))
                            }
                            Text("Vida para el próximo nivel", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = { selectedLifeType = "free" },
                                    enabled = current.freeLives > 0,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selectedLifeType == "free") Color(0xFFE53935) else Color(0xFF263A45)
                                    )
                                ) { Text("❤️ Roja") }
                                OutlinedButton(
                                    onClick = { selectedLifeType = "premium" },
                                    enabled = premiumAvailable,
                                    modifier = Modifier.weight(1f)
                                ) { Text("💛 Dorada") }
                            }
                            Text("Comprar vidas doradas", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                LifePackCard("1 vida", "2 créditos", "life_1", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                                LifePackCard("5 vidas", "10 créditos", "life_5", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                                LifePackCard("15 vidas", "30 créditos", "life_15", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                            }
                        }
                        Text(nextLifeText, color = NeonGreen, fontWeight = FontWeight.Bold)
                        Text("Cada partida comienza con ${GeoGameRules.GAME_LIVES_PER_RUN} vidas internas. Cada muerte consume exactamente 1.", color = Gold, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Mapa de los 20 niveles", style = MaterialTheme.typography.titleLarge)
                        Text("Desbloqueado: ${current.unlockedLevel}/20", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { reload(if (guestMode) true else localMode) }) { Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar", tint = NeonGreen) }
                }
            }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxWidth().height(500.dp),
                    userScrollEnabled = false,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items((1..20).toList()) { level ->
                        val data = GeoAdventureLevelFactory.build(level)
                        LevelButton(
                            level = level,
                            unlocked = level <= current.unlockedLevel,
                            importantStory = level in setOf(1, 5, 9, 11, 16, 20),
                            difficultyLabel = data.difficultyLabel,
                            onClick = { chooseLevel(level) }
                        )
                    }
                }
            }
        }

    }
}

@Composable
private fun StoryDialog(title: String, story: String, onDismiss: () -> Unit, onContinue: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(story, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        confirmButton = { Button(onClick = onContinue) { Text("Continuar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Volver") } }
    )
}

@Composable
private fun LifeInfo(symbol: String, value: String, label: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(14.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(symbol)
        Spacer(Modifier.width(6.dp))
        Column { Text(value, fontWeight = FontWeight.Bold); Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun LifePackCard(title: String, cost: String, code: String, enabled: Boolean, modifier: Modifier, onBuy: (String) -> Unit) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = Gold)
            Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(cost, color = NeonGreen, textAlign = TextAlign.Center)
            FilledTonalButton(onClick = { onBuy(code) }, enabled = enabled, contentPadding = PaddingValues(horizontal = 9.dp)) { Text("Comprar") }
        }
    }
}

@Composable
private fun LevelButton(
    level: Int,
    unlocked: Boolean,
    importantStory: Boolean,
    difficultyLabel: String,
    onClick: () -> Unit
) {
    val color = when (level) {
        in 1..5 -> Color(0xFF8EE38A)
        in 6..10 -> Color(0xFFFF9F43)
        in 11..15 -> Color(0xFF8D8BFF)
        else -> Color(0xFFFFC857)
    }
    FilledTonalButton(onClick = onClick, enabled = unlocked, modifier = Modifier.height(78.dp), contentPadding = PaddingValues(4.dp)) {
        if (unlocked) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(level.toString(), fontWeight = FontWeight.Bold)
                Text(difficultyLabel, style = MaterialTheme.typography.labelSmall, color = color, maxLines = 1)
                if (importantStory) Text("• historia", style = MaterialTheme.typography.labelSmall, color = Gold)
            }
        } else Icon(Icons.Rounded.Lock, contentDescription = "Bloqueado", modifier = Modifier.size(18.dp))
    }
}

private enum class GameOutcome { WON, LOST }
private enum class DeathCause { HAZARD, VOID }
private enum class ExitTarget { LEVELS, GEO_ADVENTURES }
private class Bullet(var x: Float, var y: Float, val direction: Float)
private class EnemyBullet(var x: Float, var y: Float, val velocityX: Float, val velocityY: Float)
private class MovingPlatformFrame(
    var platform: GamePlatform,
    var previousX: Float,
    var previousY: Float,
    var deltaX: Float = 0f,
    var deltaY: Float = 0f
)
private class EnemyRuntime(
    var x: Float,
    var y: Float,
    var direction: Float,
    var health: Int,
    var lastActionAt: Long = 0L,
    var velocityY: Float = 0f
)
private class FallingRuntime(
    var x: Float,
    var y: Float,
    var velocityX: Float = 0f,
    var velocityY: Float = 0f,
    var triggeredAt: Long? = null,
    var landedAt: Long? = null,
    var explodedAt: Long? = null,
    var chaseStartedAt: Long? = null,
    var travelled: Float = 0f,
    var disabled: Boolean = false
)
private class ChasingHoleRuntime(
    var x: Float,
    var active: Boolean = false,
    var travelled: Float = 0f,
    var closed: Boolean = false
)
private class CrusherRuntime(var triggeredAt: Long? = null)
private class TreeRuntime(
    var fallStartedAt: Long? = null
)
private data class ConduitTransit(
    val conduitIndex: Int,
    val startedAt: Long,
    val fromX: Float,
    val fromY: Float,
    val toX: Float,
    val toY: Float,
    val endsLevel: Boolean
)

@Composable
private fun GeoAdventureGame(
    level: AdventureLevel,
    run: GeoGameRunStart,
    viewModel: GanaGeoViewModel,
    onMessage: (String) -> Unit,
    onExit: () -> Unit,
    onQuit: () -> Unit,
    onAdvance: (Int, String) -> Unit,
    guestMode: Boolean = false
) {
    ImmersiveLandscapeEffect()
    val context = LocalContext.current
    val audio = remember(level.number) { GameAudioController(context, level.number) }
    val lifecycleOwner = LocalLifecycleOwner.current
    val vibrator = remember { context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator }
    var musicEnabled by rememberSaveable { mutableStateOf(true) }
    var effectsEnabled by rememberSaveable { mutableStateOf(true) }
    var vibrationEnabled by rememberSaveable { mutableStateOf(true) }

    fun vibrate(duration: Long, amplitude: Int = 130) {
        if (!vibrationEnabled || vibrator == null) return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(duration, amplitude.coerceIn(1, 255)))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(duration)
            }
        }
    }

    DisposableEffect(audio) {
        audio.setMusicEnabled(musicEnabled)
        audio.setEffectsEnabled(effectsEnabled)
        audio.startMusic()
        onDispose { audio.release() }
    }
    LaunchedEffect(musicEnabled, effectsEnabled) {
        audio.setMusicEnabled(musicEnabled)
        audio.setEffectsEnabled(effectsEnabled)
    }

    val playerWidth = 44f
    val playerHeight = 58f
    val appleRadius = 12f
    val appleDiameter = appleRadius * 2f
    val maxLives = GeoGameRules.attemptsForLevel(level.number)
    val platformSpatialIndex = remember(level.number) { GeoPlatformSpatialIndex(level.platforms) }
    val platformIndexScratch = remember(level.number) { ArrayList<Int>(48) }
    val renderPlatformIndexScratch = remember(level.number) { ArrayList<Int>(64) }
    val playerCollisionScratch = remember(level.number) { ArrayList<GamePlatform>(56) }
    val objectCollisionScratch = remember(level.number) { ArrayList<GamePlatform>(40) }
    val cameraSmoother = remember(level.number, run.runId) { GeoCameraSmoother() }
    val drawPathScratch = remember(level.number) { Path() }
    val backgroundBrush = remember(level.biome) {
        when (level.biome) {
            AdventureBiome.FOREST_DAY -> Brush.verticalGradient(listOf(Color(0xFF45BDF2), Color(0xFF9DE4FF), Color(0xFFE9FAFF)))
            AdventureBiome.FOREST_SUNSET -> Brush.verticalGradient(listOf(Color(0xFF4A286E), Color(0xFFFF7B54), Color(0xFFFFC971), Color(0xFF314B3B)))
            AdventureBiome.UNDERGROUND -> Brush.verticalGradient(listOf(Color(0xFF1A1718), Color(0xFF3A2C28), Color(0xFF171C20)))
            AdventureBiome.CAVE_NIGHT -> Brush.verticalGradient(listOf(Color(0xFF080B24), Color(0xFF17133B), Color(0xFF102D35)))
            AdventureBiome.DESERT_DAWN -> Brush.verticalGradient(listOf(Color(0xFF4E5B89), Color(0xFFFFA868), Color(0xFFFFD99A), Color(0xFFC58A47)))
        }
    }
    var suppressPlayerUntil by rememberGeoRuntimeVar(level.number, run.runId, 0L)
    val enemyHomeSupports = remember(level.number) {
        level.enemies.map { model ->
            level.platforms
                .asSequence()
                .filter { p ->
                    p.role != PlatformRole.WALL && p.role != PlatformRole.ROOF &&
                        model.x + 46f > p.x && model.x + 4f < p.x + p.width &&
                        abs(p.y - (model.y + 55f)) <= 16f
                }
                .minByOrNull { abs(it.y - (model.y + 55f)) }
        }
    }
    val movingPlatformFrames = remember(level.number, run.runId) {
        ArrayList<MovingPlatformFrame>(level.movingPlatforms.size).apply {
            level.movingPlatforms.forEachIndexed { index, moving ->
                val phase = index * 0.68
                val offset = sin(phase).toFloat() * moving.travel
                val initialX = if (moving.vertical) moving.x else moving.x + offset
                val initialY = if (moving.vertical) moving.y + offset else moving.y
                add(
                    MovingPlatformFrame(
                        platform = GamePlatform(initialX, initialY, moving.width, 26f),
                        previousX = initialX,
                        previousY = initialY
                    )
                )
            }
        }
    }
    var playerX by rememberGeoRuntimeVar(level.number, run.runId, level.spawnX)
    var playerY by rememberGeoRuntimeVar(level.number, run.runId, level.spawnY)
    var velocityY by rememberGeoRuntimeVar(level.number, run.runId, 0f)
    var horizontalVelocity by rememberGeoRuntimeVar(level.number, run.runId, 0f)
    var moveDirection by remember { mutableFloatStateOf(0f) }
    var facing by remember { mutableFloatStateOf(1f) }
    var jumpQueued by rememberGeoRuntimeVar(level.number, run.runId, false)
    var shootQueued by rememberGeoRuntimeVar(level.number, run.runId, false)
    var interactQueued by rememberGeoRuntimeVar(level.number, run.runId, false)
    var onGround by rememberGeoRuntimeVar(level.number, run.runId, false)
    var jumpsRemaining by rememberGeoRuntimeVar(level.number, run.runId, 2)
    var jumpBufferUntil by rememberGeoRuntimeVar(level.number, run.runId, 0L)
    var lastGroundedAt by rememberGeoRuntimeVar(level.number, run.runId, 0L)
    var lastPlayerShotAt by rememberGeoRuntimeVar(level.number, run.runId, 0L)
    val gameClock = remember(level.number, run.runId) { GeoFixedStepClock() }
    var renderPulse by remember(level.number, run.runId) { mutableLongStateOf(0L) }
    var elapsedSeconds by remember(level.number, run.runId) { mutableIntStateOf(0) }
    var lastJumpAt by rememberGeoRuntimeVar(level.number, run.runId, -10_000L)
    var lastDoubleJumpAt by rememberGeoRuntimeVar(level.number, run.runId, -10_000L)
    var lastLandingAt by rememberGeoRuntimeVar(level.number, run.runId, -10_000L)
    var lastLandingImpact by rememberGeoRuntimeVar(level.number, run.runId, 0f)
    var furthestPlayerX by rememberGeoRuntimeVar(level.number, run.runId, level.spawnX)
    var cameraYOffset by rememberGeoRuntimeVar(level.number, run.runId, 0f)
    var conduitTransit by rememberGeoRuntimeVar<ConduitTransit?>(level.number, run.runId, null)
    val treeWarningMs = 280L
    val treeFallDurationMs = 820f
    fun treeFallProgress(startedAt: Long?): Float {
        val started = startedAt ?: return 0f
        return ((gameClock.elapsedMs - started - treeWarningMs) / treeFallDurationMs).coerceIn(0f, 1f)
    }
    fun treeWarningActive(startedAt: Long?): Boolean {
        val started = startedAt ?: return false
        return gameClock.elapsedMs - started in 0L until treeWarningMs
    }
    val plantTriggeredAt = remember(level.number, run.runId) { HashMap<Int, Long>() }
    fun plantIsActive(index: Int): Boolean {
        val plant = level.plantTraps.getOrNull(index) ?: return false
        val triggeredAt = plantTriggeredAt[index] ?: return false
        val age = gameClock.elapsedMs - triggeredAt
        // Plants are completely hidden until GEO commits to the conduit/corridor. After triggering,
        // the root has a short emerge window before the hitbox becomes lethal.
        if (age < 320L) return false
        val cycle = plant.cycleMs.coerceAtLeast(900L)
        val phase = (age - 320L + plant.phaseMs) % cycle
        val activeWindow = plant.activeMs.coerceAtMost((cycle * 0.68f).toLong())
        return phase < activeWindow
    }


    LaunchedEffect(level.number, run.runId) {
        val arrival = level.conduits.firstOrNull { it.arrivalOnly } ?: return@LaunchedEffect
        val fromY = when (arrival.direction) {
            ConduitDirection.DOWN -> arrival.y + arrival.height + 72f
            ConduitDirection.UP -> arrival.y - 120f
            ConduitDirection.SIDE -> arrival.y
        }
        conduitTransit = ConduitTransit(
            conduitIndex = -1,
            startedAt = gameClock.elapsedMs,
            fromX = arrival.x + 18f,
            fromY = fromY,
            toX = level.spawnX,
            toY = level.spawnY,
            endsLevel = false
        )
    }
    var livesRemaining by remember(level.number, run.runId) { mutableIntStateOf(maxLives) }
    var deathCount by remember(level.number, run.runId) { mutableIntStateOf(0) }
    var deathPending by remember(level.number, run.runId) { mutableStateOf(false) }
    var deathCause by remember(level.number, run.runId) { mutableStateOf(DeathCause.HAZARD) }
    var pendingExitTarget by remember(level.number, run.runId) { mutableStateOf<ExitTarget?>(null) }
    var respawnX by rememberGeoRuntimeVar(level.number, run.runId, level.spawnX)
    var respawnY by rememberGeoRuntimeVar(level.number, run.runId, level.spawnY)
    var activeCheckpoint by remember(level.number, run.runId) { mutableIntStateOf(-1) }
    var checkpointGraceUntil by rememberGeoRuntimeVar(level.number, run.runId, 0L)
    val collected = remember(level.number, run.runId) { HashSet<Int>() }
    var collectedKeys by remember(level.number, run.runId) { mutableStateOf(setOf<Int>()) }
    var activeSwitches by remember(level.number, run.runId) { mutableStateOf(setOf<Int>()) }
    val destroyedCrates = remember(level.number, run.runId) { HashSet<Int>() }
    val collectedPickups = remember(level.number, run.runId) { HashSet<Int>() }
    var activatedCheckpoints by remember(level.number, run.runId) { mutableStateOf(setOf<Int>()) }
    val revealedCheckpoints = remember(level.number, run.runId) { HashSet<Int>() }
    val brokenDecoys = remember(level.number, run.runId) { HashSet<Int>() }
    val platformTriggeredAt = remember(level.number, run.runId) { HashMap<Int, Long>() }
    val platformRevealedAt = remember(level.number, run.runId) { HashMap<Int, Long>() }
    val hazardTriggeredAt = remember(level.number, run.runId) { HashMap<Int, Long>() }
    val activatedEnemies = remember(level.number, run.runId) { HashSet<Int>() }
    val launcherTriggeredAt = remember(level.number, run.runId) { HashMap<Int, Long>() }
    val launcherFired = remember(level.number, run.runId) { HashSet<Int>() }
    val crateTriggeredAt = remember(level.number, run.runId) { HashMap<Int, Long>() }
    val crateExplodedAt = remember(level.number, run.runId) { HashMap<Int, Long>() }

    fun hazardIsActive(index: Int, h: GameHazard): Boolean {
        if (h.kind == HazardKind.HIDDEN_SPIKES) {
            val trigger = hazardTriggeredAt[index] ?: return false
            // The hitbox becomes lethal only after the 170 ms reveal has finished.
            return gameClock.elapsedMs - trigger >= 180L
        }
        if (h.kind == HazardKind.SPIKES || h.kind == HazardKind.CEILING_SPIKES) {
            if (!h.retractable || h.cycleMs <= 0L) return true
            return ((gameClock.elapsedMs + h.phaseMs) % h.cycleMs) < h.cycleMs * 0.56f
        }
        return h.cycleMs <= 0L || ((gameClock.elapsedMs + h.phaseMs) % h.cycleMs) < h.cycleMs * 0.62f
    }

    fun hazardReveal(index: Int, h: GameHazard): Float {
        if (h.kind != HazardKind.HIDDEN_SPIKES) return if (hazardIsActive(index, h)) 1f else 0f
        val trigger = hazardTriggeredAt[index] ?: return 0f
        return ((gameClock.elapsedMs - trigger) / 170f).coerceIn(0f, 1f)
    }
    val fallingRuntime = remember(level.number, run.runId) {
        ArrayList<FallingRuntime>(level.fallingObjects.size).apply {
            addAll(level.fallingObjects.map { FallingRuntime(it.x, it.startY) })
        }
    }
    val treeRuntime = remember(level.number, run.runId) {
        ArrayList<TreeRuntime>(level.fallingObjects.size).apply {
            addAll(level.fallingObjects.map { TreeRuntime() })
        }
    }
    val chasingHoleRuntime = remember(level.number, run.runId) {
        ArrayList<ChasingHoleRuntime>(level.chasingHoles.size).apply {
            addAll(level.chasingHoles.map { ChasingHoleRuntime(it.startX) })
        }
    }
    val crusherRuntime = remember(level.number, run.runId) {
        ArrayList<CrusherRuntime>(level.crushers.size).apply {
            addAll(level.crushers.map { CrusherRuntime() })
        }
    }

    // A floor trap is represented by removing a rectangular piece of the real platform.
    // It is not drawn as an oval, cone or independent black object.
    fun splitPlatformByOpenFloor(platform: GamePlatform): List<GamePlatform> {
        var pieces = listOf(platform)
        level.chasingHoles.forEachIndexed { index, trap ->
            val runtime = chasingHoleRuntime.getOrNull(index) ?: return@forEachIndexed
            if (!runtime.active || runtime.closed) return@forEachIndexed
            val surfaceY = trap.y + 28f
            if (abs(platform.y - surfaceY) > 14f) return@forEachIndexed

            val openingStart = runtime.x.coerceIn(
                minOf(trap.surfaceStartX, trap.surfaceEndX),
                maxOf(trap.surfaceStartX, trap.surfaceEndX)
            )
            val openingEnd = (runtime.x + trap.width).coerceIn(
                minOf(trap.surfaceStartX, trap.surfaceEndX),
                maxOf(trap.surfaceStartX, trap.surfaceEndX)
            )
            if (openingEnd <= openingStart) return@forEachIndexed

            pieces = pieces.flatMap { piece ->
                val pieceEnd = piece.x + piece.width
                if (openingEnd <= piece.x || openingStart >= pieceEnd) {
                    listOf(piece)
                } else {
                    buildList {
                        val leftWidth = (openingStart - piece.x).coerceAtLeast(0f)
                        if (leftWidth > 5f) add(piece.copy(width = leftWidth))
                        val rightX = maxOf(openingEnd, piece.x)
                        val rightWidth = (pieceEnd - rightX).coerceAtLeast(0f)
                        if (rightWidth > 5f) add(piece.copy(x = rightX, width = rightWidth))
                    }
                }
            }
        }
        return pieces
    }
    var outcome by remember(level.number, run.runId) { mutableStateOf<GameOutcome?>(null) }
    var paused by remember(level.number, run.runId) { mutableStateOf(false) }
    DisposableEffect(lifecycleOwner, audio, musicEnabled, paused, outcome) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> audio.pauseMusic()
                Lifecycle.Event.ON_START -> if (musicEnabled && !paused && outcome == null) audio.startMusic()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    var activated by remember(run.runId) { mutableStateOf(!run.needsActivation) }
    var activating by remember { mutableStateOf(false) }
    var activationRewards by remember { mutableLongStateOf(0L) }
    var reportingResult by remember { mutableStateOf(false) }
    var resultSaved by remember { mutableStateOf(false) }
    var resultError by remember { mutableStateOf<String?>(null) }
    var reportAttempt by remember { mutableIntStateOf(0) }
    var autoTransitionStarted by remember(level.number, run.runId) { mutableStateOf(false) }
    var shieldHits by remember(level.number, run.runId) { mutableIntStateOf(0) }
    var weaponPowerUntil by rememberGeoRuntimeVar(level.number, run.runId, 0L)
    var invulnerableUntil by rememberGeoRuntimeVar(level.number, run.runId, 900L)
    var acechanteX by rememberGeoRuntimeVar(level.number, run.runId, -750f)
    var objectiveHint by remember(level.number, run.runId) { mutableStateOf<String?>(level.objective) }
    var objectiveHintUntil by rememberGeoRuntimeVar(level.number, run.runId, 6_000L)
    val bullets = remember(level.number, run.runId) { ArrayList<Bullet>(12) }
    val enemyBullets = remember(level.number, run.runId) { ArrayList<EnemyBullet>(16) }
    val enemies = remember(level.number, run.runId) {
        ArrayList<EnemyRuntime>(level.enemies.size).apply {
            addAll(level.enemies.mapIndexed { index, enemy -> EnemyRuntime(enemy.x, enemy.y, if (index % 2 == 0) 1f else -1f, enemy.health) })
        }
    }

    fun endGame(result: GameOutcome) {
        if (outcome != null) return
        outcome = result
        audio.play(if (result == GameOutcome.WON) GameSound.VICTORY else GameSound.DEFEAT, 0.9f)
        audio.pauseMusic()
    }

    fun resetTransientTraps() {
        platformTriggeredAt.clear()
        platformRevealedAt.clear()
        hazardTriggeredAt.clear()
        plantTriggeredAt.clear()
        activatedEnemies.clear()
        launcherTriggeredAt.clear()
        launcherFired.clear()
        crateTriggeredAt.clear()
        crateExplodedAt.clear()
        level.fallingObjects.forEachIndexed { index, trap ->
            if (index < fallingRuntime.size) fallingRuntime[index] = FallingRuntime(trap.x, trap.startY)
            if (index < treeRuntime.size) treeRuntime[index] = TreeRuntime()
        }
        level.chasingHoles.forEachIndexed { index, trap ->
            if (index < chasingHoleRuntime.size) chasingHoleRuntime[index] = ChasingHoleRuntime(trap.startX)
        }
        level.crushers.forEachIndexed { index, _ ->
            if (index < crusherRuntime.size) crusherRuntime[index] = CrusherRuntime()
        }
        bullets.clear()
        enemyBullets.clear()
        enemies.clear()
        enemies.addAll(level.enemies.mapIndexed { index, enemy ->
            EnemyRuntime(enemy.x, enemy.y, if (index % 2 == 0) 1f else -1f, enemy.health)
        })
    }

    fun respawn() {
        playerX = respawnX
        playerY = respawnY
        velocityY = 0f
        horizontalVelocity = 0f
        moveDirection = 0f
        jumpQueued = false
        shootQueued = false
        interactQueued = false
        jumpsRemaining = 2
        onGround = false
        lastJumpAt = -10_000L
        lastDoubleJumpAt = -10_000L
        lastLandingAt = -10_000L
        lastLandingImpact = 0f
        suppressPlayerUntil = gameClock.elapsedMs + 100L
        cameraSmoother.boostAfterRespawn()
        invulnerableUntil = gameClock.elapsedMs + 1_100L
        conduitTransit = null
        furthestPlayerX = respawnX
        resetTransientTraps()
    }

    fun insideActiveCheckpointGraceZone(): Boolean {
        if (activeCheckpoint < 0 || gameClock.elapsedMs > checkpointGraceUntil) return false
        val checkpoint = level.checkpoints.getOrNull(activeCheckpoint) ?: return false
        if (checkpoint.kind == CheckpointKind.DECOY) return false
        val centerX = playerX + playerWidth / 2f
        val centerY = playerY + playerHeight / 2f
        return centerX in (checkpoint.x - 105f)..(checkpoint.x + 145f) &&
            centerY in (checkpoint.y - 80f)..(checkpoint.y + 110f)
    }

    fun loseLife(
        @Suppress("UNUSED_PARAMETER") reason: String,
        cause: DeathCause = DeathCause.HAZARD
    ) {
        if (outcome != null || deathPending || gameClock.elapsedMs < invulnerableUntil || insideActiveCheckpointGraceZone()) return
        if (shieldHits > 0) {
            shieldHits--
            invulnerableUntil = gameClock.elapsedMs + 900L
            audio.play(GameSound.HIT, 0.75f)
            vibrate(80, 90)
            return
        }
        livesRemaining--
        deathCount++
        deathPending = true
        deathCause = cause
        moveDirection = 0f
        jumpQueued = false
        shootQueued = false
        interactQueued = false
        velocityY = 0f
        horizontalVelocity = 0f
        objectiveHint = null
        objectiveHintUntil = 0L
        audio.play(if (run.lifeType == "premium") GameSound.DEATH_GOLD else GameSound.DEATH_RED, 0.92f, 0.96f + (deathCount % 4) * 0.03f)
        vibrate(if (cause == DeathCause.VOID) 70 else 180, if (cause == DeathCause.VOID) 90 else 190)
    }

    LaunchedEffect(deathPending, livesRemaining, deathCause) {
        if (!deathPending) return@LaunchedEffect
        when (deathCause) {
            DeathCause.VOID -> delay(GeoGameRules.VOID_RESPAWN_DELAY_MS)
            DeathCause.HAZARD -> delay(GeoGameRules.DEATH_REVEAL_MS)
        }
        if (livesRemaining <= 0) {
            endGame(GameOutcome.LOST)
        } else {
            respawn()
        }
        deathPending = false
    }

    BackHandler {
        if (outcome == null) paused = !paused else onExit()
    }

    LaunchedEffect(paused, outcome, musicEnabled) {
        if (paused || outcome != null || !musicEnabled) audio.pauseMusic() else audio.startMusic()
    }
    LaunchedEffect(paused, outcome, deathPending) {
        delay(80L)
        context.findActivity()?.window?.let { window ->
            val appBackground = android.graphics.Color.rgb(6, 29, 18)
            window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(appBackground))
            window.decorView.setBackgroundColor(appBackground)
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
            window.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN or
                    android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
            WindowCompat.setDecorFitsSystemWindows(window, false)
            ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { _, _ ->
                WindowInsetsCompat.CONSUMED
            }
            ViewCompat.requestApplyInsets(window.decorView)
            WindowInsetsControllerCompat(window, window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    LaunchedEffect(level.number, outcome, paused, deathPending) {
        if (outcome != null || paused || deathPending) return@LaunchedEffect
        var previousNanos = withFrameNanos { it }
        while (outcome == null && !paused && !deathPending) {
            val now = withFrameNanos { it }
            val steps = gameClock.consumeFrame(now - previousNanos)
            previousNanos = now
            if (steps <= 0) {
                renderPulse++
                continue
            }

            simulationStep@ for (stepIndex in 0 until steps) {
                if (outcome != null || paused || deathPending) break@simulationStep
                gameClock.advanceOneStep()
                val dt = gameClock.stepSeconds

            val transit = conduitTransit
            if (transit != null) {
                val progress = ((gameClock.elapsedMs - transit.startedAt) / 620f).coerceIn(0f, 1f)
                val eased = progress * progress * (3f - 2f * progress)
                playerX = transit.fromX + (transit.toX - transit.fromX) * eased
                playerY = transit.fromY + (transit.toY - transit.fromY) * eased
                velocityY = 0f
                moveDirection = 0f
                val playerCenterY = playerY + playerHeight / 2f
                val transitTarget = (playerCenterY - 360f).coerceIn(-155f, 225f)
                cameraYOffset += (transitTarget - cameraYOffset) * (dt * 4.2f).coerceIn(0f, 1f)
                if (progress >= 1f) {
                    conduitTransit = null
                    invulnerableUntil = gameClock.elapsedMs + 700L
                    if (transit.endsLevel) endGame(GameOutcome.WON)
                }
                continue@simulationStep
            }

            val playerCenterY = playerY + playerHeight / 2f
            val playerScreenY = playerCenterY - cameraYOffset
            // Large vertical dead-zone: small jumps do not shake the camera. High double-jumps,
            // shafts and long falls still pull the view smoothly, like the reference platformers.
            val deadTop = 190f
            val deadBottom = 535f
            val cameraTarget = when {
                playerScreenY < deadTop -> playerCenterY - deadTop
                playerScreenY > deadBottom -> playerCenterY - deadBottom
                else -> cameraYOffset
            }.coerceIn(-155f, 225f)
            val cameraSpeed = if (abs(cameraTarget - cameraYOffset) > 125f) 3.35f else 1.85f
            cameraYOffset += (cameraTarget - cameraYOffset) * (dt * cameraSpeed).coerceIn(0f, 1f)
            furthestPlayerX = max(furthestPlayerX, playerX)

            level.checkpoints.forEachIndexed { index, cp ->
                if (cp.kind == CheckpointKind.SAFE || (level.number <= 4 && cp.kind == CheckpointKind.DECOY) || playerX >= cp.appearTriggerX) revealedCheckpoints.add(index)
            }
            val playerCenterX = playerX + playerWidth / 2f
            platformSpatialIndex.queryIndices(playerX - 620f, playerX + 720f, platformIndexScratch)
            platformIndexScratch.forEach { index ->
                val platform = level.platforms[index]
                val closeEnough = playerCenterX >= platform.x - 38f && playerCenterX <= platform.x + platform.width + 18f
                val feetY = playerY + playerHeight
                val verticallyNear = feetY >= platform.y - 150f && playerY <= platform.y + platform.height + 65f
                val reactiveFloor = platform.kind == PlatformKind.PROXIMITY_DISAPPEARING || platform.kind == PlatformKind.DISAPPEARING
                val landingCommitted = velocityY >= 0f &&
                    playerX + playerWidth > platform.x + 8f && playerX < platform.x + platform.width - 8f &&
                    feetY in (platform.y - 58f)..(platform.y + 12f)
                if (reactiveFloor && closeEnough && verticallyNear && landingCommitted && index !in platformTriggeredAt) {
                    // Start the countdown when GEO is actually committing to the landing, not merely
                    // when he passes near the platform. This preserves a real reaction window.
                    platformTriggeredAt[index] = gameClock.elapsedMs
                    audio.play(GameSound.HOLE, 0.62f, 1.12f)
                }
                if (platform.kind == PlatformKind.REVEALING && index !in platformRevealedAt) {
                    val center = platform.x + platform.width / 2f
                    val nearReveal = abs(playerCenterX - center) <= platform.revealRadius
                    val shouldReveal = when (platform.revealMode) {
                        PlatformRevealMode.APPROACH -> playerX >= platform.triggerX && nearReveal
                        PlatformRevealMode.JUMP_NEAR -> nearReveal && !onGround && velocityY < 120f
                        PlatformRevealMode.LAND_NEAR -> nearReveal && onGround && gameClock.elapsedMs - lastGroundedAt < 180L
                        PlatformRevealMode.BACKTRACK -> nearReveal && moveDirection < 0f && furthestPlayerX > center + 145f
                        PlatformRevealMode.SWITCH -> platform.triggerSwitchIndex?.let { it in activeSwitches } == true
                    }
                    if (shouldReveal) {
                        platformRevealedAt[index] = gameClock.elapsedMs
                        audio.play(GameSound.TRAP, 0.46f, 1.26f)
                    }
                }
            }
            level.enemies.forEachIndexed { index, model ->
                val triggerX = model.activationTriggerX ?: return@forEachIndexed
                if (index !in activatedEnemies && playerX >= triggerX) {
                    activatedEnemies.add(index)
                    audio.play(GameSound.TRAP, 0.42f, 0.88f + (index % 3) * 0.08f)
                }
            }
            level.launchers.forEachIndexed { index, launcher ->
                val alreadyTriggered = index in launcherTriggeredAt
                val nearLauncher = abs(playerCenterX - launcher.x) <= launcher.triggerRadius
                if (!alreadyTriggered && playerX >= launcher.triggerX && nearLauncher) {
                    launcherTriggeredAt[index] = gameClock.elapsedMs
                    audio.play(GameSound.TRAP, 0.46f, 1.38f)
                }
                val triggeredAt = launcherTriggeredAt[index]
                if (triggeredAt != null && index !in launcherFired && gameClock.elapsedMs - triggeredAt >= launcher.delayMs) {
                    val speed = launcher.projectileSpeed
                    val vx = when (launcher.direction) { LauncherDirection.LEFT -> -speed; LauncherDirection.RIGHT -> speed; else -> 0f }
                    val vy = when (launcher.direction) { LauncherDirection.UP -> -speed; LauncherDirection.DOWN -> speed; else -> 0f }
                    enemyBullets += EnemyBullet(launcher.x, launcher.y, vx, vy)
                    launcherFired.add(index)
                    audio.play(GameSound.ENEMY_SHOT, 0.62f, 0.82f + (index % 4) * 0.07f)
                }
            }
            level.hazards.forEachIndexed { index, hazard ->
                if (hazard.x + hazard.width < playerX - 1_250f || hazard.x > playerX + 1_350f) return@forEachIndexed
                val hazardCenterX = hazard.x + hazard.width / 2f
                val near = abs(playerCenterX - hazardCenterX) <= max(175f, hazard.width + 110f)
                val verticalRelevant = when (hazard.orientation) {
                    HazardOrientation.UP -> abs((playerY + playerHeight) - (hazard.y + hazard.height)) <= 185f
                    HazardOrientation.DOWN -> abs(playerY - hazard.y) <= 205f
                    HazardOrientation.LEFT, HazardOrientation.RIGHT ->
                        playerY + playerHeight >= hazard.y - 70f && playerY <= hazard.y + hazard.height + 70f
                }
                val corridorCommitted = playerCenterX >= hazard.triggerX &&
                    playerCenterX <= hazardCenterX + max(105f, hazard.width + 70f) && verticalRelevant
                val shouldTrigger = when (hazard.triggerMode) {
                    HazardTriggerMode.APPROACH -> playerX >= hazard.triggerX && near && verticalRelevant
                    HazardTriggerMode.JUMP_NEAR -> (!onGround && velocityY < 80f && near && verticalRelevant) || corridorCommitted
                    HazardTriggerMode.LAND_NEAR -> (onGround && gameClock.elapsedMs - lastGroundedAt < 180L && near && verticalRelevant) || corridorCommitted
                    HazardTriggerMode.BACKTRACK -> moveDirection < 0f && furthestPlayerX > hazardCenterX + 150f && near && verticalRelevant
                }
                if (hazard.kind == HazardKind.HIDDEN_SPIKES && shouldTrigger && index !in hazardTriggeredAt) {
                    hazardTriggeredAt[index] = gameClock.elapsedMs
                    audio.play(GameSound.SPIKE, 0.58f, 1.18f + (index % 3) * 0.08f)
                }
            }
            level.fallingObjects.forEachIndexed { index, trap ->
                val runtime = fallingRuntime[index]
                if (runtime.triggeredAt == null && (trap.x < playerX - 1_250f || trap.x > playerX + 1_450f)) return@forEachIndexed
                val trapCenterX = trap.x + trap.size / 2f
                val nearTrap = abs(playerCenterX - trapCenterX) <= trap.triggerRadius
                // JUMP_NEAR/LAND_NEAR used to depend on a very short animation state. If that
                // frame was missed, a boulder could wait until a completely unrelated jump much
                // later. Entering the authored trigger corridor now acts as a deterministic fallback.
                val feetY = playerY + playerHeight
                val verticalRelevant = feetY >= trap.startY - 95f && playerY <= trap.targetY + 170f
                val corridorCommitted = playerCenterX >= trap.triggerX &&
                    playerCenterX <= trapCenterX + max(120f, trap.triggerRadius * 0.70f) && verticalRelevant
                val shouldTrigger = when (trap.triggerMode) {
                    FallingTriggerMode.APPROACH -> playerX >= trap.triggerX && playerX < trap.x + 300f && verticalRelevant
                    FallingTriggerMode.PASS_UNDER -> nearTrap && feetY > trap.startY + 65f && verticalRelevant
                    FallingTriggerMode.JUMP_NEAR -> (nearTrap && !onGround && velocityY < 120f && verticalRelevant) || corridorCommitted
                    FallingTriggerMode.LAND_NEAR -> (nearTrap && onGround && gameClock.elapsedMs - lastGroundedAt < 180L && verticalRelevant) || corridorCommitted
                    FallingTriggerMode.BACKTRACK -> nearTrap && moveDirection < 0f && furthestPlayerX > trapCenterX + 160f && verticalRelevant
                    FallingTriggerMode.SWITCH -> trap.triggerSwitchIndex?.let { it in activeSwitches } == true
                }
                if (runtime.triggeredAt == null && shouldTrigger) {
                    runtime.triggeredAt = gameClock.elapsedMs
                    audio.play(GameSound.FRUIT_DROP, 0.58f, 0.90f + (index % 4) * 0.05f)
                }
            }

            level.movingPlatforms.forEachIndexed { index, moving ->
                val frame = movingPlatformFrames[index]
                frame.previousX = frame.platform.x
                frame.previousY = frame.platform.y
                val phase = gameClock.elapsedMs / 1000f / moving.periodSeconds * (Math.PI * 2.0) + index * 0.68
                val offset = sin(phase).toFloat() * moving.travel
                val currentX = if (moving.vertical) moving.x else moving.x + offset
                val currentY = if (moving.vertical) moving.y + offset else moving.y
                frame.deltaX = currentX - frame.previousX
                frame.deltaY = currentY - frame.previousY
                frame.platform = GamePlatform(currentX, currentY, moving.width, 26f)
            }
            fun platformVisible(index: Int, p: GamePlatform): Boolean = when (p.kind) {
                PlatformKind.SOLID, PlatformKind.BOUNCE -> true
                PlatformKind.REVEALING -> index in platformRevealedAt
                PlatformKind.DISAPPEARING, PlatformKind.PROXIMITY_DISAPPEARING -> {
                    val delay = if (p.kind == PlatformKind.DISAPPEARING) maxOf(p.delayMs, 700L) else p.delayMs
                    platformTriggeredAt[index]?.let { gameClock.elapsedMs - it <= delay } ?: true
                }
                PlatformKind.FALLING -> {
                    val triggered = platformTriggeredAt[index]
                    triggered == null || gameClock.elapsedMs - triggered <= p.delayMs
                }
            }

            fun collectCollisionPlatforms(minX: Float, maxX: Float, out: MutableList<GamePlatform>) {
                out.clear()
                val hasOpenHole = chasingHoleRuntime.any { it.active && !it.closed }
                platformSpatialIndex.queryIndices(minX, maxX, platformIndexScratch)
                platformIndexScratch.forEach { index ->
                    val base = level.platforms[index]
                    if (!platformVisible(index, base)) return@forEach
                    val runtimePlatform = if (base.kind == PlatformKind.FALLING) {
                        val triggered = platformTriggeredAt[index]
                        if (triggered != null) {
                            val fallOffset = ((gameClock.elapsedMs - triggered).coerceAtLeast(0L) / 4f).coerceAtMost(120f)
                            base.copy(y = base.y + fallOffset)
                        } else base
                    } else base
                    if (hasOpenHole) splitPlatformByOpenFloor(runtimePlatform).forEach(out::add) else out.add(runtimePlatform)
                }
                movingPlatformFrames.forEach { frame ->
                    val p = frame.platform
                    if (p.x + p.width >= minX && p.x <= maxX) out.add(p)
                }
                activeSwitches.forEach { index ->
                    level.switches.getOrNull(index)?.let { sw ->
                        val bridge = GamePlatform(sw.opensAtX, 520f, 235f, 26f)
                        if (bridge.x + bridge.width >= minX && bridge.x <= maxX) out.add(bridge)
                    }
                }
                level.fallingObjects.forEachIndexed { index, trap ->
                    val runtime = fallingRuntime.getOrNull(index)
                    if (trap.becomesPlatform && runtime?.landedAt != null && !runtime.disabled) {
                        val bridge = GamePlatform(runtime.x, runtime.y, trap.size, 18f, PlatformKind.SOLID)
                        if (bridge.x + bridge.width >= minX && bridge.x <= maxX) out.add(bridge)
                    }
                    if (!trap.treeFallsAfterTrap || trap.kind != FallingObjectKind.FRUIT) return@forEachIndexed
                    val progress = treeFallProgress(treeRuntime.getOrNull(index)?.fallStartedAt)
                    if (progress < 0.98f) return@forEachIndexed
                    val trunkLength = (trap.targetY - (trap.startY - 28f)).coerceAtLeast(180f)
                    val baseX = trap.x + trap.size / 2f
                    val direction = if ((index + level.number) % 2 == 0) 1f else -1f
                    val tipX = baseX + direction * trunkLength
                    val platformStart = minOf(baseX, tipX) + 24f
                    val platformWidth = (kotlin.math.abs(tipX - baseX) - 48f).coerceAtLeast(120f)
                    val treeBridge = GamePlatform(platformStart, trap.targetY - 11f, platformWidth, 22f, PlatformKind.SOLID)
                    if (treeBridge.x + treeBridge.width >= minX && treeBridge.x <= maxX) out.add(treeBridge)
                }
            }

            collectCollisionPlatforms(playerX - 440f, playerX + playerWidth + 540f, playerCollisionScratch)
            val nearbyCollisionPlatforms = playerCollisionScratch

            val wasOnGround = onGround
            if (wasOnGround) lastGroundedAt = gameClock.elapsedMs
            if (wasOnGround) {
                val feetY = playerY + playerHeight
                val riding = movingPlatformFrames.firstOrNull { frame ->
                    playerX + playerWidth > frame.previousX + 3f &&
                        playerX < frame.previousX + frame.platform.width - 3f &&
                        abs(feetY - frame.previousY) <= 11f
                }
                if (riding != null) {
                    playerX = (playerX + riding.deltaX).coerceIn(0f, level.width - playerWidth)
                    playerY += riding.deltaY
                }
            }
            val previousBottom = playerY + playerHeight
            if (moveDirection != 0f) facing = moveDirection.sign
            val maxRunSpeed = 278f + level.number * 3.4f
            val targetHorizontalSpeed = moveDirection * maxRunSpeed
            val horizontalAcceleration = when {
                moveDirection == 0f -> if (onGround) 2_850f else 1_900f
                onGround -> 2_350f
                else -> 1_650f
            }
            horizontalVelocity = approachFloat(horizontalVelocity, targetHorizontalSpeed, horizontalAcceleration * dt)
            var horizontalForce = horizontalVelocity
            val currentRectForFan = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)
            level.fans.forEachIndexed { index, fan ->
                if (fan.x + fan.width < playerX - 420f || fan.x > playerX + 520f) return@forEachIndexed
                val cyclingOn = fan.cycleMs <= 0 || ((gameClock.elapsedMs + fan.phaseMs) % fan.cycleMs) < fan.cycleMs * 0.66f
                if (!cyclingOn) return@forEachIndexed
                val reversed = fan.switchIndex?.let { it in activeSwitches } == true
                val fanRect = Rect(fan.x, fan.y, fan.x + fan.width, fan.y + fan.height)
                if (currentRectForFan.overlaps(fanRect)) {
                    horizontalForce += if (reversed) -fan.forceX else fan.forceX
                    velocityY += (if (reversed) -fan.forceY else fan.forceY) * dt
                }
            }
            val candidateX = (playerX + horizontalForce * dt).coerceIn(0f, level.width - playerWidth)
            val candidateRect = Rect(candidateX, playerY, candidateX + playerWidth, playerY + playerHeight)
            val blockedByBarrier = level.barriers.any { barrier ->
                barrier.switchIndex !in activeSwitches &&
                    barrier.x + barrier.width >= playerX - 420f && barrier.x <= playerX + 520f &&
                    candidateRect.overlaps(Rect(barrier.x, barrier.y, barrier.x + barrier.width, barrier.y + barrier.height))
            }
            val blockedByTerrain = nearbyCollisionPlatforms.any { platform ->
                candidateRect.overlaps(Rect(platform.x, platform.y, platform.x + platform.width, platform.y + platform.height))
            }
            if (!blockedByBarrier && !blockedByTerrain) {
                playerX = candidateX
            }

            if (jumpQueued) {
                jumpBufferUntil = gameClock.elapsedMs + 180L
                jumpQueued = false
            }
            val canGroundJump = wasOnGround || gameClock.elapsedMs - lastGroundedAt <= 125L
            if (jumpBufferUntil >= gameClock.elapsedMs && (canGroundJump || jumpsRemaining > 0)) {
                val double = !canGroundJump
                lastJumpAt = gameClock.elapsedMs
                if (double) lastDoubleJumpAt = gameClock.elapsedMs
                velocityY = if (double) -535f else -655f
                jumpsRemaining = if (double) (jumpsRemaining - 1).coerceAtLeast(0) else 1
                onGround = false
                jumpBufferUntil = 0L
                audio.play(if (double) GameSound.DOUBLE_JUMP else GameSound.JUMP, 0.8f)
            }

            velocityY += 1_470f * dt
            var nextY = playerY + velocityY * dt
            onGround = false
            val previousTop = playerY

            // Los techos y bloques del laberinto son sólidos: GEO ya no atraviesa
            // estructuras de tierra al saltar desde abajo.
            if (velocityY < 0f) {
                nearbyCollisionPlatforms.forEach { p ->
                    val overlapsX = playerX + playerWidth > p.x + 3f && playerX < p.x + p.width - 3f
                    val underside = p.y + p.height
                    if (overlapsX && previousTop >= underside - 10f && nextY <= underside) {
                        nextY = underside
                        velocityY = 0f
                    }
                }
                level.barriers.forEach { barrier ->
                    if (barrier.switchIndex in activeSwitches || barrier.x + barrier.width < playerX - 80f || barrier.x > playerX + playerWidth + 80f) return@forEach
                    val overlapsX = playerX + playerWidth > barrier.x + 3f && playerX < barrier.x + barrier.width - 3f
                    val underside = barrier.y + barrier.height
                    if (overlapsX && previousTop >= underside - 10f && nextY <= underside) {
                        nextY = underside
                        velocityY = 0f
                    }
                }
            }

            val nextBottom = nextY + playerHeight
            nearbyCollisionPlatforms.forEach { p ->
                val overlapsX = playerX + playerWidth > p.x + 2f && playerX < p.x + p.width - 2f
                if (overlapsX && velocityY >= 0f && previousBottom <= p.y + 12f && nextBottom >= p.y) {
                    val landingImpact = velocityY
                    nextY = p.y - playerHeight
                    velocityY = if (p.kind == PlatformKind.BOUNCE) -810f else 0f
                    onGround = p.kind != PlatformKind.BOUNCE
                    jumpsRemaining = if (p.kind == PlatformKind.BOUNCE) 1 else 2
                    lastGroundedAt = gameClock.elapsedMs
                    if (!wasOnGround) {
                        lastLandingAt = gameClock.elapsedMs
                        lastLandingImpact = landingImpact
                    }
                    if (!wasOnGround && velocityY == 0f) audio.play(GameSound.LAND, 0.18f, 0.92f + (level.number % 3) * 0.05f)
                    val baseIndex = level.platforms.indexOf(p)
                    if (baseIndex >= 0 && p.kind == PlatformKind.FALLING && platformTriggeredAt[baseIndex] == null) {
                        platformTriggeredAt[baseIndex] = gameClock.elapsedMs
                        audio.play(GameSound.TRAP, 0.35f, 1.15f)
                    }
                }
            }
            level.barriers.forEach { barrier ->
                if (barrier.switchIndex in activeSwitches || barrier.x + barrier.width < playerX - 80f || barrier.x > playerX + playerWidth + 80f) return@forEach
                val overlapsX = playerX + playerWidth > barrier.x + 2f && playerX < barrier.x + barrier.width - 2f
                if (overlapsX && velocityY >= 0f && previousBottom <= barrier.y + 12f && nextBottom >= barrier.y) {
                    val landingImpact = velocityY
                    nextY = barrier.y - playerHeight
                    velocityY = 0f
                    onGround = true
                    jumpsRemaining = 2
                    lastGroundedAt = gameClock.elapsedMs
                    if (!wasOnGround) {
                        lastLandingAt = gameClock.elapsedMs
                        lastLandingImpact = landingImpact
                        audio.play(GameSound.LAND, 0.18f, 0.92f + (level.number % 3) * 0.05f)
                    }
                }
            }
            playerY = nextY
            var playerRect = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)

            level.plantTraps.forEachIndexed { index, plant ->
                if (plant.x + plant.width < playerX - 260f || plant.x > playerX + 320f) return@forEachIndexed
                val plantCenterX = plant.x + plant.width / 2f
                val geoCenterX = playerX + playerWidth / 2f
                val triggerDistance = minOf(plant.detectionRange, 190f)
                if (index !in plantTriggeredAt && abs(geoCenterX - plantCenterX) <= triggerDistance) {
                    plantTriggeredAt[index] = gameClock.elapsedMs
                    audio.play(GameSound.TRAP, 0.50f, 0.78f + (index % 3) * 0.06f)
                }
                if (plantIsActive(index) && playerRect.overlaps(Rect(plant.x, plant.y, plant.x + plant.width, plant.y + plant.height))) {
                    loseLife("La planta trampa atrapó a GEO")
                }
            }

            if (conduitTransit == null && !deathPending) {
                level.conduits.forEachIndexed { index, conduit ->
                    if (conduit.arrivalOnly || !conduit.autoEnter) return@forEachIndexed
                    val entryRect = Rect(conduit.x - 10f, conduit.y - 12f, conduit.x + conduit.width + 10f, conduit.y + conduit.height + 16f)
                    if (!playerRect.overlaps(entryRect)) return@forEachIndexed
                    val guarded = level.plantTraps.indices.any { plantIndex ->
                        val plant = level.plantTraps[plantIndex]
                        abs((plant.x + plant.width / 2f) - (conduit.x + conduit.width / 2f)) < 95f && plantIsActive(plantIndex)
                    }
                    if (guarded) return@forEachIndexed
                    if (conduit.endsLevel && level.requiresKey && collectedKeys.size < level.keys.size) {
                        objectiveHint = "La salida sigue cerrada: falta la llave"
                        objectiveHintUntil = gameClock.elapsedMs + 1_800L
                        return@forEachIndexed
                    }
                    if (conduit.endsLevel && activeSwitches.size < level.requiredMechanisms) {
                        objectiveHint = "La salida sigue bloqueada: faltan mecanismos"
                        objectiveHintUntil = gameClock.elapsedMs + 1_800L
                        return@forEachIndexed
                    }
                    conduitTransit = ConduitTransit(index, gameClock.elapsedMs, playerX, playerY, conduit.targetX, conduit.targetY, conduit.endsLevel)
                    audio.play(GameSound.BUTTON, 0.65f, 0.92f)
                }
            }

            level.checkpoints.forEachIndexed { index, cp ->
                if (cp.x < playerX - 420f || cp.x > playerX + 520f) return@forEachIndexed
                if (index !in revealedCheckpoints || index in brokenDecoys) return@forEachIndexed
                val cpRect = Rect(cp.x - 25f, cp.y - 30f, cp.x + 30f, cp.y + 65f)
                if (playerRect.overlaps(cpRect) && index !in activatedCheckpoints) {
                    if (cp.kind == CheckpointKind.DECOY) {
                        brokenDecoys.add(index)
                        audio.play(GameSound.DECOY, 0.9f)
                        loseLife("El checkpoint falso explotó")
                        playerRect = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)
                    } else {
                        activatedCheckpoints = activatedCheckpoints + index
                        activeCheckpoint = index
                        checkpointGraceUntil = gameClock.elapsedMs + 750L
                        respawnX = (cp.x + 18f).coerceIn(0f, level.width - playerWidth)
                        respawnY = (cp.y + 82f - playerHeight).coerceAtLeast(50f)
                        audio.play(GameSound.CHECKPOINT, 0.85f)
                        vibrate(70, 75)
                        objectiveHint = "Checkpoint ${activatedCheckpoints.count { level.checkpoints[it].kind != CheckpointKind.DECOY }} activado"
                        objectiveHintUntil = gameClock.elapsedMs + 1_900L
                    }
                }
            }

            level.crystals.forEachIndexed { index, crystal ->
                if (index !in collected && playerRect.overlaps(Rect(crystal.x - 24f, crystal.y - 24f, crystal.x + 24f, crystal.y + 24f))) {
                    collected.add(index)
                    audio.play(GameSound.CRYSTAL, 0.75f, 1f + index * 0.08f)
                }
            }
            level.keys.forEachIndexed { index, key ->
                val visible = playerX >= key.revealTriggerX && (key.hiddenUntilSwitch == null || key.hiddenUntilSwitch in activeSwitches)
                if (visible && index !in collectedKeys && playerRect.overlaps(Rect(key.x - 28f, key.y - 28f, key.x + 28f, key.y + 28f))) {
                    collectedKeys = collectedKeys + index
                    audio.play(GameSound.PICKUP, 0.92f, 1.18f)
                    vibrate(80, 90)
                    objectiveHint = "Llave encontrada: la salida ya puede abrirse"
                    objectiveHintUntil = gameClock.elapsedMs + 2_300L
                }
            }
            level.pickups.forEachIndexed { index, pickup ->
                if (index !in collectedPickups && playerRect.overlaps(Rect(pickup.x - 25f, pickup.y - 25f, pickup.x + 25f, pickup.y + 25f))) {
                    collectedPickups.add(index)
                    when (pickup.kind) {
                        GamePickupKind.ENERGY -> livesRemaining = (livesRemaining + 1).coerceAtMost(maxLives)
                        GamePickupKind.SHIELD -> shieldHits = (shieldHits + 1).coerceAtMost(2)
                        GamePickupKind.POWER -> weaponPowerUntil = gameClock.elapsedMs + 25_000L
                    }
                    audio.play(GameSound.PICKUP, 0.8f)
                }
            }

            if (interactQueued) {
                var didInteract = false
                level.conduits.forEachIndexed { index, conduit ->
                    if (didInteract || conduit.arrivalOnly || conduit.autoEnter) return@forEachIndexed
                    val close = abs((playerX + playerWidth / 2f) - (conduit.x + conduit.width / 2f)) < 115f &&
                        abs((playerY + playerHeight / 2f) - (conduit.y + conduit.height / 2f)) < 125f
                    if (!close) return@forEachIndexed
                    val guarded = level.plantTraps.indices.any { plantIndex ->
                        val plant = level.plantTraps[plantIndex]
                        abs((plant.x + plant.width / 2f) - (conduit.x + conduit.width / 2f)) < 95f && plantIsActive(plantIndex)
                    }
                    if (guarded) {
                        objectiveHint = "Espera a que la planta se retraiga"
                        objectiveHintUntil = gameClock.elapsedMs + 1_400L
                        didInteract = true
                        return@forEachIndexed
                    }
                    conduitTransit = ConduitTransit(index, gameClock.elapsedMs, playerX, playerY, conduit.targetX, conduit.targetY, conduit.endsLevel)
                    audio.play(GameSound.BUTTON, 0.65f, 0.92f)
                    didInteract = true
                }
                level.switches.forEachIndexed { index, sw ->
                    if (index !in activeSwitches && abs(playerX - sw.x) < 115f && abs(playerY - sw.y) < 130f) {
                        activeSwitches = activeSwitches + index
                        didInteract = true
                        audio.play(GameSound.BUTTON, 0.8f)
                        vibrate(55, 70)
                        objectiveHint = if (sw.reversesFans) "Interruptor activado: algunas corrientes cambiaron de dirección" else "Interruptor activado: una barrera se abrió"
                        objectiveHintUntil = gameClock.elapsedMs + 2_100L
                    }
                }
                val crateIndex = level.crates.indices.firstOrNull { idx ->
                    val crate = level.crates[idx]
                    val crateCenterX = crate.x + 27f
                    val crateCenterY = crate.y + 27f
                    val playerCenterXNow = playerX + playerWidth / 2f
                    val playerCenterYNow = playerY + playerHeight / 2f
                    idx !in destroyedCrates && idx !in crateTriggeredAt &&
                        abs(playerCenterXNow - crateCenterX) < 92f &&
                        abs(playerCenterYNow - crateCenterY) < 88f
                }
                if (crateIndex != null) {
                    val crate = level.crates[crateIndex]
                    didInteract = true
                    when (crate.payload) {
                        CratePayload.LIFE -> {
                            destroyedCrates.add(crateIndex)
                            livesRemaining = (livesRemaining + 1).coerceAtMost(maxLives)
                            audio.play(GameSound.PICKUP, 0.72f, 1.08f)
                        }
                        CratePayload.SHIELD -> {
                            destroyedCrates.add(crateIndex)
                            shieldHits = (shieldHits + 1).coerceAtMost(2)
                            audio.play(GameSound.PICKUP, 0.72f, 0.98f)
                        }
                        CratePayload.POWER -> {
                            destroyedCrates.add(crateIndex)
                            weaponPowerUntil = gameClock.elapsedMs + 22_000L
                            audio.play(GameSound.PICKUP, 0.75f, 1.20f)
                        }
                        CratePayload.SWITCH -> {
                            destroyedCrates.add(crateIndex)
                            crate.switchIndex?.let { switchIndex -> activeSwitches = activeSwitches + switchIndex }
                            audio.play(GameSound.SWITCH, 0.82f)
                        }
                        CratePayload.EMPTY -> {
                            destroyedCrates.add(crateIndex)
                            audio.play(GameSound.DECOY, 0.42f, 1.35f)
                        }
                        CratePayload.EXPLOSION -> {
                            crateTriggeredAt[crateIndex] = gameClock.elapsedMs
                            audio.play(GameSound.TRAP, 0.68f, 1.45f)
                        }
                    }
                }
                if (!didInteract) {
                    objectiveHint = "No hay un botón u objeto cerca"
                    objectiveHintUntil = gameClock.elapsedMs + 1_100L
                }
                interactQueued = false
            }

            if (shootQueued && gameClock.elapsedMs - lastPlayerShotAt >= 330L && (level.weaponEnabled || weaponPowerUntil > gameClock.elapsedMs)) {
                bullets += Bullet(playerX + playerWidth / 2f, playerY + 25f, facing)
                lastPlayerShotAt = gameClock.elapsedMs
                audio.play(GameSound.SHOOT, 0.55f)
            }
            shootQueued = false

            for (i in bullets.indices.reversed()) {
                val moved = bullets[i]
                moved.x += moved.direction * 620f * dt
                val bulletRect = Rect(moved.x - 8f, moved.y - 8f, moved.x + 8f, moved.y + 8f)
                collectCollisionPlatforms(moved.x - 24f, moved.x + 24f, objectCollisionScratch)
                val hitTerrain = objectCollisionScratch.any { p ->
                    bulletRect.overlaps(Rect(p.x, p.y, p.x + p.width, p.y + p.height))
                } || level.barriers.any { barrier ->
                    barrier.switchIndex !in activeSwitches && bulletRect.overlaps(Rect(barrier.x, barrier.y, barrier.x + barrier.width, barrier.y + barrier.height))
                }
                if (hitTerrain) {
                    bullets.removeAt(i)
                    continue
                }
                var hit = false
                enemies.indices.forEach { enemyIndex ->
                    val e = enemies[enemyIndex]
                    val model = level.enemies[enemyIndex]
                    val enemyActive = model.activationTriggerX == null || enemyIndex in activatedEnemies
                    if (!hit && enemyActive && e.health > 0 && Rect(moved.x - 8f, moved.y - 8f, moved.x + 8f, moved.y + 8f)
                            .overlaps(Rect(e.x, e.y, e.x + 52f, e.y + 58f))) {
                        val nextHealth = (e.health - 1).coerceAtLeast(0)
                        e.health = nextHealth
                        if (nextHealth <= 0) {
                            level.enemies.getOrNull(enemyIndex)?.onDefeatSwitchIndex?.let { switchIndex ->
                                if (switchIndex !in activeSwitches) {
                                    activeSwitches = activeSwitches + switchIndex
                                    audio.play(GameSound.SWITCH, 0.72f)
                                }
                            }
                        }
                        hit = true
                    }
                }
                if (hit || moved.x < 0f || moved.x > level.width) bullets.removeAt(i)
            }

            for (i in enemies.indices) {
                val runtime = enemies[i]
                if (runtime.health <= 0) continue
                val model = level.enemies[i]
                if (model.activationTriggerX != null && i !in activatedEnemies) continue
                // Far-away ground enemies may sleep for performance, but their collision world stays
                // intact; when they wake up their support is resolved around the enemy itself.
                if (model.kind != GameEnemyKind.FLYER && abs(runtime.x - playerX) > 610f) continue
                var ex = runtime.x
                var ey = runtime.y
                var dir = runtime.direction
                var evy = runtime.velocityY
                var lastAction = runtime.lastActionAt
                val distance = playerX - ex
                val chasing = abs(distance) < model.detectionRange
                if (model.kind == GameEnemyKind.FLYER) {
                    ex += (if (chasing) distance.sign else dir) * model.speed * dt
                    ey = model.y + sin(gameClock.elapsedMs / 360.0 + i).toFloat() * 75f
                } else {
                    if (chasing) dir = distance.sign.takeIf { it != 0f } ?: dir
                    val patrolLeft = model.x - model.range
                    val patrolRight = model.x + model.range
                    if (!chasing && (ex < patrolLeft || ex > patrolRight)) dir *= -1f

                    // Ground enemies use their OWN nearby terrain, not GEO's camera corridor.
                    // This prevents platforms from disappearing under an enemy when GEO moves away.
                    val enemyFootY = ey + 55f
                    collectCollisionPlatforms(ex - 180f, ex + 230f, objectCollisionScratch)
                    val enemyLocalPlatforms = objectCollisionScratch
                    val authoredSupport = enemyHomeSupports.getOrNull(i)
                    val homeLeft = authoredSupport?.let { it.x + 4f } ?: 0f
                    val homeRight = authoredSupport?.let { it.x + it.width - 54f } ?: (level.width - 55f)
                    val groundedNow = evy == 0f && enemyLocalPlatforms.any { p ->
                        ex + 46f > p.x && ex + 4f < p.x + p.width && abs(p.y - enemyFootY) <= 10f
                    }
                    val probeX = if (dir >= 0f) ex + 57f else ex - 7f
                    val supportAhead = enemyLocalPlatforms.any { p ->
                        probeX >= p.x + 2f && probeX <= p.x + p.width - 2f && abs(p.y - enemyFootY) <= 16f
                    }
                    val blockedAtEdge = groundedNow && !supportAhead
                    if (blockedAtEdge) dir *= -1f
                    val speedFactor = if (chasing) 1.35f else 0.72f
                    var desiredEnemyX = (ex + dir * model.speed * speedFactor * dt).coerceIn(0f, level.width - 55f)
                    // WALKER/JUMPER/GUARDIAN are authored obstacles. They do not intentionally
                    // leave their home platform unless a future level explicitly implements that.
                    if (model.kind == GameEnemyKind.WALKER || model.kind == GameEnemyKind.JUMPER || model.kind == GameEnemyKind.GUARDIAN) {
                        desiredEnemyX = desiredEnemyX.coerceIn(homeLeft.coerceAtMost(homeRight), homeRight.coerceAtLeast(homeLeft))
                    }
                    val enemyCandidate = Rect(desiredEnemyX, ey, desiredEnemyX + 50f, ey + 54f)
                    val blockedByWall = enemyLocalPlatforms.any { p ->
                        p.role == PlatformRole.WALL && enemyCandidate.overlaps(Rect(p.x, p.y, p.x + p.width, p.y + p.height))
                    } || level.barriers.any { barrier ->
                        barrier.switchIndex !in activeSwitches && enemyCandidate.overlaps(Rect(barrier.x, barrier.y, barrier.x + barrier.width, barrier.y + barrier.height))
                    }
                    if (blockedAtEdge || blockedByWall) {
                        dir *= -1f
                    } else {
                        ex = desiredEnemyX
                    }
                    if (model.kind == GameEnemyKind.JUMPER && chasing && abs(distance) < 220f && groundedNow && !blockedAtEdge && gameClock.elapsedMs - lastAction > 800L) {
                        evy = -520f
                        lastAction = gameClock.elapsedMs
                    }
                    if (model.kind == GameEnemyKind.SHOOTER && chasing && abs(distance) < 520f && gameClock.elapsedMs - lastAction > 1_150L) {
                        val dx = playerX - ex
                        val dy = playerY - ey
                        val len = sqrt((dx * dx + dy * dy).toDouble()).toFloat().coerceAtLeast(1f)
                        enemyBullets += EnemyBullet(ex + 25f, ey + 22f, dx / len * 365f, dy / len * 365f)
                        lastAction = gameClock.elapsedMs
                        audio.play(GameSound.ENEMY_SHOT, 0.38f)
                    }
                    val prevBottom = ey + 55f
                    evy += 1_420f * dt
                    var nextEnemyY = ey + evy * dt
                    val nextEnemyBottom = nextEnemyY + 55f
                    enemyLocalPlatforms.forEach { p ->
                        if (ex + 50f > p.x && ex < p.x + p.width && evy >= 0f && prevBottom <= p.y + 15f && nextEnemyBottom >= p.y) {
                            nextEnemyY = p.y - 55f
                            evy = 0f
                        }
                    }
                    ey = nextEnemyY
                    if (ey > 700f) {
                        // Ground enemies are authored obstacles, not disposable objects. If one ever
                        // reaches the void because of a transient collision/culling edge case, restore
                        // it to its authored platform instead of letting it disappear from the route.
                        ex = model.x
                        ey = model.y
                        evy = 0f
                        dir *= -1f
                    }
                }
                val enemyRect = Rect(ex, ey, ex + 50f, ey + 58f)
                if (playerRect.overlaps(enemyRect)) {
                    val stomping = velocityY > 140f && playerY + playerHeight - velocityY * dt <= ey + 15f
                    if (stomping) {
                        val nextHealth = (runtime.health - 2).coerceAtLeast(0)
                        runtime.x = ex
                        runtime.y = ey
                        runtime.direction = dir
                        runtime.health = nextHealth
                        runtime.lastActionAt = lastAction
                        runtime.velocityY = evy
                        if (nextHealth <= 0) {
                            model.onDefeatSwitchIndex?.let { switchIndex ->
                                if (switchIndex !in activeSwitches) {
                                    activeSwitches = activeSwitches + switchIndex
                                    audio.play(GameSound.SWITCH, 0.72f)
                                }
                            }
                        }
                        velocityY = if (level.number <= 4) -820f else -460f
                        audio.play(GameSound.ENEMY_STOMP, 0.72f, 0.94f + (i % 3) * 0.07f)
                        continue
                    } else loseLife("Un enemigo te alcanzó")
                }
                runtime.x = ex
                runtime.y = ey
                runtime.direction = dir
                runtime.lastActionAt = lastAction
                runtime.velocityY = evy
            }

            for (i in enemyBullets.indices.reversed()) {
                val moved = enemyBullets[i]
                moved.x += moved.velocityX * dt
                moved.y += moved.velocityY * dt
                val projectileRect = Rect(moved.x - 7f, moved.y - 7f, moved.x + 7f, moved.y + 7f)
                collectCollisionPlatforms(moved.x - 26f, moved.x + 26f, objectCollisionScratch)
                val hitTerrain = objectCollisionScratch.any { p ->
                    projectileRect.overlaps(Rect(p.x, p.y, p.x + p.width, p.y + p.height))
                } || level.barriers.any { barrier ->
                    barrier.switchIndex !in activeSwitches && projectileRect.overlaps(Rect(barrier.x, barrier.y, barrier.x + barrier.width, barrier.y + barrier.height))
                }
                if (hitTerrain) {
                    enemyBullets.removeAt(i)
                } else if (playerRect.overlaps(projectileRect)) {
                    enemyBullets.removeAt(i)
                    loseLife("Un proyectil te alcanzó")
                } else if (moved.x !in 0f..level.width || moved.y !in 0f..780f) enemyBullets.removeAt(i)
                else enemyBullets[i] = moved
            }

            crateTriggeredAt.toMap().forEach { (index, startedAt) ->
                if (index in destroyedCrates || gameClock.elapsedMs - startedAt < 230L) return@forEach
                destroyedCrates.add(index)
                crateTriggeredAt.remove(index)
                crateExplodedAt[index] = gameClock.elapsedMs
                audio.play(GameSound.EXPLOSION, 0.86f, 1.08f)
                vibrate(120, 155)
                val crate = level.crates.getOrNull(index) ?: return@forEach
                val centerX = crate.x + 27f
                val centerY = crate.y + 27f
                val dx = playerX + playerWidth / 2f - centerX
                val dy = playerY + playerHeight / 2f - centerY
                if (sqrt((dx * dx + dy * dy).toDouble()).toFloat() <= 135f) loseLife("La caja era una trampa")
            }

            level.fallingObjects.forEachIndexed { index, trap ->
                var runtime = fallingRuntime[index]
                val triggeredAt = runtime.triggeredAt ?: return@forEachIndexed
                if (runtime.disabled || gameClock.elapsedMs - triggeredAt < trap.delayMs) return@forEachIndexed
                var x = runtime.x
                var y = runtime.y
                var vx = runtime.velocityX
                var vy = runtime.velocityY
                var landedAt = runtime.landedAt
                var explodedAt = runtime.explodedAt
                var chaseStartedAt = runtime.chaseStartedAt
                var travelled = runtime.travelled
                var disabled = runtime.disabled

                if (landedAt == null) {
                    val fallGravity = when (trap.kind) {
                        FallingObjectKind.ROCK, FallingObjectKind.SPIKE_BALL -> 2_050f
                        FallingObjectKind.CRATE -> 1_820f
                        FallingObjectKind.FRUIT -> 1_650f
                    }
                    vy += fallGravity * dt
                    y += vy * dt
                    if (y + trap.size >= trap.targetY) {
                        y = trap.targetY - trap.size
                        vy = 0f
                        landedAt = gameClock.elapsedMs
                        when (trap.behavior) {
                            FallingBehavior.EXPLODE, FallingBehavior.ROLL, FallingBehavior.CHASE -> audio.play(GameSound.FRUIT_DROP, 0.5f, 0.78f)
                            else -> audio.play(GameSound.CRUSHER, 0.42f, 0.76f)
                        }
                    }
                } else {
                    collectCollisionPlatforms(x - 150f, x + trap.size + 150f, objectCollisionScratch)
                    when (trap.behavior) {
                        FallingBehavior.ROLL -> {
                            val speed = 225f + level.number * 12f
                            val towardGeo = (playerX + playerWidth / 2f - (x + trap.size / 2f)).sign
                            // Commit to one direction at impact. Do not re-aim after GEO crosses it.
                            if (abs(vx) < 1f) {
                                val direction = if (towardGeo == 0f) trap.rollDirection.sign else towardGeo
                                vx = direction * speed
                            } else {
                                vx = vx.sign * speed
                            }

                            val stepX = vx * dt
                            val proposedX = x + stepX
                            val proposedRect = Rect(proposedX, y, proposedX + trap.size, y + trap.size)
                            val blockedSide = proposedX <= 0f || proposedX + trap.size >= level.width ||
                                objectCollisionScratch.any { p ->
                                    p.role == PlatformRole.WALL &&
                                        proposedRect.overlaps(Rect(p.x, p.y, p.x + p.width, p.y + p.height))
                                } || level.barriers.any { barrier ->
                                    barrier.switchIndex !in activeSwitches && proposedRect.overlaps(Rect(barrier.x, barrier.y, barrier.x + barrier.width, barrier.y + barrier.height))
                                }
                            if (blockedSide) {
                                vx = -vx
                            } else {
                                x = proposedX
                                travelled += abs(stepX)
                            }

                            // Rolling fruit now respects platform edges instead of floating across voids.
                            val previousBottom = y + trap.size
                            var support: GamePlatform? = null
                            var supportDistance = Float.MAX_VALUE
                            objectCollisionScratch.forEach { p ->
                                val distanceToSurface = abs(p.y - previousBottom)
                                if (p.role != PlatformRole.WALL && p.role != PlatformRole.ROOF &&
                                    x + trap.size > p.x + 2f && x < p.x + p.width - 2f &&
                                    distanceToSurface <= 12f && distanceToSurface < supportDistance
                                ) {
                                    support = p
                                    supportDistance = distanceToSurface
                                }
                            }
                            if (support != null && abs(vy) < 1f) {
                                y = support.y - trap.size
                                vy = 0f
                            } else {
                                vy += 1_650f * dt
                                var nextRollY = y + vy * dt
                                val nextBottom = nextRollY + trap.size
                                var landing: GamePlatform? = null
                                objectCollisionScratch.forEach { p ->
                                    if (p.role != PlatformRole.WALL && p.role != PlatformRole.ROOF &&
                                        x + trap.size > p.x + 2f && x < p.x + p.width - 2f &&
                                        previousBottom <= p.y + 12f && nextBottom >= p.y &&
                                        (landing == null || p.y < landing!!.y)
                                    ) {
                                        landing = p
                                    }
                                }
                                if (landing != null) {
                                    nextRollY = landing.y - trap.size
                                    vy = 0f
                                }
                                y = nextRollY
                            }
                        }
                        FallingBehavior.CHASE -> {
                            if (chaseStartedAt == null) chaseStartedAt = gameClock.elapsedMs
                            val chaseAge = gameClock.elapsedMs - (chaseStartedAt ?: gameClock.elapsedMs)
                            if (chaseAge >= trap.chaseDurationMs || travelled >= trap.chaseMaxTravel) {
                                disabled = true
                            } else {
                                val targetX = playerX + playerWidth / 2f - trap.size / 2f
                                val targetY = playerY + playerHeight / 2f - trap.size / 2f
                                val dx = targetX - x
                                val dy = targetY - y
                                val distance = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (distance > 4f) {
                                    val speed = (145f + level.number * 2.2f).coerceAtMost(188f)
                                    val desiredX = dx / distance * speed
                                    val desiredY = dy / distance * speed
                                    val turn = (dt * 2.4f).coerceIn(0f, 1f)
                                    vx += (desiredX - vx) * turn
                                    vy += (desiredY - vy) * turn
                                    val stepX = vx * dt
                                    val stepY = vy * dt
                                    x += stepX
                                    y += stepY
                                    travelled += sqrt((stepX * stepX + stepY * stepY).toDouble()).toFloat()
                                    val fruitRect = Rect(x, y, x + trap.size, y + trap.size)
                                    val hitTerrain = objectCollisionScratch.any { p ->
                                        fruitRect.overlaps(Rect(p.x, p.y, p.x + p.width, p.y + p.height))
                                    }
                                    val hitBarrier = level.barriers.any { barrier ->
                                        barrier.switchIndex !in activeSwitches && fruitRect.overlaps(Rect(barrier.x, barrier.y, barrier.x + barrier.width, barrier.y + barrier.height))
                                    }
                                    if (hitTerrain || hitBarrier || x <= 0f || x + trap.size >= level.width || y < 20f || y > 690f) {
                                        disabled = true
                                    }
                                }
                            }
                        }
                        FallingBehavior.EXPLODE -> if (explodedAt == null && gameClock.elapsedMs - landedAt >= trap.explosionDelayMs) {
                            explodedAt = gameClock.elapsedMs
                            audio.play(GameSound.EXPLOSION, 0.84f, 0.92f + index % 3 * 0.05f)
                            vibrate(80, 110)
                        }
                        else -> Unit
                    }
                    if (!trap.becomesPlatform) {
                        val landedAge = gameClock.elapsedMs - landedAt
                        disabled = disabled || when (trap.behavior) {
                            FallingBehavior.DROP, FallingBehavior.CHAIN -> landedAge >= 1_800L
                            FallingBehavior.ROLL -> travelled >= 760f || landedAge >= 4_200L
                            FallingBehavior.EXPLODE -> explodedAt?.let { gameClock.elapsedMs - it >= 420L } == true
                            FallingBehavior.CHASE -> false
                        }
                    }
                }
                runtime.x = x
                runtime.y = y
                runtime.velocityX = vx
                runtime.velocityY = vy
                runtime.landedAt = landedAt
                runtime.explodedAt = explodedAt
                runtime.chaseStartedAt = chaseStartedAt
                runtime.travelled = travelled
                runtime.disabled = disabled

                if (trap.treeFallsAfterTrap && index < treeRuntime.size) {
                    var tree = treeRuntime[index]
                    val readyToFall = when (trap.behavior) {
                        FallingBehavior.CHASE -> chaseStartedAt?.let { gameClock.elapsedMs - it >= 2_200L } == true
                        FallingBehavior.EXPLODE -> explodedAt != null
                        else -> landedAt?.let { gameClock.elapsedMs - it >= 900L } == true
                    }
                    if (tree.fallStartedAt == null && readyToFall) {
                        tree.fallStartedAt = gameClock.elapsedMs
                        audio.play(GameSound.CRUSHER, 0.55f, 0.82f + index % 3 * 0.08f)
                    }
                    tree.fallStartedAt?.let { started ->
                        val progress = treeFallProgress(started)
                        // El árbol solo mata mientras está cayendo. Una vez horizontal,
                        // el tronco queda como plataforma segura para continuar el nivel.
                        if (progress in 0.08f..0.96f) {
                            val trunkHeight = (trap.targetY - (trap.startY - 28f)).coerceAtLeast(180f)
                            val baseX = trap.x + trap.size / 2f
                            val baseY = trap.targetY
                            val direction = if ((index + level.number) % 2 == 0) 1f else -1f
                            val tipX = baseX + direction * trunkHeight * progress
                            val tipY = baseY - trunkHeight * (1f - progress)
                            val treeRect = Rect(
                                minOf(baseX, tipX) - 24f,
                                minOf(baseY, tipY) - 34f,
                                maxOf(baseX, tipX) + 24f,
                                maxOf(baseY, tipY) + 12f
                            )
                            if (playerRect.overlaps(treeRect)) loseLife("El árbol cayó sobre GEO")
                        }
                    }
                }

                if (!disabled) {
                    val copies = if (trap.behavior == FallingBehavior.CHAIN) trap.chainCount else 1
                    repeat(copies) { copyIndex ->
                        val copyX = x + (copyIndex - (copies - 1) / 2f) * trap.chainSpacing
                        val hitSize = if (trap.kind == FallingObjectKind.FRUIT) appleDiameter else trap.size
                        val offset = (trap.size - hitSize) / 2f
                        if (playerRect.overlaps(Rect(copyX + offset, y + offset, copyX + offset + hitSize, y + offset + hitSize))) {
                            val impactReason = when (trap.kind) {
                                FallingObjectKind.FRUIT -> "Una fruta trampa golpeó a GEO"
                                FallingObjectKind.ROCK -> "Una roca cayó sobre GEO"
                                FallingObjectKind.CRATE -> "Una caja cayó sobre GEO"
                                FallingObjectKind.SPIKE_BALL -> "La bola con pinchos golpeó a GEO"
                            }
                            loseLife(impactReason)
                        }
                    }
                }
                if (explodedAt != null && gameClock.elapsedMs - explodedAt < 360L) {
                    val centerX = x + trap.size / 2f
                    val centerY = y + trap.size / 2f
                    val dx = playerX + playerWidth / 2f - centerX
                    val dy = playerY + playerHeight / 2f - centerY
                    if (sqrt((dx * dx + dy * dy).toDouble()).toFloat() <= trap.explosionRadius) loseLife("La fruta explotó al acercarte")
                }
            }

            level.chasingHoles.forEachIndexed { index, trap ->
                var runtime = chasingHoleRuntime[index]
                val holePlayerCenter = playerX + playerWidth / 2f
                val closeToOpening = holePlayerCenter >= trap.startX - 38f && holePlayerCenter <= trap.startX + trap.width + 48f
                if (!runtime.active && !runtime.closed && closeToOpening) {
                    runtime.active = true
                    audio.play(GameSound.HOLE, 0.76f, 0.84f + index % 3 * 0.08f)
                }
                if (runtime.active && !runtime.closed) {
                    val minX = minOf(trap.surfaceStartX, trap.surfaceEndX)
                    val maxX = (maxOf(trap.surfaceStartX, trap.surfaceEndX) - trap.width).coerceAtLeast(minX)
                    val forward = if (trap.direction >= 0f) 1f else -1f
                    val playerCenter = playerX + playerWidth / 2f
                    val targetX = (playerCenter - trap.width * 0.45f).coerceIn(minX, maxX)
                    val shouldAdvance = if (forward > 0f) targetX > runtime.x else targetX < runtime.x
                    if (shouldAdvance && runtime.travelled < trap.maxTravel) {
                        val rawStep = forward * trap.speed * dt
                        val nextX = (runtime.x + rawStep).coerceIn(minX, maxX)
                        val travelledNow = runtime.travelled + abs(nextX - runtime.x)
                        runtime.x = nextX
                        runtime.travelled = travelledNow
                    }
                    val reachedSurfaceEdge = if (forward > 0f) runtime.x >= maxX - 0.5f else runtime.x <= minX + 0.5f
                    val exceededTravel = runtime.travelled >= trap.maxTravel
                    val playerLeftSurface = if (forward > 0f) playerX > trap.surfaceEndX + 45f else playerX + playerWidth < trap.surfaceStartX - 45f
                    if (reachedSurfaceEdge || exceededTravel || playerLeftSurface) {
                        runtime.active = false
                        runtime.closed = true
                    }
                }
            }

            level.crushers.forEachIndexed { index, trap ->
                var runtime = crusherRuntime[index]
                if (runtime.triggeredAt == null && playerX >= trap.triggerX) {
                    runtime.triggeredAt = gameClock.elapsedMs
                    audio.play(GameSound.CRUSHER, 0.7f, 0.86f + index % 3 * 0.08f)
                }
                val triggeredAt = runtime.triggeredAt ?: return@forEachIndexed
                if (trap.despawnAfterMs > 0L && gameClock.elapsedMs - triggeredAt >= trap.despawnAfterMs) return@forEachIndexed
                val activeMs = (gameClock.elapsedMs - triggeredAt - trap.delayMs).coerceAtLeast(0L)
                val maxDistance = abs(trap.travel)
                val forward = (activeMs / 1000f * trap.speed).coerceAtMost(maxDistance)
                val reverseStart = trap.delayMs + trap.reverseAfterMs
                val distance = if (gameClock.elapsedMs - triggeredAt <= reverseStart) forward else {
                    val reversed = ((gameClock.elapsedMs - triggeredAt - reverseStart) / 1000f * trap.speed).coerceAtMost(maxDistance)
                    (maxDistance - reversed).coerceAtLeast(0f)
                }
                val signedOffset = trap.travel.sign * distance
                val cx = trap.x + if (trap.axis == CrusherAxis.HORIZONTAL) signedOffset else 0f
                val cy = trap.y + if (trap.axis == CrusherAxis.VERTICAL) signedOffset else 0f
                if (playerRect.overlaps(Rect(cx, cy, cx + trap.width, cy + trap.height))) loseLife(if (trap.style == CrusherStyle.FALLING_WALL) "El muro cayó sobre GEO" else "La trampa de piedra aplastó a GEO")
            }

            level.hazards.forEachIndexed { index, h ->
                if (h.x + h.width < playerX - 280f || h.x > playerX + 340f) return@forEachIndexed
                if (hazardIsActive(index, h) && playerRect.overlaps(Rect(h.x, h.y, h.x + h.width, h.y + h.height))) {
                    audio.play(if (h.kind == HazardKind.FIRE) GameSound.EXPLOSION else GameSound.SPIKE, 0.58f, 0.94f + index % 4 * 0.05f)
                    loseLife(when (h.kind) {
                        HazardKind.HIDDEN_SPIKES -> "Los pinchos estaban ocultos"
                        HazardKind.SAW -> "La sierra te alcanzó"
                        HazardKind.FIRE -> "La llamarada se activó"
                        HazardKind.CEILING_SPIKES -> "El techo era una trampa"
                        else -> "Caíste en los pinchos"
                    })
                }
            }

            if (level.acechantePresent) {
                val target = playerX - 155f
                val speed = 132f + level.number * 6f
                acechanteX += (target - acechanteX).sign * speed * dt
                if (abs(playerX - acechanteX) < 60f) loseLife("El Acechante te encontró")
            }

            if (playerY > 705f) loseLife("Caíste al vacío", DeathCause.VOID)
            if (gameClock.elapsedMs > 900_000L) endGame(GameOutcome.LOST)

            val hasConduitExit = level.conduits.any { it.endsLevel }
            val nearExitHeight = playerY + playerHeight >= level.goalY - 85f && playerY <= level.goalY + 150f
            if (!hasConduitExit && playerX + playerWidth >= level.goalX && nearExitHeight) {
                when {
                    level.requiresKey && collectedKeys.size < level.keys.size -> {
                        objectiveHint = "La puerta está cerrada: encuentra la llave oculta"
                        objectiveHintUntil = gameClock.elapsedMs + 2_200L
                    }
                    activeSwitches.size < level.requiredMechanisms -> {
                        objectiveHint = "La salida está cerrada: faltan ${level.requiredMechanisms - activeSwitches.size} interruptores"
                        objectiveHintUntil = gameClock.elapsedMs + 2_200L
                    }
                    else -> endGame(GameOutcome.WON)
                }
            } else if (objectiveHint != null && objectiveHintUntil > 0 && gameClock.elapsedMs > objectiveHintUntil) {
                objectiveHint = null
                objectiveHintUntil = 0L
            }
            }
            val nextElapsedSeconds = (gameClock.elapsedMs / 1000L).toInt()
            if (nextElapsedSeconds != elapsedSeconds) elapsedSeconds = nextElapsedSeconds
            renderPulse++
        }
    }

    LaunchedEffect(run.runId, elapsedSeconds, activated, outcome) {
        if (run.needsActivation && !activated && !activating && outcome == null && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            activating = true
            viewModel.activateGeoGameRun(run)
                .onSuccess {
                    activated = true
                    activationRewards = it.awardedPoints
                }
                .onFailure { if (!it.message.orEmpty().contains("not ready", true)) onMessage(it.message ?: "No se pudo activar la vida dorada.") }
            activating = false
        }
    }

    LaunchedEffect(outcome, reportAttempt) {
        val finalOutcome = outcome ?: return@LaunchedEffect
        if (resultSaved || reportingResult) return@LaunchedEffect
        reportingResult = true
        resultError = null
        var canFinish = activated
        if (run.needsActivation && !canFinish && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            viewModel.activateGeoGameRun(run)
                .onSuccess { canFinish = true; activated = true; activationRewards = it.awardedPoints }
                .onFailure { resultError = it.message ?: "No se pudo confirmar la vida dorada." }
        }
        if (run.needsActivation && !canFinish) {
            runCatching { viewModel.cancelGeoGameRun(run) }
                .onSuccess { onMessage("La partida terminó antes de 20 segundos activos; la vida dorada fue devuelta."); resultSaved = true }
                .onFailure { resultError = it.message ?: "No se pudo devolver la vida todavía." }
            reportingResult = false
            return@LaunchedEffect
        }
        val won = finalOutcome == GameOutcome.WON
        val stars = GeoGameRules.calculateStars(won, if (won) 3 else 0, elapsedSeconds, level.parSeconds)
        val score = playerX.toLong() + collectedKeys.size * 900L + activeSwitches.size * 350L + activatedCheckpoints.size * 250L + livesRemaining * 160L + if (won) 3_000L else 0L
        viewModel.finishGeoGameRun(run, won, stars, score, gameClock.elapsedMs)
            .onSuccess { resultSaved = true }
            .onFailure { resultError = it.message ?: "No se pudo guardar el resultado." }
        reportingResult = false
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF040D13))) {
        Canvas(Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE")
            val framePulse = renderPulse
            val viewportWidth = size.width
            val viewportHeight = size.height
            val gameTop = -6f
            val gameBottom = viewportHeight + 34f
            val scaleY = (gameBottom - gameTop) / 760f
            val targetCameraX = (playerX - viewportWidth * 0.30f).coerceIn(0f, max(level.width - viewportWidth, 0f))
            val cameraX = cameraSmoother.update(targetCameraX)
            fun sy(value: Float) = gameTop + (value - cameraYOffset) * scaleY
            fun visibleX(worldX: Float, width: Float = 0f, margin: Float = 220f): Boolean =
                worldX + width >= cameraX - margin && worldX <= cameraX + viewportWidth + margin
            fun drawApple(center: Offset, radius: Float = appleRadius, exploding: Boolean = false) {
                val darkRed = if (exploding) Color(0xFF9C1322) else Color(0xFFB71C2A)
                val appleRed = if (exploding) Color(0xFFFF334D) else Color(0xFFE72F3E)
                drawOval(
                    color = darkRed,
                    topLeft = Offset(center.x - radius * 0.78f, center.y - radius * 0.52f),
                    size = Size(radius * 1.56f, radius * 1.46f)
                )
                drawCircle(appleRed, radius * 0.61f, Offset(center.x - radius * 0.30f, center.y - radius * 0.18f))
                drawCircle(appleRed, radius * 0.61f, Offset(center.x + radius * 0.30f, center.y - radius * 0.18f))
                drawOval(
                    color = appleRed,
                    topLeft = Offset(center.x - radius * 0.58f, center.y - radius * 0.02f),
                    size = Size(radius * 1.16f, radius * 0.92f)
                )
                drawLine(
                    Color(0xFF5D3A20),
                    Offset(center.x, center.y - radius * 0.72f),
                    Offset(center.x + radius * 0.12f, center.y - radius * 1.08f),
                    radius * 0.13f
                )
                val leaf = drawPathScratch.apply { reset();
                    moveTo(center.x + radius * 0.10f, center.y - radius * 0.88f)
                    quadraticBezierTo(
                        center.x + radius * 0.55f,
                        center.y - radius * 1.14f,
                        center.x + radius * 0.68f,
                        center.y - radius * 0.72f
                    )
                    quadraticBezierTo(
                        center.x + radius * 0.38f,
                        center.y - radius * 0.58f,
                        center.x + radius * 0.10f,
                        center.y - radius * 0.88f
                    )
                    close()
                }
                drawPath(leaf, Color(0xFF70C84D))
                drawCircle(Color.White.copy(alpha = 0.62f), radius * 0.12f, Offset(center.x - radius * 0.30f, center.y - radius * 0.34f))
            }

            drawRect(backgroundBrush, size = size)
            when (level.biome) {
                AdventureBiome.FOREST_DAY -> {
                    val sunPulse = 1f + sin(gameClock.elapsedMs / 1_900.0).toFloat() * 0.035f
                    drawCircle(Color(0xFFFFF1A6).copy(alpha = 0.34f), 62f * sunPulse, Offset(viewportWidth - 112f, 82f))
                    drawCircle(Color(0xFFFFE26F), 41f, Offset(viewportWidth - 112f, 82f))
                    repeat(5) { i ->
                        val drift = (gameClock.elapsedMs / (34f + i * 4f)) % (viewportWidth + 280f)
                        val cx = ((i * 230f + drift - cameraX * 0.035f) % (viewportWidth + 280f)) - 140f
                        val cy = 68f + (i % 3) * 62f
                        drawOval(Color.White.copy(alpha = 0.63f), Offset(cx, cy), Size(145f, 36f))
                        drawCircle(Color.White.copy(alpha = 0.67f), 27f, Offset(cx + 40f, cy + 5f))
                        drawCircle(Color.White.copy(alpha = 0.67f), 32f, Offset(cx + 83f, cy + 3f))
                    }
                    repeat(8) { i ->
                        val leafX = ((i * 137f - cameraX * 0.62f + gameClock.elapsedMs / (24f + i % 4 * 5f)) % (viewportWidth + 240f)) - 90f
                        val leafY = 95f + ((i * 73f + gameClock.elapsedMs / 33f) % (viewportHeight - 165f))
                        drawOval(Color(0xFF9FE36C).copy(alpha = 0.32f), Offset(leafX, leafY), Size(14f, 6f))
                    }
                }
                AdventureBiome.FOREST_SUNSET -> {
                    val sunY = 122f + sin(gameClock.elapsedMs / 2_600.0).toFloat() * 5f
                    drawCircle(Color(0xFFFFD166).copy(alpha = 0.28f), 78f, Offset(viewportWidth * 0.76f, sunY))
                    drawCircle(Color(0xFFFFC857), 48f, Offset(viewportWidth * 0.76f, sunY))
                    repeat(4) { i ->
                        val drift = (gameClock.elapsedMs / (50f + i * 7f)) % (viewportWidth + 320f)
                        val cx = ((i * 270f + drift - cameraX * 0.045f) % (viewportWidth + 320f)) - 160f
                        val cy = 72f + (i % 3) * 58f
                        drawOval(Color(0xFF5F3B69).copy(alpha = 0.34f), Offset(cx, cy), Size(190f, 30f))
                    }
                    repeat(8) { i ->
                        val px = ((i * 149f - cameraX * 0.22f + gameClock.elapsedMs / (45f + i % 4 * 4f)) % (viewportWidth + 180f)) - 60f
                        val py = 100f + (i * 67 % (viewportHeight.toInt().coerceAtLeast(220) - 120))
                        drawCircle(Color(0xFFFFD07A).copy(alpha = 0.18f + (i % 3) * 0.07f), 2f + i % 3, Offset(px, py.toFloat()))
                    }
                }
                AdventureBiome.UNDERGROUND -> {
                    repeat(7) { i ->
                        val rockX = ((i * 210f - cameraX * (0.08f + i % 3 * 0.03f)) % (viewportWidth + 240f)) - 100f
                        val rockY = 75f + (i % 4) * 115f
                        drawOval(Color(0xFF66534A).copy(alpha = 0.30f), Offset(rockX, rockY), Size(180f + i % 3 * 35f, 95f))
                    }
                    repeat(8) { i ->
                        val rootX = ((i * 173f - cameraX * 0.16f) % (viewportWidth + 180f)) - 60f
                        val sway = sin(gameClock.elapsedMs / 700.0 + i).toFloat() * 7f
                        drawLine(Color(0xFF5C3927).copy(alpha = 0.72f), Offset(rootX, 0f), Offset(rootX + sway + 38f, 155f + (i % 4) * 42f), 6f + i % 3)
                    }
                    repeat(10) { i ->
                        val dustX = ((i * 113f + gameClock.elapsedMs / (42f + i % 5 * 5f) - cameraX * 0.08f) % (viewportWidth + 100f)) - 50f
                        val dustY = 45f + (i * 59 % (viewportHeight.toInt().coerceAtLeast(160) - 70))
                        drawCircle(Color(0xFFD8B08C).copy(alpha = 0.14f + i % 3 * 0.05f), 1.5f + i % 3, Offset(dustX, dustY.toFloat()))
                    }
                }
                AdventureBiome.CAVE_NIGHT -> {
                    repeat(8) { i ->
                        val px = ((i * 127f - cameraX * (0.025f + i % 3 * 0.015f)) % (viewportWidth + 120f)) - 40f
                        val py = 26f + (i * 79 % 330)
                        drawCircle(Color(0xFFC9E9FF).copy(alpha = 0.25f + i % 4 * 0.08f), 1.3f + i % 3, Offset(px, py.toFloat()))
                    }
                    drawCircle(Color(0xFFDCEBFF).copy(alpha = 0.20f), 58f, Offset(viewportWidth - 108f, 82f))
                    drawCircle(Color(0xFFE8F2FF).copy(alpha = 0.86f), 36f, Offset(viewportWidth - 108f, 82f))
                    repeat(8) { i ->
                        val fx = ((i * 173f + sin(gameClock.elapsedMs / 650.0 + i).toFloat() * 44f - cameraX * 0.16f) % (viewportWidth + 140f)) - 45f
                        val fy = 90f + (i * 61 % (viewportHeight.toInt().coerceAtLeast(190) - 100)) + sin(gameClock.elapsedMs / 410.0 + i * 1.7).toFloat() * 22f
                        val glow = 4f + sin(gameClock.elapsedMs / 180.0 + i).toFloat() * 1.4f
                        drawCircle(Color(0xFFA8FF78).copy(alpha = 0.14f), glow * 3f, Offset(fx, fy))
                        drawCircle(Color(0xFFD7FF7A).copy(alpha = 0.88f), glow, Offset(fx, fy))
                    }
                    repeat(6) { i ->
                        val cx = ((i * 245f - cameraX * 0.31f) % (viewportWidth + 260f)) - 80f
                        val base = viewportHeight - 74f
                        val h = 34f + (i % 4) * 19f
                        val crystal = drawPathScratch.apply { reset(); moveTo(cx, base); lineTo(cx + 15f, base - h); lineTo(cx + 30f, base); close() }
                        drawPath(crystal, Color(0xFF65D8FF).copy(alpha = 0.32f + i % 3 * 0.10f))
                    }
                }
                AdventureBiome.DESERT_DAWN -> {
                    val dawnPulse = 1f + sin(gameClock.elapsedMs / 2_200.0).toFloat() * 0.04f
                    drawCircle(Color(0xFFFFF0B0).copy(alpha = 0.25f), 78f * dawnPulse, Offset(viewportWidth * 0.72f, 105f))
                    drawCircle(Color(0xFFFFD166), 45f, Offset(viewportWidth * 0.72f, 105f))
                    repeat(6) { i ->
                        val rx = ((i * 260f - cameraX * 0.19f) % (viewportWidth + 300f)) - 80f
                        val top = sy(245f + i % 3 * 65f)
                        drawRect(Color(0xFF80684E).copy(alpha = 0.52f), Offset(rx, top), Size(48f + i % 2 * 20f, sy(590f) - top))
                        drawRect(Color(0xFFAC8B62).copy(alpha = 0.42f), Offset(rx - 14f, top), Size(76f + i % 2 * 20f, 18f))
                    }
                    repeat(8) { i ->
                        val sandX = ((i * 119f + gameClock.elapsedMs / (19f + i % 4 * 5f) - cameraX * 0.30f) % (viewportWidth + 180f)) - 80f
                        val sandY = 80f + (i * 57 % (viewportHeight.toInt().coerceAtLeast(170) - 90))
                        drawLine(Color(0xFFFFE0A3).copy(alpha = 0.20f + i % 3 * 0.05f), Offset(sandX, sandY.toFloat()), Offset(sandX + 18f, sandY.toFloat() + 2f), 2f)
                    }
                }
            }

            platformSpatialIndex.queryIndices(cameraX - 260f, cameraX + viewportWidth + 260f, renderPlatformIndexScratch)
            val renderHasOpenHole = chasingHoleRuntime.any { it.active && !it.closed }
            renderPlatformIndexScratch.forEach { index ->
                val p = level.platforms[index]
                if (!visibleX(p.x, p.width, 260f)) return@forEach
                val visible = when (p.kind) {
                    PlatformKind.SOLID, PlatformKind.BOUNCE -> true
                    PlatformKind.REVEALING -> index in platformRevealedAt
                    PlatformKind.DISAPPEARING, PlatformKind.PROXIMITY_DISAPPEARING -> {
                        val delay = if (p.kind == PlatformKind.DISAPPEARING) maxOf(p.delayMs, 700L) else p.delayMs
                        platformTriggeredAt[index]?.let { gameClock.elapsedMs - it <= delay } ?: true
                    }
                    PlatformKind.FALLING -> platformTriggeredAt[index]?.let { gameClock.elapsedMs - it <= p.delayMs } ?: true
                }
                if (!visible) return@forEach
                val triggered = platformTriggeredAt[index]
                val fallOffset = if (p.kind == PlatformKind.FALLING && triggered != null) ((gameClock.elapsedMs - triggered).coerceAtLeast(0L) / 4f).coerceAtMost(120f) else 0f
                val terrainBodyColor = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> Color(0xFF6B4528)
                    AdventureBiome.FOREST_SUNSET -> Color(0xFF7C4E2F)
                    AdventureBiome.UNDERGROUND -> Color(0xFF51463F)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF24434C)
                    AdventureBiome.DESERT_DAWN -> Color(0xFFA4723E)
                }
                val terrainTopColor = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> Color(0xFF3FAE59)
                    AdventureBiome.FOREST_SUNSET -> Color(0xFF72A04A)
                    AdventureBiome.UNDERGROUND -> Color(0xFF726557)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF3D7B82)
                    AdventureBiome.DESERT_DAWN -> Color(0xFFD7B15D)
                }
                val terrainShadowColor = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> Color(0xFF4C311D)
                    AdventureBiome.FOREST_SUNSET -> Color(0xFF573521)
                    AdventureBiome.UNDERGROUND -> Color(0xFF3A312C)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF1A2F35)
                    AdventureBiome.DESERT_DAWN -> Color(0xFF7E582E)
                }
                val color = when (p.kind) {
                    PlatformKind.FALLING -> terrainBodyColor.copy(alpha = 0.96f)
                    PlatformKind.DISAPPEARING, PlatformKind.PROXIMITY_DISAPPEARING -> terrainBodyColor.copy(alpha = 0.90f)
                    PlatformKind.REVEALING -> terrainBodyColor.copy(alpha = 0.88f)
                    PlatformKind.BOUNCE -> terrainBodyColor.copy(alpha = 0.94f)
                    else -> terrainBodyColor
                }
                val topColor = when (p.kind) {
                    PlatformKind.SOLID -> terrainTopColor
                    PlatformKind.FALLING -> terrainTopColor.copy(alpha = 0.82f)
                    PlatformKind.DISAPPEARING, PlatformKind.PROXIMITY_DISAPPEARING -> terrainTopColor.copy(alpha = 0.66f)
                    PlatformKind.REVEALING -> terrainTopColor.copy(alpha = 0.72f)
                    PlatformKind.BOUNCE -> terrainTopColor.copy(alpha = 0.94f)
                }
                val shadowColor = terrainShadowColor.copy(alpha = if (p.kind == PlatformKind.SOLID) 1f else 0.80f)
                val renderedPlatform = if (fallOffset == 0f) p else p.copy(y = p.y + fallOffset)
                val splitPieces = if (renderHasOpenHole) splitPlatformByOpenFloor(renderedPlatform) else null
                val pieceCount = splitPieces?.size ?: 1
                repeat(pieceCount) { pieceIndex ->
                    val piece = splitPieces?.get(pieceIndex) ?: renderedPlatform
                    val topLeft = Offset(piece.x - cameraX, sy(piece.y))
                    val baseBodyHeight = piece.height * scaleY
                    val reachesWorldBottom = p.kind == PlatformKind.SOLID && piece.y + piece.height >= 748f
                    val bodyHeight = if (reachesWorldBottom) max(baseBodyHeight, viewportHeight - topLeft.y + 72f) else baseBodyHeight
                    val bodySize = Size(piece.width, bodyHeight)
                    val natural = p.kind == PlatformKind.SOLID && p.role == PlatformRole.GROUND
                    val surfaceHeight = (baseBodyHeight * if (natural) 0.22f else 0.18f).coerceIn(5f, 12f)

                    if (natural) {
                        // The grass is the true upper edge. Soil starts underneath it, so no brown strip
                        // can protrude above the vegetation as happened in v10.0.19.
                        val soilTop = topLeft.y + 7f
                        val soilHeight = (bodyHeight - 7f).coerceAtLeast(2f)
                        drawRect(shadowColor, Offset(topLeft.x, soilTop + 4f), Size(piece.width, soilHeight))
                        drawRect(color, Offset(topLeft.x, soilTop), Size(piece.width, soilHeight))

                        val segments = (piece.width / 24f).toInt().coerceIn(4, 24)
                        val surface = drawPathScratch.apply { reset();
                            moveTo(topLeft.x, topLeft.y + 1f)
                            repeat(segments + 1) { seg ->
                                val xx = topLeft.x + piece.width * seg / segments
                                val seed = kotlin.math.abs(piece.x.toInt() / 7 + seg * 41 + level.number * 23)
                                val irregular = when (seed % 7) {
                                    0 -> -3.2f
                                    1 -> -1.8f
                                    2 -> 1.2f
                                    3 -> -0.8f
                                    4 -> 2.0f
                                    else -> 0.3f
                                }
                                lineTo(xx, topLeft.y + irregular)
                            }
                            lineTo(topLeft.x + piece.width, topLeft.y + surfaceHeight + 7f)
                            lineTo(topLeft.x, topLeft.y + surfaceHeight + 7f)
                            close()
                        }
                        drawPath(surface, topColor)

                        // Small grass blades break the perfectly cut silhouette without altering collision.
                        val bladeCount = (piece.width / 34f).toInt().coerceIn(2, 15)
                        repeat(bladeCount) { blade ->
                            val bx = topLeft.x + 12f + blade * ((piece.width - 24f) / bladeCount.coerceAtLeast(1))
                            val seed = kotlin.math.abs(piece.x.toInt() + blade * 29 + level.number * 17)
                            val bladeH = 3f + seed % 5
                            drawLine(topColor.copy(alpha = 0.92f), Offset(bx, topLeft.y + 2f), Offset(bx + if (blade % 2 == 0) 2f else -2f, topLeft.y - bladeH), 1.5f)
                        }

                        // Irregular stones, roots and cracks; no brick pattern.
                        val details = (piece.width / 62f).toInt().coerceIn(2, 10)
                        repeat(details) { detail ->
                            val px = topLeft.x + 18f + (piece.width - 36f) * detail / details
                            val seed = kotlin.math.abs(piece.x.toInt() + detail * 53 + level.number * 31)
                            val usableDepth = (bodyHeight - surfaceHeight - 22f).coerceAtLeast(4f)
                            val py = topLeft.y + surfaceHeight + 17f + ((seed % 6) * 11f).coerceAtMost(usableDepth)
                            val radius = 2.4f + (seed % 4) * 0.7f
                            drawOval(
                                terrainShadowColor.copy(alpha = 0.27f),
                                Offset(px - radius, py - radius * 0.55f),
                                Size(radius * 2.2f, radius * 1.15f)
                            )
                            if (detail % 3 == 1 && bodyHeight > 72f) {
                                val crackLen = (12f + seed % 16).coerceAtMost(bodyHeight * 0.18f)
                                drawLine(
                                    terrainShadowColor.copy(alpha = 0.36f),
                                    Offset(px, py + 4f),
                                    Offset(px + if (detail % 2 == 0) -6f else 7f, py + crackLen),
                                    1.4f
                                )
                            }
                        }
                    } else if (p.kind == PlatformKind.SOLID && p.role == PlatformRole.LEDGE) {
                        // Floating collision shelves must look intentionally supported, never like chunks
                        // of ground cut out and left in the air. The visual support is biome-specific.
                        val shelfHeight = bodyHeight.coerceAtMost(34f)
                        when (level.biome) {
                            AdventureBiome.FOREST_DAY, AdventureBiome.FOREST_SUNSET -> {
                                val wood = if (level.biome == AdventureBiome.FOREST_DAY) Color(0xFF6A452E) else Color(0xFF744631)
                                val bark = Color(0xFF3E2B20)
                                drawRoundRect(bark, Offset(topLeft.x, topLeft.y + 5f), Size(piece.width, shelfHeight), androidx.compose.ui.geometry.CornerRadius(12f))
                                drawRoundRect(wood, topLeft, Size(piece.width, (shelfHeight - 5f).coerceAtLeast(18f)), androidx.compose.ui.geometry.CornerRadius(12f))
                                drawLine(terrainTopColor.copy(alpha = 0.72f), Offset(topLeft.x + 8f, topLeft.y + 3f), Offset(topLeft.x + piece.width - 8f, topLeft.y + 3f), 3f)
                                val rootCount = (piece.width / 76f).toInt().coerceIn(1, 3)
                                repeat(rootCount) { root ->
                                    val rx = topLeft.x + piece.width * (root + 1f) / (rootCount + 1f)
                                    val length = 24f + ((root * 17 + level.number * 11) % 24)
                                    val sway = if (root % 2 == 0) -11f else 10f
                                    drawLine(bark.copy(alpha = 0.82f), Offset(rx, topLeft.y + shelfHeight - 2f), Offset(rx + sway, topLeft.y + shelfHeight + length), 4f)
                                    drawLine(bark.copy(alpha = 0.58f), Offset(rx + sway, topLeft.y + shelfHeight + length), Offset(rx + sway * 1.35f, topLeft.y + shelfHeight + length + 11f), 2.4f)
                                }
                            }
                            AdventureBiome.UNDERGROUND, AdventureBiome.CAVE_NIGHT -> {
                                val rock = if (level.biome == AdventureBiome.CAVE_NIGHT) Color(0xFF35515A) else Color(0xFF625952)
                                val edge = if (level.biome == AdventureBiome.CAVE_NIGHT) Color(0xFF6C9AAA) else Color(0xFF8A7D73)
                                drawRoundRect(terrainShadowColor.copy(alpha = 0.72f), Offset(topLeft.x + 2f, topLeft.y + 5f), Size(piece.width - 4f, shelfHeight + 7f), androidx.compose.ui.geometry.CornerRadius(9f))
                                drawRoundRect(rock, topLeft, Size(piece.width, shelfHeight), androidx.compose.ui.geometry.CornerRadius(9f))
                                drawLine(edge.copy(alpha = 0.72f), Offset(topLeft.x + 7f, topLeft.y + 3f), Offset(topLeft.x + piece.width - 7f, topLeft.y + 3f), 3f)
                                val shardCount = (piece.width / 68f).toInt().coerceIn(1, 3)
                                repeat(shardCount) { shard ->
                                    val sx = topLeft.x + piece.width * (shard + 1f) / (shardCount + 1f)
                                    val depth = 18f + ((shard * 13 + level.number * 9) % 20)
                                    drawLine(terrainShadowColor.copy(alpha = 0.78f), Offset(sx - 9f, topLeft.y + shelfHeight - 1f), Offset(sx, topLeft.y + shelfHeight + depth), 5f)
                                    drawLine(terrainShadowColor.copy(alpha = 0.58f), Offset(sx + 8f, topLeft.y + shelfHeight - 2f), Offset(sx, topLeft.y + shelfHeight + depth), 3f)
                                }
                            }
                            AdventureBiome.DESERT_DAWN -> {
                                val stone = Color(0xFFA77C49)
                                val seam = Color(0xFF6F5235)
                                drawRoundRect(seam.copy(alpha = 0.72f), Offset(topLeft.x, topLeft.y + 5f), Size(piece.width, shelfHeight + 5f), androidx.compose.ui.geometry.CornerRadius(5f))
                                drawRoundRect(stone, topLeft, Size(piece.width, shelfHeight), androidx.compose.ui.geometry.CornerRadius(5f))
                                drawLine(Color(0xFFE0B86D).copy(alpha = 0.62f), Offset(topLeft.x + 7f, topLeft.y + 3f), Offset(topLeft.x + piece.width - 7f, topLeft.y + 3f), 3f)
                                val braceCount = (piece.width / 82f).toInt().coerceIn(1, 3)
                                repeat(braceCount) { brace ->
                                    val bx = topLeft.x + piece.width * (brace + 1f) / (braceCount + 1f)
                                    val depth = 22f + ((brace * 19 + level.number * 5) % 18)
                                    drawLine(seam.copy(alpha = 0.80f), Offset(bx - 12f, topLeft.y + shelfHeight), Offset(bx, topLeft.y + shelfHeight + depth), 4f)
                                    drawLine(seam.copy(alpha = 0.80f), Offset(bx + 12f, topLeft.y + shelfHeight), Offset(bx, topLeft.y + shelfHeight + depth), 4f)
                                }
                            }
                        }
                    } else if (p.kind == PlatformKind.SOLID && p.role == PlatformRole.ROOF) {
                        // Roofs are attached ceiling masses. Never paint grass on their top edge.
                        drawRect(shadowColor, Offset(topLeft.x, topLeft.y + 3f), bodySize)
                        drawRect(color, topLeft, bodySize)
                        val lowerY = topLeft.y + bodyHeight
                        drawRect(terrainShadowColor.copy(alpha = 0.62f), Offset(topLeft.x, lowerY - 7f), Size(piece.width, 7f))
                        val details = (piece.width / 70f).toInt().coerceIn(2, 9)
                        repeat(details) { detail ->
                            val dx = topLeft.x + 16f + (piece.width - 32f) * detail / details
                            val depth = (15f + ((detail * 17 + level.number * 13) % 28)).coerceAtMost((bodyHeight - 14f).coerceAtLeast(8f))
                            drawLine(terrainShadowColor.copy(alpha = 0.38f), Offset(dx, lowerY - 10f), Offset(dx + if (detail % 2 == 0) 5f else -5f, lowerY - depth), 1.5f)
                        }
                        if (level.biome == AdventureBiome.FOREST_DAY || level.biome == AdventureBiome.FOREST_SUNSET) {
                            val roots = (piece.width / 90f).toInt().coerceIn(2, 6)
                            repeat(roots) { root ->
                                val rx = topLeft.x + piece.width * (root + 1f) / (roots + 1f)
                                val rootLen = 7f + ((root * 13 + level.number * 5) % 10)
                                drawLine(terrainShadowColor.copy(alpha = 0.72f), Offset(rx, lowerY - 3f), Offset(rx + if (root % 2 == 0) 3f else -3f, lowerY + rootLen), 2.5f)
                            }
                        }
                    } else if (p.kind == PlatformKind.SOLID && p.role == PlatformRole.WALL) {
                        // Walls use vertical rock/earth faces, not a horizontal grass cap.
                        drawRect(shadowColor, Offset(topLeft.x + 3f, topLeft.y), bodySize)
                        drawRect(color, topLeft, bodySize)
                        drawRect(terrainShadowColor.copy(alpha = 0.50f), Offset(topLeft.x, topLeft.y), Size(6f, bodyHeight))
                        drawRect(terrainShadowColor.copy(alpha = 0.30f), Offset(topLeft.x + piece.width - 5f, topLeft.y), Size(5f, bodyHeight))
                        val cracks = (bodyHeight / 70f).toInt().coerceIn(1, 7)
                        repeat(cracks) { crack ->
                            val yy = topLeft.y + 24f + crack * ((bodyHeight - 36f).coerceAtLeast(20f) / cracks)
                            val xx = topLeft.x + piece.width * (0.30f + (crack % 3) * 0.18f)
                            drawLine(terrainShadowColor.copy(alpha = 0.34f), Offset(xx, yy), Offset(xx + if (crack % 2 == 0) 9f else -8f, yy + 13f), 1.4f)
                        }
                    } else {
                        // Reactive platforms keep the biome material and are marked subtly by motion,
                        // not by neon purple/cyan blocks that break the scenery.
                        drawRoundRect(shadowColor, Offset(topLeft.x, topLeft.y + 3f), bodySize, androidx.compose.ui.geometry.CornerRadius(7f))
                        drawRoundRect(color, topLeft, bodySize, androidx.compose.ui.geometry.CornerRadius(7f))
                        drawRoundRect(topColor, topLeft, Size(piece.width, surfaceHeight + 2f), androidx.compose.ui.geometry.CornerRadius(7f))
                        if (p.kind == PlatformKind.PROXIMITY_DISAPPEARING || p.kind == PlatformKind.FALLING) {
                            repeat((piece.width / 42f).toInt().coerceIn(2, 8)) { mark ->
                                val mx = topLeft.x + 14f + mark * 39f
                                drawLine(terrainShadowColor.copy(alpha = 0.48f), Offset(mx, topLeft.y + 6f), Offset(mx + 8f, topLeft.y + bodyHeight - 6f), 1.5f)
                            }
                        }
                    }
                }
            }
            level.movingPlatforms.forEachIndexed { index, moving ->
                val phase = gameClock.elapsedMs / 1000f / moving.periodSeconds * (Math.PI * 2.0) + index * 0.68
                val offset = sin(phase).toFloat() * moving.travel
                val movingX = if (moving.vertical) moving.x else moving.x + offset
                val movingY = if (moving.vertical) moving.y + offset else moving.y
                val movingWidth = moving.width
                val movingHeight = 26f
                if (!visibleX(movingX, movingWidth, 260f)) return@forEachIndexed
                val movingBody = when (level.biome) {
                    AdventureBiome.FOREST_DAY, AdventureBiome.FOREST_SUNSET -> Color(0xFF735239)
                    AdventureBiome.UNDERGROUND -> Color(0xFF5E5650)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF35515A)
                    AdventureBiome.DESERT_DAWN -> Color(0xFF9B7548)
                }
                val movingEdge = when (level.biome) {
                    AdventureBiome.FOREST_DAY, AdventureBiome.FOREST_SUNSET -> Color(0xFF9A704B)
                    AdventureBiome.UNDERGROUND -> Color(0xFF81746C)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF527480)
                    AdventureBiome.DESERT_DAWN -> Color(0xFFC49A5E)
                }
                drawRoundRect(movingBody, Offset(movingX - cameraX, sy(movingY)), Size(movingWidth, movingHeight * scaleY), androidx.compose.ui.geometry.CornerRadius(7f))
                drawRect(movingEdge.copy(alpha = 0.78f), Offset(movingX - cameraX + 5f, sy(movingY + 4f)), Size((movingWidth - 10f).coerceAtLeast(0f), 3f))
                drawCircle(Color(0xFFD5D6D2).copy(alpha = 0.62f), 3.5f, Offset(movingX + movingWidth / 2f - cameraX, sy(movingY + 12f)))
            }

            level.fans.forEachIndexed { index, fan ->
                if (!visibleX(fan.x, fan.width, 260f)) return@forEachIndexed
                val active = fan.cycleMs <= 0 || ((gameClock.elapsedMs + fan.phaseMs) % fan.cycleMs) < fan.cycleMs * 0.66f
                val reversed = fan.switchIndex?.let { it in activeSwitches } == true
                val dirX = if (reversed) -fan.forceX else fan.forceX
                val dirY = if (reversed) -fan.forceY else fan.forceY
                drawCircle(if (active) Color(0xFF9BE7FF) else Color(0xFF526D79), 27f, Offset(fan.x - cameraX, sy(fan.y + fan.height / 2f)))
                repeat(4) { blade ->
                    val angle = gameClock.elapsedMs / 120.0 + blade * Math.PI / 2
                    val bx = fan.x - cameraX + kotlin.math.cos(angle).toFloat() * 20f
                    val by = sy(fan.y + fan.height / 2f) + sin(angle).toFloat() * 20f
                    drawLine(Color.White.copy(alpha = 0.7f), Offset(fan.x - cameraX, sy(fan.y + fan.height / 2f)), Offset(bx, by), 5f)
                }
                if (active) repeat(7) { particle ->
                    val progress = ((gameClock.elapsedMs.toFloat() / 7f + particle * 83f) % max(fan.width, fan.height))
                    val px = if (abs(dirX) > abs(dirY)) fan.x + (if (dirX > 0f) progress else fan.width - progress) else fan.x + (particle % 3) * fan.width / 3f
                    val py = if (abs(dirY) > abs(dirX)) fan.y + (if (dirY > 0f) progress else fan.height - progress) else fan.y + 18f + (particle % 4) * 28f
                    drawLine(Color(0xFFB8F2FF).copy(alpha = 0.48f), Offset(px - cameraX, sy(py)), Offset(px - cameraX - dirX.sign * 24f, sy(py - dirY.sign * 12f)), 2f)
                }
                if (index % 2 == 0 && active) drawCircle(Color(0xFFB8F2FF).copy(alpha = 0.14f), 44f, Offset(fan.x - cameraX, sy(fan.y + fan.height / 2f)))
            }

            level.conduits.forEach { conduit ->
                if (!visibleX(conduit.x, conduit.width, 280f)) return@forEach
                val body = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> Color(0xFF765035)
                    AdventureBiome.FOREST_SUNSET -> Color(0xFF68412E)
                    AdventureBiome.UNDERGROUND -> Color(0xFF665A50)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF355B66)
                    AdventureBiome.DESERT_DAWN -> Color(0xFF9B724B)
                }
                val rim = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> Color(0xFF4F8A47)
                    AdventureBiome.FOREST_SUNSET -> Color(0xFF8B6940)
                    AdventureBiome.UNDERGROUND -> Color(0xFF8A7B6B)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF5D91A1)
                    AdventureBiome.DESERT_DAWN -> Color(0xFFC59A5B)
                }
                val sx = conduit.x - cameraX
                val syTop = sy(conduit.y)
                val h = conduit.height * scaleY
                drawRoundRect(body, Offset(sx, syTop), Size(conduit.width, h), androidx.compose.ui.geometry.CornerRadius(20f))
                drawRoundRect(rim, Offset(sx - 7f, syTop), Size(conduit.width + 14f, 18f * scaleY), androidx.compose.ui.geometry.CornerRadius(10f))
                drawOval(Color(0xFF11181B).copy(alpha = 0.92f), Offset(sx + 12f, syTop + 6f), Size(conduit.width - 24f, 16f * scaleY))
                val directionY = when (conduit.direction) {
                    ConduitDirection.DOWN -> syTop + h * 0.74f
                    ConduitDirection.UP -> syTop + h * 0.36f
                    ConduitDirection.SIDE -> syTop + h * 0.55f
                }
                drawCircle(rim.copy(alpha = 0.45f), 5f, Offset(sx + conduit.width / 2f, directionY))
                if (level.biome == AdventureBiome.FOREST_DAY || level.biome == AdventureBiome.FOREST_SUNSET) {
                    repeat(3) { root ->
                        drawLine(rim.copy(alpha = 0.72f), Offset(sx + 15f + root * 24f, syTop + h * 0.45f), Offset(sx + 5f + root * 30f, syTop + h), 5f)
                    }
                } else {
                    repeat(3) { seam ->
                        val yy = syTop + 28f + seam * 18f
                        drawLine(rim.copy(alpha = 0.45f), Offset(sx + 8f, yy), Offset(sx + conduit.width - 8f, yy), 2f)
                    }
                }
            }

            level.plantTraps.forEachIndexed { index, plant ->
                if (!visibleX(plant.x, plant.width, 260f)) return@forEachIndexed
                val triggeredAt = plantTriggeredAt[index] ?: return@forEachIndexed
                val age = gameClock.elapsedMs - triggeredAt
                if (age < 115L) return@forEachIndexed
                val cycle = plant.cycleMs.coerceAtLeast(900L)
                val activeWindow = plant.activeMs.coerceAtLeast(400L)
                val emergeWarning = ((age - 115L) / 205f).coerceIn(0f, 1f)
                val phase = (age - 320L + plant.phaseMs).coerceAtLeast(0L) % cycle
                val raw = if (age < 320L) emergeWarning else if (phase < activeWindow) {
                    val unit = phase.toFloat() / activeWindow
                    sin(unit.toDouble() * Math.PI).toFloat().coerceAtLeast(0f)
                } else 0f
                val emerge = raw.coerceIn(0f, 1f)
                if (emerge <= 0.04f) return@forEachIndexed
                val stemX = plant.x + plant.width / 2f - cameraX
                val baseY = sy(plant.y + plant.height)
                val headY = baseY - plant.height * scaleY * emerge
                val stemColor = when (level.biome) {
                    AdventureBiome.FOREST_DAY, AdventureBiome.FOREST_SUNSET -> Color(0xFF4E8C45)
                    AdventureBiome.UNDERGROUND -> Color(0xFF6C7851)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF4B7C75)
                    AdventureBiome.DESERT_DAWN -> Color(0xFF887A43)
                }
                drawLine(stemColor, Offset(stemX, baseY), Offset(stemX, headY + 20f), 11f)
                drawCircle(Color(0xFF7A2835), 25f, Offset(stemX, headY))
                drawCircle(Color(0xFF43161F), 15f, Offset(stemX, headY + 2f))
                repeat(4) { tooth ->
                    val tx = stemX - 13f + tooth * 8.5f
                    val tri = drawPathScratch.apply { reset();
                        moveTo(tx, headY - 3f); lineTo(tx + 4f, headY + 7f); lineTo(tx + 8f, headY - 3f); close()
                    }
                    drawPath(tri, Color(0xFFF0E4C8))
                }
            }

            fun drawSpikes(h: GameHazard, reveal: Float) {
                if (reveal <= 0.02f) return
                val count = max(2, ((if (h.orientation == HazardOrientation.LEFT || h.orientation == HazardOrientation.RIGHT) h.height else h.width) / 22f).toInt())
                val path = Path()
                when (h.orientation) {
                    HazardOrientation.UP -> {
                        val baseY = sy(h.y + h.height)
                        path.moveTo(h.x - cameraX, baseY)
                        repeat(count) { i ->
                            val left = h.x - cameraX + h.width * i / count
                            val mid = h.x - cameraX + h.width * (i + 0.5f) / count
                            val right = h.x - cameraX + h.width * (i + 1f) / count
                            path.lineTo(left, baseY); path.lineTo(mid, sy(h.y + h.height * (1f - reveal))); path.lineTo(right, baseY)
                        }
                    }
                    HazardOrientation.DOWN -> {
                        val baseY = sy(h.y)
                        path.moveTo(h.x - cameraX, baseY)
                        repeat(count) { i ->
                            val left = h.x - cameraX + h.width * i / count
                            val mid = h.x - cameraX + h.width * (i + 0.5f) / count
                            val right = h.x - cameraX + h.width * (i + 1f) / count
                            path.lineTo(left, baseY); path.lineTo(mid, sy(h.y + h.height * reveal)); path.lineTo(right, baseY)
                        }
                    }
                    HazardOrientation.LEFT -> {
                        val baseX = h.x + h.width - cameraX
                        path.moveTo(baseX, sy(h.y))
                        repeat(count) { i ->
                            val top = sy(h.y + h.height * i / count)
                            val mid = sy(h.y + h.height * (i + 0.5f) / count)
                            val bottom = sy(h.y + h.height * (i + 1f) / count)
                            path.lineTo(baseX, top); path.lineTo(h.x + h.width * (1f - reveal) - cameraX, mid); path.lineTo(baseX, bottom)
                        }
                    }
                    HazardOrientation.RIGHT -> {
                        val baseX = h.x - cameraX
                        path.moveTo(baseX, sy(h.y))
                        repeat(count) { i ->
                            val top = sy(h.y + h.height * i / count)
                            val mid = sy(h.y + h.height * (i + 0.5f) / count)
                            val bottom = sy(h.y + h.height * (i + 1f) / count)
                            path.lineTo(baseX, top); path.lineTo(h.x + h.width * reveal - cameraX, mid); path.lineTo(baseX, bottom)
                        }
                    }
                }
                path.close()
                val spikeShadow = Color(0xFF3F474E)
                drawPath(path, spikeShadow)
                val steel = Brush.linearGradient(
                    listOf(Color(0xFF66727B), Color(0xFFB9C2C8), Color(0xFF7B878F))
                )
                drawPath(path, steel, alpha = 0.96f)
            }
            level.hazards.forEachIndexed { index, h ->
                if (!visibleX(h.x, h.width, 260f)) return@forEachIndexed
                val active = hazardIsActive(index, h)
                val reveal = hazardReveal(index, h)
                when (h.kind) {
                    HazardKind.SAW -> if (active) {
                        val center = Offset(h.x + h.width / 2f - cameraX, sy(h.y + h.height / 2f))
                        drawCircle(Color(0xFFE0E0E0), h.width / 2f, center)
                        drawCircle(Color(0xFF455A64), h.width / 5f, center)
                        repeat(8) { tooth ->
                            val a = gameClock.elapsedMs / 170.0 + tooth * Math.PI / 4
                            drawLine(Color(0xFFFF5252), center, Offset(center.x + kotlin.math.cos(a).toFloat() * h.width * 0.58f, center.y + sin(a).toFloat() * h.width * 0.58f), 4f)
                        }
                    }
                    HazardKind.FIRE -> if (active) {
                        repeat(4) { flame ->
                            val fx = h.x + h.width * (flame + 0.5f) / 4f - cameraX
                            val wave = sin(gameClock.elapsedMs / 90.0 + flame).toFloat() * 8f
                            val p = drawPathScratch.apply { reset();
                                moveTo(fx - 10f, sy(h.y + h.height))
                                quadraticBezierTo(fx - 18f + wave, sy(h.y + h.height * 0.45f), fx, sy(h.y))
                                quadraticBezierTo(fx + 18f - wave, sy(h.y + h.height * 0.45f), fx + 10f, sy(h.y + h.height))
                                close()
                            }
                            drawPath(p, if (flame % 2 == 0) Color(0xFFFF6D00) else Color(0xFFFFD600))
                        }
                    }
                    else -> drawSpikes(h, reveal)
                }
            }

            level.fallingObjects.forEachIndexed { treeIndex, trap ->
                if (!visibleX(trap.x, trap.size, 300f)) return@forEachIndexed
                if (trap.kind != FallingObjectKind.FRUIT) return@forEachIndexed
                val treeState = treeRuntime.getOrNull(treeIndex)
                val progress = treeFallProgress(treeState?.fallStartedAt)
                val warningWobble = if (treeWarningActive(treeState?.fallStartedAt)) {
                    sin(gameClock.elapsedMs / 42.0 + treeIndex).toFloat() * 7f
                } else 0f
                val direction = if ((treeIndex + level.number) % 2 == 0) 1f else -1f
                val baseX = trap.x + trap.size / 2f - cameraX
                val baseY = sy(trap.targetY)
                val trunkTop = trap.startY - 28f
                val trunkHeight = (trap.targetY - trunkTop).coerceAtLeast(180f)
                val tipX = baseX + direction * trunkHeight * scaleY * progress + warningWobble
                val tipY = baseY - trunkHeight * scaleY * (1f - progress)
                drawLine(Color(0xFF704326), Offset(baseX, baseY), Offset(tipX, tipY), 20f)
                drawLine(Color(0xFF815135), Offset(baseX, baseY), Offset(tipX, tipY), 8f)
                val crownColors = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> listOf(Color(0xFF67B94D), Color(0xFF78CA58), Color(0xFF8AD568))
                    AdventureBiome.FOREST_SUNSET -> listOf(Color(0xFF8C7A3E), Color(0xFFB9853F), Color(0xFFC96B3A))
                    AdventureBiome.UNDERGROUND -> listOf(Color(0xFF49624A), Color(0xFF5B6D4F), Color(0xFF3F5143))
                    AdventureBiome.CAVE_NIGHT -> listOf(Color(0xFF315A61), Color(0xFF3A6E73), Color(0xFF284950))
                    AdventureBiome.DESERT_DAWN -> listOf(Color(0xFF806B3E), Color(0xFF9A7840), Color(0xFF6D5C36))
                }
                val crownCenters = listOf(
                    Offset(tipX, tipY - 10f),
                    Offset(tipX - 42f, tipY + 8f),
                    Offset(tipX + 42f, tipY + 8f),
                    Offset(tipX - 20f, tipY - 42f),
                    Offset(tipX + 25f, tipY - 40f)
                )
                crownCenters.forEachIndexed { index, center ->
                    drawCircle(crownColors[(index + treeIndex) % crownColors.size], if (index == 0) 49f else 39f, center)
                }
            }

            level.trees.forEachIndexed { index, tree ->
                if (!visibleX(tree.x - 90f, 180f, 300f)) return@forEachIndexed
                val treeX = tree.x - cameraX
                val baseY = sy(tree.groundY)
                val variantSeed = kotlin.math.abs(tree.variant * 31 + index * 17 + level.number * 13)
                val treeHeight = 218f + (variantSeed % 5) * 12f
                val lean = ((variantSeed % 7) - 3) * 2.4f
                val tipX = treeX + lean
                val tipY = sy(tree.groundY - treeHeight)
                val trunkWidth = 16f + variantSeed % 6
                drawLine(Color(0xFF674027), Offset(treeX, baseY), Offset(tipX, tipY), trunkWidth + 7f)
                drawLine(Color(0xFF815135), Offset(treeX, baseY), Offset(tipX, tipY), trunkWidth)
                val colors = if (level.biome == AdventureBiome.FOREST_SUNSET) {
                    listOf(Color(0xFF7E713D), Color(0xFFA87C3C), Color(0xFFC46D3A))
                } else {
                    listOf(Color(0xFF5DAA49), Color(0xFF72C755), Color(0xFF83CF61))
                }
                val spread = 34f + (variantSeed % 4) * 4f
                val crown = listOf(
                    Offset(tipX, tipY - 8f),
                    Offset(tipX - spread, tipY + 10f),
                    Offset(tipX + spread, tipY + 7f),
                    Offset(tipX - spread * 0.42f, tipY - 38f),
                    Offset(tipX + spread * 0.48f, tipY - 34f)
                )
                crown.forEachIndexed { crownIndex, center ->
                    val radius = if (crownIndex == 0) 44f + variantSeed % 8 else 33f + (variantSeed + crownIndex * 3) % 8
                    drawCircle(colors[(crownIndex + tree.variant + index) % colors.size], radius.toFloat(), center)
                }
                if (tree.appleVisible) {
                    val appleX = if ((tree.variant + index) % 2 == 0) tipX - 18f else tipX + 23f
                    // Partly hidden in foliage so a normal apple does not scream "trap" from far away.
                    drawApple(Offset(appleX, tipY + 8f), appleRadius * 0.82f)
                }
            }

            level.fallingObjects.forEachIndexed { index, trap ->
                val runtime = fallingRuntime[index]
                if (runtime.disabled) return@forEachIndexed
                val triggeredAt = runtime.triggeredAt ?: return@forEachIndexed
                val warningAge = gameClock.elapsedMs - triggeredAt
                if (warningAge < trap.delayMs) {
                    // Once triggered the object is already visible inside the authored camera space.
                    // It never materialises directly on GEO; the short shake is the reaction cue.
                    val warningProgress = (warningAge / trap.delayMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
                    val warningShake = sin(gameClock.elapsedMs / 28.0 + index).toFloat() * (1.5f + warningProgress * 2.5f)
                    val warningX = trap.x + warningShake
                    val warningY = trap.startY
                    val center = Offset(warningX + trap.size / 2f - cameraX, sy(warningY + trap.size / 2f))
                    val alpha = 0.58f + warningProgress * 0.34f
                    when (trap.kind) {
                        FallingObjectKind.FRUIT -> drawApple(center, appleRadius * (0.94f + warningProgress * 0.06f))
                        FallingObjectKind.ROCK -> {
                            drawCircle(Color(0xFF78909C).copy(alpha = alpha), trap.size / 2f, center)
                            drawCircle(Color.White.copy(alpha = 0.10f + warningProgress * 0.10f), trap.size * 0.16f, Offset(center.x - trap.size * 0.14f, center.y - trap.size * 0.13f))
                        }
                        FallingObjectKind.CRATE -> drawRoundRect(
                            Color(0xFF9A6A3A).copy(alpha = alpha),
                            Offset(warningX - cameraX, sy(warningY)),
                            Size(trap.size, trap.size * scaleY),
                            androidx.compose.ui.geometry.CornerRadius(7f)
                        )
                        FallingObjectKind.SPIKE_BALL -> {
                            drawCircle(Color(0xFF37474F).copy(alpha = alpha), trap.size / 2f, center)
                            repeat(10) { k ->
                                val a = k * Math.PI * 2 / 10
                                drawLine(
                                    Color(0xFFECEFF1).copy(alpha = alpha),
                                    center,
                                    Offset(center.x + kotlin.math.cos(a).toFloat() * trap.size * 0.66f, center.y + sin(a).toFloat() * trap.size * 0.66f),
                                    4f
                                )
                            }
                        }
                    }
                    drawOval(
                        Color.Black.copy(alpha = 0.12f + warningProgress * 0.18f),
                        Offset(trap.x + trap.size * 0.10f - cameraX, sy(trap.targetY) - 7f),
                        Size(trap.size * 0.80f, 10f)
                    )
                    return@forEachIndexed
                }
                val y = runtime.y
                val copies = if (trap.behavior == FallingBehavior.CHAIN) trap.chainCount else 1
                repeat(copies) { copyIndex ->
                    val x = runtime.x + (copyIndex - (copies - 1) / 2f) * trap.chainSpacing
                    val center = Offset(x + trap.size / 2f - cameraX, sy(y + trap.size / 2f))
                    when (trap.kind) {
                        FallingObjectKind.FRUIT -> drawApple(center, appleRadius, runtime.explodedAt != null)
                        FallingObjectKind.ROCK -> drawCircle(Color(0xFF78909C), trap.size / 2f, center)
                        FallingObjectKind.CRATE -> drawRoundRect(Color(0xFF9A6A3A), Offset(x - cameraX, sy(y)), Size(trap.size, trap.size * scaleY), androidx.compose.ui.geometry.CornerRadius(7f))
                        FallingObjectKind.SPIKE_BALL -> {
                            drawCircle(Color(0xFF37474F), trap.size / 2f, center)
                            repeat(10) { k ->
                                val a = k * Math.PI * 2 / 10
                                drawLine(Color(0xFFECEFF1), center, Offset(center.x + kotlin.math.cos(a).toFloat() * trap.size * 0.66f, center.y + sin(a).toFloat() * trap.size * 0.66f), 4f)
                            }
                        }
                    }
                }
                runtime.explodedAt?.let { exploded ->
                    val age = gameClock.elapsedMs - exploded
                    if (age < 360L) {
                        val progress = age / 360f
                        drawCircle(Color(0xFFFF6D00).copy(alpha = 1f - progress), trap.explosionRadius * progress.coerceAtLeast(0.18f), Offset(runtime.x + trap.size / 2f - cameraX, sy(runtime.y + trap.size / 2f)))
                    }
                }
            }

            level.crushers.forEachIndexed { index, trap ->
                val runtime = crusherRuntime[index]
                val triggeredAt = runtime.triggeredAt ?: return@forEachIndexed
                if (trap.despawnAfterMs > 0L && gameClock.elapsedMs - triggeredAt >= trap.despawnAfterMs) return@forEachIndexed
                var offset = 0f
                var warningShake = 0f
                if (triggeredAt != null) {
                    val age = gameClock.elapsedMs - triggeredAt
                    if (age < trap.delayMs) warningShake = sin(gameClock.elapsedMs / 35.0 + index).toFloat() * 4f
                    val activeMs = (age - trap.delayMs).coerceAtLeast(0L)
                    val maxDistance = abs(trap.travel)
                    val forward = (activeMs / 1000f * trap.speed).coerceAtMost(maxDistance)
                    val reverseStart = trap.delayMs + trap.reverseAfterMs
                    val distance = if (age <= reverseStart) forward else {
                        val reversed = ((age - reverseStart) / 1000f * trap.speed).coerceAtMost(maxDistance)
                        (maxDistance - reversed).coerceAtLeast(0f)
                    }
                    offset = trap.travel.sign * distance
                }
                val x = trap.x + if (trap.axis == CrusherAxis.HORIZONTAL) offset else warningShake
                val y = trap.y + if (trap.axis == CrusherAxis.VERTICAL) offset else warningShake
                val crusherX = x - cameraX
                val crusherY = sy(y)
                val crusherHeight = trap.height * scaleY
                val (outer, inner) = when (trap.style) {
                    CrusherStyle.STONE_COLUMN -> Color(0xFF4A504D) to Color(0xFF69706C)
                    CrusherStyle.FALLING_WALL -> Color(0xFF5A5148) to Color(0xFF807364)
                    CrusherStyle.LOG_PRESS -> Color(0xFF5B3422) to Color(0xFF8A5738)
                    CrusherStyle.RUIN_BLOCK -> Color(0xFF806B52) to Color(0xFFA98D67)
                }
                if (trap.axis == CrusherAxis.VERTICAL) {
                    val anchorX = trap.x + trap.width / 2f - cameraX
                    drawLine(Color(0xFF3D4546).copy(alpha = 0.75f), Offset(anchorX, gameTop), Offset(anchorX, crusherY), 5f)
                    repeat(5) { link ->
                        val linkY = gameTop + ((crusherY - gameTop) * (link + 0.5f) / 5f)
                        drawCircle(Color(0xFF7E8A8B).copy(alpha = 0.65f), 4f, Offset(anchorX, linkY))
                    }
                } else {
                    val supportY = crusherY + crusherHeight / 2f
                    drawLine(Color(0xFF3D4546).copy(alpha = 0.75f), Offset(trap.x - cameraX, supportY), Offset(crusherX, supportY), 5f)
                }
                drawRoundRect(outer, Offset(crusherX, crusherY), Size(trap.width, crusherHeight), androidx.compose.ui.geometry.CornerRadius(9f))
                drawRoundRect(inner, Offset(crusherX + 4f, crusherY + 4f), Size((trap.width - 8f).coerceAtLeast(10f), (crusherHeight - 8f).coerceAtLeast(10f)), androidx.compose.ui.geometry.CornerRadius(7f))
                repeat(4) { line ->
                    val lineY = crusherY + (line + 1) * crusherHeight / 5f
                    drawLine(outer.copy(alpha = 0.75f), Offset(crusherX + 7f, lineY), Offset(crusherX + trap.width - 7f, lineY), 3f)
                }
                repeat(3) { crack ->
                    val cx = crusherX + trap.width * (0.25f + crack * 0.24f)
                    val cy = crusherY + crusherHeight * (0.22f + (crack % 2) * 0.28f)
                    drawLine(outer.copy(alpha = 0.85f), Offset(cx, cy), Offset(cx + 10f, cy + 14f), 2f)
                    drawLine(outer.copy(alpha = 0.85f), Offset(cx + 10f, cy + 14f), Offset(cx + 3f, cy + 25f), 2f)
                }
            }

            level.barriers.filter { it.switchIndex !in activeSwitches }.forEach { b ->
                val gateX = b.x - cameraX
                val gateY = sy(b.y)
                val gateHeight = b.height * scaleY
                drawRoundRect(
                    Color(0xFF4B514F),
                    Offset(gateX, gateY),
                    Size(b.width, gateHeight),
                    androidx.compose.ui.geometry.CornerRadius(7f)
                )
                repeat(5) { block ->
                    val blockY = gateY + block * gateHeight / 5f
                    drawLine(Color(0xFF2C302F), Offset(gateX + 3f, blockY), Offset(gateX + b.width - 3f, blockY), 3f)
                }
                drawLine(Color(0xFF777F7B), Offset(gateX + 7f, gateY + 6f), Offset(gateX + 7f, gateY + gateHeight - 6f), 4f)
                val spikeCount = max(4, (gateHeight / 52f).toInt())
                repeat(spikeCount) { spike ->
                    val centerY = gateY + (spike + 0.5f) * gateHeight / spikeCount
                    val path = drawPathScratch.apply { reset();
                        moveTo(gateX, centerY - 10f)
                        lineTo(gateX - 23f, centerY)
                        lineTo(gateX, centerY + 10f)
                        close()
                    }
                    drawPath(path, Color(0xFFE7D6B2))
                }
            }
            level.switches.forEachIndexed { index, sw ->
                if (!visibleX(sw.x, 40f, 240f)) return@forEachIndexed
                val active = index in activeSwitches
                val pulse = 1f + sin(gameClock.elapsedMs / 180.0 + index).toFloat() * 0.15f
                if (!active) drawCircle(Gold.copy(alpha = 0.18f), 33f * pulse, Offset(sw.x + 17f - cameraX, sy(sw.y + 22f)))
                drawRoundRect(if (active) NeonGreen else Gold, Offset(sw.x - cameraX, sy(sw.y)), Size(34f, 50f * scaleY), androidx.compose.ui.geometry.CornerRadius(8f))
                drawCircle(Color.White, 5f, Offset(sw.x + 17f - cameraX, sy(sw.y + 14f)))
            }

            level.checkpoints.forEachIndexed { index, cp ->
                if (index !in revealedCheckpoints || index in brokenDecoys) return@forEachIndexed
                val active = index in activatedCheckpoints
                val pulse = 1f + sin(gameClock.elapsedMs / 170.0 + index).toFloat() * 0.12f
                val color = when {
                    active -> NeonGreen
                    level.number <= 4 -> Color(0xFF62D9C7)
                    cp.kind == CheckpointKind.DECOY -> Color(0xFFFFC857)
                    cp.kind == CheckpointKind.POPUP -> Gold
                    else -> Color(0xFF62D9C7)
                }
                drawCircle(color.copy(alpha = 0.18f), 34f * pulse, Offset(cp.x - cameraX, sy(cp.y + 20f)))
                drawRect(Color(0xFF37474F), Offset(cp.x - 3f - cameraX, sy(cp.y)), Size(6f, 82f * scaleY))
                val flag = drawPathScratch.apply { reset();
                    moveTo(cp.x - cameraX, sy(cp.y))
                    lineTo(cp.x + 43f - cameraX, sy(cp.y + 12f))
                    lineTo(cp.x - cameraX, sy(cp.y + 28f))
                    close()
                }
                drawPath(flag, color)
                if (level.number > 4 && cp.kind == CheckpointKind.DECOY && !active && (gameClock.elapsedMs / 250L) % 5L == 0L) drawCircle(Color(0xFFFF1744), 3f, Offset(cp.x + 31f - cameraX, sy(cp.y + 12f)))
            }

            level.crates.forEachIndexed { index, crate ->
                if (index in destroyedCrates) return@forEachIndexed
                val armed = index in crateTriggeredAt
                val shake = if (armed) sin(gameClock.elapsedMs / 28.0).toFloat() * 3.5f else 0f
                val left = crate.x - cameraX + shake
                drawRoundRect(Color(0xFF9A6A3A), Offset(left, sy(crate.y)), Size(54f, 54f * scaleY), androidx.compose.ui.geometry.CornerRadius(5f))
                drawLine(Color(0xFF4F311E), Offset(left, sy(crate.y)), Offset(left + 54f, sy(crate.y + 54f)), 5f)
                drawLine(Color(0xFF4F311E), Offset(left + 54f, sy(crate.y)), Offset(left, sy(crate.y + 54f)), 5f)
            }
            crateExplodedAt.toMap().forEach { (index, explodedAt) ->
                val age = gameClock.elapsedMs - explodedAt
                if (age !in 0L..380L) return@forEach
                val crate = level.crates.getOrNull(index) ?: return@forEach
                val progress = (age / 380f).coerceIn(0f, 1f)
                drawCircle(Color(0xFFFF8A00).copy(alpha = 1f - progress), 24f + 112f * progress, Offset(crate.x + 27f - cameraX, sy(crate.y + 27f)))
            }

            level.launchers.forEachIndexed { index, launcher ->
                val triggered = index in launcherTriggeredAt
                if (launcher.hiddenUntilTriggered && !triggered) return@forEachIndexed
                if (!visibleX(launcher.x - 24f, 48f, 260f)) return@forEachIndexed
                val pulse = if (triggered && index !in launcherFired) 0.55f + 0.45f * kotlin.math.abs(sin(gameClock.elapsedMs / 90.0).toFloat()) else 0.35f
                drawRoundRect(Color(0xFF4A4F55), Offset(launcher.x - 18f - cameraX, sy(launcher.y - 18f)), Size(36f, 36f * scaleY), androidx.compose.ui.geometry.CornerRadius(8f))
                drawCircle(Color(0xFFFFC857).copy(alpha = pulse), 7f, Offset(launcher.x - cameraX, sy(launcher.y)))
            }

            enemies.forEachIndexed { index, e ->
                if (!visibleX(e.x, 55f, 260f)) return@forEachIndexed
                if (e.health <= 0) return@forEachIndexed
                val model = level.enemies[index]
                if (model.hiddenUntilActivated && index !in activatedEnemies) return@forEachIndexed
                val kind = model.kind
                val color = when (kind) {
                    GameEnemyKind.WALKER -> Color(0xFF7B2CBF)
                    GameEnemyKind.JUMPER -> Color(0xFFE76F51)
                    GameEnemyKind.FLYER -> Color(0xFF00A6A6)
                    GameEnemyKind.SHOOTER -> Color(0xFFB5179E)
                    GameEnemyKind.GUARDIAN -> Color(0xFF5A189A)
                }
                drawRoundRect(color, Offset(e.x - cameraX, sy(e.y)), Size(50f, 56f * scaleY), androidx.compose.ui.geometry.CornerRadius(14f))
                drawCircle(Color.White, 5f, Offset(e.x + 15f - cameraX, sy(e.y + 18f)))
                drawCircle(Color.White, 5f, Offset(e.x + 35f - cameraX, sy(e.y + 18f)))
            }
            bullets.forEach { b -> drawCircle(Gold, 6f, Offset(b.x - cameraX, sy(b.y))) }
            enemyBullets.forEach { b -> drawCircle(Color(0xFFFF4D8D), 6f, Offset(b.x - cameraX, sy(b.y))) }

            level.crystals.forEachIndexed { index, c ->
                if (index in collected) return@forEachIndexed
                val p = drawPathScratch.apply { reset();
                    moveTo(c.x - cameraX, sy(c.y - 24f)); lineTo(c.x + 18f - cameraX, sy(c.y)); lineTo(c.x - cameraX, sy(c.y + 24f)); lineTo(c.x - 18f - cameraX, sy(c.y)); close()
                }
                drawPath(p, Color(0xFF00E5FF))
            }
            level.pickups.forEachIndexed { index, pickup ->
                if (index in collectedPickups) return@forEachIndexed
                val color = when (pickup.kind) {
                    GamePickupKind.ENERGY -> Color(0xFFFF5A5F)
                    GamePickupKind.SHIELD -> Color(0xFF56CFE1)
                    GamePickupKind.POWER -> Gold
                }
                drawCircle(color.copy(alpha = 0.25f), 24f, Offset(pickup.x - cameraX, sy(pickup.y)))
                drawCircle(color, 13f, Offset(pickup.x - cameraX, sy(pickup.y)))
            }

            level.keys.forEachIndexed { index, key ->
                val visible = playerX >= key.revealTriggerX && (key.hiddenUntilSwitch == null || key.hiddenUntilSwitch in activeSwitches)
                if (!visible || index in collectedKeys) return@forEachIndexed
                val pulse = 1f + sin(gameClock.elapsedMs / 170.0 + index).toFloat() * 0.12f
                val center = Offset(key.x - cameraX, sy(key.y))
                drawCircle(Gold.copy(alpha = 0.20f), 30f * pulse, center)
                drawCircle(Gold, 12f, center)
                drawCircle(Color(0xFF2C2B21), 5f, center)
                drawLine(Gold, Offset(center.x + 10f, center.y + 5f), Offset(center.x + 34f, center.y + 21f), 8f)
                drawLine(Gold, Offset(center.x + 26f, center.y + 16f), Offset(center.x + 21f, center.y + 27f), 6f)
                drawLine(Gold, Offset(center.x + 34f, center.y + 21f), Offset(center.x + 29f, center.y + 32f), 6f)
            }

            val exitReady = (!level.requiresKey || collectedKeys.size >= level.keys.size) && activeSwitches.size >= level.requiredMechanisms
            val exitX = level.goalX - cameraX
            val exitY = sy(level.goalY)
            val exitHeight = 135f * scaleY
            val readyColor = if (exitReady) NeonGreen else Color(0xFF68747A)
            when (level.exitKind) {
                LevelExitKind.DOOR -> {
                    drawRoundRect(Color(0xFF473A30), Offset(exitX - 18f, exitY), Size(76f, exitHeight), androidx.compose.ui.geometry.CornerRadius(18f))
                    drawRoundRect(if (exitReady) Color(0xFF8A633E) else Color(0xFF514B48), Offset(exitX - 11f, exitY + 7f), Size(62f, exitHeight - 7f), androidx.compose.ui.geometry.CornerRadius(15f))
                    repeat(4) { plank -> drawLine(Color(0xFF332A24).copy(alpha = 0.75f), Offset(exitX - 8f, exitY + 25f + plank * 24f * scaleY), Offset(exitX + 48f, exitY + 25f + plank * 24f * scaleY), 3f) }
                    drawCircle(if (exitReady) Gold else Color(0xFFB0BEC5), 6f, Offset(exitX + 34f, exitY + exitHeight * 0.55f))
                    if (!exitReady) {
                        drawRoundRect(Color(0xFF263238), Offset(exitX + 5f, exitY + exitHeight * 0.34f), Size(28f, 31f), androidx.compose.ui.geometry.CornerRadius(6f))
                        drawCircle(Color(0xFF263238), 11f, Offset(exitX + 19f, exitY + exitHeight * 0.34f))
                    }
                }
                LevelExitKind.CAVE, LevelExitKind.TUNNEL -> {
                    drawCircle(Color(0xFF253039), 55f, Offset(exitX + 18f, exitY + 48f))
                    drawRoundRect(Color(0xFF111922), Offset(exitX - 22f, exitY + 45f), Size(80f, exitHeight - 45f), androidx.compose.ui.geometry.CornerRadius(18f))
                    repeat(7) { rock ->
                        val angle = rock * Math.PI / 6.0
                        val rx = exitX + 18f + kotlin.math.cos(angle).toFloat() * 54f
                        val ry = exitY + 48f + sin(angle).toFloat() * 45f
                        drawCircle(Color(0xFF566169), 12f + rock % 3 * 3f, Offset(rx, ry))
                    }
                    drawCircle(readyColor.copy(alpha = 0.22f), 28f, Offset(exitX + 18f, exitY + 76f))
                }
                LevelExitKind.ASCENT, LevelExitKind.SUMMIT -> {
                    repeat(4) { step ->
                        val w = 82f - step * 12f
                        drawRoundRect(Color(0xFF82715E), Offset(exitX - 24f + step * 6f, exitY + exitHeight - 22f - step * 23f), Size(w, 18f), androidx.compose.ui.geometry.CornerRadius(5f))
                    }
                    drawLine(readyColor, Offset(exitX + 18f, exitY + 15f), Offset(exitX + 18f, exitY + 72f), 7f)
                    val arrow = drawPathScratch.apply { reset(); moveTo(exitX + 18f, exitY + 5f); lineTo(exitX, exitY + 30f); lineTo(exitX + 36f, exitY + 30f); close() }
                    drawPath(arrow, readyColor)
                }
                LevelExitKind.DESCENT -> {
                    drawRoundRect(Color(0xFF403A35), Offset(exitX - 25f, exitY + 30f), Size(86f, exitHeight - 30f), androidx.compose.ui.geometry.CornerRadius(16f))
                    repeat(4) { step -> drawRect(Color(0xFF766656), Offset(exitX - 18f + step * 5f, exitY + 48f + step * 22f), Size(72f - step * 10f, 13f)) }
                    val arrow = drawPathScratch.apply { reset(); moveTo(exitX + 18f, exitY + exitHeight - 4f); lineTo(exitX, exitY + exitHeight - 30f); lineTo(exitX + 36f, exitY + exitHeight - 30f); close() }
                    drawPath(arrow, readyColor)
                }
                LevelExitKind.LIFT -> {
                    drawRoundRect(Color(0xFF455A64), Offset(exitX - 28f, exitY + 5f), Size(92f, exitHeight - 5f), androidx.compose.ui.geometry.CornerRadius(9f))
                    drawLine(Color(0xFF90A4AE), Offset(exitX - 4f, exitY + 8f), Offset(exitX - 4f, exitY + exitHeight - 5f), 5f)
                    drawLine(Color(0xFF90A4AE), Offset(exitX + 40f, exitY + 8f), Offset(exitX + 40f, exitY + exitHeight - 5f), 5f)
                    drawCircle(readyColor, 8f, Offset(exitX + 53f, exitY + 23f))
                }
                LevelExitKind.BRIDGE -> {
                    repeat(6) { plank -> drawRoundRect(Color(0xFF805335), Offset(exitX - 35f + plank * 22f, exitY + 78f + sin(gameClock.elapsedMs / 360.0 + plank).toFloat() * 3f), Size(19f, 16f), androidx.compose.ui.geometry.CornerRadius(3f)) }
                    drawLine(Color(0xFF4D3526), Offset(exitX - 40f, exitY + 70f), Offset(exitX + 98f, exitY + 70f), 4f)
                    drawLine(Color(0xFF4D3526), Offset(exitX - 40f, exitY + 104f), Offset(exitX + 98f, exitY + 104f), 4f)
                    drawCircle(readyColor.copy(alpha = 0.22f), 27f, Offset(exitX + 75f, exitY + 86f))
                }
                LevelExitKind.RUIN_GATE -> {
                    drawRect(Color(0xFF8B7357), Offset(exitX - 25f, exitY + 6f), Size(20f, exitHeight - 6f))
                    drawRect(Color(0xFF8B7357), Offset(exitX + 48f, exitY + 6f), Size(20f, exitHeight - 6f))
                    drawRect(Color(0xFFA78B67), Offset(exitX - 36f, exitY), Size(115f, 22f))
                    drawRoundRect(Color(0xFF30271F), Offset(exitX - 2f, exitY + 35f), Size(45f, exitHeight - 35f), androidx.compose.ui.geometry.CornerRadius(14f))
                    drawCircle(readyColor.copy(alpha = 0.25f), 25f, Offset(exitX + 20f, exitY + 78f))
                }
                LevelExitKind.TRAIL -> {
                    val trail = drawPathScratch.apply { reset(); moveTo(exitX - 35f, exitY + exitHeight); quadraticBezierTo(exitX + 8f, exitY + 55f, exitX + 80f, exitY + 26f); lineTo(exitX + 100f, exitY + 64f); quadraticBezierTo(exitX + 25f, exitY + 96f, exitX - 12f, exitY + exitHeight); close() }
                    drawPath(trail, Color(0xFF9B7B55))
                    drawCircle(readyColor.copy(alpha = 0.24f), 27f, Offset(exitX + 65f, exitY + 46f))
                }
            }

            if (level.acechantePresent) {
                drawRoundRect(Color(0xFF08050D), Offset(acechanteX - cameraX, sy(playerY - 25f)), Size(42f, 98f * scaleY), androidx.compose.ui.geometry.CornerRadius(18f))
                drawCircle(Color.White, 3.5f, Offset(acechanteX + 12f - cameraX, sy(playerY + 1f)))
                drawCircle(Color.White, 3.5f, Offset(acechanteX + 29f - cameraX, sy(playerY + 1f)))
            }

            level.companion?.let { name ->
                val cx = playerX - 63f
                val color = if (name == "Luma") Color(0xFF62D9C7) else Color(0xFF7CB342)
                drawCircle(color.copy(alpha = 0.24f), 31f, Offset(cx - cameraX, sy(playerY + 34f)))
                drawCircle(color, 22f, Offset(cx - cameraX, sy(playerY + 34f)))
            }

            val basePlayerColor = if (run.lifeType == "premium") Gold else Color(0xFFE53935)
            val invulnerableBlink = gameClock.elapsedMs < invulnerableUntil && (gameClock.elapsedMs / 110L) % 2L == 0L
            val playerColor = basePlayerColor.copy(alpha = if (invulnerableBlink) 0.42f else 1f)
            val conduitScale = conduitTransit?.let { transit ->
                val progress = ((gameClock.elapsedMs - transit.startedAt) / 620f).coerceIn(0f, 1f)
                (1f - sin(progress.toDouble() * Math.PI).toFloat() * 0.42f).coerceAtLeast(0.58f)
            } ?: 1f
            val landingAge = gameClock.elapsedMs - lastLandingAt
            val jumpAge = gameClock.elapsedMs - lastJumpAt
            val doubleJumpAge = gameClock.elapsedMs - lastDoubleJumpAt
            val impactStrength = (lastLandingImpact / 780f).coerceIn(0f, 1f)
            val (slimeWidthScale, slimeHeightScale) = when {
                landingAge in 0L..125L -> {
                    val recovery = landingAge / 125f
                    val squash = (1f - recovery) * (0.20f + impactStrength * 0.12f)
                    (1f + squash) to (1f - squash * 0.82f)
                }
                doubleJumpAge in 0L..115L -> {
                    val pulse = 1f - doubleJumpAge / 115f
                    (1f - 0.15f * pulse) to (1f + 0.22f * pulse)
                }
                jumpAge in 0L..105L -> {
                    val pulse = 1f - jumpAge / 105f
                    (1f - 0.11f * pulse) to (1f + 0.17f * pulse)
                }
                !onGround && velocityY < -120f -> 0.91f to 1.12f
                !onGround && velocityY > 220f -> 0.94f to 1.09f
                moveDirection != 0f && onGround -> {
                    val wobble = sin(gameClock.elapsedMs / 95.0).toFloat() * 0.025f
                    (1f + wobble) to (1f - wobble)
                }
                else -> 1f to 1f
            }
            val displayWidth = playerWidth * slimeWidthScale * conduitScale
            val displayHeight = playerHeight * slimeHeightScale * conduitScale
            val displayX = playerX + (playerWidth - displayWidth) / 2f
            val displayPlayerY = playerY + (playerHeight - displayHeight)
            if (!onGround && jumpsRemaining > 0 && !deathPending) drawCircle(Color(0xFF8EF6E4).copy(alpha = 0.15f), 36f, Offset(playerX + playerWidth / 2f - cameraX, sy(playerY + playerHeight / 2f)))
            val hideVoidDeath = deathPending && deathCause == DeathCause.VOID
            val suppressRespawnGhost = gameClock.elapsedMs < suppressPlayerUntil
            if (!hideVoidDeath && !suppressRespawnGhost) {
                drawRoundRect(playerColor, Offset(displayX - cameraX, sy(displayPlayerY)), Size(displayWidth, displayHeight * scaleY), androidx.compose.ui.geometry.CornerRadius(12f))
                if (conduitScale > 0.35f) {
                    drawCircle(Color.White, 5f * conduitScale, Offset(displayX + displayWidth * 0.30f - cameraX, sy(displayPlayerY + displayHeight * 0.31f)))
                    drawCircle(Color.White, 5f * conduitScale, Offset(displayX + displayWidth * 0.70f - cameraX, sy(displayPlayerY + displayHeight * 0.31f)))
                }
            }

            if (level.biome == AdventureBiome.FOREST_DAY || level.biome == AdventureBiome.FOREST_SUNSET) {
                repeat(10) { i ->
                    val leafX = ((i * 149f - cameraX * 0.70f + gameClock.elapsedMs / (25f + i % 3 * 5f)) % (viewportWidth + 300f)) - 100f
                    val leafY = sy(185f + (i * 79 % 430))
                    val leafColor = if (level.biome == AdventureBiome.FOREST_DAY) Color(0xFF9CCC65) else Color(0xFFFFB05A)
                    drawOval(leafColor.copy(alpha = 0.18f), Offset(leafX, leafY), Size(17f, 7f))
                }
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 10.dp, top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HudPill("❤️", "$livesRemaining/$maxLives", Color(0xFFE53935))
            if (level.requiresKey) HudPill("🔑", "${collectedKeys.size}/${level.keys.size}", Gold)
            if (level.requiredMechanisms > 0) HudPill("⚙", "${activeSwitches.size}/${level.requiredMechanisms}", Color(0xFF90A4AE))
        }

        IconButton(
            onClick = { paused = true },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 8.dp, end = 10.dp)
                .size(32.dp)
                .background(Color(0xB20A1823), CircleShape)
        ) { Icon(Icons.Rounded.Pause, contentDescription = "Pausa") }

        objectiveHint?.let { hint ->
            Card(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 58.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xDD0B321E)),
                shape = RoundedCornerShape(16.dp)
            ) { Text(hint, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp), color = Gold, fontWeight = FontWeight.Bold) }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HoldButton(Icons.Rounded.ArrowBack, "Izquierda") { pressed -> moveDirection = if (pressed) -1f else if (moveDirection < 0f) 0f else moveDirection }
                HoldButton(Icons.Rounded.ArrowForward, "Derecha") { pressed -> moveDirection = if (pressed) 1f else if (moveDirection > 0f) 0f else moveDirection }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (level.weaponEnabled || weaponPowerUntil > gameClock.elapsedMs) HoldButton(Icons.Rounded.PlayArrow, "Disparar", accent = Gold) { if (it) shootQueued = true }
                HoldButton(Icons.Rounded.TouchApp, "Interactuar", accent = Color(0xFF62D9C7)) { if (it) interactQueued = true }
                HoldButton(Icons.Rounded.KeyboardArrowUp, "Doble salto", accent = NeonGreen) { if (it) jumpQueued = true }
            }
        }

        if (paused) {
            OverlayCard(title = "Partida en pausa", compact = true) {
                Text("N${level.number} · ${level.levelName}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                Button(
                    onClick = { paused = false },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) { Text("Continuar", fontWeight = FontWeight.Bold) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedButton(
                        onClick = { musicEnabled = !musicEnabled },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (musicEnabled) "Música: sí" else "Música: no") }
                    OutlinedButton(
                        onClick = { effectsEnabled = !effectsEnabled },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (effectsEnabled) "Efectos: sí" else "Efectos: no") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedButton(
                        onClick = { vibrationEnabled = !vibrationEnabled },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (vibrationEnabled) "Vibración: sí" else "Vibración: no") }
                    OutlinedButton(
                        onClick = {
                            val enableAll = !(musicEnabled || effectsEnabled)
                            musicEnabled = enableAll
                            effectsEnabled = enableAll
                        },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (musicEnabled || effectsEnabled) "Silenciar" else "Activar sonido") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    TextButton(
                        onClick = {
                            paused = false
                            pendingExitTarget = ExitTarget.LEVELS
                            endGame(GameOutcome.LOST)
                        },
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) { Text("Volver a niveles") }
                    TextButton(
                        onClick = {
                            paused = false
                            pendingExitTarget = ExitTarget.GEO_ADVENTURES
                            endGame(GameOutcome.LOST)
                        },
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) { Text("Salir del juego", color = Color(0xFFFFB4AB)) }
                }
            }
        }

        LaunchedEffect(resultSaved, pendingExitTarget) {
            if (!resultSaved) return@LaunchedEffect
            when (pendingExitTarget) {
                ExitTarget.LEVELS -> onExit()
                ExitTarget.GEO_ADVENTURES -> onQuit()
                null -> Unit
            }
            pendingExitTarget = null
        }

        LaunchedEffect(outcome, resultSaved, pendingExitTarget) {
            val finalOutcome = outcome ?: return@LaunchedEffect
            if (!resultSaved || pendingExitTarget != null || autoTransitionStarted) return@LaunchedEffect
            autoTransitionStarted = true
            when (finalOutcome) {
                GameOutcome.WON -> {
                    delay(if (level.outroStory != null) 2_500L else 1_450L)
                    if (level.number < GeoGameRules.LEVEL_COUNT) onAdvance(level.number + 1, run.lifeType) else onExit()
                }
                GameOutcome.LOST -> {
                    delay(1_350L)
                    onExit()
                }
            }
        }

        if (outcome != null) {
            OverlayCard(title = if (outcome == GameOutcome.WON) "¡Nivel superado!" else "Vidas 0/$maxLives") {
                Text("Checkpoints: ${activatedCheckpoints.size} · Muertes: $deathCount · Tiempo: ${elapsedSeconds}s")
                if (outcome == GameOutcome.WON) {
                    level.outroStory?.let { Text(it, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Text(
                        if (level.number < GeoGameRules.LEVEL_COUNT) "Continuando automáticamente al nivel ${level.number + 1}…" else "Aventura completada. Regresando al mapa…",
                        color = NeonGreen,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text("La partida terminó. Regresando automáticamente a la selección de niveles…", color = Gold, textAlign = TextAlign.Center)
                }
                resultError?.let {
                    Text(it, color = Color(0xFFFFB4AB), textAlign = TextAlign.Center)
                    Button(
                        onClick = { reportAttempt++ },
                        enabled = !reportingResult,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                    ) {
                        if (reportingResult) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = DeepGreen)
                        else Icon(Icons.Rounded.Refresh, contentDescription = null)
                        Text(" Reintentar guardado")
                    }
                }
            }
        }
    }
}

@Composable
private fun HudPill(symbol: String, value: String, accent: Color) {
    Row(
        modifier = Modifier
            .background(Color(0xC70A1823), RoundedCornerShape(12.dp))
            .padding(horizontal = 7.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(symbol, style = MaterialTheme.typography.bodySmall)
        Text(value, color = accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun HoldButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    accent: Color = Color(0xFF90A4AE),
    onPressed: (Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .size(62.dp)
            .background(Color(0xD91A2C38), CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    onPressed(true)
                    tryAwaitRelease()
                    onPressed(false)
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = accent, modifier = Modifier.size(32.dp))
    }
}

@Composable
private fun OverlayCard(
    title: String,
    compact: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.78f)), contentAlignment = Alignment.Center) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth(if (compact) 0.70f else 0.62f)
        ) {
            Column(
                Modifier.padding(horizontal = if (compact) 18.dp else 22.dp, vertical = if (compact) 14.dp else 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 11.dp)
            ) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                content()
            }
        }
    }
}

@Composable
private fun ImmersiveLandscapeEffect() {
    val context = LocalContext.current
    DisposableEffect(context) {
        val activity = context.findActivity()
        val previousOrientation = activity?.requestedOrientation
        val window = activity?.window
        val previousSystemUiVisibility = window?.decorView?.systemUiVisibility
        val previousWindowFlags = window?.attributes?.flags
        val previousCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window?.attributes?.layoutInDisplayCutoutMode
        } else null

        fun applyImmersive() {
            val targetWindow = window ?: return
            val appBackground = android.graphics.Color.rgb(4, 13, 19)
            targetWindow.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(appBackground))
            targetWindow.decorView.setBackgroundColor(appBackground)
            targetWindow.decorView.setPadding(0, 0, 0, 0)
            targetWindow.decorView.fitsSystemWindows = false
            targetWindow.statusBarColor = android.graphics.Color.TRANSPARENT
            targetWindow.navigationBarColor = android.graphics.Color.TRANSPARENT
            targetWindow.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN or
                    android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                targetWindow.navigationBarDividerColor = android.graphics.Color.TRANSPARENT
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                targetWindow.isStatusBarContrastEnforced = false
                targetWindow.isNavigationBarContrastEnforced = false
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                targetWindow.attributes = targetWindow.attributes.apply {
                    layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    } else {
                        android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
                }
            }
            WindowCompat.setDecorFitsSystemWindows(targetWindow, false)
            ViewCompat.setOnApplyWindowInsetsListener(targetWindow.decorView) { _, _ ->
                WindowInsetsCompat.CONSUMED
            }
            ViewCompat.requestApplyInsets(targetWindow.decorView)
            @Suppress("DEPRECATION")
            run {
                targetWindow.decorView.systemUiVisibility =
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }
            WindowInsetsControllerCompat(targetWindow, targetWindow.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }

        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        applyImmersive()
        val focusListener = android.view.ViewTreeObserver.OnWindowFocusChangeListener { hasFocus ->
            if (hasFocus) applyImmersive()
        }
        window?.decorView?.viewTreeObserver?.addOnWindowFocusChangeListener(focusListener)

        onDispose {
            window?.decorView?.viewTreeObserver?.let { observer ->
                if (observer.isAlive) observer.removeOnWindowFocusChangeListener(focusListener)
            }
            window?.let { targetWindow ->
                val appBackground = android.graphics.Color.rgb(6, 29, 18)
                targetWindow.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(appBackground))
                targetWindow.decorView.setBackgroundColor(appBackground)
                targetWindow.statusBarColor = appBackground
                targetWindow.navigationBarColor = appBackground
                ViewCompat.setOnApplyWindowInsetsListener(targetWindow.decorView, null)
                ViewCompat.requestApplyInsets(targetWindow.decorView)
                if (previousWindowFlags != null) {
                    targetWindow.attributes = targetWindow.attributes.apply { flags = previousWindowFlags }
                }
                if (previousSystemUiVisibility != null) {
                    @Suppress("DEPRECATION")
                    run { targetWindow.decorView.systemUiVisibility = previousSystemUiVisibility }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && previousCutoutMode != null) {
                    targetWindow.attributes = targetWindow.attributes.apply {
                        layoutInDisplayCutoutMode = previousCutoutMode
                    }
                }
                WindowInsetsControllerCompat(targetWindow, targetWindow.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
                WindowCompat.setDecorFitsSystemWindows(targetWindow, true)
            }
            if (previousOrientation != null) activity?.requestedOrientation = previousOrientation
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
