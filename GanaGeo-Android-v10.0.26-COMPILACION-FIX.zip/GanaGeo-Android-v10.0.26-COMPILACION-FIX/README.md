# Gana Geo Android v0.10.26

Reconstrucción **FULL TROLL** de los 20 niveles de Geo Aventuras sobre el motor optimizado de v0.10.24. La prioridad de esta versión es que el juego vuelva a ser muy difícil desde el nivel 1, con trampas frecuentes, ocultas, deterministas y aprendibles, sin convertir la dificultad en geometría imposible o en spam de pinchos visibles.

## Cambios principales

- Los **20 niveles** fueron endurecidos y ampliados con consecuencias troll adicionales por sala.
- Cada nivel mantiene al menos **30 amenazas reales** distribuidas por el recorrido.
- Pinchos/fuego letales visibles se convierten en trampas ocultas y camufladas que se revelan por trigger.
- Enemigos terrestres y aéreos quedan ocultos hasta que GEO cruza su zona de activación.
- Lanzadores/proyectiles sorpresa permanecen ocultos hasta el trigger.
- Prensas, muros y bloques de ruina no se dibujan antes de activarse.
- Plantas trampa permanecen dentro del conducto/raíz hasta que GEO se compromete con la zona; tienen una breve animación de salida antes de ser letales.
- Se añaden segundas consecuencias ocultas a las salas; desde niveles avanzados varias salas encadenan una tercera amenaza.
- Se amplían especialmente los niveles 2, 3, 5 y 19, que estaban demasiado escasos en versiones previas.
- La densidad de pinchos queda limitada: los niveles no pueden depender principalmente de ellos; parte del exceso se sustituye por proyectiles y otras familias de trampas.
- Se rellenan automáticamente tramos demasiado tranquilos con emboscadas ocultas sin alterar la ruta física.
- Se conserva el motor de v0.10.24: timestep fijo de 120 Hz, índice espacial de colisiones, menos estado reactivo de Compose, menos asignaciones por frame y movimiento suavizado.

## Filosofía jugable

- La primera ejecución puede sorprender y matar.
- El mismo trigger produce el mismo comportamiento en los siguientes intentos.
- La solución depende de memoria, timing, reacción o un salto bien ejecutado; no de azar.
- La dificultad no se consigue mostrando la trampa desde lejos ni cerrando físicamente la única ruta.
- Checkpoints reales siguen siendo zonas de respiro, pero el recorrido vuelve a tener tensión inmediatamente después.

## Validación local

- **33/33 pruebas PASS** con runner Kotlin local.
- Los 20 niveles conservan ruta física y fallback permanente.
- Amenazas mínimas: 30 por nivel.
- Trampas letales principales no se anuncian antes de que GEO se comprometa.
- Ningún tramo normal supera el límite de 1060 px entre triggers/checkpoints de tensión.
- La proporción de pinchos se mantiene en 30 % o menos del conjunto de amenazas.
- Fábrica de niveles y soporte runtime compilados con `kotlinc`.

## Protección de módulos

No se modifican login, Google, Supabase, sesión, persistencia, créditos, Geo Rewards, referidos, retiros ni las demás herramientas de Gana Geo. Los archivos protegidos se vuelven a verificar por SHA-256 antes del empaquetado.

## Build Android

El build Android completo usa Gradle 8.13. Si `services.gradle.org` no es accesible desde este entorno, la verificación final del APK debe hacerse mediante GitHub Actions o el entorno normal de compilación del proyecto. Las pruebas locales no sustituyen una prueba real en teléfono.
