package com.ganageo.app.tools

import kotlin.math.min


data class GamePlatform(val x: Float, val y: Float, val width: Float, val height: Float = 34f)
data class GameHazard(val x: Float, val y: Float, val width: Float = 58f, val height: Float = 42f)

enum class GameEnemyKind { WALKER, JUMPER, FLYER, SHOOTER, GUARDIAN }

data class GameEnemy(
    val x: Float,
    val y: Float,
    val range: Float = 120f,
    val detectionRange: Float = 480f,
    val health: Int = 2,
    val kind: GameEnemyKind = GameEnemyKind.WALKER,
    val speed: Float = 72f
)

data class GameCrystal(val x: Float, val y: Float)
data class GameCrate(val x: Float, val y: Float)
data class GameSwitch(val x: Float, val y: Float, val opensAtX: Float)

enum class GamePickupKind { ENERGY, SHIELD, POWER }

data class GamePickup(val x: Float, val y: Float, val kind: GamePickupKind)

data class GameMovingPlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val travel: Float,
    val vertical: Boolean,
    val periodSeconds: Float = 3.4f
)

data class AdventureLevel(
    val number: Int,
    val worldName: String,
    val levelName: String,
    val objective: String,
    val width: Float,
    val platforms: List<GamePlatform>,
    val movingPlatforms: List<GameMovingPlatform>,
    val hazards: List<GameHazard>,
    val enemies: List<GameEnemy>,
    val crystals: List<GameCrystal>,
    val crates: List<GameCrate>,
    val switches: List<GameSwitch>,
    val pickups: List<GamePickup>,
    val goalX: Float,
    val parSeconds: Int,
    val introStory: String? = null,
    val outroStory: String? = null,
    val companion: String? = null,
    val injured: Boolean = false,
    val weaponEnabled: Boolean = false,
    val acechantePresent: Boolean = false
)

object GeoAdventureLevelFactory {
    private val names = listOf(
        "Después del impacto", "La noche interminable", "Agua y medicina", "No estás solo",
        "Primeros impulsos", "El refugio de Luma", "Una deuda con el bosque", "Los cazadores",
        "El paso oculto", "La voz de la piedra", "El primer defensor", "La emboscada",
        "Recuperar la energía", "La torre olvidada", "Una luz en las montañas", "El precio de la señal",
        "Sin mirar atrás", "El bosque silencioso", "Los restos equivocados", "La nave sigue viva"
    )

    private val intros = mapOf(
        1 to "La cápsula cayó en una selva desconocida. GEO despierta dañado, con poca energía y recuerdos incompletos. Antes de buscar su nave deberá sobrevivir.",
        5 to "Luma ha decidido acompañar a GEO. Todavía no hablan el mismo idioma, pero ambos comprenden que solos no llegarán lejos.",
        9 to "Las ruinas reaccionan al objeto que GEO protege. Algunos habitantes quieren ayudarlo; otros creen que su llegada condenará al planeta.",
        13 to "GEO recupera parte de su energía. Taro, un guardián que antes desconfiaba de él, acepta guiarlos hacia una antigua torre.",
        17 to "La torre cayó y Taro quedó atrás para salvarlos. GEO continúa con Luma, cargando culpa, tristeza y una nueva determinación."
    )

    private val outros = mapOf(
        4 to "Luma cura las grietas del cuerpo de GEO y se queda a su lado durante la noche. En la oscuridad, algo deja marcas profundas en los árboles.",
        8 to "GEO muestra sin querer un recuerdo de la persecución. Luma comprende que no vino a conquistar su mundo: está escapando de algo mucho peor.",
        12 to "Taro observa a GEO ayudar a un habitante herido y empieza a confiar en él. Un sonido lejano confirma que el Acechante también sobrevivió.",
        16 to "Taro sostiene la compuerta para que GEO y Luma escapen. La torre se derrumba. No se sabe si sobrevivió. GEO quiere volver, pero ya es demasiado tarde.",
        20 to "Desde la montaña, GEO ve por fin su nave principal. Una luz débil confirma que sigue viva, pero una alerta aparece: acceso interno detectado. Algo ya está dentro. Continuará…"
    )

    fun build(number: Int): AdventureLevel {
        val safeLevel = number.coerceIn(1, GeoGameRules.LEVEL_COUNT)
        val worldIndex = (safeLevel - 1) / 5
        val width = 8_100f + safeLevel * 260f
        val platforms = mutableListOf<GamePlatform>()
        val movingPlatforms = mutableListOf<GameMovingPlatform>()
        val hazards = mutableListOf<GameHazard>()
        val enemies = mutableListOf<GameEnemy>()
        val crates = mutableListOf<GameCrate>()
        val switches = mutableListOf<GameSwitch>()
        val pickups = mutableListOf<GamePickup>()

        var x = 0f
        var segment = 0
        while (x < width - 720f) {
            val difficulty = worldIndex + safeLevel / 6
            val hardGap = segment > 1 && (segment + safeLevel) % 3 == 0
            val gap = if (hardGap) 190f + difficulty * 24f else 68f + (segment % 3) * 16f
            val length = 360f + ((segment * 79 + safeLevel * 37) % 280)
            platforms += GamePlatform(x, 620f, min(length, width - x))

            if (segment > 0 && (segment + safeLevel) % 2 == 0) {
                val elevatedY = 490f - ((segment + safeLevel) % 3) * 45f
                platforms += GamePlatform(x + 95f, elevatedY, 150f + (segment % 3) * 32f)
            }
            if (safeLevel >= 4 && segment > 2 && (segment + safeLevel) % 6 == 0) {
                movingPlatforms += GameMovingPlatform(
                    x = x + length + 12f,
                    y = 510f - (segment % 2) * 95f,
                    width = 145f,
                    travel = 105f + worldIndex * 28f,
                    vertical = segment % 2 == 0,
                    periodSeconds = (3.8f - worldIndex * 0.35f).coerceAtLeast(2.2f)
                )
            }
            if (segment > 0 && (segment + safeLevel) % 3 == 0) {
                hazards += GameHazard(x + length * 0.54f, 578f, width = 62f + difficulty * 4f)
            }
            if (segment > 1 && (segment + safeLevel) % 2 == 0) {
                val kind = when {
                    safeLevel >= 16 && segment % 8 == 0 -> GameEnemyKind.GUARDIAN
                    safeLevel >= 11 && segment % 5 == 0 -> GameEnemyKind.SHOOTER
                    safeLevel >= 8 && segment % 4 == 0 -> GameEnemyKind.FLYER
                    safeLevel >= 5 && segment % 3 == 0 -> GameEnemyKind.JUMPER
                    else -> GameEnemyKind.WALKER
                }
                val enemyY = if (kind == GameEnemyKind.FLYER) 395f else 568f
                enemies += GameEnemy(
                    x = x + length * 0.32f,
                    y = enemyY,
                    range = 85f + difficulty * 18f,
                    detectionRange = 420f + safeLevel * 18f,
                    health = when (kind) {
                        GameEnemyKind.GUARDIAN -> 7 + worldIndex
                        GameEnemyKind.SHOOTER -> 3 + worldIndex
                        else -> 2 + safeLevel / 8
                    },
                    kind = kind,
                    speed = when (kind) {
                        GameEnemyKind.FLYER -> 96f + safeLevel * 2f
                        GameEnemyKind.JUMPER -> 92f + safeLevel * 2f
                        GameEnemyKind.GUARDIAN -> 68f + safeLevel
                        else -> 78f + safeLevel * 1.8f
                    }
                )
                if (safeLevel >= 10 && segment % 6 == 0) {
                    enemies += GameEnemy(
                        x = x + length * 0.68f,
                        y = 568f,
                        range = 80f,
                        detectionRange = 520f,
                        health = 2 + worldIndex,
                        kind = GameEnemyKind.WALKER,
                        speed = 92f + safeLevel * 1.5f
                    )
                }
            }
            if (segment > 2 && segment % 5 == 0) crates += GameCrate(x + 78f, 566f)
            if (segment > 3 && segment % 8 == 0) switches += GameSwitch(x + 72f, 570f, x + length - 70f)
            if (segment > 2 && segment % 7 == 0) {
                val kind = when ((segment + safeLevel) % 3) {
                    0 -> GamePickupKind.ENERGY
                    1 -> GamePickupKind.SHIELD
                    else -> GamePickupKind.POWER
                }
                pickups += GamePickup(x + length * 0.72f, 530f, kind)
            }

            x += length + gap
            segment++
        }
        platforms += GamePlatform((width - 760f).coerceAtLeast(0f), 620f, 760f)

        fun reachableCrystal(ratio: Float): GameCrystal {
            val targetX = width * ratio
            val platform = platforms.minByOrNull { candidate ->
                when {
                    targetX < candidate.x -> candidate.x - targetX
                    targetX > candidate.x + candidate.width -> targetX - (candidate.x + candidate.width)
                    else -> 0f
                }
            } ?: platforms.first()
            val crystalX = targetX.coerceIn(
                platform.x + 45f,
                (platform.x + platform.width - 45f).coerceAtLeast(platform.x + 45f)
            )
            return GameCrystal(crystalX, platform.y - 92f)
        }

        val companion = when (safeLevel) {
            in 5..10, in 17..20 -> "Luma"
            in 11..16 -> "Taro"
            else -> null
        }
        val objective = when (safeLevel) {
            in 1..4 -> "Sobrevive al impacto, usa el doble salto y encuentra energía sin alejarte demasiado del refugio."
            in 5..8 -> "Ayuda a Luma, supera trampas, derrota a los cazadores y activa los mecanismos del bosque."
            in 9..12 -> "Cruza las ruinas, destruye obstáculos y descubre por qué reaccionan al núcleo."
            in 13..16 -> "Recupera energía, activa la torre y protege a tus aliados de enemigos coordinados."
            else -> "Sigue la señal, evita al Acechante y atraviesa las zonas más peligrosas hasta localizar la nave."
        }

        return AdventureLevel(
            number = safeLevel,
            worldName = GeoGameRules.worldName(safeLevel),
            levelName = names[safeLevel - 1],
            objective = objective,
            width = width,
            platforms = platforms,
            movingPlatforms = movingPlatforms,
            hazards = hazards,
            enemies = enemies,
            crystals = listOf(reachableCrystal(0.20f), reachableCrystal(0.49f), reachableCrystal(0.80f)),
            crates = crates,
            switches = switches,
            pickups = pickups,
            goalX = width - 190f,
            parSeconds = 100 + safeLevel * 5,
            introStory = intros[safeLevel],
            outroStory = outros[safeLevel],
            companion = companion,
            injured = safeLevel <= 3,
            weaponEnabled = safeLevel >= 5,
            acechantePresent = safeLevel >= 18
        )
    }
}
