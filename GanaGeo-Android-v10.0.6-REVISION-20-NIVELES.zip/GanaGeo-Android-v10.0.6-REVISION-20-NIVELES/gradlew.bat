@echo off
setlocal
set GRADLE_VERSION=8.13
set BASE_DIR=%USERPROFILE%\.gradle\manual-wrapper
set DIST_DIR=%BASE_DIR%\gradle-%GRADLE_VERSION%
set ZIP_FILE=%BASE_DIR%\gradle-%GRADLE_VERSION%-bin.zip
set GRADLE_BIN=%DIST_DIR%\bin\gradle.bat

if exist "%GRADLE_BIN%" goto run
if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"

if not exist "%ZIP_FILE%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_FILE%'"
  if errorlevel 1 exit /b 1
)

if exist "%DIST_DIR%" rmdir /S /Q "%DIST_DIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP_FILE%' -DestinationPath '%BASE_DIR%' -Force"
if errorlevel 1 exit /b 1

:run
call "%GRADLE_BIN%" %*
endlocal
