# Gana Geo Android v0.9.9 — Suelo que se abre

Versión basada en v0.9.7. Mantiene intactos el acceso con Google, Supabase, créditos, Geo Rewards, referidos, retiros y las herramientas ajenas a Geo Aventuras.

## Cambios principales

- Menú de pausa compacto y completo, sin desplazamiento.
- Eliminada la opción de reiniciar desde el checkpoint.
- Controles táctiles y sus iconos ligeramente más grandes.
- Muerte por trampas visible durante 1 segundo, sin texto explicativo.
- Caída al vacío con reaparición casi inmediata.
- El hueco negro independiente fue eliminado.
- La trampa ahora retira una parte rectangular del piso real y GEO cae naturalmente al vacío.
- Huecos perseguidores ocasionales: solo aparecen en dos de los primeros cuatro niveles.
- La abertura solo avanza por una plataforma sólida continua y se cierra al llegar al borde.
- Las zonas con hueco no mezclan pinchos, objetos que caen, enemigos, ventiladores ni aplastadores cercanos.
- Checkpoints reales continúan sobre plataformas sólidas permanentes.
- Se mantienen 15 vidas internas por partida y la dificultad extrema.

## Compilación

GitHub Actions ejecuta pruebas unitarias y genera `app-debug.apk`. Deben existir los secretos `SUPABASE_ANON_KEY` y `GOOGLE_WEB_CLIENT_ID`.
