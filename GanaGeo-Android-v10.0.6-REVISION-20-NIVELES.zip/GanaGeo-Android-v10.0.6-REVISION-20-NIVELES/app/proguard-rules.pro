# Mantener modelos serializables de Kotlinx Serialization.
-keepattributes *Annotation*, InnerClasses
-dontwarn io.ktor.**
