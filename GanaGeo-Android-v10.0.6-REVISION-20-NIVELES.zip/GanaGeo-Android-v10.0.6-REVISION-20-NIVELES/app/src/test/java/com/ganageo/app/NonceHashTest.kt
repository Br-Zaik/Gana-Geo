package com.ganageo.app

import org.junit.Assert.assertEquals
import org.junit.Test

class NonceHashTest {
    @Test
    fun sha256Hex_matchesKnownVector() {
        assertEquals(
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            sha256Hex("abc")
        )
    }
}
