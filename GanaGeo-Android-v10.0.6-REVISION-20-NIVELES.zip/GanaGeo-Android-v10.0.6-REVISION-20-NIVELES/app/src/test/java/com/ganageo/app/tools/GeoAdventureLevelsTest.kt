package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class GeoAdventureLevelsTest {
    @Test
    fun createsTwentyExtremeLevelDefinitions() {
        val levels = (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build)
        assertEquals(20, levels.size)
        levels.forEach { level ->
            assertTrue(level.width >= 6_300f)
            assertEquals(3, level.crystals.size)
            assertTrue(level.enemies.isNotEmpty())
            assertTrue(level.hazards.size >= 10)
            assertTrue(level.checkpoints.size in 4..8)
            assertTrue(level.fans.isNotEmpty())
            assertTrue(level.fallingObjects.isNotEmpty())
            level.crystals.forEach { crystal ->
                assertTrue(level.platforms.any { platform ->
                    crystal.x in platform.x..(platform.x + platform.width) &&
                        crystal.y == platform.y - 92f
                })
            }
            assertTrue(level.platforms.any { it.x <= 70f && it.x + it.width > 70f })
            assertTrue(level.platforms.any { it.x <= level.goalX && it.x + it.width >= level.goalX })
            assertTrue(level.parSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS)
        }
    }

    @Test
    fun levelsContainTheRequestedTrapFamilies() {
        val levels = (1..20).map(GeoAdventureLevelFactory::build)
        val allPlatforms = levels.flatMap { it.platforms }
        val allHazards = levels.flatMap { it.hazards }
        val allCheckpoints = levels.flatMap { it.checkpoints }
        assertTrue(allPlatforms.any { it.kind == PlatformKind.FALLING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.DISAPPEARING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.REVEALING })
        assertTrue(allHazards.any { it.kind == HazardKind.HIDDEN_SPIKES })
        assertTrue(allHazards.any { it.kind == HazardKind.SAW })
        assertTrue(allHazards.any { it.kind == HazardKind.FIRE })
        assertTrue(allCheckpoints.any { it.kind == CheckpointKind.POPUP })
        assertTrue(allCheckpoints.any { it.kind == CheckpointKind.DECOY })
    }

    @Test
    fun firstFourLevelsUseFifteenLivesAndHandcraftedTrollMechanics() {
        val extreme = (1..4).map(GeoAdventureLevelFactory::build)
        extreme.forEach { level ->
            assertEquals(GeoGameRules.GAME_LIVES_PER_RUN, GeoGameRules.attemptsForLevel(level.number))
            assertTrue(level.hazards.count { it.kind == HazardKind.HIDDEN_SPIKES } >= 10)
            assertTrue(level.hazards.any { it.camouflaged })
            assertTrue(level.platforms.any { it.kind == PlatformKind.PROXIMITY_DISAPPEARING })
            assertTrue(level.fallingObjects.any { it.behavior != FallingBehavior.DROP })
            assertTrue(level.crushers.isNotEmpty())
            assertTrue(level.checkpoints.any { it.kind == CheckpointKind.DECOY })
            assertTrue(level.checkpoints.count { it.kind == CheckpointKind.POPUP } >= 2)
            assertTrue(level.enemies.all { it.health == 2 })
        }
        assertEquals(2, extreme.count { it.chasingHoles.isNotEmpty() })
        assertTrue(extreme[0].chasingHoles.isEmpty())
        assertTrue(extreme[2].chasingHoles.isEmpty())
    }

    @Test
    fun realCheckpointsDoNotSitOnLethalObjects() {
        (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build).forEach { level ->
            level.checkpoints.filter { it.kind != CheckpointKind.DECOY }.forEach { checkpoint ->
                assertTrue(level.hazards.none { hazard ->
                    abs((hazard.x + hazard.width / 2f) - checkpoint.x) < 85f &&
                        hazard.y + hazard.height > checkpoint.y - 15f
                })
                assertTrue(level.chasingHoles.none { hole ->
                    checkpoint.x in (minOf(hole.surfaceStartX, hole.surfaceEndX) - 40f)..(maxOf(hole.surfaceStartX, hole.surfaceEndX) + 40f)
                })
                assertTrue(level.fallingObjects.none { falling ->
                    abs(falling.x - checkpoint.x) < 95f
                })
            }
        }
    }

    @Test
    fun handcraftedGroundRouteNeverHasAnImpossibleStaticGap() {
        (1..4).map(GeoAdventureLevelFactory::build).forEach { level ->
            val ground = level.platforms.filter { it.y == 620f }.sortedBy { it.x }
            val merged = mutableListOf<Pair<Float, Float>>()
            ground.forEach { platform ->
                val start = platform.x
                val end = platform.x + platform.width
                val previous = merged.lastOrNull()
                if (previous == null || start > previous.second) {
                    merged += start to end
                } else {
                    merged[merged.lastIndex] = previous.first to maxOf(previous.second, end)
                }
            }
            merged.zipWithNext().forEach { (left, right) ->
                val gap = right.first - left.second
                assertTrue("Nivel ${level.number}: hueco estático de $gap", gap <= 160f)
            }
        }
    }

    @Test
    fun everyRealCheckpointHasAPermanentSolidPlatform() {
        (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build).forEach { level ->
            level.checkpoints.filter { it.kind != CheckpointKind.DECOY }.forEach { checkpoint ->
                assertTrue("Nivel ${level.number}: checkpoint real sin plataforma segura", level.platforms.any { platform ->
                    platform.kind == PlatformKind.SOLID &&
                        checkpoint.x in platform.x..(platform.x + platform.width) &&
                        abs(platform.y - (checkpoint.y + 85f)) < 0.1f
                })
            }
        }
    }

    @Test
    fun firstFourLevelsKeepSafeLandingPocketsWithoutMakingThemEasy() {
        (1..4).map(GeoAdventureLevelFactory::build).forEach { level ->
            val ground = level.platforms.filter { it.y == 620f }.sortedBy { it.x }
            ground.forEach { platform ->
                val firstPocket = (platform.x + 12f)..(platform.x + minOf(platform.width - 12f, 105f))
                val lastPocket = (platform.x + maxOf(12f, platform.width - 105f))..(platform.x + platform.width - 12f)
                assertTrue(level.hazards.none { hazard ->
                    hazard.orientation == HazardOrientation.UP &&
                        (hazard.x + hazard.width / 2f in firstPocket || hazard.x + hazard.width / 2f in lastPocket)
                })
            }
            assertTrue(level.hazards.size >= 10)
            assertTrue(level.crushers.isNotEmpty())
        }
    }

    @Test
    fun chasingHolesAreOccasionalSurfaceBoundAndNotCrowdedByOtherTraps() {
        val levels = (1..4).map(GeoAdventureLevelFactory::build)
        val holes = levels.flatMap { level -> level.chasingHoles.map { level to it } }
        assertEquals(3, holes.size)
        assertEquals(2, levels[1].chasingHoles.size)
        holes.forEach { (level, hole) ->
            assertTrue(hole.surfaceEndX > hole.surfaceStartX + hole.width)
            assertTrue(level.platforms.any { platform ->
                platform.kind == PlatformKind.SOLID &&
                    hole.surfaceStartX >= platform.x &&
                    hole.surfaceEndX <= platform.x + platform.width &&
                    abs(platform.y - (hole.y + 28f)) <= 12f
            })
            assertTrue(level.hazards.none { hazard ->
                hazard.x + hazard.width >= hole.surfaceStartX - 85f &&
                    hazard.x <= hole.surfaceEndX + 85f
            })
            assertTrue(level.crushers.none { crusher ->
                crusher.x + crusher.width >= hole.surfaceStartX - 100f &&
                    crusher.x <= hole.surfaceEndX + 100f
            })
            assertTrue(level.fallingObjects.none { falling ->
                falling.x + falling.size >= hole.surfaceStartX - 120f &&
                    falling.x <= hole.surfaceEndX + 120f
            })
        }
    }

    @Test
    fun everyLevelHasEnoughRealCheckpointsForItsLength() {
        (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build).forEach { level ->
            val expectedMinimum = when {
                level.width <= 6_800f -> 2
                level.width <= 13_500f -> 3
                level.width <= 17_500f -> 4
                else -> 5
            }
            assertTrue("Nivel ${level.number}: pocos checkpoints reales", level.checkpoints.count { it.kind != CheckpointKind.DECOY } >= expectedMinimum)
        }
    }

    @Test
    fun allLevelsKeepAUsableLandingPocketAtEachGroundSection() {
        (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build).forEach { level ->
            level.platforms.filter { it.y >= 590f && it.width >= 170f }.forEach { platform ->
                val pocket = minOf(105f, platform.width * 0.24f)
                val firstPocket = (platform.x + 14f)..(platform.x + pocket)
                val lastPocket = (platform.x + platform.width - pocket)..(platform.x + platform.width - 14f)
                assertTrue("Nivel ${level.number}: aterrizaje totalmente bloqueado", level.hazards.none { hazard ->
                    hazard.orientation == HazardOrientation.UP &&
                        (hazard.x + hazard.width / 2f in firstPocket || hazard.x + hazard.width / 2f in lastPocket)
                })
            }
        }
    }

    @Test
    fun laterLevelsGrowLongerAndMoreDangerous() {
        val first = GeoAdventureLevelFactory.build(1)
        val middle = GeoAdventureLevelFactory.build(10)
        val last = GeoAdventureLevelFactory.build(20)
        assertTrue(last.width > first.width)
        assertTrue(last.hazards.size > first.hazards.size)
        assertTrue(last.checkpoints.size > first.checkpoints.size)
        assertTrue(middle.movingPlatforms.isNotEmpty())
        assertTrue(last.switches.size >= first.switches.size)
        assertTrue(last.acechantePresent)
    }
}
