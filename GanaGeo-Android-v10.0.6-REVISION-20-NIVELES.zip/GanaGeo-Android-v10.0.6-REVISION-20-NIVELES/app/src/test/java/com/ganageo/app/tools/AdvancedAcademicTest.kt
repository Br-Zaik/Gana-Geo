package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AdvancedAcademicTest {
    @Test
    fun matrixOperationsWork() {
        val matrix = MatrixCalculator.parse("1 2\n3 4", 2)
        assertEquals(-2.0, MatrixCalculator.determinant(matrix), 0.000001)
        val inverse = MatrixCalculator.inverse(matrix)
        assertEquals(-2.0, inverse[0][0], 0.000001)
        assertEquals(1.0, inverse[0][1], 0.000001)
    }

    @Test
    fun solvesThreeByThreeSystem() {
        val coefficients = MatrixCalculator.parse("1 1 1\n2 -1 1\n1 2 -1", 3)
        val solution = MatrixCalculator.solve3(coefficients, doubleArrayOf(6.0, 3.0, 2.0))
        assertEquals(1.0, solution[0], 0.000001)
        assertEquals(2.0, solution[1], 0.000001)
        assertEquals(3.0, solution[2], 0.000001)
    }

    @Test
    fun calculusReturnsExpectedPolynomial() {
        assertEquals("6x - 4", BasicCalculus.derivative("3x^2-4x+7").result)
        assertTrue(BasicCalculus.integral("6x-4").result.contains("3x^2 - 4x"))
    }

    @Test
    fun periodicTableContainsAllElements() {
        assertEquals(118, PeriodicTableData.elements.size)
        assertEquals("Og", PeriodicTableData.elements.last().symbol)
        assertEquals("Oganesón", PeriodicTableData.search("118").single().name)
    }

    @Test
    fun chemistryProCalculationsWork() {
        assertEquals(0.5, ChemistryProCalculator.molarity(1.0, 2.0), 0.000001)
        assertEquals(2.0, ChemistryProCalculator.dilutionFinalVolume(1.0, 1.0, 0.5), 0.000001)
        assertTrue(ChemistryProCalculator.electronConfiguration(8).contains("2p4"))
    }

    @Test
    fun textToolkitComparesAndReplaces() {
        val (updated, count) = TextToolkit.findAndReplace("Hola hola", "hola", "Geo", ignoreCase = true)
        assertEquals(2, count)
        assertEquals("Geo Geo", updated)
        val comparison = TextToolkit.compare("a\nb", "a\nc")
        assertEquals(2, comparison.firstDifferentLine)
    }
}
