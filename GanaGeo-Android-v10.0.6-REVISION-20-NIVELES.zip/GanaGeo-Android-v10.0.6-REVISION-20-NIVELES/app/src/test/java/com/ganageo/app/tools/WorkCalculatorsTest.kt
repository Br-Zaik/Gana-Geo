package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class WorkCalculatorsTest {
    @Test
    fun calculatesRegularAndOvertimePay() {
        val result = WorkPayCalculator.calculate(
            hourlyRate = 10.0,
            regularHoursPerDay = 8.0,
            overtimeHoursPerDay = 2.0,
            overtimeMultiplier = 1.5,
            days = 5.0
        )

        assertEquals(40.0, result.regularHours, 0.000001)
        assertEquals(10.0, result.overtimeHours, 0.000001)
        assertEquals(400.0, result.regularPay, 0.000001)
        assertEquals(150.0, result.overtimePay, 0.000001)
        assertEquals(550.0, result.totalPay, 0.000001)
    }

    @Test
    fun calculatesCommissionMarginAndTargetPrice() {
        val result = CommerceCalculator.analyzeSale(
            cost = 50.0,
            salePrice = 100.0,
            commissionPercent = 10.0
        )

        assertEquals(50.0, result.grossProfit, 0.000001)
        assertEquals(10.0, result.commission, 0.000001)
        assertEquals(40.0, result.netProfit, 0.000001)
        assertEquals(40.0, result.netMarginPercent, 0.000001)
        assertEquals(83.3333333333, CommerceCalculator.targetSalePrice(50.0, 30.0, 10.0), 0.000001)
    }

    @Test
    fun calculatesIgvAndRejectsInvalidTarget() {
        val totals = CommerceCalculator.quoteTotals(100.0)
        assertEquals(100.0, totals.first, 0.000001)
        assertEquals(18.0, totals.second, 0.000001)
        assertEquals(118.0, totals.third, 0.000001)

        assertThrows(IllegalArgumentException::class.java) {
            CommerceCalculator.targetSalePrice(50.0, 80.0, 20.0)
        }
    }
}
