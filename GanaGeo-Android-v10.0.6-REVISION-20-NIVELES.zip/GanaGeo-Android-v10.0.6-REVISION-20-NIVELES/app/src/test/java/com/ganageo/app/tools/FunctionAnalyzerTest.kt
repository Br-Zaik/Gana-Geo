package com.ganageo.app.tools

import org.junit.Assert.assertTrue
import org.junit.Test

class FunctionAnalyzerTest {
    @Test
    fun findsRootsAndExtrema() {
        val report = FunctionAnalyzer.analyze(listOf("x^2-4"), -5.0, 5.0, false)
        assertTrue(report.roots.any { kotlin.math.abs(it - 2.0) < 0.1 })
        assertTrue(report.roots.any { kotlin.math.abs(it + 2.0) < 0.1 })
        assertTrue(report.localMinima.any { kotlin.math.abs(it.x) < 0.1 })
    }

    @Test
    fun findsIntersection() {
        val report = FunctionAnalyzer.analyze(listOf("x", "2-x"), -2.0, 3.0, false)
        assertTrue(report.intersections.any { kotlin.math.abs(it.x - 1.0) < 0.1 })
    }
}
