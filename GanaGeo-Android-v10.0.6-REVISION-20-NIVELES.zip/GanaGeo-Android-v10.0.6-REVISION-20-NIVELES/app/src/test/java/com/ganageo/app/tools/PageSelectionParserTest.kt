package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class PageSelectionParserTest {
    @Test
    fun parsesPagesAndRangesWithoutDuplicates() {
        assertEquals(listOf(1, 2, 3, 7, 9), PageSelectionParser.parse("1-3, 7, 9, 2"))
    }

    @Test
    fun validatesMaximumPage() {
        assertThrows(IllegalArgumentException::class.java) {
            PageSelectionParser.parse("1,8", maxPage = 7)
        }
    }

    @Test
    fun rejectsExcessivelyLargeRange() {
        assertThrows(IllegalArgumentException::class.java) {
            PageSelectionParser.parse("1-20000")
        }
    }

    @Test
    fun rejectsMoreThanThreeHundredSelectedPages() {
        assertThrows(IllegalArgumentException::class.java) {
            PageSelectionParser.parse("1-301")
        }
    }

    @Test
    fun rejectsMoreThanOneHundredSplitGroups() {
        val groups = (1..101).joinToString(";") { it.toString() }
        assertThrows(IllegalArgumentException::class.java) {
            PageSelectionParser.parseGroups(groups)
        }
    }

    @Test
    fun parsesGroups() {
        assertEquals(
            listOf(listOf(1, 2, 3), listOf(4, 5), listOf(7)),
            PageSelectionParser.parseGroups("1-3;4-5;7", maxPage = 8)
        )
    }
}
