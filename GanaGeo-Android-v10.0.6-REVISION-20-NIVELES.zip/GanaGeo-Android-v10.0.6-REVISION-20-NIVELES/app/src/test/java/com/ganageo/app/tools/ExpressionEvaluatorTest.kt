package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ExpressionEvaluatorTest {
    @Test
    fun evaluatesBasicAndScientificExpressions() {
        assertEquals(30.0, ExpressionEvaluator(true).evaluate("(10+5)*2"), 0.0000001)
        assertEquals(4.5, ExpressionEvaluator(true).evaluate("sin(30)+sqrt(16)"), 0.0000001)
        assertEquals(9.0, ExpressionEvaluator(false).evaluate("cos(0)+2^3"), 0.0000001)
    }

    @Test
    fun rejectsDivisionByZero() {
        assertThrows(IllegalStateException::class.java) {
            ExpressionEvaluator(true).evaluate("5/0")
        }
    }
}
