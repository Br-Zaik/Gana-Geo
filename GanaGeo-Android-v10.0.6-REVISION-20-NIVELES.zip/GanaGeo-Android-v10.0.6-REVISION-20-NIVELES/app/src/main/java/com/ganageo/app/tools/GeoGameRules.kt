package com.ganageo.app.tools

data class GeoLifePackage(val code: String, val lives: Int, val creditCost: Int)

object GeoGameRules {
    const val MAX_FREE_LIVES = 5
    const val FREE_LIFE_RECOVERY_MINUTES = 30
    const val GAME_LIVES_PER_RUN = 15
    const val DEATH_REVEAL_MS = 1_000L
    const val VOID_RESPAWN_DELAY_MS = 80L
    const val HOLE_SINK_MS = 900L
    @Deprecated("Use GAME_LIVES_PER_RUN", ReplaceWith("GAME_LIVES_PER_RUN"))
    const val ATTEMPTS_PER_LIFE = GAME_LIVES_PER_RUN
    const val PREMIUM_DAILY_LIMIT = 10
    const val PREMIUM_LIFE_CREDIT_COST = 2
    const val PREMIUM_ACTIVATION_SECONDS = 20
    const val LEVEL_COUNT = 20

    @Deprecated("Use MAX_FREE_LIVES", ReplaceWith("MAX_FREE_LIVES"))
    const val DAILY_FREE_LIVES = MAX_FREE_LIVES

    val lifePackages: List<GeoLifePackage> = listOf(
        GeoLifePackage("life_1", 1, 2),
        GeoLifePackage("life_5", 5, 10),
        GeoLifePackage("life_15", 15, 30)
    )

    fun packageByCode(code: String): GeoLifePackage? =
        lifePackages.firstOrNull { it.code == code }

    fun attemptsForLevel(level: Int): Int {
        require(level in 1..LEVEL_COUNT)
        return GAME_LIVES_PER_RUN
    }

    fun worldName(level: Int): String {
        require(level in 1..LEVEL_COUNT)
        return listOf(
            "Selva de las trampas",
            "Bosque de los engaños",
            "Ruinas del viento",
            "Montañas imposibles"
        )[(level - 1) / 5]
    }

    fun calculateStars(won: Boolean, collectedCrystals: Int, seconds: Int, parSeconds: Int): Int {
        if (!won) return 0
        return 1 +
            (if (collectedCrystals >= 3) 1 else 0) +
            (if (seconds <= parSeconds) 1 else 0)
    }
}
