package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException
import java.util.UUID

private val Context.studyPlannerProDataStore by preferencesDataStore(name = "gana_geo_study_planner_pro")

@Serializable
data class ClassScheduleEntry(
    val id: String = UUID.randomUUID().toString(),
    val course: String,
    val dayOfWeek: Int,
    val startTime: String,
    val endTime: String,
    val room: String = ""
)

@Serializable
data class StudyGoal(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val targetMinutes: Int,
    val completedMinutes: Int = 0
)

@Serializable
data class AttendanceRecord(
    val id: String = UUID.randomUUID().toString(),
    val course: String,
    val attended: Int,
    val total: Int
)

@Serializable
data class StudyLog(
    val id: String = UUID.randomUUID().toString(),
    val course: String,
    val minutes: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
data class PlannerProData(
    val schedule: List<ClassScheduleEntry> = emptyList(),
    val goals: List<StudyGoal> = emptyList(),
    val attendance: List<AttendanceRecord> = emptyList(),
    val logs: List<StudyLog> = emptyList()
)

class StudyPlannerProStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val data: Flow<PlannerProData> = context.studyPlannerProDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs -> decode(prefs[DATA_KEY]) }

    suspend fun addSchedule(course: String, day: Int, start: String, end: String, room: String) = update { current ->
        require(course.trim().isNotBlank()) { "Escribe el curso" }
        require(day in 1..7) { "Día inválido" }
        require(start.matches(TIME_REGEX) && end.matches(TIME_REGEX)) { "Usa hora HH:MM" }
        current.copy(schedule = (current.schedule + ClassScheduleEntry(course = course.trim().take(100), dayOfWeek = day, startTime = start, endTime = end, room = room.trim().take(80))).sortedWith(compareBy({ it.dayOfWeek }, { it.startTime })))
    }

    suspend fun deleteSchedule(id: String) = update { it.copy(schedule = it.schedule.filterNot { item -> item.id == id }) }

    suspend fun addGoal(title: String, targetMinutes: Int) = update { current ->
        require(title.trim().isNotBlank()) { "Escribe una meta" }
        require(targetMinutes in 1..100_000) { "Minutos inválidos" }
        current.copy(goals = current.goals + StudyGoal(title = title.trim().take(140), targetMinutes = targetMinutes))
    }

    suspend fun addGoalProgress(id: String, minutes: Int) = update { current ->
        require(minutes in 1..1440) { "Minutos inválidos" }
        current.copy(goals = current.goals.map { if (it.id == id) it.copy(completedMinutes = (it.completedMinutes + minutes).coerceAtMost(it.targetMinutes)) else it })
    }

    suspend fun deleteGoal(id: String) = update { it.copy(goals = it.goals.filterNot { item -> item.id == id }) }

    suspend fun saveAttendance(course: String, attended: Int, total: Int) = update { current ->
        require(course.trim().isNotBlank()) { "Escribe el curso" }
        require(attended >= 0 && total > 0 && attended <= total) { "Asistencia inválida" }
        val existing = current.attendance.firstOrNull { it.course.equals(course.trim(), true) }
        val updated = if (existing == null) current.attendance + AttendanceRecord(course = course.trim().take(100), attended = attended, total = total)
        else current.attendance.map { if (it.id == existing.id) it.copy(attended = attended, total = total) else it }
        current.copy(attendance = updated)
    }

    suspend fun deleteAttendance(id: String) = update { it.copy(attendance = it.attendance.filterNot { item -> item.id == id }) }

    suspend fun logStudy(course: String, minutes: Int) = update { current ->
        require(minutes in 1..1440) { "Minutos inválidos" }
        current.copy(logs = (current.logs + StudyLog(course = course.trim().ifBlank { "Estudio general" }.take(100), minutes = minutes)).takeLast(1000))
    }

    private suspend fun update(transform: (PlannerProData) -> PlannerProData) {
        context.studyPlannerProDataStore.edit { prefs -> prefs[DATA_KEY] = json.encodeToString(transform(decode(prefs[DATA_KEY]))) }
    }

    private fun decode(raw: String?): PlannerProData = raw?.let { runCatching { json.decodeFromString<PlannerProData>(it) }.getOrNull() } ?: PlannerProData()

    private companion object {
        val DATA_KEY = stringPreferencesKey("planner_data")
        val TIME_REGEX = Regex("(?:[01]\\d|2[0-3]):[0-5]\\d")
    }
}
