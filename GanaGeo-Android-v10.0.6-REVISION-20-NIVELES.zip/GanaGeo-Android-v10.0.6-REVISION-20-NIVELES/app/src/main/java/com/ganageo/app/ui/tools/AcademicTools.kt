package com.ganageo.app.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.ChemicalComposition
import com.ganageo.app.tools.ChemistryCalculator
import com.ganageo.app.tools.ChemistryProCalculator
import com.ganageo.app.tools.CitationFormatter
import com.ganageo.app.tools.CitationInput
import com.ganageo.app.tools.CitationSourceType
import com.ganageo.app.tools.CitationStyle
import com.ganageo.app.tools.EquationResult
import com.ganageo.app.tools.EquationSolver
import com.ganageo.app.tools.NumberBaseConverter
import com.ganageo.app.tools.StatisticsCalculator
import com.ganageo.app.tools.StatisticsResult
import com.ganageo.app.tools.TextToolkit
import com.ganageo.app.tools.formatAcademicNumber
import com.ganageo.app.tools.physicsOperations
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen

@Composable
fun EquationSolverScreen(onBack: () -> Unit) {
    val modes = listOf("Ecuación lineal", "Ecuación cuadrática", "Sistema 2×2")
    var modeIndex by rememberSaveable { mutableStateOf(0) }
    var a by rememberSaveable { mutableStateOf("") }
    var b by rememberSaveable { mutableStateOf("") }
    var c by rememberSaveable { mutableStateOf("") }
    var a2 by rememberSaveable { mutableStateOf("") }
    var b2 by rememberSaveable { mutableStateOf("") }
    var c2 by rememberSaveable { mutableStateOf("") }
    var result by remember { mutableStateOf<EquationResult?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    AcademicToolPage(
        title = "Solucionador de ecuaciones",
        subtitle = "Resuelve ecuaciones y muestra el procedimiento",
        onBack = onBack
    ) {
        item {
            SimpleDropdown("Tipo", modes, modeIndex) {
                modeIndex = it
                result = null
                error = null
            }
        }
        item {
            AcademicCard(modes[modeIndex]) {
                when (modeIndex) {
                    0 -> {
                        Text("Forma: ax + b = 0", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        AcademicNumberField(a, { a = it }, "a")
                        AcademicNumberField(b, { b = it }, "b")
                    }
                    1 -> {
                        Text("Forma: ax² + bx + c = 0", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        AcademicNumberField(a, { a = it }, "a")
                        AcademicNumberField(b, { b = it }, "b")
                        AcademicNumberField(c, { c = it }, "c")
                    }
                    else -> {
                        Text("a₁x + b₁y = c₁", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CompactNumberField(a, { a = it }, "a₁", Modifier.weight(1f))
                            CompactNumberField(b, { b = it }, "b₁", Modifier.weight(1f))
                            CompactNumberField(c, { c = it }, "c₁", Modifier.weight(1f))
                        }
                        Text("a₂x + b₂y = c₂", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CompactNumberField(a2, { a2 = it }, "a₂", Modifier.weight(1f))
                            CompactNumberField(b2, { b2 = it }, "b₂", Modifier.weight(1f))
                            CompactNumberField(c2, { c2 = it }, "c₂", Modifier.weight(1f))
                        }
                    }
                }
                PrimaryAction("Resolver") {
                    runCatching {
                        when (modeIndex) {
                            0 -> EquationSolver.solveLinear(a.numberValue("a"), b.numberValue("b"))
                            1 -> EquationSolver.solveQuadratic(
                                a.numberValue("a"),
                                b.numberValue("b"),
                                c.numberValue("c")
                            )
                            else -> EquationSolver.solveSystem2x2(
                                a.numberValue("a₁"),
                                b.numberValue("b₁"),
                                c.numberValue("c₁"),
                                a2.numberValue("a₂"),
                                b2.numberValue("b₂"),
                                c2.numberValue("c₂")
                            )
                        }
                    }.onSuccess {
                        result = it
                        error = null
                    }.onFailure {
                        result = null
                        error = it.message ?: "No se pudo resolver"
                    }
                }
                error?.let { ErrorText(it) }
            }
        }
        result?.let { solved ->
            item {
                ResultCard(solved.title) {
                    solved.resultLines.forEach {
                        Text(it, style = MaterialTheme.typography.titleLarge, color = NeonGreen)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Procedimiento", fontWeight = FontWeight.Bold)
                    solved.steps.forEachIndexed { index, step ->
                        Text("${index + 1}. $step", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun StatisticsScreen(onBack: () -> Unit) {
    var input by rememberSaveable { mutableStateOf("") }
    var result by remember { mutableStateOf<StatisticsResult?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    AcademicToolPage(
        title = "Estadística descriptiva",
        subtitle = "Media, mediana, moda, cuartiles y desviación",
        onBack = onBack
    ) {
        item {
            AcademicCard("Datos") {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.take(10_000) },
                    label = { Text("Valores") },
                    placeholder = { Text("Ejemplo: 10; 12; 15.5; 18; 20") },
                    supportingText = { Text("Separa los números con punto y coma, espacios o líneas") },
                    modifier = Modifier.fillMaxWidth().height(150.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            runCatching {
                                StatisticsCalculator.calculate(StatisticsCalculator.parseValues(input))
                            }.onSuccess {
                                result = it
                                error = null
                            }.onFailure {
                                result = null
                                error = it.message ?: "Datos inválidos"
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                    ) { Text("Calcular") }
                    OutlinedButton(
                        onClick = {
                            input = ""
                            result = null
                            error = null
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null)
                        Text(" Limpiar")
                    }
                }
                error?.let { ErrorText(it) }
            }
        }
        result?.let { stats ->
            item {
                ResultCard("Resultados") {
                    StatisticRow("Cantidad", stats.count.toString())
                    StatisticRow("Suma", formatAcademicNumber(stats.sum))
                    StatisticRow("Media", formatAcademicNumber(stats.mean))
                    StatisticRow("Mediana", formatAcademicNumber(stats.median))
                    StatisticRow(
                        "Moda",
                        stats.modes.takeIf { it.isNotEmpty() }
                            ?.joinToString { formatAcademicNumber(it) }
                            ?: "Sin moda"
                    )
                    StatisticRow("Mínimo", formatAcademicNumber(stats.minimum))
                    StatisticRow("Máximo", formatAcademicNumber(stats.maximum))
                    StatisticRow("Rango", formatAcademicNumber(stats.range))
                    StatisticRow("Q1", formatAcademicNumber(stats.firstQuartile))
                    StatisticRow("Q3", formatAcademicNumber(stats.thirdQuartile))
                    StatisticRow("Varianza poblacional", formatAcademicNumber(stats.populationVariance))
                    StatisticRow("Desviación poblacional", formatAcademicNumber(stats.populationStandardDeviation))
                    stats.sampleVariance?.let { StatisticRow("Varianza muestral", formatAcademicNumber(it)) }
                    stats.sampleStandardDeviation?.let {
                        StatisticRow("Desviación muestral", formatAcademicNumber(it))
                    }
                }
            }
        }
    }
}

@Composable
fun PhysicsCalculatorScreen(onBack: () -> Unit) {
    var operationIndex by rememberSaveable { mutableStateOf(0) }
    var first by rememberSaveable { mutableStateOf("") }
    var second by rememberSaveable { mutableStateOf("") }
    var result by rememberSaveable { mutableStateOf<String?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    val operation = physicsOperations[operationIndex]

    AcademicToolPage(
        title = "Calculadora de física",
        subtitle = "Mecánica, densidad, presión y electricidad",
        onBack = onBack
    ) {
        item {
            SimpleDropdown("Cálculo", physicsOperations.map { it.title }, operationIndex) {
                operationIndex = it
                first = ""
                second = ""
                result = null
                error = null
            }
        }
        item {
            AcademicCard(operation.title) {
                Text("Fórmula: ${operation.formula}", color = NeonGreen, fontWeight = FontWeight.Bold)
                AcademicNumberField(first, { first = it }, operation.firstLabel)
                AcademicNumberField(second, { second = it }, operation.secondLabel)
                PrimaryAction("Calcular") {
                    runCatching {
                        operation.calculate(
                            first.numberValue(operation.firstLabel),
                            second.numberValue(operation.secondLabel)
                        ).also { calculated ->
                            require(calculated.isFinite()) { "El resultado no es válido" }
                        }
                    }.onSuccess {
                        result = "${operation.resultLabel}: ${formatAcademicNumber(it)} ${operation.unit}"
                        error = null
                    }.onFailure {
                        result = null
                        error = it.message ?: "No se pudo calcular"
                    }
                }
                result?.let { Text(it, style = MaterialTheme.typography.titleLarge, color = NeonGreen) }
                error?.let { ErrorText(it) }
            }
        }
    }
}

@Composable
fun ChemistryCalculatorScreen(onBack: () -> Unit) {
    val modes = listOf(
        "Masa molar", "Masa → moles", "Moles → masa", "Molaridad",
        "Dilución", "Gases ideales", "Configuración electrónica"
    )
    var modeIndex by rememberSaveable { mutableStateOf(0) }
    var formula by rememberSaveable { mutableStateOf("") }
    var quantity by rememberSaveable { mutableStateOf("") }
    var secondQuantity by rememberSaveable { mutableStateOf("") }
    var thirdQuantity by rememberSaveable { mutableStateOf("") }
    var composition by remember { mutableStateOf<ChemicalComposition?>(null) }
    var convertedResult by rememberSaveable { mutableStateOf<String?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    AcademicToolPage(
        title = "Calculadora de química",
        subtitle = "Masa molar, molaridad, diluciones, gases y electrones",
        onBack = onBack
    ) {
        item {
            SimpleDropdown("Operación", modes, modeIndex) {
                modeIndex = it
                quantity = ""
                secondQuantity = ""
                thirdQuantity = ""
                composition = null
                convertedResult = null
                error = null
            }
        }
        item {
            AcademicCard(modes[modeIndex]) {
                if (modeIndex <= 2) {
                    OutlinedTextField(
                        value = formula,
                        onValueChange = { formula = it.filterNot(Char::isWhitespace).take(60) },
                        label = { Text("Fórmula química") },
                        placeholder = { Text("Ejemplo: H2O, Ca(OH)2, CuSO4·5H2O") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                when (modeIndex) {
                    1 -> AcademicNumberField(quantity, { quantity = it }, "Masa (g)")
                    2 -> AcademicNumberField(quantity, { quantity = it }, "Cantidad (mol)")
                    3 -> {
                        AcademicNumberField(quantity, { quantity = it }, "Moles de soluto")
                        AcademicNumberField(secondQuantity, { secondQuantity = it }, "Volumen de solución (L)")
                    }
                    4 -> {
                        AcademicNumberField(quantity, { quantity = it }, "Concentración inicial C₁")
                        AcademicNumberField(secondQuantity, { secondQuantity = it }, "Volumen inicial V₁")
                        AcademicNumberField(thirdQuantity, { thirdQuantity = it }, "Concentración final C₂")
                    }
                    5 -> {
                        AcademicNumberField(quantity, { quantity = it }, "Presión (atm)")
                        AcademicNumberField(secondQuantity, { secondQuantity = it }, "Volumen (L)")
                        AcademicNumberField(thirdQuantity, { thirdQuantity = it }, "Temperatura (K)")
                    }
                    6 -> AcademicNumberField(quantity, { quantity = it.filter(Char::isDigit) }, "Número atómico")
                }
                PrimaryAction("Calcular") {
                    runCatching {
                        when (modeIndex) {
                            0, 1, 2 -> {
                                val analyzed = ChemistryCalculator.analyzeFormula(formula)
                                val converted = when (modeIndex) {
                                    1 -> "Cantidad: ${formatAcademicNumber(ChemistryCalculator.molesFromMass(quantity.numberValue("Masa"), analyzed.molarMass))} mol"
                                    2 -> "Masa: ${formatAcademicNumber(ChemistryCalculator.massFromMoles(quantity.numberValue("Moles"), analyzed.molarMass))} g"
                                    else -> null
                                }
                                composition = analyzed
                                converted
                            }
                            3 -> "Molaridad: ${formatAcademicNumber(ChemistryProCalculator.molarity(quantity.numberValue("Moles"), secondQuantity.numberValue("Volumen")))} mol/L\nFórmula: M = n / V"
                            4 -> "Volumen final: ${formatAcademicNumber(ChemistryProCalculator.dilutionFinalVolume(quantity.numberValue("C₁"), secondQuantity.numberValue("V₁"), thirdQuantity.numberValue("C₂")))}\nFórmula: C₁V₁ = C₂V₂"
                            5 -> "Cantidad: ${formatAcademicNumber(ChemistryProCalculator.idealGasMoles(quantity.numberValue("Presión"), secondQuantity.numberValue("Volumen"), thirdQuantity.numberValue("Temperatura")))} mol\nFórmula: PV = nRT"
                            else -> "Configuración: ${ChemistryProCalculator.electronConfiguration(quantity.toIntOrNull() ?: error("Número atómico inválido"))}"
                        }
                    }.onSuccess {
                        convertedResult = it
                        error = null
                    }.onFailure {
                        composition = null
                        convertedResult = null
                        error = it.message ?: "Datos inválidos"
                    }
                }
                error?.let { ErrorText(it) }
            }
        }
        composition?.let { analyzed ->
            item {
                ResultCard("Resultado") {
                    Text("Masa molar: ${formatAcademicNumber(analyzed.molarMass)} g/mol", style = MaterialTheme.typography.titleLarge, color = NeonGreen)
                    convertedResult?.let { Text(it, style = MaterialTheme.typography.titleLarge, color = NeonGreen) }
                    Text("Composición", fontWeight = FontWeight.Bold)
                    analyzed.elementCounts.forEach { (symbol, count) -> StatisticRow(symbol, count.toString()) }
                }
            }
        }
        if (composition == null && !convertedResult.isNullOrBlank()) {
            item { ResultCard("Resultado") { Text(convertedResult.orEmpty(), style = MaterialTheme.typography.titleLarge, color = NeonGreen) } }
        }
    }
}

@Composable
fun NumberSystemsScreen(onBack: () -> Unit) {
    val bases = listOf("Binario (base 2)", "Octal (base 8)", "Decimal (base 10)", "Hexadecimal (base 16)")
    val baseValues = listOf(2, 8, 10, 16)
    var baseIndex by rememberSaveable { mutableStateOf(2) }
    var input by rememberSaveable { mutableStateOf("") }
    var resultLines by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    AcademicToolPage(
        title = "Sistemas numéricos",
        subtitle = "Convierte entre binario, octal, decimal y hexadecimal",
        onBack = onBack
    ) {
        item {
            SimpleDropdown("Base de entrada", bases, baseIndex) {
                baseIndex = it
                input = ""
                resultLines = emptyList()
                error = null
            }
        }
        item {
            AcademicCard("Conversión") {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.uppercase().filter { char -> char.isLetterOrDigit() || char == '-' }.take(256) },
                    label = { Text("Número") },
                    placeholder = { Text(if (baseValues[baseIndex] == 16) "Ejemplo: FF" else "Ejemplo: 255") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                PrimaryAction("Convertir") {
                    runCatching { NumberBaseConverter.convert(input, baseValues[baseIndex]) }
                        .onSuccess {
                            resultLines = listOf(
                                "Binario" to it.binary,
                                "Octal" to it.octal,
                                "Decimal" to it.decimal,
                                "Hexadecimal" to it.hexadecimal
                            )
                            error = null
                        }
                        .onFailure {
                            resultLines = emptyList()
                            error = it.message ?: "Número inválido"
                        }
                }
                error?.let { ErrorText(it) }
            }
        }
        if (resultLines.isNotEmpty()) {
            item {
                ResultCard("Resultados") {
                    resultLines.forEach { (label, value) ->
                        Text(label, fontWeight = FontWeight.Bold)
                        Text(value, color = NeonGreen, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun CitationGeneratorScreen(onBack: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var styleIndex by rememberSaveable { mutableStateOf(0) }
    var typeIndex by rememberSaveable { mutableStateOf(0) }
    var author by rememberSaveable { mutableStateOf("") }
    var title by rememberSaveable { mutableStateOf("") }
    var year by rememberSaveable { mutableStateOf("") }
    var publisher by rememberSaveable { mutableStateOf("") }
    var journal by rememberSaveable { mutableStateOf("") }
    var volume by rememberSaveable { mutableStateOf("") }
    var issue by rememberSaveable { mutableStateOf("") }
    var pages by rememberSaveable { mutableStateOf("") }
    var url by rememberSaveable { mutableStateOf("") }
    var accessDate by rememberSaveable { mutableStateOf("") }
    var result by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    val style = CitationStyle.entries[styleIndex]
    val sourceType = CitationSourceType.entries[typeIndex]

    AcademicToolPage(
        title = "Generador de referencias",
        subtitle = "APA 7, Vancouver, IEEE y MLA sin conexión",
        onBack = onBack
    ) {
        item { SimpleDropdown("Estilo", CitationStyle.entries.map { it.label }, styleIndex) { styleIndex = it } }
        item { SimpleDropdown("Tipo de fuente", CitationSourceType.entries.map { it.label }, typeIndex) { typeIndex = it } }
        item {
            AcademicCard("Datos de la fuente") {
                AcademicTextField(author, { author = it }, "Autor o autores")
                AcademicTextField(title, { title = it }, "Título")
                AcademicTextField(year, { year = it.filter(Char::isDigit).take(4) }, "Año")
                AcademicTextField(publisher, { publisher = it }, "Editorial o institución")
                if (sourceType == CitationSourceType.ARTICLE) {
                    AcademicTextField(journal, { journal = it }, "Revista")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AcademicTextField(volume, { volume = it }, "Volumen", Modifier.weight(1f))
                        AcademicTextField(issue, { issue = it }, "Número", Modifier.weight(1f))
                    }
                    AcademicTextField(pages, { pages = it }, "Páginas")
                }
                if (sourceType != CitationSourceType.BOOK) {
                    AcademicTextField(url, { url = it }, "URL")
                }
                if (sourceType == CitationSourceType.WEBSITE) {
                    AcademicTextField(accessDate, { accessDate = it }, "Fecha de consulta")
                }
                PrimaryAction("Generar referencia") {
                    runCatching {
                        CitationFormatter.format(
                            style = style,
                            type = sourceType,
                            input = CitationInput(
                                author = author,
                                title = title,
                                year = year,
                                publisherOrInstitution = publisher,
                                journal = journal,
                                volume = volume,
                                issue = issue,
                                pages = pages,
                                url = url,
                                accessDate = accessDate
                            )
                        )
                    }.onSuccess {
                        result = it
                        error = null
                    }.onFailure {
                        result = ""
                        error = it.message ?: "Faltan datos"
                    }
                }
                error?.let { ErrorText(it) }
            }
        }
        if (result.isNotBlank()) {
            item {
                ResultCard("Referencia generada") {
                    Text(result)
                    OutlinedButton(
                        onClick = { clipboard.setText(AnnotatedString(result)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = null)
                        Text(" Copiar")
                    }
                }
            }
        }
    }
}

@Composable
fun TextToolkitScreen(onBack: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var text by rememberSaveable { mutableStateOf("") }
    var search by rememberSaveable { mutableStateOf("") }
    var replacement by rememberSaveable { mutableStateOf("") }
    var ignoreCase by rememberSaveable { mutableStateOf(false) }
    var comparisonText by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    val words = text.trim().takeIf(String::isNotEmpty)?.split(Regex("\\s+"))?.size ?: 0

    AcademicToolPage(
        title = "Herramientas de texto",
        subtitle = "Limpia, compara, busca y transforma textos sin conexión",
        onBack = onBack
    ) {
        item {
            AcademicCard("Editor") {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.take(200_000); message = null },
                    label = { Text("Texto principal") },
                    modifier = Modifier.fillMaxWidth().height(260.dp)
                )
                Text(
                    "$words palabras · ${text.length} caracteres · ${if (text.isBlank()) 0 else text.lines().size} líneas",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item {
            AcademicCard("Transformaciones") {
                ToolButtonRow(
                    firstText = "MAYÚSCULAS",
                    firstAction = { text = text.uppercase() },
                    secondText = "minúsculas",
                    secondAction = { text = text.lowercase() }
                )
                ToolButtonRow(
                    firstText = "Tipo título",
                    firstAction = { text = TextToolkit.titleCase(text) },
                    secondText = "Quitar espacios",
                    secondAction = { text = TextToolkit.normalizeSpaces(text) }
                )
                ToolButtonRow(
                    firstText = "Quitar líneas vacías",
                    firstAction = { text = TextToolkit.removeBlankLines(text) },
                    secondText = "Ordenar líneas",
                    secondAction = { text = TextToolkit.sortLines(text) }
                )
                ToolButtonRow(
                    firstText = "Numerar líneas",
                    firstAction = { text = TextToolkit.numberLines(text) },
                    secondText = "Copiar",
                    secondAction = { clipboard.setText(AnnotatedString(text)); message = "Texto copiado" }
                )
            }
        }
        item {
            AcademicCard("Buscar y reemplazar") {
                OutlinedTextField(search, { search = it.take(500); message = null }, label = { Text("Buscar") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(replacement, { replacement = it.take(500); message = null }, label = { Text("Reemplazar por") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ignorar mayúsculas y minúsculas", modifier = Modifier.weight(1f))
                    androidx.compose.material3.Switch(checked = ignoreCase, onCheckedChange = { ignoreCase = it })
                }
                Button(
                    onClick = {
                        runCatching { TextToolkit.findAndReplace(text, search, replacement, ignoreCase) }
                            .onSuccess { (updated, count) -> text = updated; message = "$count coincidencias reemplazadas" }
                            .onFailure { message = it.message ?: "No se pudo reemplazar" }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = text.isNotBlank() && search.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) { Text("Reemplazar", fontWeight = FontWeight.Bold) }
            }
        }
        item {
            AcademicCard("Comparar dos textos") {
                OutlinedTextField(
                    value = comparisonText,
                    onValueChange = { comparisonText = it.take(200_000); message = null },
                    label = { Text("Segundo texto") },
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                )
                OutlinedButton(
                    onClick = {
                        val result = TextToolkit.compare(text, comparisonText)
                        message = if (result.equal) "Los textos son iguales" else {
                            "Difieren en ${result.changedLines} líneas. Primera diferencia: línea ${result.firstDifferentLine}."
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Comparar") }
            }
        }
        item {
            message?.let { Text(it, color = if (it.contains("No se pudo")) MaterialTheme.colorScheme.error else NeonGreen) }
            OutlinedButton(onClick = { text = ""; comparisonText = ""; search = ""; replacement = ""; message = null }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Refresh, contentDescription = null)
                Text(" Limpiar todo")
            }
        }
    }
}

@Composable
private fun AcademicToolPage(
    title: String,
    subtitle: String,
    onBack: () -> Unit,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        ToolHeader(title, subtitle, onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content
        )
    }
}

@Composable
private fun AcademicCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun ResultCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.10f)),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun AcademicNumberField(value: String, onChange: (String) -> Unit, label: String) {
    CompactNumberField(value, onChange, label, Modifier.fillMaxWidth())
}

@Composable
private fun CompactNumberField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { char -> char.isDigit() || char in ".,-+" }.take(30)) },
        label = { Text(label) },
        modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true
    )
}

@Composable
private fun AcademicTextField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.take(500)) },
        label = { Text(label) },
        modifier = modifier,
        singleLine = true
    )
}

@Composable
private fun PrimaryAction(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun ErrorText(message: String) {
    Text(message, color = MaterialTheme.colorScheme.error)
}

@Composable
private fun StatisticRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, color = NeonGreen, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ToolButtonRow(
    firstText: String,
    firstAction: () -> Unit,
    secondText: String,
    secondAction: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilledTonalButton(onClick = firstAction, modifier = Modifier.weight(1f)) { Text(firstText) }
        FilledTonalButton(onClick = secondAction, modifier = Modifier.weight(1f)) { Text(secondText) }
    }
}

private fun String.numberValue(label: String): Double = replace(',', '.').toDoubleOrNull()
    ?: throw IllegalArgumentException("Ingresa un valor válido en $label")
