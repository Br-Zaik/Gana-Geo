package com.ganageo.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NeonGreen = Color(0xFFB7FF00)
val BrightGreen = Color(0xFF72F000)
val DeepGreen = Color(0xFF041A10)
val ForestGreen = Color(0xFF06351F)
val CardGreen = Color(0xFF0B2A1B)
val MutedGreen = Color(0xFF9AB8A5)
val Gold = Color(0xFFFFCC32)
val Danger = Color(0xFFFF6B6B)

private val DarkColors = darkColorScheme(
    primary = NeonGreen,
    onPrimary = DeepGreen,
    primaryContainer = ForestGreen,
    onPrimaryContainer = Color.White,
    secondary = Gold,
    onSecondary = DeepGreen,
    background = DeepGreen,
    onBackground = Color.White,
    surface = Color(0xFF071F14),
    onSurface = Color.White,
    surfaceVariant = CardGreen,
    onSurfaceVariant = Color(0xFFD4E8D9),
    error = Danger,
    onError = Color.White
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF2E6B00),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDF7B9),
    onPrimaryContainer = Color(0xFF102500),
    secondary = Color(0xFF8A6500),
    background = Color(0xFFF6FBF7),
    onBackground = Color(0xFF112018),
    surface = Color.White,
    onSurface = Color(0xFF112018),
    surfaceVariant = Color(0xFFE4EFE7),
    onSurfaceVariant = Color(0xFF425448)
)

@Composable
fun GanaGeoTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme || isSystemInDarkTheme()) DarkColors else LightColors,
        typography = GanaGeoTypography,
        content = content
    )
}
