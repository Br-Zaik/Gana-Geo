package com.ganageo.app.ui.tools

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ganageo.app.tools.ExpressionEvaluator
import com.ganageo.app.tools.FunctionAnalyzer
import com.ganageo.app.tools.GraphExportUtils
import com.ganageo.app.tools.MatrixCalculator
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.pow

private data class GraphConfig(
    val expressions: List<String>,
    val xMin: Double,
    val xMax: Double,
    val yMin: Double,
    val yMax: Double,
    val degrees: Boolean
)

@Composable
fun FunctionGrapherScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var expressionsText by rememberSaveable { mutableStateOf("x^2\n2*x+1") }
    var xMinText by rememberSaveable { mutableStateOf("-10") }
    var xMaxText by rememberSaveable { mutableStateOf("10") }
    var yMinText by rememberSaveable { mutableStateOf("-10") }
    var yMaxText by rememberSaveable { mutableStateOf("10") }
    var degrees by rememberSaveable { mutableStateOf(true) }
    var graphConfig by remember { mutableStateOf(GraphConfig(listOf("x^2", "2*x+1"), -10.0, 10.0, -10.0, 10.0, true)) }
    var analysis by remember { mutableStateOf<FunctionAnalyzer.Analysis?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var exporting by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { output ->
        if (output == null) return@rememberLauncherForActivityResult
        exporting = true
        scope.launch {
            runCatching {
                GraphExportUtils.exportPng(
                    context,
                    output,
                    GraphExportUtils.Config(
                        graphConfig.expressions,
                        graphConfig.xMin,
                        graphConfig.xMax,
                        graphConfig.yMin,
                        graphConfig.yMax,
                        graphConfig.degrees
                    )
                )
            }.onFailure { error = it.message ?: "No se pudo exportar" }
            exporting = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Graficador de funciones", "Hasta 4 funciones, tabla, análisis y exportación", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Funciones", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(
                            value = expressionsText,
                            onValueChange = { expressionsText = it.take(500) },
                            label = { Text("Una función por línea") },
                            placeholder = { Text("x^2\nsin(x)\n2*x+1") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 4
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GraphNumberField(xMinText, { xMinText = it }, "X mín.", Modifier.weight(1f))
                            GraphNumberField(xMaxText, { xMaxText = it }, "X máx.", Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GraphNumberField(yMinText, { yMinText = it }, "Y mín.", Modifier.weight(1f))
                            GraphNumberField(yMaxText, { yMaxText = it }, "Y máx.", Modifier.weight(1f))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (degrees) "Trigonometría en grados" else "Trigonometría en radianes", modifier = Modifier.weight(1f))
                            Switch(checked = degrees, onCheckedChange = { degrees = it })
                        }
                        Button(
                            onClick = {
                                runCatching {
                                    val expressions = expressionsText.lines().map(String::trim).filter(String::isNotBlank)
                                    require(expressions.isNotEmpty()) { "Escribe una función" }
                                    require(expressions.size <= 4) { "Puedes graficar hasta 4 funciones" }
                                    val xMin = xMinText.graphNumber("X mínimo")
                                    val xMax = xMaxText.graphNumber("X máximo")
                                    val yMin = yMinText.graphNumber("Y mínimo")
                                    val yMax = yMaxText.graphNumber("Y máximo")
                                    require(xMax > xMin) { "X máximo debe ser mayor que X mínimo" }
                                    require(yMax > yMin) { "Y máximo debe ser mayor que Y mínimo" }
                                    require(xMax - xMin <= 1_000_000) { "El rango de X es demasiado grande" }
                                    require(yMax - yMin <= 1_000_000) { "El rango de Y es demasiado grande" }
                                    expressions.forEach { expression ->
                                        val candidates = listOf(xMin, (xMin + xMax) / 2, xMax, 0.0, 1.0).filter { it in xMin..xMax }.distinct()
                                        require(candidates.any { x -> runCatching { ExpressionEvaluator(degrees, mapOf("x" to x)).evaluate(expression) }.isSuccess }) {
                                            "No se pudo evaluar: $expression"
                                        }
                                    }
                                    GraphConfig(expressions, xMin, xMax, yMin, yMax, degrees)
                                }.onSuccess {
                                    graphConfig = it
                                    analysis = runCatching { FunctionAnalyzer.analyze(it.expressions, it.xMin, it.xMax, it.degrees) }.getOrNull()
                                    error = null
                                }.onFailure { error = it.message ?: "No se pudo graficar" }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Graficar y analizar", fontWeight = FontWeight.Bold) }
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            item { GraphCard(graphConfig) }
            item {
                OutlinedButton(
                    onClick = { exportLauncher.launch("grafica_gana_geo.png") },
                    enabled = !exporting,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Image, contentDescription = null)
                    Text(if (exporting) " Exportando…" else " Guardar gráfica como PNG")
                }
            }
            analysis?.let { report ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Análisis aproximado de la primera función", fontWeight = FontWeight.Bold)
                            Text("Raíces: ${report.roots.joinToString { formatGraph(it) }.ifBlank { "No detectadas" }}")
                            Text("Mínimos: ${report.localMinima.joinToString { "(${formatGraph(it.x)}, ${formatGraph(it.y)})" }.ifBlank { "No detectados" }}")
                            Text("Máximos: ${report.localMaxima.joinToString { "(${formatGraph(it.x)}, ${formatGraph(it.y)})" }.ifBlank { "No detectados" }}")
                            if (graphConfig.expressions.size > 1) {
                                Text("Intersecciones: ${report.intersections.joinToString { "(${formatGraph(it.x)}, ${formatGraph(it.y)})" }.ifBlank { "No detectadas" }}")
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Tabla de valores", fontWeight = FontWeight.Bold)
                            report.table.forEach { point ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("x = ${formatGraph(point.x)}")
                                    Text("y = ${formatGraph(point.y)}", color = NeonGreen)
                                }
                            }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Funciones admitidas", fontWeight = FontWeight.Bold)
                        Text(
                            "Potencias (^), sqrt(), abs(), sin(), cos(), tan(), asin(), acos(), atan(), log(), ln(), pi y e. Usa * para multiplicar.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GraphCard(config: GraphConfig) {
    val gridColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
    val axisColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
    val curveColors = listOf(NeonGreen, Color.Cyan, Color.Magenta, Color.Yellow)
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF071B12)), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            config.expressions.forEachIndexed { index, expression ->
                Text("y${index + 1} = $expression", color = curveColors[index % curveColors.size], fontWeight = FontWeight.Bold)
            }
            Canvas(modifier = Modifier.fillMaxWidth().height(330.dp)) {
                val width = size.width
                val height = size.height
                if (width <= 0f || height <= 0f) return@Canvas
                fun mapX(x: Double): Float = ((x - config.xMin) / (config.xMax - config.xMin) * width).toFloat()
                fun mapY(y: Double): Float = (height - (y - config.yMin) / (config.yMax - config.yMin) * height).toFloat()
                val xStep = pleasantGridStep(config.xMax - config.xMin)
                val yStep = pleasantGridStep(config.yMax - config.yMin)
                var xGrid = ceil(config.xMin / xStep) * xStep
                while (xGrid <= config.xMax) { val x = mapX(xGrid); drawLine(gridColor, Offset(x, 0f), Offset(x, height), strokeWidth = 1f); xGrid += xStep }
                var yGrid = ceil(config.yMin / yStep) * yStep
                while (yGrid <= config.yMax) { val y = mapY(yGrid); drawLine(gridColor, Offset(0f, y), Offset(width, y), strokeWidth = 1f); yGrid += yStep }
                if (0.0 in config.xMin..config.xMax) { val x = mapX(0.0); drawLine(axisColor, Offset(x, 0f), Offset(x, height), strokeWidth = 2f) }
                if (0.0 in config.yMin..config.yMax) { val y = mapY(0.0); drawLine(axisColor, Offset(0f, y), Offset(width, y), strokeWidth = 2f) }
                config.expressions.forEachIndexed { expressionIndex, expression ->
                    val evaluator = { x: Double -> runCatching { ExpressionEvaluator(config.degrees, mapOf("x" to x)).evaluate(expression) }.getOrNull() }
                    val path = Path()
                    var drawing = false
                    val samples = width.toInt().coerceIn(240, 1200)
                    var previousY: Float? = null
                    for (index in 0..samples) {
                        val xValue = config.xMin + (config.xMax - config.xMin) * index / samples
                        val yValue = evaluator(xValue)
                        val screenX = mapX(xValue)
                        val screenY = yValue?.takeIf(Double::isFinite)?.let(::mapY)
                        val jump = previousY?.let { previous -> screenY == null || abs(screenY - previous) > height * 1.5f } ?: false
                        if (screenY == null || screenY < -height * 4 || screenY > height * 5 || jump) { drawing = false; previousY = screenY; continue }
                        if (!drawing) { path.moveTo(screenX, screenY); drawing = true } else path.lineTo(screenX, screenY)
                        previousY = screenY
                    }
                    drawPath(path, color = curveColors[expressionIndex % curveColors.size], style = Stroke(width = 3.5f, cap = StrokeCap.Round))
                }
            }
            Text("X: ${config.xMin} a ${config.xMax} · Y: ${config.yMin} a ${config.yMax}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun GraphNumberField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier) {
    OutlinedTextField(value = value, onValueChange = { onChange(it.filter { char -> char.isDigit() || char == '-' || char == '.' || char == ',' }.take(20)) }, label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = modifier, singleLine = true)
}

private fun String.graphNumber(label: String): Double = replace(',', '.').toDoubleOrNull()?.takeIf(Double::isFinite) ?: throw IllegalArgumentException("Ingresa un valor válido en $label")

private fun pleasantGridStep(range: Double): Double {
    if (!range.isFinite() || range <= 0) return 1.0
    val rough = range / 10.0
    val power = 10.0.pow(floor(kotlin.math.log10(rough)))
    val normalized = rough / power
    val factor = when { normalized < 1.5 -> 1.0; normalized < 3.5 -> 2.0; normalized < 7.5 -> 5.0; else -> 10.0 }
    return factor * power
}

private fun formatGraph(value: Double): String = MatrixCalculator.formatNumber(value)
