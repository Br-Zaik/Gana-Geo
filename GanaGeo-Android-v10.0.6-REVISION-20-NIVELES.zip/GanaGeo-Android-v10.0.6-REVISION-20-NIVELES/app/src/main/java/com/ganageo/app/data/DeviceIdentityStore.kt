package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

private val Context.ganaGeoDataStore by preferencesDataStore(name = "gana_geo_preferences")

class DeviceIdentityStore(context: Context) {
    private val appContext = context.applicationContext
    private val installationIdKey = stringPreferencesKey("installation_id")
    private val installationMutex = Mutex()

    /**
     * Returns one stable identifier for the lifetime of this app installation.
     *
     * The mutex is important: authentication callbacks can arrive almost at the
     * same time. Without synchronization, two coroutines could create two UUIDs
     * during the first launch and make Supabase think the account changed device.
     */
    suspend fun getOrCreateInstallationId(): String = installationMutex.withLock {
        val existing = appContext.ganaGeoDataStore.data
            .first()[installationIdKey]
            ?.trim()
            ?.takeIf(::isValidInstallationId)

        if (existing != null) return@withLock existing

        val created = UUID.randomUUID().toString()
        appContext.ganaGeoDataStore.edit { preferences ->
            preferences[installationIdKey] = created
        }
        created
    }

    private fun isValidInstallationId(value: String): Boolean =
        runCatching { UUID.fromString(value) }.isSuccess
}
