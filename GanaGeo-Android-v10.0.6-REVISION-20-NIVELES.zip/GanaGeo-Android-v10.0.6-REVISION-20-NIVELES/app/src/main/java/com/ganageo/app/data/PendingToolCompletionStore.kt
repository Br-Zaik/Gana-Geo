package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.pendingToolCompletionDataStore by preferencesDataStore(
    name = "pending_tool_completions"
)

class PendingToolCompletionStore(private val context: Context) {
    private object Keys {
        val OperationIds = stringSetPreferencesKey("operation_ids")
    }

    private fun encoded(userId: String, operationId: String): String = "$userId|$operationId"

    suspend fun add(userId: String, operationId: String) {
        if (userId.isBlank() || operationId.isBlank()) return
        context.pendingToolCompletionDataStore.edit { prefs ->
            prefs[Keys.OperationIds] = (prefs[Keys.OperationIds] ?: emptySet()) + encoded(userId, operationId)
        }
    }

    suspend fun remove(userId: String, operationId: String) {
        context.pendingToolCompletionDataStore.edit { prefs ->
            prefs[Keys.OperationIds] = (prefs[Keys.OperationIds] ?: emptySet()) - encoded(userId, operationId)
        }
    }

    suspend fun readAll(userId: String): Set<String> {
        if (userId.isBlank()) return emptySet()
        val prefix = "$userId|"
        return context.pendingToolCompletionDataStore.data
            .map { prefs ->
                (prefs[Keys.OperationIds] ?: emptySet())
                    .asSequence()
                    .filter { it.startsWith(prefix) }
                    .map { it.removePrefix(prefix) }
                    .filter { it.isNotBlank() }
                    .toSet()
            }
            .first()
    }
}
