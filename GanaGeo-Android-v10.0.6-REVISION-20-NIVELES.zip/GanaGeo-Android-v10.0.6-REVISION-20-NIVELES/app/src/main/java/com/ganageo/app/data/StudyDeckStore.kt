package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException
import java.util.UUID

private val Context.studyDeckDataStore by preferencesDataStore(name = "gana_geo_study_deck")

@Serializable
data class StudyFlashcard(
    val id: String,
    val question: String,
    val answer: String,
    val createdAt: Long,
    val deck: String = "General",
    val intervalDays: Int = 0,
    val repetitions: Int = 0,
    val dueAt: Long = 0L,
    val lastReviewedAt: Long = 0L
)

class StudyDeckStore(private val context: Context) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val cards: Flow<List<StudyFlashcard>> = context.studyDeckDataStore.data
        .catch { error ->
            if (error is IOException) emit(androidx.datastore.preferences.core.emptyPreferences())
            else throw error
        }
        .map { preferences ->
            preferences[CARDS_KEY]
                ?.let { raw -> runCatching { json.decodeFromString<List<StudyFlashcard>>(raw) }.getOrNull() }
                .orEmpty()
                .sortedByDescending { it.createdAt }
        }

    suspend fun addCard(question: String, answer: String, deck: String = "General") {
        val cleanQuestion = question.trim()
        val cleanAnswer = answer.trim()
        require(cleanQuestion.isNotBlank()) { "Escribe una pregunta" }
        require(cleanAnswer.isNotBlank()) { "Escribe una respuesta" }
        require(cleanQuestion.length <= 500) { "La pregunta es demasiado larga" }
        require(cleanAnswer.length <= 2_000) { "La respuesta es demasiado larga" }

        context.studyDeckDataStore.edit { preferences ->
            val current = decode(preferences[CARDS_KEY]).toMutableList()
            require(current.size < MAX_CARDS) { "Puedes guardar hasta $MAX_CARDS tarjetas" }
            current += StudyFlashcard(
                id = UUID.randomUUID().toString(),
                question = cleanQuestion,
                answer = cleanAnswer,
                createdAt = System.currentTimeMillis(),
                deck = deck.trim().ifBlank { "General" }.take(80),
                dueAt = System.currentTimeMillis()
            )
            preferences[CARDS_KEY] = json.encodeToString(current)
        }
    }


    suspend fun reviewCard(id: String, rating: Int) {
        require(rating in 0..2) { "Valoración inválida" }
        context.studyDeckDataStore.edit { preferences ->
            val now = System.currentTimeMillis()
            preferences[CARDS_KEY] = json.encodeToString(
                decode(preferences[CARDS_KEY]).map { card ->
                    if (card.id != id) card else {
                        val nextInterval = when (rating) {
                            0 -> 0
                            1 -> maxOf(1, if (card.intervalDays == 0) 1 else card.intervalDays * 2)
                            else -> maxOf(3, if (card.intervalDays == 0) 3 else card.intervalDays * 3)
                        }.coerceAtMost(365)
                        card.copy(
                            intervalDays = nextInterval,
                            repetitions = if (rating == 0) 0 else card.repetitions + 1,
                            lastReviewedAt = now,
                            dueAt = now + nextInterval * 86_400_000L
                        )
                    }
                }
            )
        }
    }

    suspend fun renameDeck(oldName: String, newName: String) {
        val clean = newName.trim()
        require(clean.isNotBlank()) { "Escribe el nuevo nombre" }
        context.studyDeckDataStore.edit { preferences ->
            preferences[CARDS_KEY] = json.encodeToString(
                decode(preferences[CARDS_KEY]).map { if (it.deck.equals(oldName, true)) it.copy(deck = clean.take(80)) else it }
            )
        }
    }

    fun exportDeck(cards: List<StudyFlashcard>, deck: String): String = json.encodeToString(
        cards.filter { it.deck.equals(deck, true) }
    )

    suspend fun importDeck(raw: String, deckName: String? = null): Int {
        val imported = runCatching { json.decodeFromString<List<StudyFlashcard>>(raw) }
            .getOrElse { throw IllegalArgumentException("JSON de flashcards inválido") }
        require(imported.isNotEmpty()) { "El archivo no contiene tarjetas" }
        require(imported.size <= MAX_CARDS) { "El archivo contiene demasiadas tarjetas" }
        context.studyDeckDataStore.edit { preferences ->
            val current = decode(preferences[CARDS_KEY]).toMutableList()
            require(current.size + imported.size <= MAX_CARDS) { "Se superaría el límite de $MAX_CARDS tarjetas" }
            current += imported.map { card ->
                require(card.question.isNotBlank() && card.answer.isNotBlank()) { "Hay una tarjeta incompleta" }
                card.copy(
                    id = UUID.randomUUID().toString(),
                    deck = deckName?.trim()?.takeIf { it.isNotBlank() }?.take(80) ?: card.deck.ifBlank { "General" },
                    createdAt = System.currentTimeMillis(),
                    dueAt = System.currentTimeMillis()
                )
            }
            preferences[CARDS_KEY] = json.encodeToString(current)
        }
        return imported.size
    }

    suspend fun deleteCard(id: String) {
        context.studyDeckDataStore.edit { preferences ->
            preferences[CARDS_KEY] = json.encodeToString(
                decode(preferences[CARDS_KEY]).filterNot { it.id == id }
            )
        }
    }

    suspend fun clearAll() {
        context.studyDeckDataStore.edit { preferences ->
            preferences.remove(CARDS_KEY)
        }
    }

    private fun decode(raw: String?): List<StudyFlashcard> = raw
        ?.let { runCatching { json.decodeFromString<List<StudyFlashcard>>(it) }.getOrNull() }
        .orEmpty()

    private companion object {
        val CARDS_KEY = stringPreferencesKey("cards_json")
        const val MAX_CARDS = 500
    }
}
