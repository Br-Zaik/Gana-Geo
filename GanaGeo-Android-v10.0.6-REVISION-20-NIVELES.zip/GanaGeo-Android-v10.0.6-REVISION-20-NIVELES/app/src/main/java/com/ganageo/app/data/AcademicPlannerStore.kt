package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException
import java.util.UUID

private val Context.academicPlannerDataStore by preferencesDataStore(name = "gana_geo_academic_planner")

@Serializable
data class AcademicTask(
    val id: String,
    val title: String,
    val course: String,
    val dueDate: String,
    val completed: Boolean,
    val createdAt: Long
)

class AcademicPlannerStore(private val context: Context) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val tasks: Flow<List<AcademicTask>> = context.academicPlannerDataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { preferences ->
            decode(preferences[TASKS_KEY])
                .sortedWith(
                    compareBy<AcademicTask> { it.completed }
                        .thenBy { if (it.dueDate.isBlank()) "9999-99-99" else normalizedDate(it.dueDate) }
                        .thenByDescending { it.createdAt }
                )
        }

    suspend fun addTask(title: String, course: String, dueDate: String) {
        val cleanTitle = title.trim()
        val cleanCourse = course.trim()
        val cleanDate = dueDate.trim()
        require(cleanTitle.isNotBlank()) { "Escribe una tarea" }
        require(cleanTitle.length <= 300) { "La tarea es demasiado larga" }
        require(cleanCourse.length <= 120) { "El nombre del curso es demasiado largo" }
        require(cleanDate.length <= 20) { "La fecha es demasiado larga" }
        if (cleanDate.isNotBlank()) {
            require(parseDate(cleanDate) != null) { "Usa una fecha válida en formato DD/MM/AAAA" }
        }

        context.academicPlannerDataStore.edit { preferences ->
            val current = decode(preferences[TASKS_KEY]).toMutableList()
            require(current.size < MAX_TASKS) { "Puedes guardar hasta $MAX_TASKS tareas" }
            current += AcademicTask(
                id = UUID.randomUUID().toString(),
                title = cleanTitle,
                course = cleanCourse,
                dueDate = cleanDate,
                completed = false,
                createdAt = System.currentTimeMillis()
            )
            preferences[TASKS_KEY] = json.encodeToString(current)
        }
    }

    suspend fun toggleCompleted(id: String) {
        context.academicPlannerDataStore.edit { preferences ->
            preferences[TASKS_KEY] = json.encodeToString(
                decode(preferences[TASKS_KEY]).map { task ->
                    if (task.id == id) task.copy(completed = !task.completed) else task
                }
            )
        }
    }

    suspend fun deleteTask(id: String) {
        context.academicPlannerDataStore.edit { preferences ->
            preferences[TASKS_KEY] = json.encodeToString(
                decode(preferences[TASKS_KEY]).filterNot { it.id == id }
            )
        }
    }

    suspend fun clearCompleted() {
        context.academicPlannerDataStore.edit { preferences ->
            preferences[TASKS_KEY] = json.encodeToString(
                decode(preferences[TASKS_KEY]).filterNot { it.completed }
            )
        }
    }

    private fun decode(raw: String?): List<AcademicTask> = raw
        ?.let { runCatching { json.decodeFromString<List<AcademicTask>>(it) }.getOrNull() }
        .orEmpty()

    private fun normalizedDate(value: String): String = parseDate(value)?.let { date ->
        "%04d-%02d-%02d".format(date.third, date.second, date.first)
    } ?: value

    private fun parseDate(value: String): Triple<Int, Int, Int>? {
        val parts = value.split('/', '-', '.').map(String::trim)
        if (parts.size != 3) return null
        val day = parts[0].toIntOrNull() ?: return null
        val month = parts[1].toIntOrNull() ?: return null
        val year = parts[2].toIntOrNull() ?: return null
        if (year !in 2000..2200 || month !in 1..12) return null
        val maxDay = when (month) {
            1, 3, 5, 7, 8, 10, 12 -> 31
            4, 6, 9, 11 -> 30
            else -> if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) 29 else 28
        }
        if (day !in 1..maxDay) return null
        return Triple(day, month, year)
    }

    private companion object {
        val TASKS_KEY = stringPreferencesKey("tasks_json")
        const val MAX_TASKS = 500
    }
}
