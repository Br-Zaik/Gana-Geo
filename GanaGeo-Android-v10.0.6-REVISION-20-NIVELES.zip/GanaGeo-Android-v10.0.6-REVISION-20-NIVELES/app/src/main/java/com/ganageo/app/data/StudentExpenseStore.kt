package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException
import java.util.UUID

private val Context.studentExpenseDataStore by preferencesDataStore(name = "gana_geo_student_expenses")

@Serializable
data class StudentExpense(
    val id: String = UUID.randomUUID().toString(),
    val description: String,
    val category: String,
    val amountCents: Long,
    val timestamp: Long = System.currentTimeMillis()
)

class StudentExpenseStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val expenses: Flow<List<StudentExpense>> = context.studentExpenseDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs -> decode(prefs[DATA_KEY]) }

    suspend fun add(description: String, category: String, amount: Double) {
        require(description.trim().isNotBlank()) { "Escribe una descripción" }
        require(amount > 0 && amount.isFinite()) { "El monto debe ser mayor que cero" }
        val cents = kotlin.math.round(amount * 100.0).toLong()
        require(cents in 1..100_000_000L) { "Monto fuera del límite permitido" }
        update { current ->
            (current + StudentExpense(
                description = description.trim().take(120),
                category = category.trim().ifBlank { "Otros" }.take(60),
                amountCents = cents
            )).takeLast(2000)
        }
    }

    suspend fun delete(id: String) = update { current -> current.filterNot { it.id == id } }

    suspend fun clear() = update { emptyList() }

    private suspend fun update(transform: (List<StudentExpense>) -> List<StudentExpense>) {
        context.studentExpenseDataStore.edit { prefs ->
            prefs[DATA_KEY] = json.encodeToString(transform(decode(prefs[DATA_KEY])))
        }
    }

    private fun decode(raw: String?): List<StudentExpense> = raw?.let {
        runCatching { json.decodeFromString<List<StudentExpense>>(it) }.getOrNull()
    } ?: emptyList()

    private companion object {
        val DATA_KEY = stringPreferencesKey("expenses")
    }
}
