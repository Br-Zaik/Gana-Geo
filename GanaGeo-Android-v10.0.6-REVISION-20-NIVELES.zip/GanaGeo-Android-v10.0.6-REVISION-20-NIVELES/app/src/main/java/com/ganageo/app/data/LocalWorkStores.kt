package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.workLedgerDataStore by preferencesDataStore(name = "gana_geo_work_ledger")
private val Context.inventoryDataStore by preferencesDataStore(name = "gana_geo_inventory")
private val Context.workChecklistDataStore by preferencesDataStore(name = "gana_geo_work_checklist")

@Serializable
data class WorkLedgerEntry(
    val id: String = UUID.randomUUID().toString(),
    val type: String,
    val description: String,
    val category: String,
    val amountCents: Long,
    val createdAt: Long = System.currentTimeMillis()
)

class WorkLedgerStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val entries: Flow<List<WorkLedgerEntry>> = context.workLedgerDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs -> decode(prefs[DATA_KEY]).sortedByDescending { it.createdAt } }

    suspend fun add(type: String, description: String, category: String, amount: Double) {
        val cleanType = type.trim().lowercase()
        val cleanDescription = description.trim()
        val cleanCategory = category.trim().ifBlank { "Otros" }
        require(cleanType == "ingreso" || cleanType == "gasto") { "Tipo inválido" }
        require(cleanDescription.isNotBlank()) { "Escribe una descripción" }
        require(amount.isFinite() && amount > 0) { "El monto debe ser mayor que cero" }
        val cents = kotlin.math.round(amount * 100.0).toLong()
        require(cents in 1..1_000_000_000L) { "Monto fuera del límite permitido" }
        update { current ->
            (current + WorkLedgerEntry(
                type = cleanType,
                description = cleanDescription.take(160),
                category = cleanCategory.take(80),
                amountCents = cents
            )).takeLast(MAX_ENTRIES)
        }
    }

    suspend fun delete(id: String) = update { current -> current.filterNot { it.id == id } }

    suspend fun clear() = update { emptyList() }

    private suspend fun update(transform: (List<WorkLedgerEntry>) -> List<WorkLedgerEntry>) {
        context.workLedgerDataStore.edit { prefs ->
            prefs[DATA_KEY] = json.encodeToString(transform(decode(prefs[DATA_KEY])))
        }
    }

    private fun decode(raw: String?): List<WorkLedgerEntry> = raw?.let {
        runCatching { json.decodeFromString<List<WorkLedgerEntry>>(it) }.getOrNull()
    }.orEmpty()

    private companion object {
        val DATA_KEY = stringPreferencesKey("entries")
        const val MAX_ENTRIES = 3000
    }
}

@Serializable
data class InventoryItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val sku: String,
    val quantity: Double,
    val minimumStock: Double,
    val unitCostCents: Long,
    val unitSaleCents: Long,
    val updatedAt: Long = System.currentTimeMillis()
)

class InventoryStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val items: Flow<List<InventoryItem>> = context.inventoryDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs -> decode(prefs[DATA_KEY]).sortedBy { it.name.lowercase() } }

    suspend fun add(
        name: String,
        sku: String,
        quantity: Double,
        minimumStock: Double,
        unitCost: Double,
        unitSale: Double
    ) {
        val cleanName = name.trim()
        require(cleanName.isNotBlank()) { "Escribe el nombre del producto" }
        require(quantity.isFinite() && quantity >= 0) { "Cantidad inválida" }
        require(minimumStock.isFinite() && minimumStock >= 0) { "Stock mínimo inválido" }
        require(unitCost.isFinite() && unitCost >= 0) { "Costo inválido" }
        require(unitSale.isFinite() && unitSale >= 0) { "Precio de venta inválido" }
        val costCents = kotlin.math.round(unitCost * 100.0).toLong()
        val saleCents = kotlin.math.round(unitSale * 100.0).toLong()
        update { current ->
            require(current.size < MAX_ITEMS) { "Puedes guardar hasta $MAX_ITEMS productos" }
            current + InventoryItem(
                name = cleanName.take(160),
                sku = sku.trim().take(80),
                quantity = quantity,
                minimumStock = minimumStock,
                unitCostCents = costCents,
                unitSaleCents = saleCents
            )
        }
    }

    suspend fun adjustStock(id: String, delta: Double) {
        require(delta.isFinite()) { "Movimiento inválido" }
        update { current ->
            current.map { item ->
                if (item.id == id) {
                    val next = item.quantity + delta
                    require(next >= 0) { "El stock no puede quedar negativo" }
                    item.copy(quantity = next, updatedAt = System.currentTimeMillis())
                } else item
            }
        }
    }

    suspend fun delete(id: String) = update { current -> current.filterNot { it.id == id } }

    suspend fun clear() = update { emptyList() }

    private suspend fun update(transform: (List<InventoryItem>) -> List<InventoryItem>) {
        context.inventoryDataStore.edit { prefs ->
            prefs[DATA_KEY] = json.encodeToString(transform(decode(prefs[DATA_KEY])))
        }
    }

    private fun decode(raw: String?): List<InventoryItem> = raw?.let {
        runCatching { json.decodeFromString<List<InventoryItem>>(it) }.getOrNull()
    }.orEmpty()

    private companion object {
        val DATA_KEY = stringPreferencesKey("items")
        const val MAX_ITEMS = 1500
    }
}

@Serializable
data class WorkChecklistItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val area: String,
    val completed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

class WorkChecklistStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val items: Flow<List<WorkChecklistItem>> = context.workChecklistDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { prefs ->
            decode(prefs[DATA_KEY]).sortedWith(
                compareBy<WorkChecklistItem> { it.completed }.thenByDescending { it.createdAt }
            )
        }

    suspend fun add(title: String, area: String) {
        val cleanTitle = title.trim()
        require(cleanTitle.isNotBlank()) { "Escribe una actividad" }
        update { current ->
            require(current.size < MAX_ITEMS) { "Puedes guardar hasta $MAX_ITEMS actividades" }
            current + WorkChecklistItem(
                title = cleanTitle.take(240),
                area = area.trim().take(100)
            )
        }
    }

    suspend fun toggle(id: String) = update { current ->
        current.map { if (it.id == id) it.copy(completed = !it.completed) else it }
    }

    suspend fun delete(id: String) = update { current -> current.filterNot { it.id == id } }

    suspend fun clearCompleted() = update { current -> current.filterNot { it.completed } }

    private suspend fun update(transform: (List<WorkChecklistItem>) -> List<WorkChecklistItem>) {
        context.workChecklistDataStore.edit { prefs ->
            prefs[DATA_KEY] = json.encodeToString(transform(decode(prefs[DATA_KEY])))
        }
    }

    private fun decode(raw: String?): List<WorkChecklistItem> = raw?.let {
        runCatching { json.decodeFromString<List<WorkChecklistItem>>(it) }.getOrNull()
    }.orEmpty()

    private companion object {
        val DATA_KEY = stringPreferencesKey("items")
        const val MAX_ITEMS = 1000
    }
}
