package com.ganageo.app.ui.tools

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.StudyDeckStore
import com.ganageo.app.data.StudyFlashcard
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch

@Composable
fun FlashcardsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { StudyDeckStore(context.applicationContext) }
    val cards by store.cards.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var mode by rememberSaveable { mutableStateOf("Tarjetas") }
    var selectedDeck by rememberSaveable { mutableStateOf("General") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingExport by remember { mutableStateOf<String?>(null) }
    val decks = (cards.map { it.deck } + "General").distinct().sorted()
    LaunchedEffect(decks, selectedDeck) {
        if (selectedDeck !in decks) selectedDeck = decks.firstOrNull() ?: "General"
    }
    val deckCards = cards.filter { it.deck == selectedDeck }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("No se pudo leer") }
                .mapCatching { store.importDeck(it, selectedDeck) }
                .onSuccess { message = "$it tarjetas importadas" }
                .onFailure { message = "Error: ${it.message ?: "No se pudo importar"}" }
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val raw = pendingExport
        if (uri != null && raw != null) scope.launch {
            runCatching { context.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(raw) } ?: error("No se pudo guardar") }
                .onSuccess { message = "Banco exportado" }.onFailure { message = "Error: ${it.message}" }
        }
        pendingExport = null
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Flashcards y práctica", "Bancos, JSON y repetición espaciada local", onBack)
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Tarjetas", "Practicar").forEach { option ->
                FilledTonalButton(onClick = { mode = option; message = null }, modifier = Modifier.weight(1f), colors = ButtonDefaults.filledTonalButtonColors(containerColor = if (mode == option) NeonGreen else CardGreen, contentColor = if (mode == option) DeepGreen else MaterialTheme.colorScheme.onSurface)) { Text(option) }
            }
        }
        message?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) }
        if (mode == "Tarjetas") {
            FlashcardEditor(
                cards = deckCards,
                decks = decks,
                selectedDeck = selectedDeck,
                onDeckSelected = { selectedDeck = it },
                onAdd = { q, a, deck -> scope.launch { runCatching { store.addCard(q, a, deck) }.onSuccess { message = "Tarjeta guardada" }.onFailure { message = "Error: ${it.message}" } } },
                onDelete = { scope.launch { store.deleteCard(it) } },
                onRename = { old, new -> scope.launch { runCatching { store.renameDeck(old, new) }.onSuccess { selectedDeck = new; message = "Banco renombrado" }.onFailure { message = "Error: ${it.message}" } } },
                onImport = { importLauncher.launch(arrayOf("application/json", "text/plain")) },
                onExport = {
                    if (deckCards.isEmpty()) message = "No hay tarjetas para exportar" else {
                        pendingExport = store.exportDeck(cards, selectedDeck)
                        exportLauncher.launch("${selectedDeck.replace(Regex("[^A-Za-z0-9_-]"), "_")}_flashcards.json")
                    }
                }
            )
        } else {
            FlashcardPractice(deckCards) { card, rating -> scope.launch { store.reviewCard(card.id, rating) } }
        }
    }
}

@Composable
private fun FlashcardEditor(
    cards: List<StudyFlashcard>,
    decks: List<String>,
    selectedDeck: String,
    onDeckSelected: (String) -> Unit,
    onAdd: (String, String, String) -> Unit,
    onDelete: (String) -> Unit,
    onRename: (String, String) -> Unit,
    onImport: () -> Unit,
    onExport: () -> Unit
) {
    var question by rememberSaveable { mutableStateOf("") }
    var answer by rememberSaveable { mutableStateOf("") }
    var newDeck by rememberSaveable { mutableStateOf(selectedDeck) }
    var renameValue by rememberSaveable { mutableStateOf(selectedDeck) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SimpleDropdown("Banco", decks, decks.indexOf(selectedDeck).coerceAtLeast(0)) { onDeckSelected(decks[it]); newDeck = decks[it]; renameValue = decks[it] }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(renameValue, { renameValue = it.take(80) }, label = { Text("Nombre del banco") }, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { onRename(selectedDeck, renameValue) }, enabled = renameValue.isNotBlank() && renameValue != selectedDeck) { Text("Renombrar") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onImport, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.Download, null); Text(" Importar") }
                        OutlinedButton(onClick = onExport, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.Save, null); Text(" Exportar") }
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Crear tarjeta", style = MaterialTheme.typography.titleLarge)
                    OutlinedTextField(newDeck, { newDeck = it.take(80) }, label = { Text("Banco") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(question, { question = it.take(500) }, label = { Text("Pregunta") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    OutlinedTextField(answer, { answer = it.take(2000) }, label = { Text("Respuesta") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    Button(onClick = { onAdd(question, answer, newDeck); question = ""; answer = "" }, enabled = question.isNotBlank() && answer.isNotBlank(), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Guardar tarjeta", fontWeight = FontWeight.Bold) }
                }
            }
        }
        item { Text("$selectedDeck · ${cards.size} tarjetas", style = MaterialTheme.typography.titleLarge) }
        if (cards.isEmpty()) item { Text("Este banco todavía no tiene tarjetas.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(cards, key = { it.id }) { card ->
            Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(card.question, fontWeight = FontWeight.Bold)
                    Text(card.answer, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Próxima revisión: ${if (card.intervalDays == 0) "ahora" else "en ${card.intervalDays} días"}", color = Gold)
                    OutlinedButton(onClick = { onDelete(card.id) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Delete, null); Text(" Eliminar") }
                }
            }
        }
    }
}

@Composable
private fun FlashcardPractice(cards: List<StudyFlashcard>, onReview: (StudyFlashcard, Int) -> Unit) {
    val dueCards = cards.filter { it.dueAt == 0L || it.dueAt <= System.currentTimeMillis() }.ifEmpty { cards }
    var session by remember { mutableStateOf<List<StudyFlashcard>>(emptyList()) }
    var index by rememberSaveable { mutableIntStateOf(0) }
    var showAnswer by rememberSaveable { mutableStateOf(false) }
    var correct by rememberSaveable { mutableIntStateOf(0) }
    var incorrect by rememberSaveable { mutableIntStateOf(0) }
    val finished = session.isNotEmpty() && index >= session.size
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (cards.isEmpty()) item { Card(colors = CardDefaults.cardColors(containerColor = CardGreen)) { Text("Crea tarjetas antes de practicar.", modifier = Modifier.padding(18.dp)) } }
        else if (session.isEmpty()) item {
            Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Icon(Icons.Rounded.Shuffle, null, tint = NeonGreen)
                    Text("${dueCards.size} tarjetas para repasar", style = MaterialTheme.typography.titleLarge)
                    Button(onClick = { session = dueCards.shuffled(); index = 0; correct = 0; incorrect = 0; showAnswer = false }, colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Comenzar práctica") }
                }
            }
        } else if (finished) item {
            Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Práctica terminada", style = MaterialTheme.typography.headlineSmall)
                    Text("Recordadas: $correct · Repasar: $incorrect")
                    Button(onClick = { session = dueCards.shuffled(); index = 0; correct = 0; incorrect = 0; showAnswer = false }) { Icon(Icons.Rounded.Refresh, null); Text(" Repetir") }
                }
            }
        } else {
            val card = session[index]
            item { Text("Tarjeta ${index + 1} de ${session.size}") }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text(card.question, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                        if (showAnswer) Text(card.answer, color = NeonGreen, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                        else OutlinedButton(onClick = { showAnswer = true }) { Icon(Icons.Rounded.Visibility, null); Text(" Mostrar respuesta") }
                    }
                }
            }
            if (showAnswer) item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onReview(card, 0); incorrect++; index++; showAnswer = false }, modifier = Modifier.weight(1f)) { Text("Otra vez") }
                    OutlinedButton(onClick = { onReview(card, 1); correct++; index++; showAnswer = false }, modifier = Modifier.weight(1f)) { Text("Bien") }
                    Button(onClick = { onReview(card, 2); correct++; index++; showAnswer = false }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Fácil") }
                }
            }
        }
    }
}
