package com.ganageo.app.ui.tools

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ganageo.app.BuildConfig
import com.ganageo.app.GanaGeoUiState
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolCategory
import com.ganageo.app.model.ToolId
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.flow.collect

private data class CategoryPalette(
    val container: Color,
    val accent: Color,
    val badge: Color
)

private fun ToolCategory.palette(): CategoryPalette = when (this) {
    ToolCategory.MATH -> CategoryPalette(Color(0xFF102A48), Color(0xFF6EC1FF), Color(0xFF123B63))
    ToolCategory.VIEWERS -> CategoryPalette(Color(0xFF233244), Color(0xFFC5D9F1), Color(0xFF31455D))
    ToolCategory.PDF -> CategoryPalette(Color(0xFF401415), Color(0xFFFF7D7D), Color(0xFF5B1D1F))
    ToolCategory.IMAGE -> CategoryPalette(Color(0xFF402511), Color(0xFFFFB35A), Color(0xFF5A3517))
    ToolCategory.SCIENCE -> CategoryPalette(Color(0xFF113A3F), Color(0xFF74F1FF), Color(0xFF1B4F55))
    ToolCategory.ACADEMIC -> CategoryPalette(Color(0xFF2E184B), Color(0xFFC997FF), Color(0xFF43216C))
    ToolCategory.WORK -> CategoryPalette(Color(0xFF173825), Color(0xFF7CF3A6), Color(0xFF214B31))
    ToolCategory.GAME -> CategoryPalette(Color(0xFF102E45), NeonGreen, Color(0xFF1C425E))
    ToolCategory.QUICK -> CategoryPalette(Color(0xFF16343A), Color(0xFF6DE1D2), Color(0xFF1E4950))
}

@Composable
fun ToolsScreen(
    uiState: GanaGeoUiState,
    viewModel: GanaGeoViewModel,
    guestMode: Boolean = false,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    var selectedToolName by rememberSaveable { mutableStateOf(viewModel.rememberedToolName) }
    val selectedTool = selectedToolName?.let { name ->
        ToolId.entries.firstOrNull { it.name == name }
    }
    val snackbar = remember { SnackbarHostState() }
    var localMessage by remember { mutableStateOf<String?>(null) }
    val homeListState = rememberSaveable(saver = LazyListState.Saver) {
        LazyListState(viewModel.rememberedToolsScrollIndex, viewModel.rememberedToolsScrollOffset)
    }

    fun selectTool(name: String?) {
        selectedToolName = name
        viewModel.rememberTool(name)
    }

    BackHandler(enabled = selectedTool != null) {
        onImmersiveChanged(false)
        selectTool(null)
    }

    LaunchedEffect(homeListState) {
        snapshotFlow { homeListState.firstVisibleItemIndex to homeListState.firstVisibleItemScrollOffset }
            .collect { (index, offset) -> viewModel.rememberToolsScroll(index, offset) }
    }

    LaunchedEffect(selectedToolName) {
        if (selectedToolName == null) viewModel.retryPendingToolCompletions()
    }

    LaunchedEffect(localMessage) {
        localMessage?.let {
            snackbar.showSnackbar(it)
            localMessage = null
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (selectedTool == null) {
                ToolsHome(
                    uiState = uiState,
                    listState = homeListState,
                    guestMode = guestMode,
                    onOpen = { selectTool(it.name) },
                    onLocked = { localMessage = "Inicia sesión para desbloquear esta herramienta." },
                    onAddTestCredits = viewModel::addTestToolCredits
                )
            } else {
                ToolDestination(
                    tool = selectedTool,
                    viewModel = viewModel,
                    onBack = {
                        onImmersiveChanged(false)
                        selectTool(null)
                    },
                    onMessage = { localMessage = it },
                    onImmersiveChanged = onImmersiveChanged,
                    guestMode = guestMode
                )
            }
        }
    }
}

@Composable
private fun ToolsHome(
    uiState: GanaGeoUiState,
    listState: LazyListState,
    guestMode: Boolean,
    onOpen: (ToolId) -> Unit,
    onLocked: () -> Unit,
    onAddTestCredits: (Long) -> Unit
) {
    val realCredits = uiState.dashboard?.toolCredits?.availableCredits ?: 0
    val testCredits = if (BuildConfig.DEBUG) uiState.testToolBalance.availableCredits else 0
    val rewardPoints = uiState.dashboard?.wallet?.internalPoints ?: 0
    val testRewards = if (BuildConfig.DEBUG) uiState.testToolBalance.rewardPoints else 0
    val categories = listOf(
        ToolCategory.PDF,
        ToolCategory.WORK,
        ToolCategory.ACADEMIC,
        ToolCategory.MATH,
        ToolCategory.SCIENCE,
        ToolCategory.IMAGE,
        ToolCategory.VIEWERS,
        ToolCategory.QUICK
    )
    val allTools = ToolId.entries.filter { it.category != ToolCategory.GAME }
    val freeToolsCount = allTools.count { it.creditCost == 0 }
    val paidToolsCount = allTools.count { it.creditCost > 0 }

    var search by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf("Todas") }

    val filteredTools = allTools.filter { tool ->
        val matchesCategory = selectedCategory == "Todas" || tool.category.name == selectedCategory
        val query = search.trim().lowercase()
        val matchesSearch = query.isBlank() || tool.title.lowercase().contains(query) || tool.subtitle.lowercase().contains(query)
        matchesCategory && matchesSearch
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Herramientas Geo", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(5.dp))
            Text(
                "Estudia, crea documentos, trabaja con imágenes y resuelve tareas diarias desde un solo lugar.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            if (guestMode) {
                InfoBanner("Usa primero las herramientas gratuitas. Las funciones adicionales aparecen después, visibles con candado.")
            } else {
                CreditHero(
                    realCredits = realCredits,
                    realRewardPoints = rewardPoints,
                    testCredits = testCredits,
                    testRewardPoints = testRewards,
                    realProgress = uiState.dashboard?.toolCredits?.rewardProgress ?: 0,
                    testProgress = if (BuildConfig.DEBUG) uiState.testToolBalance.rewardProgress else 0,
                    freeToolsCount = freeToolsCount,
                    paidToolsCount = paidToolsCount
                )
            }
        }

        item {
            GeoAdventurePromoCard(
                guestMode = guestMode,
                onClick = { onOpen(ToolId.GEO_ADVENTURES) }
            )
        }

        item {
            SearchAndFilterCard(
                search = search,
                onSearchChange = { search = it.take(60) },
                selectedCategory = selectedCategory,
                categories = categories,
                onSelectCategory = { selectedCategory = it }
            )
        }

        if (!guestMode) {
            item {
                Text("Packs de créditos", style = MaterialTheme.typography.titleLarge)
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PackCard(
                        title = "Pack Geo 50",
                        price = "S/5",
                        credits = "50 créditos",
                        reward = "Hasta 250 Rewards",
                        modifier = Modifier.weight(1f),
                        onClick = { if (BuildConfig.DEBUG) onAddTestCredits(50) }
                    )
                    PackCard(
                        title = "Pack Geo 100",
                        price = "S/10",
                        credits = "100 créditos",
                        reward = "Hasta 500 Rewards",
                        modifier = Modifier.weight(1f),
                        onClick = { if (BuildConfig.DEBUG) onAddTestCredits(100) }
                    )
                }
            }

            item {
                InfoBanner(
                    if (BuildConfig.DEBUG) {
                        "Modo de prueba: los packs agregan créditos simulados. No cobran dinero ni generan saldo retirable real."
                    } else {
                        "Las compras se habilitarán mediante Google Play cuando los productos pack_geo_50 y pack_geo_100 estén configurados y verificados en el servidor."
                    }
                )
            }
        }

        if (filteredTools.isEmpty()) {
            item {
                EmptyToolsResultCard(
                    onReset = {
                        search = ""
                        selectedCategory = "Todas"
                    }
                )
            }
        } else if (guestMode) {
            val freeTools = filteredTools.filter { it.creditCost == 0 }
            val lockedTools = filteredTools.filter { it.creditCost > 0 }

            if (freeTools.isNotEmpty()) {
                item {
                    ToolAccessSectionHeader(
                        title = "Herramientas gratuitas",
                        subtitle = "Listas para usar sin iniciar sesión",
                        locked = false
                    )
                }
                categories.forEach { category ->
                    val toolsInCategory = freeTools.filter { it.category == category }
                    if (toolsInCategory.isNotEmpty()) {
                        item { CategoryHeaderCard(category = category, total = toolsInCategory.size) }
                        items(toolsInCategory, key = { "free_${it.name}" }) { tool ->
                            ToolCard(tool = tool, locked = false, onClick = { onOpen(tool) })
                        }
                    }
                }
            }

            if (lockedTools.isNotEmpty()) {
                item {
                    ToolAccessSectionHeader(
                        title = "Más herramientas",
                        subtitle = "Visibles con candado hasta iniciar sesión",
                        locked = true
                    )
                }
                categories.forEach { category ->
                    val toolsInCategory = lockedTools.filter { it.category == category }
                    if (toolsInCategory.isNotEmpty()) {
                        item { CategoryHeaderCard(category = category, total = toolsInCategory.size) }
                        items(toolsInCategory, key = { "locked_${it.name}" }) { tool ->
                            ToolCard(tool = tool, locked = true, onClick = onLocked)
                        }
                    }
                }
            }
        } else {
            categories.forEach { category ->
                val toolsInCategory = filteredTools.filter { it.category == category }
                if (toolsInCategory.isNotEmpty()) {
                    item { CategoryHeaderCard(category = category, total = toolsInCategory.size) }
                    items(toolsInCategory, key = { it.name }) { tool ->
                        ToolCard(tool = tool, locked = false, onClick = { onOpen(tool) })
                    }
                }
            }
        }

        item {
            InfoBanner(
                if (guestMode) {
                    "Tu progreso de invitado y Geo Aventuras se guardan en este dispositivo."
                } else {
                    "Las herramientas gratuitas no generan Rewards. En las herramientas pagadas, los créditos se descuentan al iniciar y los Rewards se confirman al terminar; si falla antes de crear el archivo, los créditos se devuelven."
                }
            )
        }
    }
}

@Composable
private fun SearchAndFilterCard(
    search: String,
    onSearchChange: (String) -> Unit,
    selectedCategory: String,
    categories: List<ToolCategory>,
    onSelectCategory: (String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Encuentra rápido lo que necesitas", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = search,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Buscar herramienta") },
                placeholder = { Text("PDF, matemáticas, CV, QR...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (search.isNotBlank()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Limpiar")
                        }
                    }
                }
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedCategory == "Todas",
                        onClick = { onSelectCategory("Todas") },
                        label = { Text("Todas") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonGreen,
                            selectedLabelColor = DeepGreen
                        )
                    )
                }
                items(categories, key = { it.name }) { category ->
                    val palette = category.palette()
                    FilterChip(
                        selected = selectedCategory == category.name,
                        onClick = { onSelectCategory(category.name) },
                        label = { Text(category.title) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = palette.container,
                            labelColor = MaterialTheme.colorScheme.onSurface,
                            selectedContainerColor = palette.accent,
                            selectedLabelColor = DeepGreen
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun ToolAccessSectionHeader(title: String, subtitle: String, locked: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (locked) Gold.copy(alpha = 0.10f) else NeonGreen.copy(alpha = 0.10f),
                RoundedCornerShape(18.dp)
            )
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            if (locked) Icons.Rounded.Lock else Icons.Rounded.CheckCircle,
            contentDescription = null,
            tint = if (locked) Gold else NeonGreen
        )
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CategoryHeaderCard(category: ToolCategory, total: Int) {
    val palette = category.palette()
    Card(
        colors = CardDefaults.cardColors(containerColor = palette.container),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(category.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(category.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box(
                modifier = Modifier.background(palette.badge, RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("$total", color = palette.accent, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun EmptyToolsResultCard(onReset: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2C1B1D)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("No encontramos herramientas con ese filtro", fontWeight = FontWeight.Bold)
            Text(
                "Prueba con otra palabra o vuelve a mostrar todas las categorías.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = onReset,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
                Text("Mostrar todo", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun GeoAdventurePromoCard(guestMode: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF102E45)),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier.size(64.dp).background(Color(0xFFE53935), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Box(Modifier.size(9.dp).background(Color.White, RoundedCornerShape(50)))
                    Box(Modifier.size(9.dp).background(Color.White, RoundedCornerShape(50)))
                }
            }
            Column(Modifier.weight(1f)) {
                Text("Geo Aventuras", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("20 niveles extremos · 15 vidas por partida", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if (guestMode) "Modo invitado: solo vidas rojas" else "Toca para jugar", color = NeonGreen, fontWeight = FontWeight.Bold)
            }
            Icon(Icons.Rounded.ArrowBack, contentDescription = null, tint = NeonGreen, modifier = Modifier.graphicsLayer(rotationZ = 180f))
        }
    }
}

@Composable
private fun CreditHero(
    realCredits: Long,
    realRewardPoints: Long,
    testCredits: Long,
    testRewardPoints: Long,
    realProgress: Long,
    testProgress: Long,
    freeToolsCount: Int,
    paidToolsCount: Int
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = NeonGreen)
                Spacer(Modifier.width(8.dp))
                Text("Créditos para herramientas", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallInfo("Créditos disponibles", realCredits.toString(), Icons.Rounded.CheckCircle, Modifier.weight(1f))
                SmallInfo("Geo Rewards", realRewardPoints.toString(), Icons.Rounded.CheckCircle, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallInfo("Gratis", freeToolsCount.toString(), Icons.Rounded.Info, Modifier.weight(1f))
                SmallInfo("Con créditos", paidToolsCount.toString(), Icons.Rounded.Lock, Modifier.weight(1f))
            }
            Text(
                "Progreso para los próximos 50 Rewards: $realProgress/10 créditos comprados usados",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium
            )
            if (BuildConfig.DEBUG) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SmallInfo("Créditos de prueba", testCredits.toString(), Icons.Rounded.Info, Modifier.weight(1f))
                    SmallInfo("Rewards de prueba", testRewardPoints.toString(), Icons.Rounded.Info, Modifier.weight(1f))
                }
                Text(
                    "Progreso de prueba: $testProgress/10",
                    color = Gold,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun SmallInfo(label: String, value: String, icon: ImageVector, modifier: Modifier) {
    Row(
        modifier = modifier
            .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(value, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PackCard(
    title: String,
    price: String,
    credits: String,
    reward: String,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(enabled = BuildConfig.DEBUG, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = NeonGreen)
            Spacer(Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(price, color = NeonGreen, style = MaterialTheme.typography.titleLarge)
            Text(credits, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(reward, color = Gold, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                if (BuildConfig.DEBUG) "Agregar para probar" else "Google Play",
                color = if (BuildConfig.DEBUG) NeonGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun ToolCard(tool: ToolId, locked: Boolean = false, onClick: () -> Unit) {
    val palette = tool.category.palette()
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer(alpha = if (locked) 0.78f else 1f)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = palette.container),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(palette.badge, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(tool.icon, contentDescription = null, tint = palette.accent)
            }
            Spacer(Modifier.width(13.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(tool.title, fontWeight = FontWeight.Bold)
                Text(tool.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Text(
                    tool.category.title,
                    color = palette.accent,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (locked || tool.creditCost > 0) {
                Column(horizontalAlignment = Alignment.End) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = Gold, modifier = Modifier.size(18.dp))
                    Text(if (locked) "Bloqueada" else "${tool.creditCost} cr.", color = Gold, fontWeight = FontWeight.Bold)
                }
            } else {
                Text("Gratis", color = palette.accent, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun InfoBanner(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.10f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Rounded.Info, contentDescription = null, tint = Gold)
            Spacer(Modifier.width(10.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun ToolHeader(title: String, subtitle: String, onBack: () -> Unit) {
    val accent = when {
        title.contains("PDF", ignoreCase = true) || title.contains("document", ignoreCase = true) || title.contains("Word", ignoreCase = true) -> Color(0xFFFF7D7D)
        title.contains("matem", ignoreCase = true) || title.contains("calcul", ignoreCase = true) || title.contains("ecuaci", ignoreCase = true) || title.contains("funci", ignoreCase = true) || title.contains("geometr", ignoreCase = true) || title.contains("estad", ignoreCase = true) -> Color(0xFF6EC1FF)
        title.contains("imagen", ignoreCase = true) || title.contains("foto", ignoreCase = true) || title.contains("escáner", ignoreCase = true) -> Color(0xFFFFB35A)
        title.contains("estudio", ignoreCase = true) || title.contains("acad", ignoreCase = true) || title.contains("flash", ignoreCase = true) || title.contains("referenc", ignoreCase = true) || title.contains("examen", ignoreCase = true) -> Color(0xFFC997FF)
        title.contains("trabajo", ignoreCase = true) || title.contains("CV", ignoreCase = true) || title.contains("inventario", ignoreCase = true) || title.contains("cotiz", ignoreCase = true) || title.contains("ingresos", ignoreCase = true) || title.contains("comision", ignoreCase = true) -> Color(0xFF7CF3A6)
        title.contains("química", ignoreCase = true) || title.contains("física", ignoreCase = true) || title.contains("periódica", ignoreCase = true) -> Color(0xFF74F1FF)
        else -> NeonGreen
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.09f)),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = accent)
            }
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(accent.copy(alpha = 0.18f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    title.trim().firstOrNull()?.uppercase() ?: "G",
                    color = accent,
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.titleLarge
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun ToolDestination(
    tool: ToolId,
    viewModel: GanaGeoViewModel,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit,
    guestMode: Boolean
) {
    if (guestMode && tool.creditCost > 0) {
        LaunchedEffect(tool) { onMessage("Inicia sesión para usar esta función."); onBack() }
        return
    }
    when (tool) {
        ToolId.SCIENTIFIC_CALCULATOR -> ScientificCalculatorScreen(onBack)
        ToolId.UNIT_CONVERTER -> UnitConverterScreen(onBack)
        ToolId.PERCENT_RULE -> PercentRuleScreen(onBack)
        ToolId.GRADES_AVERAGES -> GradesAverageScreen(onBack)
        ToolId.GEOMETRY -> GeometryScreen(onBack)
        ToolId.ADVANCED_MATH -> AdvancedMathScreen(onBack)
        ToolId.EQUATION_SOLVER -> EquationSolverScreen(onBack)
        ToolId.FUNCTION_GRAPHER -> FunctionGrapherScreen(onBack)
        ToolId.STATISTICS -> StatisticsScreen(onBack)
        ToolId.PHYSICS_CALCULATOR -> PhysicsCalculatorScreen(onBack)
        ToolId.PERIODIC_TABLE -> PeriodicTableScreen(onBack)
        ToolId.CHEMISTRY_CALCULATOR -> ChemistryCalculatorScreen(onBack)
        ToolId.NUMBER_SYSTEMS -> NumberSystemsScreen(onBack)
        ToolId.CITATION_GENERATOR -> CitationGeneratorScreen(onBack)
        ToolId.EXAM_BUILDER -> ExamBuilderScreen(onBack, onMessage)
        ToolId.STUDY_PLANNER_PRO -> StudyPlannerProScreen(onBack, onMessage)
        ToolId.FINANCE_CALCULATOR -> StudentFinanceScreen(onBack)
        ToolId.FLASHCARDS -> FlashcardsScreen(onBack)
        ToolId.ACADEMIC_PLANNER -> AcademicPlannerScreen(onBack)
        ToolId.TEXT_TOOLKIT -> TextToolkitScreen(onBack)
        ToolId.CV_BUILDER -> CvBuilderScreen(onBack)
        ToolId.WORK_HOURS -> WorkHoursScreen(onBack)
        ToolId.QUOTE_IGV -> QuoteIgvScreen(onBack)
        ToolId.INCOME_EXPENSE_TRACKER -> IncomeExpenseTrackerScreen(onBack)
        ToolId.INVENTORY_BASIC -> InventoryBasicScreen(onBack)
        ToolId.COMMISSION_MARGIN -> CommissionMarginScreen(onBack)
        ToolId.WORK_CHECKLIST -> WorkChecklistScreen(onBack)
        ToolId.GEO_ADVENTURES -> GeoAdventuresScreen(viewModel, onBack, onMessage, onImmersiveChanged, guestMode)
        ToolId.PDF_VIEWER -> PdfViewerScreen(tool, onBack, onMessage)
        ToolId.WORD_VIEWER -> OfficeViewerScreen(tool, OfficeViewerType.WORD, onBack, onMessage)
        ToolId.EXCEL_VIEWER -> OfficeViewerScreen(tool, OfficeViewerType.EXCEL, onBack, onMessage)
        ToolId.POWERPOINT_VIEWER -> OfficeViewerScreen(tool, OfficeViewerType.POWERPOINT, onBack, onMessage)
        ToolId.DOCUMENT_SCANNER -> DocumentScannerScreen(viewModel, tool, onBack, onMessage)
        ToolId.TEXT_TO_PDF -> TextToPdfScreen(viewModel, tool, onBack, onMessage)
        ToolId.PDF_WATERMARK_SECURITY -> PdfWatermarkSecurityScreen(viewModel, tool, onBack, onMessage)
        ToolId.IMAGES_TO_PDF -> ImagesToPdfScreen(viewModel, tool, onBack, onMessage)
        ToolId.PDF_ORGANIZER -> PdfOrganizerScreen(viewModel, tool, onBack, onMessage)
        ToolId.PDF_TO_IMAGES -> PdfToImagesScreen(viewModel, tool, onBack, onMessage)
        ToolId.SIGN_PDF -> SignPdfScreen(viewModel, tool, onBack, onMessage)
        ToolId.IMAGE_BATCH_STUDIO -> ImageBatchStudioScreen(viewModel, tool, onBack, onMessage)
        ToolId.COMPRESS_IMAGE,
        ToolId.RESIZE_IMAGE,
        ToolId.CONVERT_IMAGE,
        ToolId.CROP_ROTATE_IMAGE,
        ToolId.WATERMARK_IMAGE -> ImageToolScreen(viewModel, tool, onBack, onMessage)
        ToolId.QR_TOOL -> QrToolScreen(onBack, onMessage)
        ToolId.WORD_COUNTER -> WordCounterScreen(onBack)
        ToolId.STOPWATCH_TIMER -> StopwatchTimerScreen(onBack)
    }
}
