package com.ganageo.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class StudyReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Recordatorios de estudio", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Avisos locales creados en el planificador de Gana Geo"
            }
        )
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Recordatorio de estudio" }
        val text = intent.getStringExtra(EXTRA_TEXT).orEmpty().ifBlank { "Es momento de continuar tu planificación." }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.ganageo.app.R.drawable.logo_gana_geo)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(intent.getIntExtra(EXTRA_ID, 1001), notification) }
    }

    companion object {
        const val CHANNEL_ID = "gana_geo_study_reminders"
        const val EXTRA_TITLE = "title"
        const val EXTRA_TEXT = "text"
        const val EXTRA_ID = "id"
    }
}
