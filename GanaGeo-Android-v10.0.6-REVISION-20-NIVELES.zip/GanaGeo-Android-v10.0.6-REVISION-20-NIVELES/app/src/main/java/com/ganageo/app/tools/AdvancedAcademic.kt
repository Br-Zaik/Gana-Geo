package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.pow
import kotlin.math.sqrt

object MatrixCalculator {
    fun parse(raw: String, expectedSize: Int? = null): Array<DoubleArray> {
        val rows = raw.trim()
            .lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .map { line ->
                line.split(',', ';', ' ', '\t')
                    .map(String::trim)
                    .filter(String::isNotBlank)
                    .map { it.replace(',', '.').toDoubleOrNull() ?: error("Número inválido: $it") }
                    .toDoubleArray()
            }
        require(rows.isNotEmpty()) { "Escribe la matriz" }
        require(rows.all { it.size == rows.first().size }) { "Todas las filas deben tener la misma cantidad de valores" }
        if (expectedSize != null) {
            require(rows.size == expectedSize && rows.first().size == expectedSize) {
                "La matriz debe ser de ${expectedSize}×$expectedSize"
            }
        }
        return rows.toTypedArray()
    }

    fun determinant(matrix: Array<DoubleArray>): Double {
        require(matrix.isNotEmpty() && matrix.all { it.size == matrix.size }) { "La matriz debe ser cuadrada" }
        val n = matrix.size
        val copy = Array(n) { matrix[it].clone() }
        var sign = 1.0
        var determinant = 1.0
        for (column in 0 until n) {
            var pivot = column
            for (row in column + 1 until n) {
                if (abs(copy[row][column]) > abs(copy[pivot][column])) pivot = row
            }
            if (abs(copy[pivot][column]) < 1e-12) return 0.0
            if (pivot != column) {
                val temp = copy[pivot]
                copy[pivot] = copy[column]
                copy[column] = temp
                sign *= -1
            }
            val pivotValue = copy[column][column]
            determinant *= pivotValue
            for (row in column + 1 until n) {
                val factor = copy[row][column] / pivotValue
                for (item in column + 1 until n) copy[row][item] -= factor * copy[column][item]
            }
        }
        return determinant * sign
    }

    fun inverse(matrix: Array<DoubleArray>): Array<DoubleArray> {
        require(matrix.isNotEmpty() && matrix.all { it.size == matrix.size }) { "La matriz debe ser cuadrada" }
        val n = matrix.size
        val augmented = Array(n) { row ->
            DoubleArray(n * 2) { column ->
                when {
                    column < n -> matrix[row][column]
                    column - n == row -> 1.0
                    else -> 0.0
                }
            }
        }
        for (column in 0 until n) {
            var pivot = column
            for (row in column + 1 until n) {
                if (abs(augmented[row][column]) > abs(augmented[pivot][column])) pivot = row
            }
            require(abs(augmented[pivot][column]) > 1e-12) { "La matriz no tiene inversa" }
            val temp = augmented[pivot]
            augmented[pivot] = augmented[column]
            augmented[column] = temp
            val divisor = augmented[column][column]
            for (item in 0 until n * 2) augmented[column][item] /= divisor
            for (row in 0 until n) {
                if (row == column) continue
                val factor = augmented[row][column]
                for (item in 0 until n * 2) augmented[row][item] -= factor * augmented[column][item]
            }
        }
        return Array(n) { row -> DoubleArray(n) { column -> augmented[row][column + n] } }
    }

    fun multiply(left: Array<DoubleArray>, right: Array<DoubleArray>): Array<DoubleArray> {
        require(left.isNotEmpty() && right.isNotEmpty()) { "Las matrices no pueden estar vacías" }
        require(left.all { it.size == left.first().size } && right.all { it.size == right.first().size }) {
            "Las matrices deben ser rectangulares"
        }
        require(left.first().size == right.size) { "Las columnas de A deben coincidir con las filas de B" }
        return Array(left.size) { row ->
            DoubleArray(right.first().size) { column ->
                (right.indices).sumOf { k -> left[row][k] * right[k][column] }
            }
        }
    }

    fun solve3(coefficients: Array<DoubleArray>, constants: DoubleArray): DoubleArray {
        require(coefficients.size == 3 && coefficients.all { it.size == 3 } && constants.size == 3) {
            "Se necesita un sistema de 3 ecuaciones"
        }
        val det = determinant(coefficients)
        require(abs(det) > 1e-12) { "El sistema no tiene una solución única" }
        return DoubleArray(3) { column ->
            val replaced = Array(3) { row -> coefficients[row].clone() }
            for (row in 0..2) replaced[row][column] = constants[row]
            determinant(replaced) / det
        }
    }

    fun format(matrix: Array<DoubleArray>): String = matrix.joinToString("\n") { row ->
        row.joinToString("   ") { formatNumber(it) }
    }

    fun formatNumber(value: Double): String = if (abs(value - value.toLong()) < 1e-10) {
        value.toLong().toString()
    } else {
        "%.6f".format(value).trimEnd('0').trimEnd('.')
    }
}

data class VectorResult(
    val magnitudeA: Double,
    val magnitudeB: Double,
    val dotProduct: Double,
    val angleDegrees: Double?,
    val sum: DoubleArray,
    val difference: DoubleArray
)

object VectorCalculator {
    fun parse(raw: String): DoubleArray {
        val values = raw.split(',', ';', ' ', '\t')
            .map(String::trim)
            .filter(String::isNotBlank)
            .map { it.replace(',', '.').toDoubleOrNull() ?: error("Componente inválido: $it") }
        require(values.size in 2..3) { "Escribe 2 o 3 componentes" }
        return values.toDoubleArray()
    }

    fun analyze(a: DoubleArray, b: DoubleArray): VectorResult {
        require(a.size == b.size) { "Los vectores deben tener la misma dimensión" }
        val magnitudeA = sqrt(a.sumOf { it * it })
        val magnitudeB = sqrt(b.sumOf { it * it })
        val dot = a.indices.sumOf { a[it] * b[it] }
        val angle = if (magnitudeA > 0 && magnitudeB > 0) {
            Math.toDegrees(acos((dot / (magnitudeA * magnitudeB)).coerceIn(-1.0, 1.0)))
        } else null
        return VectorResult(
            magnitudeA = magnitudeA,
            magnitudeB = magnitudeB,
            dotProduct = dot,
            angleDegrees = angle,
            sum = DoubleArray(a.size) { a[it] + b[it] },
            difference = DoubleArray(a.size) { a[it] - b[it] }
        )
    }
}

data class SequenceResult(
    val terms: List<Double>,
    val nthTerm: Double,
    val sum: Double,
    val formula: String
)

object SequenceCalculator {
    fun arithmetic(first: Double, difference: Double, count: Int): SequenceResult {
        require(count in 1..1000) { "La cantidad de términos debe estar entre 1 y 1000" }
        val terms = List(count) { first + it * difference }
        val nth = terms.last()
        return SequenceResult(terms, nth, count * (first + nth) / 2.0, "aₙ = a₁ + (n − 1)d")
    }

    fun geometric(first: Double, ratio: Double, count: Int): SequenceResult {
        require(count in 1..200) { "La cantidad de términos debe estar entre 1 y 200" }
        val terms = List(count) { first * ratio.pow(it) }
        val sum = if (abs(ratio - 1.0) < 1e-12) first * count else first * (1 - ratio.pow(count)) / (1 - ratio)
        return SequenceResult(terms, terms.last(), sum, "aₙ = a₁ · rⁿ⁻¹")
    }
}

data class CalculusResult(val result: String, val steps: List<String>)

object BasicCalculus {
    private data class Term(val coefficient: Double, val exponent: Int)

    fun derivative(raw: String): CalculusResult {
        val terms = parsePolynomial(raw)
        val output = terms.mapNotNull { term ->
            if (term.exponent == 0) null else Term(term.coefficient * term.exponent, term.exponent - 1)
        }
        val steps = terms.map { term ->
            if (term.exponent == 0) "La derivada de ${formatTerm(term)} es 0"
            else "d/dx(${formatTerm(term)}) = ${formatTerm(Term(term.coefficient * term.exponent, term.exponent - 1))}"
        }
        return CalculusResult(formatPolynomial(output), steps + "Resultado: ${formatPolynomial(output)}")
    }

    fun integral(raw: String): CalculusResult {
        val terms = parsePolynomial(raw)
        val output = terms.map { term -> Term(term.coefficient / (term.exponent + 1), term.exponent + 1) }
        val steps = terms.map { term ->
            "∫${formatTerm(term)} dx = ${formatTerm(Term(term.coefficient / (term.exponent + 1), term.exponent + 1))}"
        }
        return CalculusResult("${formatPolynomial(output)} + C", steps + "Resultado: ${formatPolynomial(output)} + C")
    }

    private fun parsePolynomial(raw: String): List<Term> {
        val cleaned = raw.replace(" ", "").replace("−", "-")
        require(cleaned.isNotBlank()) { "Escribe un polinomio" }
        require(cleaned.matches(Regex("[0-9xX+\\-.*^]+"))) {
            "Por ahora se admiten polinomios, por ejemplo: 3x^2-4x+7"
        }
        val normalized = if (cleaned.first() in listOf('+', '-')) cleaned else "+$cleaned"
        val chunks = Regex("([+-])([^+-]+)").findAll(normalized).map { it.groupValues[1] to it.groupValues[2] }.toList()
        require(chunks.isNotEmpty()) { "No se pudo interpretar el polinomio" }
        return chunks.map { (sign, bodyRaw) ->
            val body = bodyRaw.replace("X", "x").replace("*", "")
            val multiplier = if (sign == "-") -1.0 else 1.0
            if ('x' !in body) {
                Term(multiplier * (body.toDoubleOrNull() ?: error("Término inválido: $body")), 0)
            } else {
                val parts = body.split('x', limit = 2)
                val coefficient = when (parts[0]) {
                    "" -> 1.0
                    else -> parts[0].toDoubleOrNull() ?: error("Coeficiente inválido: ${parts[0]}")
                }
                val exponent = when {
                    parts[1].isBlank() -> 1
                    parts[1].startsWith("^") -> parts[1].drop(1).toIntOrNull() ?: error("Exponente inválido")
                    else -> error("Usa ^ para indicar exponentes")
                }
                require(exponent in 0..20) { "El exponente debe estar entre 0 y 20" }
                Term(multiplier * coefficient, exponent)
            }
        }
    }

    private fun formatPolynomial(terms: List<Term>): String {
        if (terms.isEmpty() || terms.all { abs(it.coefficient) < 1e-12 }) return "0"
        return terms.filter { abs(it.coefficient) >= 1e-12 }
            .sortedByDescending { it.exponent }
            .mapIndexed { index, term ->
                val absolute = term.copy(coefficient = abs(term.coefficient))
                val body = formatTerm(absolute)
                when {
                    index == 0 && term.coefficient < 0 -> "-$body"
                    index == 0 -> body
                    term.coefficient < 0 -> " - $body"
                    else -> " + $body"
                }
            }.joinToString("")
    }

    private fun formatTerm(term: Term): String {
        val coefficient = term.coefficient
        return when (term.exponent) {
            0 -> MatrixCalculator.formatNumber(coefficient)
            1 -> when {
                abs(coefficient - 1.0) < 1e-12 -> "x"
                abs(coefficient + 1.0) < 1e-12 -> "-x"
                else -> "${MatrixCalculator.formatNumber(coefficient)}x"
            }
            else -> when {
                abs(coefficient - 1.0) < 1e-12 -> "x^${term.exponent}"
                abs(coefficient + 1.0) < 1e-12 -> "-x^${term.exponent}"
                else -> "${MatrixCalculator.formatNumber(coefficient)}x^${term.exponent}"
            }
        }
    }
}

data class FinanceResult(val principal: Double, val interest: Double, val total: Double, val payment: Double? = null)

object StudentFinanceCalculator {
    fun simpleInterest(principal: Double, annualRatePercent: Double, years: Double): FinanceResult {
        require(principal >= 0 && annualRatePercent >= 0 && years >= 0) { "Los valores no pueden ser negativos" }
        val interest = principal * annualRatePercent / 100.0 * years
        return FinanceResult(principal, interest, principal + interest)
    }

    fun compoundInterest(principal: Double, annualRatePercent: Double, years: Double, periodsPerYear: Int): FinanceResult {
        require(principal >= 0 && annualRatePercent >= 0 && years >= 0) { "Los valores no pueden ser negativos" }
        require(periodsPerYear in 1..365) { "Frecuencia de capitalización inválida" }
        val total = principal * (1 + annualRatePercent / 100.0 / periodsPerYear).pow(periodsPerYear * years)
        return FinanceResult(principal, total - principal, total)
    }

    fun loanPayment(amount: Double, annualRatePercent: Double, months: Int): FinanceResult {
        require(amount > 0) { "El monto debe ser mayor que cero" }
        require(annualRatePercent >= 0) { "La tasa no puede ser negativa" }
        require(months in 1..600) { "El plazo debe estar entre 1 y 600 meses" }
        val monthlyRate = annualRatePercent / 100.0 / 12.0
        val payment = if (monthlyRate == 0.0) amount / months else amount * monthlyRate / (1 - (1 + monthlyRate).pow(-months))
        val total = payment * months
        return FinanceResult(amount, total - amount, total, payment)
    }
}

data class PeriodicElement(
    val atomicNumber: Int,
    val symbol: String,
    val name: String,
    val atomicMass: Double,
    val category: String,
    val group: Int?,
    val period: Int
)

object PeriodicTableData {
    private val symbols = listOf(
        "H","He","Li","Be","B","C","N","O","F","Ne","Na","Mg","Al","Si","P","S","Cl","Ar",
        "K","Ca","Sc","Ti","V","Cr","Mn","Fe","Co","Ni","Cu","Zn","Ga","Ge","As","Se","Br","Kr",
        "Rb","Sr","Y","Zr","Nb","Mo","Tc","Ru","Rh","Pd","Ag","Cd","In","Sn","Sb","Te","I","Xe",
        "Cs","Ba","La","Ce","Pr","Nd","Pm","Sm","Eu","Gd","Tb","Dy","Ho","Er","Tm","Yb","Lu","Hf",
        "Ta","W","Re","Os","Ir","Pt","Au","Hg","Tl","Pb","Bi","Po","At","Rn","Fr","Ra","Ac","Th",
        "Pa","U","Np","Pu","Am","Cm","Bk","Cf","Es","Fm","Md","No","Lr","Rf","Db","Sg","Bh","Hs",
        "Mt","Ds","Rg","Cn","Nh","Fl","Mc","Lv","Ts","Og"
    )
    private val names = listOf(
        "Hidrógeno","Helio","Litio","Berilio","Boro","Carbono","Nitrógeno","Oxígeno","Flúor","Neón","Sodio","Magnesio","Aluminio","Silicio","Fósforo","Azufre","Cloro","Argón",
        "Potasio","Calcio","Escandio","Titanio","Vanadio","Cromo","Manganeso","Hierro","Cobalto","Níquel","Cobre","Zinc","Galio","Germanio","Arsénico","Selenio","Bromo","Kriptón",
        "Rubidio","Estroncio","Itrio","Circonio","Niobio","Molibdeno","Tecnecio","Rutenio","Rodio","Paladio","Plata","Cadmio","Indio","Estaño","Antimonio","Telurio","Yodo","Xenón",
        "Cesio","Bario","Lantano","Cerio","Praseodimio","Neodimio","Prometio","Samario","Europio","Gadolinio","Terbio","Disprosio","Holmio","Erbio","Tulio","Iterbio","Lutecio","Hafnio",
        "Tantalio","Wolframio","Renio","Osmio","Iridio","Platino","Oro","Mercurio","Talio","Plomo","Bismuto","Polonio","Astato","Radón","Francio","Radio","Actinio","Torio",
        "Protactinio","Uranio","Neptunio","Plutonio","Americio","Curio","Berkelio","Californio","Einstenio","Fermio","Mendelevio","Nobelio","Lawrencio","Rutherfordio","Dubnio","Seaborgio","Bohrio","Hassio",
        "Meitnerio","Darmstadtio","Roentgenio","Copernicio","Nihonio","Flerovio","Moscovio","Livermorio","Teneso","Oganesón"
    )

    val elements: List<PeriodicElement> = symbols.indices.map { index ->
        val atomicNumber = index + 1
        val symbol = symbols[index]
        PeriodicElement(
            atomicNumber = atomicNumber,
            symbol = symbol,
            name = names[index],
            atomicMass = ChemistryCalculator.atomicMass(symbol) ?: 0.0,
            category = categoryFor(atomicNumber),
            group = groupFor(atomicNumber),
            period = periodFor(atomicNumber)
        )
    }

    fun search(query: String): List<PeriodicElement> {
        val normalized = query.trim().lowercase()
        if (normalized.isBlank()) return elements
        return elements.filter {
            it.name.lowercase().contains(normalized) ||
                it.symbol.lowercase() == normalized ||
                it.atomicNumber.toString() == normalized ||
                it.category.lowercase().contains(normalized)
        }
    }

    private fun periodFor(z: Int): Int = when (z) {
        in 1..2 -> 1
        in 3..10 -> 2
        in 11..18 -> 3
        in 19..36 -> 4
        in 37..54 -> 5
        in 55..86 -> 6
        else -> 7
    }

    private fun groupFor(z: Int): Int? = when (z) {
        1 -> 1; 2 -> 18
        in 3..10 -> listOf(1,2,13,14,15,16,17,18)[z-3]
        in 11..18 -> listOf(1,2,13,14,15,16,17,18)[z-11]
        in 19..36 -> z - 18
        in 37..54 -> z - 36
        55 -> 1; 56 -> 2; 57 -> 3
        in 58..71 -> null
        in 72..86 -> z - 68
        87 -> 1; 88 -> 2; 89 -> 3
        in 90..103 -> null
        in 104..118 -> z - 100
        else -> null
    }

    private fun categoryFor(z: Int): String = when {
        z in setOf(2,10,18,36,54,86,118) -> "Gas noble"
        z in setOf(9,17,35,53,85,117) -> "Halógeno"
        z in setOf(3,11,19,37,55,87) -> "Metal alcalino"
        z in setOf(4,12,20,38,56,88) -> "Metal alcalinotérreo"
        z in 57..71 -> "Lantánido"
        z in 89..103 -> "Actínido"
        z in setOf(5,14,32,33,51,52) -> "Metaloide"
        z in setOf(1,6,7,8,15,16,34) -> "No metal"
        z in setOf(13,31,49,50,81,82,83,84,113,114,115,116) -> "Metal postransición"
        z in 21..30 || z in 39..48 || z in 72..80 || z in 104..112 -> "Metal de transición"
        else -> "Elemento químico"
    }
}

object ChemistryProCalculator {
    private const val GAS_CONSTANT = 0.082057 // L·atm·mol⁻¹·K⁻¹

    fun molarity(moles: Double, liters: Double): Double {
        require(moles >= 0 && liters > 0) { "Los moles deben ser positivos y el volumen mayor que cero" }
        return moles / liters
    }

    fun dilutionFinalVolume(initialConcentration: Double, initialVolume: Double, finalConcentration: Double): Double {
        require(initialConcentration > 0 && initialVolume > 0 && finalConcentration > 0) { "Todos los valores deben ser mayores que cero" }
        return initialConcentration * initialVolume / finalConcentration
    }

    fun idealGasMoles(pressureAtm: Double, volumeLiters: Double, temperatureKelvin: Double): Double {
        require(pressureAtm > 0 && volumeLiters > 0 && temperatureKelvin > 0) { "Presión, volumen y temperatura deben ser mayores que cero" }
        return pressureAtm * volumeLiters / (GAS_CONSTANT * temperatureKelvin)
    }

    fun electronConfiguration(atomicNumber: Int): String {
        require(atomicNumber in 1..118) { "El número atómico debe estar entre 1 y 118" }
        val orbitals = listOf(
            "1s" to 2, "2s" to 2, "2p" to 6, "3s" to 2, "3p" to 6, "4s" to 2,
            "3d" to 10, "4p" to 6, "5s" to 2, "4d" to 10, "5p" to 6, "6s" to 2,
            "4f" to 14, "5d" to 10, "6p" to 6, "7s" to 2, "5f" to 14, "6d" to 10, "7p" to 6
        )
        var remaining = atomicNumber
        return buildList {
            orbitals.forEach { (orbital, capacity) ->
                if (remaining > 0) {
                    val electrons = minOf(remaining, capacity)
                    add("$orbital$electrons")
                    remaining -= electrons
                }
            }
        }.joinToString(" ")
    }
}
