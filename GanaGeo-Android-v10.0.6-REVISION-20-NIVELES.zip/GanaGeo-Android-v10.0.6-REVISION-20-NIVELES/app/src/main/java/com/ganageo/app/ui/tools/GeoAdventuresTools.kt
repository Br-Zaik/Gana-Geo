package com.ganageo.app.ui.tools

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.GeoGameRunStart
import com.ganageo.app.model.GeoGameStatus
import com.ganageo.app.tools.AdventureLevel
import com.ganageo.app.tools.CheckpointKind
import com.ganageo.app.tools.CrusherAxis
import com.ganageo.app.tools.FallingBehavior
import com.ganageo.app.tools.FallingObjectKind
import com.ganageo.app.tools.GameEnemyKind
import com.ganageo.app.tools.GameHazard
import com.ganageo.app.tools.GamePickupKind
import com.ganageo.app.tools.GamePlatform
import com.ganageo.app.tools.GeoAdventureLevelFactory
import com.ganageo.app.tools.GeoGameRules
import com.ganageo.app.tools.GeoLifePackage
import com.ganageo.app.tools.HazardKind
import com.ganageo.app.tools.HazardOrientation
import com.ganageo.app.tools.PlatformKind
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun GeoAdventuresScreen(
    viewModel: GanaGeoViewModel,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {},
    guestMode: Boolean = false
) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<GeoGameStatus?>(null) }
    var loading by remember { mutableStateOf(true) }
    var localMode by remember { mutableStateOf(guestMode) }
    var activeRun by remember { mutableStateOf<GeoGameRunStart?>(null) }
    var activeLevel by rememberSaveable { mutableIntStateOf(1) }
    var pendingPurchase by remember { mutableStateOf<GeoLifePackage?>(null) }
    var selectedLifeType by rememberSaveable { mutableStateOf("free") }
    var storyBeforeStart by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var pendingLifeType by remember { mutableStateOf("free") }
    var shownStories by remember { mutableStateOf(setOf<Int>()) }
    var countdownNowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var nextLifeDeadlineMs by remember { mutableLongStateOf(0L) }

    fun reload(preferLocal: Boolean = localMode) {
        scope.launch {
            loading = true
            viewModel.loadGeoGameStatus(preferLocal)
                .onSuccess {
                    status = it
                    localMode = it.isLocalTest
                    activeLevel = activeLevel.coerceAtMost(it.unlockedLevel.coerceAtLeast(1))
                }
                .onFailure { onMessage(it.message ?: "No se pudo cargar Geo Aventuras.") }
            loading = false
        }
    }

    fun startLevel(level: Int, lifeType: String) {
        val levelData = GeoAdventureLevelFactory.build(level)
        if (levelData.introStory != null && level !in shownStories) {
            pendingLifeType = lifeType
            storyBeforeStart = level to levelData.introStory
            shownStories = shownStories + level
            return
        }
        scope.launch {
            loading = true
            viewModel.startGeoGameRun(level, lifeType, localMode)
                .onSuccess {
                    activeLevel = level
                    activeRun = it
                }
                .onFailure { onMessage(it.message ?: "No se pudo iniciar el nivel.") }
            loading = false
        }
    }

    fun chooseLevel(level: Int) {
        val current = status ?: return
        if (level > current.unlockedLevel || loading) return
        val canUsePremium = !guestMode &&
            current.premiumLives > 0 &&
            current.premiumUsedToday < current.premiumDailyLimit
        val lifeType = if (selectedLifeType == "premium" && canUsePremium) "premium" else "free"
        if (lifeType == "free" && current.freeLives <= 0) {
            onMessage("No tienes vidas rojas disponibles. Espera la recuperación o inicia sesión para revisar tus opciones.")
            return
        }
        if (selectedLifeType == "premium" && !canUsePremium) selectedLifeType = "free"
        startLevel(level, lifeType)
    }

    fun buyPackage(packageInfo: GeoLifePackage) {
        scope.launch {
            loading = true
            viewModel.buyGeoGameLives(packageInfo.code)
                .onSuccess { purchase ->
                    localMode = purchase.isLocalTest
                    onMessage("Recibiste ${purchase.livesAdded} vida(s) dorada(s). Los Rewards se liberan tras 20 segundos activos.")
                    status = viewModel.loadGeoGameStatus(localMode).getOrNull() ?: status
                }
                .onFailure { onMessage(it.message ?: "No se pudieron comprar vidas.") }
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload(guestMode) }
    LaunchedEffect(status?.freeLives, status?.nextFreeLifeInSeconds) {
        val remainingSeconds = status?.nextFreeLifeInSeconds ?: 0L
        countdownNowMs = System.currentTimeMillis()
        nextLifeDeadlineMs = if (remainingSeconds > 0L) {
            countdownNowMs + remainingSeconds * 1_000L
        } else {
            0L
        }
        while (nextLifeDeadlineMs > 0L) {
            countdownNowMs = System.currentTimeMillis()
            if (countdownNowMs >= nextLifeDeadlineMs) {
                nextLifeDeadlineMs = 0L
                reload(localMode)
                break
            }
            delay(1_000L)
        }
    }

    DisposableEffect(activeRun) {
        onImmersiveChanged(activeRun != null)
        onDispose { if (activeRun != null) onImmersiveChanged(false) }
    }

    storyBeforeStart?.let { (level, story) ->
        StoryDialog(
            title = "Capítulo ${((level - 1) / 4) + 1} · ${GeoAdventureLevelFactory.build(level).levelName}",
            story = story,
            onDismiss = { storyBeforeStart = null },
            onContinue = {
                storyBeforeStart = null
                startLevel(level, pendingLifeType)
            }
        )
    }


    pendingPurchase?.let { pack ->
        AlertDialog(
            onDismissRequest = { if (!loading) pendingPurchase = null },
            title = { Text("Confirmar compra de vidas") },
            text = { Text("Comprarás ${pack.lives} vida(s) dorada(s) por ${pack.creditCost} créditos.") },
            confirmButton = {
                Button(onClick = { pendingPurchase = null; buyPackage(pack) }, enabled = !loading) { Text("Comprar") }
            },
            dismissButton = { TextButton(onClick = { pendingPurchase = null }, enabled = !loading) { Text("Cancelar") } }
        )
    }

    activeRun?.let { run ->
        GeoAdventureGame(
            level = GeoAdventureLevelFactory.build(activeLevel),
            run = run,
            viewModel = viewModel,
            onMessage = onMessage,
            onExit = {
                activeRun = null
                onImmersiveChanged(false)
                reload(if (guestMode) true else localMode)
            },
            onQuit = {
                activeRun = null
                onImmersiveChanged(false)
                onBack()
            },
            guestMode = guestMode
        )
        return
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Geo Aventuras", "20 niveles extremos · trampas de reacción", onBack)
        if (loading && status == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = NeonGreen) }
            return@Column
        }
        val current = status ?: GeoGameStatus(isLocalTest = true)
        val displayedNextLifeSeconds = when {
            current.freeLives >= GeoGameRules.MAX_FREE_LIVES -> 0L
            nextLifeDeadlineMs > 0L -> ((nextLifeDeadlineMs - countdownNowMs).coerceAtLeast(0L) + 999L) / 1_000L
            else -> current.nextFreeLifeInSeconds
        }
        val nextLifeText = if (current.freeLives >= GeoGameRules.MAX_FREE_LIVES || displayedNextLifeSeconds <= 0L) {
            "Vidas rojas completas"
        } else {
            val min = displayedNextLifeSeconds / 60
            val sec = displayedNextLifeSeconds % 60
            "Próxima vida en %02d:%02d".format(min, sec)
        }
        val premiumAvailable = !guestMode && current.premiumLives > 0 && current.premiumUsedToday < current.premiumDailyLimit
        LaunchedEffect(premiumAvailable) {
            if (!premiumAvailable && selectedLifeType == "premium") selectedLifeType = "free"
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF102E45)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("GEO contra un planeta tramposo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(
                            "20 niveles full troleo con pisos falsos, pinchos repentinos, huecos perseguidores, árboles trampa, enemigos de rebote y checkpoints engañosos.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (guestMode) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                LifeInfo("❤️", current.freeLives.toString(), "Vidas rojas", Modifier.weight(1f))
                                LifeInfo("⭐", current.totalStars.toString(), "Estrellas", Modifier.weight(1f))
                            }
                            Text("Modo invitado: juego básico sin compras ni vidas doradas.", color = NeonGreen, fontWeight = FontWeight.Bold)
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                LifeInfo("❤️", current.freeLives.toString(), "Rojas", Modifier.weight(1f))
                                LifeInfo("💛", current.premiumLives.toString(), "Doradas", Modifier.weight(1f))
                                LifeInfo("⭐", current.totalStars.toString(), "Estrellas", Modifier.weight(1f))
                            }
                            Text("Vida para el próximo nivel", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = { selectedLifeType = "free" },
                                    enabled = current.freeLives > 0,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selectedLifeType == "free") Color(0xFFE53935) else Color(0xFF263A45)
                                    )
                                ) { Text("❤️ Roja") }
                                OutlinedButton(
                                    onClick = { selectedLifeType = "premium" },
                                    enabled = premiumAvailable,
                                    modifier = Modifier.weight(1f)
                                ) { Text("💛 Dorada") }
                            }
                            Text("Comprar vidas doradas", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                LifePackCard("1 vida", "2 créditos", "life_1", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                                LifePackCard("5 vidas", "10 créditos", "life_5", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                                LifePackCard("15 vidas", "30 créditos", "life_15", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                            }
                        }
                        Text(nextLifeText, color = NeonGreen, fontWeight = FontWeight.Bold)
                        Text("Cada partida comienza con ${GeoGameRules.GAME_LIVES_PER_RUN} vidas internas. Cada muerte consume exactamente 1.", color = Gold, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Mapa de los 20 niveles", style = MaterialTheme.typography.titleLarge)
                        Text("Desbloqueado: ${current.unlockedLevel}/20", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { reload(if (guestMode) true else localMode) }) { Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar", tint = NeonGreen) }
                }
            }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxWidth().height(500.dp),
                    userScrollEnabled = false,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items((1..20).toList()) { level ->
                        val data = GeoAdventureLevelFactory.build(level)
                        LevelButton(
                            level = level,
                            unlocked = level <= current.unlockedLevel,
                            importantStory = level in setOf(1, 4, 5, 8, 9, 12, 13, 16, 17, 20),
                            difficultyLabel = data.difficultyLabel,
                            onClick = { chooseLevel(level) }
                        )
                    }
                }
            }
        }

    }
}

@Composable
private fun StoryDialog(title: String, story: String, onDismiss: () -> Unit, onContinue: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(story, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        confirmButton = { Button(onClick = onContinue) { Text("Continuar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Volver") } }
    )
}

@Composable
private fun LifeInfo(symbol: String, value: String, label: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(14.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(symbol)
        Spacer(Modifier.width(6.dp))
        Column { Text(value, fontWeight = FontWeight.Bold); Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun LifePackCard(title: String, cost: String, code: String, enabled: Boolean, modifier: Modifier, onBuy: (String) -> Unit) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = Gold)
            Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(cost, color = NeonGreen, textAlign = TextAlign.Center)
            FilledTonalButton(onClick = { onBuy(code) }, enabled = enabled, contentPadding = PaddingValues(horizontal = 9.dp)) { Text("Comprar") }
        }
    }
}

@Composable
private fun LevelButton(
    level: Int,
    unlocked: Boolean,
    importantStory: Boolean,
    difficultyLabel: String,
    onClick: () -> Unit
) {
    val color = when (level) {
        in 1..4 -> Color(0xFFFFC857)
        in 5..8 -> Color(0xFFFF9F43)
        in 9..12 -> Color(0xFFFF6B6B)
        in 13..16 -> Color(0xFFFF477E)
        else -> Color(0xFFD000FF)
    }
    FilledTonalButton(onClick = onClick, enabled = unlocked, modifier = Modifier.height(78.dp), contentPadding = PaddingValues(4.dp)) {
        if (unlocked) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(level.toString(), fontWeight = FontWeight.Bold)
                Text(difficultyLabel, style = MaterialTheme.typography.labelSmall, color = color, maxLines = 1)
                if (importantStory) Text("• historia", style = MaterialTheme.typography.labelSmall, color = Gold)
            }
        } else Icon(Icons.Rounded.Lock, contentDescription = "Bloqueado", modifier = Modifier.size(18.dp))
    }
}

private enum class GameOutcome { WON, LOST }
private enum class DeathCause { HAZARD, VOID }
private enum class ExitTarget { LEVELS, GEO_ADVENTURES }
private data class Bullet(val x: Float, val y: Float, val direction: Float)
private data class EnemyBullet(val x: Float, val y: Float, val velocityX: Float, val velocityY: Float)
private data class EnemyRuntime(
    val x: Float,
    val y: Float,
    val direction: Float,
    val health: Int,
    val lastActionAt: Long = 0L,
    val velocityY: Float = 0f
)
private data class FallingRuntime(
    val x: Float,
    val y: Float,
    val velocityX: Float = 0f,
    val velocityY: Float = 0f,
    val triggeredAt: Long? = null,
    val landedAt: Long? = null,
    val explodedAt: Long? = null
)
private data class ChasingHoleRuntime(
    val x: Float,
    val active: Boolean = false,
    val travelled: Float = 0f,
    val closed: Boolean = false
)
private data class CrusherRuntime(val triggeredAt: Long? = null)

@Composable
private fun GeoAdventureGame(
    level: AdventureLevel,
    run: GeoGameRunStart,
    viewModel: GanaGeoViewModel,
    onMessage: (String) -> Unit,
    onExit: () -> Unit,
    onQuit: () -> Unit,
    guestMode: Boolean = false
) {
    ImmersiveLandscapeEffect()
    val context = LocalContext.current
    val worldIndex = (level.number - 1) / 5
    val audio = remember(level.number) { GameAudioController(context, worldIndex) }
    val vibrator = remember { context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator }
    var musicEnabled by rememberSaveable { mutableStateOf(true) }
    var effectsEnabled by rememberSaveable { mutableStateOf(true) }
    var vibrationEnabled by rememberSaveable { mutableStateOf(true) }

    fun vibrate(duration: Long, amplitude: Int = 130) {
        if (!vibrationEnabled || vibrator == null) return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(duration, amplitude.coerceIn(1, 255)))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(duration)
            }
        }
    }

    DisposableEffect(audio) {
        audio.setMusicEnabled(musicEnabled)
        audio.setEffectsEnabled(effectsEnabled)
        audio.startMusic()
        onDispose { audio.release() }
    }
    LaunchedEffect(musicEnabled, effectsEnabled) {
        audio.setMusicEnabled(musicEnabled)
        audio.setEffectsEnabled(effectsEnabled)
    }

    val playerWidth = 44f
    val playerHeight = 58f
    val appleRadius = 12f
    val appleDiameter = appleRadius * 2f
    val maxLives = GeoGameRules.attemptsForLevel(level.number)
    var playerX by remember(level.number) { mutableFloatStateOf(70f) }
    var playerY by remember(level.number) { mutableFloatStateOf(520f) }
    var velocityY by remember(level.number) { mutableFloatStateOf(0f) }
    var moveDirection by remember { mutableFloatStateOf(0f) }
    var facing by remember { mutableFloatStateOf(1f) }
    var jumpQueued by remember { mutableStateOf(false) }
    var shootQueued by remember { mutableStateOf(false) }
    var interactQueued by remember { mutableStateOf(false) }
    var onGround by remember { mutableStateOf(false) }
    var jumpsRemaining by remember(level.number) { mutableIntStateOf(2) }
    var jumpBufferUntil by remember { mutableLongStateOf(0L) }
    var lastGroundedAt by remember { mutableLongStateOf(0L) }
    var lastPlayerShotAt by remember { mutableLongStateOf(0L) }
    var lastFanSoundAt by remember { mutableLongStateOf(-1_000L) }
    var elapsedMs by remember { mutableLongStateOf(0L) }
    var livesRemaining by remember(level.number) { mutableIntStateOf(maxLives) }
    var deathCount by remember(level.number) { mutableIntStateOf(0) }
    var deathPending by remember(level.number) { mutableStateOf(false) }
    var deathCause by remember(level.number) { mutableStateOf(DeathCause.HAZARD) }
    var pendingExitTarget by remember(level.number) { mutableStateOf<ExitTarget?>(null) }
    var respawnX by remember(level.number) { mutableFloatStateOf(70f) }
    var respawnY by remember(level.number) { mutableFloatStateOf(520f) }
    var activeCheckpoint by remember(level.number) { mutableIntStateOf(-1) }
    var collected by remember { mutableStateOf(setOf<Int>()) }
    var activeSwitches by remember { mutableStateOf(setOf<Int>()) }
    var destroyedCrates by remember { mutableStateOf(setOf<Int>()) }
    var collectedPickups by remember { mutableStateOf(setOf<Int>()) }
    var activatedCheckpoints by remember { mutableStateOf(setOf<Int>()) }
    var revealedCheckpoints by remember { mutableStateOf(setOf<Int>()) }
    var brokenDecoys by remember { mutableStateOf(setOf<Int>()) }
    val platformTriggeredAt = remember(level.number) { mutableStateMapOf<Int, Long>() }
    val hazardTriggeredAt = remember(level.number) { mutableStateMapOf<Int, Long>() }
    val fallingRuntime = remember(level.number) {
        mutableStateListOf<FallingRuntime>().apply { addAll(level.fallingObjects.map { FallingRuntime(it.x, it.startY) }) }
    }
    val chasingHoleRuntime = remember(level.number) {
        mutableStateListOf<ChasingHoleRuntime>().apply { addAll(level.chasingHoles.map { ChasingHoleRuntime(it.startX) }) }
    }
    val crusherRuntime = remember(level.number) {
        mutableStateListOf<CrusherRuntime>().apply { addAll(level.crushers.map { CrusherRuntime() }) }
    }

    // A floor trap is represented by removing a rectangular piece of the real platform.
    // It is not drawn as an oval, cone or independent black object.
    fun splitPlatformByOpenFloor(platform: GamePlatform): List<GamePlatform> {
        var pieces = listOf(platform)
        level.chasingHoles.forEachIndexed { index, trap ->
            val runtime = chasingHoleRuntime.getOrNull(index) ?: return@forEachIndexed
            if (!runtime.active || runtime.closed) return@forEachIndexed
            val surfaceY = trap.y + 28f
            if (abs(platform.y - surfaceY) > 14f) return@forEachIndexed

            val openingStart = runtime.x.coerceIn(
                minOf(trap.surfaceStartX, trap.surfaceEndX),
                maxOf(trap.surfaceStartX, trap.surfaceEndX)
            )
            val openingEnd = (runtime.x + trap.width).coerceIn(
                minOf(trap.surfaceStartX, trap.surfaceEndX),
                maxOf(trap.surfaceStartX, trap.surfaceEndX)
            )
            if (openingEnd <= openingStart) return@forEachIndexed

            pieces = pieces.flatMap { piece ->
                val pieceEnd = piece.x + piece.width
                if (openingEnd <= piece.x || openingStart >= pieceEnd) {
                    listOf(piece)
                } else {
                    buildList {
                        val leftWidth = (openingStart - piece.x).coerceAtLeast(0f)
                        if (leftWidth > 5f) add(piece.copy(width = leftWidth))
                        val rightX = maxOf(openingEnd, piece.x)
                        val rightWidth = (pieceEnd - rightX).coerceAtLeast(0f)
                        if (rightWidth > 5f) add(piece.copy(x = rightX, width = rightWidth))
                    }
                }
            }
        }
        return pieces
    }
    var outcome by remember { mutableStateOf<GameOutcome?>(null) }
    var paused by remember { mutableStateOf(false) }
    var activated by remember(run.runId) { mutableStateOf(!run.needsActivation) }
    var activating by remember { mutableStateOf(false) }
    var activationRewards by remember { mutableLongStateOf(0L) }
    var reportingResult by remember { mutableStateOf(false) }
    var resultSaved by remember { mutableStateOf(false) }
    var resultError by remember { mutableStateOf<String?>(null) }
    var reportAttempt by remember { mutableIntStateOf(0) }
    var shieldHits by remember { mutableIntStateOf(0) }
    var weaponPowerUntil by remember { mutableLongStateOf(0L) }
    var invulnerableUntil by remember { mutableLongStateOf(900L) }
    var acechanteX by remember(level.number) { mutableFloatStateOf(-750f) }
    var outroDismissed by remember { mutableStateOf(false) }
    var objectiveHint by remember(level.number) { mutableStateOf<String?>("Sobrevive, activa ${level.requiredMechanisms} interruptores y recoge 3 cristales.") }
    var objectiveHintUntil by remember(level.number) { mutableLongStateOf(6_000L) }
    val bullets = remember(level.number) { mutableStateListOf<Bullet>() }
    val enemyBullets = remember(level.number) { mutableStateListOf<EnemyBullet>() }
    val enemies = remember(level.number) {
        mutableStateListOf<EnemyRuntime>().apply {
            addAll(level.enemies.mapIndexed { index, enemy -> EnemyRuntime(enemy.x, enemy.y, if (index % 2 == 0) 1f else -1f, enemy.health) })
        }
    }

    fun endGame(result: GameOutcome) {
        if (outcome != null) return
        outcome = result
        audio.play(if (result == GameOutcome.WON) GameSound.VICTORY else GameSound.DEFEAT, 0.9f)
        audio.pauseMusic()
    }

    fun resetTransientTraps() {
        platformTriggeredAt.clear()
        hazardTriggeredAt.clear()
        level.fallingObjects.forEachIndexed { index, trap ->
            if (index < fallingRuntime.size) fallingRuntime[index] = FallingRuntime(trap.x, trap.startY)
        }
        level.chasingHoles.forEachIndexed { index, trap ->
            if (index < chasingHoleRuntime.size) chasingHoleRuntime[index] = ChasingHoleRuntime(trap.startX)
        }
        level.crushers.forEachIndexed { index, _ ->
            if (index < crusherRuntime.size) crusherRuntime[index] = CrusherRuntime()
        }
        bullets.clear()
        enemyBullets.clear()
        enemies.clear()
        enemies.addAll(level.enemies.mapIndexed { index, enemy ->
            EnemyRuntime(enemy.x, enemy.y, if (index % 2 == 0) 1f else -1f, enemy.health)
        })
    }

    fun respawn() {
        playerX = respawnX
        playerY = respawnY
        velocityY = 0f
        moveDirection = 0f
        jumpQueued = false
        shootQueued = false
        interactQueued = false
        jumpsRemaining = 2
        onGround = false
        invulnerableUntil = elapsedMs + 1_100L
        resetTransientTraps()
    }

    fun insideRealCheckpointSafeZone(): Boolean {
        val centerX = playerX + playerWidth / 2f
        val centerY = playerY + playerHeight / 2f
        return level.checkpoints.any { checkpoint ->
            checkpoint.kind != CheckpointKind.DECOY &&
                centerX in (checkpoint.x - 125f)..(checkpoint.x + 165f) &&
                centerY in (checkpoint.y - 95f)..(checkpoint.y + 125f)
        }
    }

    fun loseLife(
        @Suppress("UNUSED_PARAMETER") reason: String,
        cause: DeathCause = DeathCause.HAZARD
    ) {
        if (outcome != null || deathPending || elapsedMs < invulnerableUntil || insideRealCheckpointSafeZone()) return
        if (shieldHits > 0) {
            shieldHits--
            invulnerableUntil = elapsedMs + 900L
            audio.play(GameSound.HIT, 0.75f)
            vibrate(80, 90)
            return
        }
        livesRemaining--
        deathCount++
        deathPending = true
        deathCause = cause
        moveDirection = 0f
        jumpQueued = false
        shootQueued = false
        interactQueued = false
        velocityY = 0f
        objectiveHint = null
        objectiveHintUntil = 0L
        audio.play(if (run.lifeType == "premium") GameSound.DEATH_GOLD else GameSound.DEATH_RED, 0.92f, 0.96f + (deathCount % 4) * 0.03f)
        vibrate(if (cause == DeathCause.VOID) 70 else 180, if (cause == DeathCause.VOID) 90 else 190)
    }

    LaunchedEffect(deathPending, livesRemaining, deathCause) {
        if (!deathPending) return@LaunchedEffect
        when (deathCause) {
            DeathCause.VOID -> delay(GeoGameRules.VOID_RESPAWN_DELAY_MS)
            DeathCause.HAZARD -> delay(GeoGameRules.DEATH_REVEAL_MS)
        }
        if (livesRemaining <= 0) {
            endGame(GameOutcome.LOST)
        } else {
            respawn()
        }
        deathPending = false
    }

    BackHandler {
        if (outcome == null) paused = !paused else if (resultSaved) onExit()
    }

    LaunchedEffect(paused, outcome, musicEnabled) {
        if (paused || outcome != null || !musicEnabled) audio.pauseMusic() else audio.startMusic()
    }
    LaunchedEffect(paused) {
        delay(80L)
        context.findActivity()?.window?.let { window ->
            WindowCompat.setDecorFitsSystemWindows(window, false)
            WindowInsetsControllerCompat(window, window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    LaunchedEffect(level.number, outcome, paused, deathPending) {
        if (outcome != null || paused || deathPending) return@LaunchedEffect
        var previousNanos = withFrameNanos { it }
        while (outcome == null && !paused && !deathPending) {
            val now = withFrameNanos { it }
            val dt = ((now - previousNanos) / 1_000_000_000f).coerceIn(0f, 0.035f)
            previousNanos = now
            elapsedMs += (dt * 1000).toLong()

            level.checkpoints.forEachIndexed { index, cp ->
                if (cp.kind == CheckpointKind.SAFE || (level.number <= 4 && cp.kind == CheckpointKind.DECOY) || playerX >= cp.appearTriggerX) revealedCheckpoints = revealedCheckpoints + index
            }
            level.platforms.forEachIndexed { index, platform ->
                if (platform.kind == PlatformKind.PROXIMITY_DISAPPEARING && playerX >= platform.triggerX && index !in platformTriggeredAt) {
                    platformTriggeredAt[index] = elapsedMs
                    audio.play(GameSound.HOLE, 0.62f, 1.12f)
                }
            }
            level.hazards.forEachIndexed { index, hazard ->
                if (hazard.kind == HazardKind.HIDDEN_SPIKES && playerX >= hazard.triggerX && index !in hazardTriggeredAt) {
                    hazardTriggeredAt[index] = elapsedMs
                    audio.play(GameSound.SPIKE, 0.58f, 1.18f + (index % 3) * 0.08f)
                }
            }
            level.fallingObjects.forEachIndexed { index, trap ->
                val runtime = fallingRuntime[index]
                if (runtime.triggeredAt == null && playerX >= trap.triggerX && playerX < trap.x + 300f) {
                    fallingRuntime[index] = runtime.copy(triggeredAt = elapsedMs)
                    audio.play(GameSound.FRUIT_DROP, 0.58f, 0.90f + (index % 4) * 0.05f)
                }
            }

            val movingPlatforms = level.movingPlatforms.mapIndexed { index, moving ->
                val phase = elapsedMs / 1000f / moving.periodSeconds * (Math.PI * 2.0) + index * 0.68
                val offset = sin(phase).toFloat() * moving.travel
                GamePlatform(
                    x = if (moving.vertical) moving.x else moving.x + offset,
                    y = if (moving.vertical) moving.y + offset else moving.y,
                    width = moving.width,
                    height = 26f
                )
            }

            fun platformVisible(index: Int, p: GamePlatform): Boolean = when (p.kind) {
                PlatformKind.SOLID, PlatformKind.BOUNCE -> true
                PlatformKind.REVEALING -> playerX >= p.triggerX || activeSwitches.isNotEmpty()
                PlatformKind.DISAPPEARING -> ((elapsedMs + p.phaseMs) % p.cycleMs) < (p.cycleMs * 0.64f)
                PlatformKind.PROXIMITY_DISAPPEARING -> platformTriggeredAt[index]?.let { elapsedMs - it <= p.delayMs } ?: true
                PlatformKind.FALLING -> {
                    val triggered = platformTriggeredAt[index]
                    triggered == null || elapsedMs - triggered <= p.delayMs
                }
            }

            val visibleBasePlatforms = level.platforms.mapIndexedNotNull { index, p ->
                if (!platformVisible(index, p)) return@mapIndexedNotNull null
                if (p.kind == PlatformKind.FALLING) {
                    val triggered = platformTriggeredAt[index]
                    if (triggered != null) {
                        val fallOffset = ((elapsedMs - triggered).coerceAtLeast(0L) / 4f).coerceAtMost(120f)
                        p.copy(y = p.y + fallOffset)
                    } else p
                } else p
            }
            val collisionPlatforms = buildList {
                addAll(visibleBasePlatforms.flatMap(::splitPlatformByOpenFloor))
                addAll(movingPlatforms)
                activeSwitches.forEach { index ->
                    level.switches.getOrNull(index)?.let { add(GamePlatform(it.opensAtX, 520f, 235f, 26f)) }
                }
            }
            val blockingBarriers = level.barriers.filter { it.switchIndex !in activeSwitches }

            val wasOnGround = onGround
            if (wasOnGround) lastGroundedAt = elapsedMs
            val previousBottom = playerY + playerHeight
            if (moveDirection != 0f) facing = moveDirection.sign
            var horizontalForce = moveDirection * (278f + level.number * 3.4f)
            val currentRectForFan = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)
            level.fans.forEachIndexed { index, fan ->
                val cyclingOn = fan.cycleMs <= 0 || ((elapsedMs + fan.phaseMs) % fan.cycleMs) < fan.cycleMs * 0.66f
                if (!cyclingOn) return@forEachIndexed
                val reversed = fan.switchIndex?.let { it in activeSwitches } == true
                val fanRect = Rect(fan.x, fan.y, fan.x + fan.width, fan.y + fan.height)
                if (currentRectForFan.overlaps(fanRect)) {
                    horizontalForce += if (reversed) -fan.forceX else fan.forceX
                    velocityY += (if (reversed) -fan.forceY else fan.forceY) * dt
                    if (elapsedMs - lastFanSoundAt >= 700L) {
                        audio.play(GameSound.FAN, 0.14f)
                        lastFanSoundAt = elapsedMs
                    }
                }
            }
            val candidateX = (playerX + horizontalForce * dt).coerceIn(0f, level.width - playerWidth)
            val candidateRect = Rect(candidateX, playerY, candidateX + playerWidth, playerY + playerHeight)
            if (blockingBarriers.none { candidateRect.overlaps(Rect(it.x, it.y, it.x + it.width, it.y + it.height)) }) {
                playerX = candidateX
            }

            if (jumpQueued) {
                jumpBufferUntil = elapsedMs + 180L
                jumpQueued = false
            }
            val canGroundJump = wasOnGround || elapsedMs - lastGroundedAt <= 125L
            if (jumpBufferUntil >= elapsedMs && (canGroundJump || jumpsRemaining > 0)) {
                val double = !canGroundJump
                velocityY = if (double) -535f else -655f
                jumpsRemaining = if (double) (jumpsRemaining - 1).coerceAtLeast(0) else 1
                onGround = false
                jumpBufferUntil = 0L
                audio.play(if (double) GameSound.DOUBLE_JUMP else GameSound.JUMP, 0.8f)
            }

            velocityY += 1_470f * dt
            var nextY = playerY + velocityY * dt
            onGround = false
            val nextBottom = nextY + playerHeight
            collisionPlatforms.forEach { p ->
                val overlapsX = playerX + playerWidth > p.x + 2f && playerX < p.x + p.width - 2f
                if (overlapsX && velocityY >= 0f && previousBottom <= p.y + 12f && nextBottom >= p.y) {
                    nextY = p.y - playerHeight
                    velocityY = if (p.kind == PlatformKind.BOUNCE) -810f else 0f
                    onGround = p.kind != PlatformKind.BOUNCE
                    jumpsRemaining = if (p.kind == PlatformKind.BOUNCE) 1 else 2
                    lastGroundedAt = elapsedMs
                    if (!wasOnGround && velocityY == 0f) audio.play(GameSound.LAND, 0.18f, 0.92f + (level.number % 3) * 0.05f)
                    val baseIndex = level.platforms.indexOf(p)
                    if (baseIndex >= 0 && p.kind == PlatformKind.FALLING && platformTriggeredAt[baseIndex] == null) {
                        platformTriggeredAt[baseIndex] = elapsedMs
                        audio.play(GameSound.TRAP, 0.35f, 1.15f)
                    }
                }
            }
            playerY = nextY
            var playerRect = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)

            level.checkpoints.forEachIndexed { index, cp ->
                if (index !in revealedCheckpoints || index in brokenDecoys) return@forEachIndexed
                val cpRect = Rect(cp.x - 25f, cp.y - 30f, cp.x + 30f, cp.y + 65f)
                if (playerRect.overlaps(cpRect) && index !in activatedCheckpoints) {
                    if (cp.kind == CheckpointKind.DECOY) {
                        brokenDecoys = brokenDecoys + index
                        audio.play(GameSound.DECOY, 0.9f)
                        loseLife("El checkpoint falso explotó")
                        playerRect = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)
                    } else {
                        activatedCheckpoints = activatedCheckpoints + index
                        activeCheckpoint = index
                        respawnX = (cp.x + 18f).coerceIn(0f, level.width - playerWidth)
                        respawnY = (cp.y + 85f - playerHeight).coerceAtLeast(50f)
                        audio.play(GameSound.CHECKPOINT, 0.85f)
                        vibrate(70, 75)
                        objectiveHint = "Checkpoint ${activatedCheckpoints.count { level.checkpoints[it].kind != CheckpointKind.DECOY }} activado"
                        objectiveHintUntil = elapsedMs + 1_900L
                    }
                }
            }

            level.crystals.forEachIndexed { index, crystal ->
                if (index !in collected && playerRect.overlaps(Rect(crystal.x - 24f, crystal.y - 24f, crystal.x + 24f, crystal.y + 24f))) {
                    collected = collected + index
                    audio.play(GameSound.CRYSTAL, 0.75f, 1f + index * 0.08f)
                }
            }
            level.pickups.forEachIndexed { index, pickup ->
                if (index !in collectedPickups && playerRect.overlaps(Rect(pickup.x - 25f, pickup.y - 25f, pickup.x + 25f, pickup.y + 25f))) {
                    collectedPickups = collectedPickups + index
                    when (pickup.kind) {
                        GamePickupKind.ENERGY -> livesRemaining = (livesRemaining + 1).coerceAtMost(maxLives)
                        GamePickupKind.SHIELD -> shieldHits = (shieldHits + 1).coerceAtMost(2)
                        GamePickupKind.POWER -> weaponPowerUntil = elapsedMs + 25_000L
                    }
                    audio.play(GameSound.PICKUP, 0.8f)
                }
            }

            if (interactQueued) {
                var didInteract = false
                level.switches.forEachIndexed { index, sw ->
                    if (index !in activeSwitches && abs(playerX - sw.x) < 115f && abs(playerY - sw.y) < 130f) {
                        activeSwitches = activeSwitches + index
                        didInteract = true
                        audio.play(GameSound.BUTTON, 0.8f)
                        vibrate(55, 70)
                        objectiveHint = if (sw.reversesFans) "Interruptor activado: algunas corrientes cambiaron de dirección" else "Interruptor activado: una barrera se abrió"
                        objectiveHintUntil = elapsedMs + 2_100L
                    }
                }
                val crateIndex = level.crates.indices.firstOrNull { idx -> idx !in destroyedCrates && abs(playerX - level.crates[idx].x) < 95f }
                if (crateIndex != null) {
                    destroyedCrates = destroyedCrates + crateIndex
                    didInteract = true
                    if ((crateIndex + level.number) % 2 == 0) shieldHits = (shieldHits + 1).coerceAtMost(2)
                    else livesRemaining = (livesRemaining + 1).coerceAtMost(maxLives)
                    audio.play(GameSound.PICKUP, 0.7f)
                }
                if (!didInteract) {
                    objectiveHint = "No hay un botón u objeto cerca"
                    objectiveHintUntil = elapsedMs + 1_100L
                }
                interactQueued = false
            }

            if (shootQueued && elapsedMs - lastPlayerShotAt >= 330L && (level.weaponEnabled || weaponPowerUntil > elapsedMs)) {
                bullets += Bullet(playerX + playerWidth / 2f, playerY + 25f, facing)
                lastPlayerShotAt = elapsedMs
                audio.play(GameSound.SHOOT, 0.55f)
            }
            shootQueued = false

            for (i in bullets.indices.reversed()) {
                val b = bullets[i]
                val moved = b.copy(x = b.x + b.direction * 620f * dt)
                var hit = false
                enemies.indices.forEach { enemyIndex ->
                    val e = enemies[enemyIndex]
                    if (!hit && e.health > 0 && Rect(moved.x - 8f, moved.y - 8f, moved.x + 8f, moved.y + 8f)
                            .overlaps(Rect(e.x, e.y, e.x + 52f, e.y + 58f))) {
                        enemies[enemyIndex] = e.copy(health = (e.health - 1).coerceAtLeast(0))
                        hit = true
                    }
                }
                if (hit || moved.x < 0f || moved.x > level.width) bullets.removeAt(i) else bullets[i] = moved
            }

            for (i in enemies.indices) {
                val runtime = enemies[i]
                if (runtime.health <= 0) continue
                val model = level.enemies[i]
                var ex = runtime.x
                var ey = runtime.y
                var dir = runtime.direction
                var evy = runtime.velocityY
                var lastAction = runtime.lastActionAt
                val distance = playerX - ex
                val chasing = abs(distance) < model.detectionRange
                if (model.kind == GameEnemyKind.FLYER) {
                    ex += (if (chasing) distance.sign else dir) * model.speed * dt
                    ey = model.y + sin(elapsedMs / 360.0 + i).toFloat() * 75f
                } else {
                    if (chasing) dir = distance.sign.takeIf { it != 0f } ?: dir
                    val left = model.x - model.range
                    val right = model.x + model.range
                    if (!chasing && (ex < left || ex > right)) dir *= -1f
                    ex = (ex + dir * model.speed * (if (chasing) 1.35f else 0.72f) * dt).coerceIn(0f, level.width - 55f)
                    if (model.kind == GameEnemyKind.JUMPER && chasing && abs(distance) < 220f && evy == 0f && elapsedMs - lastAction > 800L) {
                        evy = -520f
                        lastAction = elapsedMs
                    }
                    if (model.kind == GameEnemyKind.SHOOTER && chasing && abs(distance) < 520f && elapsedMs - lastAction > 1_150L) {
                        val dx = playerX - ex
                        val dy = playerY - ey
                        val len = sqrt((dx * dx + dy * dy).toDouble()).toFloat().coerceAtLeast(1f)
                        enemyBullets += EnemyBullet(ex + 25f, ey + 22f, dx / len * 365f, dy / len * 365f)
                        lastAction = elapsedMs
                        audio.play(GameSound.ENEMY_SHOT, 0.38f)
                    }
                    val prevBottom = ey + 55f
                    evy += 1_420f * dt
                    var nextEnemyY = ey + evy * dt
                    val nextEnemyBottom = nextEnemyY + 55f
                    collisionPlatforms.forEach { p ->
                        if (ex + 50f > p.x && ex < p.x + p.width && evy >= 0f && prevBottom <= p.y + 15f && nextEnemyBottom >= p.y) {
                            nextEnemyY = p.y - 55f
                            evy = 0f
                        }
                    }
                    ey = nextEnemyY
                }
                val enemyRect = Rect(ex, ey, ex + 50f, ey + 58f)
                if (playerRect.overlaps(enemyRect)) {
                    val stomping = velocityY > 140f && playerY + playerHeight - velocityY * dt <= ey + 15f
                    if (stomping) {
                        enemies[i] = runtime.copy(x = ex, y = ey, direction = dir, health = (runtime.health - 2).coerceAtLeast(0), lastActionAt = lastAction, velocityY = evy)
                        velocityY = if (level.number <= 4) -820f else -460f
                        audio.play(GameSound.ENEMY_STOMP, 0.72f, 0.94f + (i % 3) * 0.07f)
                        continue
                    } else loseLife("Un enemigo te alcanzó")
                }
                enemies[i] = runtime.copy(x = ex, y = ey, direction = dir, lastActionAt = lastAction, velocityY = evy)
            }

            for (i in enemyBullets.indices.reversed()) {
                val b = enemyBullets[i]
                val moved = b.copy(x = b.x + b.velocityX * dt, y = b.y + b.velocityY * dt)
                if (playerRect.overlaps(Rect(moved.x - 7f, moved.y - 7f, moved.x + 7f, moved.y + 7f))) {
                    enemyBullets.removeAt(i)
                    loseLife("Un proyectil te alcanzó")
                } else if (moved.x !in 0f..level.width || moved.y !in 0f..780f) enemyBullets.removeAt(i)
                else enemyBullets[i] = moved
            }

            level.fallingObjects.forEachIndexed { index, trap ->
                val runtime = fallingRuntime[index]
                val triggeredAt = runtime.triggeredAt ?: return@forEachIndexed
                if (elapsedMs - triggeredAt < trap.delayMs) return@forEachIndexed
                var x = runtime.x
                var y = runtime.y
                var vx = runtime.velocityX
                var vy = runtime.velocityY
                var landedAt = runtime.landedAt
                var explodedAt = runtime.explodedAt

                if (landedAt == null) {
                    if (trap.behavior == FallingBehavior.CHASE) {
                        vx += (playerX - x).sign * 420f * dt
                        vx = vx.coerceIn(-235f, 235f)
                        x += vx * dt
                    }
                    vy += 1_650f * dt
                    y += vy * dt
                    if (y + trap.size >= trap.targetY) {
                        y = trap.targetY - trap.size
                        vy = 0f
                        landedAt = elapsedMs
                        when (trap.behavior) {
                            FallingBehavior.EXPLODE -> audio.play(GameSound.EXPLOSION, 0.82f, 0.90f + index % 3 * 0.06f)
                            FallingBehavior.ROLL, FallingBehavior.CHASE -> audio.play(GameSound.FRUIT_DROP, 0.5f, 0.72f)
                            else -> audio.play(GameSound.CRUSHER, 0.42f, 0.76f)
                        }
                    }
                } else {
                    when (trap.behavior) {
                        FallingBehavior.ROLL -> {
                            vx = trap.rollDirection * (245f + level.number * 18f)
                            x += vx * dt
                        }
                        FallingBehavior.CHASE -> {
                            vx = (playerX - x).sign * (185f + level.number * 16f)
                            x += vx * dt
                        }
                        FallingBehavior.EXPLODE -> if (explodedAt == null && elapsedMs - landedAt >= 120L) explodedAt = elapsedMs
                        else -> Unit
                    }
                }
                fallingRuntime[index] = runtime.copy(x = x, y = y, velocityX = vx, velocityY = vy, landedAt = landedAt, explodedAt = explodedAt)

                val copies = if (trap.behavior == FallingBehavior.CHAIN) trap.chainCount else 1
                repeat(copies) { copyIndex ->
                    val copyX = x + (copyIndex - (copies - 1) / 2f) * trap.chainSpacing
                    val hitSize = if (trap.kind == FallingObjectKind.FRUIT) appleDiameter else trap.size
                    val offset = (trap.size - hitSize) / 2f
                    if (playerRect.overlaps(Rect(copyX + offset, y + offset, copyX + offset + hitSize, y + offset + hitSize))) loseLife("Una fruta trampa aplastó a GEO")
                }
                if (explodedAt != null && elapsedMs - explodedAt < 360L) {
                    val centerX = x + trap.size / 2f
                    val centerY = y + trap.size / 2f
                    val dx = playerX + playerWidth / 2f - centerX
                    val dy = playerY + playerHeight / 2f - centerY
                    if (sqrt((dx * dx + dy * dy).toDouble()).toFloat() <= trap.explosionRadius) loseLife("La fruta explotó al acercarte")
                }
            }

            level.chasingHoles.forEachIndexed { index, trap ->
                var runtime = chasingHoleRuntime[index]
                if (!runtime.active && !runtime.closed && playerX >= trap.triggerX && playerX <= trap.surfaceEndX + 90f) {
                    runtime = runtime.copy(active = true)
                    audio.play(GameSound.HOLE, 0.76f, 0.84f + index % 3 * 0.08f)
                }
                if (runtime.active && !runtime.closed) {
                    val minX = minOf(trap.surfaceStartX, trap.surfaceEndX)
                    val maxX = (maxOf(trap.surfaceStartX, trap.surfaceEndX) - trap.width).coerceAtLeast(minX)
                    val forward = if (trap.direction >= 0f) 1f else -1f
                    val playerCenter = playerX + playerWidth / 2f
                    val targetX = (playerCenter - trap.width * 0.45f).coerceIn(minX, maxX)
                    val shouldAdvance = if (forward > 0f) targetX > runtime.x else targetX < runtime.x
                    if (shouldAdvance && runtime.travelled < trap.maxTravel) {
                        val rawStep = forward * trap.speed * dt
                        val nextX = (runtime.x + rawStep).coerceIn(minX, maxX)
                        val travelledNow = runtime.travelled + abs(nextX - runtime.x)
                        runtime = runtime.copy(x = nextX, travelled = travelledNow)
                    }
                    val reachedSurfaceEdge = if (forward > 0f) runtime.x >= maxX - 0.5f else runtime.x <= minX + 0.5f
                    val exceededTravel = runtime.travelled >= trap.maxTravel
                    val playerLeftSurface = if (forward > 0f) playerX > trap.surfaceEndX + 45f else playerX + playerWidth < trap.surfaceStartX - 45f
                    if (reachedSurfaceEdge || exceededTravel || playerLeftSurface) {
                        runtime = runtime.copy(active = false, closed = true)
                    }
                }
                chasingHoleRuntime[index] = runtime
            }

            level.crushers.forEachIndexed { index, trap ->
                var runtime = crusherRuntime[index]
                if (runtime.triggeredAt == null && playerX >= trap.triggerX) {
                    runtime = runtime.copy(triggeredAt = elapsedMs)
                    audio.play(GameSound.CRUSHER, 0.7f, 0.86f + index % 3 * 0.08f)
                    crusherRuntime[index] = runtime
                }
                val triggeredAt = runtime.triggeredAt ?: return@forEachIndexed
                val activeMs = (elapsedMs - triggeredAt - trap.delayMs).coerceAtLeast(0L)
                val maxDistance = abs(trap.travel)
                val forward = (activeMs / 1000f * trap.speed).coerceAtMost(maxDistance)
                val reverseStart = trap.delayMs + trap.reverseAfterMs
                val distance = if (elapsedMs - triggeredAt <= reverseStart) forward else {
                    val reversed = ((elapsedMs - triggeredAt - reverseStart) / 1000f * trap.speed).coerceAtMost(maxDistance)
                    (maxDistance - reversed).coerceAtLeast(0f)
                }
                val signedOffset = trap.travel.sign * distance
                val cx = trap.x + if (trap.axis == CrusherAxis.HORIZONTAL) signedOffset else 0f
                val cy = trap.y + if (trap.axis == CrusherAxis.VERTICAL) signedOffset else 0f
                if (playerRect.overlaps(Rect(cx, cy, cx + trap.width, cy + trap.height))) loseLife("La pared te aplastó")
            }

            fun hazardIsActive(index: Int, h: GameHazard): Boolean {
                val cycleActive = h.cycleMs <= 0 || ((elapsedMs + h.phaseMs) % h.cycleMs) < h.cycleMs * 0.62f
                if (!cycleActive) return false
                if (h.kind != HazardKind.HIDDEN_SPIKES) return true
                val trigger = hazardTriggeredAt[index] ?: return false
                return elapsedMs - trigger > 120L
            }
            level.hazards.forEachIndexed { index, h ->
                if (hazardIsActive(index, h) && playerRect.overlaps(Rect(h.x, h.y, h.x + h.width, h.y + h.height))) {
                    audio.play(if (h.kind == HazardKind.FIRE) GameSound.EXPLOSION else GameSound.SPIKE, 0.58f, 0.94f + index % 4 * 0.05f)
                    loseLife(when (h.kind) {
                        HazardKind.HIDDEN_SPIKES -> "Los pinchos estaban ocultos"
                        HazardKind.SAW -> "La sierra te alcanzó"
                        HazardKind.FIRE -> "La llamarada se activó"
                        HazardKind.CEILING_SPIKES -> "El techo era una trampa"
                        else -> "Caíste en los pinchos"
                    })
                }
            }

            if (level.acechantePresent) {
                val target = playerX - 155f
                val speed = 132f + level.number * 6f
                acechanteX += (target - acechanteX).sign * speed * dt
                if (abs(playerX - acechanteX) < 60f) loseLife("El Acechante te encontró")
            }

            if (playerY > 705f) loseLife("Caíste al vacío", DeathCause.VOID)
            if (elapsedMs > 900_000L) endGame(GameOutcome.LOST)

            if (playerX + playerWidth >= level.goalX) {
                when {
                    collected.size < 3 -> {
                        objectiveHint = "La salida está cerrada: faltan ${3 - collected.size} cristales"
                        objectiveHintUntil = elapsedMs + 2_200L
                    }
                    activeSwitches.size < level.requiredMechanisms -> {
                        objectiveHint = "La salida está cerrada: faltan ${level.requiredMechanisms - activeSwitches.size} interruptores"
                        objectiveHintUntil = elapsedMs + 2_200L
                    }
                    else -> endGame(GameOutcome.WON)
                }
            } else if (objectiveHint != null && objectiveHintUntil > 0 && elapsedMs > objectiveHintUntil) {
                objectiveHint = null
                objectiveHintUntil = 0L
            }
        }
    }

    val elapsedSeconds = (elapsedMs / 1000L).toInt()
    LaunchedEffect(run.runId, elapsedSeconds, activated, outcome) {
        if (run.needsActivation && !activated && !activating && outcome == null && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            activating = true
            viewModel.activateGeoGameRun(run)
                .onSuccess {
                    activated = true
                    activationRewards = it.awardedPoints
                }
                .onFailure { if (!it.message.orEmpty().contains("not ready", true)) onMessage(it.message ?: "No se pudo activar la vida dorada.") }
            activating = false
        }
    }

    LaunchedEffect(outcome, reportAttempt) {
        val finalOutcome = outcome ?: return@LaunchedEffect
        if (resultSaved || reportingResult) return@LaunchedEffect
        reportingResult = true
        resultError = null
        var canFinish = activated
        if (run.needsActivation && !canFinish && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            viewModel.activateGeoGameRun(run)
                .onSuccess { canFinish = true; activated = true; activationRewards = it.awardedPoints }
                .onFailure { resultError = it.message ?: "No se pudo confirmar la vida dorada." }
        }
        if (run.needsActivation && !canFinish) {
            runCatching { viewModel.cancelGeoGameRun(run) }
                .onSuccess { onMessage("La partida terminó antes de 20 segundos activos; la vida dorada fue devuelta."); resultSaved = true }
                .onFailure { resultError = it.message ?: "No se pudo devolver la vida todavía." }
            reportingResult = false
            return@LaunchedEffect
        }
        val won = finalOutcome == GameOutcome.WON
        val stars = GeoGameRules.calculateStars(won, collected.size, elapsedSeconds, level.parSeconds)
        val score = playerX.toLong() + collected.size * 900L + activeSwitches.size * 350L + activatedCheckpoints.size * 250L + livesRemaining * 160L + if (won) 3_000L else 0L
        viewModel.finishGeoGameRun(run, won, stars, score, elapsedMs)
            .onSuccess { resultSaved = true }
            .onFailure { resultError = it.message ?: "No se pudo guardar el resultado." }
        reportingResult = false
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF040D13))) {
        Canvas(Modifier.fillMaxSize()) {
            val viewportWidth = size.width
            val viewportHeight = size.height
            val gameTop = 2f
            val gameBottom = viewportHeight - 76f
            val scaleY = (gameBottom - gameTop) / 720f
            val cameraX = (playerX - viewportWidth * 0.30f).coerceIn(0f, max(level.width - viewportWidth, 0f))
            fun sy(value: Float) = gameTop + value * scaleY
            fun drawApple(center: Offset, radius: Float = appleRadius, exploding: Boolean = false) {
                val darkRed = if (exploding) Color(0xFF9C1322) else Color(0xFFB71C2A)
                val appleRed = if (exploding) Color(0xFFFF334D) else Color(0xFFE72F3E)
                drawOval(
                    color = darkRed,
                    topLeft = Offset(center.x - radius * 0.78f, center.y - radius * 0.52f),
                    size = Size(radius * 1.56f, radius * 1.46f)
                )
                drawCircle(appleRed, radius * 0.61f, Offset(center.x - radius * 0.30f, center.y - radius * 0.18f))
                drawCircle(appleRed, radius * 0.61f, Offset(center.x + radius * 0.30f, center.y - radius * 0.18f))
                drawOval(
                    color = appleRed,
                    topLeft = Offset(center.x - radius * 0.58f, center.y - radius * 0.02f),
                    size = Size(radius * 1.16f, radius * 0.92f)
                )
                drawLine(
                    Color(0xFF5D3A20),
                    Offset(center.x, center.y - radius * 0.72f),
                    Offset(center.x + radius * 0.12f, center.y - radius * 1.08f),
                    radius * 0.13f
                )
                val leaf = Path().apply {
                    moveTo(center.x + radius * 0.10f, center.y - radius * 0.88f)
                    quadraticBezierTo(
                        center.x + radius * 0.55f,
                        center.y - radius * 1.14f,
                        center.x + radius * 0.68f,
                        center.y - radius * 0.72f
                    )
                    quadraticBezierTo(
                        center.x + radius * 0.38f,
                        center.y - radius * 0.58f,
                        center.x + radius * 0.10f,
                        center.y - radius * 0.88f
                    )
                    close()
                }
                drawPath(leaf, Color(0xFF70C84D))
                drawCircle(Color.White.copy(alpha = 0.62f), radius * 0.12f, Offset(center.x - radius * 0.30f, center.y - radius * 0.34f))
            }

            val sky = listOf(
                listOf(Color(0xFF071B2C), Color(0xFF165B61)),
                listOf(Color(0xFF141C34), Color(0xFF2E5B42)),
                listOf(Color(0xFF211638), Color(0xFF5A335E)),
                listOf(Color(0xFF07111E), Color(0xFF33485C))
            )[worldIndex]
            drawRect(Brush.verticalGradient(sky), size = size)

            repeat(24) { i ->
                val px = ((i * 151f - cameraX * (0.03f + (i % 3) * 0.02f)) % (viewportWidth + 180f)) - 60f
                val py = gameTop + 20f + (i * 73 % 280)
                drawCircle(Color.White.copy(alpha = 0.18f + (i % 4) * 0.06f), 1.4f + i % 3, Offset(px, py))
            }
            val moonX = viewportWidth - 105f - cameraX * 0.012f % 80f
            drawCircle(Color(0xFFFFD37A).copy(alpha = 0.88f), 48f, Offset(moonX, gameTop + 70f))

            fun mountain(parallax: Float, base: Float, amp: Float, color: Color, spacing: Float) {
                val path = Path().apply {
                    moveTo(0f, viewportHeight)
                    lineTo(0f, sy(base))
                    var px = -((cameraX * parallax) % spacing) - spacing
                    var k = 0
                    while (px < viewportWidth + spacing) {
                        lineTo(px + spacing * 0.5f, sy(base - amp - (k % 3) * 20f))
                        lineTo(px + spacing, sy(base))
                        px += spacing
                        k++
                    }
                    lineTo(viewportWidth, viewportHeight)
                    close()
                }
                drawPath(path, color)
            }
            mountain(0.08f, 440f, 155f, Color(0xFF183C42).copy(alpha = 0.68f), 320f)
            mountain(0.18f, 525f, 110f, Color(0xFF102E33).copy(alpha = 0.86f), 235f)

            repeat(20) { i ->
                val tx = ((i * 182f - cameraX * 0.30f) % (viewportWidth + 280f)) - 90f
                val top = sy(250f + (i % 4) * 30f)
                drawRect(Color(0xFF152C27).copy(alpha = 0.82f), Offset(tx, top), Size(21f, sy(620f) - top))
                drawCircle(Color(0xFF1D553A).copy(alpha = 0.72f), 58f + (i % 3) * 12f, Offset(tx + 10f, top))
            }

            val movingPlatforms = level.movingPlatforms.mapIndexed { index, moving ->
                val phase = elapsedMs / 1000f / moving.periodSeconds * (Math.PI * 2.0) + index * 0.68
                val offset = sin(phase).toFloat() * moving.travel
                GamePlatform(if (moving.vertical) moving.x else moving.x + offset, if (moving.vertical) moving.y + offset else moving.y, moving.width, 26f)
            }

            level.platforms.forEachIndexed { index, p ->
                val visible = when (p.kind) {
                    PlatformKind.SOLID, PlatformKind.BOUNCE -> true
                    PlatformKind.REVEALING -> playerX >= p.triggerX || activeSwitches.isNotEmpty()
                    PlatformKind.DISAPPEARING -> ((elapsedMs + p.phaseMs) % p.cycleMs) < p.cycleMs * 0.64f
                    PlatformKind.PROXIMITY_DISAPPEARING -> platformTriggeredAt[index]?.let { elapsedMs - it <= p.delayMs } ?: true
                    PlatformKind.FALLING -> platformTriggeredAt[index]?.let { elapsedMs - it <= p.delayMs } ?: true
                }
                if (!visible) return@forEachIndexed
                val triggered = platformTriggeredAt[index]
                val fallOffset = if (p.kind == PlatformKind.FALLING && triggered != null) ((elapsedMs - triggered).coerceAtLeast(0L) / 4f).coerceAtMost(120f) else 0f
                val color = if (level.number <= 4) Color(0xFF274E3D) else when (p.kind) {
                    PlatformKind.FALLING -> Color(0xFFD06A3A)
                    PlatformKind.DISAPPEARING, PlatformKind.PROXIMITY_DISAPPEARING -> Color(0xFF7B61FF).copy(alpha = 0.78f)
                    PlatformKind.REVEALING -> Color(0xFF4FC3F7).copy(alpha = 0.78f)
                    PlatformKind.BOUNCE -> Color(0xFF8AF07C)
                    else -> Color(0xFF274E3D)
                }
                val renderedPlatform = p.copy(y = p.y + fallOffset)
                splitPlatformByOpenFloor(renderedPlatform).forEach { piece ->
                    drawRoundRect(color, Offset(piece.x - cameraX, sy(piece.y)), Size(piece.width, piece.height * scaleY), androidx.compose.ui.geometry.CornerRadius(8f))
                    drawRect(Color.White.copy(alpha = 0.14f), Offset(piece.x - cameraX + 5f, sy(piece.y + 4f)), Size((piece.width - 10f).coerceAtLeast(0f), 4f))
                }
            }
            movingPlatforms.forEach { p ->
                drawRoundRect(Color(0xFF56CFE1), Offset(p.x - cameraX, sy(p.y)), Size(p.width, p.height * scaleY), androidx.compose.ui.geometry.CornerRadius(9f))
                drawCircle(Color.White.copy(alpha = 0.55f), 5f, Offset(p.x + p.width / 2f - cameraX, sy(p.y + 12f)))
            }

            level.fans.forEachIndexed { index, fan ->
                val active = fan.cycleMs <= 0 || ((elapsedMs + fan.phaseMs) % fan.cycleMs) < fan.cycleMs * 0.66f
                val reversed = fan.switchIndex?.let { it in activeSwitches } == true
                val dirX = if (reversed) -fan.forceX else fan.forceX
                val dirY = if (reversed) -fan.forceY else fan.forceY
                drawCircle(if (active) Color(0xFF9BE7FF) else Color(0xFF526D79), 27f, Offset(fan.x - cameraX, sy(fan.y + fan.height / 2f)))
                repeat(4) { blade ->
                    val angle = elapsedMs / 120.0 + blade * Math.PI / 2
                    val bx = fan.x - cameraX + kotlin.math.cos(angle).toFloat() * 20f
                    val by = sy(fan.y + fan.height / 2f) + sin(angle).toFloat() * 20f
                    drawLine(Color.White.copy(alpha = 0.7f), Offset(fan.x - cameraX, sy(fan.y + fan.height / 2f)), Offset(bx, by), 5f)
                }
                if (active) repeat(7) { particle ->
                    val progress = ((elapsedMs.toFloat() / 7f + particle * 83f) % max(fan.width, fan.height))
                    val px = if (abs(dirX) > abs(dirY)) fan.x + (if (dirX > 0f) progress else fan.width - progress) else fan.x + (particle % 3) * fan.width / 3f
                    val py = if (abs(dirY) > abs(dirX)) fan.y + (if (dirY > 0f) progress else fan.height - progress) else fan.y + 18f + (particle % 4) * 28f
                    drawLine(Color(0xFFB8F2FF).copy(alpha = 0.48f), Offset(px - cameraX, sy(py)), Offset(px - cameraX - dirX.sign * 24f, sy(py - dirY.sign * 12f)), 2f)
                }
                if (index % 2 == 0 && active) drawCircle(Color(0xFFB8F2FF).copy(alpha = 0.14f), 44f, Offset(fan.x - cameraX, sy(fan.y + fan.height / 2f)))
            }

            fun drawSpikes(h: GameHazard, active: Boolean) {
                if (!active) return
                val count = max(2, ((if (h.orientation == HazardOrientation.LEFT || h.orientation == HazardOrientation.RIGHT) h.height else h.width) / 22f).toInt())
                val path = Path()
                when (h.orientation) {
                    HazardOrientation.UP -> {
                        val baseY = sy(h.y + h.height)
                        path.moveTo(h.x - cameraX, baseY)
                        repeat(count) { i ->
                            val left = h.x - cameraX + h.width * i / count
                            val mid = h.x - cameraX + h.width * (i + 0.5f) / count
                            val right = h.x - cameraX + h.width * (i + 1f) / count
                            path.lineTo(left, baseY); path.lineTo(mid, sy(h.y)); path.lineTo(right, baseY)
                        }
                    }
                    HazardOrientation.DOWN -> {
                        val baseY = sy(h.y)
                        path.moveTo(h.x - cameraX, baseY)
                        repeat(count) { i ->
                            val left = h.x - cameraX + h.width * i / count
                            val mid = h.x - cameraX + h.width * (i + 0.5f) / count
                            val right = h.x - cameraX + h.width * (i + 1f) / count
                            path.lineTo(left, baseY); path.lineTo(mid, sy(h.y + h.height)); path.lineTo(right, baseY)
                        }
                    }
                    HazardOrientation.LEFT -> {
                        val baseX = h.x + h.width - cameraX
                        path.moveTo(baseX, sy(h.y))
                        repeat(count) { i ->
                            val top = sy(h.y + h.height * i / count)
                            val mid = sy(h.y + h.height * (i + 0.5f) / count)
                            val bottom = sy(h.y + h.height * (i + 1f) / count)
                            path.lineTo(baseX, top); path.lineTo(h.x - cameraX, mid); path.lineTo(baseX, bottom)
                        }
                    }
                    HazardOrientation.RIGHT -> {
                        val baseX = h.x - cameraX
                        path.moveTo(baseX, sy(h.y))
                        repeat(count) { i ->
                            val top = sy(h.y + h.height * i / count)
                            val mid = sy(h.y + h.height * (i + 0.5f) / count)
                            val bottom = sy(h.y + h.height * (i + 1f) / count)
                            path.lineTo(baseX, top); path.lineTo(h.x + h.width - cameraX, mid); path.lineTo(baseX, bottom)
                        }
                    }
                }
                path.close()
                val spikeColor = when {
                    h.kind == HazardKind.HIDDEN_SPIKES || h.camouflaged -> Color(0xFFFF5A64)
                    h.kind == HazardKind.CEILING_SPIKES -> Color(0xFFFFB74D)
                    else -> Color(0xFFF2F5F7)
                }
                drawPath(path, spikeColor)
            }
            level.hazards.forEachIndexed { index, h ->
                val cycle = h.cycleMs <= 0 || ((elapsedMs + h.phaseMs) % h.cycleMs) < h.cycleMs * 0.62f
                val active = cycle && (h.kind != HazardKind.HIDDEN_SPIKES || hazardTriggeredAt[index]?.let { elapsedMs - it > 120L } == true)
                if (h.camouflaged) {
                    when (h.orientation) {
                        HazardOrientation.UP -> Unit
                        HazardOrientation.DOWN -> drawRect(Color(0xFF274E3D), Offset(h.x - cameraX, sy(h.y - 18f)), Size(h.width, 20f * scaleY))
                        HazardOrientation.LEFT -> drawRect(Color(0xFF274E3D), Offset(h.x + h.width - cameraX, sy(h.y)), Size(20f, h.height * scaleY))
                        HazardOrientation.RIGHT -> drawRect(Color(0xFF274E3D), Offset(h.x - 20f - cameraX, sy(h.y)), Size(20f, h.height * scaleY))
                    }
                }
                when (h.kind) {
                    HazardKind.SAW -> if (active) {
                        val center = Offset(h.x + h.width / 2f - cameraX, sy(h.y + h.height / 2f))
                        drawCircle(Color(0xFFE0E0E0), h.width / 2f, center)
                        drawCircle(Color(0xFF455A64), h.width / 5f, center)
                        repeat(8) { tooth ->
                            val a = elapsedMs / 170.0 + tooth * Math.PI / 4
                            drawLine(Color(0xFFFF5252), center, Offset(center.x + kotlin.math.cos(a).toFloat() * h.width * 0.58f, center.y + sin(a).toFloat() * h.width * 0.58f), 4f)
                        }
                    }
                    HazardKind.FIRE -> if (active) {
                        repeat(4) { flame ->
                            val fx = h.x + h.width * (flame + 0.5f) / 4f - cameraX
                            val wave = sin(elapsedMs / 90.0 + flame).toFloat() * 8f
                            val p = Path().apply {
                                moveTo(fx - 10f, sy(h.y + h.height))
                                quadraticBezierTo(fx - 18f + wave, sy(h.y + h.height * 0.45f), fx, sy(h.y))
                                quadraticBezierTo(fx + 18f - wave, sy(h.y + h.height * 0.45f), fx + 10f, sy(h.y + h.height))
                                close()
                            }
                            drawPath(p, if (flame % 2 == 0) Color(0xFFFF6D00) else Color(0xFFFFD600))
                        }
                    }
                    else -> drawSpikes(h, active)
                }
            }

            if (level.number <= 4) {
                level.fallingObjects.filter { it.kind == FallingObjectKind.FRUIT }.forEachIndexed { treeIndex, trap ->
                    val trunkX = trap.x + trap.size / 2f - cameraX
                    val crownY = sy(trap.startY - 24f)
                    val trunkTop = trap.startY - 28f
                    val trunkHeight = (trap.targetY - trunkTop).coerceAtLeast(180f)
                    drawRoundRect(
                        Color(0xFF704326),
                        Offset(trunkX - 10f, sy(trunkTop)),
                        Size(20f, trunkHeight * scaleY),
                        androidx.compose.ui.geometry.CornerRadius(6f)
                    )
                    drawLine(Color(0xFF815135), Offset(trunkX, sy(trap.startY + 8f)), Offset(trunkX - 42f, crownY + 16f), 9f)
                    drawLine(Color(0xFF815135), Offset(trunkX, sy(trap.startY + 6f)), Offset(trunkX + 42f, crownY + 12f), 9f)
                    val crownColors = listOf(Color(0xFF67B94D), Color(0xFF78CA58), Color(0xFF8AD568))
                    val crownCenters = listOf(
                        Offset(trunkX, crownY - 10f),
                        Offset(trunkX - 42f, crownY + 8f),
                        Offset(trunkX + 42f, crownY + 8f),
                        Offset(trunkX - 20f, crownY - 42f),
                        Offset(trunkX + 25f, crownY - 40f)
                    )
                    crownCenters.forEachIndexed { index, center ->
                        drawCircle(crownColors[(index + treeIndex) % crownColors.size], if (index == 0) 49f else 39f, center)
                    }
                    drawApple(Offset(trunkX - 33f, crownY - 5f), appleRadius)
                    drawApple(Offset(trunkX + 26f, crownY - 23f), appleRadius)
                    drawApple(Offset(trunkX + 47f, crownY + 15f), appleRadius)
                }
            }

            level.fallingObjects.forEachIndexed { index, trap ->
                val runtime = fallingRuntime[index]
                val y = runtime.y
                val copies = if (trap.behavior == FallingBehavior.CHAIN) trap.chainCount else 1
                repeat(copies) { copyIndex ->
                    val x = runtime.x + (copyIndex - (copies - 1) / 2f) * trap.chainSpacing
                    val center = Offset(x + trap.size / 2f - cameraX, sy(y + trap.size / 2f))
                    when (trap.kind) {
                        FallingObjectKind.FRUIT -> {
                            drawApple(center, appleRadius, trap.behavior == FallingBehavior.EXPLODE)
                        }
                        FallingObjectKind.ROCK -> drawCircle(Color(0xFF78909C), trap.size / 2f, center)
                        FallingObjectKind.CRATE -> drawRoundRect(Color(0xFF9A6A3A), Offset(x - cameraX, sy(y)), Size(trap.size, trap.size * scaleY), androidx.compose.ui.geometry.CornerRadius(7f))
                        FallingObjectKind.SPIKE_BALL -> {
                            drawCircle(Color(0xFF37474F), trap.size / 2f, center)
                            repeat(10) { k ->
                                val a = k * Math.PI * 2 / 10
                                drawLine(Color(0xFFECEFF1), center, Offset(center.x + kotlin.math.cos(a).toFloat() * trap.size * 0.66f, center.y + sin(a).toFloat() * trap.size * 0.66f), 4f)
                            }
                        }
                    }
                }
                runtime.explodedAt?.let { exploded ->
                    val age = elapsedMs - exploded
                    if (age < 360L) {
                        val progress = age / 360f
                        drawCircle(Color(0xFFFF6D00).copy(alpha = 1f - progress), trap.explosionRadius * progress.coerceAtLeast(0.18f), Offset(runtime.x + trap.size / 2f - cameraX, sy(runtime.y + trap.size / 2f)))
                    }
                }
            }

            level.crushers.forEachIndexed { index, trap ->
                val runtime = crusherRuntime[index]
                val triggeredAt = runtime.triggeredAt
                var offset = 0f
                if (triggeredAt != null) {
                    val activeMs = (elapsedMs - triggeredAt - trap.delayMs).coerceAtLeast(0L)
                    val maxDistance = abs(trap.travel)
                    val forward = (activeMs / 1000f * trap.speed).coerceAtMost(maxDistance)
                    val reverseStart = trap.delayMs + trap.reverseAfterMs
                    val distance = if (elapsedMs - triggeredAt <= reverseStart) forward else {
                        val reversed = ((elapsedMs - triggeredAt - reverseStart) / 1000f * trap.speed).coerceAtMost(maxDistance)
                        (maxDistance - reversed).coerceAtLeast(0f)
                    }
                    offset = trap.travel.sign * distance
                }
                val x = trap.x + if (trap.axis == CrusherAxis.HORIZONTAL) offset else 0f
                val y = trap.y + if (trap.axis == CrusherAxis.VERTICAL) offset else 0f
                val crusherX = x - cameraX
                val crusherY = sy(y)
                val crusherHeight = trap.height * scaleY
                drawRoundRect(
                    Color(0xFF172A38),
                    Offset(crusherX, crusherY),
                    Size(trap.width, crusherHeight),
                    androidx.compose.ui.geometry.CornerRadius(10f)
                )
                drawRoundRect(
                    Color(0x5532D8FF),
                    Offset(crusherX + 3f, crusherY + 3f),
                    Size((trap.width - 6f).coerceAtLeast(10f), (crusherHeight - 6f).coerceAtLeast(10f)),
                    androidx.compose.ui.geometry.CornerRadius(8f)
                )
                repeat(4) { line ->
                    val lineY = crusherY + (line + 1) * crusherHeight / 5f
                    drawLine(Color(0xFF8EF6E4).copy(alpha = 0.55f), Offset(crusherX + 6f, lineY), Offset(crusherX + trap.width - 6f, lineY), 3f)
                }
                drawLine(Color.White.copy(alpha = 0.35f), Offset(crusherX + 5f, crusherY + 8f), Offset(crusherX + 5f, crusherY + crusherHeight - 8f), 3f)
            }

            level.barriers.filter { it.switchIndex !in activeSwitches }.forEach { b ->
                val gateX = b.x - cameraX
                val gateY = sy(b.y)
                val gateHeight = b.height * scaleY
                drawRoundRect(Color(0x9927B27B), Offset(gateX + 4f, gateY), Size((b.width - 8f).coerceAtLeast(18f), gateHeight), androidx.compose.ui.geometry.CornerRadius(10f))
                drawRoundRect(Color(0x5532D8FF), Offset(gateX, gateY - 4f), Size(b.width, gateHeight + 8f), androidx.compose.ui.geometry.CornerRadius(12f))
                repeat(5) { k ->
                    val x = gateX + 8f + k * ((b.width - 16f) / 4f)
                    drawLine(Color(0xFFB8F2FF), Offset(x, gateY + 10f), Offset(x, gateY + gateHeight - 10f), 3f)
                }
                drawLine(Color.White.copy(alpha = 0.38f), Offset(gateX + 5f, gateY + 10f), Offset(gateX + b.width - 5f, gateY + 10f), 3f)
            }
            level.switches.forEachIndexed { index, sw ->
                val active = index in activeSwitches
                val pulse = 1f + sin(elapsedMs / 180.0 + index).toFloat() * 0.15f
                if (!active) drawCircle(Gold.copy(alpha = 0.18f), 33f * pulse, Offset(sw.x + 17f - cameraX, sy(sw.y + 22f)))
                drawRoundRect(if (active) NeonGreen else Gold, Offset(sw.x - cameraX, sy(sw.y)), Size(34f, 50f * scaleY), androidx.compose.ui.geometry.CornerRadius(8f))
                drawCircle(Color.White, 5f, Offset(sw.x + 17f - cameraX, sy(sw.y + 14f)))
            }

            level.checkpoints.forEachIndexed { index, cp ->
                if (index !in revealedCheckpoints || index in brokenDecoys) return@forEachIndexed
                val active = index in activatedCheckpoints
                val pulse = 1f + sin(elapsedMs / 170.0 + index).toFloat() * 0.12f
                val color = when {
                    active -> NeonGreen
                    level.number <= 4 -> Color(0xFF62D9C7)
                    cp.kind == CheckpointKind.DECOY -> Color(0xFFFFC857)
                    cp.kind == CheckpointKind.POPUP -> Gold
                    else -> Color(0xFF62D9C7)
                }
                drawCircle(color.copy(alpha = 0.18f), 34f * pulse, Offset(cp.x - cameraX, sy(cp.y + 20f)))
                drawRect(Color(0xFF37474F), Offset(cp.x - 3f - cameraX, sy(cp.y)), Size(6f, 82f * scaleY))
                val flag = Path().apply {
                    moveTo(cp.x - cameraX, sy(cp.y))
                    lineTo(cp.x + 43f - cameraX, sy(cp.y + 12f))
                    lineTo(cp.x - cameraX, sy(cp.y + 28f))
                    close()
                }
                drawPath(flag, color)
                if (level.number > 4 && cp.kind == CheckpointKind.DECOY && !active && (elapsedMs / 250L) % 5L == 0L) drawCircle(Color(0xFFFF1744), 3f, Offset(cp.x + 31f - cameraX, sy(cp.y + 12f)))
            }

            level.crates.forEachIndexed { index, crate ->
                if (index in destroyedCrates) return@forEachIndexed
                drawRoundRect(Color(0xFF9A6A3A), Offset(crate.x - cameraX, sy(crate.y)), Size(54f, 54f * scaleY), androidx.compose.ui.geometry.CornerRadius(5f))
                drawLine(Color(0xFF4F311E), Offset(crate.x - cameraX, sy(crate.y)), Offset(crate.x + 54f - cameraX, sy(crate.y + 54f)), 5f)
                drawLine(Color(0xFF4F311E), Offset(crate.x + 54f - cameraX, sy(crate.y)), Offset(crate.x - cameraX, sy(crate.y + 54f)), 5f)
            }

            enemies.forEachIndexed { index, e ->
                if (e.health <= 0) return@forEachIndexed
                val kind = level.enemies[index].kind
                val color = when (kind) {
                    GameEnemyKind.WALKER -> Color(0xFF7B2CBF)
                    GameEnemyKind.JUMPER -> Color(0xFFE76F51)
                    GameEnemyKind.FLYER -> Color(0xFF00A6A6)
                    GameEnemyKind.SHOOTER -> Color(0xFFB5179E)
                    GameEnemyKind.GUARDIAN -> Color(0xFF5A189A)
                }
                drawRoundRect(color, Offset(e.x - cameraX, sy(e.y)), Size(50f, 56f * scaleY), androidx.compose.ui.geometry.CornerRadius(14f))
                drawCircle(Color.White, 5f, Offset(e.x + 15f - cameraX, sy(e.y + 18f)))
                drawCircle(Color.White, 5f, Offset(e.x + 35f - cameraX, sy(e.y + 18f)))
            }
            bullets.forEach { b -> drawCircle(Gold, 6f, Offset(b.x - cameraX, sy(b.y))) }
            enemyBullets.forEach { b -> drawCircle(Color(0xFFFF4D8D), 6f, Offset(b.x - cameraX, sy(b.y))) }

            level.crystals.forEachIndexed { index, c ->
                if (index in collected) return@forEachIndexed
                val p = Path().apply {
                    moveTo(c.x - cameraX, sy(c.y - 24f)); lineTo(c.x + 18f - cameraX, sy(c.y)); lineTo(c.x - cameraX, sy(c.y + 24f)); lineTo(c.x - 18f - cameraX, sy(c.y)); close()
                }
                drawPath(p, Color(0xFF00E5FF))
            }
            level.pickups.forEachIndexed { index, pickup ->
                if (index in collectedPickups) return@forEachIndexed
                val color = when (pickup.kind) {
                    GamePickupKind.ENERGY -> Color(0xFFFF5A5F)
                    GamePickupKind.SHIELD -> Color(0xFF56CFE1)
                    GamePickupKind.POWER -> Gold
                }
                drawCircle(color.copy(alpha = 0.25f), 24f, Offset(pickup.x - cameraX, sy(pickup.y)))
                drawCircle(color, 13f, Offset(pickup.x - cameraX, sy(pickup.y)))
            }

            val portalReady = collected.size >= 3 && activeSwitches.size >= level.requiredMechanisms
            drawRoundRect(if (portalReady) Gold else Color(0xFF607D8B), Offset(level.goalX - cameraX, sy(485f)), Size(34f, 135f * scaleY), androidx.compose.ui.geometry.CornerRadius(14f))
            drawCircle(if (portalReady) NeonGreen else Color(0xFF455A64), 42f, Offset(level.goalX + 17f - cameraX, sy(472f)))

            if (level.acechantePresent) {
                drawRoundRect(Color(0xFF08050D), Offset(acechanteX - cameraX, sy(playerY - 25f)), Size(42f, 98f * scaleY), androidx.compose.ui.geometry.CornerRadius(18f))
                drawCircle(Color.White, 3.5f, Offset(acechanteX + 12f - cameraX, sy(playerY + 1f)))
                drawCircle(Color.White, 3.5f, Offset(acechanteX + 29f - cameraX, sy(playerY + 1f)))
            }

            level.companion?.let { name ->
                val cx = playerX - 63f
                val color = if (name == "Luma") Color(0xFF62D9C7) else Color(0xFF7CB342)
                drawCircle(color.copy(alpha = 0.24f), 31f, Offset(cx - cameraX, sy(playerY + 34f)))
                drawCircle(color, 22f, Offset(cx - cameraX, sy(playerY + 34f)))
            }

            val playerColor = when {
                elapsedMs < invulnerableUntil && (elapsedMs / 100L) % 2L == 0L -> Color.White
                run.lifeType == "premium" -> Gold
                else -> Color(0xFFE53935)
            }
            val displayPlayerY = playerY
            val playerScale = 1f
            val displayHeight = playerHeight * playerScale
            val displayWidth = playerWidth * (0.82f + playerScale * 0.18f)
            val displayX = playerX + (playerWidth - displayWidth) / 2f
            if (!onGround && jumpsRemaining > 0 && !deathPending) drawCircle(Color(0xFF8EF6E4).copy(alpha = 0.18f), 38f, Offset(playerX + playerWidth / 2f - cameraX, sy(playerY + playerHeight / 2f)))
            drawRoundRect(playerColor, Offset(displayX - cameraX, sy(displayPlayerY)), Size(displayWidth, displayHeight * scaleY), androidx.compose.ui.geometry.CornerRadius(12f))
            if (playerScale > 0.35f) {
                drawCircle(Color.White, 5f * playerScale, Offset(displayX + displayWidth * 0.30f - cameraX, sy(displayPlayerY + displayHeight * 0.31f)))
                drawCircle(Color.White, 5f * playerScale, Offset(displayX + displayWidth * 0.70f - cameraX, sy(displayPlayerY + displayHeight * 0.31f)))
            }

            repeat(28) { i ->
                val leafX = ((i * 149f - cameraX * 0.70f + elapsedMs / 24f) % (viewportWidth + 300f)) - 100f
                val leafY = sy(185f + (i * 79 % 430))
                drawOval(Color(0xFF9CCC65).copy(alpha = 0.20f), Offset(leafX, leafY), Size(17f, 7f))
            }
        }

        Row(
            Modifier.fillMaxWidth().background(Color(0xE8061827)).padding(horizontal = 10.dp, vertical = 4.dp).align(Alignment.TopCenter),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Text("N${level.number} · ${level.levelName}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            HudPill("❤️", "$livesRemaining/$maxLives", Color(0xFFE53935))
            HudPill("CP", "${activatedCheckpoints.count { level.checkpoints[it].kind != CheckpointKind.DECOY }}/${level.checkpoints.count { it.kind != CheckpointKind.DECOY }}", Color(0xFF62D9C7))
            HudPill("💎", "${collected.size}/3", Color(0xFF32D8FF))
            HudPill("⚙", "${activeSwitches.size}/${level.requiredMechanisms}", Color(0xFF90A4AE))
            HudPill("↑", "x$jumpsRemaining", NeonGreen)
            Spacer(Modifier.weight(1f))
            if (shieldHits > 0) HudPill("🛡", "$shieldHits", Color(0xFF8EF6E4))
            if (!guestMode && activationRewards > 0) HudPill("⭐", "+$activationRewards", Gold)
            Text("${elapsedSeconds}s", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            IconButton(onClick = { paused = true }, modifier = Modifier.size(38.dp)) { Icon(Icons.Rounded.Pause, contentDescription = "Pausa") }
        }

        objectiveHint?.let { hint ->
            Card(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 50.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xDD0B321E)),
                shape = RoundedCornerShape(16.dp)
            ) { Text(hint, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp), color = Gold, fontWeight = FontWeight.Bold) }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                HoldButton(Icons.Rounded.ArrowBack, "Izquierda") { pressed -> moveDirection = if (pressed) -1f else if (moveDirection < 0f) 0f else moveDirection }
                HoldButton(Icons.Rounded.ArrowForward, "Derecha") { pressed -> moveDirection = if (pressed) 1f else if (moveDirection > 0f) 0f else moveDirection }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (level.weaponEnabled || weaponPowerUntil > elapsedMs) HoldButton(Icons.Rounded.PlayArrow, "Disparar", accent = Gold) { if (it) shootQueued = true }
                HoldButton(Icons.Rounded.TouchApp, "Interactuar", accent = Color(0xFF62D9C7)) { if (it) interactQueued = true }
                HoldButton(Icons.Rounded.KeyboardArrowUp, "Doble salto", accent = NeonGreen) { if (it) jumpQueued = true }
            }
        }

        if (paused) {
            OverlayCard(title = "Partida en pausa", compact = true) {
                Text("N${level.number} · ${level.levelName}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                Button(
                    onClick = { paused = false },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) { Text("Continuar", fontWeight = FontWeight.Bold) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedButton(
                        onClick = { musicEnabled = !musicEnabled },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (musicEnabled) "Música: sí" else "Música: no") }
                    OutlinedButton(
                        onClick = { effectsEnabled = !effectsEnabled },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (effectsEnabled) "Efectos: sí" else "Efectos: no") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedButton(
                        onClick = { vibrationEnabled = !vibrationEnabled },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (vibrationEnabled) "Vibración: sí" else "Vibración: no") }
                    OutlinedButton(
                        onClick = {
                            val enableAll = !(musicEnabled || effectsEnabled)
                            musicEnabled = enableAll
                            effectsEnabled = enableAll
                        },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (musicEnabled || effectsEnabled) "Silenciar" else "Activar sonido") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    TextButton(
                        onClick = {
                            paused = false
                            pendingExitTarget = ExitTarget.LEVELS
                            endGame(GameOutcome.LOST)
                        },
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) { Text("Volver a niveles") }
                    TextButton(
                        onClick = {
                            paused = false
                            pendingExitTarget = ExitTarget.GEO_ADVENTURES
                            endGame(GameOutcome.LOST)
                        },
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) { Text("Salir del juego", color = Color(0xFFFFB4AB)) }
                }
            }
        }

        LaunchedEffect(resultSaved, pendingExitTarget) {
            if (!resultSaved) return@LaunchedEffect
            when (pendingExitTarget) {
                ExitTarget.LEVELS -> onExit()
                ExitTarget.GEO_ADVENTURES -> onQuit()
                null -> Unit
            }
            pendingExitTarget = null
        }

        if (outcome != null && resultSaved && outcome == GameOutcome.WON && level.outroStory != null && !outroDismissed) {
            OverlayCard(title = "Historia · ${level.levelName}") {
                Text(level.outroStory, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { outroDismissed = true }, colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Continuar") }
            }
        } else if (outcome != null) {
            OverlayCard(title = if (outcome == GameOutcome.WON) "¡Nivel superado!" else "Se agotaron las $maxLives vidas") {
                Text("Cristales: ${collected.size}/3 · Checkpoints: ${activatedCheckpoints.size} · Muertes: $deathCount · Tiempo: ${elapsedSeconds}s")
                if (outcome == GameOutcome.LOST) Text("La partida terminó. La próxima partida comenzará con $maxLives vidas de juego.", color = Gold, textAlign = TextAlign.Center)
                resultError?.let { Text(it, color = Color(0xFFFFB4AB), textAlign = TextAlign.Center) }
                Button(
                    onClick = { if (resultSaved) onExit() else reportAttempt++ },
                    enabled = !reportingResult,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) {
                    if (reportingResult) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = DeepGreen)
                    else Icon(if (resultSaved) Icons.Rounded.ArrowBack else Icons.Rounded.Refresh, contentDescription = null)
                    Text(if (resultSaved) " Volver a niveles" else " Reintentar guardado")
                }
            }
        }
    }
}

@Composable
private fun HudPill(symbol: String, value: String, accent: Color) {
    Row(
        modifier = Modifier
            .background(accent.copy(alpha = 0.16f), RoundedCornerShape(12.dp))
            .padding(horizontal = 7.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(symbol, style = MaterialTheme.typography.bodySmall)
        Text(value, color = accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun HoldButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    accent: Color = Color(0xFF90A4AE),
    onPressed: (Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .background(Color(0xD91A2C38), CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    onPressed(true)
                    tryAwaitRelease()
                    onPressed(false)
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = accent, modifier = Modifier.size(41.dp))
    }
}

@Composable
private fun OverlayCard(
    title: String,
    compact: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.78f)), contentAlignment = Alignment.Center) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth(if (compact) 0.70f else 0.62f)
        ) {
            Column(
                Modifier.padding(horizontal = if (compact) 18.dp else 22.dp, vertical = if (compact) 14.dp else 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 11.dp)
            ) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                content()
            }
        }
    }
}

@Composable
private fun ImmersiveLandscapeEffect() {
    val context = LocalContext.current
    DisposableEffect(context) {
        val activity = context.findActivity()
        val previousOrientation = activity?.requestedOrientation
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        activity?.window?.let { window ->
            WindowCompat.setDecorFitsSystemWindows(window, false)
            WindowInsetsControllerCompat(window, window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
        onDispose {
            activity?.window?.let { window ->
                WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
                WindowCompat.setDecorFitsSystemWindows(window, true)
            }
            if (previousOrientation != null) activity?.requestedOrientation = previousOrientation
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
