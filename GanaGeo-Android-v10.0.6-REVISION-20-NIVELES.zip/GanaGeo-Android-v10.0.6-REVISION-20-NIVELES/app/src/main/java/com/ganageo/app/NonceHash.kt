package com.ganageo.app

import java.security.MessageDigest

/**
 * Supabase recibe el nonce original y valida su SHA-256 contra el claim nonce
 * incluido por Google en el ID token.
 */
internal fun sha256Hex(value: String): String {
    return MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString(separator = "") { byte ->
            "%02x".format(byte.toInt() and 0xff)
        }
}
