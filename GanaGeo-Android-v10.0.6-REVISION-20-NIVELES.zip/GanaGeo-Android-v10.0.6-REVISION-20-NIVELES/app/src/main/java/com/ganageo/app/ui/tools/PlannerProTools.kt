package com.ganageo.app.ui.tools

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ganageo.app.StudyReminderReceiver
import com.ganageo.app.data.StudyPlannerProStore
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun StudyPlannerProScreen(onBack: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { StudyPlannerProStore(context.applicationContext) }
    val data by store.data.collectAsState(initial = com.ganageo.app.data.PlannerProData())
    val scope = rememberCoroutineScope()
    val tabs = listOf("Pomodoro", "Horario", "Metas", "Asistencia", "Estadísticas", "Recordatorio")
    var tab by rememberSaveable { mutableIntStateOf(0) }

    var pomodoroMinutes by rememberSaveable { mutableStateOf("25") }
    var remainingSeconds by rememberSaveable { mutableLongStateOf(25L * 60L) }
    var running by rememberSaveable { mutableStateOf(false) }
    var pomodoroCourse by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(running) {
        while (running && remainingSeconds > 0) {
            delay(1000)
            remainingSeconds--
        }
        if (remainingSeconds <= 0) running = false
    }

    var scheduleCourse by rememberSaveable { mutableStateOf("") }
    var scheduleDay by rememberSaveable { mutableIntStateOf(1) }
    var startTime by rememberSaveable { mutableStateOf("08:00") }
    var endTime by rememberSaveable { mutableStateOf("09:00") }
    var room by rememberSaveable { mutableStateOf("") }

    var goalTitle by rememberSaveable { mutableStateOf("") }
    var goalMinutes by rememberSaveable { mutableStateOf("300") }
    var progressMinutes by rememberSaveable { mutableStateOf("30") }

    var attendanceCourse by rememberSaveable { mutableStateOf("") }
    var attended by rememberSaveable { mutableStateOf("8") }
    var total by rememberSaveable { mutableStateOf("10") }

    var reminderTitle by rememberSaveable { mutableStateOf("Estudiar") }
    var reminderText by rememberSaveable { mutableStateOf("Continúa tu sesión de estudio en Gana Geo") }
    var reminderMinutes by rememberSaveable { mutableStateOf("10") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Planificador de estudio", "Pomodoro, horario, metas, asistencia y recordatorios", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { SimpleDropdown("Sección", tabs, tab) { tab = it } }
            when (tab) {
                0 -> item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("${remainingSeconds / 60}:${(remainingSeconds % 60).toString().padStart(2, '0')}", style = MaterialTheme.typography.displayMedium, color = NeonGreen, fontWeight = FontWeight.Bold)
                            LinearProgressIndicator(progress = {
                                val totalSeconds = (pomodoroMinutes.toLongOrNull()?.coerceAtLeast(1) ?: 25L) * 60L
                                (1f - remainingSeconds.toFloat() / totalSeconds).coerceIn(0f, 1f)
                            }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(pomodoroCourse, { pomodoroCourse = it.take(100) }, label = { Text("Curso o tema") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(pomodoroMinutes, {
                                pomodoroMinutes = it.filter(Char::isDigit).take(3)
                                if (!running) remainingSeconds = (pomodoroMinutes.toLongOrNull() ?: 25L) * 60L
                            }, label = { Text("Minutos") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { running = !running }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                                    Icon(if (running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null); Text(if (running) " Pausar" else " Iniciar")
                                }
                                OutlinedButton(onClick = { running = false; remainingSeconds = (pomodoroMinutes.toLongOrNull() ?: 25L) * 60L }, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.Refresh, null); Text(" Reiniciar") }
                            }
                            Button(onClick = {
                                val minutes = pomodoroMinutes.toIntOrNull() ?: 25
                                scope.launch { store.logStudy(pomodoroCourse, minutes); onMessage("Sesión de $minutes minutos guardada") }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Guardar sesión completada") }
                        }
                    }
                }
                1 -> {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                OutlinedTextField(scheduleCourse, { scheduleCourse = it.take(100) }, label = { Text("Curso") }, modifier = Modifier.fillMaxWidth())
                                SimpleDropdown("Día", listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"), scheduleDay - 1) { scheduleDay = it + 1 }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(startTime, { startTime = it.filter { c -> c.isDigit() || c == ':' }.take(5) }, label = { Text("Inicio") }, modifier = Modifier.weight(1f))
                                    OutlinedTextField(endTime, { endTime = it.filter { c -> c.isDigit() || c == ':' }.take(5) }, label = { Text("Fin") }, modifier = Modifier.weight(1f))
                                }
                                OutlinedTextField(room, { room = it.take(80) }, label = { Text("Aula o lugar") }, modifier = Modifier.fillMaxWidth())
                                Button(onClick = { scope.launch { runCatching { store.addSchedule(scheduleCourse, scheduleDay, startTime, endTime, room) }.onSuccess { scheduleCourse = ""; room = "" }.onFailure { onMessage(it.message ?: "No se pudo guardar") } } }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Agregar al horario") }
                            }
                        }
                    }
                    items(data.schedule, key = { it.id }) { item ->
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(16.dp)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(item.course, fontWeight = FontWeight.Bold)
                                    Text("${dayName(item.dayOfWeek)} · ${item.startTime}–${item.endTime}${if (item.room.isBlank()) "" else " · ${item.room}"}")
                                }
                                IconButton(onClick = { scope.launch { store.deleteSchedule(item.id) } }) { Icon(Icons.Rounded.Delete, "Eliminar") }
                            }
                        }
                    }
                }
                2 -> {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                OutlinedTextField(goalTitle, { goalTitle = it.take(140) }, label = { Text("Meta") }, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(goalMinutes, { goalMinutes = it.filter(Char::isDigit).take(6) }, label = { Text("Minutos objetivo") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                                Button(onClick = { scope.launch { runCatching { store.addGoal(goalTitle, goalMinutes.toIntOrNull() ?: 0) }.onSuccess { goalTitle = "" }.onFailure { onMessage(it.message ?: "No se pudo guardar") } } }, modifier = Modifier.fillMaxWidth()) { Text("Crear meta") }
                            }
                        }
                    }
                    items(data.goals, key = { it.id }) { goal ->
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text(goal.title, fontWeight = FontWeight.Bold)
                                val progress = goal.completedMinutes.toFloat() / goal.targetMinutes.coerceAtLeast(1)
                                LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                                Text("${goal.completedMinutes}/${goal.targetMinutes} min")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(progressMinutes, { progressMinutes = it.filter(Char::isDigit).take(4) }, label = { Text("Añadir min") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                    Button(onClick = { scope.launch { store.addGoalProgress(goal.id, progressMinutes.toIntOrNull() ?: 0) } }) { Text("Sumar") }
                                    IconButton(onClick = { scope.launch { store.deleteGoal(goal.id) } }) { Icon(Icons.Rounded.Delete, "Eliminar") }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                OutlinedTextField(attendanceCourse, { attendanceCourse = it.take(100) }, label = { Text("Curso") }, modifier = Modifier.fillMaxWidth())
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(attended, { attended = it.filter(Char::isDigit).take(4) }, label = { Text("Asistidas") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                    OutlinedTextField(total, { total = it.filter(Char::isDigit).take(4) }, label = { Text("Total") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                }
                                Button(onClick = { scope.launch { runCatching { store.saveAttendance(attendanceCourse, attended.toIntOrNull() ?: 0, total.toIntOrNull() ?: 0) }.onFailure { onMessage(it.message ?: "Datos inválidos") } } }, modifier = Modifier.fillMaxWidth()) { Text("Guardar asistencia") }
                            }
                        }
                    }
                    items(data.attendance, key = { it.id }) { record ->
                        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(16.dp)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(record.course, fontWeight = FontWeight.Bold)
                                    val percentage = record.attended * 100.0 / record.total
                                    Text("${record.attended}/${record.total} · ${"%.1f".format(percentage)} %", color = if (percentage >= 70) NeonGreen else Gold)
                                }
                                IconButton(onClick = { scope.launch { store.deleteAttendance(record.id) } }) { Icon(Icons.Rounded.Delete, "Eliminar") }
                            }
                        }
                    }
                }
                4 -> item {
                    val totalMinutes = data.logs.sumOf { it.minutes }
                    val sessions = data.logs.size
                    val byCourse = data.logs.groupBy { it.course }.mapValues { it.value.sumOf { log -> log.minutes } }.entries.sortedByDescending { it.value }
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Resumen de estudio", style = MaterialTheme.typography.titleLarge)
                            Text("$sessions sesiones · $totalMinutes minutos", color = NeonGreen, fontWeight = FontWeight.Bold)
                            byCourse.take(12).forEach { Text("${it.key}: ${it.value} min") }
                            if (sessions == 0) Text("Guarda sesiones desde Pomodoro para ver estadísticas.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                5 -> item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            OutlinedTextField(reminderTitle, { reminderTitle = it.take(100) }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(reminderText, { reminderText = it.take(250) }, label = { Text("Mensaje") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(reminderMinutes, { reminderMinutes = it.filter(Char::isDigit).take(5) }, label = { Text("Avisar dentro de minutos") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                            Button(onClick = {
                                if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                runCatching { scheduleReminder(context, reminderTitle, reminderText, reminderMinutes.toLong()) }
                                    .onSuccess { onMessage("Recordatorio programado") }
                                    .onFailure { onMessage(it.message ?: "No se pudo programar") }
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                                Icon(Icons.Rounded.Notifications, null); Text(" Programar recordatorio")
                            }
                            Text("El aviso se crea localmente en el teléfono y no usa servidor.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

private fun scheduleReminder(context: Context, title: String, text: String, minutes: Long) {
    require(minutes in 1..525_600) { "Los minutos deben estar entre 1 y 525600" }
    val id = (System.currentTimeMillis() and 0x7FFFFFFF).toInt()
    val intent = Intent(context, StudyReminderReceiver::class.java).apply {
        putExtra(StudyReminderReceiver.EXTRA_TITLE, title)
        putExtra(StudyReminderReceiver.EXTRA_TEXT, text)
        putExtra(StudyReminderReceiver.EXTRA_ID, id)
    }
    val pending = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + minutes * 60_000L, pending)
}

private fun dayName(day: Int): String = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo").getOrElse(day - 1) { "Día" }
