package com.ganageo.app.tools

import kotlin.math.abs

object FunctionAnalyzer {
    data class Point(val x: Double, val y: Double)
    data class Analysis(
        val roots: List<Double>,
        val localMinima: List<Point>,
        val localMaxima: List<Point>,
        val intersections: List<Point>,
        val table: List<Point>
    )

    fun analyze(
        expressions: List<String>,
        xMin: Double,
        xMax: Double,
        degrees: Boolean,
        samples: Int = 1200
    ): Analysis {
        require(expressions.isNotEmpty()) { "Agrega al menos una función" }
        require(xMax > xMin) { "Rango X inválido" }
        val count = samples.coerceIn(200, 5000)
        val step = (xMax - xMin) / count
        val evaluators = expressions.map { expression ->
            { x: Double -> runCatching { ExpressionEvaluator(degrees, mapOf("x" to x)).evaluate(expression) }.getOrNull()?.takeIf(Double::isFinite) }
        }
        val values = evaluators.map { evaluator -> List(count + 1) { index -> evaluator(xMin + index * step) } }
        val roots = mutableListOf<Double>()
        val minima = mutableListOf<Point>()
        val maxima = mutableListOf<Point>()
        val first = values.first()
        for (index in 1 until count) {
            val previous = first[index - 1]
            val current = first[index]
            val next = first[index + 1]
            if (previous != null && current != null && previous * current <= 0 && abs(previous - current) < 1e8) {
                roots += xMin + (index - 0.5) * step
            }
            if (previous != null && current != null && next != null) {
                val x = xMin + index * step
                if (current < previous && current < next) minima += Point(x, current)
                if (current > previous && current > next) maxima += Point(x, current)
            }
        }
        val intersections = mutableListOf<Point>()
        if (values.size >= 2) {
            for (a in 0 until values.lastIndex) {
                for (b in a + 1 until values.size) {
                    var previousDiff: Double? = null
                    for (index in 0..count) {
                        val va = values[a][index]
                        val vb = values[b][index]
                        if (va == null || vb == null) { previousDiff = null; continue }
                        val diff = va - vb
                        if (previousDiff != null && previousDiff * diff <= 0 && abs(previousDiff - diff) < 1e8) {
                            intersections += Point(xMin + (index - 0.5) * step, (va + vb) / 2)
                        }
                        previousDiff = diff
                    }
                }
            }
        }
        val tableStep = (xMax - xMin) / 10.0
        val table = (0..10).mapNotNull { index ->
            val x = xMin + tableStep * index
            evaluators.first()(x)?.let { Point(x, it) }
        }
        return Analysis(
            roots = deduplicateNumbers(roots).take(20),
            localMinima = deduplicatePoints(minima).take(20),
            localMaxima = deduplicatePoints(maxima).take(20),
            intersections = deduplicatePoints(intersections).take(30),
            table = table
        )
    }

    private fun deduplicateNumbers(values: List<Double>): List<Double> = values.sorted().fold(mutableListOf()) { acc, value ->
        if (acc.isEmpty() || abs(acc.last() - value) > 1e-3) acc += value
        acc
    }

    private fun deduplicatePoints(values: List<Point>): List<Point> = values.sortedBy(Point::x).fold(mutableListOf()) { acc, value ->
        if (acc.isEmpty() || abs(acc.last().x - value.x) > 1e-3) acc += value
        acc
    }
}
