package com.ganageo.app.tools

object PageSelectionParser {
    private const val MAX_SELECTED_PAGES = 300
    private const val MAX_GROUPS = 100

    fun parse(raw: String, maxPage: Int? = null): List<Int> {
        if (raw.isBlank()) return emptyList()
        val result = linkedSetOf<Int>()
        raw.split(',')
            .map(String::trim)
            .filter(String::isNotBlank)
            .forEach { token ->
                if ('-' in token) {
                    val pieces = token.split('-', limit = 2).map(String::trim)
                    require(pieces.size == 2) { "Rango inválido: $token" }
                    val start = pieces[0].toIntOrNull() ?: error("Rango inválido: $token")
                    val end = pieces[1].toIntOrNull() ?: error("Rango inválido: $token")
                    require(start > 0 && end >= start) { "Rango inválido: $token" }
                    require(end.toLong() - start.toLong() <= 10_000L) { "El rango es demasiado grande: $token" }
                    for (page in start..end) addValidated(result, page, maxPage)
                } else {
                    val page = token.toIntOrNull() ?: error("Página inválida: $token")
                    addValidated(result, page, maxPage)
                }
            }
        return result.toList()
    }

    fun parseGroups(raw: String, maxPage: Int? = null): List<List<Int>> {
        require(raw.isNotBlank()) { "Escribe al menos un rango." }
        val groups = raw.split(';')
            .map(String::trim)
            .filter(String::isNotBlank)
        require(groups.size <= MAX_GROUPS) { "Puedes crear hasta $MAX_GROUPS partes por operación." }
        return groups.map { group ->
            parse(group, maxPage).also {
                require(it.isNotEmpty()) { "Rango vacío: $group" }
            }
        }.also { parsed ->
            require(parsed.sumOf(List<Int>::size) <= MAX_SELECTED_PAGES) {
                "La selección total supera $MAX_SELECTED_PAGES páginas."
            }
        }
    }

    private fun addValidated(result: MutableSet<Int>, page: Int, maxPage: Int?) {
        require(page > 0) { "Las páginas comienzan en 1." }
        if (maxPage != null) require(page <= maxPage) {
            "La página $page no existe. El documento tiene $maxPage páginas."
        }
        require(result.size < MAX_SELECTED_PAGES || page in result) {
            "Puedes seleccionar hasta $MAX_SELECTED_PAGES páginas por operación."
        }
        result += page
    }
}
