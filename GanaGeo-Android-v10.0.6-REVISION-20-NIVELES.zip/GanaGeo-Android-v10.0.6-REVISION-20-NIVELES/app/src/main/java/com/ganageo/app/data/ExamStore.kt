package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException
import java.util.UUID

private val Context.examDataStore by preferencesDataStore(name = "gana_geo_exams")

@Serializable
enum class ExamQuestionType { MULTIPLE_CHOICE, TRUE_FALSE }

@Serializable
data class ExamQuestion(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val type: ExamQuestionType,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String = ""
)

@Serializable
data class ExamBank(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val course: String = "",
    val questions: List<ExamQuestion> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
data class ExamSession(
    val bankId: String,
    val currentIndex: Int = 0,
    val answers: Map<String, Int> = emptyMap(),
    val startedAt: Long = System.currentTimeMillis(),
    val durationMinutes: Int = 0
)

class ExamStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true }

    val banks: Flow<List<ExamBank>> = context.examDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { decodeBanks(it[BANKS_KEY]).sortedByDescending(ExamBank::updatedAt) }

    val session: Flow<ExamSession?> = context.examDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { raw -> raw[SESSION_KEY]?.let { runCatching { json.decodeFromString<ExamSession>(it) }.getOrNull() } }

    suspend fun createBank(name: String, course: String): ExamBank {
        val cleanName = name.trim()
        require(cleanName.isNotBlank()) { "Escribe el nombre del banco" }
        require(cleanName.length <= 100) { "El nombre es demasiado largo" }
        val bank = ExamBank(name = cleanName, course = course.trim().take(100))
        context.examDataStore.edit { prefs ->
            val current = decodeBanks(prefs[BANKS_KEY]).toMutableList()
            require(current.size < 50) { "Puedes guardar hasta 50 bancos" }
            current += bank
            prefs[BANKS_KEY] = json.encodeToString(current)
        }
        return bank
    }

    suspend fun renameBank(id: String, name: String) = updateBank(id) {
        val clean = name.trim()
        require(clean.isNotBlank()) { "Escribe el nombre del banco" }
        it.copy(name = clean.take(100), updatedAt = System.currentTimeMillis())
    }

    suspend fun updateBankInfo(id: String, name: String, course: String) = updateBank(id) {
        val clean = name.trim()
        require(clean.isNotBlank()) { "Escribe el nombre del banco" }
        it.copy(name = clean.take(100), course = course.trim().take(100), updatedAt = System.currentTimeMillis())
    }

    suspend fun deleteBank(id: String) {
        context.examDataStore.edit { prefs ->
            prefs[BANKS_KEY] = json.encodeToString(decodeBanks(prefs[BANKS_KEY]).filterNot { it.id == id })
            val currentSession = prefs[SESSION_KEY]?.let { runCatching { json.decodeFromString<ExamSession>(it) }.getOrNull() }
            if (currentSession?.bankId == id) prefs.remove(SESSION_KEY)
        }
    }

    suspend fun addQuestion(bankId: String, question: ExamQuestion) {
        validateQuestion(question)
        updateBank(bankId) { bank ->
            require(bank.questions.size < 500) { "Máximo 500 preguntas por banco" }
            bank.copy(questions = bank.questions + question, updatedAt = System.currentTimeMillis())
        }
    }

    suspend fun deleteQuestion(bankId: String, questionId: String) = updateBank(bankId) { bank ->
        bank.copy(questions = bank.questions.filterNot { it.id == questionId }, updatedAt = System.currentTimeMillis())
    }

    suspend fun saveSession(session: ExamSession?) {
        context.examDataStore.edit { prefs ->
            if (session == null) prefs.remove(SESSION_KEY) else prefs[SESSION_KEY] = json.encodeToString(session)
        }
    }

    fun exportBank(bank: ExamBank): String = json.encodeToString(bank)

    suspend fun importBank(raw: String): ExamBank {
        val imported = runCatching { json.decodeFromString<ExamBank>(raw) }.getOrElse { throw IllegalArgumentException("JSON de examen inválido") }
        require(imported.name.isNotBlank()) { "El banco no tiene nombre" }
        require(imported.questions.size <= 500) { "El banco supera 500 preguntas" }
        imported.questions.forEach(::validateQuestion)
        val safe = imported.copy(id = UUID.randomUUID().toString(), updatedAt = System.currentTimeMillis())
        context.examDataStore.edit { prefs ->
            val current = decodeBanks(prefs[BANKS_KEY]).toMutableList()
            require(current.size < 50) { "Puedes guardar hasta 50 bancos" }
            current += safe
            prefs[BANKS_KEY] = json.encodeToString(current)
        }
        return safe
    }

    private suspend fun updateBank(id: String, transform: (ExamBank) -> ExamBank) {
        context.examDataStore.edit { prefs ->
            var found = false
            val updated = decodeBanks(prefs[BANKS_KEY]).map { bank ->
                if (bank.id == id) { found = true; transform(bank) } else bank
            }
            require(found) { "Banco no encontrado" }
            prefs[BANKS_KEY] = json.encodeToString(updated)
        }
    }

    private fun validateQuestion(question: ExamQuestion) {
        require(question.text.isNotBlank()) { "La pregunta está vacía" }
        require(question.text.length <= 1000) { "La pregunta es demasiado larga" }
        when (question.type) {
            ExamQuestionType.MULTIPLE_CHOICE -> {
                require(question.options.size == 4) { "Una pregunta de alternativas debe tener 4 opciones" }
                require(question.options.all { it.isNotBlank() }) { "Completa las cuatro opciones" }
                require(question.correctIndex in 0..3) { "Respuesta correcta inválida" }
            }
            ExamQuestionType.TRUE_FALSE -> require(question.correctIndex in 0..1) { "Respuesta correcta inválida" }
        }
    }

    private fun decodeBanks(raw: String?): List<ExamBank> = raw?.let { runCatching { json.decodeFromString<List<ExamBank>>(it) }.getOrNull() }.orEmpty()

    private companion object {
        val BANKS_KEY = stringPreferencesKey("banks_json")
        val SESSION_KEY = stringPreferencesKey("session_json")
    }
}
