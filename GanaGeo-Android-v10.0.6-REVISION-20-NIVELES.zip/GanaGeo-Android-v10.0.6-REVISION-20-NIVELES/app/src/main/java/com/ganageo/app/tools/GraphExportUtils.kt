package com.ganageo.app.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow

object GraphExportUtils {
    data class Config(
        val expressions: List<String>,
        val xMin: Double,
        val xMax: Double,
        val yMin: Double,
        val yMax: Double,
        val degrees: Boolean
    )

    suspend fun exportPng(context: Context, output: Uri, config: Config) = withContext(Dispatchers.IO) {
        val bitmap = render(config)
        try {
            context.contentResolver.openOutputStream(output, "w")?.use { stream ->
                check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream))
            } ?: error("No se pudo guardar la gráfica")
        } finally {
            bitmap.recycle()
        }
    }

    fun render(config: Config, width: Int = 1600, height: Int = 1100): Bitmap {
        require(config.expressions.isNotEmpty()) { "No hay funciones" }
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.rgb(7, 27, 18))
        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(40, 255, 255, 255); strokeWidth = 2f }
        val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(170, 255, 255, 255); strokeWidth = 4f }
        val colors = listOf(Color.rgb(168, 255, 0), Color.CYAN, Color.MAGENTA, Color.YELLOW)
        fun mapX(x: Double) = ((x - config.xMin) / (config.xMax - config.xMin) * width).toFloat()
        fun mapY(y: Double) = (height - (y - config.yMin) / (config.yMax - config.yMin) * height).toFloat()
        val xStep = gridStep(config.xMax - config.xMin)
        val yStep = gridStep(config.yMax - config.yMin)
        var x = ceil(config.xMin / xStep) * xStep
        while (x <= config.xMax) { val sx = mapX(x); canvas.drawLine(sx, 0f, sx, height.toFloat(), gridPaint); x += xStep }
        var y = ceil(config.yMin / yStep) * yStep
        while (y <= config.yMax) { val sy = mapY(y); canvas.drawLine(0f, sy, width.toFloat(), sy, gridPaint); y += yStep }
        if (0.0 in config.xMin..config.xMax) canvas.drawLine(mapX(0.0), 0f, mapX(0.0), height.toFloat(), axisPaint)
        if (0.0 in config.yMin..config.yMax) canvas.drawLine(0f, mapY(0.0), width.toFloat(), mapY(0.0), axisPaint)
        config.expressions.take(4).forEachIndexed { expressionIndex, expression ->
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colors[expressionIndex % colors.size]; strokeWidth = 6f; style = Paint.Style.STROKE }
            val path = Path()
            var drawing = false
            var previousY: Float? = null
            val samples = width
            for (index in 0..samples) {
                val valueX = config.xMin + (config.xMax - config.xMin) * index / samples
                val valueY = runCatching { ExpressionEvaluator(config.degrees, mapOf("x" to valueX)).evaluate(expression) }.getOrNull()
                val screenY = valueY?.takeIf(Double::isFinite)?.let(::mapY)
                val jump = previousY?.let { p -> screenY == null || abs(screenY - p) > height * 1.5f } ?: false
                if (screenY == null || screenY < -height * 4 || screenY > height * 5 || jump) {
                    drawing = false; previousY = screenY; continue
                }
                val screenX = mapX(valueX)
                if (!drawing) { path.moveTo(screenX, screenY); drawing = true } else path.lineTo(screenX, screenY)
                previousY = screenY
            }
            canvas.drawPath(path, paint)
        }
        return bitmap
    }

    private fun gridStep(range: Double): Double {
        if (!range.isFinite() || range <= 0) return 1.0
        val rough = range / 10.0
        val power = 10.0.pow(floor(log10(rough)))
        val normalized = rough / power
        return when {
            normalized < 1.5 -> 1.0
            normalized < 3.5 -> 2.0
            normalized < 7.5 -> 5.0
            else -> 10.0
        } * power
    }
}
