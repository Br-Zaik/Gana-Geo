package com.ganageo.app.tools

data class WorkPayResult(
    val regularHours: Double,
    val overtimeHours: Double,
    val regularPay: Double,
    val overtimePay: Double,
    val totalPay: Double
)

object WorkPayCalculator {
    fun calculate(
        hourlyRate: Double,
        regularHoursPerDay: Double,
        overtimeHoursPerDay: Double,
        overtimeMultiplier: Double,
        days: Double
    ): WorkPayResult {
        require(hourlyRate.isFinite() && hourlyRate >= 0) { "Pago por hora inválido" }
        require(regularHoursPerDay.isFinite() && regularHoursPerDay >= 0) { "Horas regulares inválidas" }
        require(overtimeHoursPerDay.isFinite() && overtimeHoursPerDay >= 0) { "Horas extra inválidas" }
        require(overtimeMultiplier.isFinite() && overtimeMultiplier > 0) { "Multiplicador inválido" }
        require(days.isFinite() && days > 0) { "Cantidad de días inválida" }

        val regularHours = regularHoursPerDay * days
        val overtimeHours = overtimeHoursPerDay * days
        val regularPay = hourlyRate * regularHours
        val overtimePay = hourlyRate * overtimeHours * overtimeMultiplier
        val totalPay = regularPay + overtimePay

        require(listOf(regularPay, overtimePay, totalPay).all(Double::isFinite)) {
            "El resultado está fuera del límite permitido"
        }

        return WorkPayResult(
            regularHours = regularHours,
            overtimeHours = overtimeHours,
            regularPay = regularPay,
            overtimePay = overtimePay,
            totalPay = totalPay
        )
    }
}

data class SaleProfitResult(
    val grossProfit: Double,
    val commission: Double,
    val netProfit: Double,
    val netMarginPercent: Double,
    val markupPercent: Double
)

object CommerceCalculator {
    fun analyzeSale(cost: Double, salePrice: Double, commissionPercent: Double): SaleProfitResult {
        require(cost.isFinite() && cost >= 0) { "Costo inválido" }
        require(salePrice.isFinite() && salePrice > 0) { "Precio de venta inválido" }
        require(commissionPercent.isFinite() && commissionPercent in 0.0..100.0) { "Comisión inválida" }

        val commission = salePrice * commissionPercent / 100.0
        val grossProfit = salePrice - cost
        val netProfit = grossProfit - commission
        val netMargin = netProfit / salePrice * 100.0
        val markup = if (cost > 0) grossProfit / cost * 100.0 else 0.0

        return SaleProfitResult(
            grossProfit = grossProfit,
            commission = commission,
            netProfit = netProfit,
            netMarginPercent = netMargin,
            markupPercent = markup
        )
    }

    fun targetSalePrice(cost: Double, desiredMarginPercent: Double, commissionPercent: Double): Double {
        require(cost.isFinite() && cost >= 0) { "Costo inválido" }
        require(desiredMarginPercent.isFinite() && desiredMarginPercent >= 0) { "Margen inválido" }
        require(commissionPercent.isFinite() && commissionPercent >= 0) { "Comisión inválida" }
        val margin = desiredMarginPercent / 100.0
        val commission = commissionPercent / 100.0
        require(margin + commission < 1.0) { "Margen y comisión juntos deben ser menores de 100%" }
        return cost / (1.0 - margin - commission)
    }

    fun quoteTotals(subtotal: Double, igvPercent: Double = 18.0): Triple<Double, Double, Double> {
        require(subtotal.isFinite() && subtotal >= 0) { "Subtotal inválido" }
        require(igvPercent.isFinite() && igvPercent >= 0) { "IGV inválido" }
        val tax = subtotal * igvPercent / 100.0
        return Triple(subtotal, tax, subtotal + tax)
    }
}
