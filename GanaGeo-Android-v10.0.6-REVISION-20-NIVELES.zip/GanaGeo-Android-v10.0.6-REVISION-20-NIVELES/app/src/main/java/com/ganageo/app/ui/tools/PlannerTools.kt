package com.ganageo.app.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.AcademicPlannerStore
import com.ganageo.app.data.AcademicTask
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch

@Composable
fun AcademicPlannerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { AcademicPlannerStore(context.applicationContext) }
    val tasks by store.tasks.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var title by rememberSaveable { mutableStateOf("") }
    var course by rememberSaveable { mutableStateOf("") }
    var dueDate by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var filter by rememberSaveable { mutableStateOf("Pendientes") }
    val visibleTasks = when (filter) {
        "Completadas" -> tasks.filter { it.completed }
        "Todas" -> tasks
        else -> tasks.filterNot { it.completed }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Agenda académica", "Organiza tareas y cursos sin conexión", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardGreen),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Nueva tarea", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it.take(300) },
                            label = { Text("Tarea o actividad") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = course,
                            onValueChange = { course = it.take(120) },
                            label = { Text("Curso (opcional)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = dueDate,
                            onValueChange = {
                                dueDate = it.filter { char -> char.isDigit() || char in "/-." }.take(10)
                            },
                            label = { Text("Fecha límite (opcional)") },
                            placeholder = { Text("DD/MM/AAAA") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                scope.launch {
                                    runCatching { store.addTask(title, course, dueDate) }
                                        .onSuccess {
                                            title = ""
                                            course = ""
                                            dueDate = ""
                                            message = "Tarea guardada"
                                        }
                                        .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
                                }
                            },
                            enabled = title.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonGreen,
                                contentColor = DeepGreen
                            )
                        ) { Text("Agregar tarea", fontWeight = FontWeight.Bold) }
                        message?.let {
                            Text(
                                it,
                                color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen
                            )
                        }
                    }
                }
            }

            item {
                val pending = tasks.count { !it.completed }
                val completed = tasks.size - pending
                Card(
                    colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.09f)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Pendientes: $pending", color = Gold, fontWeight = FontWeight.Bold)
                        Text("Completadas: $completed", color = NeonGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Pendientes", "Completadas", "Todas").forEach { option ->
                        Button(
                            onClick = { filter = option },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (filter == option) NeonGreen else CardGreen,
                                contentColor = if (filter == option) DeepGreen else MaterialTheme.colorScheme.onSurface
                            ),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) { Text(option, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }

            if (tasks.any { it.completed }) {
                item {
                    OutlinedButton(
                        onClick = { scope.launch { store.clearCompleted() } },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = null)
                        Text(" Eliminar tareas completadas")
                    }
                }
            }

            if (tasks.isEmpty()) {
                item {
                    Text(
                        "Todavía no tienes tareas registradas.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (visibleTasks.isEmpty()) {
                item {
                    Text(
                        "No hay tareas en el filtro $filter.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(visibleTasks, key = { it.id }) { task ->
                    PlannerTaskCard(
                        task = task,
                        onToggle = { scope.launch { store.toggleCompleted(task.id) } },
                        onDelete = { scope.launch { store.deleteTask(task.id) } }
                    )
                }
            }
        }
    }
}

@Composable
private fun PlannerTaskCard(
    task: AcademicTask,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            IconButton(onClick = onToggle) {
                Icon(
                    if (task.completed) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                    contentDescription = if (task.completed) "Marcar pendiente" else "Marcar completada",
                    tint = if (task.completed) NeonGreen else Gold
                )
            }
            Column(
                modifier = Modifier.weight(1f).padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    task.title,
                    fontWeight = FontWeight.Bold,
                    textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None
                )
                if (task.course.isNotBlank()) {
                    Text(task.course, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (task.dueDate.isNotBlank()) {
                    Text("Fecha: ${task.dueDate}", color = Gold)
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar")
            }
        }
    }
}
