package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

private val Context.toolCreditsDataStore by preferencesDataStore(name = "tool_test_credits")

data class TestToolBalance(
    val credits: Long = 0,
    val reservedCredits: Long = 0,
    val usedCredits: Long = 0,
    val rewardProgress: Long = 0,
    val rewardPoints: Long = 0
) {
    val availableCredits: Long
        get() = (credits - reservedCredits).coerceAtLeast(0)
}

data class LocalToolReservation(
    val id: String,
    val cost: Long
)

class ToolCreditsStore(private val context: Context) {
    private object Keys {
        val Credits = longPreferencesKey("credits")
        val UsedCredits = longPreferencesKey("used_credits")
        val RewardProgress = longPreferencesKey("reward_progress")
        val RewardPoints = longPreferencesKey("reward_points")
        val ReservedCredits = longPreferencesKey("reserved_credits")
    }

    suspend fun readBalance(): TestToolBalance = context.toolCreditsDataStore.data
        .map { prefs ->
            TestToolBalance(
                credits = prefs[Keys.Credits] ?: 0,
                reservedCredits = prefs[Keys.ReservedCredits] ?: 0,
                usedCredits = prefs[Keys.UsedCredits] ?: 0,
                rewardProgress = prefs[Keys.RewardProgress] ?: 0,
                rewardPoints = prefs[Keys.RewardPoints] ?: 0
            )
        }
        .first()

    suspend fun recoverInterruptedReservations() {
        context.toolCreditsDataStore.edit { prefs ->
            // En modo debug una reserva no puede continuar después de cerrar el proceso.
            // Se libera al iniciar para que los créditos simulados no queden bloqueados.
            prefs[Keys.ReservedCredits] = 0
        }
    }

    suspend fun addTestCredits(amount: Long) {
        require(amount > 0)
        context.toolCreditsDataStore.edit { prefs ->
            prefs[Keys.Credits] = (prefs[Keys.Credits] ?: 0) + amount
        }
    }

    suspend fun reserve(cost: Long): LocalToolReservation {
        require(cost > 0)
        var success = false
        context.toolCreditsDataStore.edit { prefs ->
            val credits = prefs[Keys.Credits] ?: 0
            val reserved = prefs[Keys.ReservedCredits] ?: 0
            if (credits - reserved >= cost) {
                prefs[Keys.ReservedCredits] = reserved + cost
                success = true
            }
        }
        if (!success) error("No tienes créditos de prueba suficientes.")
        return LocalToolReservation(UUID.randomUUID().toString(), cost)
    }

    suspend fun complete(reservation: LocalToolReservation): Long {
        var awarded = 0L
        context.toolCreditsDataStore.edit { prefs ->
            val reserved = prefs[Keys.ReservedCredits] ?: 0
            if (reserved < reservation.cost) error("La reserva de créditos no es válida.")

            val credits = prefs[Keys.Credits] ?: 0
            if (credits < reservation.cost) error("El saldo de créditos cambió.")

            val previousProgress = prefs[Keys.RewardProgress] ?: 0
            val combined = previousProgress + reservation.cost
            val completedBlocks = combined / 10
            awarded = completedBlocks * 50

            prefs[Keys.Credits] = credits - reservation.cost
            prefs[Keys.ReservedCredits] = reserved - reservation.cost
            prefs[Keys.UsedCredits] = (prefs[Keys.UsedCredits] ?: 0) + reservation.cost
            prefs[Keys.RewardProgress] = combined % 10
            prefs[Keys.RewardPoints] = (prefs[Keys.RewardPoints] ?: 0) + awarded
        }
        return awarded
    }

    suspend fun cancel(reservation: LocalToolReservation) {
        context.toolCreditsDataStore.edit { prefs ->
            val reserved = prefs[Keys.ReservedCredits] ?: 0
            prefs[Keys.ReservedCredits] = (reserved - reservation.cost).coerceAtLeast(0)
        }
    }


    suspend fun spendForGameLives(cost: Long) {
        require(cost > 0)
        var success = false
        context.toolCreditsDataStore.edit { prefs ->
            val credits = prefs[Keys.Credits] ?: 0
            val reserved = prefs[Keys.ReservedCredits] ?: 0
            if (credits - reserved >= cost) {
                prefs[Keys.Credits] = credits - cost
                success = true
            }
        }
        if (!success) error("No tienes créditos de prueba suficientes.")
    }

    suspend fun rewardUsedGameLife(creditCost: Long): Long {
        require(creditCost > 0)
        var awarded = 0L
        context.toolCreditsDataStore.edit { prefs ->
            val previousProgress = prefs[Keys.RewardProgress] ?: 0
            val combined = previousProgress + creditCost
            awarded = (combined / 10) * 50
            prefs[Keys.UsedCredits] = (prefs[Keys.UsedCredits] ?: 0) + creditCost
            prefs[Keys.RewardProgress] = combined % 10
            prefs[Keys.RewardPoints] = (prefs[Keys.RewardPoints] ?: 0) + awarded
        }
        return awarded
    }

    suspend fun reset() {
        context.toolCreditsDataStore.edit { it.clear() }
    }
}
