-- Gana Geo v8.2: correccion permanente del control de instalaciones.
-- Ejecutar UNA sola vez en Supabase > SQL Editor.
-- No borra usuarios, saldos, movimientos, retiros ni Geo IDs.

begin;

create or replace function public.register_my_device(
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_hash text := btrim(p_installation_hash);
    v_owner_id uuid;
    v_active_id uuid;
    v_active_hash text;
    v_existing_id uuid;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    if v_hash is null or length(v_hash) < 16 then
        raise exception 'Invalid installation identifier';
    end if;

    if not exists (
        select 1
        from public.profiles
        where user_id = v_user_id
          and account_status = 'active'
    ) then
        raise exception 'Account is not active';
    end if;

    perform pg_advisory_xact_lock(hashtext(v_user_id::text)::bigint);
    perform pg_advisory_xact_lock(hashtext(v_hash)::bigint);

    select user_id
    into v_owner_id
    from public.devices
    where installation_hash = v_hash
      and device_status = 'active'
    limit 1
    for update;

    if v_owner_id is not null and v_owner_id <> v_user_id then
        raise exception 'This device is already linked to another account';
    end if;

    select id, installation_hash
    into v_active_id, v_active_hash
    from public.devices
    where user_id = v_user_id
      and device_status = 'active'
    limit 1
    for update;

    if v_active_id is not null and v_active_hash <> v_hash then
        raise exception 'This account is already linked to another active device';
    end if;

    if v_active_id is not null then
        update public.devices
        set last_seen_at = now()
        where id = v_active_id;
    else
        select id
        into v_existing_id
        from public.devices
        where user_id = v_user_id
          and installation_hash = v_hash
        order by last_seen_at desc
        limit 1
        for update;

        if v_existing_id is null then
            insert into public.devices (
                user_id,
                installation_hash,
                device_status,
                first_seen_at,
                last_seen_at
            ) values (
                v_user_id,
                v_hash,
                'active',
                now(),
                now()
            );
        else
            update public.devices
            set device_status = 'active',
                last_seen_at = now()
            where id = v_existing_id;
        end if;
    end if;

    update public.profiles
    set last_seen_at = now()
    where user_id = v_user_id;
end;
$$;

create or replace function public.replace_my_device(
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_hash text := btrim(p_installation_hash);
    v_other_owner uuid;
    v_existing_id uuid;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    if v_hash is null or length(v_hash) < 16 then
        raise exception 'Invalid installation identifier';
    end if;

    if not exists (
        select 1
        from public.profiles
        where user_id = v_user_id
          and account_status = 'active'
    ) then
        raise exception 'Account is not active';
    end if;

    perform pg_advisory_xact_lock(hashtext(v_user_id::text)::bigint);
    perform pg_advisory_xact_lock(hashtext(v_hash)::bigint);

    select user_id
    into v_other_owner
    from public.devices
    where installation_hash = v_hash
      and device_status = 'active'
    limit 1
    for update;

    if v_other_owner is not null and v_other_owner <> v_user_id then
        raise exception 'This device is already linked to another account';
    end if;

    -- Libera todas las instalaciones activas de esta cuenta, incluso si quedó
    -- un registro inconsistente de una versión anterior.
    update public.devices
    set device_status = 'replaced',
        last_seen_at = now()
    where user_id = v_user_id
      and device_status = 'active';

    select id
    into v_existing_id
    from public.devices
    where user_id = v_user_id
      and installation_hash = v_hash
    order by last_seen_at desc
    limit 1
    for update;

    if v_existing_id is null then
        insert into public.devices (
            user_id,
            installation_hash,
            device_status,
            first_seen_at,
            last_seen_at
        ) values (
            v_user_id,
            v_hash,
            'active',
            now(),
            now()
        );
    else
        update public.devices
        set device_status = 'active',
            last_seen_at = now()
        where id = v_existing_id;
    end if;

    update public.profiles
    set last_seen_at = now()
    where user_id = v_user_id;
end;
$$;

revoke all on function public.register_my_device(text)
from public, anon;

grant execute on function public.register_my_device(text)
to authenticated;

revoke all on function public.replace_my_device(text)
from public, anon;

grant execute on function public.replace_my_device(text)
to authenticated;

commit;

notify pgrst, 'reload schema';
