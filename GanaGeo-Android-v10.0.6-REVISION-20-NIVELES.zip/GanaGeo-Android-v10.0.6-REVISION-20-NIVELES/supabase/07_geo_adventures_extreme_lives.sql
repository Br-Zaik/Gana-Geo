-- Gana Geo v0.9.3
-- Migración del juego extremo: 5 vidas rojas, 1 vida cada 30 minutos.
-- Los 10 intentos y checkpoints se controlan dentro de una partida; el servidor
-- consume una sola vida al crear la partida.

begin;

alter table public.geo_game_accounts
    add column if not exists free_life_updated_at timestamptz not null default now();

do $$
declare
    c record;
begin
    for c in
        select conname
          from pg_constraint
         where conrelid = 'public.geo_game_accounts'::regclass
           and contype = 'c'
           and pg_get_constraintdef(oid) ilike '%free_lives%'
    loop
        execute format('alter table public.geo_game_accounts drop constraint %I', c.conname);
    end loop;
end;
$$;

alter table public.geo_game_accounts
    add constraint geo_game_accounts_free_lives_check check (free_lives between 0 and 5);

update public.geo_game_accounts
   set free_lives = least(5, greatest(0, free_lives)),
       free_life_updated_at = coalesce(free_life_updated_at, now()),
       updated_at = now();

create or replace function public.refresh_geo_game_state(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_today date := (now() at time zone 'America/Lima')::date;
begin
    insert into public.geo_game_accounts (
        user_id, free_lives, free_lives_day, free_life_updated_at, premium_used_day
    ) values (
        p_user_id, 5, v_today, now(), v_today
    )
    on conflict (user_id) do nothing;

    update public.geo_game_accounts
       set free_lives = least(
               5,
               free_lives + floor(extract(epoch from (now() - free_life_updated_at)) / 1800)::integer
           ),
           free_life_updated_at = case
               when free_lives + floor(extract(epoch from (now() - free_life_updated_at)) / 1800)::integer >= 5
                   then now()
               else free_life_updated_at + (
                   floor(extract(epoch from (now() - free_life_updated_at)) / 1800)::integer * interval '30 minutes'
               )
           end,
           free_lives_day = v_today,
           updated_at = now()
     where user_id = p_user_id
       and free_lives < 5
       and now() - free_life_updated_at >= interval '30 minutes';

    update public.geo_game_accounts
       set free_life_updated_at = now(),
           free_lives_day = v_today,
           updated_at = now()
     where user_id = p_user_id
       and free_lives >= 5
       and now() - free_life_updated_at >= interval '30 minutes';

    update public.geo_game_accounts
       set premium_used_today = 0,
           premium_used_day = v_today,
           updated_at = now()
     where user_id = p_user_id
       and premium_used_day <> v_today;

    update public.geo_game_premium_lives l
       set status = 'available',
           reserved_run_id = null,
           reserved_at = null
     where l.user_id = p_user_id
       and l.status = 'reserved'
       and l.reserved_at < now() - interval '45 minutes';

    update public.geo_game_runs r
       set status = 'abandoned',
           finished_at = now(),
           updated_at = now()
     where r.user_id = p_user_id
       and r.status in ('started', 'activated')
       and r.started_at < now() - interval '45 minutes';
end;
$$;


drop function if exists public.get_geo_game_status(text);
create or replace function public.get_geo_game_status(p_installation_hash text)
returns table (
    free_lives integer,
    premium_lives bigint,
    unlocked_level integer,
    total_stars bigint,
    best_score bigint,
    premium_used_today integer,
    premium_daily_limit integer,
    next_free_life_in_seconds bigint
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
begin
    if v_user_id is null then raise exception 'Authentication required'; end if;
    perform public.assert_active_installation(v_user_id, p_installation_hash);
    perform public.refresh_geo_game_state(v_user_id);
    return query
    select a.free_lives,
           (select count(*) from public.geo_game_premium_lives l where l.user_id = v_user_id and l.status = 'available'),
           a.unlocked_level,
           coalesce((select sum(p.best_stars) from public.geo_game_level_progress p where p.user_id = v_user_id), 0),
           a.best_score,
           a.premium_used_today,
           10,
           case
               when a.free_lives >= 5 then 0::bigint
               else greatest(0, ceil(extract(epoch from (a.free_life_updated_at + interval '30 minutes' - now()))))::bigint
           end
      from public.geo_game_accounts a
     where a.user_id = v_user_id;
end;
$$;

create or replace function public.start_geo_game_run(
    p_level_no integer,
    p_life_type text,
    p_installation_hash text,
    p_request_id uuid
)
returns table (
    run_id uuid,
    life_type text,
    free_lives_remaining integer,
    premium_lives_remaining bigint,
    needs_activation boolean
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_account public.geo_game_accounts%rowtype;
    v_life public.geo_game_premium_lives%rowtype;
    v_existing public.geo_game_runs%rowtype;
    v_run_id uuid := gen_random_uuid();
    v_type text := lower(trim(p_life_type));
begin
    if v_user_id is null then raise exception 'Authentication required'; end if;
    if p_request_id is null then raise exception 'Invalid request identifier'; end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);
    perform public.refresh_geo_game_state(v_user_id);
    perform pg_advisory_xact_lock(hashtext(v_user_id::text)::bigint);

    select * into v_existing
      from public.geo_game_runs
     where user_id = v_user_id and client_request_id = p_request_id
     limit 1 for update;

    if v_existing.id is not null then
        if v_existing.level_no <> p_level_no or v_existing.life_type <> v_type then
            raise exception 'Request identifier already used for another run';
        end if;
        return query
        select v_existing.id,
               v_existing.life_type,
               a.free_lives,
               (select count(*) from public.geo_game_premium_lives l where l.user_id = v_user_id and l.status = 'available'),
               (v_existing.life_type = 'premium' and v_existing.status = 'started')
          from public.geo_game_accounts a
         where a.user_id = v_user_id;
        return;
    end if;

    select * into v_account
      from public.geo_game_accounts
     where user_id = v_user_id
     for update;

    if p_level_no is null or p_level_no < 1 or p_level_no > 20 then raise exception 'Invalid level'; end if;
    if p_level_no > v_account.unlocked_level then raise exception 'Level is locked'; end if;
    if exists (
        select 1 from public.geo_game_runs r
         where r.user_id = v_user_id and r.status in ('started', 'activated')
    ) then raise exception 'Another game run is active'; end if;

    if v_type = 'free' then
        if v_account.free_lives <= 0 then raise exception 'No free lives available'; end if;
        update public.geo_game_accounts
           set free_life_updated_at = case when free_lives >= 5 then now() else free_life_updated_at end,
               free_lives = free_lives - 1,
               total_runs = total_runs + 1,
               updated_at = now()
         where user_id = v_user_id;
        insert into public.geo_game_runs (
            id, user_id, level_no, life_type, client_request_id, status, activated_at
        ) values (
            v_run_id, v_user_id, p_level_no, 'free', p_request_id, 'activated', now()
        );
    elsif v_type = 'premium' then
        if v_account.premium_used_today >= 10 then raise exception 'Daily premium life limit reached'; end if;
        select * into v_life
          from public.geo_game_premium_lives
         where user_id = v_user_id and status = 'available'
         order by created_at limit 1 for update skip locked;
        if v_life.id is null then raise exception 'No premium lives available'; end if;
        insert into public.geo_game_runs (
            id, user_id, level_no, life_type, premium_life_id, client_request_id, status
        ) values (
            v_run_id, v_user_id, p_level_no, 'premium', v_life.id, p_request_id, 'started'
        );
        update public.geo_game_premium_lives
           set status = 'reserved', reserved_run_id = v_run_id, reserved_at = now()
         where id = v_life.id;
        update public.geo_game_accounts
           set total_runs = total_runs + 1, updated_at = now()
         where user_id = v_user_id;
    else
        raise exception 'Invalid life type';
    end if;

    return query
    select v_run_id,
           v_type,
           a.free_lives,
           (select count(*) from public.geo_game_premium_lives l where l.user_id = v_user_id and l.status = 'available'),
           (v_type = 'premium')
      from public.geo_game_accounts a
     where a.user_id = v_user_id;
end;
$$;

commit;
