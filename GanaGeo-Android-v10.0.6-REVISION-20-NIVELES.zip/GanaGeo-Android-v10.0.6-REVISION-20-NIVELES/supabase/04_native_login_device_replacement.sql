-- Gana Geo: funciones seguras que la app puede invocar.
-- Ejecutar UNA sola vez en Supabase > SQL Editor, después del bloque inicial de tablas.
-- No usa service_role dentro de la app y nunca permite que el APK cambie saldos libremente.

begin;

-- =========================================================
-- 1. REGISTRAR UNA INSTALACION ACTIVA POR CUENTA/DISPOSITIVO
-- =========================================================

create or replace function public.register_my_device(
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_device_id uuid;
    v_owner_id uuid;
    v_current_hash text;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    if p_installation_hash is null or length(trim(p_installation_hash)) < 16 then
        raise exception 'Invalid installation identifier';
    end if;

    if not exists (
        select 1
          from public.profiles
         where user_id = v_user_id
           and account_status = 'active'
    ) then
        raise exception 'Account is not active';
    end if;

    -- Serializa el registro para evitar carreras entre dos aperturas simultáneas.
    perform pg_advisory_xact_lock(hashtext(v_user_id::text)::bigint);
    perform pg_advisory_xact_lock(hashtext(trim(p_installation_hash))::bigint);

    -- Impide que una instalación activa pertenezca a otra cuenta.
    select id, user_id
      into v_device_id, v_owner_id
      from public.devices
     where installation_hash = trim(p_installation_hash)
       and device_status = 'active'
     for update;

    if v_device_id is not null and v_owner_id <> v_user_id then
        raise exception 'This device is already linked to another account';
    end if;

    v_device_id := null;

    -- Impide que una cuenta activa cambie de dispositivo sin revisión.
    select id, installation_hash
      into v_device_id, v_current_hash
      from public.devices
     where user_id = v_user_id
       and device_status = 'active'
     for update;

    if v_device_id is not null then
        if v_current_hash <> trim(p_installation_hash) then
            raise exception 'This account is already linked to another active device';
        end if;

        update public.devices
           set last_seen_at = now()
         where id = v_device_id;
    else
        insert into public.devices (
            user_id,
            installation_hash,
            device_status,
            first_seen_at,
            last_seen_at
        ) values (
            v_user_id,
            trim(p_installation_hash),
            'active',
            now(),
            now()
        );
    end if;

    update public.profiles
       set last_seen_at = now()
     where user_id = v_user_id;
end;
$$;

-- Verifica que una operación sensible provenga de la instalación activa.
create or replace function public.assert_active_installation(
    p_user_id uuid,
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if p_user_id is null or p_installation_hash is null
       or length(trim(p_installation_hash)) < 16 then
        raise exception 'Invalid installation identifier';
    end if;

    if not exists (
        select 1
          from public.devices
         where user_id = p_user_id
           and installation_hash = trim(p_installation_hash)
           and device_status = 'active'
    ) then
        raise exception 'This installation is not active';
    end if;
end;
$$;

-- Permite al propietario reemplazar explícitamente su instalación anterior.
-- Nunca roba una instalación que actualmente pertenece a otra cuenta.
create or replace function public.replace_my_device(
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_existing_id uuid;
    v_other_owner uuid;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    if p_installation_hash is null or length(trim(p_installation_hash)) < 16 then
        raise exception 'Invalid installation identifier';
    end if;

    if not exists (
        select 1
          from public.profiles
         where user_id = v_user_id
           and account_status = 'active'
    ) then
        raise exception 'Account is not active';
    end if;

    -- Serializa cambios para esta cuenta e instalación y evita carreras.
    perform pg_advisory_xact_lock(hashtext(v_user_id::text)::bigint);
    perform pg_advisory_xact_lock(hashtext(trim(p_installation_hash))::bigint);

    select user_id
      into v_other_owner
      from public.devices
     where installation_hash = trim(p_installation_hash)
       and device_status = 'active'
     limit 1
     for update;

    if v_other_owner is not null and v_other_owner <> v_user_id then
        raise exception 'This device is already linked to another account';
    end if;

    update public.devices
       set device_status = 'replaced',
           last_seen_at = now()
     where user_id = v_user_id
       and device_status = 'active'
       and installation_hash <> trim(p_installation_hash);

    select id
      into v_existing_id
      from public.devices
     where user_id = v_user_id
       and installation_hash = trim(p_installation_hash)
     order by last_seen_at desc
     limit 1
     for update;

    if v_existing_id is null then
        insert into public.devices (
            user_id,
            installation_hash,
            device_status,
            first_seen_at,
            last_seen_at
        ) values (
            v_user_id,
            trim(p_installation_hash),
            'active',
            now(),
            now()
        );
    else
        update public.devices
           set device_status = 'active',
               last_seen_at = now()
         where id = v_existing_id;
    end if;

    update public.profiles
       set last_seen_at = now()
     where user_id = v_user_id;
end;
$$;

-- Elimina firmas antiguas sin validación de instalación.
drop function if exists public.request_withdrawal(numeric, text, text);
drop function if exists public.request_withdrawal(numeric, text, text, text);
drop function if exists public.cancel_my_withdrawal(uuid);
drop function if exists public.cancel_my_withdrawal(uuid, text);

-- =========================================================
-- 2. SOLICITAR RETIRO Y BLOQUEAR EL SALDO EN UNA TRANSACCION
-- =========================================================

create or replace function public.request_withdrawal(
    p_amount numeric,
    p_payment_method text,
    p_payment_destination text,
    p_installation_hash text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_currency text;
    v_withdrawal_id uuid;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    if p_amount is null or p_amount < 5 then
        raise exception 'Withdrawal amount must be at least S/5';
    end if;

    if p_amount <> round(p_amount, 2) then
        raise exception 'Withdrawal amount can have at most two decimals';
    end if;

    if lower(trim(p_payment_method)) not in ('yape', 'plin', 'paypal') then
        raise exception 'Unsupported payment method';
    end if;

    if p_payment_destination is null or length(trim(p_payment_destination)) < 5 then
        raise exception 'Invalid payment destination';
    end if;

    if not exists (
        select 1
          from public.profiles
         where user_id = v_user_id
           and account_status = 'active'
    ) then
        raise exception 'Account is not active';
    end if;

    select currency
      into v_currency
      from public.wallets
     where user_id = v_user_id
     for update;

    if v_currency is null then
        raise exception 'Wallet not found';
    end if;

    update public.wallets
       set available_amount = available_amount - p_amount,
           locked_amount = locked_amount + p_amount,
           updated_at = now()
     where user_id = v_user_id
       and available_amount >= p_amount;

    if not found then
        raise exception 'Insufficient available balance';
    end if;

    insert into public.withdrawals (
        user_id,
        amount,
        currency,
        payment_method,
        payment_destination,
        status,
        requested_at,
        updated_at
    ) values (
        v_user_id,
        p_amount,
        v_currency,
        lower(trim(p_payment_method)),
        trim(p_payment_destination),
        'pending',
        now(),
        now()
    )
    returning id into v_withdrawal_id;

    insert into public.ledger_entries (
        user_id,
        entry_type,
        points_delta,
        cash_delta,
        cash_bucket,
        currency,
        provider,
        external_transaction_id,
        description,
        metadata
    ) values (
        v_user_id,
        'withdrawal',
        0,
        -p_amount,
        'available',
        v_currency,
        'gana_geo',
        v_withdrawal_id::text,
        'Retiro solicitado',
        jsonb_build_object(
            'withdrawal_id', v_withdrawal_id,
            'status', 'pending',
            'payment_method', lower(trim(p_payment_method))
        )
    );

    return v_withdrawal_id;
end;
$$;

-- =========================================================
-- 3. CANCELAR UN RETIRO PENDIENTE Y LIBERAR EL SALDO
-- =========================================================

create or replace function public.cancel_my_withdrawal(
    p_withdrawal_id uuid,
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_amount numeric(14,2);
    v_currency text;
    v_status text;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    select amount, currency, status
      into v_amount, v_currency, v_status
      from public.withdrawals
     where id = p_withdrawal_id
       and user_id = v_user_id
     for update;

    if v_amount is null then
        raise exception 'Withdrawal not found';
    end if;

    if v_status not in ('pending', 'under_review') then
        raise exception 'This withdrawal can no longer be cancelled';
    end if;

    update public.wallets
       set available_amount = available_amount + v_amount,
           locked_amount = locked_amount - v_amount,
           updated_at = now()
     where user_id = v_user_id
       and locked_amount >= v_amount;

    if not found then
        raise exception 'Wallet locked balance is inconsistent';
    end if;

    update public.withdrawals
       set status = 'cancelled',
           updated_at = now(),
           processed_at = now()
     where id = p_withdrawal_id;

    insert into public.ledger_entries (
        user_id,
        entry_type,
        points_delta,
        cash_delta,
        cash_bucket,
        currency,
        provider,
        external_transaction_id,
        description,
        metadata
    ) values (
        v_user_id,
        'reversal',
        0,
        v_amount,
        'available',
        v_currency,
        'gana_geo_cancel',
        p_withdrawal_id::text,
        'Retiro cancelado',
        jsonb_build_object(
            'withdrawal_id', p_withdrawal_id,
            'status', 'cancelled'
        )
    );
end;
$$;

-- =========================================================
-- 4. PERMISOS MINIMOS
-- =========================================================

revoke all on function public.register_my_device(text)
from public, anon;

grant execute on function public.register_my_device(text)
to authenticated;

-- Esta función es solo un helper interno de las RPC security definer.
revoke all on function public.assert_active_installation(uuid, text)
from public, anon, authenticated;

revoke all on function public.replace_my_device(text)
from public, anon;

grant execute on function public.replace_my_device(text)
to authenticated;

revoke all on function public.request_withdrawal(numeric, text, text, text)
from public, anon;

grant execute on function public.request_withdrawal(numeric, text, text, text)
to authenticated;

revoke all on function public.cancel_my_withdrawal(uuid, text)
from public, anon;

grant execute on function public.cancel_my_withdrawal(uuid, text)
to authenticated;

commit;
-- Gana Geo: créditos de herramientas y Rewards por uso.
-- Ejecutar después de 01_schema.sql y 02_secure_app_functions.sql.
-- La app nunca concede créditos reales desde el celular: los packs se acreditan
-- únicamente desde un proceso de servidor que verifica la compra de Google Play.

begin;

-- =========================================================
-- 1. CUENTA DE CRÉDITOS Y OPERACIONES RESERVADAS
-- =========================================================

create table if not exists public.tool_credit_accounts (
    user_id uuid primary key references auth.users(id) on delete cascade,
    purchased_credits bigint not null default 0 check (purchased_credits >= 0),
    promo_credits bigint not null default 0 check (promo_credits >= 0),
    reserved_purchased bigint not null default 0 check (reserved_purchased >= 0),
    reserved_promo bigint not null default 0 check (reserved_promo >= 0),
    purchased_used_total bigint not null default 0 check (purchased_used_total >= 0),
    promo_used_total bigint not null default 0 check (promo_used_total >= 0),
    reward_progress bigint not null default 0 check (reward_progress between 0 and 9),
    updated_at timestamptz not null default now(),
    check (reserved_purchased <= purchased_credits),
    check (reserved_promo <= promo_credits)
);

create table if not exists public.tool_operations (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    tool_code text not null,
    credit_cost bigint not null check (credit_cost > 0),
    reserved_purchased bigint not null default 0 check (reserved_purchased >= 0),
    reserved_promo bigint not null default 0 check (reserved_promo >= 0),
    status text not null default 'reserved' check (
        status in ('reserved', 'completed', 'cancelled', 'expired')
    ),
    reward_points_awarded bigint not null default 0 check (reward_points_awarded >= 0),
    created_at timestamptz not null default now(),
    completed_at timestamptz,
    updated_at timestamptz not null default now(),
    check (reserved_purchased + reserved_promo = credit_cost)
);

create index if not exists tool_operations_user_date_idx
on public.tool_operations (user_id, created_at desc);

create index if not exists tool_operations_reserved_idx
on public.tool_operations (status, created_at)
where status = 'reserved';

create table if not exists public.play_purchase_claims (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    product_id text not null check (product_id in ('pack_geo_50', 'pack_geo_100')),
    purchase_token_hash text not null unique,
    order_id text,
    purchase_state text not null default 'pending' check (
        purchase_state in ('pending', 'verified', 'rejected', 'refunded')
    ),
    credits_granted bigint not null default 0 check (credits_granted >= 0),
    raw_payload jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    verified_at timestamptz,
    updated_at timestamptz not null default now()
);

create index if not exists play_purchase_claims_user_idx
on public.play_purchase_claims (user_id, created_at desc);

-- El tipo de movimiento ahora incluye Rewards por uso de herramientas.
alter table public.ledger_entries
    drop constraint if exists ledger_entries_entry_type_check;

alter table public.ledger_entries
    add constraint ledger_entries_entry_type_check check (
        entry_type in (
            'survey_reward', 'offer_reward', 'game_reward', 'referral_reward',
            'ad_points', 'purchase_points', 'tool_reward', 'withdrawal',
            'reversal', 'adjustment'
        )
    );

-- =========================================================
-- 2. ALTA Y REPARACIÓN DE USUARIOS
-- =========================================================

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    insert into public.profiles (user_id, display_name, avatar_url, country_code)
    values (
        new.id,
        coalesce(
            new.raw_user_meta_data ->> 'full_name',
            new.raw_user_meta_data ->> 'name',
            split_part(new.email, '@', 1),
            'Usuario'
        ),
        coalesce(
            new.raw_user_meta_data ->> 'avatar_url',
            new.raw_user_meta_data ->> 'picture'
        ),
        'PE'
    )
    on conflict (user_id) do nothing;

    insert into public.wallets (user_id, currency)
    values (new.id, 'PEN')
    on conflict (user_id) do nothing;

    insert into public.tool_credit_accounts (user_id)
    values (new.id)
    on conflict (user_id) do nothing;

    return new;
end;
$$;

insert into public.tool_credit_accounts (user_id)
select id from auth.users
on conflict (user_id) do nothing;

-- =========================================================
-- 3. RLS: SOLO LECTURA PROPIA DESDE EL APK
-- =========================================================

alter table public.tool_credit_accounts enable row level security;
alter table public.tool_operations enable row level security;
alter table public.play_purchase_claims enable row level security;

revoke all on table public.tool_credit_accounts from anon, authenticated;
revoke all on table public.tool_operations from anon, authenticated;
revoke all on table public.play_purchase_claims from anon, authenticated;

grant select on table public.tool_credit_accounts to authenticated;
grant select on table public.tool_operations to authenticated;
-- play_purchase_claims contiene datos de verificación y queda accesible solo al backend.

drop policy if exists "User reads own tool credits" on public.tool_credit_accounts;
create policy "User reads own tool credits"
on public.tool_credit_accounts for select to authenticated
using ((select auth.uid()) is not null and (select auth.uid()) = user_id);

drop policy if exists "User reads own tool operations" on public.tool_operations;
create policy "User reads own tool operations"
on public.tool_operations for select to authenticated
using ((select auth.uid()) is not null and (select auth.uid()) = user_id);

drop policy if exists "User reads own purchase claims" on public.play_purchase_claims;

-- =========================================================
-- 4. RESERVAR, COMPLETAR O CANCELAR UNA OPERACIÓN
-- =========================================================

-- Elimina firmas antiguas que no comprobaban la instalación activa.
drop function if exists public.begin_tool_operation(text, bigint);
drop function if exists public.begin_tool_operation(text, bigint, text);
drop function if exists public.complete_tool_operation(uuid);
drop function if exists public.complete_tool_operation(uuid, text);
drop function if exists public.cancel_tool_operation(uuid);
drop function if exists public.cancel_tool_operation(uuid, text);

create or replace function public.begin_tool_operation(
    p_tool_code text,
    p_credit_cost bigint,
    p_installation_hash text
)
returns table (
    operation_id uuid,
    reserved_credits bigint,
    credit_source text
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_account public.tool_credit_accounts%rowtype;
    v_available_purchased bigint;
    v_available_promo bigint;
    v_take_purchased bigint;
    v_take_promo bigint;
    v_operation_id uuid;
    v_tool_code text;
    v_expected_cost bigint;
    v_expired_purchased bigint := 0;
    v_expired_promo bigint := 0;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    if p_tool_code is null or length(trim(p_tool_code)) < 3 then
        raise exception 'Invalid tool code';
    end if;

    v_tool_code := lower(trim(p_tool_code));
    v_expected_cost := case v_tool_code
        when 'images_to_pdf' then 5
        when 'pdf_organizer' then 10
        when 'pdf_to_images' then 5
        when 'sign_pdf' then 5
        when 'compress_image' then 5
        when 'resize_image' then 5
        when 'convert_image' then 5
        when 'crop_rotate_image' then 5
        when 'watermark_image' then 5
        else null
    end;

    if v_expected_cost is null then
        raise exception 'Unsupported paid tool';
    end if;

    if p_credit_cost is null or p_credit_cost <> v_expected_cost then
        raise exception 'Invalid credit cost for tool';
    end if;

    if not exists (
        select 1 from public.profiles
        where user_id = v_user_id and account_status = 'active'
    ) then
        raise exception 'Account is not active';
    end if;

    select * into v_account
    from public.tool_credit_accounts
    where user_id = v_user_id
    for update;

    if v_account.user_id is null then
        insert into public.tool_credit_accounts (user_id)
        values (v_user_id)
        returning * into v_account;
    end if;

    -- Libera reservas abandonadas por cierres inesperados o pérdida de conexión.
    with expired as (
        update public.tool_operations
           set status = 'expired',
               completed_at = now(),
               updated_at = now()
         where user_id = v_user_id
           and status = 'reserved'
           and created_at < now() - interval '2 hours'
        returning reserved_purchased, reserved_promo
    )
    select coalesce(sum(reserved_purchased), 0), coalesce(sum(reserved_promo), 0)
      into v_expired_purchased, v_expired_promo
      from expired;

    if v_expired_purchased > 0 or v_expired_promo > 0 then
        update public.tool_credit_accounts
           set reserved_purchased = greatest(reserved_purchased - v_expired_purchased, 0),
               reserved_promo = greatest(reserved_promo - v_expired_promo, 0),
               updated_at = now()
         where user_id = v_user_id
        returning * into v_account;
    end if;

    v_available_purchased := v_account.purchased_credits - v_account.reserved_purchased;
    v_available_promo := v_account.promo_credits - v_account.reserved_promo;

    if v_available_purchased + v_available_promo < p_credit_cost then
        raise exception 'Insufficient tool credits';
    end if;

    -- Se consumen primero los créditos comprados para respetar el progreso de Rewards.
    v_take_purchased := least(v_available_purchased, p_credit_cost);
    v_take_promo := p_credit_cost - v_take_purchased;

    update public.tool_credit_accounts
       set reserved_purchased = reserved_purchased + v_take_purchased,
           reserved_promo = reserved_promo + v_take_promo,
           updated_at = now()
     where user_id = v_user_id;

    insert into public.tool_operations (
        user_id,
        tool_code,
        credit_cost,
        reserved_purchased,
        reserved_promo,
        status
    ) values (
        v_user_id,
        v_tool_code,
        p_credit_cost,
        v_take_purchased,
        v_take_promo,
        'reserved'
    ) returning id into v_operation_id;

    return query select
        v_operation_id,
        p_credit_cost,
        case
            when v_take_purchased = p_credit_cost then 'purchased'
            when v_take_promo = p_credit_cost then 'promo'
            else 'mixed'
        end;
end;
$$;

create or replace function public.complete_tool_operation(
    p_operation_id uuid,
    p_installation_hash text
)
returns table (
    awarded_points bigint,
    remaining_credits bigint
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_operation public.tool_operations%rowtype;
    v_account public.tool_credit_accounts%rowtype;
    v_combined_progress bigint;
    v_awarded bigint;
    v_remaining bigint;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    select * into v_operation
    from public.tool_operations
    where id = p_operation_id and user_id = v_user_id
    for update;

    if v_operation.id is null then
        raise exception 'Tool operation not found';
    end if;

    if v_operation.status = 'completed' then
        select reward_points_awarded into v_awarded
        from public.tool_operations where id = p_operation_id;

        select purchased_credits + promo_credits - reserved_purchased - reserved_promo
          into v_remaining
          from public.tool_credit_accounts
         where user_id = v_user_id;

        return query select coalesce(v_awarded, 0), greatest(coalesce(v_remaining, 0), 0);
        return;
    end if;

    if v_operation.status <> 'reserved' then
        raise exception 'Tool operation is not reserved';
    end if;

    select * into v_account
    from public.tool_credit_accounts
    where user_id = v_user_id
    for update;

    if v_account.reserved_purchased < v_operation.reserved_purchased
       or v_account.reserved_promo < v_operation.reserved_promo
       or v_account.purchased_credits < v_operation.reserved_purchased
       or v_account.promo_credits < v_operation.reserved_promo then
        raise exception 'Tool credit reservation is inconsistent';
    end if;

    v_combined_progress := v_account.reward_progress + v_operation.reserved_purchased;
    v_awarded := (v_combined_progress / 10) * 50;

    update public.tool_credit_accounts
       set purchased_credits = purchased_credits - v_operation.reserved_purchased,
           promo_credits = promo_credits - v_operation.reserved_promo,
           reserved_purchased = reserved_purchased - v_operation.reserved_purchased,
           reserved_promo = reserved_promo - v_operation.reserved_promo,
           purchased_used_total = purchased_used_total + v_operation.reserved_purchased,
           promo_used_total = promo_used_total + v_operation.reserved_promo,
           reward_progress = v_combined_progress % 10,
           updated_at = now()
     where user_id = v_user_id;

    if v_awarded > 0 then
        update public.wallets
           set internal_points = internal_points + v_awarded,
               updated_at = now()
         where user_id = v_user_id;

        insert into public.ledger_entries (
            user_id,
            entry_type,
            points_delta,
            cash_delta,
            provider,
            external_transaction_id,
            description,
            metadata
        ) values (
            v_user_id,
            'tool_reward',
            v_awarded,
            0,
            'gana_geo_tools',
            p_operation_id::text,
            'Geo Rewards por usar herramientas',
            jsonb_build_object(
                'tool_code', v_operation.tool_code,
                'purchased_credits_used', v_operation.reserved_purchased,
                'promo_credits_used', v_operation.reserved_promo
            )
        ) on conflict (provider, external_transaction_id) do nothing;
    end if;

    update public.tool_operations
       set status = 'completed',
           reward_points_awarded = v_awarded,
           completed_at = now(),
           updated_at = now()
     where id = p_operation_id;

    select purchased_credits + promo_credits - reserved_purchased - reserved_promo
      into v_remaining
      from public.tool_credit_accounts
     where user_id = v_user_id;

    return query select v_awarded, greatest(v_remaining, 0);
end;
$$;

create or replace function public.cancel_tool_operation(
    p_operation_id uuid,
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_operation public.tool_operations%rowtype;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    select * into v_operation
    from public.tool_operations
    where id = p_operation_id and user_id = v_user_id
    for update;

    if v_operation.id is null then
        raise exception 'Tool operation not found';
    end if;

    if v_operation.status = 'cancelled' then
        return;
    end if;

    if v_operation.status <> 'reserved' then
        raise exception 'This tool operation can no longer be cancelled';
    end if;

    update public.tool_credit_accounts
       set reserved_purchased = reserved_purchased - v_operation.reserved_purchased,
           reserved_promo = reserved_promo - v_operation.reserved_promo,
           updated_at = now()
     where user_id = v_user_id
       and reserved_purchased >= v_operation.reserved_purchased
       and reserved_promo >= v_operation.reserved_promo;

    if not found then
        raise exception 'Tool credit reservation is inconsistent';
    end if;

    update public.tool_operations
       set status = 'cancelled',
           completed_at = now(),
           updated_at = now()
     where id = p_operation_id;
end;
$$;

-- Esta función es solo para un backend con service_role después de verificar Google Play.
-- Nunca se concede permiso al rol authenticated.
create or replace function public.grant_verified_tool_pack(
    p_user_id uuid,
    p_purchase_token_hash text,
    p_product_id text,
    p_order_id text default null,
    p_raw_payload jsonb default '{}'::jsonb
)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_credits bigint;
begin
    v_credits := case p_product_id
        when 'pack_geo_50' then 50
        when 'pack_geo_100' then 100
        else null
    end;

    if v_credits is null then
        raise exception 'Unsupported product';
    end if;

    insert into public.play_purchase_claims (
        user_id,
        product_id,
        purchase_token_hash,
        order_id,
        purchase_state,
        credits_granted,
        raw_payload,
        verified_at
    ) values (
        p_user_id,
        p_product_id,
        p_purchase_token_hash,
        p_order_id,
        'verified',
        v_credits,
        coalesce(p_raw_payload, '{}'::jsonb),
        now()
    ) on conflict (purchase_token_hash) do nothing;

    if not found then
        raise exception 'Purchase token already processed';
    end if;

    insert into public.tool_credit_accounts (user_id, purchased_credits)
    values (p_user_id, v_credits)
    on conflict (user_id) do update
       set purchased_credits = public.tool_credit_accounts.purchased_credits + excluded.purchased_credits,
           updated_at = now();

    return v_credits;
end;
$$;

-- =========================================================
-- 5. PERMISOS MÍNIMOS
-- =========================================================

revoke all on function public.begin_tool_operation(text, bigint, text)
from public, anon;
grant execute on function public.begin_tool_operation(text, bigint, text)
to authenticated;

revoke all on function public.complete_tool_operation(uuid, text)
from public, anon;
grant execute on function public.complete_tool_operation(uuid, text)
to authenticated;

revoke all on function public.cancel_tool_operation(uuid, text)
from public, anon;
grant execute on function public.cancel_tool_operation(uuid, text)
to authenticated;

revoke all on function public.grant_verified_tool_pack(uuid, text, text, text, jsonb)
from public, anon, authenticated;
grant execute on function public.grant_verified_tool_pack(uuid, text, text, text, jsonb)
to service_role;

revoke execute on function public.handle_new_user() from public, anon, authenticated;

commit;
