-- Gana Geo: esquema base de Supabase.
-- Ejecutar una sola vez en un proyecto nuevo, antes de 02_secure_app_functions.sql.
-- Es idempotente: puede volver a ejecutarse para reparar objetos faltantes sin borrar datos.

begin;

create extension if not exists pgcrypto;

-- =========================================================
-- 1. GEO ID DE 9 DIGITOS
-- =========================================================

create sequence if not exists public.geo_id_sequence
as bigint
start with 100000000
increment by 1
minvalue 100000000
maxvalue 999999999
no cycle;

-- =========================================================
-- 2. PERFIL, BILLETERA Y MOVIMIENTOS
-- =========================================================

create table if not exists public.profiles (
    user_id uuid primary key references auth.users(id) on delete cascade,
    geo_id bigint not null default nextval('public.geo_id_sequence'::regclass) unique,
    display_name text,
    avatar_url text,
    country_code text not null default 'PE' check (country_code ~ '^[A-Z]{2}$'),
    account_status text not null default 'active' check (
        account_status in ('active', 'inactive', 'under_review', 'suspended', 'deleted')
    ),
    last_seen_at timestamptz not null default now(),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

alter sequence public.geo_id_sequence owned by public.profiles.geo_id;

create table if not exists public.wallets (
    user_id uuid primary key references auth.users(id) on delete cascade,
    internal_points bigint not null default 0 check (internal_points >= 0),
    pending_amount numeric(14,2) not null default 0 check (pending_amount >= 0),
    available_amount numeric(14,2) not null default 0 check (available_amount >= 0),
    locked_amount numeric(14,2) not null default 0 check (locked_amount >= 0),
    currency text not null default 'PEN' check (currency ~ '^[A-Z]{3}$'),
    updated_at timestamptz not null default now()
);

create table if not exists public.ledger_entries (
    id bigint generated always as identity primary key,
    user_id uuid not null references auth.users(id) on delete cascade,
    entry_type text not null check (
        entry_type in (
            'survey_reward', 'offer_reward', 'game_reward', 'referral_reward',
            'ad_points', 'purchase_points', 'withdrawal', 'reversal', 'adjustment'
        )
    ),
    points_delta bigint not null default 0,
    cash_delta numeric(14,2) not null default 0,
    cash_bucket text check (
        cash_bucket is null or cash_bucket in ('pending', 'available', 'locked')
    ),
    currency text check (currency is null or currency ~ '^[A-Z]{3}$'),
    provider text,
    external_transaction_id text,
    description text,
    metadata jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    unique (provider, external_transaction_id)
);

create index if not exists ledger_entries_user_date_idx
on public.ledger_entries (user_id, created_at desc);

-- =========================================================
-- 3. RETIROS, DISPOSITIVOS Y PROVEEDORES
-- =========================================================

create table if not exists public.withdrawals (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    amount numeric(14,2) not null check (amount > 0),
    currency text not null check (currency ~ '^[A-Z]{3}$'),
    payment_method text not null check (payment_method in ('yape', 'plin', 'paypal')),
    payment_destination text not null,
    status text not null default 'pending' check (
        status in ('pending', 'under_review', 'approved', 'paid', 'rejected', 'cancelled')
    ),
    payment_reference text,
    rejection_reason text,
    requested_at timestamptz not null default now(),
    processed_at timestamptz,
    updated_at timestamptz not null default now()
);

create index if not exists withdrawals_user_date_idx
on public.withdrawals (user_id, requested_at desc);

create index if not exists withdrawals_status_idx
on public.withdrawals (status, requested_at);

create table if not exists public.devices (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    installation_hash text not null,
    device_status text not null default 'active' check (
        device_status in ('active', 'replaced', 'blocked', 'under_review')
    ),
    first_seen_at timestamptz not null default now(),
    last_seen_at timestamptz not null default now()
);

create unique index if not exists one_active_device_per_user
on public.devices (user_id)
where device_status = 'active';

create unique index if not exists one_account_per_active_device
on public.devices (installation_hash)
where device_status = 'active';

create table if not exists public.provider_transactions (
    id uuid primary key default gen_random_uuid(),
    provider text not null,
    external_transaction_id text not null,
    user_id uuid not null references auth.users(id) on delete cascade,
    transaction_status text not null default 'pending' check (
        transaction_status in ('pending', 'completed', 'reversed', 'rejected')
    ),
    gross_amount numeric(14,2) not null default 0 check (gross_amount >= 0),
    user_reward_amount numeric(14,2) not null default 0 check (user_reward_amount >= 0),
    currency text not null default 'PEN' check (currency ~ '^[A-Z]{3}$'),
    raw_payload jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    unique (provider, external_transaction_id)
);

create index if not exists provider_transactions_user_idx
on public.provider_transactions (user_id, created_at desc);

-- =========================================================
-- 4. FECHAS AUTOMATICAS Y ALTA DE USUARIO
-- =========================================================

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
    new.updated_at = now();
    return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists wallets_set_updated_at on public.wallets;
create trigger wallets_set_updated_at
before update on public.wallets
for each row execute function public.set_updated_at();

drop trigger if exists withdrawals_set_updated_at on public.withdrawals;
create trigger withdrawals_set_updated_at
before update on public.withdrawals
for each row execute function public.set_updated_at();

drop trigger if exists provider_transactions_set_updated_at on public.provider_transactions;
create trigger provider_transactions_set_updated_at
before update on public.provider_transactions
for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    insert into public.profiles (user_id, display_name, avatar_url, country_code)
    values (
        new.id,
        coalesce(
            new.raw_user_meta_data ->> 'full_name',
            new.raw_user_meta_data ->> 'name',
            split_part(new.email, '@', 1),
            'Usuario'
        ),
        coalesce(
            new.raw_user_meta_data ->> 'avatar_url',
            new.raw_user_meta_data ->> 'picture'
        ),
        'PE'
    )
    on conflict (user_id) do nothing;

    insert into public.wallets (user_id, currency)
    values (new.id, 'PEN')
    on conflict (user_id) do nothing;

    return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- Repara perfiles/billeteras de usuarios creados antes del trigger.
insert into public.profiles (user_id, display_name, avatar_url, country_code)
select
    u.id,
    coalesce(
        u.raw_user_meta_data ->> 'full_name',
        u.raw_user_meta_data ->> 'name',
        split_part(u.email, '@', 1),
        'Usuario'
    ),
    coalesce(
        u.raw_user_meta_data ->> 'avatar_url',
        u.raw_user_meta_data ->> 'picture'
    ),
    'PE'
from auth.users u
on conflict (user_id) do nothing;

insert into public.wallets (user_id, currency)
select u.id, 'PEN'
from auth.users u
on conflict (user_id) do nothing;

-- =========================================================
-- 5. RLS: EL CELULAR SOLO LEE DATOS PROPIOS
-- =========================================================

alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.ledger_entries enable row level security;
alter table public.withdrawals enable row level security;
alter table public.devices enable row level security;
alter table public.provider_transactions enable row level security;

revoke all on table public.profiles from anon, authenticated;
revoke all on table public.wallets from anon, authenticated;
revoke all on table public.ledger_entries from anon, authenticated;
revoke all on table public.withdrawals from anon, authenticated;
revoke all on table public.devices from anon, authenticated;
revoke all on table public.provider_transactions from anon, authenticated;

grant select on table public.profiles to authenticated;
grant select on table public.wallets to authenticated;
grant select on table public.ledger_entries to authenticated;
grant select on table public.withdrawals to authenticated;

drop policy if exists "User reads own profile" on public.profiles;
create policy "User reads own profile"
on public.profiles for select to authenticated
using ((select auth.uid()) is not null and (select auth.uid()) = user_id);

drop policy if exists "User reads own wallet" on public.wallets;
create policy "User reads own wallet"
on public.wallets for select to authenticated
using ((select auth.uid()) is not null and (select auth.uid()) = user_id);

drop policy if exists "User reads own ledger" on public.ledger_entries;
create policy "User reads own ledger"
on public.ledger_entries for select to authenticated
using ((select auth.uid()) is not null and (select auth.uid()) = user_id);

drop policy if exists "User reads own withdrawals" on public.withdrawals;
create policy "User reads own withdrawals"
on public.withdrawals for select to authenticated
using ((select auth.uid()) is not null and (select auth.uid()) = user_id);

revoke execute on function public.set_updated_at() from public, anon, authenticated;
revoke execute on function public.handle_new_user() from public, anon, authenticated;

commit;
