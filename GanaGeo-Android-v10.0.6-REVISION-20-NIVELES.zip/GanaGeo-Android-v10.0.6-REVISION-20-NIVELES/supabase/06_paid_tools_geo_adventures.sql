-- Gana Geo v8.6
-- Corrección de operaciones pagadas + Geo Aventuras.
-- Ejecutar después de 05_device_login_permanent_fix.sql.
-- No modifica Google OAuth, perfiles, referidos, retiros ni reglas de conversión.

begin;

-- =========================================================
-- 1. OPERACIONES PAGADAS IDEMPOTENTES Y SIN RESERVAS QUE EXPIRAN
-- =========================================================

alter table public.tool_operations
    add column if not exists client_request_id uuid;

create unique index if not exists tool_operations_user_request_uidx
on public.tool_operations (user_id, client_request_id)
where client_request_id is not null;

-- Libera cualquier reserva heredada de versiones anteriores antes de cambiar el flujo.
with legacy as (
    select user_id,
           coalesce(sum(reserved_purchased), 0)::bigint as purchased_to_release,
           coalesce(sum(reserved_promo), 0)::bigint as promo_to_release
      from public.tool_operations
     where status = 'reserved'
     group by user_id
)
update public.tool_credit_accounts a
   set reserved_purchased = greatest(a.reserved_purchased - legacy.purchased_to_release, 0),
       reserved_promo = greatest(a.reserved_promo - legacy.promo_to_release, 0),
       updated_at = now()
  from legacy
 where a.user_id = legacy.user_id;

update public.tool_operations
   set status = 'cancelled',
       completed_at = coalesce(completed_at, now()),
       updated_at = now()
 where status = 'reserved';

alter table public.tool_operations
    drop constraint if exists tool_operations_status_check;

alter table public.tool_operations
    add constraint tool_operations_status_check check (
        status in ('reserved', 'charged', 'completed', 'cancelled', 'expired')
    );

-- La nueva función descuenta los créditos al iniciar. De esa forma, si el archivo
-- se genera y luego se pierde Internet, el usuario no recupera automáticamente
-- los créditos. La finalización solo libera los Rewards y es idempotente.
create or replace function public.begin_tool_operation_v2(
    p_tool_code text,
    p_credit_cost bigint,
    p_installation_hash text,
    p_request_id uuid
)
returns table (
    operation_id uuid,
    reserved_credits bigint,
    credit_source text
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_account public.tool_credit_accounts%rowtype;
    v_existing public.tool_operations%rowtype;
    v_available_purchased bigint;
    v_available_promo bigint;
    v_take_purchased bigint;
    v_take_promo bigint;
    v_operation_id uuid;
    v_tool_code text;
    v_expected_cost bigint;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    if p_request_id is null then
        raise exception 'Invalid request identifier';
    end if;

    if p_tool_code is null or length(trim(p_tool_code)) < 3 then
        raise exception 'Invalid tool code';
    end if;

    v_tool_code := lower(trim(p_tool_code));
    v_expected_cost := case v_tool_code
        when 'document_scanner' then 5
        when 'text_to_pdf' then 5
        when 'pdf_watermark_security' then 5
        when 'images_to_pdf' then 5
        when 'pdf_organizer' then 10
        when 'pdf_to_images' then 5
        when 'sign_pdf' then 5
        when 'image_batch_studio' then 5
        when 'compress_image' then 5
        when 'resize_image' then 5
        when 'convert_image' then 5
        when 'crop_rotate_image' then 5
        when 'watermark_image' then 5
        else null
    end;

    if v_expected_cost is null then
        raise exception 'Unsupported paid tool';
    end if;

    if p_credit_cost is null or p_credit_cost <> v_expected_cost then
        raise exception 'Invalid credit cost for tool';
    end if;

    if not exists (
        select 1 from public.profiles
        where user_id = v_user_id and account_status = 'active'
    ) then
        raise exception 'Account is not active';
    end if;

    perform pg_advisory_xact_lock(hashtext(v_user_id::text)::bigint);

    select * into v_existing
      from public.tool_operations
     where user_id = v_user_id
       and client_request_id = p_request_id
     limit 1
     for update;

    if v_existing.id is not null then
        if v_existing.tool_code <> v_tool_code or v_existing.credit_cost <> p_credit_cost then
            raise exception 'Request identifier already used for another operation';
        end if;

        if v_existing.status in ('charged', 'completed') then
            return query select
                v_existing.id,
                v_existing.credit_cost,
                case
                    when v_existing.reserved_purchased = v_existing.credit_cost then 'purchased'
                    when v_existing.reserved_promo = v_existing.credit_cost then 'promo'
                    else 'mixed'
                end;
            return;
        end if;

        raise exception 'Request identifier is no longer reusable';
    end if;

    select * into v_account
      from public.tool_credit_accounts
     where user_id = v_user_id
     for update;

    if v_account.user_id is null then
        insert into public.tool_credit_accounts (user_id)
        values (v_user_id)
        returning * into v_account;
    end if;

    v_available_purchased := v_account.purchased_credits - v_account.reserved_purchased;
    v_available_promo := v_account.promo_credits - v_account.reserved_promo;

    if v_available_purchased + v_available_promo < p_credit_cost then
        raise exception 'Insufficient tool credits';
    end if;

    v_take_purchased := least(v_available_purchased, p_credit_cost);
    v_take_promo := p_credit_cost - v_take_purchased;

    update public.tool_credit_accounts
       set purchased_credits = purchased_credits - v_take_purchased,
           promo_credits = promo_credits - v_take_promo,
           updated_at = now()
     where user_id = v_user_id;

    insert into public.tool_operations (
        user_id,
        tool_code,
        credit_cost,
        reserved_purchased,
        reserved_promo,
        status,
        client_request_id
    ) values (
        v_user_id,
        v_tool_code,
        p_credit_cost,
        v_take_purchased,
        v_take_promo,
        'charged',
        p_request_id
    ) returning id into v_operation_id;

    return query select
        v_operation_id,
        p_credit_cost,
        case
            when v_take_purchased = p_credit_cost then 'purchased'
            when v_take_promo = p_credit_cost then 'promo'
            else 'mixed'
        end;
end;
$$;

-- Compatibilidad con APK anteriores: también cobran de forma segura.
create or replace function public.begin_tool_operation(
    p_tool_code text,
    p_credit_cost bigint,
    p_installation_hash text
)
returns table (
    operation_id uuid,
    reserved_credits bigint,
    credit_source text
)
language sql
security definer
set search_path = ''
as $$
    select *
      from public.begin_tool_operation_v2(
          p_tool_code,
          p_credit_cost,
          p_installation_hash,
          gen_random_uuid()
      );
$$;

create or replace function public.complete_tool_operation(
    p_operation_id uuid,
    p_installation_hash text
)
returns table (
    awarded_points bigint,
    remaining_credits bigint
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_operation public.tool_operations%rowtype;
    v_account public.tool_credit_accounts%rowtype;
    v_combined_progress bigint;
    v_awarded bigint := 0;
    v_remaining bigint := 0;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    select * into v_operation
      from public.tool_operations
     where id = p_operation_id and user_id = v_user_id
     for update;

    if v_operation.id is null then
        raise exception 'Tool operation not found';
    end if;

    if v_operation.status = 'completed' then
        select purchased_credits + promo_credits - reserved_purchased - reserved_promo
          into v_remaining
          from public.tool_credit_accounts
         where user_id = v_user_id;

        return query select v_operation.reward_points_awarded, greatest(coalesce(v_remaining, 0), 0);
        return;
    end if;

    if v_operation.status <> 'charged' then
        raise exception 'Tool operation is not awaiting completion';
    end if;

    select * into v_account
      from public.tool_credit_accounts
     where user_id = v_user_id
     for update;

    v_combined_progress := v_account.reward_progress + v_operation.reserved_purchased;
    v_awarded := (v_combined_progress / 10) * 50;

    update public.tool_credit_accounts
       set purchased_used_total = purchased_used_total + v_operation.reserved_purchased,
           promo_used_total = promo_used_total + v_operation.reserved_promo,
           reward_progress = v_combined_progress % 10,
           updated_at = now()
     where user_id = v_user_id;

    if v_awarded > 0 then
        insert into public.wallets (user_id, internal_points, currency)
        values (v_user_id, v_awarded, 'PEN')
        on conflict (user_id) do update
           set internal_points = public.wallets.internal_points + excluded.internal_points,
               updated_at = now();

        insert into public.ledger_entries (
            user_id,
            entry_type,
            points_delta,
            cash_delta,
            provider,
            external_transaction_id,
            description,
            metadata
        ) values (
            v_user_id,
            'tool_reward',
            v_awarded,
            0,
            'gana_geo_tools',
            p_operation_id::text,
            'Geo Rewards por usar herramientas',
            jsonb_build_object(
                'tool_code', v_operation.tool_code,
                'purchased_credits_used', v_operation.reserved_purchased,
                'promo_credits_used', v_operation.reserved_promo
            )
        ) on conflict (provider, external_transaction_id) do nothing;
    end if;

    update public.tool_operations
       set status = 'completed',
           reward_points_awarded = v_awarded,
           completed_at = now(),
           updated_at = now()
     where id = p_operation_id;

    select purchased_credits + promo_credits - reserved_purchased - reserved_promo
      into v_remaining
      from public.tool_credit_accounts
     where user_id = v_user_id;

    return query select v_awarded, greatest(coalesce(v_remaining, 0), 0);
end;
$$;

create or replace function public.cancel_tool_operation(
    p_operation_id uuid,
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_operation public.tool_operations%rowtype;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    select * into v_operation
      from public.tool_operations
     where id = p_operation_id and user_id = v_user_id
     for update;

    if v_operation.id is null then
        raise exception 'Tool operation not found';
    end if;

    if v_operation.status = 'cancelled' then
        return;
    end if;

    if v_operation.status <> 'charged' then
        raise exception 'This tool operation can no longer be cancelled';
    end if;

    update public.tool_credit_accounts
       set purchased_credits = purchased_credits + v_operation.reserved_purchased,
           promo_credits = promo_credits + v_operation.reserved_promo,
           updated_at = now()
     where user_id = v_user_id;

    update public.tool_operations
       set status = 'cancelled',
           completed_at = now(),
           updated_at = now()
     where id = p_operation_id;
end;
$$;

-- =========================================================
-- 2. GEO AVENTURAS: CUENTAS, VIDAS Y PROGRESO
-- =========================================================

create table if not exists public.geo_game_accounts (
    user_id uuid primary key references auth.users(id) on delete cascade,
    free_lives integer not null default 5 check (free_lives between 0 and 5),
    free_lives_day date not null default current_date,
    free_life_updated_at timestamptz not null default now(),
    unlocked_level integer not null default 1 check (unlocked_level between 1 and 20),
    premium_used_today integer not null default 0 check (premium_used_today >= 0),
    premium_used_day date not null default current_date,
    total_runs bigint not null default 0 check (total_runs >= 0),
    total_wins bigint not null default 0 check (total_wins >= 0),
    best_score bigint not null default 0 check (best_score >= 0),
    updated_at timestamptz not null default now()
);

create table if not exists public.geo_game_premium_lives (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    purchased_credit_cost integer not null default 0 check (purchased_credit_cost between 0 and 2),
    promo_credit_cost integer not null default 0 check (promo_credit_cost between 0 and 2),
    status text not null default 'available' check (status in ('available', 'reserved', 'used')),
    reserved_run_id uuid,
    created_at timestamptz not null default now(),
    reserved_at timestamptz,
    used_at timestamptz,
    check (purchased_credit_cost + promo_credit_cost = 2)
);

create table if not exists public.geo_game_runs (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    level_no integer not null check (level_no between 1 and 20),
    life_type text not null check (life_type in ('free', 'premium')),
    premium_life_id uuid references public.geo_game_premium_lives(id) on delete set null,
    client_request_id uuid,
    status text not null default 'started' check (status in ('started', 'activated', 'won', 'lost', 'abandoned')),
    reward_points_awarded bigint not null default 0 check (reward_points_awarded >= 0),
    stars integer not null default 0 check (stars between 0 and 3),
    score bigint not null default 0 check (score >= 0),
    time_ms bigint,
    started_at timestamptz not null default now(),
    activated_at timestamptz,
    finished_at timestamptz,
    updated_at timestamptz not null default now()
);

create table if not exists public.geo_game_level_progress (
    user_id uuid not null references auth.users(id) on delete cascade,
    level_no integer not null check (level_no between 1 and 20),
    best_stars integer not null default 0 check (best_stars between 0 and 3),
    best_score bigint not null default 0 check (best_score >= 0),
    best_time_ms bigint,
    completed_count bigint not null default 0 check (completed_count >= 0),
    updated_at timestamptz not null default now(),
    primary key (user_id, level_no)
);

create table if not exists public.geo_game_life_purchases (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    client_request_id uuid not null,
    package_code text not null check (package_code in ('life_1', 'life_5', 'life_15')),
    lives_added integer not null check (lives_added > 0),
    credits_spent integer not null check (credits_spent > 0),
    created_at timestamptz not null default now(),
    unique (user_id, client_request_id)
);

-- Compatibilidad si este parche se vuelve a ejecutar sobre una instalación previa.
alter table public.geo_game_runs add column if not exists client_request_id uuid;
create unique index if not exists geo_game_runs_user_request_uidx
on public.geo_game_runs (user_id, client_request_id)
where client_request_id is not null;

create index if not exists geo_game_lives_available_idx
on public.geo_game_premium_lives (user_id, created_at)
where status = 'available';

create index if not exists geo_game_runs_user_idx
on public.geo_game_runs (user_id, started_at desc);

alter table public.geo_game_accounts enable row level security;
alter table public.geo_game_premium_lives enable row level security;
alter table public.geo_game_runs enable row level security;
alter table public.geo_game_level_progress enable row level security;
alter table public.geo_game_life_purchases enable row level security;

revoke all on table public.geo_game_accounts from anon, authenticated;
revoke all on table public.geo_game_premium_lives from anon, authenticated;
revoke all on table public.geo_game_runs from anon, authenticated;
revoke all on table public.geo_game_level_progress from anon, authenticated;
revoke all on table public.geo_game_life_purchases from anon, authenticated;

grant select on table public.geo_game_accounts to authenticated;
grant select on table public.geo_game_premium_lives to authenticated;
grant select on table public.geo_game_runs to authenticated;
grant select on table public.geo_game_level_progress to authenticated;
grant select on table public.geo_game_life_purchases to authenticated;

drop policy if exists "User reads own game account" on public.geo_game_accounts;
create policy "User reads own game account"
on public.geo_game_accounts for select to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "User reads own premium lives" on public.geo_game_premium_lives;
create policy "User reads own premium lives"
on public.geo_game_premium_lives for select to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "User reads own game runs" on public.geo_game_runs;
create policy "User reads own game runs"
on public.geo_game_runs for select to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "User reads own level progress" on public.geo_game_level_progress;
create policy "User reads own level progress"
on public.geo_game_level_progress for select to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "User reads own game purchases" on public.geo_game_life_purchases;
create policy "User reads own game purchases"
on public.geo_game_life_purchases for select to authenticated
using ((select auth.uid()) = user_id);

create or replace function public.refresh_geo_game_state(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_today date := (now() at time zone 'America/Lima')::date;
begin
    insert into public.geo_game_accounts (user_id, free_lives, free_lives_day, free_life_updated_at, premium_used_day)
    values (p_user_id, 5, v_today, now(), v_today)
    on conflict (user_id) do nothing;

    update public.geo_game_accounts
       set free_lives = least(
               5,
               free_lives + floor(extract(epoch from (now() - free_life_updated_at)) / 1800)::integer
           ),
           free_life_updated_at = case
               when free_lives + floor(extract(epoch from (now() - free_life_updated_at)) / 1800)::integer >= 5
                   then now()
               else free_life_updated_at + (
                   floor(extract(epoch from (now() - free_life_updated_at)) / 1800)::integer * interval '30 minutes'
               )
           end,
           free_lives_day = v_today,
           updated_at = now()
     where user_id = p_user_id
       and free_lives < 5
       and now() - free_life_updated_at >= interval '30 minutes';

    update public.geo_game_accounts
       set free_life_updated_at = now(),
           free_lives_day = v_today,
           updated_at = now()
     where user_id = p_user_id
       and free_lives >= 5
       and now() - free_life_updated_at >= interval '30 minutes';

    update public.geo_game_accounts
       set premium_used_today = 0,
           premium_used_day = v_today,
           updated_at = now()
     where user_id = p_user_id
       and premium_used_day <> v_today;

    -- Una vida premium que nunca se activó vuelve a estar disponible.
    update public.geo_game_premium_lives l
       set status = 'available',
           reserved_run_id = null,
           reserved_at = null
     where l.user_id = p_user_id
       and l.status = 'reserved'
       and l.reserved_at < now() - interval '45 minutes';

    update public.geo_game_runs r
       set status = 'abandoned',
           finished_at = now(),
           updated_at = now()
     where r.user_id = p_user_id
       and r.status in ('started', 'activated')
       and r.started_at < now() - interval '45 minutes';
end;
$$;

create or replace function public.get_geo_game_status(p_installation_hash text)
returns table (
    free_lives integer,
    premium_lives bigint,
    unlocked_level integer,
    total_stars bigint,
    best_score bigint,
    premium_used_today integer,
    premium_daily_limit integer,
    next_free_life_in_seconds bigint
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);
    perform public.refresh_geo_game_state(v_user_id);

    return query
    select a.free_lives,
           (select count(*) from public.geo_game_premium_lives l where l.user_id = v_user_id and l.status = 'available'),
           a.unlocked_level,
           coalesce((select sum(p.best_stars) from public.geo_game_level_progress p where p.user_id = v_user_id), 0),
           a.best_score,
           a.premium_used_today,
           10,
           case
               when a.free_lives >= 5 then 0::bigint
               else greatest(0, ceil(extract(epoch from (a.free_life_updated_at + interval '30 minutes' - now()))))::bigint
           end
      from public.geo_game_accounts a
     where a.user_id = v_user_id;
end;
$$;

drop function if exists public.buy_geo_game_lives(text, text);

create or replace function public.buy_geo_game_lives(
    p_package_code text,
    p_installation_hash text,
    p_request_id uuid
)
returns table (
    lives_added integer,
    credits_spent integer,
    remaining_credits bigint,
    premium_lives bigint
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_lives integer;
    v_cost integer;
    v_account public.tool_credit_accounts%rowtype;
    v_existing public.geo_game_life_purchases%rowtype;
    v_available_purchased bigint;
    v_available_promo bigint;
    v_take_purchased bigint;
    v_take_promo bigint;
    v_remaining_purchased bigint;
    v_life_purchased integer;
    v_i integer;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    if p_request_id is null then
        raise exception 'Invalid request identifier';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);
    perform public.refresh_geo_game_state(v_user_id);

    select x.lives, x.cost
      into v_lives, v_cost
      from (values
          ('life_1'::text, 1::integer, 2::integer),
          ('life_5'::text, 5::integer, 10::integer),
          ('life_15'::text, 15::integer, 30::integer)
      ) as x(code, lives, cost)
     where x.code = lower(trim(p_package_code));

    if v_lives is null then
        raise exception 'Unsupported life package';
    end if;

    perform pg_advisory_xact_lock(hashtext(v_user_id::text)::bigint);

    select * into v_existing
      from public.geo_game_life_purchases
     where user_id = v_user_id
       and client_request_id = p_request_id
     limit 1
     for update;

    if v_existing.id is not null then
        if v_existing.package_code <> lower(trim(p_package_code)) then
            raise exception 'Request identifier already used for another purchase';
        end if;
        return query
        select v_existing.lives_added,
               v_existing.credits_spent,
               (a.purchased_credits + a.promo_credits - a.reserved_purchased - a.reserved_promo),
               (select count(*) from public.geo_game_premium_lives l where l.user_id = v_user_id and l.status = 'available')
          from public.tool_credit_accounts a
         where a.user_id = v_user_id;
        return;
    end if;

    select * into v_account
      from public.tool_credit_accounts
     where user_id = v_user_id
     for update;

    if v_account.user_id is null then
        insert into public.tool_credit_accounts (user_id)
        values (v_user_id)
        returning * into v_account;
    end if;

    v_available_purchased := v_account.purchased_credits - v_account.reserved_purchased;
    v_available_promo := v_account.promo_credits - v_account.reserved_promo;

    if v_available_purchased + v_available_promo < v_cost then
        raise exception 'Insufficient tool credits';
    end if;

    v_take_purchased := least(v_available_purchased, v_cost);
    v_take_promo := v_cost - v_take_purchased;

    update public.tool_credit_accounts
       set purchased_credits = purchased_credits - v_take_purchased,
           promo_credits = promo_credits - v_take_promo,
           updated_at = now()
     where user_id = v_user_id;

    v_remaining_purchased := v_take_purchased;
    for v_i in 1..v_lives loop
        v_life_purchased := least(v_remaining_purchased, 2)::integer;
        insert into public.geo_game_premium_lives (
            user_id,
            purchased_credit_cost,
            promo_credit_cost
        ) values (
            v_user_id,
            v_life_purchased,
            2 - v_life_purchased
        );
        v_remaining_purchased := v_remaining_purchased - v_life_purchased;
    end loop;

    insert into public.geo_game_life_purchases (
        user_id, client_request_id, package_code, lives_added, credits_spent
    ) values (
        v_user_id, p_request_id, lower(trim(p_package_code)), v_lives, v_cost
    );

    return query
    select v_lives,
           v_cost,
           (a.purchased_credits + a.promo_credits - a.reserved_purchased - a.reserved_promo),
           (select count(*) from public.geo_game_premium_lives l where l.user_id = v_user_id and l.status = 'available')
      from public.tool_credit_accounts a
     where a.user_id = v_user_id;
end;
$$;

drop function if exists public.start_geo_game_run(integer, text, text);

create or replace function public.start_geo_game_run(
    p_level_no integer,
    p_life_type text,
    p_installation_hash text,
    p_request_id uuid
)
returns table (
    run_id uuid,
    life_type text,
    free_lives_remaining integer,
    premium_lives_remaining bigint,
    needs_activation boolean
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_account public.geo_game_accounts%rowtype;
    v_life public.geo_game_premium_lives%rowtype;
    v_existing public.geo_game_runs%rowtype;
    v_run_id uuid := gen_random_uuid();
    v_type text := lower(trim(p_life_type));
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    if p_request_id is null then
        raise exception 'Invalid request identifier';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);
    perform public.refresh_geo_game_state(v_user_id);
    perform pg_advisory_xact_lock(hashtext(v_user_id::text)::bigint);

    select * into v_existing
      from public.geo_game_runs
     where user_id = v_user_id
       and client_request_id = p_request_id
     limit 1
     for update;

    if v_existing.id is not null then
        if v_existing.level_no <> p_level_no or v_existing.life_type <> v_type then
            raise exception 'Request identifier already used for another run';
        end if;
        return query
        select v_existing.id,
               v_existing.life_type,
               a.free_lives,
               (select count(*) from public.geo_game_premium_lives l where l.user_id = v_user_id and l.status = 'available'),
               (v_existing.life_type = 'premium' and v_existing.status = 'started')
          from public.geo_game_accounts a
         where a.user_id = v_user_id;
        return;
    end if;

    select * into v_account
      from public.geo_game_accounts
     where user_id = v_user_id
     for update;

    if p_level_no is null or p_level_no < 1 or p_level_no > 20 then
        raise exception 'Invalid level';
    end if;

    if p_level_no > v_account.unlocked_level then
        raise exception 'Level is locked';
    end if;

    if exists (
        select 1
          from public.geo_game_runs r
         where r.user_id = v_user_id
           and r.status in ('started', 'activated')
    ) then
        raise exception 'Another game run is active';
    end if;

    if v_type = 'free' then
        if v_account.free_lives <= 0 then
            raise exception 'No free lives available';
        end if;

        update public.geo_game_accounts
           set free_life_updated_at = case when free_lives >= 5 then now() else free_life_updated_at end,
               free_lives = free_lives - 1,
               total_runs = total_runs + 1,
               updated_at = now()
         where user_id = v_user_id;

        insert into public.geo_game_runs (
            id, user_id, level_no, life_type, client_request_id, status, activated_at
        ) values (
            v_run_id, v_user_id, p_level_no, 'free', p_request_id, 'activated', now()
        );
    elsif v_type = 'premium' then
        if v_account.premium_used_today >= 10 then
            raise exception 'Daily premium life limit reached';
        end if;

        select * into v_life
          from public.geo_game_premium_lives
         where user_id = v_user_id
           and status = 'available'
         order by created_at
         limit 1
         for update skip locked;

        if v_life.id is null then
            raise exception 'No premium lives available';
        end if;

        insert into public.geo_game_runs (
            id, user_id, level_no, life_type, premium_life_id, client_request_id, status
        ) values (
            v_run_id, v_user_id, p_level_no, 'premium', v_life.id, p_request_id, 'started'
        );

        update public.geo_game_premium_lives
           set status = 'reserved',
               reserved_run_id = v_run_id,
               reserved_at = now()
         where id = v_life.id;

        update public.geo_game_accounts
           set total_runs = total_runs + 1,
               updated_at = now()
         where user_id = v_user_id;
    else
        raise exception 'Invalid life type';
    end if;

    return query
    select v_run_id,
           v_type,
           a.free_lives,
           (select count(*) from public.geo_game_premium_lives l where l.user_id = v_user_id and l.status = 'available'),
           (v_type = 'premium')
      from public.geo_game_accounts a
     where a.user_id = v_user_id;
end;
$$;

create or replace function public.activate_geo_game_run(
    p_run_id uuid,
    p_installation_hash text
)
returns table (
    awarded_points bigint,
    premium_lives_remaining bigint,
    premium_used_today integer
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_run public.geo_game_runs%rowtype;
    v_life public.geo_game_premium_lives%rowtype;
    v_account public.tool_credit_accounts%rowtype;
    v_game_account public.geo_game_accounts%rowtype;
    v_combined_progress bigint;
    v_awarded bigint := 0;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);
    perform public.refresh_geo_game_state(v_user_id);

    select * into v_run
      from public.geo_game_runs
     where id = p_run_id and user_id = v_user_id
     for update;

    if v_run.id is null then
        raise exception 'Game run not found';
    end if;

    if v_run.status in ('activated', 'won', 'lost') then
        return query
        select v_run.reward_points_awarded,
               (select count(*) from public.geo_game_premium_lives l where l.user_id = v_user_id and l.status = 'available'),
               a.premium_used_today
          from public.geo_game_accounts a
         where a.user_id = v_user_id;
        return;
    end if;

    if v_run.life_type <> 'premium' or v_run.status <> 'started' then
        raise exception 'Game run cannot be activated';
    end if;

    if v_run.started_at > now() - interval '20 seconds' then
        raise exception 'Premium life activation is not ready';
    end if;

    select * into v_life
      from public.geo_game_premium_lives
     where id = v_run.premium_life_id
       and user_id = v_user_id
     for update;

    if v_life.id is null or v_life.status <> 'reserved' or v_life.reserved_run_id <> p_run_id then
        raise exception 'Premium life reservation is invalid';
    end if;

    select * into v_game_account
      from public.geo_game_accounts
     where user_id = v_user_id
     for update;

    if v_game_account.premium_used_today >= 10 then
        raise exception 'Daily premium life limit reached';
    end if;

    select * into v_account
      from public.tool_credit_accounts
     where user_id = v_user_id
     for update;

    v_combined_progress := v_account.reward_progress + v_life.purchased_credit_cost;
    v_awarded := (v_combined_progress / 10) * 50;

    update public.tool_credit_accounts
       set purchased_used_total = purchased_used_total + v_life.purchased_credit_cost,
           promo_used_total = promo_used_total + v_life.promo_credit_cost,
           reward_progress = v_combined_progress % 10,
           updated_at = now()
     where user_id = v_user_id;

    update public.geo_game_premium_lives
       set status = 'used',
           used_at = now()
     where id = v_life.id;

    update public.geo_game_accounts
       set premium_used_today = premium_used_today + 1,
           updated_at = now()
     where user_id = v_user_id;

    if v_awarded > 0 then
        insert into public.wallets (user_id, internal_points, currency)
        values (v_user_id, v_awarded, 'PEN')
        on conflict (user_id) do update
           set internal_points = public.wallets.internal_points + excluded.internal_points,
               updated_at = now();

        insert into public.ledger_entries (
            user_id,
            entry_type,
            points_delta,
            cash_delta,
            provider,
            external_transaction_id,
            description,
            metadata
        ) values (
            v_user_id,
            'game_reward',
            v_awarded,
            0,
            'geo_adventures',
            p_run_id::text,
            'Geo Rewards por usar una vida premium',
            jsonb_build_object(
                'level', v_run.level_no,
                'purchased_credits_used', v_life.purchased_credit_cost,
                'promo_credits_used', v_life.promo_credit_cost
            )
        ) on conflict (provider, external_transaction_id) do nothing;
    end if;

    update public.geo_game_runs
       set status = 'activated',
           reward_points_awarded = v_awarded,
           activated_at = now(),
           updated_at = now()
     where id = p_run_id;

    return query
    select v_awarded,
           (select count(*) from public.geo_game_premium_lives l where l.user_id = v_user_id and l.status = 'available'),
           a.premium_used_today
      from public.geo_game_accounts a
     where a.user_id = v_user_id;
end;
$$;

create or replace function public.finish_geo_game_run(
    p_run_id uuid,
    p_won boolean,
    p_stars integer,
    p_score bigint,
    p_time_ms bigint,
    p_installation_hash text
)
returns table (
    unlocked_level integer,
    total_stars bigint,
    best_score bigint
)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_run public.geo_game_runs%rowtype;
    v_stars integer := case when p_won then greatest(1, least(coalesce(p_stars, 1), 3)) else 0 end;
    v_score bigint := greatest(coalesce(p_score, 0), 0);
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    select * into v_run
      from public.geo_game_runs
     where id = p_run_id and user_id = v_user_id
     for update;

    if v_run.id is null then
        raise exception 'Game run not found';
    end if;

    if v_run.status in ('won', 'lost') then
        return query
        select a.unlocked_level,
               coalesce((select sum(p.best_stars) from public.geo_game_level_progress p where p.user_id = v_user_id), 0),
               a.best_score
          from public.geo_game_accounts a
         where a.user_id = v_user_id;
        return;
    end if;

    if v_run.status <> 'activated' then
        raise exception 'Game run is not active';
    end if;

    update public.geo_game_runs
       set status = case when p_won then 'won' else 'lost' end,
           stars = v_stars,
           score = v_score,
           time_ms = greatest(coalesce(p_time_ms, 0), 0),
           finished_at = now(),
           updated_at = now()
     where id = p_run_id;

    if p_won then
        insert into public.geo_game_level_progress (
            user_id, level_no, best_stars, best_score, best_time_ms, completed_count
        ) values (
            v_user_id, v_run.level_no, v_stars, v_score, greatest(coalesce(p_time_ms, 0), 0), 1
        ) on conflict (user_id, level_no) do update
           set best_stars = greatest(public.geo_game_level_progress.best_stars, excluded.best_stars),
               best_score = greatest(public.geo_game_level_progress.best_score, excluded.best_score),
               best_time_ms = case
                   when public.geo_game_level_progress.best_time_ms is null then excluded.best_time_ms
                   else least(public.geo_game_level_progress.best_time_ms, excluded.best_time_ms)
               end,
               completed_count = public.geo_game_level_progress.completed_count + 1,
               updated_at = now();

        update public.geo_game_accounts
           set unlocked_level = greatest(unlocked_level, least(v_run.level_no + 1, 20)),
               total_wins = total_wins + 1,
               best_score = greatest(best_score, v_score),
               updated_at = now()
         where user_id = v_user_id;
    else
        update public.geo_game_accounts
           set best_score = greatest(best_score, v_score),
               updated_at = now()
         where user_id = v_user_id;
    end if;

    return query
    select a.unlocked_level,
           coalesce((select sum(p.best_stars) from public.geo_game_level_progress p where p.user_id = v_user_id), 0),
           a.best_score
      from public.geo_game_accounts a
     where a.user_id = v_user_id;
end;
$$;

create or replace function public.cancel_geo_game_run(
    p_run_id uuid,
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_run public.geo_game_runs%rowtype;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    select * into v_run
      from public.geo_game_runs
     where id = p_run_id and user_id = v_user_id
     for update;

    if v_run.id is null or v_run.status = 'abandoned' then
        return;
    end if;

    if v_run.status <> 'started' then
        raise exception 'Activated runs cannot return a life';
    end if;

    if v_run.started_at < now() - interval '30 seconds' then
        raise exception 'The life can no longer be returned';
    end if;

    if v_run.life_type = 'premium' and v_run.premium_life_id is not null then
        update public.geo_game_premium_lives
           set status = 'available',
               reserved_run_id = null,
               reserved_at = null
         where id = v_run.premium_life_id
           and status = 'reserved'
           and reserved_run_id = p_run_id;
    end if;

    update public.geo_game_runs
       set status = 'abandoned',
           finished_at = now(),
           updated_at = now()
     where id = p_run_id;
end;
$$;

-- =========================================================
-- 3. PERMISOS
-- =========================================================

revoke all on function public.begin_tool_operation_v2(text, bigint, text, uuid)
from public, anon;
grant execute on function public.begin_tool_operation_v2(text, bigint, text, uuid)
to authenticated;

revoke all on function public.begin_tool_operation(text, bigint, text)
from public, anon;
grant execute on function public.begin_tool_operation(text, bigint, text)
to authenticated;

revoke all on function public.complete_tool_operation(uuid, text)
from public, anon;
grant execute on function public.complete_tool_operation(uuid, text)
to authenticated;

revoke all on function public.cancel_tool_operation(uuid, text)
from public, anon;
grant execute on function public.cancel_tool_operation(uuid, text)
to authenticated;

revoke all on function public.refresh_geo_game_state(uuid)
from public, anon, authenticated;

revoke all on function public.get_geo_game_status(text)
from public, anon;
grant execute on function public.get_geo_game_status(text)
to authenticated;

revoke all on function public.buy_geo_game_lives(text, text, uuid)
from public, anon;
grant execute on function public.buy_geo_game_lives(text, text, uuid)
to authenticated;

revoke all on function public.start_geo_game_run(integer, text, text, uuid)
from public, anon;
grant execute on function public.start_geo_game_run(integer, text, text, uuid)
to authenticated;

revoke all on function public.activate_geo_game_run(uuid, text)
from public, anon;
grant execute on function public.activate_geo_game_run(uuid, text)
to authenticated;

revoke all on function public.finish_geo_game_run(uuid, boolean, integer, bigint, bigint, text)
from public, anon;
grant execute on function public.finish_geo_game_run(uuid, boolean, integer, bigint, bigint, text)
to authenticated;

revoke all on function public.cancel_geo_game_run(uuid, text)
from public, anon;
grant execute on function public.cancel_geo_game_run(uuid, text)
to authenticated;

commit;
notify pgrst, 'reload schema';
