# Pruebas obligatorias — Login V8

## Preparación

1. Ejecutar `supabase/04_native_login_device_replacement.sql`.
2. Configurar `SUPABASE_ANON_KEY` y `GOOGLE_WEB_CLIENT_ID` en GitHub.
3. Ejecutar Actions una vez y copiar la SHA-1 mostrada en **Preparar firma Debug estable**.
4. Registrar en Google el paquete `com.ganageo.app` y esa SHA-1; después volver a compilar.

## Casos mínimos

1. **Primer acceso:** el botón abre el selector nativo de Google; no debe abrir Chrome.
2. **Cuenta existente, misma instalación:** entra directamente al panel.
3. **Reinstalación:** después de entrar con la misma cuenta debe aparecer la pantalla de conflicto y el botón de reemplazo.
4. **Reemplazo confirmado:** entra al panel y la fila anterior en `devices` queda `replaced`.
5. **Instalación anterior:** al intentar retirar o usar una herramienta pagada debe recibir “This installation is not active”.
6. **Otra cuenta en la misma instalación activa:** debe bloquearse y no ofrecer robo automático del vínculo.
7. **Cerrar sesión:** al volver a entrar debe permitir elegir otra cuenta.
8. **Sin red:** la carga debe terminar con error visible; no debe quedar girando indefinidamente.
9. **SQL no actualizado:** el panel debe bloquearse y pedir ejecutar la migración, no cargar datos ignorando el control.

## Verificación de Supabase

```sql
select user_id, installation_hash, device_status, first_seen_at, last_seen_at
from public.devices
order by last_seen_at desc;
```

Debe existir como máximo una fila `active` por usuario y una fila `active` por `installation_hash`.
