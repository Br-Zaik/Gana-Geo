# Antes de publicar Gana Geo

## Acceso y configuración

- [ ] Crear en Google un cliente OAuth de tipo Web y colocar su Client ID en `GOOGLE_WEB_CLIENT_ID`.
- [ ] Configurar ese mismo Client ID Web en el proveedor Google de Supabase.
- [ ] Crear un cliente OAuth de tipo Android para `com.ganageo.app`.
- [ ] Registrar la SHA-1 real de la clave que firma el APK/AAB de publicación.
- [ ] Confirmar que el APK abre el selector nativo de cuentas y no Chrome.
- [ ] Probar cerrar sesión y entrar con otra cuenta.

## Base de datos y dispositivo

- [ ] Ejecutar `supabase/04_native_login_device_replacement.sql` en el proyecto existente.
- [ ] Probar una instalación nueva sin vínculo previo.
- [ ] Probar reinstalación: debe mostrar “Reemplazar instalación anterior”.
- [ ] Confirmar que la instalación reemplazada ya no puede retirar ni usar herramientas pagadas.
- [ ] Confirmar que una instalación activa de otra cuenta no puede ser tomada.

## Dinero y créditos

- [ ] Mantener `service_role` exclusivamente en backend.
- [ ] Verificar compras reales con Google Play Developer API.
- [ ] No acreditar créditos ni Rewards basándose solo en datos del teléfono.
- [ ] Definir proceso de revisión, pago, rechazo y auditoría de retiros.

## Privacidad y publicación

- [ ] Política de privacidad y términos disponibles públicamente.
- [ ] Canal de soporte y procedimiento para recuperar cuentas.
- [ ] Revisar permisos declarados en AndroidManifest.
- [ ] Confirmar que los archivos procesados permanecen en el dispositivo.
- [ ] Ejecutar pruebas cerradas de Google Play antes de producción.
