# Pruebas manuales — Gana Geo v8.4

## Antes de probar

1. Compila desde GitHub Actions.
2. Confirma que `testDebugUnitTest` y `assembleDebug` estén en verde.
3. Instala el APK sobre la versión actual para conservar la instalación.
4. Usa créditos de prueba únicamente en la compilación Debug.

## Acceso protegido

- Inicia sesión con la cuenta actual.
- Cierra y vuelve a abrir la app.
- Reinstala solo si deseas verificar “Reemplazar instalación anterior”.
- Confirma que Inicio, Billetera y Perfil se vean igual que antes.

## Imágenes a PDF

- Selecciona 1, 4 y 20 imágenes.
- Toma una foto con cámara y acepta/rechaza el permiso.
- Cambia orden, gira y elimina páginas.
- Prueba Original, Documento, Gris y Mejorar color.
- Prueba A4 vertical, Carta horizontal y tamaño automático.
- Prueba cada compresión.
- Crea un PDF sin contraseña y otro con contraseña.
- Abre el resultado en un lector PDF.
- Verifica que se descuenten exactamente 5 créditos una sola vez.

## Organizar PDF

- Une dos PDF y cambia el orden.
- Reordena páginas con `3,1,2`.
- Extrae `1-3,7`.
- Elimina una página y confirma que no permita eliminar todas.
- Gira una página y luego todas.
- Invierte el orden.
- Divide con `1-3;4-6;7-9`.
- Comprime en cada nivel y compara tamaño/calidad.
- Verifica descuento de 10 créditos una sola vez.

## PDF a imágenes

- Exporta todas las páginas como JPG.
- Exporta páginas `1-2,4` como PNG.
- Prueba las tres resoluciones y diferentes calidades JPG.
- Verifica nombres y numeración en la carpeta elegida.
- Verifica descuento de 5 créditos.

## Firmar PDF

- Dibuja, limpia y vuelve a dibujar una firma.
- Prueba página 1 y otra página.
- Prueba esquina inferior derecha, centro y parte superior.
- Cambia tamaño y agrega texto opcional.
- Abre el PDF final y verifica descuento de 5 créditos.

## Imágenes

- Comprime y compara el peso.
- Redimensiona a 50 %, HD y tamaño personalizado.
- Convierte JPG a PNG y WebP.
- Prueba todas las proporciones, giros y volteos.
- Prueba filtros, brillo y contraste.
- Prueba marca de agua normal y repetida.
- Verifica vista Original/Resultado y descuento de 5 créditos.

## Matemática gratuita

- Calculadora: `sin(30)+sqrt(16)` debe dar `4.5` en grados.
- Prueba división entre cero y expresión incompleta.
- Geometría: cuadrado lado 5 debe dar área 25 y perímetro 20.
- Cono radio 3, altura 4 debe mostrar volumen y área total.
- Confirma que ninguna herramienta matemática descuente créditos ni entregue Rewards.

## Casos de error

- Cancela un selector de archivo.
- Intenta usar una herramienta con créditos insuficientes.
- Selecciona un PDF dañado o con contraseña.
- Escribe páginas inexistentes.
- Escribe dimensiones mayores a 8192 px.
- Sal de la herramienta antes de exportar: no debe descontar créditos.
