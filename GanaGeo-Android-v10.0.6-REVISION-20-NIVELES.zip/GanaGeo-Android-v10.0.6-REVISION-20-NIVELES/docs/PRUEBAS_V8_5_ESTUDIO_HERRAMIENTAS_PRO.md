# Pruebas recomendadas — Gana Geo v8.5

## Antes de instalar

1. Ejecutar GitHub Actions.
2. Confirmar que `testDebugUnitTest` y `assembleDebug` estén en verde.
3. Confirmar que la SHA-1 del APK coincide con la firma Debug estable.

## Acceso protegido

- Iniciar con la cuenta usada en v8.4.
- Cerrar y volver a abrir sin perder sesión.
- Reinstalar en una prueba controlada y usar **Reemplazar instalación anterior**.
- Confirmar que no se pidió ningún SQL nuevo.

## PDF e imágenes

- Escanear 1, 5 y 20 páginas.
- Probar cámara y galería, giro, orden, filtros y contraseña.
- Crear PDF desde texto largo y revisar salto de páginas.
- Agregar marca de agua y numeración a páginas seleccionadas.
- Probar PDF protegido con contraseña correcta e incorrecta.
- Procesar un lote JPG/PNG, collage, foto carnet, EXIF y ZIP.
- Cancelar el selector de archivos o carpeta y confirmar que no se descuentan créditos.
- Provocar un error antes de guardar y confirmar que se muestra un mensaje claro.

## Matemática y ciencia

- Matriz 2×2 y 3×3, inversa no existente y sistema sin solución única.
- Gráficas con una y cuatro funciones; exportar PNG.
- Derivada e integral de `3x^2-4x+7`.
- Buscar elementos 1, 26, 79 y 118.
- Molaridad, dilución, gas ideal y configuración electrónica.

## Estudio

- Crear, renombrar, exportar e importar bancos de exámenes y flashcards.
- Cerrar la app a mitad de un examen y continuar.
- Probar temporizador y revisión final.
- Registrar horario, meta, asistencia, Pomodoro y recordatorio.
- Comprobar que los datos locales persisten al cerrar la app.

## Créditos y reglas protegidas

- Las herramientas gratuitas no descuentan créditos.
- Cada herramienta con créditos conserva el costo anterior.
- No se alteraron Rewards, referidos, retiro mínimo ni billetera.
