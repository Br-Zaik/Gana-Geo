# Cómo probar Herramientas Geo V7

## 1. Base de datos

En Supabase SQL Editor ejecuta, en este orden:

```text
supabase/02_secure_app_functions.sql
supabase/03_tool_credits.sql
```

El tercer archivo crea las cuentas de créditos, las reservas de operaciones y la acreditación segura de Rewards.

## 2. Compilación de prueba

Sube el proyecto al repositorio y ejecuta:

```text
Actions → Compilar Gana Geo → Run workflow
```

Descarga el artefacto `Gana-Geo-v7-Herramientas` e instala `app-debug.apk` desde la prueba interna de Google Play cuando esté configurada.

## 3. Créditos simulados

En la compilación debug:

1. Inicia sesión normalmente con Google.
2. Abre la pestaña central **Herramientas**.
3. Pulsa `Pack Geo 50` o `Pack Geo 100`.
4. Se agregan créditos de prueba locales; no hay cobro.
5. Usa las herramientas con candado para comprobar los descuentos.
6. Cada 10 créditos de prueba consumidos generan 50 Rewards de prueba.

Los saldos de prueba aparecen separados de los créditos y Rewards reales y nunca habilitan un retiro real.

## 4. Pruebas mínimas

- Calculadora: `sin(30)+sqrt(16)` debe dar `4.5` en grados.
- Conversor: `1 km` debe dar `1000 m`.
- Imágenes a PDF: crear un PDF con 2 o más imágenes.
- Organizador: unir 2 PDF y reordenar páginas de un PDF.
- PDF a imágenes: exportar páginas a una carpeta elegida.
- Firma: dibujar, elegir página y guardar una copia firmada.
- Imagen: probar compresión, tamaño, formato, recorte y marca de agua.
- QR: crear, guardar, leer desde imagen y escanear con cámara.
- Confirmar que cancelar un selector no descuente créditos.
- Confirmar que un archivo fallido no descuente créditos.

## 5. Compra real

La V7 no finge compras reales. En release, los packs no conceden créditos hasta completar:

- productos consumibles `pack_geo_50` y `pack_geo_100` en Play Console;
- Google Play Billing;
- verificación del token en un backend;
- llamada del backend a `grant_verified_tool_pack` con `service_role`.

Nunca coloques `service_role` ni credenciales privadas dentro del APK.

## Inicio de sesión

Las herramientas permanecen separadas del acceso. En V8, Google usa Credential Manager nativo y ya no depende del retorno `ganageo://login-callback`.
