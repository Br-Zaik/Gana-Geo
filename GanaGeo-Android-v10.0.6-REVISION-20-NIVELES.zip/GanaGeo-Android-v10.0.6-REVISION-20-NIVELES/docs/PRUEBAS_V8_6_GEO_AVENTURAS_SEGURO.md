# Pruebas v8.6 — Geo Aventuras Seguro

## Orden obligatorio

1. Ejecutar `supabase/06_paid_tools_geo_adventures.sql`.
2. Compilar el APK con GitHub Actions.
3. Instalar el APK v8.6.

## Herramientas pagadas

Probar con créditos de servidor:

- Escáner de documentos: 5.
- Texto a PDF: 5.
- Marca, numera y protege PDF: 5.
- Imágenes por lote: 5.
- Imágenes a PDF: 5.
- Organizar PDF: 10.
- PDF a imágenes: 5.
- Firmar PDF: 5.
- Cinco herramientas individuales de imagen: 5 cada una.

Para cada herramienta:

1. Confirmar el descuento exacto al comenzar.
2. Generar y abrir el archivo.
3. Confirmar que el uso comprado suma al progreso de Rewards.
4. Repetir una confirmación y verificar que no duplica Rewards.
5. Provocar un fallo antes de guardar y comprobar la devolución.
6. Desactivar Internet después de guardar y confirmar que los créditos no regresan;
   al volver a Herramientas con conexión deben confirmarse los Rewards pendientes.

## Geo Aventuras

### Vidas rojas

- Una cuenta nueva debe mostrar 3 vidas rojas.
- Iniciar una partida debe dejar 2.
- Ganar y perder no deben crear Rewards.
- Al cambiar de día en el servidor deben volver a 3, sin acumular más.

### Vidas amarillas

- Comprar 1 debe costar 2 créditos.
- Comprar 5 debe costar 10.
- Comprar 15 debe costar 30.
- La compra no debe entregar Rewards inmediatamente.
- Salir antes de 20 segundos debe devolver la vida amarilla.
- Jugar 20 segundos debe consumirla y sumar solo la parte de créditos comprados.
- Ganar o perder debe producir la misma recompensa fija.
- Después de 10 vidas amarillas utilizadas, el servidor debe impedir otra ese día.
- Repetir una petición de compra o inicio con el mismo request ID no debe duplicar el cobro ni la vida.

### Niveles

- Los niveles 1–20 deben abrirse en secuencia.
- Cada nivel debe tener 3 cristales y un portal.
- Caer, tocar un peligro, tocar un enemigo o agotar el tiempo debe terminar la partida.
- Llegar al portal debe desbloquear el siguiente nivel.
- Estrellas: una por terminar, otra por recoger los 3 cristales y otra por tiempo objetivo.

## Acceso y datos protegidos

- Iniciar con Google.
- Cerrar y volver a abrir la app.
- Reinstalar y usar “Reemplazar instalación anterior”.
- Consultar billetera y retiros.
- Confirmar que no se alteraron referidos ni retiro mínimo.

## Compilación

GitHub Actions debe completar en verde:

```text
:app:testDebugUnitTest
:app:assembleDebug
```

La compilación en verde es obligatoria antes de instalar la nueva versión en otros teléfonos.
