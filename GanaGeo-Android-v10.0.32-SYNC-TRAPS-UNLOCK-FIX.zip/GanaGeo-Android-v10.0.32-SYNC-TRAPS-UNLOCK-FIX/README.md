# Gana Geo Android v0.10.32

Version enfocada en corregir el **multijugador local de Geo Aventuras** sobre la v0.10.31, sin cambiar la jugabilidad base de los 20 niveles y sin tocar login, Google, Supabase ni sesion.

## Inicio sincronizado de partida

- El boton **INICIAR PARTIDA** ya no depende de cambiar el color/skin para que el otro telefono reciba el inicio.
- El host cambia la sala a `preparing` y todos los dispositivos precargan el mismo nivel.
- Cada dispositivo responde `MATCH_READY` cuando termino de cargar.
- Solo cuando todos los jugadores conectados estan listos, el host envia el estado `playing` y luego entra localmente al juego.
- El envio de sala/partida se realiza en el scope de red (`Dispatchers.IO`).

## Trampas compartidas y rearmables

- El host es la autoridad del estado compartido de las trampas.
- Si un jugador activa una plataforma, pincho oculto, planta, launcher, crusher, roca/bola, agujero perseguidor o caja explosiva, el estado se propaga a los demas jugadores.
- El rearmado ocurre en el host y espera a que **todos los GEO vivos** hayan salido de la zona de la trampa.
- Las trampas transitorias completan su ciclo, cooldown y vuelven a quedar armadas para los jugadores que vienen detras.
- Se agrego una ventana de aceptacion de solicitudes remotas para evitar que un cliente con estado atrasado vuelva a activar una trampa que el host ya rearmo.
- Agujeros perseguidores incluyen edad/epoch de activacion para distinguir una activacion nueva de una copia vieja.
- Enemigos y objetos perseguidores usan como objetivo al GEO vivo mas cercano en multijugador, evitando que el host adelantado congele la amenaza del jugador que viene atras.
- Llaves, interruptores y progreso permanente siguen siendo compartidos y no se reinician como trampas transitorias.

## Desbloqueo al ganar

- Completar el nivel `N` conserva/desbloquea `N` y desbloquea tambien `N+1` para todos los participantes locales.
- Si cualquier jugador vivo llega a la salida, la sala completa recibe victoria.
- El host difunde el resultado, todos regresan a la misma sala y el siguiente nivel queda disponible donde corresponda.
- Nivel 20 no intenta crear un nivel 21.

## Trafico LAN

- El host envia snapshots de juego en una cadencia fija de ~70 ms en vez de difundir la sala completa cada vez que recibe una posicion.
- Los clientes reciben el `worldState` autoritativo del host; los payloads transitorios de otros clientes no se reenvian a todos.
- El beacon UDP de descubrimiento solo se anuncia mientras la sala esta en lobby.

## Validacion realizada

- Contrato estatico de multijugador: **17/17 PASS**.
- Codec compacto de trampas compartidas `g2`: **PASS**.
- Construccion de niveles y reglas/runtime puras: **44 checks PASS**.
- Typecheck Kotlin aislado de `GeoLocalMultiplayerService`: **PASS**.
- Typecheck Kotlin aislado de `GeoMultiplayerSession`: **PASS**.
- El intento de `:app:compileDebugKotlin` no pudo comenzar porque este entorno no puede resolver `services.gradle.org` para descargar Gradle 8.13. La compilacion Android completa debe confirmarse en GitHub Actions.

## Proteccion

No se modifican login, Google, Supabase, sesion, persistencia, creditos, Geo Rewards, referidos ni retiros. Los archivos protegidos se verifican por SHA-256 antes de empaquetar.
