# Lista obligatoria antes de publicar

- [ ] Probar el login con al menos dos cuentas autorizadas.
- [ ] Confirmar que `ganageo://login-callback` está en Redirect URLs de Supabase.
- [ ] Ejecutar `supabase/02_secure_app_functions.sql`.
- [ ] Confirmar que ningún archivo contiene `service_role` o Client Secret de Google.
- [ ] Crear clave de firma release y guardar copias seguras.
- [ ] Crear OAuth Android con `com.ganageo.app` y SHA-1 release.
- [ ] Contratar proveedores reales antes de activar encuestas, ofertas o anuncios.
- [ ] Crear panel administrativo para verificar y pagar retiros.
- [ ] Publicar política de privacidad y términos reales.
- [ ] Realizar pruebas antifraude y límites de retiros. El UUID local no sustituye una solución antifraude profesional.
- [ ] Revisar impuestos y obligaciones aplicables antes de pagar recompensas.
