package com.ganageo.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ganageo.app.data.DeviceIdentityStore
import com.ganageo.app.data.GanaGeoRepository
import com.ganageo.app.data.SupabaseProvider
import com.ganageo.app.model.DashboardData
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.status.SessionStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface AuthPhase {
    data object ConfigurationMissing : AuthPhase
    data object Initializing : AuthPhase
    data object CompletingSignIn : AuthPhase
    data object SignedOut : AuthPhase
    data object SignedIn : AuthPhase
}

data class GanaGeoUiState(
    val authPhase: AuthPhase = AuthPhase.Initializing,
    val dashboard: DashboardData? = null,
    val isLoading: Boolean = false,
    val message: String? = null,
    val error: String? = null
)

class GanaGeoViewModel(application: Application) : AndroidViewModel(application) {
    private val client = SupabaseProvider.client
    private val repository = client?.let(::GanaGeoRepository)
    private val deviceStore = DeviceIdentityStore(application)

    private var authCallbackTimeoutJob: Job? = null
    private var dashboardJob: Job? = null
    private var loadedDashboardUserId: String? = null

    private val _uiState = MutableStateFlow(
        GanaGeoUiState(
            authPhase = if (SupabaseProvider.isConfigured) {
                AuthPhase.Initializing
            } else {
                AuthPhase.ConfigurationMissing
            }
        )
    )
    val uiState: StateFlow<GanaGeoUiState> = _uiState.asStateFlow()

    init {
        if (client != null && repository != null) {
            viewModelScope.launch {
                client.auth.sessionStatus.collect { status ->
                    when (status) {
                        SessionStatus.Initializing -> {
                            if (_uiState.value.authPhase != AuthPhase.CompletingSignIn) {
                                _uiState.update { it.copy(authPhase = AuthPhase.Initializing) }
                            }
                        }

                        is SessionStatus.Authenticated -> {
                            authCallbackTimeoutJob?.cancel()
                            markAuthenticatedAndLoad()
                        }

                        is SessionStatus.NotAuthenticated -> {
                            val state = _uiState.value
                            val shouldPreserveCallbackError =
                                state.authPhase == AuthPhase.SignedOut && !state.error.isNullOrBlank()

                            if (state.authPhase != AuthPhase.CompletingSignIn && !shouldPreserveCallbackError) {
                                resetToSignedOut()
                            }
                        }

                        is SessionStatus.RefreshFailure -> {
                            authCallbackTimeoutJob?.cancel()
                            loadedDashboardUserId = null
                            _uiState.update {
                                it.copy(
                                    authPhase = AuthPhase.SignedOut,
                                    dashboard = null,
                                    isLoading = false,
                                    error = "La sesión venció. Inicia sesión nuevamente."
                                )
                            }
                        }

                        else -> Unit
                    }
                }
            }
        }
    }

    fun signInWithGoogle() {
        val repo = repository ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching { repo.signInWithGoogle() }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = error.userMessage("No se pudo abrir el inicio de sesión con Google.")
                        )
                    }
                }
                .onSuccess {
                    _uiState.update { it.copy(isLoading = false) }
                }
        }
    }

    fun onAuthCallbackStarted() {
        authCallbackTimeoutJob?.cancel()
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.CompletingSignIn,
                isLoading = true,
                error = null,
                message = null
            )
        }

        authCallbackTimeoutJob = viewModelScope.launch {
            delay(AUTH_CALLBACK_TIMEOUT_MS)
            if (_uiState.value.authPhase == AuthPhase.CompletingSignIn) {
                val sessionExists = client?.auth?.currentSessionOrNull() != null
                if (sessionExists) {
                    markAuthenticatedAndLoad()
                } else {
                    _uiState.update {
                        it.copy(
                            authPhase = AuthPhase.SignedOut,
                            isLoading = false,
                            error = "Google regresó a Gana Geo, pero Supabase no terminó de crear la sesión. Vuelve a intentar el acceso."
                        )
                    }
                }
            }
        }
    }

    fun onAuthCallbackSuccess() {
        authCallbackTimeoutJob?.cancel()
        viewModelScope.launch {
            val sessionFound = waitForSession()
            if (sessionFound) {
                markAuthenticatedAndLoad()
            } else {
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedOut,
                        isLoading = false,
                        error = "Supabase indicó que el acceso terminó, pero no guardó una sesión válida. Intenta iniciar sesión nuevamente."
                    )
                }
            }
        }
    }

    fun onAuthCallbackError(error: Throwable) {
        authCallbackTimeoutJob?.cancel()
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.SignedOut,
                dashboard = null,
                isLoading = false,
                error = error.authCallbackMessage()
            )
        }
    }

    fun reconcileSession() {
        if (client == null || _uiState.value.authPhase == AuthPhase.ConfigurationMissing) return

        viewModelScope.launch {
            if (client.auth.currentSessionOrNull() != null) {
                authCallbackTimeoutJob?.cancel()
                markAuthenticatedAndLoad()
            }
        }
    }

    fun refreshDashboard() {
        val repo = repository ?: return
        dashboardJob?.cancel()
        dashboardJob = viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.loadDashboard(installationId)
            }.onSuccess { dashboard ->
                loadedDashboardUserId = repo.currentUserId()
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedIn,
                        dashboard = dashboard,
                        isLoading = false,
                        error = null
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedIn,
                        isLoading = false,
                        error = error.userMessage("No se pudieron cargar tus datos.")
                    )
                }
            }
        }
    }

    fun requestWithdrawal(amountText: String, method: String, destination: String) {
        val repo = repository ?: return
        val amount = amountText.replace(',', '.').toDoubleOrNull()
        val available = _uiState.value.dashboard?.wallet?.availableAmount ?: 0.0

        when {
            amount == null || amount <= 0.0 -> {
                _uiState.update { it.copy(error = "Escribe un monto válido.") }
                return
            }

            amount > available -> {
                _uiState.update { it.copy(error = "No tienes saldo disponible suficiente.") }
                return
            }

            destination.trim().length < 5 -> {
                _uiState.update { it.copy(error = "Escribe un número o correo válido para el pago.") }
                return
            }
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching {
                repo.requestWithdrawal(amount, method, destination)
            }.onSuccess {
                _uiState.update {
                    it.copy(
                        message = "Solicitud registrada. El saldo quedó bloqueado hasta su revisión.",
                        isLoading = false
                    )
                }
                refreshDashboard()
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = error.userMessage(
                            "No se pudo registrar el retiro. Ejecuta primero el SQL seguro incluido en el repositorio."
                        )
                    )
                }
            }
        }
    }

    fun cancelWithdrawal(withdrawalId: String) {
        val repo = repository ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching { repo.cancelWithdrawal(withdrawalId) }
                .onSuccess {
                    _uiState.update {
                        it.copy(message = "Solicitud cancelada y saldo liberado.", isLoading = false)
                    }
                    refreshDashboard()
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = error.userMessage("No se pudo cancelar la solicitud.")
                        )
                    }
                }
        }
    }

    fun signOut() {
        val repo = repository ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching { repo.signOut() }
                .onSuccess {
                    loadedDashboardUserId = null
                    dashboardJob?.cancel()
                    resetToSignedOut()
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = error.userMessage("No se pudo cerrar la sesión.")
                        )
                    }
                }
        }
    }

    fun clearNotice() {
        _uiState.update { it.copy(message = null, error = null) }
    }

    private fun markAuthenticatedAndLoad() {
        val userId = repository?.currentUserId()
        if (userId.isNullOrBlank()) {
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.CompletingSignIn,
                    isLoading = true
                )
            }
            return
        }

        val shouldLoadDashboard = loadedDashboardUserId != userId || _uiState.value.dashboard == null
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.SignedIn,
                isLoading = shouldLoadDashboard,
                error = null
            )
        }

        if (shouldLoadDashboard) {
            refreshDashboard()
        }
    }

    private suspend fun waitForSession(): Boolean {
        repeat(SESSION_WAIT_ATTEMPTS) {
            if (client?.auth?.currentSessionOrNull() != null) return true
            delay(SESSION_WAIT_DELAY_MS)
        }
        return false
    }

    private fun resetToSignedOut() {
        loadedDashboardUserId = null
        dashboardJob?.cancel()
        _uiState.value = GanaGeoUiState(authPhase = AuthPhase.SignedOut)
    }

    private fun Throwable.authCallbackMessage(): String {
        val raw = message.orEmpty()
        return when {
            raw.contains("flow_state_not_found", ignoreCase = true) ->
                "El intento de acceso venció o ya fue utilizado. Pulsa nuevamente Continuar con Google."

            raw.contains("code verifier", ignoreCase = true) ||
                raw.contains("verifier", ignoreCase = true) ->
                "No se pudo validar el acceso seguro de Google. Cierra la app, ábrela otra vez e inténtalo nuevamente."

            raw.contains("access_denied", ignoreCase = true) ->
                "Cancelaste el acceso con Google o la cuenta no tiene permiso para entrar."

            raw.isNotBlank() ->
                "Google regresó a Gana Geo, pero Supabase rechazó la sesión: ${raw.take(220)}"

            else ->
                "Google regresó a Gana Geo, pero no se pudo terminar el inicio de sesión."
        }
    }

    private fun Throwable.userMessage(fallback: String): String {
        val raw = message.orEmpty()
        return when {
            raw.contains("device", ignoreCase = true) && raw.contains("active", ignoreCase = true) ->
                "Esta cuenta o este dispositivo ya está vinculado a otra instalación."
            raw.contains("account is not active", ignoreCase = true) ->
                "Tu cuenta no está activa. Comunícate con soporte antes de continuar."
            raw.contains("insufficient", ignoreCase = true) ->
                "No tienes saldo disponible suficiente."
            raw.contains("function", ignoreCase = true) && raw.contains("not", ignoreCase = true) ->
                "$fallback Función de servidor no encontrada."
            raw.isNotBlank() -> "$fallback ${raw.take(180)}"
            else -> fallback
        }
    }

    private companion object {
        const val AUTH_CALLBACK_TIMEOUT_MS = 20_000L
        const val SESSION_WAIT_ATTEMPTS = 20
        const val SESSION_WAIT_DELAY_MS = 150L
    }
}
