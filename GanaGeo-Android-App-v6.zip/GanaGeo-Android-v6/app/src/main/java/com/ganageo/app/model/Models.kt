package com.ganageo.app.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Profile(
    @SerialName("user_id") val userId: String,
    @SerialName("geo_id") val geoId: Long,
    @SerialName("display_name") val displayName: String? = null,
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("country_code") val countryCode: String = "PE",
    @SerialName("account_status") val accountStatus: String = "active",
    @SerialName("created_at") val createdAt: String? = null
)

@Serializable
data class Wallet(
    @SerialName("user_id") val userId: String,
    @SerialName("internal_points") val internalPoints: Long = 0,
    @SerialName("pending_amount") val pendingAmount: Double = 0.0,
    @SerialName("available_amount") val availableAmount: Double = 0.0,
    @SerialName("locked_amount") val lockedAmount: Double = 0.0,
    val currency: String = "PEN"
)

@Serializable
data class LedgerEntry(
    val id: Long,
    @SerialName("entry_type") val entryType: String,
    @SerialName("points_delta") val pointsDelta: Long = 0,
    @SerialName("cash_delta") val cashDelta: Double = 0.0,
    @SerialName("cash_bucket") val cashBucket: String? = null,
    val currency: String? = null,
    val provider: String? = null,
    val description: String? = null,
    @SerialName("created_at") val createdAt: String? = null
)

@Serializable
data class Withdrawal(
    val id: String,
    val amount: Double,
    val currency: String,
    @SerialName("payment_method") val paymentMethod: String,
    @SerialName("payment_destination") val paymentDestination: String,
    val status: String,
    @SerialName("requested_at") val requestedAt: String? = null,
    @SerialName("rejection_reason") val rejectionReason: String? = null
)

data class DashboardData(
    val profile: Profile,
    val wallet: Wallet,
    val ledger: List<LedgerEntry>,
    val withdrawals: List<Withdrawal>,
    val deviceNotice: String? = null
)
