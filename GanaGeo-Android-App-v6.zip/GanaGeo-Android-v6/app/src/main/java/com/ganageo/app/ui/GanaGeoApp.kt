package com.ganageo.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Poll
import androidx.compose.material.icons.rounded.Redeem
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ganageo.app.AuthPhase
import com.ganageo.app.GanaGeoUiState
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.R
import com.ganageo.app.model.DashboardData
import com.ganageo.app.model.LedgerEntry
import com.ganageo.app.model.Withdrawal
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import java.text.NumberFormat
import java.util.Locale

private val penFormatter: NumberFormat = NumberFormat.getCurrencyInstance(Locale("es", "PE"))

@Composable
fun GanaGeoApp(viewModel: GanaGeoViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    when (uiState.authPhase) {
        AuthPhase.ConfigurationMissing -> ConfigurationMissingScreen()
        AuthPhase.Initializing -> LoadingScreen("Preparando Gana Geo…")
        AuthPhase.CompletingSignIn -> LoadingScreen("Finalizando el acceso con Google…")
        AuthPhase.SignedOut -> LoginScreen(
            loading = uiState.isLoading,
            error = uiState.error,
            onGoogleLogin = viewModel::signInWithGoogle
        )
        AuthPhase.SignedIn -> MainShell(
            uiState = uiState,
            onRefresh = viewModel::refreshDashboard,
            onWithdraw = viewModel::requestWithdrawal,
            onCancelWithdrawal = viewModel::cancelWithdrawal,
            onSignOut = viewModel::signOut,
            onNoticeShown = viewModel::clearNotice
        )
    }
}

@Composable
private fun ConfigurationMissingScreen() {
    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.logo_gana_geo),
                contentDescription = "Logo Gana Geo",
                modifier = Modifier.size(142.dp)
            )
            Spacer(Modifier.height(24.dp))
            Text("Falta conectar Supabase", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text(
                "Copia local.properties.example como local.properties y pega la clave pública publishable/anon de tu proyecto. Nunca pegues service_role ni el Client Secret de Google dentro de la app.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun LoadingScreen(text: String) {
    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator(color = NeonGreen)
            Spacer(Modifier.height(16.dp))
            Text(text)
        }
    }
}

@Composable
private fun LoginScreen(
    loading: Boolean,
    error: String?,
    onGoogleLogin: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = DeepGreen) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.logo_gana_geo),
                contentDescription = "Logo Gana Geo",
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(180.dp)
            )
            Spacer(Modifier.height(24.dp))
            Text("Gana Geo", style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(8.dp))
            Text(
                "Encuestas, ofertas y recompensas verificadas en un solo lugar.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(28.dp))

            Button(
                onClick = onGoogleLogin,
                enabled = !loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonGreen,
                    contentColor = DeepGreen
                )
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = DeepGreen
                    )
                } else {
                    Text("Continuar con Google", fontWeight = FontWeight.Bold)
                }
            }

            if (!error.isNullOrBlank()) {
                Spacer(Modifier.height(16.dp))
                NoticeCard(error, isError = true)
            }

            Spacer(Modifier.height(22.dp))
            Text(
                "Las ganancias no están garantizadas. Los puntos solo se acreditan cuando un proveedor confirma una actividad válida.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

private data class TabItem(
    val label: String,
    val icon: ImageVector
)

@Composable
private fun MainShell(
    uiState: GanaGeoUiState,
    onRefresh: () -> Unit,
    onWithdraw: (String, String, String) -> Unit,
    onCancelWithdrawal: (String) -> Unit,
    onSignOut: () -> Unit,
    onNoticeShown: () -> Unit
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.message, uiState.error) {
        val notice = uiState.error ?: uiState.message
        if (!notice.isNullOrBlank()) {
            snackbarHostState.showSnackbar(notice)
            onNoticeShown()
        }
    }

    val tabs = remember {
        listOf(
            TabItem("Inicio", Icons.Rounded.Home),
            TabItem("Ganar", Icons.Rounded.Redeem),
            TabItem("Billetera", Icons.Rounded.AccountBalanceWallet),
            TabItem("Perfil", Icons.Rounded.Person)
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF061D12)) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepGreen,
                            selectedTextColor = NeonGreen,
                            indicatorColor = NeonGreen,
                            unselectedIconColor = Color(0xFF9AB8A5),
                            unselectedTextColor = Color(0xFF9AB8A5)
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            val dashboard = uiState.dashboard
            if (dashboard == null) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(color = NeonGreen)
                    Spacer(Modifier.height(14.dp))
                    Text("Cargando tu cuenta…")
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = onRefresh) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Reintentar")
                    }
                }
            } else {
                when (selectedTab) {
                    0 -> HomeScreen(dashboard, onRefresh)
                    1 -> EarnScreen()
                    2 -> WalletScreen(dashboard, onWithdraw, onCancelWithdrawal)
                    else -> ProfileScreen(dashboard, onSignOut)
                }
            }

            if (uiState.isLoading && dashboard != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = NeonGreen)
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(dashboard: DashboardData, onRefresh: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Hola, ${dashboard.profile.displayName ?: "Usuario"}",
                        style = MaterialTheme.typography.headlineMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "Geo ID ${dashboard.profile.geoId}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar")
                }
            }
        }

        item {
            BalanceHero(dashboard)
        }

        dashboard.deviceNotice?.let { notice ->
            item { NoticeCard(notice, isError = false) }
        }

        item {
            Text("Formas de ganar", style = MaterialTheme.typography.titleLarge)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction(
                    title = "Encuestas",
                    subtitle = "Proveedor pendiente",
                    icon = Icons.Rounded.Poll,
                    modifier = Modifier.weight(1f)
                )
                QuickAction(
                    title = "Ofertas",
                    subtitle = "Proveedor pendiente",
                    icon = Icons.Rounded.Apps,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Text("Actividad reciente", style = MaterialTheme.typography.titleLarge)
        }

        if (dashboard.ledger.isEmpty()) {
            item { EmptyCard("Aún no tienes movimientos confirmados.") }
        } else {
            items(dashboard.ledger.take(6), key = { it.id }) { entry ->
                LedgerRow(entry)
            }
        }
    }
}

@Composable
private fun BalanceHero(dashboard: DashboardData) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
        shape = RoundedCornerShape(26.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.TrendingUp, contentDescription = null, tint = NeonGreen)
                Spacer(Modifier.width(8.dp))
                Text("Saldo disponible", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                penFormatter.format(dashboard.wallet.availableAmount),
                style = MaterialTheme.typography.displaySmall,
                color = NeonGreen
            )
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniBalance(
                    "Puntos",
                    dashboard.wallet.internalPoints.toString(),
                    Icons.Rounded.Redeem,
                    Modifier.weight(1f)
                )
                MiniBalance(
                    "Pendiente",
                    penFormatter.format(dashboard.wallet.pendingAmount),
                    Icons.Rounded.Schedule,
                    Modifier.weight(1f)
                )
                MiniBalance(
                    "Bloqueado",
                    penFormatter.format(dashboard.wallet.lockedAmount),
                    Icons.Rounded.Lock,
                    Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MiniBalance(label: String, value: String, icon: ImageVector, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .padding(12.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(8.dp))
        Text(value, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9AB8A5))
    }
}

@Composable
private fun QuickAction(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(NeonGreen.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = NeonGreen)
            }
            Spacer(Modifier.height(12.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9AB8A5))
        }
    }
}

@Composable
private fun EarnScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Ganar puntos", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                "La app solo acreditará recompensas confirmadas por proveedores. No se otorgarán puntos desde el celular sin una validación del servidor.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            EarnProviderCard(
                icon = Icons.Rounded.Poll,
                title = "Encuestas",
                text = "Conecta una API de encuestas para mostrar campañas según el país y perfil del usuario."
            )
        }
        item {
            EarnProviderCard(
                icon = Icons.Rounded.Apps,
                title = "Ofertas e instalaciones",
                text = "Necesita un proveedor con postback firmado para evitar instalaciones falsas o repetidas."
            )
        }
        item {
            EarnProviderCard(
                icon = Icons.Rounded.PlayCircle,
                title = "Anuncios recompensados",
                text = "Debe integrarse con un SDK autorizado. La recompensa se valida en servidor; no basta con tocar un botón."
            )
        }
        item {
            NoticeCard(
                "Estas opciones están preparadas visualmente, pero permanecerán desactivadas hasta contratar y configurar proveedores reales.",
                isError = false
            )
        }
    }
}

@Composable
private fun EarnProviderCard(icon: ImageVector, title: String, text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.Top) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(NeonGreen.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = NeonGreen)
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(5.dp))
                Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Text("Próximamente", color = Gold, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WalletScreen(
    dashboard: DashboardData,
    onWithdraw: (String, String, String) -> Unit,
    onCancelWithdrawal: (String) -> Unit
) {
    var showWithdrawDialog by rememberSaveable { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Billetera", style = MaterialTheme.typography.headlineMedium)
        }
        item { BalanceHero(dashboard) }
        item {
            Button(
                onClick = { showWithdrawDialog = true },
                enabled = dashboard.wallet.availableAmount > 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonGreen,
                    contentColor = DeepGreen
                )
            ) {
                Icon(Icons.Rounded.Payments, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Solicitar retiro")
            }
        }
        item { Text("Solicitudes", style = MaterialTheme.typography.titleLarge) }

        if (dashboard.withdrawals.isEmpty()) {
            item { EmptyCard("Todavía no has solicitado retiros.") }
        } else {
            items(dashboard.withdrawals, key = { it.id }) { withdrawal ->
                WithdrawalRow(withdrawal, onCancelWithdrawal)
            }
        }
    }

    if (showWithdrawDialog) {
        WithdrawalDialog(
            available = dashboard.wallet.availableAmount,
            onDismiss = { showWithdrawDialog = false },
            onSubmit = { amount, method, destination ->
                showWithdrawDialog = false
                onWithdraw(amount, method, destination)
            }
        )
    }
}

@Composable
private fun WithdrawalDialog(
    available: Double,
    onDismiss: () -> Unit,
    onSubmit: (String, String, String) -> Unit
) {
    var amount by rememberSaveable { mutableStateOf("") }
    var destination by rememberSaveable { mutableStateOf("") }
    var method by rememberSaveable { mutableStateOf("yape") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Solicitar retiro") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Disponible: ${penFormatter.format(available)}")
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it.take(10) },
                    label = { Text("Monto en soles") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("yape", "plin", "paypal").forEach { option ->
                        FilledTonalButton(
                            onClick = { method = option },
                            modifier = Modifier.weight(1f),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                horizontal = 6.dp,
                                vertical = 8.dp
                            ),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (method == option) NeonGreen else CardGreen,
                                contentColor = if (method == option) DeepGreen else Color.White
                            )
                        ) {
                            Text(option.replaceFirstChar { it.uppercase() })
                        }
                    }
                }
                OutlinedTextField(
                    value = destination,
                    onValueChange = { destination = it.take(80) },
                    label = {
                        Text(if (method == "paypal") "Correo de PayPal" else "Número de celular")
                    },
                    singleLine = true
                )
                Text(
                    "El retiro quedará pendiente de revisión. La app no enviará dinero automáticamente hasta integrar un proveedor de pagos.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(amount, method, destination) },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) {
                Text("Enviar solicitud")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun WithdrawalRow(withdrawal: Withdrawal, onCancel: (String) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(penFormatter.format(withdrawal.amount), fontWeight = FontWeight.Bold)
                    Text(
                        "${withdrawal.paymentMethod.uppercase()} · ${withdrawal.paymentDestination}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                StatusChip(withdrawal.status)
            }
            if (!withdrawal.rejectionReason.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(withdrawal.rejectionReason, color = MaterialTheme.colorScheme.error)
            }
            if (withdrawal.status in setOf("pending", "under_review")) {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { onCancel(withdrawal.id) }) {
                    Icon(Icons.Rounded.Cancel, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Cancelar solicitud")
                }
            }
        }
    }
}

@Composable
private fun StatusChip(status: String) {
    val (label, color) = when (status) {
        "paid" -> "Pagado" to NeonGreen
        "approved" -> "Aprobado" to Gold
        "rejected" -> "Rechazado" to MaterialTheme.colorScheme.error
        "cancelled" -> "Cancelado" to Color(0xFF9AB8A5)
        "under_review" -> "En revisión" to Gold
        else -> "Pendiente" to Color(0xFF74C7FF)
    }
    Text(
        label,
        color = color,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(100.dp))
            .background(color.copy(alpha = 0.13f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    )
}

@Composable
private fun ProfileScreen(dashboard: DashboardData, onSignOut: () -> Unit) {
    val context = LocalContext.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(R.drawable.logo_gana_geo),
                    contentDescription = null,
                    modifier = Modifier.size(100.dp)
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    dashboard.profile.displayName ?: "Usuario",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    "Cuenta ${dashboard.profile.accountStatus}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Tu Geo ID", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            dashboard.profile.geoId.toString(),
                            style = MaterialTheme.typography.headlineMedium,
                            color = NeonGreen,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(
                                ClipData.newPlainText("Geo ID", dashboard.profile.geoId.toString())
                            )
                        }) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copiar Geo ID")
                        }
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                    Spacer(Modifier.height(12.dp))
                    Text("País: ${dashboard.profile.countryCode}")
                    Text("Moneda: ${dashboard.wallet.currency}")
                }
            }
        }

        item {
            NoticeCard(
                "El Geo ID identifica la cuenta dentro de Gana Geo. No reemplaza el correo, el teléfono ni una identidad oficial.",
                isError = false
            )
        }

        item {
            OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Cerrar sesión")
            }
        }
    }
}

@Composable
private fun LedgerRow(entry: LedgerEntry) {
    val positive = entry.pointsDelta > 0 || entry.cashDelta > 0
    val amountText = when {
        entry.pointsDelta != 0L -> "${if (entry.pointsDelta > 0) "+" else ""}${entry.pointsDelta} pts"
        entry.cashDelta != 0.0 -> "${if (entry.cashDelta > 0) "+" else ""}${penFormatter.format(entry.cashDelta)}"
        else -> "Sin cambio"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background((if (positive) NeonGreen else Gold).copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (positive) Icons.Rounded.CheckCircle else Icons.Rounded.Payments,
                    contentDescription = null,
                    tint = if (positive) NeonGreen else Gold
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(entry.description ?: entry.entryType.readableEntryType(), fontWeight = FontWeight.SemiBold)
                Text(
                    entry.provider ?: "Gana Geo",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Text(
                amountText,
                color = if (positive) NeonGreen else Gold,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun String.readableEntryType(): String = when (this) {
    "survey_reward" -> "Recompensa de encuesta"
    "offer_reward" -> "Recompensa de oferta"
    "game_reward" -> "Recompensa de juego"
    "referral_reward" -> "Recompensa por referido"
    "ad_points" -> "Puntos por anuncio"
    "purchase_points" -> "Compra de puntos"
    "withdrawal" -> "Retiro solicitado"
    "reversal" -> "Devolución"
    else -> "Ajuste de saldo"
}

@Composable
private fun EmptyCard(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Info, contentDescription = null, tint = Gold)
            Spacer(Modifier.width(12.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun NoticeCard(text: String, isError: Boolean) {
    val color = if (isError) MaterialTheme.colorScheme.error else Gold
    Card(
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.10f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(
                if (isError) Icons.Rounded.ErrorOutline else Icons.Rounded.Info,
                contentDescription = null,
                tint = color
            )
            Spacer(Modifier.width(10.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
