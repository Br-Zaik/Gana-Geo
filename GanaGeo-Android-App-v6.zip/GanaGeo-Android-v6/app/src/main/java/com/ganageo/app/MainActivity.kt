package com.ganageo.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.ganageo.app.data.SupabaseProvider
import com.ganageo.app.ui.GanaGeoApp
import com.ganageo.app.ui.theme.GanaGeoTheme
import io.github.jan.supabase.auth.handleDeeplinks

class MainActivity : ComponentActivity() {
    private val viewModel: GanaGeoViewModel by viewModels()
    private var lastHandledAuthUri: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            GanaGeoTheme {
                GanaGeoApp(viewModel)
            }
        }

        processAuthIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        processAuthIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        viewModel.reconcileSession()
    }

    private fun processAuthIntent(intent: Intent?) {
        val callbackUri = intent?.data ?: return
        if (!callbackUri.isGanaGeoAuthCallback()) return

        val callbackValue = callbackUri.toString()
        if (callbackValue == lastHandledAuthUri) return
        lastHandledAuthUri = callbackValue

        val callbackIntent = Intent(intent)
        setIntent(Intent(intent).apply { data = null })

        viewModel.onAuthCallbackStarted()

        val providerError = callbackUri.getQueryParameter("error_description")
            ?: callbackUri.getQueryParameter("error")

        if (!providerError.isNullOrBlank()) {
            viewModel.onAuthCallbackError(IllegalStateException(providerError))
            return
        }

        val client = SupabaseProvider.client
        if (client == null) {
            viewModel.onAuthCallbackError(
                IllegalStateException("Supabase no está configurado en esta compilación.")
            )
            return
        }

        client.handleDeeplinks(
            intent = callbackIntent,
            onSessionSuccess = {
                viewModel.onAuthCallbackSuccess()
            },
            onError = { error ->
                viewModel.onAuthCallbackError(error)
            }
        )
    }

    private fun Uri.isGanaGeoAuthCallback(): Boolean =
        scheme.equals("ganageo", ignoreCase = true) &&
            host.equals("login-callback", ignoreCase = true)
}
