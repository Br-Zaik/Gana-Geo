package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import java.util.UUID

private val Context.ganaGeoDataStore by preferencesDataStore(name = "gana_geo_preferences")

class DeviceIdentityStore(private val context: Context) {
    private val installationIdKey = stringPreferencesKey("installation_id")

    suspend fun getOrCreateInstallationId(): String {
        val existing = context.ganaGeoDataStore.data.first()[installationIdKey]
        if (!existing.isNullOrBlank()) return existing

        val created = UUID.randomUUID().toString()
        context.ganaGeoDataStore.edit { preferences ->
            preferences[installationIdKey] = created
        }
        return created
    }
}
