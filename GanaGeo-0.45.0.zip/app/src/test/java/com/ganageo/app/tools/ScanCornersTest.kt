package com.ganageo.app.tools

import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanCornersTest {
    /** Mapa de calor falso: 4 manchas en puntos conocidos (cuadro de 256). */
    private fun heat(points: List<Pair<Float, Float>>, size: Int, channelsFirst: Boolean): FloatArray {
        val out = FloatArray(4 * size * size)
        for ((c, p) in points.withIndex()) for (y in 0 until size) for (x in 0 until size) {
            val dx = (x + 0.5f) * 256f / size - p.first
            val dy = (y + 0.5f) * 256f / size - p.second
            val v = kotlin.math.exp(-(dx * dx + dy * dy) / (2f * 36f))
            if (channelsFirst) out[(c * size + y) * size + x] = v else out[(y * size + x) * 4 + c] = v
        }
        return out
    }

    @Test
    fun leeLasEsquinasDelMapaDeCalor() {
        val truth = listOf(40f to 30f, 210f to 44f, 220f to 230f, 30f to 214f)
        for (first in listOf(true, false)) {
            val shape = if (first) longArrayOf(1, 4, 64, 64) else longArrayOf(1, 64, 64, 4)
            val found = ScanCorners.decode(heat(truth, 64, first), shape)
            assertNotNull(found)
            for ((k, p) in truth.withIndex()) {
                assertTrue("esquina $k ${found!![k][0]},${found[k][1]}", abs(found[k][0] - p.first) < 3f && abs(found[k][1] - p.second) < 3f)
            }
        }
        // Salida que no es de 4 mapas.
        assertNull(ScanCorners.decode(FloatArray(10), longArrayOf(1, 10)))
    }

    @Test
    fun ordenaLasEsquinas() {
        val mixed = listOf(floatArrayOf(220f, 230f, 1f), floatArrayOf(40f, 30f, 1f), floatArrayOf(30f, 214f, 1f), floatArrayOf(210f, 44f, 1f))
        val q = ScanCorners.order(mixed)
        assertEquals(listOf(40f, 30f, 210f, 44f, 220f, 230f, 30f, 214f), q.toList())
    }

    @Test
    fun entradaYVueltaALaFoto() {
        val w = 300; val h = 400
        val px = IntArray(w * h) { 0xFF808080.toInt() }
        for (variant in ScanCorners.VARIANTS) {
            val (input, mapping) = ScanCorners.input(px, w, h, variant)
            assertEquals(3 * 256 * 256, input.size)
            // Un punto de la foto ida y vuelta.
            val x256 = 150f * mapping.sx + mapping.ox
            val y256 = 200f * mapping.sy + mapping.oy
            assertTrue(abs(mapping.toImageX(x256) - 150f) < 0.01f && abs(mapping.toImageY(y256) - 200f) < 0.01f)
            assertEquals(variant, ScanCorners.Variant.parse(variant.code()))
        }
        // Gris 0,5: con 0..1 queda 0,5; con −1..1 queda ~0.
        val (plain, _) = ScanCorners.input(px, w, h, ScanCorners.Variant(false, 0, false))
        assertTrue(abs(plain[128 * 256 + 128] - 128f / 255f) < 0.01f)
    }

    @Test
    fun fotoDePruebaTieneLaHojaDondeDice() {
        val (image, truth) = ScanCorners.sample()
        val (px, w, h) = image
        // El centro de la hoja es claro; una esquina de la foto es mesa (más oscura y con color).
        val cx = (truth[0] + truth[2] + truth[4] + truth[6]) / 4f
        val cy = (truth[1] + truth[3] + truth[5] + truth[7]) / 4f
        val center = px[cy.toInt() * w + cx.toInt() + 3]
        val corner = px[5 * w + 5]
        assertTrue(((center shr 8) and 255) > 200)
        assertTrue(((corner shr 8) and 255) < 160)
        // El buscador de siempre también la encuentra, cerca de las esquinas verdaderas.
        val found = ScanPhoto.detect(px, w, h)
        assertNotNull(found.quad)
        assertTrue("error ${ScanCorners.error(found.quad!!.points, truth, w, h)}", ScanCorners.error(found.quad!!.points, truth, w, h) < 0.03f)
    }
}
