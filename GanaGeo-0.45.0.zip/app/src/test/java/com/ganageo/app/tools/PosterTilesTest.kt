package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PosterTilesTest {
    private val a4 = PosterTiles.PAPERS[0]

    @Test
    fun franjaSoloEnLasHojasQueRecibenYSinMargenAfuera() {
        val options = PosterTiles.Options(2, 2, a4, landscape = false, borderMm = 0f, overlapMm = 10f, fill = true)
        // Hoja 1: imagen hasta todos sus bordes (sin margen).
        assertEquals(0f, options.leftOf(0), 0.01f)
        assertEquals(0f, options.topOf(0), 0.01f)
        assertEquals(a4.width, options.colWidth(0), 0.01f)
        // Hojas 2 y 4 (derecha): franja de 10 mm a la izquierda; 3 y 4 (abajo): arriba.
        assertEquals(10f * PosterTiles.MM, options.leftOf(1), 0.01f)
        assertEquals(10f * PosterTiles.MM, options.topOf(1), 0.01f)
        assertEquals(a4.width - 10f * PosterTiles.MM, options.colWidth(1), 0.01f)
        val tiles = PosterTiles.tiles(2000, 2800, options)
        assertEquals(listOf("1", "2", "3", "4"), tiles.map { it.label })
        // Las imágenes se juntan sin repetirse: la hoja 2 empieza donde termina la 1.
        assertEquals(tiles[0].source!![2], tiles[1].source!![0], 0.01f)
        assertEquals(tiles[0].source!![3], tiles[2].source!![1], 0.01f)
    }

    @Test
    fun completaDejaBlancoSinCortar() {
        val options = PosterTiles.Options(1, 3, a4, landscape = true, borderMm = 0f, overlapMm = 0f, fill = false)
        val tiles = PosterTiles.tiles(1000, 1000, options)
        assertEquals(0f, tiles.mapNotNull { it.source }.minOf { it[0] }, 0.5f)
        assertEquals(1000f, tiles.mapNotNull { it.source }.maxOf { it[2] }, 0.5f)
    }

    @Test
    fun mejorCuadriculaSegunLaImagen() {
        assertEquals(1 to 2, PosterTiles.bestGrid(2, 3000, 1000, a4, landscape = true))
        assertEquals(2 to 1, PosterTiles.bestGrid(2, 1000, 3000, a4, landscape = false))
        assertEquals(2 to 2, PosterTiles.bestGrid(4, 1000, 1414, a4, landscape = false))
    }

    @Test
    fun tamanoArmado() {
        val options = PosterTiles.Options(2, 2, a4, landscape = false, borderMm = 0f, overlapMm = 10f, fill = true)
        val (w, h) = PosterTiles.sizeCm(options)
        // 21 + (21 − 1) = 41 cm; 29,7 + (29,7 − 1) = 58,4 cm.
        assertEquals(41f, w, 0.1f)
        assertEquals(58.4f, h, 0.1f)
        assertTrue(PosterTiles.dpi(3000, 4000, options) in 120..220)
        assertEquals("AA1", PosterTiles.label(26, 0))
    }

    @Test
    fun hojaSinImagenQuedaEnBlanco() {
        val options = PosterTiles.Options(1, 4, a4, landscape = true, borderMm = 0f, overlapMm = 0f, fill = false)
        // Imagen alta en un papelote muy ancho: las hojas de los costados quedan blancas.
        val tiles = PosterTiles.tiles(500, 2000, options)
        assertNull(tiles.first().source)
    }

    @Test
    fun pasosDelTutorial() {
        // 2 filas × 3 columnas: 2 pasos por fila + 1 para unir las filas.
        val steps = PosterTiles.steps(2, 3)
        assertEquals(5, steps.size)
        assertEquals(listOf(1), steps[0].placed)
        assertEquals(listOf(2), steps[0].incoming)
        assertTrue(steps[0].fromRight)
        assertEquals(listOf(1, 2), steps[1].placed)
        assertEquals(listOf(3), steps[1].incoming)
        assertEquals(listOf(4), steps[2].placed)
        assertEquals(listOf(1, 2, 3), steps[4].placed)
        assertEquals(listOf(4, 5, 6), steps[4].incoming)
        assertTrue(!steps[4].fromRight)
        // Una sola columna: solo se juntan filas.
        val column = PosterTiles.steps(3, 1)
        assertEquals(2, column.size)
        assertTrue(column.none { it.fromRight })
        // Cada hoja llega una sola vez y todas llegan (menos la 1).
        val all = PosterTiles.steps(3, 4)
        assertEquals((2..12).toSet(), all.flatMap { it.incoming }.toSet())
    }

    @Test
    fun papelesDeImprenta() {
        assertEquals(listOf("A4", "A3", "Oficio", "Carta", "A5"), PosterTiles.PAPERS.map { it.name })
        // Todas paradas (alto > ancho) y A3 = dos A4.
        assertTrue(PosterTiles.PAPERS.all { it.height > it.width })
        val a3 = PosterTiles.PAPERS[1]
        assertTrue(kotlin.math.abs(a3.width * a3.height - 2 * a4.width * a4.height) < 50f)
    }

    @Test
    fun ajustarALaImagenRecortaLoQueSobra() {
        // Imagen cuadrada en 1 columna × 2 filas (una encima de otra): con Ajustar, la imagen
        // entra entera desde arriba, sin blanco a los lados, y abajo se recorta.
        val options = PosterTiles.Options(2, 1, a4, false, 0f, 10f, fill = false, adapt = true)
        val p = PosterTiles.place(1000, 1000, options)
        assertEquals(0f, p.x, 0.01f)
        assertEquals(0f, p.y, 0.01f)
        assertEquals(options.posterWidth, p.width, 0.5f)
        val (cutX, cutY) = PosterTiles.cuts(1000, 1000, options)
        assertTrue(cutX == null)
        assertNotNull(cutY)
        assertEquals(p.height, cutY!!, 0.5f)
        // Llenar corta imagen; Completa deja blanco; los dos pierden algo con esta forma.
        val fill = PosterTiles.Options(2, 1, a4, false, 0f, 10f, fill = true)
        val fit = PosterTiles.Options(2, 1, a4, false, 0f, 10f, fill = false)
        assertTrue(PosterTiles.waste(1000, 1000, fill) > 0.3f)
        assertTrue(PosterTiles.waste(1000, 1000, fit) > 0.3f)
        // 2 × 2 para una imagen cuadrada pierde mucho menos (es la recomendada).
        val best = PosterTiles.bestGrid(4, 1000, 1000, a4, false)
        assertEquals(2 to 2, best)
        val square = PosterTiles.Options(2, 2, a4, false, 0f, 10f, fill = true)
        assertTrue(PosterTiles.waste(1000, 1000, square) < 0.35f)
        // Sin Ajustar no hay cortes.
        assertEquals(null to null, PosterTiles.cuts(1000, 1000, fit))
    }

    @Test
    fun tutorialCabeEnSusPaginas() {
        val measure = PosterTutorial.Measure { text, size, _ -> text.length * size * 0.55f }
        for ((rows, cols, glue) in listOf(Triple(2, 2, 10f), Triple(2, 3, 0f), Triple(4, 4, 20f), Triple(3, 1, 10f))) {
            for (landscape in listOf(false, true)) {
                val options = PosterTiles.Options(rows, cols, a4, landscape, 0f, glue, true)
                val pages = PosterTutorial.pages(1200, 900, options, measure)
                // Portada + un paso por página + final.
                assertEquals(PosterTiles.steps(rows, cols).size + 2, pages.size)
                for ((index, ops) in pages.withIndex()) {
                    val b = PosterTutorial.bounds(ops)
                    assertTrue("página $index ${b.joinToString()}", b[0] >= -0.5f && b[1] >= -0.5f && b[2] <= PosterTutorial.PAGE_W + 0.5f && b[3] <= PosterTutorial.PAGE_H + 0.5f)
                }
                // En cada paso hay una flecha (punta azul) y, con franja, pegamento amarillo.
                for (ops in pages.drop(1).dropLast(1)) {
                    assertTrue(ops.any { it is PosterTutorial.Poly && it.fill == PosterTutorial.BLUE })
                    if (glue > 0f) assertTrue(ops.any { it is PosterTutorial.Box && it.fill == PosterTutorial.GLUE })
                }
            }
        }
    }
}
