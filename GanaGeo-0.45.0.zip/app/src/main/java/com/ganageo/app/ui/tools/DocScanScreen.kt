package com.ganageo.app.ui.tools

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.RectF
import android.net.Uri
import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.BorderRight
import androidx.compose.material.icons.rounded.BorderLeft
import androidx.compose.material.icons.rounded.BorderBottom
import androidx.compose.material.icons.rounded.BorderTop
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.DocumentScanner
import androidx.compose.material.icons.rounded.Draw
import androidx.compose.material.icons.rounded.FormatAlignCenter
import androidx.compose.material.icons.rounded.FormatAlignJustify
import androidx.compose.material.icons.rounded.FormatAlignLeft
import androidx.compose.material.icons.rounded.FormatAlignRight
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Redo
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import com.ganageo.app.tools.ScanReader
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextGeometricTransform
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.ScanGuides
import com.ganageo.app.tools.ScanRebuild
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Colores propios del escáner.
private val DocScanBackground = Color(0xFF0B1410)
private val DocScanBar = Color(0xFF101D16)
private val DocScanChipIdle = Color(0xFF1A2B22)
private val DocScanChipOn = Color(0xFF2A4A1A)
private val DocScanInk = Color(0xFFE6EFE9)
private val DocScanMuted = Color(0xFF8FA398)
private val DocScanFocus = Color(0xFF3D8BFF)
private val DocScanGuide = Color(0xFFFF3DA5)
private val DocScanDanger = Color(0xFFFF8A80)
private const val DocScanSignatureInk = 0xFF10233F.toInt()

private const val DOC_SCAN_FORMAT_PDF = 0
private const val DOC_SCAN_FORMAT_WORD = 1
private const val DOC_SCAN_FORMAT_IMAGE = 2
private const val DOC_SCAN_FORMAT_WORD_SHEET = 3
private const val DOC_SCAN_FORMAT_EXCEL = 4
private const val DOC_SCAN_FORMAT_PDF_PHOTO = 5
private const val DOC_SCAN_UNDO_LIMIT = 60
private const val DOC_SCAN_TYPING_PAUSE_MS = 1500L

private val DocScanPalette = listOf(
    0xFF000000.toInt(),
    0xFF3C3C3C.toInt(),
    0xFFFFFFFF.toInt(),
    0xFFC62828.toInt(),
    0xFF1565C0.toInt(),
    0xFF1B2A41.toInt(),
    0xFF2E7D32.toInt(),
    0xFFEF6C00.toInt(),
    0xFF6A1B9A.toInt()
)

/** Lo que está elegido en la hoja. */
private sealed interface DocScanSel {
    val pageId: Int
}

private data class DocScanSelBlock(override val pageId: Int, val blockId: Int) : DocScanSel
private data class DocScanSelText(override val pageId: Int, val textId: Int) : DocScanSel
private data class DocScanSelSign(override val pageId: Int, val signId: Int) : DocScanSel
private data class DocScanSelObject(override val pageId: Int, val objectId: Int) : DocScanSel
private data class DocScanSelShape(override val pageId: Int, val shapeId: Int) : DocScanSel
/** Celda elegida de una tabla. */
private data class DocScanSelTable(override val pageId: Int, val tableId: Int, val row: Int, val col: Int) : DocScanSel

/** Dónde se tomó la firma o imagen (centro y primer toque, en píxeles de la hoja encajada). */
private class DocScanGrab {
    var center: Offset = Offset.Zero
    var start: Offset = Offset.Zero
}

/** Qué le falta a la imagen de la hoja (eso se dibuja aparte, en vivo). */
private data class DocScanSheetKey(val pageId: Int, val hiddenBlock: Int, val hiddenObject: Int, val hiddenShape: Int = -1)

private fun docScanActivity(context: Context): Activity? {
    var current: Context? = context
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}

private fun docScanFilterLabel(filter: DocumentImageFilter): String = when (filter) {
    DocumentImageFilter.ORIGINAL -> "Original"
    DocumentImageFilter.DOCUMENT -> "Documento (más nítido)"
    DocumentImageFilter.GRAYSCALE -> "Gris"
    DocumentImageFilter.ENHANCE -> "Color mejorado"
}

/** Caja de lo elegido, en píxeles de la hoja encajada. */
private fun docScanSelectionRect(
    selection: DocScanSel?,
    pageId: Int,
    layout: DocScanLayout?,
    objects: List<DocScanObject>,
    edits: DocScanPageEdits,
    width: Float,
    height: Float,
    addedFamily: Int,
    paint: android.graphics.Paint,
    shapes: List<DocScanShape> = emptyList()
): RectF? {
    if (selection == null || selection.pageId != pageId || width <= 0f || height <= 0f) return null
    return when (selection) {
        is DocScanSelBlock -> {
            val block = layout?.block(selection.blockId) ?: return null
            val scaleX = width / layout.width.coerceAtLeast(1)
            val scaleY = height / layout.height.coerceAtLeast(1)
            RectF(block.rect.left * scaleX, block.rect.top * scaleY, block.rect.right * scaleX, block.rect.bottom * scaleY)
        }
        is DocScanSelObject -> {
            val piece = objects.firstOrNull { it.id == selection.objectId } ?: return null
            val rect = docScanObjectRect(piece.rect, edits.objects[piece.id])
            val pageWidth = layout?.width?.toFloat() ?: return null
            val pageHeight = layout.height.toFloat()
            RectF(rect.left * width / pageWidth, rect.top * height / pageHeight, rect.right * width / pageWidth, rect.bottom * height / pageHeight)
        }
        is DocScanSelText -> edits.texts.firstOrNull { it.id == selection.textId }
            ?.let { docScanAddedBounds(it, width, height, addedFamily, paint) }
        is DocScanSelSign -> edits.signs.firstOrNull { it.id == selection.signId }
            ?.let { docScanSignRect(it, width, height) }
        is DocScanSelShape -> {
            val shape = shapes.firstOrNull { it.id == selection.shapeId } ?: return null
            val rect = docScanShapeRect(shape, edits.shapes[shape.id])
            val pageWidth = layout?.width?.toFloat() ?: return null
            val pageHeight = layout.height.toFloat()
            RectF(rect.left * width / pageWidth, rect.top * height / pageHeight, rect.right * width / pageWidth, rect.bottom * height / pageHeight)
        }
        is DocScanSelTable -> {
            val table = layout?.table(selection.tableId) ?: return null
            val cell = table.data.cellAt(selection.row, selection.col) ?: return null
            val rect = table.cellRect(cell)
            val scaleX = width / layout.width.coerceAtLeast(1)
            val scaleY = height / layout.height.coerceAtLeast(1)
            RectF(rect.left * scaleX, rect.top * scaleY, rect.right * scaleX, rect.bottom * scaleY)
        }
    }
}

/**
 * Lo que se está arrastrando, movido en vivo (solo para dibujar). dx, dy en fracción
 * de la hoja; [scale] y [turn]: lo que se está agrandando y girando con los dedos.
 * [pageRatio]: alto / ancho de la hoja.
 */
private fun docScanPreview(
    edits: DocScanPageEdits,
    selection: DocScanSel?,
    dx: Float,
    dy: Float,
    scale: Float = 1f,
    turn: Float = 0f,
    pageRatio: Float = 1.4142f
): DocScanPageEdits =
    when (selection) {
        is DocScanSelText -> edits.copy(
            texts = edits.texts.map { if (it.id == selection.textId) it.copy(x = it.x + dx, y = it.y + dy) else it }
        )
        is DocScanSelSign -> edits.copy(
            signs = edits.signs.map {
                if (it.id != selection.signId) it else {
                    var sign = it.movedBy(dx, dy)
                    if (scale != 1f) sign = sign.resizedBy(scale, pageRatio)
                    if (turn != 0f) sign = sign.turnedBy(turn)
                    sign
                }
            }
        )
        is DocScanSelObject -> if (scale == 1f && turn == 0f) edits else {
            val edit = edits.objects[selection.objectId] ?: DocScanObjectEdit()
            edits.copy(
                objects = edits.objects + (selection.objectId to edit.copy(
                    scale = (edit.scale * scale).coerceIn(0.1f, 8f),
                    rotation = docScanNormalAngle(edit.rotation + turn)
                ))
            )
        }
        else -> edits
    }

/** Giro (grados) de la firma o imagen elegida; 0 para lo demás. */
private fun docScanSelectionTurn(selection: DocScanSel?, edits: DocScanPageEdits): Float = when (selection) {
    is DocScanSelSign -> edits.signs.firstOrNull { it.id == selection.signId }?.rotation ?: 0f
    is DocScanSelObject -> edits.objects[selection.objectId]?.rotation ?: 0f
    else -> 0f
}

/**
 * Escáner de documentos.
 *
 * 1. Entrada: "Escanear" (escáner de Google: encuentra la hoja, la recorta y la
 *    endereza) o "Elegir de tus fotos" (selector de fotos de Android).
 * 2. Hoja reconstruida: se borra el texto de la foto y se escribe encima el
 *    texto de verdad (mismo lugar, tamaño, color y negrita). Se toca un párrafo
 *    y se escribe directo encima, como en Word. Manteniendo presionado se mueve,
 *    con guías para alinear.
 * 3. Guardar: PDF (con texto real editable), Word (párrafos con formato) o imagen.
 */
@Composable
fun DocumentScannerScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Teclado: la pantalla se achica una sola vez (sin esto Android además la empuja
    // hacia arriba y queda un espacio vacío entre el panel y el teclado).
    DisposableEffect(context) {
        val window = docScanActivity(context)?.window
        val previous = window?.attributes?.softInputMode
        window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        onDispose {
            if (window != null && previous != null) window.setSoftInputMode(previous)
        }
    }
    val scope = rememberCoroutineScope()
    var pages by remember { mutableStateOf<List<DocScanPage>>(emptyList()) }
    var nextPageId by remember { mutableIntStateOf(1) }
    var session by remember { mutableIntStateOf(0) }
    var importing by remember { mutableStateOf(false) }
    var scannerOpening by remember { mutableStateOf(false) }
    // true = las páginas que lleguen se agregan al documento abierto.
    var appending by remember { mutableStateOf(false) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }

    // Copias de escaneos de otras veces: se borran al entrar.
    LaunchedEffect(Unit) {
        runCatching { docScanCleanCache(context, emptySet()) }
    }

    var importStep by remember { mutableStateOf("Preparando páginas…") }

    fun receivePages(uris: List<Uri>, originals: List<Uri?> = emptyList(), photo: Boolean = false) {
        if (uris.isEmpty()) return
        val base = if (appending) pages else emptyList()
        val room = DOC_SCAN_MAX_PAGES - base.size
        if (room <= 0) {
            onMessage("Máximo $DOC_SCAN_MAX_PAGES páginas por documento.")
            return
        }
        val accepted = uris.take(room)
        var id = nextPageId
        val created = accepted.mapIndexed { index, uri ->
            val original = originals.getOrNull(index)
            DocScanPage(id++, uri, original, photo = photo || original != null)
        }
        nextPageId = id
        if (!appending) session++
        pages = base + created
        if (uris.size > room) onMessage("Se agregaron ${accepted.size} páginas. Máximo $DOC_SCAN_MAX_PAGES.")
    }

    // Fotos del celular: primero Recortar (esquinas que se pueden mover), luego se
    // enderezan con animación y se elige el filtro.
    var cropSources by remember { mutableStateOf<List<Uri>?>(null) }

    fun receivePhotos(uris: List<Uri>) {
        if (uris.isEmpty()) return
        cropSources = uris.take(DOC_SCAN_MAX_PAGES)
    }

    // Respaldo sin pantalla de recorte (se usa si la otra no se puede).
    @Suppress("unused")
    fun receivePhotosDirect(uris: List<Uri>) {
        if (uris.isEmpty()) return
        importing = true
        importStep = "Enderezando la hoja…"
        scope.launch {
            val flat = runCatching {
                docScanFlattenPhotos(context, uris.take(DOC_SCAN_MAX_PAGES)) { done, total ->
                    if (total > 1) importStep = "Enderezando hojas… ${(done + 1).coerceAtMost(total)} de $total"
                }
            }.getOrElse { uris.map { it to null } }
            importing = false
            importStep = "Preparando páginas…"
            receivePages(flat.map { it.first }, flat.map { it.second })
        }
    }

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(DOC_SCAN_MAX_PAGES)
    ) { uris -> receivePhotos(uris) }

    // Desde archivos: PDF (cada página una hoja) o imágenes (se enderezan).
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        val resolver = context.contentResolver
        val pdfs = uris.filter { resolver.getType(it) == "application/pdf" || it.toString().lowercase().endsWith(".pdf") }
        val images = uris - pdfs.toSet()
        if (pdfs.isEmpty()) {
            receivePhotos(images)
            return@rememberLauncherForActivityResult
        }
        importing = true
        importStep = "Abriendo el PDF…"
        scope.launch {
            val room = DOC_SCAN_MAX_PAGES - (if (appending) pages.size else 0)
            val fromPdf = ArrayList<Uri>()
            for (pdf in pdfs) {
                val left = room - fromPdf.size
                if (left <= 0) break
                fromPdf += runCatching { docScanPdfPages(context, pdf, left) }.getOrDefault(emptyList())
            }
            importing = false
            importStep = "Preparando páginas…"
            if (fromPdf.isEmpty() && images.isEmpty()) {
                onMessage("No se pudo abrir el PDF (puede tener clave).")
                return@launch
            }
            if (fromPdf.isNotEmpty()) receivePages(fromPdf)
            if (images.isNotEmpty()) {
                appending = true
                receivePhotos(images)
            }
        }
    }

    fun pickFiles(append: Boolean) {
        if (importing) return
        appending = append
        runCatching { filePicker.launch(arrayOf("application/pdf", "image/*")) }
            .onFailure { onMessage("No se pudieron abrir tus archivos.") }
    }

    // Al volver al Escáner (de la cámara, la galería o los archivos): los botones se
    // vuelven a habilitar aunque la otra pantalla no haya respondido.
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME && scannerOpening) {
                scope.launch {
                    delay(900)
                    scannerOpening = false
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val googleScanner = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        scannerOpening = false
        if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val scan = runCatching { GmsDocumentScanningResult.fromActivityResultIntent(result.data) }.getOrNull()
        val sources = scan?.pages.orEmpty().map { it.imageUri }
        if (sources.isEmpty()) {
            onMessage("No se pudo leer el escaneo. Intenta otra vez.")
            return@rememberLauncherForActivityResult
        }
        importing = true
        scope.launch {
            val copied = runCatching { docScanCopyToCache(context, sources) }.getOrDefault(emptyList())
            importing = false
            if (copied.isEmpty()) onMessage("No se pudo leer el escaneo. Intenta otra vez.") else receivePages(copied, photo = true)
        }
    }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
        val uri = cameraUri
        cameraUri = null
        if (saved && uri != null) receivePhotos(listOf(uri))
    }

    fun openPlainCamera() {
        val uri = runCatching { ToolFileUtils.createCameraImageUri(context) }.getOrNull()
        if (uri == null) {
            onMessage("No se pudo abrir la cámara.")
            return
        }
        cameraUri = uri
        runCatching { takePicture.launch(uri) }.onFailure {
            cameraUri = null
            onMessage("No se pudo abrir la cámara.")
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openPlainCamera() else onMessage("Da permiso de cámara para tomar la foto.")
    }

    // Respaldo: celular sin Servicios de Google o con poca memoria.
    fun cameraFallback() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openPlainCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    fun startScan(append: Boolean) {
        if (scannerOpening || importing) return
        appending = append
        val room = DOC_SCAN_MAX_PAGES - (if (append) pages.size else 0)
        if (room <= 0) {
            onMessage("Máximo $DOC_SCAN_MAX_PAGES páginas por documento.")
            return
        }
        val activity = docScanActivity(context)
        if (activity == null) {
            cameraFallback()
            return
        }
        scannerOpening = true
        runCatching {
            val options = GmsDocumentScannerOptions.Builder()
                // También desde la galería: el escáner de Google recorta y endereza igual.
                .setGalleryImportAllowed(true)
                .setPageLimit(room)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build()
            GmsDocumentScanning.getClient(options)
                .getStartScanIntent(activity)
                .addOnSuccessListener { sender ->
                    runCatching { googleScanner.launch(IntentSenderRequest.Builder(sender).build()) }
                        .onFailure {
                            scannerOpening = false
                            cameraFallback()
                        }
                }
                .addOnFailureListener {
                    scannerOpening = false
                    cameraFallback()
                }
        }.onFailure {
            scannerOpening = false
            cameraFallback()
        }
    }

    fun pickPhotos(append: Boolean) {
        if (importing) return
        appending = append
        runCatching {
            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }.onFailure { onMessage("No se pudieron abrir tus fotos.") }
    }

    // Antes de trabajar: si falta la IA, se pregunta si se baja (con IA sale mucho mejor).
    var aiGate by remember { mutableStateOf<(() -> Unit)?>(null) }
    fun withAi(action: () -> Unit) {
        if (DocScanAiPack.declined || DocScanAiPack.missing(context).isEmpty()) action() else aiGate = action
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DocScanBackground)
    ) {
        if (pages.isEmpty()) {
            DocScanHome(
                tool = tool,
                busy = scannerOpening || importing,
                animate = uiState.animationsEnabled,
                onBack = onBack,
                onScan = { withAi { startScan(append = false) } },
                onPhotos = { withAi { pickPhotos(append = false) } },
                onFiles = { withAi { pickFiles(append = false) } }
            )
        } else {
            key(session) {
                DocScanWorkspace(
                    viewModel = viewModel,
                    tool = tool,
                    pages = pages,
                    onMessage = onMessage,
                    onClose = {
                        pages = emptyList()
                        scope.launch { runCatching { docScanCleanCache(context, emptySet()) } }
                    },
                    onAddScan = { withAi { startScan(append = true) } },
                    onAddPhotos = { withAi { pickPhotos(append = true) } },
                    onAddFiles = { withAi { pickFiles(append = true) } },
                    onRemovePage = { id -> pages = pages.filterNot { it.id == id } },
                    onUseOriginal = { id ->
                        val page = pages.firstOrNull { it.id == id }
                        val original = page?.original
                        if (page == null || original == null) null else {
                            val fresh = DocScanPage(nextPageId++, original, photo = true)
                            pages = pages.map { if (it.id == id) fresh else it }
                            fresh.id
                        }
                    },
                    onSetPhoto = { id, photo ->
                        val page = pages.firstOrNull { it.id == id }
                        if (page == null || page.photo == photo) null else {
                            val fresh = page.copy(id = nextPageId++, photo = photo)
                            pages = pages.map { if (it.id == id) fresh else it }
                            fresh.id
                        }
                    }
                )
            }
        }

        cropSources?.let { sources ->
            DocScanCropFlow(
                sources = sources,
                animate = uiState.animationsEnabled,
                onCancel = { cropSources = null },
                onDone = { flat ->
                    cropSources = null
                    receivePages(flat.map { it.first }, flat.map { it.second })
                },
                onMessage = onMessage
            )
        }

        aiGate?.let { action ->
            DocScanAiDialog { _ ->
                aiGate = null
                action()
            }
        }

        if (importing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xB3000000))
                    .pointerInput(Unit) { detectTapGestures { } },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = NeonGreen)
                    Spacer(Modifier.height(12.dp))
                    Text(importStep, color = DocScanInk)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Entrada
// ---------------------------------------------------------------------------

@Composable
private fun DocScanHome(
    tool: ToolId,
    busy: Boolean,
    animate: Boolean,
    onBack: () -> Unit,
    onScan: () -> Unit,
    onPhotos: () -> Unit,
    onFiles: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ToolHeader(tool.title, "Escanea, edita y guarda tus hojas", onBack)

        // Dibujo grande: una hoja que se escanea (llena la pantalla, sin texto de más).
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF143323), Color(0xFF0D1F16))))
        ) {
            DocScanHeroArt(
                animate = animate,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(start = 28.dp, end = 28.dp, top = 22.dp, bottom = 70.dp)
            )
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                DocScanFeature(Icons.Rounded.TextFields, "Editar texto")
                DocScanFeature(Icons.Rounded.Draw, "Firmar")
                DocScanFeature(Icons.Rounded.PictureAsPdf, "PDF y Word")
            }
        }

        // Botones abajo, a la mano del pulgar.
        Column(
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            DocScanBigButton(
                icon = Icons.Rounded.DocumentScanner,
                title = if (busy) "Abriendo…" else "Escanear documento",
                primary = true,
                enabled = !busy,
                onClick = onScan
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) {
                    DocScanBigButton(
                        icon = Icons.Rounded.PhotoLibrary,
                        title = "Tus fotos",
                        primary = false,
                        enabled = !busy,
                        onClick = onPhotos
                    )
                }
                Box(Modifier.weight(1f)) {
                    DocScanBigButton(
                        icon = Icons.Rounded.FolderOpen,
                        title = "Archivos",
                        primary = false,
                        enabled = !busy,
                        onClick = onFiles
                    )
                }
            }
            Text(
                "Editar es gratis · Guardar o copiar: ${tool.creditCost} créditos",
                color = DocScanMuted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun DocScanFeature(icon: ImageVector, label: String) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x33000000))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, color = DocScanInk, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun DocScanBigButton(
    icon: ImageVector,
    title: String,
    primary: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (primary) 62.dp else 54.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (primary) NeonGreen else CardGreen)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (primary) DeepGreen else NeonGreen, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        Text(
            title,
            color = if (primary) DeepGreen else DocScanInk,
            fontWeight = FontWeight.Black,
            fontSize = if (primary) 17.sp else 16.sp
        )
    }
}

/**
 * Hoja que se escanea: una línea de luz baja por la hoja y lo que ya pasó queda
 * nítido. Liviana: solo se vuelve a dibujar el lienzo, en bucle suave.
 */
@Composable
private fun DocScanHeroArt(animate: Boolean, modifier: Modifier) {
    val progress = if (animate) {
        val transition = rememberInfiniteTransition(label = "escaneo")
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(durationMillis = 2800, easing = LinearEasing), RepeatMode.Restart),
            label = "linea"
        )
    } else {
        null
    }
    Canvas(modifier) {
        val t = progress?.value ?: 0.62f
        // Hoja centrada (proporción A4).
        val sheetHeight = min(size.height, size.width / 0.72f)
        val sheetWidth = sheetHeight * 0.72f
        val left = (size.width - sheetWidth) / 2f
        val top = (size.height - sheetHeight) / 2f
        val corner = sheetWidth * 0.04f
        drawRoundRect(
            color = Color(0x40000000),
            topLeft = Offset(left + 6f, top + 10f),
            size = Size(sheetWidth, sheetHeight),
            cornerRadius = CornerRadius(corner, corner)
        )
        drawRoundRect(
            color = Color(0xFFF7F8F6),
            topLeft = Offset(left, top),
            size = Size(sheetWidth, sheetHeight),
            cornerRadius = CornerRadius(corner, corner)
        )
        val pad = sheetWidth * 0.11f
        val scanY = top + sheetHeight * (0.06f + 0.88f * t)
        // Título, logo y renglones: arriba de la línea ya escaneados (oscuros).
        fun ink(y: Float) = if (y < scanY) Color(0xFF26332C) else Color(0xFFD5DAD6)
        val logo = sheetWidth * 0.14f
        drawRoundRect(
            color = if (top + pad < scanY) Color(0xFF2E7D32) else Color(0xFFD5DAD6),
            topLeft = Offset(left + pad, top + pad),
            size = Size(logo, logo),
            cornerRadius = CornerRadius(logo * 0.25f, logo * 0.25f)
        )
        val lineHeight = sheetHeight * 0.022f
        val titleY = top + pad + logo * 0.2f
        drawRoundRect(
            color = ink(titleY),
            topLeft = Offset(left + pad + logo * 1.3f, titleY),
            size = Size(sheetWidth * 0.42f, lineHeight * 1.5f),
            cornerRadius = CornerRadius(lineHeight, lineHeight)
        )
        drawRoundRect(
            color = ink(titleY + lineHeight * 2.4f),
            topLeft = Offset(left + pad + logo * 1.3f, titleY + lineHeight * 2.4f),
            size = Size(sheetWidth * 0.28f, lineHeight),
            cornerRadius = CornerRadius(lineHeight, lineHeight)
        )
        val widths = floatArrayOf(0.78f, 0.72f, 0.76f, 0.5f, 0f, 0.78f, 0.7f, 0.74f, 0.66f, 0.42f, 0f, 0.6f, 0.74f, 0.56f)
        var y = top + pad + logo + sheetHeight * 0.06f
        for (share in widths) {
            if (y > top + sheetHeight - pad) break
            if (share > 0f) {
                drawRoundRect(
                    color = ink(y),
                    topLeft = Offset(left + pad, y),
                    size = Size(sheetWidth * share, lineHeight),
                    cornerRadius = CornerRadius(lineHeight / 2f, lineHeight / 2f)
                )
            }
            y += lineHeight * 2.3f
        }
        // Línea de luz con brillo.
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color(0x00B8FF00), Color(0x55B8FF00)),
                startY = scanY - sheetHeight * 0.12f,
                endY = scanY
            ),
            topLeft = Offset(left, scanY - sheetHeight * 0.12f),
            size = Size(sheetWidth, sheetHeight * 0.12f)
        )
        drawLine(
            color = NeonGreen,
            start = Offset(left - sheetWidth * 0.04f, scanY),
            end = Offset(left + sheetWidth * 1.04f, scanY),
            strokeWidth = 3.dp.toPx(),
            cap = StrokeCap.Round
        )
        // Esquinas del visor.
        val arm = sheetWidth * 0.12f
        val gap = sheetWidth * 0.05f
        val stroke = 3.dp.toPx()
        val l = left - gap
        val r = left + sheetWidth + gap
        val tp = top - gap
        val b = top + sheetHeight + gap
        listOf(
            Triple(Offset(l, tp), 1f, 1f),
            Triple(Offset(r, tp), -1f, 1f),
            Triple(Offset(l, b), 1f, -1f),
            Triple(Offset(r, b), -1f, -1f)
        ).forEach { (corner0, sx, sy) ->
            drawLine(NeonGreen, corner0, Offset(corner0.x + arm * sx, corner0.y), stroke, StrokeCap.Round)
            drawLine(NeonGreen, corner0, Offset(corner0.x, corner0.y + arm * sy), stroke, StrokeCap.Round)
        }
    }
}

// ---------------------------------------------------------------------------
// Hoja de trabajo
// ---------------------------------------------------------------------------

@Composable
private fun DocScanWorkspace(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    pages: List<DocScanPage>,
    onMessage: (String) -> Unit,
    onClose: () -> Unit,
    onAddScan: () -> Unit,
    onAddPhotos: () -> Unit,
    onAddFiles: () -> Unit = {},
    onRemovePage: (Int) -> Unit,
    /** Cambia la hoja enderezada por la foto tal cual; devuelve el id nuevo. */
    onUseOriginal: (Int) -> Int? = { null },
    /** Cambia cómo se trabaja la página: foto de cámara o imagen limpia; id nuevo. */
    onSetPhoto: (Int, Boolean) -> Int? = { _, _ -> null }
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val density = LocalDensity.current
    val haptics = LocalHapticFeedback.current

    var currentId by remember { mutableIntStateOf(pages.first().id) }
    val currentPage = pages.firstOrNull { it.id == currentId } ?: pages.first()
    val pageNumber = pages.indexOf(currentPage) + 1

    val analyses = remember { mutableStateMapOf<Int, DocScanAnalysis>() }
    val thumbs = remember { mutableStateMapOf<Int, ImageBitmap>() }
    var edits by remember { mutableStateOf<Map<Int, DocScanPageEdits>>(emptyMap()) }
    var undoStack by remember { mutableStateOf<List<Map<Int, DocScanPageEdits>>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<Map<Int, DocScanPageEdits>>>(emptyList()) }
    var typingKey by remember { mutableStateOf<String?>(null) }
    var typingAt by remember { mutableLongStateOf(0L) }

    var filter by remember { mutableStateOf(DocumentImageFilter.ORIGINAL) }
    var fontChoice by remember { mutableIntStateOf(DOC_SCAN_FONT_AUTO) }
    var paperChoice by remember { mutableIntStateOf(DOC_SCAN_PAPER_AUTO) }
    var showBoxes by remember { mutableStateOf(false) }
    var showOriginal by remember { mutableStateOf(false) }
    // Comparar: la foto a la izquierda de la raya y la hoja nueva a la derecha (null = apagado).
    var compareAt by remember { mutableStateOf<Float?>(null) }

    var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var cleaned by remember { mutableStateOf<DocScanCleaned?>(null) }
    // Hoja limpia SIN mejorar (para volver a mejorar si se cambia Original / x2).
    var cleanedPlain by remember { mutableStateOf<DocScanCleaned?>(null) }
    // "Mejorar imágenes": logos, fotos e íconos con la IA (Apagado, Original o x2).
    var enhanceMode by remember { mutableIntStateOf(DocScanEnhance.OFF) }
    var enhanceStep by remember { mutableStateOf<String?>(null) }
    var enhanceWarned by remember { mutableStateOf(false) }
    var cleanPageId by remember { mutableIntStateOf(-1) }
    var cleanPaper by remember { mutableStateOf(true) }
    // Hoja reconstruida: papel blanco + formas limpias + piezas + texto (si no, la foto limpia).
    var rebuildPage by remember { mutableStateOf(true) }
    // Muestra las partes que reconoció la IA (para revisar).
    var showAi by remember { mutableStateOf(false) }
    // IA de la hoja: ¿vino en la app o se bajó? Mientras se baja: avance (0..1).
    var aiInstalled by remember { mutableStateOf(DocScanAiPack.missing(context).isEmpty()) }
    var aiAsk by remember { mutableStateOf(false) }
    // La IA de la hoja viene DENTRO de la app (GitHub la pone al compilar y no deja
    // compilar sin ella): no se pregunta ni se baja nada.
    val aiPaint = remember {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
    }
    var bitmapPageId by remember { mutableIntStateOf(-1) }
    var loadingPage by remember { mutableStateOf(false) }
    var analyzing by remember { mutableStateOf(false) }
    var analyzeStep by remember { mutableStateOf("Leyendo el texto…") }

    // Hoja lista para mostrar (una sola imagen: fondo + logos + texto).
    var sheet by remember { mutableStateOf<ImageBitmap?>(null) }
    var sheetKey by remember { mutableStateOf(DocScanSheetKey(-1, -1, -1)) }

    // Zoom: si se está moviendo, y la última posición quieta (escala, x, y).
    var zoomMoving by remember { mutableStateOf(false) }
    var settled by remember { mutableStateOf(Triple(1f, 0f, 0f)) }
    // Pedazo nítido (zoom) de lo que se ve, y dónde va (píxeles de la hoja encajada).
    var detail by remember { mutableStateOf<ImageBitmap?>(null) }
    var detailRect by remember { mutableStateOf<Rect?>(null) }
    var detailPage by remember { mutableIntStateOf(-1) }

    var selection by remember { mutableStateOf<DocScanSel?>(null) }
    var newTextId by remember { mutableIntStateOf(-1) }
    // Donde se tocó el párrafo (para poner el cursor ahí), en píxeles de la hoja encajada.
    var tapAt by remember { mutableStateOf<Offset?>(null) }
    // Último toque para escribir (no se borra): para correr la hoja lo mínimo al salir el teclado.
    var lastWriteTap by remember { mutableStateOf<Offset?>(null) }
    // Doble toque en el párrafo que se escribe: elegir esa palabra.
    var wordTapAt by remember { mutableStateOf<Offset?>(null) }
    // Mover: con pulsación larga (pressMoving) o con la manija mientras se escribe (handleMoving).
    var pressMoving by remember { mutableStateOf(false) }
    var handleMoving by remember { mutableStateOf(false) }
    var dragPreview by remember { mutableStateOf(Offset.Zero) }
    // Firma o imagen elegida: agrandar y girar en vivo (con dos dedos o con sus manijas).
    var transformScale by remember { mutableFloatStateOf(1f) }
    var transformTurn by remember { mutableFloatStateOf(0f) }
    // Estirar un cuadro de texto: ancho al empezar y lo arrastrado (píxeles de la foto).
    var resizeBase by remember { mutableFloatStateOf(0f) }
    var resizeDelta by remember { mutableFloatStateOf(0f) }
    var showColors by remember { mutableStateOf(false) }
    // Letra y tamaño de hoja: solo al escribir (botón "Aa").
    var showFonts by remember { mutableStateOf(false) }
    // Preguntar si la hoja es foto de cámara o imagen limpia.
    var modeAsk by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    var showText by remember { mutableStateOf(false) }
    var showSignature by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var textPaid by remember { mutableStateOf(false) }
    var flingJob by remember { mutableStateOf<Job?>(null) }

    val zoom = remember { DocScanZoomState() }
    val measurePaint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }
    val layoutPaint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }
    val livePaint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }
    val textPaths = remember { DocScanTextPaths() }
    val fieldFocus = remember { FocusRequester() }
    val cellFocus = remember { FocusRequester() }
    val filterMatrix = remember(filter) { docScanFilterMatrix(filter) }
    val composeFilter = remember(filterMatrix) { filterMatrix?.let { ColorFilter.colorMatrix(ColorMatrix(it)) } }
    val liveColorFilter = remember(filterMatrix) { filterMatrix?.let { android.graphics.ColorMatrixColorFilter(it) } }

    val analysis = analyses[currentPage.id]
    val currentEdits = edits[currentPage.id] ?: DocScanPageEdits()
    // Palabras dudosas de esta página (para "Revisar"): se buscan aparte, sin trabar la pantalla.
    var doubts by remember { mutableStateOf<List<DocScanDoubt>>(emptyList()) }
    var reviewList by remember { mutableStateOf<List<DocScanDoubt>?>(null) }
    LaunchedEffect(analysis, currentEdits) {
        val read = analysis
        doubts = if (read == null || read.failed) emptyList() else runCatching {
            withContext(Dispatchers.Default) { docScanDoubts(read, currentEdits, DocScanWords.get(context)) }
        }.getOrElse {
            if (it is kotlinx.coroutines.CancellationException) throw it
            emptyList()
        }
    }
    val shownBitmap = pageBitmap.takeIf { bitmapPageId == currentPage.id }
    val shownCleaned = cleaned.takeIf { cleanPageId == currentPage.id }
    val pieces = shownCleaned?.objects.orEmpty()
    // La hoja armada (texto de verdad) se recalcula solo cuando cambia un párrafo.
    val pageLayout = remember(analysis, currentEdits.blocks, currentEdits.tables, fontChoice) {
        analysis?.takeIf { it.blocks.isNotEmpty() || it.tables.isNotEmpty() }
            ?.let { docScanLayout(it, currentEdits.blocks, fontChoice, layoutPaint, currentEdits.tables) }
    }
    val tableShapes = pageLayout?.tableShapes.orEmpty()
    val addedFamily = docScanAddedFamily(analysis, fontChoice)
    val paperLabel = analysis?.let {
        val paper = if (paperChoice >= 0) paperChoice else it.paper
        docScanPaperLabel(paper, it.landscape)
    }.orEmpty()
    val sheetReady = sheet != null && sheetKey.pageId == currentPage.id && shownCleaned != null
    // Se reconstruye cuando la hoja está lista; si no, se ve la foto.
    val rebuilt = sheetReady && !showOriginal

    // Lo elegido no va en la imagen de la hoja: se dibuja aparte (para moverlo o escribir encima).
    val selectedBlockId = (selection as? DocScanSelBlock)?.takeIf { it.pageId == currentPage.id }?.blockId ?: -1
    val selectedObjectId = (selection as? DocScanSelObject)?.takeIf { it.pageId == currentPage.id }?.objectId ?: -1
    // Una forma elegida sigue en la hoja (puede tener texto encima); solo sale mientras se arrastra.
    val movingShapeId = (selection as? DocScanSelShape)?.takeIf { it.pageId == currentPage.id && pressMoving }?.shapeId ?: -1
    val sheetShapes = shownCleaned?.shapes.orEmpty()
    val selectedTextId = (selection as? DocScanSelText)?.takeIf { it.pageId == currentPage.id }?.textId ?: -1
    val selectedBlockDeleted = selectedBlockId >= 0 && currentEdits.blocks[selectedBlockId]?.deleted == true
    // Se escribe directo encima: párrafo o texto agregado elegido (no mientras se mueve con pulsación larga).
    val writingBlock = rebuilt && selectedBlockId >= 0 && !selectedBlockDeleted && !pressMoving
    val writingText = rebuilt && selectedTextId >= 0 && !pressMoving
    val stillRuns = remember(pageLayout, selectedBlockId) {
        pageLayout?.runs?.filter { it.blockId != selectedBlockId }.orEmpty()
    }
    // Al escribir se ven las letras de la hoja (fijas, se agrandan con el zoom como todo);
    // el cuadro del teclado queda invisible y el cursor lo dibuja la hoja.
    val writingRuns = if (writingBlock) pageLayout?.runs?.filter { it.blockId == selectedBlockId }.orEmpty() else emptyList()
    val writingValue = if (writingBlock) {
        analysis?.blocks?.firstOrNull { it.id == selectedBlockId }?.let { block -> (currentEdits.blocks[block.id] ?: block.originalEdit()).text }
    } else {
        null
    }
    val writingStarts = writingValue?.let { docScanRunStarts(it, writingRuns) }
    val sheetLetters = writingBlock && writingStarts != null
    var editSelection by remember { mutableStateOf(TextRange(0)) }
    var caretOn by remember { mutableStateOf(true) }
    val caretPaint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }
    val caretMeasure = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }
    // El cursor parpadea (dos veces por segundo; al escribir se queda prendido).
    LaunchedEffect(sheetLetters, editSelection, writingValue) {
        caretOn = true
        if (!sheetLetters) return@LaunchedEffect
        while (true) {
            delay(530)
            caretOn = !caretOn
        }
    }

    // ---------------- Página actual: foto y lectura ----------------
    LaunchedEffect(currentPage.id) {
        val page = currentPage
        selection = null
        dragPreview = Offset.Zero
        pressMoving = false
        handleMoving = false
        showColors = false
        showFonts = false
        loadingPage = true
        val loaded = try {
            ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            null
        } finally {
            loadingPage = false
        }
        if (loaded == null) {
            onMessage("No se pudo abrir esta página.")
            return@LaunchedEffect
        }
        pageBitmap = loaded
        bitmapPageId = page.id
        analyzing = true
        val known = analyses[page.id]
        val (read, straight) = try {
            if (known != null) {
                known to withContext(Dispatchers.Default) { docScanStraighten(loaded, known.rotation) }
            } else {
                // Puede tardar: se lee, se endereza, se revisa de cerca y se compara la letra.
                val result = docScanAnalyze(context, loaded, page.photo, if (page.photo) null else docScanPdfText(context, page.uri, loaded.width, loaded.height)) { step -> analyzeStep = step }
                result.analysis to result.bitmap
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            // Sin memoria u otro problema: otra vez con la foto más chica (no se cierra la app).
            System.gc()
            analyzeStep = "Probando con la foto más liviana…"
            val smaller = try {
                ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_SAFE_EDGE)
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (again: Throwable) {
                null
            }
            val retry = if (smaller == null) null else try {
                if (known != null) known to withContext(Dispatchers.Default) { docScanStraighten(smaller, known.rotation) }
                else docScanAnalyze(context, smaller, page.photo, if (page.photo) null else docScanPdfText(context, page.uri, smaller.width, smaller.height)) { step -> analyzeStep = step }.let { it.analysis to it.bitmap }
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (again: Throwable) {
                null
            }
            if (retry != null && smaller != null) {
                pageBitmap = smaller
                retry
            } else {
                onMessage("No se pudo leer esta página. Puedes escribir y firmar encima igual.")
                DocScanAnalysis(loaded.width, loaded.height, emptyList(), emptyList(), failed = true) to loaded
            }
        } finally {
            analyzing = false
        }
        // Primero la foto enderezada y después la lectura (así se limpia una sola vez).
        if (straight !== loaded) pageBitmap = straight
        if (known == null) analyses[page.id] = read
    }

    // Hoja limpia: sin texto, con el papel parejo y los logos y fotos como piezas.
    val cleanSource = shownBitmap
    LaunchedEffect(cleanSource, analysis, cleanPaper, rebuildPage) {
        val source = cleanSource ?: return@LaunchedEffect
        val read = analysis ?: return@LaunchedEffect
        // Aunque no se lea texto, la hoja se limpia igual (para escribir y firmar encima).
        if (source.width != read.width || source.height != read.height) return@LaunchedEffect
        val pageId = currentPage.id
        analyzing = true
        analyzeStep = "Limpiando la hoja…"
        try {
            if (rebuildPage) analyzeStep = "Rearmando la hoja…"
            val plain = docScanCleanPage(source, read, cleanPaper, rebuildPage, currentPage.photo)
            cleanedPlain = plain
            cleaned = plain
            cleanPageId = pageId
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            // Sin hoja limpia se queda la foto original.
        } finally {
            analyzing = false
        }
    }

    // Mejorar imágenes: la hoja se ve al toque y las piezas mejoradas llegan después
    // (de la memoria del celular si ya se hicieron). Cambiar de página lo cancela.
    LaunchedEffect(cleanedPlain, enhanceMode) {
        val plain = cleanedPlain ?: return@LaunchedEffect
        val pageId = cleanPageId
        if (enhanceMode == DocScanEnhance.OFF || plain.objects.isEmpty()) {
            cleaned = plain
            enhanceStep = null
            return@LaunchedEffect
        }
        try {
            val better = DocScanEnhance.apply(context, plain, enhanceMode) { done, total ->
                if (total > 0 && done < total) enhanceStep = "Mejorando imágenes… $done de $total"
            }
            if (cleanedPlain === plain && cleanPageId == pageId) cleaned = better
            if (better === plain && DocScanEnhance.failed() && !enhanceWarned) {
                enhanceWarned = true
                onMessage("La IA de Mejorar imágenes no abrió en este celular: las imágenes quedan como están.")
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            // Sin mejora: quedan las piezas como estaban.
        } finally {
            enhanceStep = null
        }
    }

    // Imagen de la hoja: se dibuja aparte (procesador), así las letras salen
    // completas y el zoom va fluido. Escribir en un párrafo no la rehace.
    val sheetObjects = currentEdits.objects
    val shapeEdits = currentEdits.shapes
    LaunchedEffect(shownCleaned, analysis, stillRuns, sheetObjects, selectedObjectId, shapeEdits, movingShapeId, tableShapes) {
        val clean = shownCleaned ?: return@LaunchedEffect
        val read = analysis ?: return@LaunchedEffect
        val pageId = currentPage.id
        val hiddenBlock = selectedBlockId
        val hiddenObject = selectedObjectId
        val hiddenShape = movingShapeId
        val shapesNow = shapeEdits
        val runs = stillRuns
        val tablesNow = tableShapes
        val rendered = withContext(Dispatchers.Default) {
            runCatching {
                docScanRenderSheet(clean, read.width, read.height, runs, sheetObjects, hiddenObject, shapesNow, hiddenShape, tablesNow)
            }.getOrNull()
        }
        if (rendered != null) {
            sheet = rendered.asImageBitmap()
            sheetKey = DocScanSheetKey(pageId, hiddenBlock, hiddenObject, hiddenShape)
        }
    }

    // Miniaturas para cambiar de página.
    LaunchedEffect(pages) {
        if (pages.size < 2) return@LaunchedEffect
        for (page in pages) {
            if (thumbs.containsKey(page.id)) continue
            val small = runCatching { ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_THUMB_EDGE) }.getOrNull() ?: continue
            thumbs[page.id] = small.asImageBitmap()
        }
    }

    // ---------------- Cambios y deshacer ----------------
    fun commit(next: Map<Int, DocScanPageEdits>, typing: String? = null) {
        if (next == edits) return
        val now = SystemClock.elapsedRealtime()
        val sameTyping = typing != null && typing == typingKey && now - typingAt < DOC_SCAN_TYPING_PAUSE_MS
        if (!sameTyping) undoStack = (undoStack + listOf(edits)).takeLast(DOC_SCAN_UNDO_LIMIT)
        redoStack = emptyList()
        typingKey = typing
        typingAt = now
        edits = next
    }

    fun updatePage(pageId: Int, typing: String? = null, change: (DocScanPageEdits) -> DocScanPageEdits) {
        val updated = change(edits[pageId] ?: DocScanPageEdits())
        commit(if (updated.isEmpty) edits - pageId else edits + (pageId to updated), typing)
    }

    fun undo() {
        val previous = undoStack.lastOrNull() ?: return
        undoStack = undoStack.dropLast(1)
        redoStack = (redoStack + listOf(edits)).takeLast(DOC_SCAN_UNDO_LIMIT)
        typingKey = null
        edits = previous
    }

    fun redo() {
        val next = redoStack.lastOrNull() ?: return
        redoStack = redoStack.dropLast(1)
        undoStack = (undoStack + listOf(edits)).takeLast(DOC_SCAN_UNDO_LIMIT)
        typingKey = null
        edits = next
    }

    fun setBlockEdit(pageId: Int, block: DocScanBlock, edit: DocScanBlockEdit, typing: Boolean = false) {
        updatePage(pageId, if (typing) "block:$pageId:${block.id}" else null) { page ->
            val blocks = if (edit == block.originalEdit()) page.blocks - block.id else page.blocks + (block.id to edit)
            page.copy(blocks = blocks)
        }
    }

    fun setAddedText(pageId: Int, textId: Int, typing: Boolean = false, update: (DocScanAddedText) -> DocScanAddedText) {
        updatePage(pageId, if (typing) "text:$pageId:$textId" else null) { page ->
            page.copy(texts = page.texts.map { if (it.id == textId) update(it) else it })
        }
    }

    fun setTableEdit(pageId: Int, table: DocScanTable, typing: String? = null, change: (DocScanTableEdit) -> DocScanTableEdit) {
        updatePage(pageId, typing) { page ->
            val original = DocScanTableEdit(table.data)
            val next = change(page.tables[table.id] ?: original)
            page.copy(tables = if (next == original) page.tables - table.id else page.tables + (table.id to next))
        }
    }

    fun deselect() {
        selection = null
        showColors = false
        showFonts = false
        tapAt = null
        lastWriteTap = null
        pressMoving = false
        handleMoving = false
        dragPreview = Offset.Zero
        focusManager.clearFocus()
    }

    // ---------------- Toques en la hoja ----------------
    fun hitTest(point: Offset): DocScanSel? {
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (width <= 0f || height <= 0f) return null
        val slack = 10f / zoom.scale
        currentEdits.signs.asReversed().firstOrNull { sign ->
            docScanTurnedContains(docScanSignRect(sign, width, height), sign.rotation, point.x, point.y, slack)
        }?.let { return DocScanSelSign(currentPage.id, it.id) }
        currentEdits.texts.asReversed().firstOrNull { text ->
            docScanAddedBounds(text, width, height, addedFamily, measurePaint).apply { inset(-slack, -slack) }.contains(point.x, point.y)
        }?.let { return DocScanSelText(currentPage.id, it.id) }
        val read = analysis ?: return null
        val scaleX = width / read.width.coerceAtLeast(1)
        val scaleY = height / read.height.coerceAtLeast(1)
        var best: DocScanPlacedBlock? = null
        var bestArea = Float.MAX_VALUE
        for (block in pageLayout?.blocks.orEmpty()) {
            val rect = RectF(block.rect.left * scaleX, block.rect.top * scaleY, block.rect.right * scaleX, block.rect.bottom * scaleY)
            rect.inset(-slack, -slack * 0.6f)
            if (rect.contains(point.x, point.y)) {
                val area = rect.width() * rect.height()
                if (area < bestArea) {
                    best = block
                    bestArea = area
                }
            }
        }
        best?.let { return DocScanSelBlock(currentPage.id, it.id) }
        // Tablas: la celda tocada.
        for (table in pageLayout?.tables.orEmpty()) {
            val cell = table.cellAt(point.x / scaleX, point.y / scaleY) ?: continue
            return DocScanSelTable(currentPage.id, table.id, cell.row, cell.col)
        }
        // Logos y fotos (están debajo del texto).
        val piece = pieces.asReversed().firstOrNull { item ->
            val edit = currentEdits.objects[item.id]
            if (edit?.deleted == true) return@firstOrNull false
            val rect = docScanObjectRect(item.rect, edit)
            docScanTurnedContains(
                RectF(rect.left * scaleX, rect.top * scaleY, rect.right * scaleX, rect.bottom * scaleY),
                edit?.rotation ?: 0f, point.x, point.y, slack
            )
        }
        piece?.let { return DocScanSelObject(currentPage.id, it.id) }
        // Barras, recuadros y líneas (lo de más abajo).
        val shape = sheetShapes.asReversed().firstOrNull { item ->
            val edit = currentEdits.shapes[item.id]
            if (edit?.deleted == true) return@firstOrNull false
            val rect = docScanShapeRect(item, edit)
            RectF(rect.left * scaleX, rect.top * scaleY, rect.right * scaleX, rect.bottom * scaleY)
                .apply { inset(-slack * 1.5f, -slack * 1.5f) }.contains(point.x, point.y)
        }
        return shape?.let { DocScanSelShape(currentPage.id, it.id) }
    }

    // Cajas (en píxeles de la foto) para las guías al mover.
    fun boxOf(sel: DocScanSel, read: DocScanAnalysis): ScanGuides.Box? {
        val pageWidth = read.width.toFloat()
        val pageHeight = read.height.toFloat()
        val rect: RectF = when (sel) {
            is DocScanSelBlock -> pageLayout?.block(sel.blockId)?.rect ?: return null
            is DocScanSelObject -> {
                val piece = pieces.firstOrNull { it.id == sel.objectId } ?: return null
                val edit = currentEdits.objects[piece.id]
                docScanTurnedBounds(docScanObjectRect(piece.rect, edit), edit?.rotation ?: 0f)
            }
            is DocScanSelText -> currentEdits.texts.firstOrNull { it.id == sel.textId }
                ?.let { docScanAddedBounds(it, pageWidth, pageHeight, addedFamily, measurePaint) } ?: return null
            is DocScanSelSign -> currentEdits.signs.firstOrNull { it.id == sel.signId }
                ?.let { docScanTurnedBounds(docScanSignRect(it, pageWidth, pageHeight), it.rotation) } ?: return null
            is DocScanSelShape -> sheetShapes.firstOrNull { it.id == sel.shapeId }
                ?.let { docScanShapeRect(it, currentEdits.shapes[it.id]) } ?: return null
            is DocScanSelTable -> pageLayout?.table(sel.tableId)?.rect ?: return null
        }
        return ScanGuides.Box(rect.left, rect.top, rect.right, rect.bottom)
    }

    fun otherBoxes(sel: DocScanSel, read: DocScanAnalysis): List<ScanGuides.Box> {
        val pageWidth = read.width.toFloat()
        val pageHeight = read.height.toFloat()
        val result = ArrayList<ScanGuides.Box>()
        for (block in pageLayout?.blocks.orEmpty()) {
            if (block.deleted || block.text.isBlank()) continue
            if (sel is DocScanSelBlock && sel.blockId == block.id) continue
            result += ScanGuides.Box(block.rect.left, block.rect.top, block.rect.right, block.rect.bottom)
        }
        for (piece in pieces) {
            val edit = currentEdits.objects[piece.id]
            if (edit?.deleted == true) continue
            if (sel is DocScanSelObject && sel.objectId == piece.id) continue
            val rect = docScanTurnedBounds(docScanObjectRect(piece.rect, edit), edit?.rotation ?: 0f)
            result += ScanGuides.Box(rect.left, rect.top, rect.right, rect.bottom)
        }
        for (text in currentEdits.texts) {
            if (sel is DocScanSelText && sel.textId == text.id) continue
            val rect = docScanAddedBounds(text, pageWidth, pageHeight, addedFamily, measurePaint)
            result += ScanGuides.Box(rect.left, rect.top, rect.right, rect.bottom)
        }
        for (sign in currentEdits.signs) {
            if (sel is DocScanSelSign && sel.signId == sign.id) continue
            val rect = docScanTurnedBounds(docScanSignRect(sign, pageWidth, pageHeight), sign.rotation)
            result += ScanGuides.Box(rect.left, rect.top, rect.right, rect.bottom)
        }
        for (shape in sheetShapes) {
            val edit = currentEdits.shapes[shape.id]
            if (edit?.deleted == true) continue
            if (sel is DocScanSelShape && sel.shapeId == shape.id) continue
            val rect = docScanShapeRect(shape, edit)
            result += ScanGuides.Box(rect.left, rect.top, rect.right, rect.bottom)
        }
        for (table in pageLayout?.tables.orEmpty()) {
            if (table.deleted) continue
            if (sel is DocScanSelTable && sel.tableId == table.id) continue
            val rect = table.rect
            result += ScanGuides.Box(rect.left, rect.top, rect.right, rect.bottom)
        }
        return result
    }

    val guideThresholdPx = with(density) { 9.dp.toPx() }

    /** Imán para un arrastre [raw] (píxeles de la hoja encajada). Resultado en píxeles de la foto. */
    fun snapFor(raw: Offset): ScanGuides.Snap? {
        val sel = selection ?: return null
        val read = analysis ?: return null
        if (zoom.contentWidth <= 0f) return null
        val k = zoom.contentWidth / read.width.coerceAtLeast(1)
        val box = boxOf(sel, read) ?: return null
        val threshold = guideThresholdPx / (k * zoom.scale)
        return ScanGuides.snap(
            box, raw.x / k, raw.y / k, otherBoxes(sel, read),
            read.width.toFloat(), read.height.toFloat(), read.margins, threshold
        )
    }

    /** Arrastre ya con imán, en píxeles de la hoja encajada. */
    fun snappedOffset(raw: Offset): Offset {
        if (raw == Offset.Zero) return Offset.Zero
        val read = analysis ?: return raw
        val snap = snapFor(raw) ?: return raw
        val k = zoom.contentWidth / read.width.coerceAtLeast(1)
        return Offset(snap.dx * k, snap.dy * k)
    }

    val handleTap: (Offset) -> Unit = { screen ->
        if (!rebuilt) {
            if (analyzing) onMessage("Espera un momento: se está preparando la hoja.")
        } else {
            val content = zoom.toContent(screen)
            val hit = hitTest(content)
            if (hit == null) {
                deselect()
            } else {
                if (hit != selection) {
                    showColors = false
                    showFonts = false
                    selection = hit
                }
                tapAt = content
                lastWriteTap = content
            }
        }
    }
    // Doble toque: sobre el párrafo que se escribe, elige la palabra (como en Word);
    // en otro lado, acerca o aleja.
    val handleDoubleTap: (Offset) -> Unit = { screen ->
        val content = zoom.toContent(screen)
        val sel = selection
        val onWriting = rebuilt && (sel is DocScanSelBlock || sel is DocScanSelText) && hitTest(content) == sel
        if (onWriting) {
            tapAt = null
            wordTapAt = content
        } else {
            scope.launch { zoom.toggleAt(screen) }
        }
    }
    // Mantener presionado: se elige y se mueve (con guías para alinear).
    val handleLongPress: (Offset) -> Boolean = { point ->
        val hit = if (rebuilt) hitTest(point) else null
        val movable = when (hit) {
            null -> false
            is DocScanSelBlock -> currentEdits.blocks[hit.blockId]?.deleted != true
            is DocScanSelObject -> currentEdits.objects[hit.objectId]?.deleted != true
            is DocScanSelShape -> currentEdits.shapes[hit.shapeId]?.deleted != true
            is DocScanSelTable -> currentEdits.tables[hit.tableId]?.deleted != true
            else -> true
        }
        if (hit != null && movable) {
            focusManager.clearFocus()
            showColors = false
            showFonts = false
            tapAt = null
            lastWriteTap = null
            selection = hit
            dragPreview = Offset.Zero
            pressMoving = true
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            true
        } else {
            false
        }
    }
    val onItemDrag: (Offset) -> Unit = { delta -> dragPreview += delta }
    val onItemDragEnd: () -> Unit = {
        val raw = dragPreview
        val wasPress = pressMoving
        val sel = selection
        val read = analysis
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (sel != null && width > 0f && height > 0f && (abs(raw.x) > 0.5f || abs(raw.y) > 0.5f)) {
            // Movimiento final en píxeles de la foto (con el imán de las guías).
            val snap = snapFor(raw)
            var moveX: Float
            var moveY: Float
            if (snap != null && read != null) {
                moveX = snap.dx
                moveY = snap.dy
            } else {
                moveX = raw.x / width * (read?.width ?: 1)
                moveY = raw.y / height * (read?.height ?: 1)
            }
            val pageWidth = (read?.width ?: 1).toFloat()
            val pageHeight = (read?.height ?: 1).toFloat()
            // Nada se sale de la hoja: se frena en el borde.
            val box = if (read != null) boxOf(sel, read) else null
            if (box != null) {
                fun keep(move: Float, start: Float, end: Float, size: Float): Float {
                    val low = -start
                    val high = size - end
                    return if (low <= high) move.coerceIn(low, high) else move
                }
                moveX = keep(moveX, box.left, box.right, pageWidth)
                moveY = keep(moveY, box.top, box.bottom, pageHeight)
            }
            when (sel) {
                is DocScanSelText -> setAddedText(sel.pageId, sel.textId) {
                    it.copy(
                        x = (it.x + moveX / pageWidth).coerceIn(-0.2f, 0.98f),
                        y = (it.y + moveY / pageHeight).coerceIn(0.01f, 1.1f)
                    )
                }
                is DocScanSelSign -> updatePage(sel.pageId) { page ->
                    page.copy(signs = page.signs.map { if (it.id == sel.signId) it.movedBy(moveX / pageWidth, moveY / pageHeight) else it })
                }
                is DocScanSelBlock -> {
                    val block = read?.blocks?.firstOrNull { it.id == sel.blockId }
                    if (block != null) {
                        val edit = currentEdits.blocks[block.id] ?: block.originalEdit()
                        setBlockEdit(sel.pageId, block, edit.copy(dx = edit.dx + moveX, dy = edit.dy + moveY))
                    }
                }
                is DocScanSelShape -> updatePage(sel.pageId) { page ->
                    val edit = page.shapes[sel.shapeId] ?: DocScanShapeEdit()
                    page.copy(shapes = page.shapes + (sel.shapeId to edit.copy(dx = edit.dx + moveX, dy = edit.dy + moveY)))
                }
                is DocScanSelObject -> updatePage(sel.pageId) { page ->
                    val edit = page.objects[sel.objectId] ?: DocScanObjectEdit()
                    page.copy(objects = page.objects + (sel.objectId to edit.copy(dx = edit.dx + moveX, dy = edit.dy + moveY)))
                }
                is DocScanSelTable -> {
                    val table = read?.tables?.firstOrNull { it.id == sel.tableId }
                    if (table != null) setTableEdit(sel.pageId, table) { it.copy(dx = it.dx + moveX, dy = it.dy + moveY) }
                }
            }
        }
        dragPreview = Offset.Zero
        pressMoving = false
        handleMoving = false
        // Un texto movido con pulsación larga se suelta (se toca para escribir).
        if (wasPress && (sel is DocScanSelBlock || sel is DocScanSelText)) deselect()
    }
    // ---- Firma e imagen: mover con un dedo, agrandar y girar (dedos o manijas) ----
    // Modo del dedo que tocó: 0 nada, 1 mover, 2 manija de tamaño (esquina), 3 manija de giro (arriba).
    val grabAt = remember { DocScanGrab() }

    /** Caja sin girar y giro de la firma o imagen elegida (píxeles de la hoja encajada). */
    fun grabbedBox(): Pair<RectF, Float>? {
        val sel = selection ?: return null
        if (sel.pageId != currentPage.id) return null
        if (sel !is DocScanSelSign && sel !is DocScanSelObject) return null
        if (sel is DocScanSelObject && currentEdits.objects[sel.objectId]?.deleted == true) return null
        val rect = docScanSelectionRect(
            sel, currentPage.id, pageLayout, pieces, currentEdits, zoom.contentWidth, zoom.contentHeight,
            addedFamily, measurePaint, sheetShapes
        ) ?: return null
        return rect to docScanSelectionTurn(sel, currentEdits)
    }

    /** Dónde están las manijas (esquina y giro), ya giradas, en píxeles de la hoja encajada. */
    fun handlePoints(rect: RectF, turn: Float): Pair<Offset, Offset> {
        val pad = with(density) { 3.dp.toPx() } / zoom.scale
        val stem = with(density) { 26.dp.toPx() } / zoom.scale
        val center = Offset(rect.centerX(), rect.centerY())
        fun turned(x: Float, y: Float): Offset {
            val radians = Math.toRadians(turn.toDouble())
            val dx = x - center.x
            val dy = y - center.y
            return Offset(
                center.x + (dx * kotlin.math.cos(radians) - dy * kotlin.math.sin(radians)).toFloat(),
                center.y + (dx * kotlin.math.sin(radians) + dy * kotlin.math.cos(radians)).toFloat()
            )
        }
        return turned(rect.right + pad, rect.bottom + pad) to turned(rect.centerX(), rect.top - pad - stem)
    }

    fun grabModeAt(point: Offset): Int {
        val (rect, turn) = grabbedBox() ?: return 0
        val (corner, knob) = handlePoints(rect, turn)
        val reach = with(density) { 22.dp.toPx() } / zoom.scale
        grabAt.center = Offset(rect.centerX(), rect.centerY())
        grabAt.start = point
        return when {
            (point - knob).getDistance() <= reach -> 3
            (point - corner).getDistance() <= reach -> 2
            docScanTurnedContains(rect, turn, point.x, point.y, with(density) { 8.dp.toPx() } / zoom.scale) -> 1
            else -> 0
        }
    }
    val handleGrab: (Offset) -> Int = grab@{ point ->
        if (!rebuilt) return@grab 0
        transformScale = 1f
        transformTurn = 0f
        dragPreview = Offset.Zero
        // Comparar: el dedo cerca de la línea la arrastra (a la izquierda la foto).
        compareAt?.let { at ->
            val reach = with(density) { 30.dp.toPx() } / zoom.scale
            if (zoom.contentWidth > 0f && kotlin.math.abs(point.x - at * zoom.contentWidth) <= reach) return@grab 4
        }
        val mode = grabModeAt(point)
        if (mode != 0) return@grab mode
        // Una firma se arrastra de una vez (sin tener que elegirla antes).
        val hit = hitTest(point)
        if (hit is DocScanSelSign) {
            focusManager.clearFocus()
            showColors = false
            showFonts = false
            tapAt = null
            lastWriteTap = null
            selection = hit
            return@grab 1.also { grabModeAt(point) }
        }
        0
    }
    // Un dedo sobre la manija: tamaño (distancia al centro) o giro (ángulo alrededor del centro).
    val handleGrabMove: (Int, Offset) -> Unit = move@{ mode, point ->
        if (mode == 4) {
            if (zoom.contentWidth > 0f) compareAt = (point.x / zoom.contentWidth).coerceIn(0f, 1f)
            return@move
        }
        val from = grabAt.start - grabAt.center
        val to = point - grabAt.center
        if (mode == 2) {
            val start = from.getDistance().coerceAtLeast(1f)
            transformScale = (to.getDistance() / start).coerceIn(0.1f, 8f)
        } else if (mode == 3) {
            val a0 = kotlin.math.atan2(from.y, from.x)
            val a1 = kotlin.math.atan2(to.y, to.x)
            transformTurn = Math.toDegrees((a1 - a0).toDouble()).toFloat()
        }
    }
    // Dos dedos sobre lo elegido: se agranda y gira junto con los dedos.
    val handleGrabPinch: (Float, Float) -> Unit = { zoomChange, rotationChange ->
        transformScale = (transformScale * zoomChange).coerceIn(0.1f, 8f)
        transformTurn += rotationChange
    }
    val handleGrabEnd: () -> Unit = {
        val sel = selection
        val scale = transformScale
        val turn = transformTurn
        val ratio = if (zoom.contentWidth > 0f) zoom.contentHeight / zoom.contentWidth else 1.4142f
        if (sel != null && (scale != 1f || turn != 0f)) {
            when (sel) {
                is DocScanSelSign -> updatePage(sel.pageId) { page ->
                    page.copy(signs = page.signs.map {
                        if (it.id != sel.signId) it else {
                            var sign = it
                            if (scale != 1f) sign = sign.resizedBy(scale, ratio)
                            if (turn != 0f) sign = sign.turnedBy(turn)
                            sign
                        }
                    })
                }
                is DocScanSelObject -> updatePage(sel.pageId) { page ->
                    val edit = page.objects[sel.objectId] ?: DocScanObjectEdit()
                    page.copy(objects = page.objects + (sel.objectId to edit.copy(
                        scale = (edit.scale * scale).coerceIn(0.1f, 8f),
                        rotation = docScanNormalAngle(edit.rotation + turn)
                    )))
                }
                else -> Unit
            }
        }
        transformScale = 1f
        transformTurn = 0f
        // Lo movido (con imán de guías), igual que al arrastrar.
        onItemDragEnd()
    }
    val latestGrab by rememberUpdatedState(handleGrab)
    val latestGrabMove by rememberUpdatedState(handleGrabMove)
    val latestGrabPinch by rememberUpdatedState(handleGrabPinch)
    val latestGrabEnd by rememberUpdatedState(handleGrabEnd)
    val latestTap by rememberUpdatedState(handleTap)
    val latestDoubleTap by rememberUpdatedState(handleDoubleTap)
    val latestLongPress by rememberUpdatedState(handleLongPress)
    val latestDrag by rememberUpdatedState(onItemDrag)
    val latestDragEnd by rememberUpdatedState(onItemDragEnd)

    // ---------------- Agregar ----------------
    fun addText() {
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (width <= 0f || height <= 0f) return
        val center = zoom.visibleCenter()
        val lines = analysis?.lines.orEmpty()
        val pageHeight = (analysis?.height ?: 1).coerceAtLeast(1).toFloat()
        val heights = lines.map { (it.bottom - it.top) / pageHeight }.sorted()
        val size = if (heights.isEmpty()) 0.022f else (heights[heights.size / 2] * 0.95f).coerceIn(0.008f, 0.08f)
        // Color de letra más común de la hoja (la tinta "del medio" por brillo).
        val inks = lines.map { it.ink }.sortedBy {
            android.graphics.Color.red(it) * 299 + android.graphics.Color.green(it) * 587 + android.graphics.Color.blue(it) * 114
        }
        val color = if (inks.isEmpty()) android.graphics.Color.BLACK else inks[inks.size / 2]
        val id = (currentEdits.texts.maxOfOrNull { it.id } ?: 0) + 1
        // Empieza en el margen izquierdo de la hoja (alineado con el texto).
        val marginX = analysis?.let { it.margins.left / it.width.coerceAtLeast(1) } ?: 0.1f
        val x = marginX.coerceIn(0.02f, 0.9f)
        val y = (center.y / height).coerceIn(0.05f, 0.97f)
        updatePage(currentPage.id) { it.copy(texts = it.texts + DocScanAddedText(id, x, y, "Texto", size, color)) }
        newTextId = id
        tapAt = null
        lastWriteTap = null
        selection = DocScanSelText(currentPage.id, id)
    }

    fun addSign(bitmap: Bitmap) {
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (width <= 0f || height <= 0f || bitmap.width < 2) return
        val center = zoom.visibleCenter()
        val signWidth = 0.32f
        val signHeight = signWidth * width * bitmap.height / bitmap.width / height
        val id = (currentEdits.signs.maxOfOrNull { it.id } ?: 0) + 1
        updatePage(currentPage.id) {
            it.copy(
                signs = it.signs + DocScanSign(
                    id,
                    (center.x / width - signWidth / 2f).coerceIn(0f, 1f - signWidth),
                    (center.y / height - signHeight / 2f).coerceIn(0f, 0.95f),
                    signWidth,
                    bitmap
                )
            )
        }
        selection = DocScanSelSign(currentPage.id, id)
    }

    fun setObjectEdit(pageId: Int, objectId: Int, edit: DocScanObjectEdit) {
        updatePage(pageId) { page ->
            page.copy(objects = if (edit == DocScanObjectEdit()) page.objects - objectId else page.objects + (objectId to edit))
        }
    }

    // Imagen de la galería: se pega como una pieza que se mueve y se agranda.
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val image = runCatching { ToolFileUtils.loadBitmap(context, uri, 1400) }.getOrNull()
                if (image == null) onMessage("No se pudo abrir la imagen.") else addSign(image)
            }
        }
    }

    // ---------------- Guardar ----------------
    fun runSave(output: Uri, format: Int) {
        if (saving) return
        saving = true
        val pagesNow = pages
        val pageIds = pagesNow.map { it.id }.toSet()
        val editsNow = edits.filterKeys { it in pageIds }
        val known = analyses.toMap()
        val page = currentPage
        val fontNow = fontChoice
        val paperNow = paperChoice
        val cleanNow = cleanPaper
        val rebuildNow = rebuildPage
        val enhanceNow = enhanceMode
        val matrix = filterMatrix
        scope.launch {
            var tablesSaved = -1
            val result = runPaidTool(viewModel, tool) {
                withContext(Dispatchers.IO) {
                    val stream = context.contentResolver.openOutputStream(output, "w") ?: error("No se pudo crear el archivo.")
                    stream.use { out ->
                        when (format) {
                            DOC_SCAN_FORMAT_PDF -> docScanWritePdf(context, out, pagesNow, known, editsNow, fontNow, paperNow, cleanNow, matrix, rebuildNow, enhanceNow)
                            DOC_SCAN_FORMAT_PDF_PHOTO -> docScanWritePdf(
                                context, out, pagesNow, known, editsNow, fontNow, paperNow, cleanNow, null, rebuildNow, enhanceNow, photoLayer = true
                            )
                            DOC_SCAN_FORMAT_WORD_SHEET -> docScanWriteDocxSheet(
                                context, out, pagesNow, known, editsNow, fontNow, paperNow, cleanNow, matrix, rebuildNow, enhanceNow
                            )
                            DOC_SCAN_FORMAT_EXCEL -> {
                                val all = docScanEnsureAnalyses(context, pagesNow, known)
                                tablesSaved = docScanWriteXlsx(out, pagesNow, all, editsNow, fontNow, paperNow)
                            }
                            DOC_SCAN_FORMAT_WORD -> docScanWriteDocxSheet(
                                context, out, pagesNow, known, editsNow, fontNow, paperNow, cleanNow, matrix, rebuildNow, enhanceNow, flow = true
                            )
                            else -> docScanWriteImage(
                                context,
                                out,
                                page,
                                known[page.id],
                                editsNow[page.id] ?: DocScanPageEdits(),
                                fontNow,
                                cleanNow,
                                matrix,
                                rebuildNow,
                                enhanceNow
                            )
                        }
                    }
                }
            }
            saving = false
            val label = when (format) {
                DOC_SCAN_FORMAT_PDF, DOC_SCAN_FORMAT_PDF_PHOTO -> "PDF guardado."
                DOC_SCAN_FORMAT_WORD, DOC_SCAN_FORMAT_WORD_SHEET -> "Word guardado."
                DOC_SCAN_FORMAT_EXCEL -> if (tablesSaved == 0) "Excel guardado. No había tablas: va el texto, un párrafo por fila." else "Excel guardado."
                else -> "Imagen guardada."
            }
            result
                .onSuccess { onMessage(successMessage(label, it)) }
                .onFailure { onMessage(it.message ?: "No se pudo guardar el archivo.") }
        }
    }

    val savePdf = rememberLauncherForActivityResult(TrackedCreateDocument("application/pdf")) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_PDF)
    }
    val savePdfPhoto = rememberLauncherForActivityResult(TrackedCreateDocument("application/pdf")) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_PDF_PHOTO)
    }
    val saveWord = rememberLauncherForActivityResult(TrackedCreateDocument(DOC_SCAN_DOCX_MIME)) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_WORD)
    }
    val saveWordSheet = rememberLauncherForActivityResult(TrackedCreateDocument(DOC_SCAN_DOCX_MIME)) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_WORD_SHEET)
    }
    val saveExcel = rememberLauncherForActivityResult(TrackedCreateDocument(DOC_SCAN_XLSX_MIME)) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_EXCEL)
    }
    val saveImage = rememberLauncherForActivityResult(TrackedCreateDocument("image/jpeg")) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_IMAGE)
    }

    fun chooseFormat(format: Int) {
        showSave = false
        val stamp = System.currentTimeMillis() / 1000
        launchPaidExport(viewModel, tool, onMessage) {
            when (format) {
                DOC_SCAN_FORMAT_PDF -> savePdf.launch("Escaneo_$stamp.pdf")
                DOC_SCAN_FORMAT_PDF_PHOTO -> savePdfPhoto.launch("Escaneo_foto_$stamp.pdf")
                DOC_SCAN_FORMAT_WORD -> saveWord.launch("Escaneo_$stamp.docx")
                DOC_SCAN_FORMAT_WORD_SHEET -> saveWordSheet.launch("Escaneo_$stamp.docx")
                DOC_SCAN_FORMAT_EXCEL -> saveExcel.launch("Escaneo_$stamp.xlsx")
                else -> saveImage.launch("Escaneo_${stamp}_p$pageNumber.jpg")
            }
        }
    }

    // Copiar o compartir el texto se cobra una sola vez por documento.
    fun withPaidText(text: String, action: (String) -> Unit) {
        if (text.isBlank()) {
            onMessage("No hay texto para copiar.")
            return
        }
        if (textPaid) {
            action(text)
            return
        }
        launchPaidExport(viewModel, tool, onMessage) {
            scope.launch {
                runPaidTool(viewModel, tool) { }
                    .onSuccess {
                        textPaid = true
                        action(text)
                        onMessage(successMessage("Listo.", it))
                    }
                    .onFailure { onMessage(it.message ?: "No se pudo completar.") }
            }
        }
    }

    fun handleBack() {
        when {
            showSignature -> showSignature = false
            showText -> showText = false
            showSave -> showSave = false
            showSettings -> showSettings = false
            selection != null -> deselect()
            edits.isNotEmpty() -> confirmExit = true
            else -> onClose()
        }
    }
    BackHandler { handleBack() }

    // Al elegir un texto para escribir, sale el teclado.
    val selectionKey = selection?.let { sel ->
        when (sel) {
            is DocScanSelBlock -> "b:${sel.pageId}:${sel.blockId}"
            is DocScanSelText -> "t:${sel.pageId}:${sel.textId}"
            is DocScanSelSign -> "s:${sel.pageId}:${sel.signId}"
            is DocScanSelObject -> "o:${sel.pageId}:${sel.objectId}"
            is DocScanSelShape -> "f:${sel.pageId}:${sel.shapeId}"
            is DocScanSelTable -> "c:${sel.pageId}:${sel.tableId}:${sel.row}:${sel.col}"
        }
    }
    val wantsKeyboard = writingBlock || writingText
    LaunchedEffect(selectionKey, wantsKeyboard) {
        if (wantsKeyboard) {
            // Al siguiente cuadro (cuando el campo ya está puesto): el teclado sale al toque.
            delay(16)
            runCatching { fieldFocus.requestFocus() }
        }
    }
    // Al tocar una celda: se escribe en ella (cuadro abajo, con su teclado).
    val editingCell = rebuilt && selection is DocScanSelTable && !pressMoving
    LaunchedEffect(selectionKey, editingCell) {
        if (editingCell) {
            delay(80)
            runCatching { cellFocus.requestFocus() }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DocScanBackground)
                .imePadding()
        ) {
            // ---------------- Barra de arriba ----------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DocScanBar)
                    .statusBarsPadding()
                    .height(56.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { handleBack() }) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = DocScanInk)
                }
                Column(Modifier.weight(1f)) {
                    Text("Escáner", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Cómo se trabajó la hoja (la app lo elige; tocando se cambia).
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(NeonGreen.copy(alpha = 0.14f))
                                .clickable(enabled = !analyzing) { modeAsk = true }
                                .padding(horizontal = 6.dp, vertical = 1.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (currentPage.photo) Icons.Rounded.PhotoCamera else Icons.Rounded.Image,
                                contentDescription = null, tint = NeonGreen, modifier = Modifier.size(12.dp)
                            )
                            Spacer(Modifier.width(3.dp))
                            Text(if (currentPage.photo) "Foto" else "Imagen limpia", color = NeonGreen, fontSize = 11.sp, maxLines = 1)
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(
                            (if (pages.size > 1) "$pageNumber de ${pages.size}" else "1 página") +
                                if (paperLabel.isNotEmpty()) " · $paperLabel" else "",
                            color = DocScanMuted,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                }
                IconButton(onClick = { undo() }, enabled = undoStack.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Undo,
                        contentDescription = "Deshacer",
                        tint = if (undoStack.isNotEmpty()) DocScanInk else Color(0xFF4A5A51)
                    )
                }
                IconButton(onClick = { redo() }, enabled = redoStack.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Redo,
                        contentDescription = "Rehacer",
                        tint = if (redoStack.isNotEmpty()) DocScanInk else Color(0xFF4A5A51)
                    )
                }
                Box {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Rounded.Tune, contentDescription = "Ajustes", tint = DocScanInk)
                    }
                    DropdownMenu(expanded = showSettings, onDismissRequest = { showSettings = false }) {
                        DocScanMenuLabel("Imagen")
                        DocumentImageFilter.entries.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(docScanFilterLabel(option)) },
                                onClick = {
                                    filter = option
                                    showSettings = false
                                },
                                trailingIcon = {
                                    if (filter == option) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen)
                                }
                            )
                        }
                        HorizontalDivider()
                        if (currentPage.original != null) {
                            DropdownMenuItem(
                                text = { Text("Usar la foto sin enderezar") },
                                onClick = {
                                    showSettings = false
                                    onUseOriginal(currentPage.id)?.let { currentId = it }
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Hoja reconstruida (nueva)") },
                            onClick = {
                                rebuildPage = !rebuildPage
                                showSettings = false
                            },
                            trailingIcon = { if (rebuildPage) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen) }
                        )
                        if (!rebuildPage) {
                            DropdownMenuItem(
                                text = { Text("Foto con papel blanco") },
                                onClick = {
                                    cleanPaper = !cleanPaper
                                    showSettings = false
                                },
                                trailingIcon = { if (cleanPaper) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen) }
                            )
                        }
                        // Mejorar imágenes (logos, fotos, íconos): solo si se elige. Apagado → x2 → Original.
                        DropdownMenuItem(
                            text = { Text("Mejorar imágenes: ${DocScanEnhance.label(enhanceMode)}") },
                            onClick = {
                                enhanceMode = when (enhanceMode) {
                                    DocScanEnhance.OFF -> DocScanEnhance.X2
                                    DocScanEnhance.X2 -> DocScanEnhance.ORIGINAL
                                    else -> DocScanEnhance.OFF
                                }
                            },
                            trailingIcon = { if (enhanceMode != DocScanEnhance.OFF) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen) }
                        )
                        // IA: viene en la app. Si falta alguna, se puede bajar una vez desde aquí.
                        if (!aiInstalled) {
                            DropdownMenuItem(
                                text = { Text("Bajar IA (mejor resultado)", color = NeonGreen, fontWeight = FontWeight.Bold) },
                                onClick = {
                                    showSettings = false
                                    aiAsk = true
                                }
                            )
                        } else if (DocScanLayoutAi.lastError != null) {
                            DropdownMenuItem(
                                text = { Text("IA de la hoja: no abre en este celular") },
                                enabled = false,
                                onClick = {}
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Ver lo que reconoce la IA") },
                            onClick = {
                                showAi = !showAi
                                showSettings = false
                            },
                            trailingIcon = { if (showAi) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen) }
                        )
                        DropdownMenuItem(
                            text = { Text("Marcar los párrafos") },
                            onClick = { showBoxes = !showBoxes },
                            trailingIcon = { if (showBoxes) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen) }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Agregar páginas con la cámara") },
                            onClick = {
                                showSettings = false
                                onAddScan()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Agregar páginas de tus fotos") },
                            onClick = {
                                showSettings = false
                                onAddPhotos()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Agregar desde archivos (PDF o imagen)") },
                            onClick = {
                                showSettings = false
                                onAddFiles()
                            }
                        )
                        if (pages.size > 1) {
                            DropdownMenuItem(
                                text = { Text("Quitar esta página", color = DocScanDanger) },
                                onClick = {
                                    showSettings = false
                                    val index = pages.indexOf(currentPage)
                                    val removed = currentPage.id
                                    currentId = pages.getOrNull(index + 1)?.id ?: pages.getOrNull(index - 1)?.id ?: removed
                                    edits = edits - removed
                                    onRemovePage(removed)
                                }
                            )
                        }
                    }
                }
                Box(
                    modifier = Modifier
                        .padding(start = 2.dp, end = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (saving) Color(0xFF5E7F1A) else NeonGreen)
                        .clickable(enabled = !saving) {
                            deselect()
                            showSave = true
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        if (saving) "Guardando…" else "Guardar",
                        color = DeepGreen,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            }
            if (saving) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = NeonGreen)

            // ---------------- Hoja ----------------
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clipToBounds()
            ) {
                val viewWidth = constraints.maxWidth.toFloat()
                val viewHeight = constraints.maxHeight.toFloat()
                // El alto más grande visto: al salir el teclado la hoja no se achica, solo se mueve.
                val stableHeight = remember { FloatArray(1) }
                if (viewHeight > stableHeight[0]) stableHeight[0] = viewHeight
                val bitmap = shownBitmap
                val readablePx = with(density) { 17.sp.toPx() }

                if (bitmap != null) {
                    val margin = with(density) { 12.dp.toPx() }
                    val aspect = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
                    val contentWidth = min(viewWidth - 2f * margin, (stableHeight[0] - 2f * margin) * aspect).coerceAtLeast(10f)
                    val contentHeight = contentWidth / aspect
                    zoom.setSizes(currentPage.id, viewWidth, viewHeight, contentWidth, contentHeight)
                    val picture = remember(bitmap) { bitmap.asImageBitmap() }
                    val sheetPicture = sheet.takeIf { sheetReady }
                    // Píxeles de la foto → píxeles de la hoja encajada.
                    val k = analysis?.let { contentWidth / it.width.coerceAtLeast(1) } ?: 1f

                    // Para escribir: se mueve lo mínimo (solo si la letra es muy chica o
                    // el párrafo quedó tapado por el teclado).
                    val minPx = with(density) { 11.sp.toPx() }
                    LaunchedEffect(selectionKey, constraints.maxHeight, writingBlock, writingText) {
                        if (!writingBlock && !writingText) return@LaunchedEffect
                        // Corto: solo para que el teclado termine de abrir (cambia el alto).
                        delay(60)
                        val read = analysis ?: return@LaunchedEffect
                        val kk = zoom.contentWidth / read.width.coerceAtLeast(1)
                        if (writingBlock) {
                            val placed = pageLayout?.block(selectedBlockId) ?: return@LaunchedEffect
                            val area = Rect(
                                min(placed.areaLeft, placed.rect.left) * kk,
                                placed.rect.top * kk,
                                maxOf(placed.areaRight, placed.rect.right) * kk,
                                placed.rect.bottom * kk
                            )
                            zoom.showForEditing(area, placed.size * kk, minPx, readablePx, tapAt ?: lastWriteTap)
                        } else {
                            val text = currentEdits.texts.firstOrNull { it.id == selectedTextId } ?: return@LaunchedEffect
                            val box = docScanAddedBounds(text, zoom.contentWidth, zoom.contentHeight, addedFamily, measurePaint)
                            zoom.showForEditing(
                                Rect(box.left, box.top, box.right, box.bottom),
                                text.size * zoom.contentHeight,
                                minPx,
                                readablePx,
                                tapAt ?: lastWriteTap
                            )
                        }
                    }

                    // Zoom quieto: el cuadro de texto se muestra y se dibuja el pedazo nítido.
                    LaunchedEffect(zoom) {
                        snapshotFlow { Triple(zoom.scale, zoom.offsetX, zoom.offsetY) }.collectLatest { now ->
                            if (now == settled) {
                                zoomMoving = false
                            } else {
                                zoomMoving = true
                                delay(140)
                                settled = now
                                zoomMoving = false
                            }
                        }
                    }

                    // Pedazo nítido de lo que se ve (con zoom): texto y formas como en un lector de PDF.
                    LaunchedEffect(settled, shownCleaned, analysis, stillRuns, sheetObjects, selectedObjectId, rebuilt, shapeEdits, movingShapeId, tableShapes) {
                        val (scaleNow, offsetXNow, offsetYNow) = settled
                        val clean = shownCleaned
                        val read = analysis
                        if (!rebuilt || clean == null || read == null || scaleNow < 1.25f) {
                            detail = null
                            return@LaunchedEffect
                        }
                        val pageId = currentPage.id
                        val viewW = zoom.viewWidth
                        val viewH = zoom.viewHeight
                        val cw = zoom.contentWidth
                        val ch = zoom.contentHeight
                        if (viewW <= 0f || cw <= 0f) return@LaunchedEffect
                        // Lo que se ve (en píxeles de la hoja encajada) + un margen para mover un poco.
                        var left = -offsetXNow / scaleNow
                        var top = -offsetYNow / scaleNow
                        var right = (viewW - offsetXNow) / scaleNow
                        var bottom = (viewH - offsetYNow) / scaleNow
                        val padX = (right - left) * 0.2f
                        val padY = (bottom - top) * 0.2f
                        left = kotlin.math.floor((left - padX).coerceIn(0f, cw))
                        top = kotlin.math.floor((top - padY).coerceIn(0f, ch))
                        right = kotlin.math.ceil((right + padX).coerceIn(0f, cw))
                        bottom = kotlin.math.ceil((bottom + padY).coerceIn(0f, ch))
                        if (right - left < 2f || bottom - top < 2f) return@LaunchedEffect
                        // Tamaño de la imagen: como la pantalla (con tope de memoria).
                        var outScale = scaleNow
                        val maxPixels = 9_000_000f
                        val pixelsNeeded = (right - left) * (bottom - top) * outScale * outScale
                        if (pixelsNeeded > maxPixels) outScale *= kotlin.math.sqrt(maxPixels / pixelsNeeded)
                        val kk = cw / read.width.coerceAtLeast(1)
                        val region = RectF(left / kk, top / kk, right / kk, bottom / kk)
                        val runs = stillRuns
                        val objectsNow = sheetObjects
                        val hidden = selectedObjectId
                        val tablesNow = tableShapes
                        val rendered = withContext(Dispatchers.Default) {
                            runCatching {
                                docScanRenderDetail(
                                    clean, read.width, read.height, runs, objectsNow, hidden, region,
                                    ((right - left) * outScale).roundToInt(), ((bottom - top) * outScale).roundToInt(),
                                    shapeEdits, movingShapeId, tablesNow
                                )
                            }.getOrNull()
                        }
                        if (rendered != null) {
                            detail = rendered.asImageBitmap()
                            detailRect = Rect(left, top, right, bottom)
                            detailPage = pageId
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                // El toque se atiende al instante (sin esperar a ver si es doble).
                                // Si llega otro toque al lado enseguida, además cuenta como doble.
                                var lastTapTime = 0L
                                var lastTapPoint = Offset.Zero
                                val near = 48.dp.toPx()
                                detectTapGestures(
                                    onTap = { point ->
                                        latestTap(point)
                                        val now = System.nanoTime()
                                        val quick = now - lastTapTime < viewConfiguration.doubleTapTimeoutMillis * 1_000_000L
                                        if (quick && (point - lastTapPoint).getDistance() < near) {
                                            latestDoubleTap(point)
                                            lastTapTime = 0L
                                        } else {
                                            lastTapTime = now
                                            lastTapPoint = point
                                        }
                                    }
                                )
                            }
                            .pointerInput(zoom) {
                                // Un dedo mueve la hoja (con inercia); dos dedos acercan donde están
                                // los dedos. Mantener presionado algo lo elige y arrastrarlo lo mueve.
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false)
                                    flingJob?.cancel()
                                    // Firma o imagen elegida: el dedo encima la mueve; en sus manijas,
                                    // cambia el tamaño o la gira; con dos dedos encima, ambas cosas.
                                    val grab = latestGrab(zoom.toContent(down.position))
                                    if (grab != 0) {
                                        val slop = viewConfiguration.touchSlop
                                        var travelled = Offset.Zero
                                        var started = grab != 1
                                        if (started) down.consume()
                                        if (grab == 1) pressMoving = true
                                        while (true) {
                                            val event = awaitPointerEvent()
                                            val pressed = event.changes.filter { it.pressed }
                                            if (pressed.isEmpty()) {
                                                if (started) event.changes.forEach { it.consume() }
                                                break
                                            }
                                            val pan = event.calculatePan()
                                            if (!started) {
                                                travelled += pan
                                                if (pressed.size >= 2 || travelled.getDistance() > slop) started = true
                                            }
                                            if (!started) continue
                                            if (grab == 1) {
                                                if (pressed.size >= 2) latestGrabPinch(event.calculateZoom(), event.calculateRotation())
                                                latestDrag(Offset(pan.x / zoom.scale, pan.y / zoom.scale))
                                            } else {
                                                latestGrabMove(grab, zoom.toContent(pressed.first().position))
                                            }
                                            event.changes.forEach { it.consume() }
                                        }
                                        latestGrabEnd()
                                        return@awaitEachGesture
                                    }
                                    val tracker = VelocityTracker()
                                    tracker.addPosition(down.uptimeMillis, down.position)
                                    val slop = viewConfiguration.touchSlop
                                    var travelled = Offset.Zero
                                    var lifted = false
                                    var startedEarly = false
                                    // 1) ¿Se queda quieto el dedo (pulsación larga) o se mueve?
                                    val heldStill = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                        while (!lifted && !startedEarly) {
                                            val event = awaitPointerEvent()
                                            val pressed = event.changes.filter { it.pressed }
                                            if (pressed.isEmpty()) {
                                                lifted = true
                                            } else {
                                                travelled += event.calculatePan()
                                                if (pressed.size >= 2 || travelled.getDistance() > slop) startedEarly = true
                                                val lead = pressed.first()
                                                tracker.addPosition(lead.uptimeMillis, lead.position)
                                            }
                                        }
                                        false
                                    } == null
                                    if (!lifted) {
                                        var movingItem = heldStill && latestLongPress(zoom.toContent(down.position))
                                        var active = startedEarly || movingItem
                                        var pinched = false
                                        var pointerCount = 1
                                        while (true) {
                                            val event = awaitPointerEvent()
                                            val pressed = event.changes.filter { it.pressed }
                                            if (pressed.isEmpty()) {
                                                // Al soltar lo que se movía no cuenta como toque.
                                                if (movingItem) event.changes.forEach { it.consume() }
                                                break
                                            }
                                            if (pressed.size != pointerCount) {
                                                pointerCount = pressed.size
                                                tracker.resetTracking()
                                            }
                                            val zoomChange = event.calculateZoom()
                                            val pan = event.calculatePan()
                                            if (!active) {
                                                travelled += pan
                                                if (pressed.size >= 2 || travelled.getDistance() > slop) active = true
                                            }
                                            if (active) {
                                                if (pressed.size >= 2) {
                                                    pinched = true
                                                    if (movingItem) {
                                                        movingItem = false
                                                        latestDragEnd()
                                                    }
                                                    val centroid = event.calculateCentroid(useCurrent = true)
                                                    if (centroid.isSpecified) zoom.zoomBy(zoomChange, centroid, pan)
                                                } else if (movingItem) {
                                                    latestDrag(Offset(pan.x / zoom.scale, pan.y / zoom.scale))
                                                } else {
                                                    zoom.panBy(pan)
                                                }
                                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                                            }
                                            if (movingItem) event.changes.forEach { it.consume() }
                                            val lead = pressed.first()
                                            tracker.addPosition(lead.uptimeMillis, lead.position)
                                        }
                                        if (movingItem) {
                                            latestDragEnd()
                                        } else if (active && !pinched) {
                                            val velocity = tracker.calculateVelocity()
                                            flingJob = scope.launch { zoom.fling(velocity) }
                                        }
                                        if (pinched && zoom.scale < 1f) scope.launch { zoom.animateToFit() }
                                    }
                                }
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(
                                    with(density) { contentWidth.toDp() },
                                    with(density) { contentHeight.toDp() }
                                )
                                .graphicsLayer {
                                    transformOrigin = TransformOrigin(0f, 0f)
                                    scaleX = zoom.scale
                                    scaleY = zoom.scale
                                    translationX = zoom.offsetX
                                    translationY = zoom.offsetY
                                }
                                .background(Color.White)
                        ) {
                            // La hoja: una sola imagen (fondo limpio + logos + texto) o la foto tal cual.
                            Image(
                                bitmap = if (rebuilt && sheetPicture != null) sheetPicture else picture,
                                contentDescription = "Página $pageNumber",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.FillBounds,
                                colorFilter = composeFilter
                            )
                            // Con zoom: el pedazo nítido encima (mismo dibujo, más resolución).
                            val tile = detail
                            val tileRect = detailRect
                            if (rebuilt && tile != null && tileRect != null && detailPage == currentPage.id) {
                                Image(
                                    bitmap = tile,
                                    contentDescription = null,
                                    modifier = Modifier
                                        .graphicsLayer {
                                            transformOrigin = TransformOrigin(0f, 0f)
                                            translationX = tileRect.left
                                            translationY = tileRect.top
                                        }
                                        .size(
                                            with(density) { tileRect.width.toDp() },
                                            with(density) { tileRect.height.toDp() }
                                        ),
                                    contentScale = ContentScale.FillBounds,
                                    colorFilter = composeFilter
                                )
                            }
                            // Comparar: la foto encima, solo a la izquierda de la raya.
                            val splitAt = compareAt
                            if (rebuilt && splitAt != null) {
                                Image(
                                    bitmap = picture,
                                    contentDescription = null,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .drawWithContent {
                                            clipRect(right = size.width * splitAt) { this@drawWithContent.drawContent() }
                                            // Línea blanca con sombra y una manija redonda con flechas:
                                            // se arrastra con el dedo (sin barra abajo).
                                            val k = 1f / zoom.scale.coerceAtLeast(0.2f)
                                            val x = size.width * splitAt
                                            drawLine(Color(0x55000000), Offset(x + 1.5f * k, 0f), Offset(x + 1.5f * k, size.height), strokeWidth = 3.dp.toPx() * k)
                                            drawLine(Color.White, Offset(x, 0f), Offset(x, size.height), strokeWidth = 2.dp.toPx() * k)
                                            val cy = size.height / 2f
                                            val r = 18.dp.toPx() * k
                                            drawCircle(Color(0x66000000), radius = r + 2.dp.toPx() * k, center = Offset(x, cy + 1.dp.toPx() * k))
                                            drawCircle(Color.White, radius = r, center = Offset(x, cy))
                                            val a = 5.dp.toPx() * k
                                            val gap = 4.dp.toPx() * k
                                            for (dir in listOf(-1f, 1f)) {
                                                // Flechita "<" y ">" con dos rayitas.
                                                val tip = x + dir * (gap + a * 1.2f)
                                                val base = x + dir * gap
                                                val w = 2.2.dp.toPx() * k
                                                drawLine(DocScanBackground, Offset(base, cy - a), Offset(tip, cy), strokeWidth = w, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                                                drawLine(DocScanBackground, Offset(base, cy + a), Offset(tip, cy), strokeWidth = w, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                                            }
                                        },
                                    contentScale = ContentScale.FillBounds
                                )
                            }
                            // Encima, en vivo: lo que se mueve, los textos agregados, las firmas,
                            // la marca de lo elegido y las guías para alinear.
                            Canvas(Modifier.fillMaxSize()) {
                                val width = size.width
                                val height = size.height
                                val read = analysis
                                val layoutNow = pageLayout
                                val sel = selection
                                val raw = dragPreview
                                val moving = (pressMoving || handleMoving) && raw != Offset.Zero
                                val snap = if (moving) snapFor(raw) else null
                                val kk = if (read != null) width / read.width.coerceAtLeast(1) else 1f
                                var shift = if (snap != null) Offset(snap.dx * kk, snap.dy * kk) else if (moving) raw else Offset.Zero
                                // Igual que al soltar: no se sale de la hoja.
                                val box = if (moving && read != null && sel != null) boxOf(sel, read) else null
                                if (box != null && kk > 0f) {
                                    fun keep(move: Float, start: Float, end: Float, size: Float): Float {
                                        val low = -start * kk
                                        val high = (size - end) * kk
                                        return if (low <= high) move.coerceIn(low, high) else move
                                    }
                                    shift = Offset(
                                        keep(shift.x, box.left, box.right, read!!.width.toFloat()),
                                        keep(shift.y, box.top, box.bottom, read.height.toFloat())
                                    )
                                }

                                if (rebuilt && read != null) {
                                    // Párrafo y pieza que no están en la imagen de la hoja.
                                    val liveBlock = sheetKey.hiddenBlock
                                    val liveObject = sheetKey.hiddenObject
                                    val blockShift = if (sel is DocScanSelBlock && sel.blockId == liveBlock) shift else Offset.Zero
                                    val objectShift = if (sel is DocScanSelObject && sel.objectId == liveObject) shift else Offset.Zero
                                    val liveShape = sheetKey.hiddenShape
                                    val shapeShift = if (sel is DocScanSelShape && sel.shapeId == liveShape) shift else Offset.Zero
                                    // Imagen que se agranda o gira con los dedos: en vivo.
                                    val liveObjectEdits = if (sel is DocScanSelObject && (transformScale != 1f || transformTurn != 0f)) {
                                        docScanPreview(currentEdits, sel, 0f, 0f, transformScale, transformTurn).objects
                                    } else {
                                        currentEdits.objects
                                    }
                                    drawIntoCanvas { canvas ->
                                        val native = canvas.nativeCanvas
                                        native.save()
                                        native.scale(kk, kk)
                                        if (liveShape >= 0) {
                                            val shape = sheetShapes.firstOrNull { it.id == liveShape }
                                            if (shape != null) {
                                                livePaint.colorFilter = liveColorFilter
                                                docScanDrawShapes(
                                                    native, listOf(shape), livePaint, currentEdits.shapes,
                                                    moving = shape.id, dx = shapeShift.x / kk, dy = shapeShift.y / kk
                                                )
                                            }
                                        }
                                        if (liveObject >= 0) {
                                            val piece = pieces.firstOrNull { it.id == liveObject }
                                            if (piece != null) {
                                                livePaint.colorFilter = liveColorFilter
                                                docScanDrawObjects(
                                                    native, listOf(piece), liveObjectEdits, livePaint,
                                                    piece.id, objectShift.x / kk, objectShift.y / kk
                                                )
                                            }
                                        }
                                        // Recién tocado: la hoja todavía tiene el párrafo; el cuadro y el
                                        // cursor salen ya mismo encima (sin esperar a que se rehaga).
                                        val startsEarly = writingStarts
                                        if (sheetLetters && selectedBlockId >= 0 && selectedBlockId != liveBlock && layoutNow != null && startsEarly != null) {
                                            val runsEarly = writingRuns
                                            if (runsEarly.isNotEmpty() && startsEarly.size == runsEarly.size) {
                                                docScanDrawCaret(
                                                    native, runsEarly, startsEarly, editSelection, caretOn, layoutNow.block(selectedBlockId),
                                                    caretPaint, caretMeasure, 2.dp.toPx() / (zoom.scale * kk)
                                                )
                                            }
                                        }
                                        // Mientras el zoom se mueve, el párrafo que se escribe se dibuja aquí
                                        // (pegado a la hoja); quieto, lo muestra el cuadro de texto.
                                        val writingThis = writingBlock && selectedBlockId == liveBlock && !zoomMoving && !sheetLetters
                                        if (liveBlock >= 0 && !writingThis && layoutNow != null) {
                                            val runs = layoutNow.runs.filter { it.blockId == liveBlock }
                                            native.translate(blockShift.x / kk, blockShift.y / kk)
                                            if (runs.isNotEmpty()) {
                                                livePaint.colorFilter = liveColorFilter
                                                textPaths.drawRuns(native, runs, livePaint)
                                            }
                                            // Cursor, selección y borde del cuadro, sobre las letras de la hoja.
                                            val starts = writingStarts
                                            if (sheetLetters && selectedBlockId == liveBlock && starts != null && starts.size == runs.size) {
                                                docScanDrawCaret(
                                                    native, runs, starts, editSelection, caretOn, layoutNow.block(liveBlock),
                                                    caretPaint, caretMeasure, 2.dp.toPx() / (zoom.scale * kk)
                                                )
                                            }
                                        }
                                        native.restore()
                                    }
                                }
                                // Partes que reconoció la IA, con su nombre.
                                if (showAi && read != null) {
                                    val stroke = 1.5.dp.toPx() / zoom.scale
                                    val labelSize = 11.dp.toPx() / zoom.scale
                                    for (region in read.regions) {
                                        val color = docScanRegionColor(region.kind)
                                        val box = region.rect
                                        drawRect(
                                            color = color.copy(alpha = 0.1f),
                                            topLeft = Offset(box.left * kk, box.top * kk),
                                            size = Size(box.width() * kk, box.height() * kk)
                                        )
                                        drawRect(
                                            color = color,
                                            topLeft = Offset(box.left * kk, box.top * kk),
                                            size = Size(box.width() * kk, box.height() * kk),
                                            style = Stroke(width = stroke)
                                        )
                                        drawIntoCanvas { canvas ->
                                            aiPaint.textSize = labelSize
                                            aiPaint.color = android.graphics.Color.WHITE
                                            val label = "${region.label} ${(region.score * 100).roundToInt()}%"
                                            val labelWidth = aiPaint.measureText(label)
                                            val native = canvas.nativeCanvas
                                            val backPaint = android.graphics.Paint().apply { this.color = color.toArgbInt() }
                                            native.drawRect(
                                                box.left * kk, box.top * kk - labelSize * 1.3f,
                                                box.left * kk + labelWidth + labelSize * 0.6f, box.top * kk, backPaint
                                            )
                                            textPaths.drawText(
                                                native, "ia|${labelSize}", label,
                                                box.left * kk + labelSize * 0.3f, box.top * kk - labelSize * 0.3f, aiPaint
                                            )
                                        }
                                    }
                                }
                                if (showBoxes && layoutNow != null && rebuilt) {
                                    for (block in layoutNow.blocks) {
                                        if (block.deleted) continue
                                        drawRect(
                                            color = DocScanFocus.copy(alpha = 0.09f),
                                            topLeft = Offset(block.rect.left * kk, block.rect.top * kk),
                                            size = Size(block.rect.width() * kk, block.rect.height() * kk)
                                        )
                                    }
                                }
                                // Textos agregados y firmas.
                                val transforming = transformScale != 1f || transformTurn != 0f
                                val drawn = if ((moving && (sel is DocScanSelText || sel is DocScanSelSign)) || transforming) {
                                    val signShift = if (moving && (sel is DocScanSelText || sel is DocScanSelSign)) shift else Offset.Zero
                                    docScanPreview(
                                        currentEdits, sel, signShift.x / width, signShift.y / height,
                                        transformScale, transformTurn, height / width.coerceAtLeast(1f)
                                    )
                                } else {
                                    currentEdits
                                }
                                drawIntoCanvas { canvas ->
                                    livePaint.colorFilter = liveColorFilter
                                    docScanDrawAdded(
                                        canvas.nativeCanvas, width, height, drawn, addedFamily, livePaint,
                                        paths = textPaths,
                                        hiddenText = if (writingText) selectedTextId else -1
                                    )
                                    livePaint.colorFilter = null
                                }
                                // Marca de lo elegido: línea fina (no tapa la hoja).
                                val line = 1.5.dp.toPx() / zoom.scale
                                // Tabla: su contorno (al moverla, va entera).
                                val tableRect = (sel as? DocScanSelTable)?.takeIf { it.pageId == currentPage.id }
                                    ?.let { layoutNow?.table(it.tableId)?.rect }
                                    ?.let { RectF(it.left * kk, it.top * kk, it.right * kk, it.bottom * kk) }
                                if (tableRect != null && !pressMoving) {
                                    drawRect(
                                        color = DocScanFocus.copy(alpha = 0.55f),
                                        topLeft = Offset(tableRect.left, tableRect.top),
                                        size = Size(tableRect.width(), tableRect.height()),
                                        style = Stroke(width = 1.dp.toPx() / zoom.scale)
                                    )
                                }
                                val rect = (if (tableRect != null && pressMoving) tableRect else
                                    docScanSelectionRect(sel, currentPage.id, layoutNow, pieces, drawn, width, height, addedFamily, measurePaint, sheetShapes))
                                    ?.apply {
                                        if (sel is DocScanSelBlock || sel is DocScanSelObject || sel is DocScanSelShape || sel is DocScanSelTable) offset(shift.x, shift.y)
                                    }
                                if (rect != null && !(writingBlock && !handleMoving) && !writingText) {
                                    val pad = 3.dp.toPx() / zoom.scale
                                    // Firma e imagen: el marco gira con ellas (como en Word).
                                    val turnNow = docScanSelectionTurn(sel, drawn)
                                    rotate(turnNow, pivot = Offset(rect.centerX(), rect.centerY())) {
                                        drawRoundRect(
                                            color = DocScanFocus.copy(alpha = 0.06f),
                                            topLeft = Offset(rect.left - pad, rect.top - pad),
                                            size = Size(rect.width() + pad * 2f, rect.height() + pad * 2f),
                                            cornerRadius = CornerRadius(pad, pad)
                                        )
                                        drawRoundRect(
                                            color = DocScanFocus,
                                            topLeft = Offset(rect.left - pad, rect.top - pad),
                                            size = Size(rect.width() + pad * 2f, rect.height() + pad * 2f),
                                            cornerRadius = CornerRadius(pad, pad),
                                            style = Stroke(width = line)
                                        )
                                        if (sel is DocScanSelObject || sel is DocScanSelSign || sel is DocScanSelShape) {
                                            val knob = 4.dp.toPx() / zoom.scale
                                            listOf(
                                                Offset(rect.left - pad, rect.top - pad),
                                                Offset(rect.right + pad, rect.top - pad),
                                                Offset(rect.left - pad, rect.bottom + pad),
                                                Offset(rect.right + pad, rect.bottom + pad)
                                            ).forEach { center ->
                                                drawCircle(Color.White, radius = knob, center = center)
                                                drawCircle(DocScanFocus, radius = knob, center = center, style = Stroke(width = line))
                                            }
                                        }
                                        if (sel is DocScanSelObject || sel is DocScanSelSign) {
                                            // Manija de tamaño (esquina) y de giro (arriba, con su palito).
                                            val big = 7.dp.toPx() / zoom.scale
                                            val corner = Offset(rect.right + pad, rect.bottom + pad)
                                            drawCircle(DocScanFocus, radius = big, center = corner)
                                            drawCircle(Color.White, radius = big * 0.45f, center = corner)
                                            val stem = 26.dp.toPx() / zoom.scale
                                            val top = Offset(rect.centerX(), rect.top - pad)
                                            val knobAt = Offset(rect.centerX(), rect.top - pad - stem)
                                            drawLine(DocScanFocus, top, knobAt, line)
                                            drawCircle(Color.White, radius = big, center = knobAt)
                                            drawCircle(DocScanFocus, radius = big, center = knobAt, style = Stroke(width = line * 1.4f))
                                            drawArc(
                                                color = DocScanFocus,
                                                startAngle = -60f, sweepAngle = 260f, useCenter = false,
                                                topLeft = Offset(knobAt.x - big * 0.5f, knobAt.y - big * 0.5f),
                                                size = Size(big, big),
                                                style = Stroke(width = line)
                                            )
                                        }
                                    }
                                }
                                // Guías para alinear (rosadas, como en los editores de diseño).
                                if (snap != null) {
                                    val guideStroke = 1.5.dp.toPx() / zoom.scale
                                    for (guide in snap.guides) {
                                        if (guide.vertical) {
                                            drawLine(
                                                DocScanGuide,
                                                Offset(guide.position * kk, guide.start * kk),
                                                Offset(guide.position * kk, guide.end * kk),
                                                guideStroke
                                            )
                                        } else {
                                            drawLine(
                                                DocScanGuide,
                                                Offset(guide.start * kk, guide.position * kk),
                                                Offset(guide.end * kk, guide.position * kk),
                                                guideStroke
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ---------------- Escribir directo sobre la hoja ----------------
                    val read = analysis
                    if (writingBlock && read != null) {
                        val placed = pageLayout?.block(selectedBlockId)
                        val block = read.blocks.firstOrNull { it.id == selectedBlockId }
                        if (placed != null && block != null) {
                            val edit = currentEdits.blocks[block.id] ?: block.originalEdit()
                            val runsNow = writingRuns
                            val startsNow = writingStarts
                            DocScanInlineEditor(
                                zoom = zoom,
                                sheetLetters = sheetLetters,
                                boxTop = placed.rect.top * k,
                                boxHeight = placed.rect.height() * k,
                                tapToOffset = { tap ->
                                    if (startsNow == null || runsNow.isEmpty()) {
                                        null
                                    } else {
                                        val x = tap.x / k
                                        val y = tap.y / k
                                        val line = runsNow.indices.minByOrNull { abs(y - (runsNow[it].baseline - runsNow[it].size * 0.35f)) } ?: 0
                                        startsNow[line] + docScanCaretIndex(runsNow[line], x, caretMeasure)
                                    }
                                },
                                caretRect = { offset ->
                                    if (startsNow == null || runsNow.isEmpty()) {
                                        null
                                    } else {
                                        val line = docScanRunFor(offset, runsNow, startsNow)
                                        val run = runsNow[line]
                                        val x = docScanCaretX(run, offset - startsNow[line], caretMeasure)
                                        android.graphics.RectF(x * k, (run.baseline - run.size * 0.95f) * k, x * k + 1f, (run.baseline + run.size * 0.3f) * k)
                                    }
                                },
                                onSelection = { editSelection = it },
                                fieldKey = "b:${currentPage.id}:${block.id}",
                                text = edit.text,
                                selectAll = false,
                                left = placed.areaLeft * k,
                                baseline = placed.baseline * k,
                                width = (placed.areaRight - placed.areaLeft) * k,
                                fontSize = placed.size * k,
                                leading = placed.leading * k,
                                scaleX = placed.scaleX,
                                typeface = DocScanFonts.typeface(placed.family, edit.bold, edit.italic),
                                color = Color(docScanFilterColor(edit.color, filterMatrix)),
                                align = edit.align,
                                singleLine = false,
                                // Mientras la imagen de la hoja todavía tiene el párrafo, se tapa.
                                cover = if (sheetKey.hiddenBlock != block.id) {
                                    Color(docScanFilterColor(block.background, filterMatrix))
                                } else {
                                    null
                                },
                                pendingTap = tapAt,
                                onTapUsed = { tapAt = null },
                                pendingWord = wordTapAt,
                                onWordUsed = { wordTapAt = null },
                                dragOffset = { if (handleMoving) snappedOffset(dragPreview) else Offset.Zero },
                                focusRequester = fieldFocus,
                                onText = { setBlockEdit(currentPage.id, block, edit.copy(text = it), typing = true) },
                                onDone = { deselect() },
                                onMoveStart = {
                                    dragPreview = Offset.Zero
                                    handleMoving = true
                                },
                                onMove = { delta -> latestDrag(delta) },
                                onMoveEnd = { latestDragEnd() },
                                view = settled,
                                visible = !zoomMoving,
                                onSettle = { settled = Triple(zoom.scale, zoom.offsetX, zoom.offsetY) },
                                onResizeStart = {
                                    resizeBase = placed.areaRight - placed.areaLeft
                                    resizeDelta = 0f
                                },
                                onResize = { delta ->
                                    resizeDelta += delta / k
                                    val newWidth = (resizeBase + resizeDelta).coerceIn(placed.size * 2f, read.width.toFloat())
                                    setBlockEdit(currentPage.id, block, edit.copy(width = newWidth), typing = true)
                                }
                            )
                        }
                    } else if (writingText && read != null) {
                        val added = currentEdits.texts.firstOrNull { it.id == selectedTextId }
                        if (added != null) {
                            val pageW = zoom.contentWidth
                            val pageH = zoom.contentHeight
                            DocScanInlineEditor(
                                zoom = zoom,
                                sheetLetters = false,
                                fieldKey = "t:${currentPage.id}:${added.id}",
                                text = added.text,
                                selectAll = newTextId == added.id,
                                left = added.x * pageW,
                                baseline = added.y * pageH,
                                width = null,
                                fontSize = added.size * pageH,
                                leading = added.size * pageH * 1.22f,
                                scaleX = 1f,
                                typeface = DocScanFonts.typeface(addedFamily, added.bold, added.italic),
                                color = Color(docScanFilterColor(added.color, filterMatrix)),
                                align = DOC_SCAN_ALIGN_LEFT,
                                singleLine = true,
                                cover = null,
                                pendingTap = tapAt,
                                onTapUsed = { tapAt = null },
                                pendingWord = wordTapAt,
                                onWordUsed = { wordTapAt = null },
                                dragOffset = { if (handleMoving) snappedOffset(dragPreview) else Offset.Zero },
                                focusRequester = fieldFocus,
                                onText = { value ->
                                    newTextId = -1
                                    setAddedText(currentPage.id, added.id, typing = true) { it.copy(text = value) }
                                },
                                onDone = { deselect() },
                                onMoveStart = {
                                    dragPreview = Offset.Zero
                                    handleMoving = true
                                },
                                onMove = { delta -> latestDrag(delta) },
                                onMoveEnd = { latestDragEnd() },
                                view = settled,
                                visible = !zoomMoving,
                                onSettle = { settled = Triple(zoom.scale, zoom.offsetX, zoom.offsetY) }
                            )
                        }
                    }
                }

                // Avisos sobre la hoja.
                when {
                    loadingPage || bitmap == null -> {
                        CircularProgressIndicator(color = NeonGreen, modifier = Modifier.align(Alignment.Center))
                    }
                    analyzing -> DocScanStatusChip(analyzeStep, Modifier.align(Alignment.TopCenter))
                    enhanceStep != null && !pressMoving -> DocScanStatusChip(enhanceStep.orEmpty(), Modifier.align(Alignment.TopCenter))
                    showOriginal -> DocScanStatusChip("Foto original · toca \"Original\" para volver", Modifier.align(Alignment.TopCenter))
                    analysis != null && (analysis.failed || analysis.lines.isEmpty()) ->
                        DocScanStatusChip("No se encontró texto en esta página", Modifier.align(Alignment.TopCenter))
                    pressMoving -> DocScanStatusChip("Arrastra · las líneas rosadas te ayudan a alinear", Modifier.align(Alignment.TopCenter))
                    rebuilt && selection == null && doubts.isNotEmpty() -> Text(
                        if (doubts.size == 1) "Revisar 1 palabra dudosa" else "Revisar ${doubts.size} palabras dudosas",
                        color = Color(0xFF06140C),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 10.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFFFFD54F))
                            .clickable { reviewList = doubts }
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                    showAi && analysis != null -> DocScanStatusChip(
                        when {
                            analysis.regions.isNotEmpty() -> "La IA reconoció ${analysis.regions.size} partes"
                            !aiInstalled -> "Falta la IA: bájala en el menú (mejor resultado)"
                            DocScanLayoutAi.lastError != null -> "La IA no pudo abrirse en este celular"
                            else -> "La IA no encontró partes en esta hoja"
                        },
                        Modifier.align(Alignment.TopCenter)
                    )
                }
            }

            // ---------------- Barra de abajo ----------------
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DocScanBar)
                    .navigationBarsPadding()
                    .padding(vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val sel = selection
                val selectedBlock = (sel as? DocScanSelBlock)?.let { blockSel ->
                    analysis?.blocks?.firstOrNull { it.id == blockSel.blockId }
                }
                val selectedText = (sel as? DocScanSelText)?.let { textSel ->
                    currentEdits.texts.firstOrNull { it.id == textSel.textId }
                }
                val selectedSign = (sel as? DocScanSelSign)?.let { signSel ->
                    currentEdits.signs.firstOrNull { it.id == signSel.signId }
                }
                val selectedShape = (sel as? DocScanSelShape)?.let { shapeSel ->
                    sheetShapes.firstOrNull { it.id == shapeSel.shapeId }
                }
                val selectedObject = (sel as? DocScanSelObject)?.let { objectSel ->
                    pieces.firstOrNull { it.id == objectSel.objectId }
                }
                val tableSel = sel as? DocScanSelTable
                val selectedTable = tableSel?.let { ts -> analysis?.tables?.firstOrNull { it.id == ts.tableId } }

                when {
                    pressMoving -> {
                        DocScanHint("Suelta para dejarlo ahí. Deshacer lo regresa.")
                    }

                    selectedTable != null && tableSel != null -> {
                        val table = selectedTable
                        val edit = currentEdits.tables[table.id] ?: DocScanTableEdit(table.data)
                        val data = edit.data
                        val cell = data.cellAt(tableSel.row, tableSel.col)
                        val changed = currentEdits.tables.containsKey(table.id)
                        fun goTo(row: Int, col: Int, newData: DocScanTableData = data) {
                            val r = row.coerceIn(0, (newData.rowCount - 1).coerceAtLeast(0))
                            val c = col.coerceIn(0, (newData.colCount - 1).coerceAtLeast(0))
                            val target = newData.cellAt(r, c)
                            selection = DocScanSelTable(currentPage.id, table.id, target?.row ?: r, target?.col ?: c)
                        }
                        fun change(update: (DocScanTableData) -> DocScanTableData): DocScanTableData {
                            val next = update(data)
                            setTableEdit(currentPage.id, table) { it.copy(data = next) }
                            return next
                        }
                        if (edit.deleted) {
                            DocScanRow {
                                Text("Tabla borrada", color = DocScanMuted, fontSize = 13.sp)
                                DocScanChip(active = false, onClick = { setTableEdit(currentPage.id, table) { it.copy(deleted = false) } }) {
                                    DocScanLabel("Recuperar")
                                }
                                DocScanDoneChip { deselect() }
                            }
                        } else {
                            DocScanCellField(
                                fieldKey = "${currentPage.id}:${table.id}:${tableSel.row}:${tableSel.col}",
                                label = "Fila ${tableSel.row + 1} · Columna ${tableSel.col + 1}",
                                text = cell?.text.orEmpty(),
                                focus = cellFocus,
                                onText = { text ->
                                    setTableEdit(currentPage.id, table, "cell:${currentPage.id}:${table.id}:${tableSel.row}:${tableSel.col}") {
                                        it.copy(data = it.data.withText(tableSel.row, tableSel.col, text))
                                    }
                                },
                                onNext = {
                                    val (r, c) = data.stepCell(tableSel.row, tableSel.col, forward = true)
                                    goTo(r, c)
                                }
                            )
                            DocScanRow {
                                DocScanIconChip(active = false, onClick = {
                                    val (r, c) = data.stepCell(tableSel.row, tableSel.col, forward = false)
                                    goTo(r, c)
                                }) {
                                    Icon(Icons.Rounded.KeyboardArrowLeft, contentDescription = "Celda anterior", tint = DocScanInk, modifier = Modifier.size(24.dp))
                                }
                                DocScanIconChip(active = false, onClick = {
                                    val (r, c) = data.stepCell(tableSel.row, tableSel.col, forward = true)
                                    goTo(r, c)
                                }) {
                                    Icon(Icons.Rounded.KeyboardArrowRight, contentDescription = "Celda siguiente", tint = DocScanInk, modifier = Modifier.size(24.dp))
                                }
                                DocScanIconChip(active = cell?.bold == true, onClick = {
                                    change { it.withCell(tableSel.row, tableSel.col) { c -> c.copy(bold = !c.bold, ink = null) } }
                                }) {
                                    Text("B", color = DocScanInk, fontWeight = FontWeight.Black, fontSize = 17.sp)
                                }
                                DocScanIconChip(active = false, onClick = {
                                    change {
                                        it.withCell(tableSel.row, tableSel.col) { c ->
                                            val next = when (c.align) {
                                                DOC_SCAN_ALIGN_LEFT -> DOC_SCAN_ALIGN_CENTER
                                                DOC_SCAN_ALIGN_CENTER -> DOC_SCAN_ALIGN_RIGHT
                                                else -> DOC_SCAN_ALIGN_LEFT
                                            }
                                            c.copy(align = next, ink = null)
                                        }
                                    }
                                }) {
                                    Icon(docScanAlignIcon(cell?.align ?: DOC_SCAN_ALIGN_LEFT), contentDescription = "Alinear", tint = DocScanInk, modifier = Modifier.size(22.dp))
                                }
                                DocScanChip(active = false, onClick = {
                                    val next = change { it.insertRow(tableSel.row) }
                                    goTo(tableSel.row + 1, tableSel.col, next)
                                }) { DocScanLabel("+ Fila") }
                                DocScanChip(active = false, enabled = data.rowCount > 1, onClick = {
                                    val next = change { it.deleteRow(tableSel.row) }
                                    goTo(tableSel.row, tableSel.col, next)
                                }) { DocScanLabel("− Fila") }
                                DocScanChip(active = false, onClick = {
                                    val next = change { it.insertColumn(tableSel.col) }
                                    goTo(tableSel.row, tableSel.col + 1, next)
                                }) { DocScanLabel("+ Columna") }
                                DocScanChip(active = false, enabled = data.colCount > 1, onClick = {
                                    val next = change { it.deleteColumn(tableSel.col) }
                                    goTo(tableSel.row, tableSel.col, next)
                                }) { DocScanLabel("− Columna") }
                                DocScanChip(active = data.borders, onClick = { change { it.toggleBorders() } }) { DocScanLabel("Rayas") }
                                // Rayas de esta celda, una por una (para quitar solo una de más).
                                listOf(
                                    0 to Icons.Rounded.BorderTop, 2 to Icons.Rounded.BorderBottom,
                                    3 to Icons.Rounded.BorderLeft, 1 to Icons.Rounded.BorderRight
                                ).forEach { (side, icon) ->
                                    val on = data.hasEdge(tableSel.row, tableSel.col, side)
                                    DocScanIconChip(active = on, onClick = { change { it.toggleEdge(tableSel.row, tableSel.col, side) } }) {
                                        Icon(icon, contentDescription = if (on) "Quitar raya" else "Poner raya", tint = DocScanInk, modifier = Modifier.size(20.dp))
                                    }
                                }
                                DocScanChip(active = false, onClick = {
                                    setTableEdit(currentPage.id, table) { it.copy(scale = (it.scale * 0.92f).coerceAtLeast(0.4f)) }
                                }) { DocScanLabel("A−") }
                                DocScanChip(active = false, onClick = {
                                    setTableEdit(currentPage.id, table) { it.copy(scale = (it.scale * 1.08f).coerceAtMost(3f)) }
                                }) { DocScanLabel("A+") }
                                DocScanChip(active = false, onClick = {
                                    setTableEdit(currentPage.id, table) { it.copy(deleted = true) }
                                    deselect()
                                    onMessage("Tabla borrada. Deshacer la regresa.")
                                }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Borrar tabla", tint = DocScanDanger, modifier = Modifier.size(20.dp))
                                }
                                if (changed) {
                                    DocScanChip(active = false, onClick = { setTableEdit(currentPage.id, table) { DocScanTableEdit(table.data) } }) {
                                        Icon(Icons.Rounded.Refresh, contentDescription = "Como estaba", tint = DocScanInk, modifier = Modifier.size(20.dp))
                                    }
                                }
                                DocScanDoneChip { deselect() }
                            }
                            DocScanHint("Toca otra celda para escribir en ella. Mantén presionada la tabla para moverla.")
                        }
                    }

                    selectedBlock != null -> {
                        val block = selectedBlock
                        val edit = currentEdits.blocks[block.id] ?: block.originalEdit()
                        val changed = currentEdits.blocks.containsKey(block.id)
                        if (edit.deleted) {
                            DocScanRow {
                                Text("Párrafo borrado", color = DocScanMuted, fontSize = 13.sp)
                                DocScanChip(active = false, onClick = { setBlockEdit(currentPage.id, block, edit.copy(deleted = false)) }) {
                                    DocScanLabel("Recuperar")
                                }
                                DocScanChip(active = false, onClick = { deselect() }) {
                                    Text("Listo", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        } else {
                            DocScanEditBar(
                                bold = edit.bold,
                                italic = edit.italic,
                                color = edit.color,
                                align = edit.align,
                                showColors = showColors,
                                showFonts = showFonts,
                                changed = changed,
                                onBold = { setBlockEdit(currentPage.id, block, edit.copy(bold = !edit.bold)) },
                                onItalic = { setBlockEdit(currentPage.id, block, edit.copy(italic = !edit.italic)) },
                                onColors = { showColors = !showColors; showFonts = false },
                                onFonts = { showFonts = !showFonts; showColors = false },
                                onSmaller = { setBlockEdit(currentPage.id, block, edit.copy(scale = (edit.scale * 0.92f).coerceAtLeast(0.4f))) },
                                onBigger = { setBlockEdit(currentPage.id, block, edit.copy(scale = (edit.scale * 1.08f).coerceAtMost(3f))) },
                                onAlign = { setBlockEdit(currentPage.id, block, edit.copy(align = docScanNextAlign(edit.align))) },
                                onDelete = {
                                    setBlockEdit(currentPage.id, block, edit.copy(deleted = true))
                                    deselect()
                                    onMessage("Párrafo borrado. Deshacer lo regresa.")
                                },
                                onRestore = { setBlockEdit(currentPage.id, block, block.originalEdit()) },
                                onDone = { deselect() }
                            )
                            if (showColors) {
                                DocScanPaletteRow(selected = edit.color) { color ->
                                    setBlockEdit(currentPage.id, block, edit.copy(color = color))
                                }
                            }
                            if (showFonts) {
                                DocScanFontPanel(
                                    font = fontChoice,
                                    paper = paperChoice,
                                    autoPaper = analysis?.let { docScanPaperLabel(it.paper, it.landscape) }.orEmpty(),
                                    onFont = { fontChoice = it },
                                    onPaper = { paperChoice = it }
                                )
                            }
                        }
                    }

                    selectedObject != null -> {
                        val piece = selectedObject
                        val edit = currentEdits.objects[piece.id] ?: DocScanObjectEdit()
                        if (edit.deleted) {
                            DocScanRow {
                                Text("Imagen quitada", color = DocScanMuted, fontSize = 13.sp)
                                DocScanChip(active = false, onClick = { setObjectEdit(currentPage.id, piece.id, edit.copy(deleted = false)) }) {
                                    DocScanLabel("Recuperar")
                                }
                                DocScanChip(active = false, onClick = { deselect() }) {
                                    Text("Listo", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        } else {
                            DocScanRow {
                                DocScanChip(active = false, onClick = {
                                    setObjectEdit(currentPage.id, piece.id, edit.copy(scale = (edit.scale * 0.9f).coerceAtLeast(0.2f)))
                                }) { DocScanLabel("Más chica") }
                                DocScanChip(active = false, onClick = {
                                    setObjectEdit(currentPage.id, piece.id, edit.copy(scale = (edit.scale * 1.1f).coerceAtMost(8f)))
                                }) { DocScanLabel("Más grande") }
                                DocScanChip(active = false, onClick = {
                                    setObjectEdit(currentPage.id, piece.id, edit.copy(rotation = docScanNormalAngle(edit.rotation + 90f)))
                                }) { DocScanLabel("Girar") }
                                // Mejorar (todas las imágenes de la hoja, con la IA local): solo si se toca.
                                DocScanChip(active = enhanceMode != DocScanEnhance.OFF, onClick = {
                                    enhanceMode = if (enhanceMode == DocScanEnhance.OFF) DocScanEnhance.X2 else DocScanEnhance.OFF
                                }) { DocScanLabel(if (enhanceMode == DocScanEnhance.OFF) "Mejorar" else "Mejorada ✓") }
                                DocScanChip(active = false, onClick = {
                                    setObjectEdit(currentPage.id, piece.id, edit.copy(deleted = true))
                                    deselect()
                                }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = DocScanDanger, modifier = Modifier.size(20.dp))
                                }
                                if (edit != DocScanObjectEdit()) {
                                    DocScanChip(active = false, onClick = { setObjectEdit(currentPage.id, piece.id, DocScanObjectEdit()) }) {
                                        Icon(Icons.Rounded.Refresh, contentDescription = "Como estaba", tint = DocScanInk, modifier = Modifier.size(20.dp))
                                    }
                                }
                                DocScanDoneChip { deselect() }
                            }
                            DocScanHint("Arrástrala con un dedo. Con dos dedos encima: agrandar y girar. También con las manijas.")
                        }
                    }

                    selectedText != null -> {
                        val added = selectedText
                        DocScanEditBar(
                            bold = added.bold,
                            italic = added.italic,
                            color = added.color,
                            align = null,
                            showColors = showColors,
                            showFonts = showFonts,
                            changed = false,
                            onBold = { setAddedText(currentPage.id, added.id) { it.copy(bold = !it.bold) } },
                            onItalic = { setAddedText(currentPage.id, added.id) { it.copy(italic = !it.italic) } },
                            onColors = { showColors = !showColors; showFonts = false },
                            onFonts = { showFonts = !showFonts; showColors = false },
                            onSmaller = { setAddedText(currentPage.id, added.id) { it.copy(size = (it.size * 0.92f).coerceAtLeast(0.005f)) } },
                            onBigger = { setAddedText(currentPage.id, added.id) { it.copy(size = (it.size * 1.08f).coerceAtMost(0.2f)) } },
                            onAlign = {},
                            onDelete = {
                                updatePage(currentPage.id) { page -> page.copy(texts = page.texts.filterNot { it.id == added.id }) }
                                deselect()
                            },
                            onRestore = {},
                            onDone = { deselect() }
                        )
                        if (showColors) {
                            DocScanPaletteRow(selected = added.color) { color -> setAddedText(currentPage.id, added.id) { it.copy(color = color) } }
                        }
                        if (showFonts) {
                            DocScanFontPanel(
                                font = fontChoice,
                                paper = paperChoice,
                                autoPaper = analysis?.let { docScanPaperLabel(it.paper, it.landscape) }.orEmpty(),
                                onFont = { fontChoice = it },
                                onPaper = { paperChoice = it }
                            )
                        }
                    }

                    selectedSign != null -> {
                        val sign = selectedSign
                        DocScanRow {
                            val pageRatio = if (zoom.contentWidth > 0f) zoom.contentHeight / zoom.contentWidth else 1.4142f
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page ->
                                    page.copy(signs = page.signs.map { if (it.id == sign.id) it.resizedBy(0.9f, pageRatio) else it })
                                }
                            }) { DocScanLabel("Más chica") }
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page ->
                                    page.copy(signs = page.signs.map { if (it.id == sign.id) it.resizedBy(1.1f, pageRatio) else it })
                                }
                            }) { DocScanLabel("Más grande") }
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page ->
                                    page.copy(signs = page.signs.map { if (it.id == sign.id) it.turnedBy(90f) else it })
                                }
                            }) { DocScanLabel("Girar") }
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page -> page.copy(signs = page.signs.filterNot { it.id == sign.id }) }
                                deselect()
                            }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = DocScanDanger, modifier = Modifier.size(20.dp))
                            }
                            DocScanDoneChip { deselect() }
                        }
                        DocScanHint("Arrástrala con un dedo. Con dos dedos encima: agrandar y girar. También con las manijas.")
                    }

                    selectedShape != null -> {
                        val shape = selectedShape
                        val edit = currentEdits.shapes[shape.id] ?: DocScanShapeEdit()
                        fun setShape(next: DocScanShapeEdit) {
                            updatePage(currentPage.id) { page ->
                                page.copy(shapes = if (next == DocScanShapeEdit()) page.shapes - shape.id else page.shapes + (shape.id to next))
                            }
                        }
                        if (edit.deleted) {
                            DocScanRow {
                                Text("Forma quitada", color = DocScanMuted, fontSize = 13.sp)
                                DocScanChip(active = false, onClick = { setShape(edit.copy(deleted = false)) }) {
                                    DocScanLabel("Recuperar")
                                }
                                DocScanDoneChip { deselect() }
                            }
                        } else {
                            DocScanRow {
                                DocScanChip(active = false, onClick = {
                                    setShape(edit.copy(widthScale = (edit.widthScale * 0.9f).coerceAtLeast(0.1f)))
                                }) { DocScanLabel("Más corta") }
                                DocScanChip(active = false, onClick = {
                                    setShape(edit.copy(widthScale = (edit.widthScale * 1.1f).coerceAtMost(6f)))
                                }) { DocScanLabel("Más larga") }
                                DocScanChip(active = false, onClick = {
                                    setShape(edit.copy(deleted = true))
                                    deselect()
                                }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = DocScanDanger, modifier = Modifier.size(20.dp))
                                }
                                if (edit != DocScanShapeEdit()) {
                                    DocScanChip(active = false, onClick = { setShape(DocScanShapeEdit()) }) {
                                        Icon(Icons.Rounded.Refresh, contentDescription = "Como estaba", tint = DocScanInk, modifier = Modifier.size(20.dp))
                                    }
                                }
                                DocScanDoneChip { deselect() }
                            }
                            DocScanPaletteRow(selected = edit.color ?: shape.color) { color -> setShape(edit.copy(color = color)) }
                            DocScanHint("Mantén presionada la forma para moverla.")
                        }
                    }

                    else -> {
                        if (pages.size > 1) {
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(horizontal = 10.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                itemsIndexed(pages, key = { _, page -> page.id }) { index, page ->
                                    val current = page.id == currentPage.id
                                    Box(
                                        modifier = Modifier
                                            .size(width = 42.dp, height = 54.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF22352B))
                                            .border(
                                                width = if (current) 2.dp else 1.dp,
                                                color = if (current) NeonGreen else Color(0xFF2E4237),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable { if (!current) currentId = page.id },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        val thumb = thumbs[page.id]
                                        if (thumb != null) {
                                            Image(
                                                bitmap = thumb,
                                                contentDescription = "Página ${index + 1}",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                        Text(
                                            "${index + 1}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .background(Color(0x99000000), RoundedCornerShape(topStart = 6.dp))
                                                .padding(horizontal = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            DocScanToolButton(Icons.Rounded.Description, "Texto", active = false) {
                                deselect()
                                showText = true
                            }
                            DocScanToolButton(Icons.Rounded.TextFields, "Escribir", active = false) { addText() }
                            DocScanToolButton(Icons.Rounded.Draw, "Firma", active = false) { showSignature = true }
                            DocScanToolButton(Icons.Rounded.Image, "Imagen", active = false) {
                                pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                            DocScanToolButton(Icons.Rounded.Visibility, "Comparar", active = compareAt != null) {
                                showOriginal = false
                                compareAt = if (compareAt == null && sheetReady) 0.5f else null
                            }
                        }
                        if (compareAt != null && sheetReady) {
                            DocScanHint("Arrastra la línea: a la izquierda la foto, a la derecha la nueva")
                        } else {
                            DocScanHint("Toca para escribir · Mantén presionado para mover")
                        }
                    }
                }
            }
        }

        // ---------------- Ventanas ----------------
        reviewList?.let { list ->
            val photo = pageBitmap
            val read = analysis
            if (photo == null || read == null || list.isEmpty()) {
                reviewList = null
            } else {
                DocScanReview(
                    doubts = list,
                    photo = photo,
                    onClose = { reviewList = null },
                    onFix = { doubt, fixed ->
                        val pageId = currentPage.id
                        val pageNow = edits[pageId] ?: DocScanPageEdits()
                        if (doubt.blockId >= 0) {
                            val block = read.blocks.firstOrNull { it.id == doubt.blockId }
                            if (block != null) {
                                val edit = pageNow.blocks[block.id] ?: block.originalEdit()
                                ScanReader.replaceWord(edit.text, doubt.word, fixed)?.let { setBlockEdit(pageId, block, edit.copy(text = it)) }
                            }
                        } else if (doubt.tableId >= 0) {
                            val table = read.tables.firstOrNull { it.id == doubt.tableId }
                            if (table != null) {
                                setTableEdit(pageId, table) { edit ->
                                    val cell = edit.data.cellAt(doubt.row, doubt.col)
                                    val text = cell?.let { ScanReader.replaceWord(it.text, doubt.word, fixed) }
                                    if (text == null) edit else edit.copy(data = edit.data.withText(doubt.row, doubt.col, text))
                                }
                            }
                        }
                    }
                )
            }
        }

        if (showText) {
            DocScanTextMode(
                pages = pages,
                currentPageId = currentPage.id,
                analyses = analyses,
                edits = edits,
                fontChoice = fontChoice,
                paid = textPaid,
                cost = tool.creditCost,
                onClose = { showText = false },
                onBlockText = { pageId, block, text ->
                    val edit = edits[pageId]?.blocks?.get(block.id) ?: block.originalEdit()
                    setBlockEdit(pageId, block, edit.copy(text = text, deleted = false), typing = true)
                },
                onAddedText = { pageId, textId, text ->
                    setAddedText(pageId, textId, typing = true) { it.copy(text = text) }
                },
                onCopy = { text ->
                    withPaidText(text) { value ->
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        runCatching { clipboard?.setPrimaryClip(ClipData.newPlainText("Texto escaneado", value)) }
                        onMessage("Texto copiado.")
                    }
                },
                onShare = { text ->
                    withPaidText(text) { value ->
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, value)
                        }
                        runCatching { context.startActivity(Intent.createChooser(send, "Compartir texto")) }
                    }
                }
            )
        }

        if (showSignature) {
            DocScanSignaturePad(
                onCancel = { showSignature = false },
                onDone = { bitmap ->
                    showSignature = false
                    addSign(bitmap)
                }
            )
        }

        if (showSave) {
            AlertDialog(
                onDismissRequest = { showSave = false },
                containerColor = CardGreen,
                title = { Text("Guardar como", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DocScanFormatOption(
                            "PDF",
                            if (pages.size > 1) "Las ${pages.size} páginas, como se ven. Con texto real que se puede editar y copiar."
                            else "Como se ve la hoja. Con texto real que se puede editar y copiar."
                        ) { chooseFormat(DOC_SCAN_FORMAT_PDF) }
                        DocScanFormatOption(
                            "PDF igual a la foto",
                            "La foto tal cual, con su texto escondido para buscar y copiar. El más seguro para trámites."
                        ) { chooseFormat(DOC_SCAN_FORMAT_PDF_PHOTO) }
                        DocScanFormatOption(
                            "Word para editar",
                            "Se abre bien en Word, Google Docs y WPS. Textos, tablas y logos en orden, fácil de seguir escribiendo."
                        ) {
                            chooseFormat(DOC_SCAN_FORMAT_WORD)
                        }
                        DocScanFormatOption("Word igual a la hoja", "Todo en su lugar exacto, como la hoja. Mejor en Microsoft Word.") {
                            chooseFormat(DOC_SCAN_FORMAT_WORD_SHEET)
                        }
                        val tableCount = analyses.values.sumOf { it.tables.size }
                        DocScanFormatOption(
                            "Excel",
                            if (tableCount > 0) "Las tablas ($tableCount), con sus celdas y números que se pueden sumar."
                            else "Las tablas de la hoja, con sus celdas y números que se pueden sumar."
                        ) { chooseFormat(DOC_SCAN_FORMAT_EXCEL) }
                        DocScanFormatOption(
                            "Imagen JPG",
                            if (pages.size > 1) "Esta página (la $pageNumber), como se ve." else "La hoja, como se ve."
                        ) { chooseFormat(DOC_SCAN_FORMAT_IMAGE) }
                        Text(
                            "Cada archivo cuesta ${tool.creditCost} créditos.",
                            color = DocScanMuted,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showSave = false }) { Text("Cancelar") }
                }
            )
        }

        if (modeAsk) {
            AlertDialog(
                onDismissRequest = { modeAsk = false },
                containerColor = CardGreen,
                title = { Text("¿Qué es esta hoja?", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf(
                            Triple(true, Icons.Rounded.PhotoCamera, "Foto de cámara" to "Endereza, quita sombras y revisa dos veces (trabaja más)."),
                            Triple(false, Icons.Rounded.Image, "Imagen limpia" to "Captura, PDF o imagen hecha en la compu o con IA: no se toca, se lee directo.")
                        ).forEach { (photo, icon, texts) ->
                            val active = currentPage.photo == photo
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (active) NeonGreen.copy(alpha = 0.16f) else Color(0x14FFFFFF))
                                    .clickable {
                                        modeAsk = false
                                        if (!active) onSetPhoto(currentPage.id, photo)?.let { currentId = it }
                                    }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(icon, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(24.dp))
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(texts.first, fontWeight = FontWeight.Bold, color = DocScanInk)
                                    Text(texts.second, fontSize = 12.sp, color = DocScanMuted)
                                }
                                if (active) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen)
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { modeAsk = false }) { Text("Listo", color = NeonGreen) } }
            )
        }

        if (aiAsk) {
            DocScanAiDialog { installed ->
                aiAsk = false
                aiInstalled = DocScanAiPack.missing(context).isEmpty()
                if (installed) onMessage("IA lista: se usa en las hojas que agregues.")
            }
        }

        if (confirmExit) {
            AlertDialog(
                onDismissRequest = { confirmExit = false },
                containerColor = CardGreen,
                title = { Text("¿Salir sin guardar?", fontWeight = FontWeight.Bold) },
                text = { Text("Se perderán los cambios que hiciste en este documento.") },
                confirmButton = {
                    TextButton(onClick = {
                        confirmExit = false
                        onClose()
                    }) { Text("Salir", color = DocScanDanger) }
                },
                dismissButton = {
                    TextButton(onClick = { confirmExit = false }) { Text("Seguir editando") }
                }
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Piezas de la interfaz
// ---------------------------------------------------------------------------

/** Color de cada tipo de parte que reconoce la IA. */
private fun docScanRegionColor(kind: Int): Color = when (kind) {
    DocScanLayoutAi.DOC_TITLE, DocScanLayoutAi.PARAGRAPH_TITLE -> Color(0xFFE53935)
    DocScanLayoutAi.TEXT -> Color(0xFF1E88E5)
    DocScanLayoutAi.TABLE -> Color(0xFF8E24AA)
    DocScanLayoutAi.HEADER, DocScanLayoutAi.FOOTER -> Color(0xFF6D4C41)
    in DocScanLayoutAi.FIGURES -> Color(0xFF43A047)
    else -> Color(0xFFFB8C00)
}

/** Color de Compose a entero ARGB de Android. */
private fun Color.toArgbInt(): Int {
    fun channel(value: Float) = (value * 255f + 0.5f).toInt().coerceIn(0, 255)
    return (channel(alpha) shl 24) or (channel(red) shl 16) or (channel(green) shl 8) or channel(blue)
}

/** Izquierda → centro → derecha → justificado → izquierda. */
private fun docScanNextAlign(align: Int): Int = when (align) {
    DOC_SCAN_ALIGN_LEFT -> DOC_SCAN_ALIGN_CENTER
    DOC_SCAN_ALIGN_CENTER -> DOC_SCAN_ALIGN_RIGHT
    DOC_SCAN_ALIGN_RIGHT -> DOC_SCAN_ALIGN_JUSTIFY
    else -> DOC_SCAN_ALIGN_LEFT
}

private fun docScanAlignIcon(align: Int): ImageVector = when (align) {
    DOC_SCAN_ALIGN_CENTER -> Icons.Rounded.FormatAlignCenter
    DOC_SCAN_ALIGN_RIGHT -> Icons.Rounded.FormatAlignRight
    DOC_SCAN_ALIGN_JUSTIFY -> Icons.Rounded.FormatAlignJustify
    else -> Icons.Rounded.FormatAlignLeft
}

@Composable
private fun DocScanStatusChip(text: String, modifier: Modifier) {
    Text(
        text,
        color = DocScanInk,
        fontSize = 13.sp,
        modifier = modifier
            .padding(top = 10.dp)
            .clip(RoundedCornerShape(50))
            .background(Color(0xE6101D16))
            .padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
private fun DocScanMenuLabel(text: String) {
    Text(
        text,
        color = DocScanMuted,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
    )
}

@Composable
private fun DocScanHint(text: String) {
    Text(
        text,
        color = DocScanMuted,
        fontSize = 12.sp,
        textAlign = TextAlign.Center,
        maxLines = 1,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
    )
}

@Composable
private fun DocScanRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        content()
    }
}

@Composable
private fun DocScanChip(
    active: Boolean,
    onClick: () -> Unit,
    enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .height(42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) DocScanChipOn else DocScanChipIdle)
            .border(
                width = 1.dp,
                color = if (active) NeonGreen.copy(alpha = 0.7f) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        content()
    }
}

/** Botón cuadrado de la barra de formato. */
@Composable
private fun DocScanIconChip(active: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .size(width = 44.dp, height = 42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) DocScanChipOn else DocScanChipIdle)
            .border(
                width = 1.dp,
                color = if (active) NeonGreen.copy(alpha = 0.7f) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
private fun DocScanDoneChip(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(width = 52.dp, height = 42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(NeonGreen)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.Check, contentDescription = "Listo", tint = DeepGreen, modifier = Modifier.size(24.dp))
    }
}

/** Botón grande de la barra de abajo (ícono y nombre corto). */
@Composable
private fun DocScanToolButton(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(66.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (active) DocScanChipOn else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = if (active) NeonGreen else DocScanInk, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (active) NeonGreen else DocScanInk, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun DocScanLabel(text: String) {
    Text(text, color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 13.sp)
}

/**
 * Barra de formato mientras se escribe: una sola fila encima del teclado.
 * [align] null = sin botón de alineación (textos agregados).
 */
@Composable
private fun DocScanEditBar(
    bold: Boolean,
    italic: Boolean,
    color: Int,
    align: Int?,
    showColors: Boolean,
    showFonts: Boolean,
    changed: Boolean,
    onBold: () -> Unit,
    onItalic: () -> Unit,
    onColors: () -> Unit,
    onFonts: () -> Unit,
    onSmaller: () -> Unit,
    onBigger: () -> Unit,
    onAlign: () -> Unit,
    onDelete: () -> Unit,
    onRestore: () -> Unit,
    onDone: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DocScanIconChip(active = bold, onClick = onBold) {
                Text("B", color = DocScanInk, fontWeight = FontWeight.Black, fontSize = 17.sp)
            }
            DocScanIconChip(active = italic, onClick = onItalic) {
                Text("I", color = DocScanInk, fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            DocScanIconChip(active = showFonts, onClick = onFonts) {
                Text("Aa", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            DocScanIconChip(active = showColors, onClick = onColors) {
                Box(
                    Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(Color(color))
                        .border(1.dp, DocScanMuted, CircleShape)
                )
            }
            DocScanIconChip(active = false, onClick = onSmaller) {
                Text("A−", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            DocScanIconChip(active = false, onClick = onBigger) {
                Text("A+", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            if (align != null) {
                DocScanIconChip(active = false, onClick = onAlign) {
                    Icon(docScanAlignIcon(align), contentDescription = "Alinear", tint = DocScanInk, modifier = Modifier.size(22.dp))
                }
            }
            DocScanIconChip(active = false, onClick = onDelete) {
                Icon(Icons.Rounded.Delete, contentDescription = "Borrar", tint = DocScanDanger, modifier = Modifier.size(21.dp))
            }
            if (changed) {
                DocScanIconChip(active = false, onClick = onRestore) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Como estaba", tint = DocScanInk, modifier = Modifier.size(21.dp))
                }
            }
        }
        Spacer(Modifier.width(6.dp))
        DocScanDoneChip(onDone)
    }
}

/** Letra de toda la hoja y tamaño de hoja (se abre con "Aa" al escribir). */
@Composable
private fun DocScanFontPanel(font: Int, paper: Int, autoPaper: String, onFont: (Int) -> Unit, onPaper: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Letra", color = DocScanMuted, fontSize = 12.sp)
            (listOf(DOC_SCAN_FONT_AUTO) + (0 until DocScanFonts.count)).forEach { option ->
                DocScanChip(active = font == option, onClick = { onFont(option) }) {
                    DocScanLabel(if (option == DOC_SCAN_FONT_AUTO) "Como la foto" else DocScanFonts.labels[option])
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Hoja", color = DocScanMuted, fontSize = 12.sp)
            (listOf(DOC_SCAN_PAPER_AUTO) + (0..3)).forEach { option ->
                DocScanChip(active = paper == option, onClick = { onPaper(option) }) {
                    DocScanLabel(
                        if (option == DOC_SCAN_PAPER_AUTO) (if (autoPaper.isEmpty()) "Automática" else "Auto ($autoPaper)")
                        else ScanRebuild.papers[option].first
                    )
                }
            }
        }
    }
}

@Composable
private fun DocScanPaletteRow(selected: Int, onPick: (Int) -> Unit) {
    DocScanRow {
        DocScanPalette.forEach { swatch ->
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(swatch))
                    .border(
                        width = if (selected == swatch) 2.dp else 1.dp,
                        color = if (selected == swatch) NeonGreen else DocScanMuted,
                        shape = CircleShape
                    )
                    .clickable { onPick(swatch) }
            )
        }
    }
}

@Composable
private fun DocScanFormatOption(title: String, detail: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF123524))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(title, fontWeight = FontWeight.Bold, color = NeonGreen)
        Text(detail, style = MaterialTheme.typography.bodySmall, color = DocScanInk.copy(alpha = 0.85f))
    }
}

/**
 * Escribir directo sobre la hoja, como en Word: un campo de texto puesto justo
 * encima del párrafo, con la misma letra, tamaño, color, ancho y alineación.
 * La hoja se ve detrás. Todo va en píxeles de la hoja encajada ([left], [baseline],
 * [width], [fontSize], [leading]); el zoom lo lleva a la pantalla.
 * Arriba tiene una manija para arrastrarlo.
 */
@Composable
private fun DocScanInlineEditor(
    zoom: DocScanZoomState,
    /**
     * true: las letras que se ven son las de la hoja (fijas, no se mueven con el zoom).
     * El cuadro del teclado queda invisible; el cursor lo dibuja la hoja.
     */
    sheetLetters: Boolean,
    fieldKey: String,
    text: String,
    selectAll: Boolean,
    left: Float,
    baseline: Float,
    width: Float?,
    fontSize: Float,
    leading: Float,
    scaleX: Float,
    typeface: android.graphics.Typeface,
    color: Color,
    align: Int,
    singleLine: Boolean,
    cover: Color?,
    pendingTap: Offset?,
    onTapUsed: () -> Unit,
    dragOffset: () -> Offset,
    focusRequester: FocusRequester,
    onText: (String) -> Unit,
    onDone: () -> Unit,
    onMoveStart: () -> Unit,
    onMove: (Offset) -> Unit,
    onMoveEnd: () -> Unit,
    /** Zoom quieto (escala, x, y): el cuadro se arma con esto y no se rehace en cada cuadro del zoom. */
    view: Triple<Float, Float, Float>,
    /** false mientras el zoom se mueve (la hoja dibuja el párrafo pegado a ella). */
    visible: Boolean,
    /** Avisa que la hoja se corrió sola (para seguir al cursor) y ya está quieta. */
    onSettle: () -> Unit,
    /** Estirar el cuadro de texto desde su borde derecho (en píxeles de la hoja encajada). */
    onResizeStart: (() -> Unit)? = null,
    onResize: ((Float) -> Unit)? = null,
    /** Arriba y alto del cuadro (píxeles de la hoja encajada), con [sheetLetters]. */
    boxTop: Float = 0f,
    boxHeight: Float = 0f,
    /** Letra del texto donde se tocó (píxeles de la hoja encajada), con [sheetLetters]. */
    tapToOffset: ((Offset) -> Int?)? = null,
    /** Dónde está el cursor (píxeles de la hoja encajada), con [sheetLetters]. */
    caretRect: ((Int) -> android.graphics.RectF?)? = null,
    onSelection: ((TextRange) -> Unit)? = null,
    /** Doble toque (píxeles de la hoja encajada): se elige la palabra de ahí. */
    pendingWord: Offset? = null,
    onWordUsed: () -> Unit = {}
) {
    val density = LocalDensity.current
    val (scale, viewX, viewY) = view
    val screenFont = (fontSize * scale).coerceAtLeast(2f)
    val screenLeading = (leading * scale).coerceAtLeast(screenFont)
    var field by remember(fieldKey) {
        mutableStateOf(TextFieldValue(text, if (selectAll) TextRange(0, text.length) else TextRange(text.length)))
    }
    // Si el texto cambió por fuera (deshacer, rehacer, modo texto), se muestra el del documento.
    val shown = if (field.text == text) field else TextFieldValue(text, TextRange(text.length))
    var firstBaseline by remember(fieldKey) { mutableFloatStateOf(Float.NaN) }
    var textLayout by remember(fieldKey) { mutableStateOf<TextLayoutResult?>(null) }
    val latestTap by rememberUpdatedState(pendingTap)
    val latestTapUsed by rememberUpdatedState(onTapUsed)
    val latestMoveStart by rememberUpdatedState(onMoveStart)
    val latestMove by rememberUpdatedState(onMove)
    val latestMoveEnd by rememberUpdatedState(onMoveEnd)
    val latestView by rememberUpdatedState(view)
    val latestResizeStart by rememberUpdatedState(onResizeStart)
    val latestResize by rememberUpdatedState(onResize)
    val fontFamily = remember(typeface) { FontFamily(androidx.compose.ui.text.font.Typeface(typeface)) }
    val style = TextStyle(
        color = color,
        fontSize = with(density) { screenFont.toSp() },
        lineHeight = with(density) { screenLeading.toSp() },
        fontFamily = fontFamily,
        textAlign = when (align) {
            DOC_SCAN_ALIGN_CENTER -> TextAlign.Center
            DOC_SCAN_ALIGN_RIGHT -> TextAlign.Right
            DOC_SCAN_ALIGN_JUSTIFY -> TextAlign.Justify
            else -> TextAlign.Left
        },
        textGeometricTransform = TextGeometricTransform(scaleX = scaleX),
        lineBreak = LineBreak.Simple
    )
    val handleSize = 34.dp
    val handlePx = with(density) { handleSize.toPx() }

    // Esquina de arriba a la izquierda del campo, en la pantalla (la línea base cae justo
    // donde estaba el texto de la hoja).
    fun topLeft(): Offset {
        val (s, x, y) = latestView
        val drag = dragOffset()
        if (sheetLetters) return Offset(left * s + x + drag.x * s, boxTop * s + y + drag.y * s)
        val base = if (firstBaseline.isNaN()) (fontSize * s) * 0.8f else firstBaseline
        return Offset(left * s + x + drag.x * s, baseline * s + y + drag.y * s - base)
    }

    // El cursor siempre a la vista: solo cuando se escribe o se mueve el cursor
    // (no cuando se hace zoom).
    LaunchedEffect(shown.text, shown.selection) {
        onSelection?.invoke(shown.selection)
        if (sheetLetters) {
            val rect = caretRect?.invoke(shown.selection.end) ?: return@LaunchedEffect
            val (s, x, y) = latestView
            if (zoom.keepVisible(rect.left * s + x, rect.top * s + y, rect.bottom * s + y)) onSettle()
            return@LaunchedEffect
        }
        val result = textLayout ?: return@LaunchedEffect
        val length = result.layoutInput.text.text.length
        val cursor = result.getCursorRect(shown.selection.end.coerceIn(0, length))
        val origin = topLeft()
        if (zoom.keepVisible(origin.x + cursor.left, origin.y + cursor.top, origin.y + cursor.bottom)) onSettle()
    }
    // Tocar el párrafo pone el cursor en esa letra (medida con las letras de la hoja).
    LaunchedEffect(pendingTap, sheetLetters) {
        if (!sheetLetters) return@LaunchedEffect
        val tap = pendingTap ?: return@LaunchedEffect
        val offset = tapToOffset?.invoke(tap)
        if (offset != null) field = TextFieldValue(text, TextRange(offset.coerceIn(0, text.length)))
        onTapUsed()
    }

    // Doble toque: la palabra entera queda elegida.
    LaunchedEffect(pendingWord) {
        val tap = pendingWord ?: return@LaunchedEffect
        val offset = if (sheetLetters) {
            tapToOffset?.invoke(tap)
        } else {
            textLayout?.let { result ->
                val (s, x, y) = latestView
                val fieldLeft = left * s + x
                val fieldTop = baseline * s + y - result.firstBaseline
                result.getOffsetForPosition(Offset(tap.x * s + x - fieldLeft, tap.y * s + y - fieldTop))
            }
        }
        onWordUsed()
        if (offset == null) return@LaunchedEffect
        val range = docScanWordAt(text, offset)
        field = TextFieldValue(text, range)
    }

    val hiddenSelection = remember { TextSelectionColors(handleColor = Color.Transparent, backgroundColor = Color.Transparent) }
    CompositionLocalProvider(LocalTextSelectionColors provides if (sheetLetters) hiddenSelection else LocalTextSelectionColors.current) {
    BasicTextField(
        value = shown,
        onValueChange = { next ->
            field = next
            if (next.text != text) onText(next.text)
        },
        // Con las letras de la hoja, el cuadro no se ve (ni su letra ni su cursor).
        textStyle = if (sheetLetters) style.copy(color = Color.Transparent) else style,
        singleLine = singleLine,
        cursorBrush = SolidColor(if (sheetLetters) Color.Transparent else DocScanFocus),
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.Sentences,
            imeAction = if (singleLine) ImeAction.Done else ImeAction.Default
        ),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        onTextLayout = { result ->
            firstBaseline = result.firstBaseline
            textLayout = result
            val tap = latestTap
            if (tap != null && !sheetLetters) {
                // El cursor va donde se tocó la hoja.
                val (s, x, y) = latestView
                val fieldLeft = left * s + x
                val fieldTop = baseline * s + y - result.firstBaseline
                val offset = result.getOffsetForPosition(Offset(tap.x * s + x - fieldLeft, tap.y * s + y - fieldTop))
                field = TextFieldValue(result.layoutInput.text.text, TextRange(offset))
                latestTapUsed()
            }
        },
        modifier = if (sheetLetters) {
            // Invisible y chiquito (no tapa la hoja ni recibe los toques): solo para el teclado.
            Modifier
                .offset {
                    val point = topLeft()
                    IntOffset(point.x.roundToInt(), point.y.roundToInt())
                }
                .requiredSize(1.dp)
                .alpha(0f)
                .focusRequester(focusRequester)
        } else {
            Modifier
                .offset {
                    val point = topLeft()
                    IntOffset(point.x.roundToInt(), point.y.roundToInt())
                }
                .wrapContentSize(Alignment.TopStart, unbounded = true)
                .then(
                    if (width != null) {
                        Modifier.width(with(density) { (width * scale).coerceAtLeast(8f).toDp() })
                    } else {
                        Modifier.widthIn(min = 20.dp)
                    }
                )
                .alpha(if (visible) 1f else 0f)
                .then(if (cover != null && visible) Modifier.background(cover) else Modifier)
                // Borde del cuadro de texto (como en Word).
                .then(if (width != null && visible) Modifier.border(1.dp, DocScanFocus.copy(alpha = 0.55f)) else Modifier)
                .focusRequester(focusRequester)
        }
    )
    }

    // Tirador del borde derecho: estira o achica el cuadro y el texto se acomoda.
    if (visible && width != null && onResize != null) {
        val pillWidth = 14.dp
        val pillHeight = 40.dp
        val pillWidthPx = with(density) { pillWidth.toPx() }
        val pillHeightPx = with(density) { pillHeight.toPx() }
        Box(
            modifier = Modifier
                .offset {
                    val point = topLeft()
                    val fieldHeight = if (sheetLetters) boxHeight * latestView.first else textLayout?.size?.height?.toFloat() ?: (screenLeading)
                    IntOffset(
                        (point.x + width * latestView.first - pillWidthPx / 2f).roundToInt(),
                        (point.y + fieldHeight / 2f - pillHeightPx / 2f).roundToInt()
                    )
                }
                .size(width = pillWidth, height = pillHeight)
                .clip(RoundedCornerShape(7.dp))
                .background(DocScanFocus)
                .border(2.dp, Color.White, RoundedCornerShape(7.dp))
                .pointerInput(fieldKey) {
                    detectDragGestures(
                        onDragStart = { latestResizeStart?.invoke() },
                        onDrag = { change, amount ->
                            change.consume()
                            latestResize?.invoke(amount.x / latestView.first)
                        }
                    )
                }
        )
    }

    // Manija para mover (arriba a la izquierda del párrafo).
    if (visible) {
        Box(
            modifier = Modifier
                .offset {
                    val point = topLeft()
                    IntOffset((point.x - handlePx * 0.2f).roundToInt(), (point.y - handlePx - 8f).roundToInt())
                }
                .size(handleSize)
                .clip(CircleShape)
                .background(DocScanFocus)
                .pointerInput(fieldKey) {
                    detectDragGestures(
                        onDragStart = { latestMoveStart() },
                        onDrag = { change, amount ->
                            change.consume()
                            val s = latestView.first
                            latestMove(Offset(amount.x / s, amount.y / s))
                        },
                        onDragEnd = { latestMoveEnd() },
                        onDragCancel = { latestMoveEnd() }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.OpenWith, contentDescription = "Mover", tint = Color.White, modifier = Modifier.size(20.dp))
        }
    }
}

/** Palabra que contiene la letra [offset] (letras, números, tildes y guiones internos). */
internal fun docScanWordAt(text: String, offset: Int): TextRange {
    if (text.isEmpty()) return TextRange(0)
    fun part(c: Char) = c.isLetterOrDigit() || c == '\'' || c == '’'
    var at = offset.coerceIn(0, text.length)
    // Si se tocó justo después de la palabra (o en un espacio pegado), se toma la de la izquierda.
    if ((at == text.length || !part(text[at])) && at > 0 && part(text[at - 1])) at--
    if (at >= text.length || !part(text[at])) return TextRange(offset.coerceIn(0, text.length))
    var start = at
    var end = at
    while (start > 0 && (part(text[start - 1]) || (text[start - 1] == '-' && start > 1 && part(text[start - 2])))) start--
    while (end < text.length && (part(text[end]) || (text[end] == '-' && end + 1 < text.length && part(text[end + 1])))) end++
    return TextRange(start, end)
}

/**
 * Cursor, selección y borde del cuadro de texto, dibujados sobre las letras de la hoja
 * (lienzo en píxeles de la foto analizada).
 */
private fun docScanDrawCaret(
    canvas: android.graphics.Canvas,
    runs: List<DocScanRun>,
    starts: IntArray,
    selection: TextRange,
    caretOn: Boolean,
    placed: DocScanPlacedBlock?,
    paint: android.graphics.Paint,
    measure: android.graphics.Paint,
    lineWidth: Float
) {
    val focus = DocScanFocus.toArgb()
    if (placed != null) {
        val top = runs.firstOrNull()?.let { it.baseline - it.size * 0.95f } ?: placed.rect.top
        val bottom = runs.lastOrNull()?.let { it.baseline + it.size * 0.3f } ?: placed.rect.bottom
        paint.style = android.graphics.Paint.Style.STROKE
        paint.strokeWidth = lineWidth * 0.6f
        paint.color = (focus and 0x00FFFFFF) or (140 shl 24)
        canvas.drawRect(placed.areaLeft - lineWidth * 2f, top, placed.areaRight + lineWidth * 2f, bottom, paint)
    }
    paint.style = android.graphics.Paint.Style.FILL
    if (!selection.collapsed) {
        paint.color = (focus and 0x00FFFFFF) or (80 shl 24)
        for (i in runs.indices) {
            val run = runs[i]
            val from = max(selection.min, starts[i]) - starts[i]
            val to = min(selection.max, starts[i] + run.text.length) - starts[i]
            if (from >= to) continue
            val x0 = docScanCaretX(run, from, measure)
            val x1 = docScanCaretX(run, to, measure)
            canvas.drawRect(x0, run.baseline - run.size * 0.92f, x1, run.baseline + run.size * 0.28f, paint)
        }
    }
    if (!caretOn) return
    paint.color = focus
    if (runs.isEmpty()) {
        if (placed == null) return
        val x = when (placed.align) {
            DOC_SCAN_ALIGN_CENTER -> (placed.areaLeft + placed.areaRight) / 2f
            DOC_SCAN_ALIGN_RIGHT -> placed.areaRight
            else -> placed.areaLeft
        }
        canvas.drawRect(x - lineWidth / 2f, placed.baseline - placed.size * 0.92f, x + lineWidth / 2f, placed.baseline + placed.size * 0.28f, paint)
        return
    }
    val line = docScanRunFor(selection.end, runs, starts)
    val run = runs[line]
    val x = docScanCaretX(run, selection.end - starts[line], measure)
    canvas.drawRect(x - lineWidth / 2f, run.baseline - run.size * 0.92f, x + lineWidth / 2f, run.baseline + run.size * 0.28f, paint)
}

/** Un párrafo en el modo texto. */
private class DocScanNote(
    val key: String,
    val top: Float,
    val left: Float,
    val text: String,
    val bold: Boolean,
    val block: DocScanBlock?,
    val textId: Int
)

/**
 * Modo texto: la hoja como un bloc de notas. Cada párrafo se edita como texto
 * normal y el cambio pasa a la hoja (en su lugar, con su letra). Desde aquí
 * también se copia o comparte todo el texto, en orden.
 */
@Composable
private fun DocScanTextMode(
    pages: List<DocScanPage>,
    currentPageId: Int,
    analyses: MutableMap<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    fontChoice: Int,
    paid: Boolean,
    cost: Int,
    onClose: () -> Unit,
    onBlockText: (Int, DocScanBlock, String) -> Unit,
    onAddedText: (Int, Int, String) -> Unit,
    onCopy: (String) -> Unit,
    onShare: (String) -> Unit
) {
    val context = LocalContext.current
    var allPages by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }

    // Para "Todas las páginas" se leen las que todavía no se abrieron.
    LaunchedEffect(allPages) {
        if (!allPages) return@LaunchedEffect
        if (pages.all { analyses[it.id] != null }) return@LaunchedEffect
        loading = true
        try {
            val read = docScanEnsureAnalyses(context, pages, analyses.toMap())
            read.forEach { (id, value) -> analyses[id] = value }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            // Se muestra lo que se pudo leer.
        } finally {
            loading = false
        }
    }

    val analysis = analyses[currentPageId]
    val pageEdits = edits[currentPageId] ?: DocScanPageEdits()
    val layout = remember(analysis, pageEdits.blocks, fontChoice) {
        analysis?.takeIf { it.blocks.isNotEmpty() }?.let { docScanLayout(it, pageEdits.blocks, fontChoice) }
    }
    val notes = remember(layout, pageEdits.texts, analysis) {
        val list = ArrayList<DocScanNote>()
        val read = analysis
        if (read != null && layout != null) {
            for (placed in layout.blocks) {
                if (placed.deleted) continue
                val block = read.blocks.firstOrNull { it.id == placed.id } ?: continue
                list += DocScanNote("b${placed.id}", placed.rect.top, placed.rect.left, placed.text, placed.bold, block, -1)
            }
        }
        val pageWidth = (read?.width ?: 1).toFloat()
        val pageHeight = (read?.height ?: 1).toFloat()
        for (added in pageEdits.texts) {
            list += DocScanNote(
                "t${added.id}", (added.y - added.size) * pageHeight, added.x * pageWidth, added.text, added.bold, null, added.id
            )
        }
        list.sortedWith(compareBy<DocScanNote>({ it.top }, { it.left }))
    }
    val pageIndex = pages.indexOfFirst { it.id == currentPageId }
    val copyText = when {
        loading -> ""
        else -> docScanAllText(
            if (allPages) pages else listOfNotNull(pages.getOrNull(pageIndex)),
            analyses,
            edits,
            fontChoice
        )
    }
    val price = if (paid) "" else " · $cost créditos"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DocScanBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = DocScanInk)
            }
            Column(Modifier.weight(1f)) {
                Text("Texto de la hoja", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    (if (pages.size > 1) "Página ${pageIndex + 1} · " else "") + "Toca y escribe: pasa a la hoja",
                    color = DocScanMuted,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }
            Box(
                modifier = Modifier
                    .padding(end = 8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(NeonGreen)
                    .clickable { onClose() }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text("Ver hoja", color = DeepGreen, fontWeight = FontWeight.Black, fontSize = 14.sp)
            }
        }

        // La hoja como bloc de notas.
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFFFAFBF8))
        ) {
            if (notes.isEmpty()) {
                Text(
                    if (analysis == null) "Espera a que termine de leer la hoja." else "No se encontró texto en esta página.",
                    color = Color(0xFF5A665F),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(notes, key = { it.key }) { note ->
                        DocScanNoteField(
                            fieldKey = note.key,
                            text = note.text,
                            bold = note.bold,
                            onText = { value ->
                                val block = note.block
                                if (block != null) onBlockText(currentPageId, block, value) else onAddedText(currentPageId, note.textId, value)
                            }
                        )
                        HorizontalDivider(
                            color = Color(0xFFE3E8E4),
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            }
        }

        if (pages.size > 1) {
            Spacer(Modifier.height(8.dp))
            DocScanRow {
                Text("Copiar:", color = DocScanMuted, fontSize = 13.sp)
                DocScanChip(active = !allPages, onClick = { allPages = false }) { DocScanLabel("Esta página") }
                DocScanChip(active = allPages, onClick = { allPages = true }) { DocScanLabel("Todas") }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(DocScanChipIdle)
                    .clickable(enabled = !loading && copyText.isNotBlank()) { onCopy(copyText) },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = DocScanInk, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Copiar$price", color = DocScanInk, fontWeight = FontWeight.Bold)
            }
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(DocScanChipIdle)
                    .clickable(enabled = !loading && copyText.isNotBlank()) { onShare(copyText) },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Share, contentDescription = null, tint = DocScanInk, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Compartir$price", color = DocScanInk, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Cuadro para escribir en una celda de tabla (con su nombre: fila y columna). */
@Composable
private fun DocScanCellField(
    fieldKey: String,
    label: String,
    text: String,
    focus: FocusRequester,
    onText: (String) -> Unit,
    onNext: () -> Unit
) {
    var field by remember(fieldKey) { mutableStateOf(TextFieldValue(text, TextRange(text.length))) }
    val shown = if (field.text == text) field else TextFieldValue(text, TextRange(text.length))
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .border(1.dp, DocScanFocus.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(label, color = Color(0xFF5B6B62), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        BasicTextField(
            value = shown,
            onValueChange = { next ->
                field = next
                if (next.text != text) onText(next.text)
            },
            textStyle = TextStyle(color = Color(0xFF1C2420), fontSize = 16.sp, lineHeight = 21.sp),
            cursorBrush = SolidColor(DocScanFocus),
            maxLines = 4,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { onNext() }),
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(focus)
                .padding(vertical = 2.dp)
        )
    }
}

/** Un párrafo editable del modo texto. */
@Composable
private fun DocScanNoteField(fieldKey: String, text: String, bold: Boolean, onText: (String) -> Unit) {
    var field by remember(fieldKey) { mutableStateOf(TextFieldValue(text, TextRange(text.length))) }
    val shown = if (field.text == text) field else TextFieldValue(text, TextRange(text.length))
    BasicTextField(
        value = shown,
        onValueChange = { next ->
            field = next
            if (next.text != text) onText(next.text)
        },
        textStyle = TextStyle(
            color = Color(0xFF1C2420),
            fontSize = 16.sp,
            lineHeight = 23.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        ),
        cursorBrush = SolidColor(DocScanFocus),
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 11.dp)
    )
}

/** Cuadro para firmar con el dedo. Devuelve la firma como imagen con fondo transparente. */
@Composable
private fun DocScanSignaturePad(onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    val live = remember { mutableStateListOf<Offset>() }
    val strokeWidthPx = with(LocalDensity.current) { 3.dp.toPx() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xE6000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 18.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(DocScanBar)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Firma con el dedo", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { start ->
                                live.clear()
                                live.add(start)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                live.add(change.position)
                            },
                            onDragEnd = {
                                if (live.size > 1) strokes.add(live.toList())
                                live.clear()
                            },
                            onDragCancel = { live.clear() }
                        )
                    }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val ink = Color(DocScanSignatureInk)
                    fun line(points: List<Offset>) {
                        for (index in 1 until points.size) {
                            drawLine(
                                color = ink,
                                start = points[index - 1],
                                end = points[index],
                                strokeWidth = strokeWidthPx,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                    strokes.forEach { line(it) }
                    line(live.toList())
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DocScanChip(active = false, onClick = {
                    strokes.clear()
                    live.clear()
                }) { DocScanLabel("Limpiar") }
                Spacer(Modifier.weight(1f))
                DocScanChip(active = false, onClick = onCancel) { DocScanLabel("Cancelar") }
                DocScanChip(active = true, enabled = strokes.isNotEmpty(), onClick = {
                    val bitmap = docScanSignatureBitmap(strokes.toList(), strokeWidthPx)
                    if (bitmap != null) onDone(bitmap) else onCancel()
                }) {
                    Text("Usar", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

/** Pasa los trazos a una imagen recortada justo al tamaño de la firma. */
private fun docScanSignatureBitmap(strokes: List<List<Offset>>, strokeWidthPx: Float): Bitmap? {
    val points = strokes.flatten()
    if (points.size < 2) return null
    val margin = strokeWidthPx * 2f + 4f
    val left = points.minOf { it.x } - margin
    val top = points.minOf { it.y } - margin
    val width = (points.maxOf { it.x } + margin - left).roundToInt().coerceIn(8, 4000)
    val height = (points.maxOf { it.y } + margin - top).roundToInt().coerceIn(8, 4000)
    return runCatching {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = DocScanSignatureInk
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = strokeWidthPx
            strokeCap = android.graphics.Paint.Cap.ROUND
            strokeJoin = android.graphics.Paint.Join.ROUND
        }
        strokes.forEach { stroke ->
            if (stroke.size < 2) return@forEach
            val path = android.graphics.Path()
            path.moveTo(stroke[0].x - left, stroke[0].y - top)
            for (index in 1 until stroke.size) path.lineTo(stroke[index].x - left, stroke[index].y - top)
            canvas.drawPath(path, paint)
        }
        bitmap
    }.getOrNull()
}

/**
 * Revisar palabras dudosas una por una: arriba el pedazo de la foto (como está en el
 * papel) y abajo la palabra leída para corregirla. "Está bien" pasa a la siguiente.
 */
@Composable
private fun DocScanReview(
    doubts: List<DocScanDoubt>,
    photo: Bitmap,
    onClose: () -> Unit,
    onFix: (DocScanDoubt, String) -> Unit
) {
    var index by remember { mutableIntStateOf(0) }
    val doubt = doubts[index.coerceIn(0, doubts.size - 1)]
    var value by remember(index) { mutableStateOf(doubt.word) }
    // El renglón o la celda de la foto, con un poco de margen.
    val crop = remember(index, photo) {
        runCatching {
            if (photo.isRecycled) return@runCatching null
            val box = doubt.box
            val margin = (box.height() * 0.4f).roundToInt().coerceAtLeast(6)
            val rect = android.graphics.Rect(box.left - margin, box.top - margin, box.right + margin, box.bottom + margin)
            if (!rect.intersect(0, 0, photo.width, photo.height) || rect.width() < 2 || rect.height() < 2) null
            else Bitmap.createBitmap(photo, rect.left, rect.top, rect.width(), rect.height()).asImageBitmap()
        }.getOrNull()
    }
    fun next() {
        if (index >= doubts.size - 1) onClose() else index++
    }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = CardGreen,
        title = { Text("Revisar · ${index + 1} de ${doubts.size}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Así está en la foto:", color = DocScanMuted, fontSize = 13.sp)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    val image = crop
                    if (image != null) {
                        Image(image, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                    }
                }
                Text("Se leyó \"${doubt.word}\". Corrígela si está mal:", color = DocScanMuted, fontSize = 13.sp)
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it.replace("\n", " ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val fixed = value.trim()
                if (fixed.isNotEmpty() && fixed != doubt.word) onFix(doubt, fixed)
                next()
            }) { Text(if (value.trim() != doubt.word) "Cambiar" else "Está bien", color = NeonGreen) }
        },
        dismissButton = {
            Row {
                if (index > 0) TextButton(onClick = { index-- }) { Text("Anterior") }
                TextButton(onClick = onClose) { Text("Cerrar") }
            }
        }
    )
}
