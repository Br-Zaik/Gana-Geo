package com.ganageo.app.ui.tools

import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Las IA del Escáner (todas gratis, de uso comercial, Apache 2.0):
 * - partes de la hoja (PP-DocLayout-S),
 * - segundo lector de letras (PP-OCRv5 latino, con su lista de letras),
 * - aplanar hojas dobladas (UVDoc),
 * - esquinas de la hoja (DocAligner, DocsaidLab).
 *
 * Normalmente vienen dentro de la app (las baja GitHub al compilar). Si alguna no vino,
 * se puede bajar UNA vez desde la app (necesita internet) y queda guardada en el
 * celular: después todo funciona sin internet. Sin ellas el Escáner igual funciona.
 */
internal object DocScanAiPack {
    class Part(
        val asset: String?,
        val file: String,
        val url: String,
        val minBytes: Long,
        val maxBytes: Long,
        val label: String,
        /** Se prueba que abra con ONNX Runtime antes de guardarlo. */
        val onnx: Boolean,
        /** Huella SHA-256 publicada por sus autores (si la hay): se comprueba al bajar. */
        val sha256: String? = null
    )

    private const val HF = "https://huggingface.co/monkt/paddleocr-onnx/resolve/main"

    val LAYOUT = Part(
        "models/pp_doclayout_s.onnx", "pp_doclayout_s.onnx",
        "https://huggingface.co/stefanj0/PP-DocLayout-S-ONNX/resolve/main/pp_doclayout_s.onnx",
        1_000_000L, 60_000_000L, "Partes de la hoja", onnx = true
    )
    val READER = Part(
        "models/latin_rec.onnx", "latin_rec.onnx", "$HF/languages/latin/rec.onnx",
        1_000_000L, 120_000_000L, "Lector de letras", onnx = true
    )
    val DICT = Part(
        "models/latin_dict.txt", "latin_dict.txt", "$HF/languages/latin/dict.txt",
        300L, 2_000_000L, "Letras del lector", onnx = false
    )
    /** La otra lista de letras (la oficial); se prueba si la primera no calza. */
    val DICT_OFFICIAL = Part(
        null, "latin_dict_oficial.txt",
        "https://raw.githubusercontent.com/PaddlePaddle/PaddleOCR/main/ppocr/utils/dict/ppocrv5_latin_dict.txt",
        300L, 2_000_000L, "Letras del lector", onnx = false
    )
    val UNWARP = Part(
        "models/uvdoc.onnx", "uvdoc.onnx", "$HF/preprocessing/doc-unwarping/UVDoc.onnx",
        1_000_000L, 150_000_000L, "Aplanar hojas", onnx = true
    )

    /** Esquinas de la hoja: DocAligner FastViT-T8 (DocsaidLab, Apache 2.0), versión 1.1.1. */
    val CORNERS = Part(
        "models/docaligner.onnx", "docaligner.onnx",
        "https://github.com/DocsaidLab/DocAligner/releases/download/1.1.1/fastvit_t8_h_e_bifpn_256_fp32.onnx",
        1_000_000L, 40_000_000L, "Esquinas de la hoja", onnx = true,
        sha256 = "950070fd4a46e25d46db7c35d0ed77612d9063f70d4543c7c504f0da6a943a89"
    )

    private val all = listOf(LAYOUT, READER, DICT, UNWARP, CORNERS)

    /** La persona dijo "sin IA" en esta vez que abrió la app: no se pregunta de nuevo. */
    @Volatile var declined = false

    private fun folder(context: Context) = File(context.applicationContext.filesDir, "models")

    fun localFile(context: Context, part: Part): File = File(folder(context), part.file)

    private fun inApp(context: Context, part: Part): Boolean {
        val asset = part.asset ?: return false
        return runCatching { context.applicationContext.assets.open(asset).use { it.read() >= 0 } }.getOrDefault(false)
    }

    private fun onPhone(context: Context, part: Part): Boolean =
        localFile(context, part).let { it.isFile && it.length() >= part.minBytes }

    fun has(context: Context, part: Part): Boolean = inApp(context, part) || onPhone(context, part)

    /** Las que faltan (ni en la app ni bajadas). */
    fun missing(context: Context): List<Part> = all.filter { !has(context, it) }

    /** Bytes del modelo: de la app o del celular. null si no está. */
    fun bytes(context: Context, part: Part): ByteArray? {
        part.asset?.let { asset ->
            runCatching { context.applicationContext.assets.open(asset).use { it.readBytes() } }.getOrNull()?.let { return it }
        }
        val file = localFile(context, part)
        return if (file.isFile && file.length() >= part.minBytes) runCatching { file.readBytes() }.getOrNull() else null
    }

    /** Texto (lista de letras): de la app o del celular. */
    fun text(context: Context, part: Part): String? = bytes(context, part)?.toString(Charsets.UTF_8)

    /**
     * Baja lo que falta, una por una. [onProgress]: (cuál va, cuántas son, avance 0..1 de esa).
     * Devuelve null si todo salió bien, o el motivo. Llamar fuera del hilo principal.
     */
    fun download(context: Context, onProgress: (Int, Int, Float) -> Unit): String? {
        val parts = missing(context).toMutableList()
        if (DICT in parts || READER in parts) parts += DICT_OFFICIAL
        val total = parts.size
        var failure: String? = null
        parts.forEachIndexed { index, part ->
            if (Thread.currentThread().isInterrupted) return "Cancelado."
            onProgress(index, total, 0f)
            val error = fetch(part, localFile(context, part)) { onProgress(index, total, it) }
            // La lista oficial es solo un respaldo: si no baja, no es un error.
            if (error != null && part !== DICT_OFFICIAL && failure == null) failure = "${part.label}: $error"
        }
        // Que las IA se vuelvan a abrir con lo bajado.
        DocScanLayoutAi.reset()
        DocScanReaderAi.reset()
        DocScanUnwarpAi.reset()
        DocScanCornerAi.reset()
        onProgress(total, total, 1f)
        return failure
    }

    /** Baja un archivo por HTTPS (sigue redirecciones solo a HTTPS) y lo prueba antes de dejarlo. */
    private fun fetch(part: Part, target: File, onProgress: (Float) -> Unit): String? {
        target.parentFile?.mkdirs()
        val temp = File(target.parentFile, "${target.name}.part")
        var connection: HttpURLConnection? = null
        try {
            var url = URL(part.url)
            var redirects = 0
            while (true) {
                connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 30_000
                    instanceFollowRedirects = false
                    setRequestProperty("User-Agent", "GanaGeo")
                }
                val code = connection.responseCode
                if (code in 300..399) {
                    val next = connection.getHeaderField("Location") ?: return "el servidor no dio la dirección."
                    connection.disconnect()
                    url = URL(url, next)
                    if (url.protocol != "https") return "dirección no segura."
                    if (++redirects > 6) return "demasiadas redirecciones."
                    continue
                }
                if (code != 200) return "el servidor respondió $code."
                break
            }
            val open = connection ?: return "no se pudo conectar."
            val size = open.contentLengthLong
            if (size > part.maxBytes) return "el archivo es demasiado grande."
            var read = 0L
            open.inputStream.use { input ->
                temp.outputStream().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        if (Thread.currentThread().isInterrupted) return "cancelado."
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        read += count
                        if (read > part.maxBytes) return "el archivo es demasiado grande."
                        if (size > 0) onProgress((read.toFloat() / size).coerceIn(0f, 1f))
                    }
                }
            }
            if (read < part.minBytes || (size > 0 && read != size)) return "la descarga se cortó."
            part.sha256?.let { expected ->
                val digest = java.security.MessageDigest.getInstance("SHA-256")
                temp.inputStream().use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        digest.update(buffer, 0, count)
                    }
                }
                val actual = digest.digest().joinToString("") { "%02x".format(it) }
                if (!actual.equals(expected, ignoreCase = true)) return "el archivo no es el original."
            }
            if (part.onnx) {
                val test = runCatching {
                    OrtEnvironment.getEnvironment().createSession(temp.readBytes(), OrtSession.SessionOptions()).close()
                }
                if (test.isFailure) return "el archivo no sirve en este celular."
            }
            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) return "no se pudo guardar."
            onProgress(1f)
            return null
        } catch (error: Throwable) {
            return "sin conexión o se cortó."
        } finally {
            connection?.disconnect()
            if (temp.exists()) temp.delete()
        }
    }
}

/**
 * Pregunta si se baja la IA (si falta) y la baja con su avance. [onFinished] se llama
 * siempre al final (con IA o sin ella): el trabajo sigue igual.
 */
@Composable
internal fun DocScanAiDialog(onFinished: (installed: Boolean) -> Unit) {
    val context = LocalContext.current
    var downloading by remember { mutableStateOf(false) }
    var step by remember { mutableStateOf(0 to 1) }
    var progress by remember { mutableFloatStateOf(0f) }
    var failed by remember { mutableStateOf<String?>(null) }

    if (downloading) {
        LaunchedEffect(Unit) {
            val error = withContext(Dispatchers.IO) {
                DocScanAiPack.download(context) { index, total, value ->
                    step = index to total
                    progress = value
                }
            }
            downloading = false
            if (error == null) onFinished(true) else failed = error
        }
    }

    val failure = failed
    when {
        failure != null -> AlertDialog(
            onDismissRequest = {},
            containerColor = CardGreen,
            title = { Text("No se pudo bajar todo", fontWeight = FontWeight.Bold) },
            text = { Text("$failure\n\nRevisa tu internet y prueba otra vez. También puedes seguir sin IA.") },
            confirmButton = {
                TextButton(onClick = {
                    failed = null
                    progress = 0f
                    downloading = true
                }) { Text("Probar otra vez", color = NeonGreen) }
            },
            dismissButton = {
                TextButton(onClick = {
                    DocScanAiPack.declined = true
                    onFinished(DocScanAiPack.missing(context).isEmpty())
                }) { Text("Seguir sin IA") }
            }
        )
        downloading -> AlertDialog(
            onDismissRequest = {},
            containerColor = CardGreen,
            title = { Text("Bajando la IA…", fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    val (index, total) = step
                    Text("Parte ${(index + 1).coerceAtMost(total)} de $total. Es una sola vez; después funciona sin internet.")
                    Spacer(Modifier.height(14.dp))
                    LinearProgressIndicator(
                        progress = { ((index + progress) / total.coerceAtLeast(1)).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                        color = NeonGreen
                    )
                }
            },
            confirmButton = {}
        )
        else -> AlertDialog(
            onDismissRequest = {
                DocScanAiPack.declined = true
                onFinished(false)
            },
            containerColor = CardGreen,
            title = { Text("¿Usar la IA? (recomendado)", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Con la IA la hoja sale más derecha, y las tablas, títulos y letras salen mucho mejor.\n\n" +
                        "Se baja una sola vez (usa internet, mejor con Wi-Fi) y después funciona sin internet. " +
                        "Sin la IA el Escáner igual funciona."
                )
            },
            confirmButton = {
                TextButton(onClick = { downloading = true }) { Text("Bajar IA", color = NeonGreen, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = {
                    DocScanAiPack.declined = true
                    onFinished(false)
                }) { Text("Sin IA") }
            }
        )
    }
}
