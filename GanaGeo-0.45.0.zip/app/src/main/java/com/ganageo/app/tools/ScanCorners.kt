package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Ayuda de la IA de esquinas (DocAligner, DocsaidLab, Apache 2.0): la IA mira la foto
 * en chico (256 × 256) y da un "mapa de calor" por cada esquina de la hoja; aquí se
 * prepara la entrada, se leen las 4 esquinas y se arma una foto de prueba para saber
 * cómo quiere la entrada esta IA (colores y escala), sin adivinar.
 * Sin Android: se prueba en la compu.
 */
object ScanCorners {
    const val SIZE = 256

    /** Forma de preparar la foto. [norm]: 0 = 0..1, 1 = media/desvío de ImageNet, 2 = −1..1. */
    data class Variant(val bgr: Boolean, val norm: Int, val pad: Boolean) {
        fun code() = "${if (bgr) 1 else 0}${norm}${if (pad) 1 else 0}"

        companion object {
            fun parse(code: String): Variant? {
                if (code.length != 3) return null
                val norm = code[1].digitToIntOrNull() ?: return null
                return Variant(code[0] == '1', norm.coerceIn(0, 2), code[2] == '1')
            }
        }
    }

    /** Las que se prueban (la más común primero). */
    val VARIANTS: List<Variant> = buildList {
        for (pad in listOf(false, true)) for (norm in listOf(0, 1, 2)) for (bgr in listOf(false, true)) add(Variant(bgr, norm, pad))
    }

    /** Cómo se pasó de la foto a 256 × 256: x256 = x · sx + ox. */
    class Mapping(val sx: Float, val sy: Float, val ox: Float, val oy: Float) {
        fun toImageX(v: Float) = (v - ox) / sx
        fun toImageY(v: Float) = (v - oy) / sy
    }

    /** Entrada [1, 3, 256, 256] (planos de color). */
    fun input(pixels: IntArray, width: Int, height: Int, variant: Variant): Pair<FloatArray, Mapping> {
        val mapping = if (variant.pad) {
            val s = SIZE / max(width, height).toFloat()
            Mapping(s, s, (SIZE - width * s) / 2f, (SIZE - height * s) / 2f)
        } else {
            Mapping(SIZE / width.toFloat(), SIZE / height.toFloat(), 0f, 0f)
        }
        val plane = SIZE * SIZE
        val out = FloatArray(plane * 3)
        val mean = floatArrayOf(0.485f, 0.456f, 0.406f)
        val std = floatArrayOf(0.229f, 0.224f, 0.225f)
        for (y in 0 until SIZE) {
            val sy = mapping.toImageY(y + 0.5f)
            for (x in 0 until SIZE) {
                val sx = mapping.toImageX(x + 0.5f)
                val inside = sx >= 0f && sy >= 0f && sx < width && sy < height
                // Promedio de una cajita (la foto se achica bastante).
                var r = 0f; var g = 0f; var b = 0f
                if (inside) {
                    val x0 = sx.toInt().coerceIn(0, width - 1)
                    val y0 = sy.toInt().coerceIn(0, height - 1)
                    val x1 = min(width - 1, x0 + max(0, (1f / mapping.sx).toInt() - 1))
                    val y1 = min(height - 1, y0 + max(0, (1f / mapping.sy).toInt() - 1))
                    var n = 0
                    var yy = y0
                    while (yy <= y1) {
                        var xx = x0
                        while (xx <= x1) {
                            val c = pixels[yy * width + xx]
                            r += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255
                            n++
                            xx += max(1, (x1 - x0) / 3)
                        }
                        yy += max(1, (y1 - y0) / 3)
                    }
                    r /= n; g /= n; b /= n
                }
                val rgb = if (variant.bgr) floatArrayOf(b, g, r) else floatArrayOf(r, g, b)
                for (c in 0 until 3) {
                    val v = rgb[c] / 255f
                    out[c * plane + y * SIZE + x] = when (variant.norm) {
                        1 -> (v - (if (variant.bgr) mean[2 - c] else mean[c])) / (if (variant.bgr) std[2 - c] else std[c])
                        2 -> v * 2f - 1f
                        else -> v
                    }
                }
            }
        }
        return out to mapping
    }

    /**
     * Las 4 esquinas desde la salida de la IA (en el cuadro de 256): por cada mapa, la
     * mancha alrededor del punto más alto y su centro. [shape] [1, 4, h, w] o [1, h, w, 4].
     * Devuelve (x, y, fuerza) × 4, o null si la salida no es de 4 mapas.
     */
    fun decode(values: FloatArray, shape: LongArray): List<FloatArray>? {
        val dims = shape.map { it.toInt() }.filter { it > 0 }
        if (dims.size < 3) return null
        val channelsFirst: Boolean
        val h: Int
        val w: Int
        when {
            dims.size >= 3 && dims[dims.size - 3] == 4 -> { channelsFirst = true; h = dims[dims.size - 2]; w = dims[dims.size - 1] }
            dims.last() == 4 -> { channelsFirst = false; h = dims[dims.size - 3]; w = dims[dims.size - 2] }
            else -> return null
        }
        if (h < 4 || w < 4 || values.size < 4 * h * w) return null
        fun at(c: Int, y: Int, x: Int) = if (channelsFirst) values[(c * h + y) * w + x] else values[(y * w + x) * 4 + c]
        val out = ArrayList<FloatArray>()
        for (c in 0 until 4) {
            var best = -Float.MAX_VALUE
            var bx = 0
            var by = 0
            for (y in 0 until h) for (x in 0 until w) {
                val v = at(c, y, x)
                if (v > best) { best = v; bx = x; by = y }
            }
            // Mancha alrededor del máximo (lo que pasa de la mitad entre el fondo y el máximo).
            var low = Float.MAX_VALUE
            for (y in 0 until h) for (x in 0 until w) low = min(low, at(c, y, x))
            val limit = low + (best - low) * 0.5f
            val seen = BooleanArray(h * w)
            val queue = IntArray(h * w)
            var head = 0
            var tail = 0
            queue[tail++] = by * w + bx
            seen[by * w + bx] = true
            var sx = 0.0; var sy = 0.0; var sw = 0.0
            while (head < tail) {
                val i = queue[head++]
                val x = i % w
                val y = i / w
                val v = (at(c, y, x) - limit).toDouble()
                sx += (x + 0.5) * v; sy += (y + 0.5) * v; sw += v
                for ((nx, ny) in listOf(x - 1 to y, x + 1 to y, x to y - 1, x to y + 1)) {
                    if (nx !in 0 until w || ny !in 0 until h) continue
                    val j = ny * w + nx
                    if (seen[j] || at(c, ny, nx) < limit) continue
                    seen[j] = true
                    queue[tail++] = j
                }
            }
            val cx = if (sw > 0) (sx / sw).toFloat() else bx + 0.5f
            val cy = if (sw > 0) (sy / sw).toFloat() else by + 0.5f
            out += floatArrayOf(cx * SIZE / w, cy * SIZE / h, best)
        }
        return out
    }

    /** Ordena 4 puntos como arriba-izq, arriba-der, abajo-der, abajo-izq. */
    fun order(points: List<FloatArray>): FloatArray {
        val cx = points.map { it[0] }.average().toFloat()
        val cy = points.map { it[1] }.average().toFloat()
        val sorted = points.sortedBy { atan2(it[1] - cy, it[0] - cx) } // desde la izquierda, en sentido horario (y hacia abajo)
        // atan2 da −π..π: el primero (más negativo) es el de arriba a la izquierda aprox.
        var start = 0
        var bestSum = Float.MAX_VALUE
        for (i in sorted.indices) {
            val s = sorted[i][0] + sorted[i][1]
            if (s < bestSum) { bestSum = s; start = i }
        }
        val out = FloatArray(8)
        for (k in 0 until 4) {
            val p = sorted[(start + k) % 4]
            out[k * 2] = p[0]
            out[k * 2 + 1] = p[1]
        }
        return out
    }

    /** Esquinas en la foto (desde las del cuadro de 256). */
    fun toImage(quad256: FloatArray, mapping: Mapping): FloatArray =
        FloatArray(8) { if (it % 2 == 0) mapping.toImageX(quad256[it]) else mapping.toImageY(quad256[it]) }

    /** Error promedio de las esquinas (parte de la diagonal de la foto). */
    fun error(found: FloatArray, truth: FloatArray, width: Int, height: Int): Float {
        var sum = 0f
        for (k in 0 until 4) sum += hypot(found[k * 2] - truth[k * 2], found[k * 2 + 1] - truth[k * 2 + 1])
        return sum / 4f / hypot(width.toFloat(), height.toFloat())
    }

    /**
     * Foto de prueba: hoja clara con renglones y una tabla, en perspectiva, sobre una
     * mesa con textura. Devuelve (píxeles, ancho, alto, esquinas verdaderas).
     */
    fun sample(): Pair<Triple<IntArray, Int, Int>, FloatArray> {
        val w = 360
        val h = 480
        val q = floatArrayOf(70f, 62f, 300f, 88f, 318f, 420f, 44f, 402f)
        var seed = 99L
        fun noise(): Int {
            seed = seed * 6364136223846793005L + 1442695040888963407L
            return ((seed ushr 40) % 23).toInt() - 11
        }
        // Coordenadas dentro de la hoja (u, v en 0..1) con una homografía.
        val m = ScanPhoto.homography(q, 1f, 1f)
        val inv = m?.let { invert(it) }
        val px = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var color: Int
            val u: Double
            val v: Double
            if (inv != null) {
                val d = inv[6] * x + inv[7] * y + inv[8]
                u = (inv[0] * x + inv[1] * y + inv[2]) / d
                v = (inv[3] * x + inv[4] * y + inv[5]) / d
            } else { u = -1.0; v = -1.0 }
            if (u in 0.0..1.0 && v in 0.0..1.0) {
                val shade = (236 - (v * 18)).toInt()
                color = rgb(shade, shade + 1, shade - 3)
                val line = (v * 40).let { it - it.toInt() } < 0.18 && v in 0.1..0.92 && u in 0.1..0.9 && ((u * 13).toInt() % 4 != 3)
                val table = v in 0.45..0.75 && u in 0.12..0.88 && (abs((v - 0.45) * 20 - ((v - 0.45) * 20).roundToInt()) < 0.06 || abs(u * 6 - (u * 6).roundToInt()) < 0.012)
                if (line || table) color = rgb(60, 62, 70)
            } else {
                val base = 120 + ((x / 7 + y / 5) % 9) * 3
                color = rgb(base + noise(), base - 30 + noise(), base - 55 + noise())
            }
            px[y * w + x] = color
        }
        return Triple(px, w, h) to q
    }

    private fun rgb(r: Int, g: Int, b: Int): Int =
        (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    private fun invert(m: DoubleArray): DoubleArray? {
        val det = m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) + m[2] * (m[3] * m[7] - m[4] * m[6])
        if (abs(det) < 1e-12) return null
        val d = 1.0 / det
        return doubleArrayOf(
            (m[4] * m[8] - m[5] * m[7]) * d, (m[2] * m[7] - m[1] * m[8]) * d, (m[1] * m[5] - m[2] * m[4]) * d,
            (m[5] * m[6] - m[3] * m[8]) * d, (m[0] * m[8] - m[2] * m[6]) * d, (m[2] * m[3] - m[0] * m[5]) * d,
            (m[3] * m[7] - m[4] * m[6]) * d, (m[1] * m[6] - m[0] * m[7]) * d, (m[0] * m[4] - m[1] * m[3]) * d
        )
    }
}
