package com.ganageo.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.ganageo.app.ui.theme.NeonGreen

/**
 * Barra para ajustar, fina y elegante (para toda la app): una línea delgada, un punto
 * que brilla un poco y, al moverla, una burbujita con el valor ([label]).
 * Se toca o se arrastra en cualquier parte de la barra.
 */
@Composable
fun GeoSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    accent: Color = NeonGreen,
    track: Color = Color(0x47808C86),
    enabled: Boolean = true,
    label: ((Float) -> String)? = null
) {
    val span = (valueRange.endInclusive - valueRange.start).takeIf { it > 0f } ?: 1f
    val fraction = ((value.coerceIn(valueRange.start, valueRange.endInclusive) - valueRange.start) / span)
    var dragging by remember { mutableStateOf(false) }
    val change by rememberUpdatedState(onValueChange)
    val paint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textAlign = android.graphics.Paint.Align.CENTER } }
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(if (label != null) 52.dp else 36.dp)
            .pointerInput(enabled to valueRange) {
                if (!enabled) return@pointerInput
                val pad = 12.dp.toPx()
                fun at(x: Float): Float {
                    val usable = (size.width - pad * 2).coerceAtLeast(1f)
                    val f = ((x - pad) / usable).coerceIn(0f, 1f)
                    return valueRange.start + f * span
                }
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    dragging = true
                    change(at(down.position.x))
                    down.consume()
                    while (true) {
                        val event = awaitPointerEvent()
                        val finger = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!finger.pressed) break
                        change(at(finger.position.x))
                        finger.consume()
                    }
                    dragging = false
                }
            }
    ) {
        val pad = 12.dp.toPx()
        val usable = (size.width - pad * 2).coerceAtLeast(1f)
        val cy = size.height - 18.dp.toPx()
        val thickness = 4.dp.toPx()
        val x = pad + usable * fraction
        val tint = if (enabled) accent else accent.copy(alpha = 0.35f)
        // Línea de fondo y la parte elegida.
        drawRoundRect(track, Offset(pad, cy - thickness / 2), Size(usable, thickness), CornerRadius(thickness, thickness))
        drawRoundRect(tint, Offset(pad, cy - thickness / 2), Size((x - pad).coerceAtLeast(0f), thickness), CornerRadius(thickness, thickness))
        // Punto: brillo suave, borde del color y centro blanco.
        val r = (if (dragging) 10.dp else 8.dp).toPx()
        drawCircle(tint.copy(alpha = if (dragging) 0.28f else 0.16f), radius = r * 1.9f, center = Offset(x, cy))
        drawCircle(tint, radius = r, center = Offset(x, cy))
        drawCircle(Color.White, radius = r * 0.55f, center = Offset(x, cy))
        // Burbujita con el valor, solo mientras se mueve.
        if (dragging && label != null) {
            val text = label(value)
            drawIntoCanvas { canvas ->
                paint.textSize = 12.dp.toPx()
                paint.isFakeBoldText = true
                val w = paint.measureText(text) + 16.dp.toPx()
                val h = 22.dp.toPx()
                val bx = (x - w / 2f).coerceIn(0f, size.width - w)
                val by = cy - r - h - 6.dp.toPx()
                paint.color = android.graphics.Color.argb(240, 10, 26, 18)
                canvas.nativeCanvas.drawRoundRect(bx, by, bx + w, by + h, h / 2f, h / 2f, paint)
                paint.color = android.graphics.Color.WHITE
                canvas.nativeCanvas.drawText(text, bx + w / 2f, by + h / 2f + paint.textSize * 0.36f, paint)
            }
        }
    }
}
