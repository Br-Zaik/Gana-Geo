# Gana Geo Android v0.10.8 — Ruta reactiva y nivel 2 corregido

Versión basada en v0.10.7. Mantiene intactos el inicio de sesión, Supabase, créditos, Geo Rewards, referidos, retiros y las herramientas ajenas a Geo Aventuras.

## Correcciones principales

- Los pisos ya no desaparecen solo porque avanza el reloj. Se activan únicamente cuando GEO entra cerca o sobre el tramo.
- Los pisos reactivos tienen una demora mínima para que exista tiempo real de respuesta.
- En el nivel 2 se quitó la combinación imposible de pinchos superiores y sierra del tramo mostrado en video.
- La plataforma de esa sección quedó sólida para ofrecer una zona de aterrizaje real.
- Se restauró un ventilador suave en esa parte, con ciclos de descanso y empuje favorable al avance.
- Se conservaron el suelo que se abre, las manzanas troll, árboles, pinchos retráctiles y checkpoints ya implementados.
- Durante el juego inmersivo se elimina el padding lateral del contenedor principal para aprovechar el ancho completo.

## Validación

- 21 pruebas puras aprobadas.
- 20 niveles generados.
- 0 pisos temporizados en los niveles finales.
- Tramo 3300–3600 del nivel 2 sin sierra ni pinchos superiores bloqueando la ruta.
- Compilación Android pendiente de GitHub Actions porque el entorno local no pudo descargar Gradle 8.13 por DNS.
