package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeoAdventureLevelsTest {
    @Test
    fun createsTwentyPlayableLevelDefinitions() {
        val levels = (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build)
        assertEquals(20, levels.size)
        levels.forEach { level ->
            assertTrue(level.width >= 8_100f)
            assertEquals(3, level.crystals.size)
            assertTrue(level.enemies.isNotEmpty())
            level.crystals.forEach { crystal ->
                assertTrue(level.platforms.any { platform ->
                    crystal.x in platform.x..(platform.x + platform.width) &&
                        crystal.y == platform.y - 92f
                })
            }
            assertTrue(level.platforms.any { it.x <= 70f && it.x + it.width > 70f })
            assertTrue(level.platforms.any { it.x <= level.goalX && it.x + it.width >= level.goalX })
            assertTrue(level.parSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS)
        }
    }

    @Test
    fun difficultyAddsEnemiesMovingPlatformsAndObjects() {
        val first = GeoAdventureLevelFactory.build(1)
        val middle = GeoAdventureLevelFactory.build(10)
        val last = GeoAdventureLevelFactory.build(20)
        assertTrue(last.width > first.width)
        assertTrue(last.hazards.size >= first.hazards.size)
        assertTrue(last.enemies.size >= first.enemies.size)
        assertTrue(middle.movingPlatforms.isNotEmpty())
        assertTrue(last.crates.isNotEmpty())
        assertTrue(last.switches.isNotEmpty())
        assertTrue(last.pickups.isNotEmpty())
        assertTrue(last.enemies.any { it.kind == GameEnemyKind.SHOOTER || it.kind == GameEnemyKind.GUARDIAN })
    }
}
