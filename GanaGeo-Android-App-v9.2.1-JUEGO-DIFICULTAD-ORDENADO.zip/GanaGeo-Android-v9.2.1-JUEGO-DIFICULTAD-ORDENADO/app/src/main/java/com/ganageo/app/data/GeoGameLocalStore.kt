package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ganageo.app.model.GeoGameFinish
import com.ganageo.app.model.GeoGameRunStart
import com.ganageo.app.model.GeoGameStatus
import com.ganageo.app.tools.GeoGameRules
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import java.time.LocalDate
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

private val Context.geoGameLocalDataStore by preferencesDataStore(name = "geo_game_local_test")

private data class LocalGameRun(
    val id: String,
    val level: Int,
    val premium: Boolean,
    var activated: Boolean
)

class GeoGameLocalStore(private val context: Context) {
    private object Keys {
        val FreeLives = intPreferencesKey("free_lives")
        val FreeDay = longPreferencesKey("free_day")
        val PremiumLives = longPreferencesKey("premium_lives")
        val UnlockedLevel = intPreferencesKey("unlocked_level")
        val TotalStars = longPreferencesKey("total_stars")
        val BestScore = longPreferencesKey("best_score")
        val PremiumUsedToday = intPreferencesKey("premium_used_today")
        val PremiumUsedDay = longPreferencesKey("premium_used_day")
        fun levelStars(level: Int) = intPreferencesKey("level_${level}_best_stars")
    }

    private val mutex = Mutex()
    private val runs = ConcurrentHashMap<String, LocalGameRun>()

    private fun today(): Long = LocalDate.now().toEpochDay()

    private suspend fun refreshDaily() {
        val currentDay = today()
        context.geoGameLocalDataStore.edit { prefs ->
            if ((prefs[Keys.FreeDay] ?: Long.MIN_VALUE) != currentDay) {
                prefs[Keys.FreeLives] = GeoGameRules.DAILY_FREE_LIVES
                prefs[Keys.FreeDay] = currentDay
            }
            if ((prefs[Keys.PremiumUsedDay] ?: Long.MIN_VALUE) != currentDay) {
                prefs[Keys.PremiumUsedToday] = 0
                prefs[Keys.PremiumUsedDay] = currentDay
            }
            if (prefs[Keys.UnlockedLevel] == null) prefs[Keys.UnlockedLevel] = 1
        }
    }

    suspend fun status(): GeoGameStatus {
        refreshDaily()
        return context.geoGameLocalDataStore.data.map { prefs ->
            GeoGameStatus(
                freeLives = prefs[Keys.FreeLives] ?: GeoGameRules.DAILY_FREE_LIVES,
                premiumLives = prefs[Keys.PremiumLives] ?: 0,
                unlockedLevel = prefs[Keys.UnlockedLevel] ?: 1,
                totalStars = prefs[Keys.TotalStars] ?: 0,
                bestScore = prefs[Keys.BestScore] ?: 0,
                premiumUsedToday = prefs[Keys.PremiumUsedToday] ?: 0,
                premiumDailyLimit = GeoGameRules.PREMIUM_DAILY_LIMIT,
                isLocalTest = true
            )
        }.first()
    }

    suspend fun addPremiumLives(count: Int) {
        require(count > 0)
        context.geoGameLocalDataStore.edit { prefs ->
            prefs[Keys.PremiumLives] = (prefs[Keys.PremiumLives] ?: 0) + count
        }
    }

    suspend fun start(level: Int, lifeType: String): GeoGameRunStart {
        mutex.lock()
        try {
            refreshDaily()
            val current = status()
            require(level in 1..current.unlockedLevel.coerceAtMost(20)) { "Este nivel todavía está bloqueado." }
            val premium = lifeType == "premium"
            if (premium) {
                require(current.premiumLives > 0) { "No tienes vidas amarillas." }
                require(current.premiumUsedToday < current.premiumDailyLimit) {
                    "Alcanzaste el límite diario de vidas amarillas."
                }
            } else {
                require(current.freeLives > 0) { "No tienes vidas rojas disponibles hoy." }
            }

            context.geoGameLocalDataStore.edit { prefs ->
                if (premium) {
                    prefs[Keys.PremiumLives] = ((prefs[Keys.PremiumLives] ?: 0) - 1).coerceAtLeast(0)
                } else {
                    prefs[Keys.FreeLives] = ((prefs[Keys.FreeLives] ?: 0) - 1).coerceAtLeast(0)
                }
            }

            val id = UUID.randomUUID().toString()
            runs[id] = LocalGameRun(id, level, premium, activated = !premium)
            val updated = status()
            return GeoGameRunStart(
                runId = id,
                lifeType = if (premium) "premium" else "free",
                freeLivesRemaining = updated.freeLives,
                premiumLivesRemaining = updated.premiumLives,
                needsActivation = premium,
                isLocalTest = true
            )
        } finally {
            mutex.unlock()
        }
    }

    suspend fun activate(runId: String): Boolean {
        mutex.lock()
        try {
            val run = runs[runId] ?: error("La partida de prueba ya no está disponible.")
            if (!run.premium || run.activated) return false
            run.activated = true
            context.geoGameLocalDataStore.edit { prefs ->
                prefs[Keys.PremiumUsedToday] = (prefs[Keys.PremiumUsedToday] ?: 0) + 1
                prefs[Keys.PremiumUsedDay] = today()
            }
            return true
        } finally {
            mutex.unlock()
        }
    }

    suspend fun finish(runId: String, won: Boolean, stars: Int, score: Long): GeoGameFinish {
        mutex.lock()
        try {
            val run = runs.remove(runId) ?: error("La partida de prueba ya terminó.")
            require(run.activated) { "La vida premium todavía no fue activada." }
            context.geoGameLocalDataStore.edit { prefs ->
                prefs[Keys.BestScore] = maxOf(prefs[Keys.BestScore] ?: 0, score)
                if (won) {
                    prefs[Keys.UnlockedLevel] = maxOf(
                        prefs[Keys.UnlockedLevel] ?: 1,
                        (run.level + 1).coerceAtMost(20)
                    )
                    val starsKey = Keys.levelStars(run.level)
                    val previousBest = prefs[starsKey] ?: 0
                    val newBest = maxOf(previousBest, stars.coerceIn(1, 3))
                    prefs[starsKey] = newBest
                    prefs[Keys.TotalStars] = (prefs[Keys.TotalStars] ?: 0) - previousBest + newBest
                }
            }
            val updated = status()
            return GeoGameFinish(
                unlockedLevel = updated.unlockedLevel,
                totalStars = updated.totalStars,
                bestScore = updated.bestScore,
                isLocalTest = true
            )
        } finally {
            mutex.unlock()
        }
    }

    suspend fun cancel(runId: String) {
        mutex.lock()
        try {
            val run = runs.remove(runId) ?: return
            if (run.premium && !run.activated) {
                context.geoGameLocalDataStore.edit { prefs ->
                    prefs[Keys.PremiumLives] = (prefs[Keys.PremiumLives] ?: 0) + 1
                }
            }
        } finally {
            mutex.unlock()
        }
    }

}
