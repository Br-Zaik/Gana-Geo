package com.ganageo.app.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class GeoGameStatus(
    @SerialName("free_lives") val freeLives: Int = 3,
    @SerialName("premium_lives") val premiumLives: Long = 0,
    @SerialName("unlocked_level") val unlockedLevel: Int = 1,
    @SerialName("total_stars") val totalStars: Long = 0,
    @SerialName("best_score") val bestScore: Long = 0,
    @SerialName("premium_used_today") val premiumUsedToday: Int = 0,
    @SerialName("premium_daily_limit") val premiumDailyLimit: Int = 10,
    val isLocalTest: Boolean = false
)

@Serializable
data class GeoGameLifePurchase(
    @SerialName("lives_added") val livesAdded: Int,
    @SerialName("credits_spent") val creditsSpent: Int,
    @SerialName("remaining_credits") val remainingCredits: Long,
    @SerialName("premium_lives") val premiumLives: Long,
    val isLocalTest: Boolean = false
)

@Serializable
data class GeoGameRunStart(
    @SerialName("run_id") val runId: String,
    @SerialName("life_type") val lifeType: String,
    @SerialName("free_lives_remaining") val freeLivesRemaining: Int,
    @SerialName("premium_lives_remaining") val premiumLivesRemaining: Long,
    @SerialName("needs_activation") val needsActivation: Boolean,
    val isLocalTest: Boolean = false
)

@Serializable
data class GeoGameActivation(
    @SerialName("awarded_points") val awardedPoints: Long = 0,
    @SerialName("premium_lives_remaining") val premiumLivesRemaining: Long = 0,
    @SerialName("premium_used_today") val premiumUsedToday: Int = 0,
    val isLocalTest: Boolean = false
)

@Serializable
data class GeoGameFinish(
    @SerialName("unlocked_level") val unlockedLevel: Int = 1,
    @SerialName("total_stars") val totalStars: Long = 0,
    @SerialName("best_score") val bestScore: Long = 0,
    val isLocalTest: Boolean = false
)
