package com.ganageo.app.ui.tools

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.InventoryItem
import com.ganageo.app.data.InventoryStore
import com.ganageo.app.data.WorkChecklistItem
import com.ganageo.app.data.WorkChecklistStore
import com.ganageo.app.data.WorkLedgerEntry
import com.ganageo.app.data.WorkLedgerStore
import com.ganageo.app.tools.CommerceCalculator
import com.ganageo.app.tools.WorkPayCalculator
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import java.util.Locale
import kotlinx.coroutines.launch

private data class QuoteLine(
    val id: Long,
    val description: String,
    val quantity: Double,
    val unitPrice: Double
)

@Composable
fun CvBuilderScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var fullName by rememberSaveable { mutableStateOf("") }
    var desiredRole by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var city by rememberSaveable { mutableStateOf("") }
    var profile by rememberSaveable { mutableStateOf("") }
    var experience by rememberSaveable { mutableStateOf("") }
    var education by rememberSaveable { mutableStateOf("") }
    var skills by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingExport by remember { mutableStateOf<String?>(null) }

    val cvText = remember(fullName, desiredRole, phone, email, city, profile, experience, education, skills) {
        buildCvText(
            fullName = fullName,
            desiredRole = desiredRole,
            phone = phone,
            email = email,
            city = city,
            profile = profile,
            experience = experience,
            education = education,
            skills = skills
        )
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val content = pendingExport
        if (uri != null && content != null) {
            runCatching { saveText(context, uri.toString(), content) }
                .onSuccess { message = "CV guardado" }
                .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
        }
        pendingExport = null
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Constructor de CV", "Crea un currículum base y expórtalo en texto", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Datos principales", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(fullName, { fullName = it.take(120) }, label = { Text("Nombre completo") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(desiredRole, { desiredRole = it.take(120) }, label = { Text("Puesto o especialidad") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(phone, { phone = it.take(30) }, label = { Text("Teléfono") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(email, { email = it.take(120) }, label = { Text("Correo") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(city, { city = it.take(120) }, label = { Text("Ciudad") }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Contenido del CV", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(profile, { profile = it.take(1200) }, label = { Text("Perfil profesional") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                        OutlinedTextField(experience, { experience = it.take(3000) }, label = { Text("Experiencia") }, modifier = Modifier.fillMaxWidth(), minLines = 4, placeholder = { Text("Ejemplo: Empresa - puesto - fechas - funciones") })
                        OutlinedTextField(education, { education = it.take(2000) }, label = { Text("Formación") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                        OutlinedTextField(skills, { skills = it.take(1200) }, label = { Text("Habilidades") }, modifier = Modifier.fillMaxWidth(), minLines = 3, placeholder = { Text("Ejemplo: Excel, atención al cliente, manejo de caja") })
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    copyPlainText(context, "cv", cvText)
                                    message = "CV copiado"
                                },
                                enabled = cvText.isNotBlank(),
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                            ) {
                                Icon(Icons.Rounded.ContentCopy, contentDescription = null)
                                Text(" Copiar", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = {
                                    pendingExport = cvText
                                    exportLauncher.launch("CV_${safeFileName(fullName, "sin_nombre")}.txt")
                                },
                                enabled = cvText.isNotBlank(),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.Save, contentDescription = null)
                                Text(" Guardar TXT")
                            }
                        }
                        message?.let {
                            Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen)
                        }
                    }
                }
            }
            item {
                ResultSurface(title = "Vista previa") {
                    if (cvText.isBlank()) {
                        Text("Completa al menos el nombre o una sección para generar la vista previa.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text(cvText)
                    }
                }
            }
        }
    }
}

@Composable
fun WorkHoursScreen(onBack: () -> Unit) {
    var rate by rememberSaveable { mutableStateOf("15") }
    var regularHours by rememberSaveable { mutableStateOf("8") }
    var overtimeHours by rememberSaveable { mutableStateOf("2") }
    var overtimeMultiplier by rememberSaveable { mutableStateOf("1.25") }
    var days by rememberSaveable { mutableStateOf("5") }
    var result by rememberSaveable { mutableStateOf<String?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Horas de trabajo", "Pago regular y horas extra por jornada o semana", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Cálculo de pago", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        DecimalField(rate, { rate = it }, "Pago por hora (S/)")
                        DecimalField(regularHours, { regularHours = it }, "Horas regulares por día")
                        DecimalField(overtimeHours, { overtimeHours = it }, "Horas extra por día")
                        DecimalField(overtimeMultiplier, { overtimeMultiplier = it }, "Multiplicador de extra")
                        DecimalField(days, { days = it }, "Cantidad de días")
                        Button(
                            onClick = {
                                runCatching {
                                    val data = WorkPayCalculator.calculate(
                                        hourlyRate = parseNumber(rate),
                                        regularHoursPerDay = parseNumber(regularHours),
                                        overtimeHoursPerDay = parseNumber(overtimeHours),
                                        overtimeMultiplier = parseNumber(overtimeMultiplier),
                                        days = parseNumber(days)
                                    )
                                    buildString {
                                        appendLine("Horas regulares totales: ${formatNumber(data.regularHours)}")
                                        appendLine("Horas extra totales: ${formatNumber(data.overtimeHours)}")
                                        appendLine("Pago regular: S/ ${formatMoney(data.regularPay)}")
                                        appendLine("Pago por horas extra: S/ ${formatMoney(data.overtimePay)}")
                                        append("Pago total estimado: S/ ${formatMoney(data.totalPay)}")
                                    }
                                }.onSuccess {
                                    result = it
                                    error = null
                                }.onFailure {
                                    error = it.message ?: "Datos inválidos"
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Calcular", fontWeight = FontWeight.Bold) }
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            result?.let {
                item {
                    ResultSurface(title = "Resultado") {
                        Text(it, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.10f)), shape = RoundedCornerShape(18.dp)) {
                    Text(
                        "Usa 1.25, 1.35, 1.5 u otro multiplicador según tus reglas de pago. Es un cálculo práctico y rápido.",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun QuoteIgvScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var client by rememberSaveable { mutableStateOf("") }
    var quoteName by rememberSaveable { mutableStateOf("Cotización") }
    var notes by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var quantity by rememberSaveable { mutableStateOf("1") }
    var unitPrice by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingExport by remember { mutableStateOf<String?>(null) }
    val quoteItems = remember { mutableStateListOf<QuoteLine>() }

    val subtotal = quoteItems.sumOf { it.quantity * it.unitPrice }
    val (_, igv, total) = CommerceCalculator.quoteTotals(subtotal)
    val summary = remember(client, quoteName, notes, quoteItems.size, subtotal, igv, total) {
        buildQuoteSummary(client, quoteName, notes, quoteItems, subtotal, igv, total)
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val content = pendingExport
        if (uri != null && content != null) {
            runCatching { saveText(context, uri.toString(), content) }
                .onSuccess { message = "Cotización guardada" }
                .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
        }
        pendingExport = null
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Cotización e IGV", "Arma ítems y obtén subtotal, IGV y total", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Encabezado", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(quoteName, { quoteName = it.take(120) }, label = { Text("Nombre del documento") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(client, { client = it.take(120) }, label = { Text("Cliente (opcional)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(notes, { notes = it.take(500) }, label = { Text("Observaciones") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Agregar ítem", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(description, { description = it.take(160) }, label = { Text("Descripción") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DecimalField(quantity, { quantity = it }, "Cantidad", Modifier.weight(1f))
                            DecimalField(unitPrice, { unitPrice = it }, "Precio unitario", Modifier.weight(1f))
                        }
                        Button(
                            onClick = {
                                runCatching {
                                    val q = parseNumber(quantity)
                                    val p = parseNumber(unitPrice)
                                    require(description.isNotBlank()) { "Escribe una descripción" }
                                    require(q > 0 && p >= 0) { "Cantidad o precio inválido" }
                                    QuoteLine(System.currentTimeMillis() + quoteItems.size, description.trim(), q, p)
                                }.onSuccess {
                                    quoteItems.add(it)
                                    description = ""
                                    quantity = "1"
                                    unitPrice = ""
                                    message = "Ítem agregado"
                                }.onFailure {
                                    message = "Error: ${it.message ?: "No se pudo agregar"}"
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Agregar ítem", fontWeight = FontWeight.Bold) }
                        message?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen) }
                    }
                }
            }
            if (quoteItems.isEmpty()) {
                item {
                    Text("Todavía no agregaste ítems.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(quoteItems, key = { it.id }) { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(item.description, fontWeight = FontWeight.Bold)
                                Text("${formatNumber(item.quantity)} × S/ ${formatMoney(item.unitPrice)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("S/ ${formatMoney(item.quantity * item.unitPrice)}", color = Gold, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { quoteItems.remove(item) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar")
                            }
                        }
                    }
                }
                item {
                    ResultSurface(title = "Totales") {
                        Text("Subtotal: S/ ${formatMoney(subtotal)}")
                        Text("IGV (18%): S/ ${formatMoney(igv)}")
                        Text("Total: S/ ${formatMoney(total)}", fontWeight = FontWeight.Bold, color = NeonGreen)
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                copyPlainText(context, "cotizacion", summary)
                                message = "Resumen copiado"
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = null)
                            Text(" Copiar", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = {
                                pendingExport = summary
                                exportLauncher.launch("${safeFileName(quoteName, "cotizacion")}.txt")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.Save, contentDescription = null)
                            Text(" Guardar TXT")
                        }
                    }
                }
                item {
                    ResultSurface(title = "Resumen listo para compartir") {
                        Text(summary)
                    }
                }
            }
        }
    }
}

@Composable
fun IncomeExpenseTrackerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { WorkLedgerStore(context.applicationContext) }
    val entries by store.entries.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var movementType by rememberSaveable { mutableStateOf("gasto") }
    var description by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("General") }
    var amount by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingExport by remember { mutableStateOf<String?>(null) }

    val totalIncome = entries.filter { it.type == "ingreso" }.sumOf { it.amountCents }
    val totalExpense = entries.filter { it.type == "gasto" }.sumOf { it.amountCents }
    val balance = totalIncome - totalExpense
    val csv = remember(entries) { ledgerCsv(entries) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val content = pendingExport
        if (uri != null && content != null) {
            runCatching { saveText(context, uri.toString(), content) }
                .onSuccess { message = "Movimientos exportados" }
                .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
        }
        pendingExport = null
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Ingresos y gastos", "Control local con saldo y exportación CSV", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneySummaryCard("Ingresos", totalIncome, NeonGreen, Modifier.weight(1f))
                    MoneySummaryCard("Gastos", totalExpense, Gold, Modifier.weight(1f))
                }
            }
            item {
                ResultSurface(title = "Saldo actual") {
                    Text(
                        "S/ ${formatMoney(balance / 100.0)}",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (balance >= 0) NeonGreen else MaterialTheme.colorScheme.error
                    )
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Nuevo movimiento", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { movementType = "ingreso" },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (movementType == "ingreso") NeonGreen else CardGreen,
                                    contentColor = if (movementType == "ingreso") DeepGreen else MaterialTheme.colorScheme.onSurface
                                )
                            ) { Text("Ingreso") }
                            Button(
                                onClick = { movementType = "gasto" },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (movementType == "gasto") Gold else CardGreen,
                                    contentColor = if (movementType == "gasto") DeepGreen else MaterialTheme.colorScheme.onSurface
                                )
                            ) { Text("Gasto") }
                        }
                        OutlinedTextField(description, { description = it.take(160) }, label = { Text("Descripción") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(category, { category = it.take(80) }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth())
                        DecimalField(amount, { amount = it }, "Monto (S/)")
                        Button(
                            onClick = {
                                scope.launch {
                                    runCatching { store.add(movementType, description, category, parseNumber(amount)) }
                                        .onSuccess {
                                            description = ""
                                            amount = ""
                                            message = "Movimiento guardado"
                                        }
                                        .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
                                }
                            },
                            enabled = description.isNotBlank() && amount.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Guardar movimiento", fontWeight = FontWeight.Bold) }
                        message?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen) }
                    }
                }
            }
            if (entries.isNotEmpty()) {
                item {
                    OutlinedButton(
                        onClick = {
                            pendingExport = csv
                            exportLauncher.launch("ingresos_gastos.csv")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Save, contentDescription = null)
                        Text(" Exportar CSV")
                    }
                }
                items(entries, key = { it.id }) { entry ->
                    LedgerEntryCard(entry) {
                        scope.launch { store.delete(entry.id) }
                    }
                }
            } else {
                item { EmptyStateText("Todavía no registraste ingresos ni gastos.") }
            }
        }
    }
}

@Composable
fun InventoryBasicScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { InventoryStore(context.applicationContext) }
    val inventoryItems by store.items.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var name by rememberSaveable { mutableStateOf("") }
    var sku by rememberSaveable { mutableStateOf("") }
    var quantity by rememberSaveable { mutableStateOf("0") }
    var minimumStock by rememberSaveable { mutableStateOf("1") }
    var unitCost by rememberSaveable { mutableStateOf("0") }
    var unitSale by rememberSaveable { mutableStateOf("0") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingExport by remember { mutableStateOf<String?>(null) }

    val lowStock = inventoryItems.count { it.quantity <= it.minimumStock }
    val stockValueCents = inventoryItems.sumOf { kotlin.math.round(it.quantity * it.unitCostCents).toLong() }
    val potentialSaleCents = inventoryItems.sumOf { kotlin.math.round(it.quantity * it.unitSaleCents).toLong() }
    val csv = remember(inventoryItems) { inventoryCsv(inventoryItems) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val content = pendingExport
        if (uri != null && content != null) {
            runCatching { saveText(context, uri.toString(), content) }
                .onSuccess { message = "Inventario exportado" }
                .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
        }
        pendingExport = null
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Inventario básico", "Stock, costos, precios y alertas de mínimo", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallMetricCard("Productos", inventoryItems.size.toString(), Modifier.weight(1f))
                    SmallMetricCard("Stock bajo", lowStock.toString(), Modifier.weight(1f), if (lowStock > 0) Gold else NeonGreen)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallMetricCard("Costo en stock", "S/ ${formatMoney(stockValueCents / 100.0)}", Modifier.weight(1f))
                    SmallMetricCard("Venta potencial", "S/ ${formatMoney(potentialSaleCents / 100.0)}", Modifier.weight(1f))
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Agregar producto", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(name, { name = it.take(160) }, label = { Text("Producto") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(sku, { sku = it.take(80) }, label = { Text("Código o SKU (opcional)") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DecimalField(quantity, { quantity = it }, "Stock inicial", Modifier.weight(1f))
                            DecimalField(minimumStock, { minimumStock = it }, "Stock mínimo", Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DecimalField(unitCost, { unitCost = it }, "Costo unitario", Modifier.weight(1f))
                            DecimalField(unitSale, { unitSale = it }, "Precio de venta", Modifier.weight(1f))
                        }
                        Button(
                            onClick = {
                                scope.launch {
                                    runCatching {
                                        store.add(
                                            name = name,
                                            sku = sku,
                                            quantity = parseNumber(quantity),
                                            minimumStock = parseNumber(minimumStock),
                                            unitCost = parseNumber(unitCost),
                                            unitSale = parseNumber(unitSale)
                                        )
                                    }.onSuccess {
                                        name = ""
                                        sku = ""
                                        quantity = "0"
                                        minimumStock = "1"
                                        unitCost = "0"
                                        unitSale = "0"
                                        message = "Producto guardado"
                                    }.onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
                                }
                            },
                            enabled = name.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Guardar producto", fontWeight = FontWeight.Bold) }
                        message?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen) }
                    }
                }
            }
            if (inventoryItems.isNotEmpty()) {
                item {
                    OutlinedButton(
                        onClick = {
                            pendingExport = csv
                            exportLauncher.launch("inventario_gana_geo.csv")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Save, contentDescription = null)
                        Text(" Exportar inventario CSV")
                    }
                }
                items(inventoryItems, key = { it.id }) { item ->
                    InventoryItemCard(
                        item = item,
                        onDecrease = {
                            scope.launch {
                                runCatching { store.adjustStock(item.id, -1.0) }
                                    .onFailure { message = "Error: ${it.message ?: "No se pudo actualizar"}" }
                            }
                        },
                        onIncrease = { scope.launch { store.adjustStock(item.id, 1.0) } },
                        onDelete = { scope.launch { store.delete(item.id) } }
                    )
                }
            } else {
                item { EmptyStateText("Todavía no agregaste productos al inventario.") }
            }
        }
    }
}

@Composable
fun CommissionMarginScreen(onBack: () -> Unit) {
    var cost by rememberSaveable { mutableStateOf("50") }
    var sale by rememberSaveable { mutableStateOf("80") }
    var commissionPercent by rememberSaveable { mutableStateOf("5") }
    var desiredMargin by rememberSaveable { mutableStateOf("30") }
    var result by rememberSaveable { mutableStateOf<String?>(null) }
    var targetResult by rememberSaveable { mutableStateOf<String?>(null) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Comisiones y ganancias", "Utilidad, comisión, margen y precio objetivo", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Analizar una venta", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        DecimalField(cost, { cost = it }, "Costo (S/)")
                        DecimalField(sale, { sale = it }, "Precio de venta (S/)")
                        DecimalField(commissionPercent, { commissionPercent = it }, "Comisión sobre venta (%)")
                        Button(
                            onClick = {
                                runCatching {
                                    val data = CommerceCalculator.analyzeSale(
                                        cost = parseNumber(cost),
                                        salePrice = parseNumber(sale),
                                        commissionPercent = parseNumber(commissionPercent)
                                    )
                                    buildString {
                                        appendLine("Utilidad antes de comisión: S/ ${formatMoney(data.grossProfit)}")
                                        appendLine("Comisión: S/ ${formatMoney(data.commission)}")
                                        appendLine("Utilidad neta: S/ ${formatMoney(data.netProfit)}")
                                        appendLine("Margen neto: ${formatMoney(data.netMarginPercent)}%")
                                        append("Ganancia sobre costo: ${formatMoney(data.markupPercent)}%")
                                    }
                                }.onSuccess {
                                    result = it
                                    error = null
                                }.onFailure { error = it.message ?: "Datos inválidos" }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Calcular venta", fontWeight = FontWeight.Bold) }
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            result?.let {
                item { ResultSurface("Resultado de la venta") { Text(it, fontWeight = FontWeight.Bold) } }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Precio para un margen objetivo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        DecimalField(cost, { cost = it }, "Costo (S/)")
                        DecimalField(desiredMargin, { desiredMargin = it }, "Margen deseado (%)")
                        DecimalField(commissionPercent, { commissionPercent = it }, "Comisión estimada (%)")
                        OutlinedButton(
                            onClick = {
                                runCatching {
                                    val targetPrice = CommerceCalculator.targetSalePrice(
                                        cost = parseNumber(cost),
                                        desiredMarginPercent = parseNumber(desiredMargin),
                                        commissionPercent = parseNumber(commissionPercent)
                                    )
                                    "Precio sugerido: S/ ${formatMoney(targetPrice)}"
                                }.onSuccess { targetResult = it }
                                    .onFailure { targetResult = "Error: ${it.message ?: "Datos inválidos"}" }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Calcular precio sugerido") }
                        targetResult?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }
}

@Composable
fun WorkChecklistScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember(context) { WorkChecklistStore(context.applicationContext) }
    val checklistItems by store.items.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var title by rememberSaveable { mutableStateOf("") }
    var area by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }

    val pending = checklistItems.count { !it.completed }
    val completed = checklistItems.size - pending

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Checklist de trabajo", "Actividades, áreas y control de cumplimiento", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallMetricCard("Pendientes", pending.toString(), Modifier.weight(1f), Gold)
                    SmallMetricCard("Completadas", completed.toString(), Modifier.weight(1f), NeonGreen)
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Nueva actividad", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(title, { title = it.take(240) }, label = { Text("Actividad") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(area, { area = it.take(100) }, label = { Text("Área o grupo (opcional)") }, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = {
                                scope.launch {
                                    runCatching { store.add(title, area) }
                                        .onSuccess {
                                            title = ""
                                            area = ""
                                            message = "Actividad agregada"
                                        }
                                        .onFailure { message = "Error: ${it.message ?: "No se pudo guardar"}" }
                                }
                            },
                            enabled = title.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Agregar actividad", fontWeight = FontWeight.Bold) }
                        message?.let { Text(it, color = if (it.startsWith("Error")) MaterialTheme.colorScheme.error else NeonGreen) }
                    }
                }
            }
            if (completed > 0) {
                item {
                    OutlinedButton(
                        onClick = { scope.launch { store.clearCompleted() } },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = null)
                        Text(" Eliminar completadas")
                    }
                }
            }
            if (checklistItems.isEmpty()) {
                item { EmptyStateText("Todavía no agregaste actividades.") }
            } else {
                items(checklistItems, key = { it.id }) { item ->
                    ChecklistItemCard(
                        item = item,
                        onToggle = { scope.launch { store.toggle(item.id) } },
                        onDelete = { scope.launch { store.delete(item.id) } }
                    )
                }
            }
        }
    }
}

@Composable
private fun MoneySummaryCard(label: String, cents: Long, accent: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.10f)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("S/ ${formatMoney(cents / 100.0)}", color = accent, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SmallMetricCard(label: String, value: String, modifier: Modifier, accent: androidx.compose.ui.graphics.Color = NeonGreen) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.09f)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, color = accent, fontWeight = FontWeight.Bold)
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun LedgerEntryCard(entry: WorkLedgerEntry, onDelete: () -> Unit) {
    val accent = if (entry.type == "ingreso") NeonGreen else Gold
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(entry.description, fontWeight = FontWeight.Bold)
                Text(entry.category, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                "${if (entry.type == "ingreso") "+" else "-"} S/ ${formatMoney(entry.amountCents / 100.0)}",
                color = accent,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Eliminar") }
        }
    }
}

@Composable
private fun InventoryItemCard(
    item: InventoryItem,
    onDecrease: () -> Unit,
    onIncrease: () -> Unit,
    onDelete: () -> Unit
) {
    val low = item.quantity <= item.minimumStock
    Card(
        colors = CardDefaults.cardColors(containerColor = if (low) Gold.copy(alpha = 0.10f) else CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.name, fontWeight = FontWeight.Bold)
                    if (item.sku.isNotBlank()) Text("Código: ${item.sku}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        if (low) "Stock bajo o mínimo" else "Stock disponible",
                        color = if (low) Gold else NeonGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Eliminar") }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = onDecrease, enabled = item.quantity >= 1.0) {
                    Icon(Icons.Rounded.Remove, contentDescription = "Restar stock")
                }
                Text(formatNumber(item.quantity), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                IconButton(onClick = onIncrease) {
                    Icon(Icons.Rounded.Add, contentDescription = "Aumentar stock")
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("Costo: S/ ${formatMoney(item.unitCostCents / 100.0)}")
                    Text("Venta: S/ ${formatMoney(item.unitSaleCents / 100.0)}", color = NeonGreen)
                }
            }
        }
    }
}

@Composable
private fun ChecklistItemCard(item: WorkChecklistItem, onToggle: () -> Unit, onDelete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onToggle) {
                Icon(
                    if (item.completed) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                    contentDescription = if (item.completed) "Marcar pendiente" else "Marcar completada",
                    tint = if (item.completed) NeonGreen else Gold
                )
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(item.title, fontWeight = FontWeight.Bold, color = if (item.completed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                if (item.area.isNotBlank()) Text(item.area, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Eliminar") }
        }
    }
}

@Composable
private fun EmptyStateText(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Text(text, modifier = Modifier.fillMaxWidth().padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun ledgerCsv(entries: List<WorkLedgerEntry>): String = buildString {
    appendLine("tipo,descripcion,categoria,monto")
    entries.forEach { entry ->
        appendLine("${csvCell(entry.type)},${csvCell(entry.description)},${csvCell(entry.category)},${formatMoney(entry.amountCents / 100.0)}")
    }
}

private fun inventoryCsv(items: List<InventoryItem>): String = buildString {
    appendLine("producto,sku,stock,stock_minimo,costo_unitario,precio_venta")
    items.forEach { item ->
        appendLine("${csvCell(item.name)},${csvCell(item.sku)},${formatNumber(item.quantity)},${formatNumber(item.minimumStock)},${formatMoney(item.unitCostCents / 100.0)},${formatMoney(item.unitSaleCents / 100.0)}")
    }
}

private fun csvCell(value: String): String {
    val escaped = value.replace("\"", "\"\"")
    return "\"$escaped\""
}

private fun safeFileName(value: String, fallback: String): String = value
    .trim()
    .ifBlank { fallback }
    .replace(Regex("[\\/:*?\"<>|]"), "_")
    .replace(Regex("\\s+"), "_")
    .take(70)


@Composable
private fun ResultSurface(title: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.08f)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun DecimalField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    OutlinedTextField(
        value = value,
        onValueChange = { candidate -> onValueChange(candidate.filter { it.isDigit() || it == '.' || it == ',' }) },
        label = { Text(label) },
        modifier = modifier,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
}

private fun buildCvText(
    fullName: String,
    desiredRole: String,
    phone: String,
    email: String,
    city: String,
    profile: String,
    experience: String,
    education: String,
    skills: String
): String {
    val sections = mutableListOf<String>()
    if (fullName.isNotBlank()) sections += fullName.trim()
    if (desiredRole.isNotBlank()) sections += desiredRole.trim()
    val contact = listOf(phone.trim(), email.trim(), city.trim()).filter { it.isNotBlank() }.joinToString(" | ")
    if (contact.isNotBlank()) sections += contact
    if (profile.isNotBlank()) sections += "\nPERFIL\n${profile.trim()}"
    if (experience.isNotBlank()) sections += "\nEXPERIENCIA\n${experience.trim()}"
    if (education.isNotBlank()) sections += "\nFORMACIÓN\n${education.trim()}"
    if (skills.isNotBlank()) sections += "\nHABILIDADES\n${skills.trim()}"
    return sections.joinToString("\n")
}

private fun buildQuoteSummary(
    client: String,
    quoteName: String,
    notes: String,
    items: List<QuoteLine>,
    subtotal: Double,
    igv: Double,
    total: Double
): String = buildString {
    appendLine(quoteName.ifBlank { "Cotización" })
    if (client.isNotBlank()) appendLine("Cliente: ${client.trim()}")
    appendLine("")
    items.forEachIndexed { index, item ->
        appendLine("${index + 1}. ${item.description} · ${formatNumber(item.quantity)} × S/ ${formatMoney(item.unitPrice)} = S/ ${formatMoney(item.quantity * item.unitPrice)}")
    }
    appendLine("")
    appendLine("Subtotal: S/ ${formatMoney(subtotal)}")
    appendLine("IGV (18%): S/ ${formatMoney(igv)}")
    appendLine("Total: S/ ${formatMoney(total)}")
    if (notes.isNotBlank()) {
        appendLine("")
        appendLine("Observaciones: ${notes.trim()}")
    }
}

private fun parseNumber(value: String): Double = value.replace(',', '.').toDouble()

private fun formatMoney(value: Double): String = String.format(Locale.US, "%.2f", value)

private fun formatNumber(value: Double): String {
    val rounded = String.format(Locale.US, "%.2f", value)
    return rounded.removeSuffix(".00")
}

private fun copyPlainText(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}

private fun saveText(context: Context, uriString: String, text: String) {
    val uri = android.net.Uri.parse(uriString)
    context.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(text) }
        ?: error("No se pudo guardar")
}
