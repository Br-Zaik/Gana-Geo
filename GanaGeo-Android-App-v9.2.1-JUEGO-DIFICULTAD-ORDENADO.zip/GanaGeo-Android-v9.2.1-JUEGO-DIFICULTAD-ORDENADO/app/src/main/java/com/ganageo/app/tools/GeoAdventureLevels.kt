package com.ganageo.app.tools

import kotlin.math.min


data class GamePlatform(val x: Float, val y: Float, val width: Float, val height: Float = 34f)
data class GameHazard(val x: Float, val y: Float, val width: Float = 58f, val height: Float = 42f)
data class GameBarrier(
    val x: Float,
    val y: Float = 270f,
    val width: Float = 46f,
    val height: Float = 350f,
    val switchIndex: Int
)

enum class GameEnemyKind { WALKER, JUMPER, FLYER, SHOOTER, GUARDIAN }

data class GameEnemy(
    val x: Float,
    val y: Float,
    val range: Float = 120f,
    val detectionRange: Float = 480f,
    val health: Int = 2,
    val kind: GameEnemyKind = GameEnemyKind.WALKER,
    val speed: Float = 72f
)

data class GameCrystal(val x: Float, val y: Float)
data class GameCrate(val x: Float, val y: Float)
data class GameSwitch(val x: Float, val y: Float, val opensAtX: Float)

enum class GamePickupKind { ENERGY, SHIELD, POWER }

data class GamePickup(val x: Float, val y: Float, val kind: GamePickupKind)

data class GameMovingPlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val travel: Float,
    val vertical: Boolean,
    val periodSeconds: Float = 3.4f
)

data class AdventureLevel(
    val number: Int,
    val worldName: String,
    val levelName: String,
    val objective: String,
    val difficultyLabel: String,
    val width: Float,
    val platforms: List<GamePlatform>,
    val movingPlatforms: List<GameMovingPlatform>,
    val hazards: List<GameHazard>,
    val barriers: List<GameBarrier>,
    val enemies: List<GameEnemy>,
    val crystals: List<GameCrystal>,
    val crates: List<GameCrate>,
    val switches: List<GameSwitch>,
    val requiredMechanisms: Int,
    val pickups: List<GamePickup>,
    val goalX: Float,
    val parSeconds: Int,
    val introStory: String? = null,
    val outroStory: String? = null,
    val companion: String? = null,
    val injured: Boolean = false,
    val weaponEnabled: Boolean = false,
    val acechantePresent: Boolean = false
)

object GeoAdventureLevelFactory {
    private val names = listOf(
        "Después del impacto", "La noche interminable", "Agua y medicina", "No estás solo",
        "Primeros impulsos", "El refugio de Luma", "Una deuda con el bosque", "Los cazadores",
        "El paso oculto", "La voz de la piedra", "El primer defensor", "La emboscada",
        "Recuperar la energía", "La torre olvidada", "Una luz en las montañas", "El precio de la señal",
        "Sin mirar atrás", "El bosque silencioso", "Los restos equivocados", "La nave sigue viva"
    )

    private val intros = mapOf(
        1 to "La cápsula cayó en una selva desconocida. GEO despierta dañado, con poca energía y recuerdos incompletos. Antes de buscar su nave deberá sobrevivir.",
        5 to "Luma ha decidido acompañar a GEO. Todavía no hablan el mismo idioma, pero ambos comprenden que solos no llegarán lejos.",
        9 to "Las ruinas reaccionan al objeto que GEO protege. Algunos habitantes quieren ayudarlo; otros creen que su llegada condenará al planeta.",
        13 to "GEO recupera parte de su energía. Taro, un guardián que antes desconfiaba de él, acepta guiarlos hacia una antigua torre.",
        17 to "La torre cayó y Taro quedó atrás para salvarlos. GEO continúa con Luma, cargando culpa, tristeza y una nueva determinación."
    )

    private val outros = mapOf(
        4 to "Luma cura las grietas del cuerpo de GEO y se queda a su lado durante la noche. En la oscuridad, algo deja marcas profundas en los árboles.",
        8 to "GEO muestra sin querer un recuerdo de la persecución. Luma comprende que no vino a conquistar su mundo: está escapando de algo mucho peor.",
        12 to "Taro observa a GEO ayudar a un habitante herido y empieza a confiar en él. Un sonido lejano confirma que el Acechante también sobrevivió.",
        16 to "Taro sostiene la compuerta para que GEO y Luma escapen. La torre se derrumba. No se sabe si sobrevivió. GEO quiere volver, pero ya es demasiado tarde.",
        20 to "Desde la montaña, GEO ve por fin su nave principal. Una luz débil confirma que sigue viva, pero una alerta aparece: acceso interno detectado. Algo ya está dentro. Continuará…"
    )

    fun build(number: Int): AdventureLevel {
        val safeLevel = number.coerceIn(1, GeoGameRules.LEVEL_COUNT)
        val worldIndex = (safeLevel - 1) / 5
        val width = 7_800f + safeLevel * 285f
        val platforms = mutableListOf<GamePlatform>()
        val movingPlatforms = mutableListOf<GameMovingPlatform>()
        val hazards = mutableListOf<GameHazard>()
        val barriers = mutableListOf<GameBarrier>()
        val enemies = mutableListOf<GameEnemy>()
        val crates = mutableListOf<GameCrate>()
        val switches = mutableListOf<GameSwitch>()
        val pickups = mutableListOf<GamePickup>()

        val hardGapEvery = (7 - safeLevel / 4).coerceAtLeast(3)
        val movingEvery = (9 - safeLevel / 3).coerceAtLeast(3)
        val hazardEvery = (7 - safeLevel / 4).coerceAtLeast(2)
        val enemyEvery = (6 - safeLevel / 5).coerceAtLeast(2)
        val switchEvery = (8 - safeLevel / 4).coerceAtLeast(3)
        val requiredMechanisms = (1 + (safeLevel - 1) / 6).coerceAtMost(4)

        var x = 0f
        var segment = 0
        while (x < width - 760f) {
            val hardGap = segment > 1 && (segment + safeLevel) % hardGapEvery == 0
            val normalGap = 62f + safeLevel * 2.8f + (segment % 3) * 13f
            val gap = if (hardGap) {
                (normalGap + 74f + safeLevel * 3.7f).coerceAtMost(338f)
            } else {
                normalGap.coerceAtMost(160f)
            }
            val lengthVariation = ((segment * 83 + safeLevel * 41) % 230).toFloat()
            val length = (530f - safeLevel * 6.5f + lengthVariation).coerceIn(305f, 620f)
            val platformWidth = min(length, width - x)
            platforms += GamePlatform(x, 620f, platformWidth)

            if (segment > 0 && (segment + safeLevel) % 2 == 0) {
                val elevatedY = 500f - ((segment + safeLevel) % 3) * 48f
                val elevatedWidth = (185f - safeLevel * 1.5f + (segment % 3) * 28f).coerceAtLeast(132f)
                platforms += GamePlatform(x + 88f, elevatedY, elevatedWidth)
            }

            if (safeLevel >= 3 && segment > 2 && (segment + safeLevel) % movingEvery == 0) {
                movingPlatforms += GameMovingPlatform(
                    x = x + platformWidth + 12f,
                    y = 510f - (segment % 2) * 92f,
                    width = (170f - safeLevel * 1.8f).coerceAtLeast(125f),
                    travel = 78f + safeLevel * 4.2f,
                    vertical = (segment + safeLevel) % 2 == 0,
                    periodSeconds = (4.4f - safeLevel * 0.095f).coerceAtLeast(2.35f)
                )
            }

            if (segment > 0 && (segment + safeLevel) % hazardEvery == 0) {
                val hazardWidth = (54f + safeLevel * 2.2f).coerceAtMost(98f)
                hazards += GameHazard(x + platformWidth * 0.55f, 578f, width = hazardWidth)
                if (safeLevel >= 14 && segment % 4 == 0 && platformWidth > 430f) {
                    hazards += GameHazard(x + platformWidth * 0.76f, 578f, width = 56f + safeLevel)
                }
            }

            if (segment > 1 && (segment + safeLevel) % enemyEvery == 0) {
                val kind = when {
                    safeLevel >= 16 && segment % 7 == 0 -> GameEnemyKind.GUARDIAN
                    safeLevel >= 10 && segment % 5 == 0 -> GameEnemyKind.SHOOTER
                    safeLevel >= 7 && segment % 4 == 0 -> GameEnemyKind.FLYER
                    safeLevel >= 4 && segment % 3 == 0 -> GameEnemyKind.JUMPER
                    else -> GameEnemyKind.WALKER
                }
                val enemyY = if (kind == GameEnemyKind.FLYER) 395f else 568f
                enemies += GameEnemy(
                    x = x + platformWidth * 0.34f,
                    y = enemyY,
                    range = 75f + safeLevel * 8f,
                    detectionRange = 390f + safeLevel * 19f,
                    health = when (kind) {
                        GameEnemyKind.GUARDIAN -> 7 + worldIndex
                        GameEnemyKind.SHOOTER -> 3 + worldIndex
                        GameEnemyKind.FLYER -> 2 + safeLevel / 10
                        else -> 2 + safeLevel / 9
                    },
                    kind = kind,
                    speed = when (kind) {
                        GameEnemyKind.FLYER -> 86f + safeLevel * 2.8f
                        GameEnemyKind.JUMPER -> 82f + safeLevel * 2.6f
                        GameEnemyKind.SHOOTER -> 68f + safeLevel * 2.0f
                        GameEnemyKind.GUARDIAN -> 60f + safeLevel * 1.8f
                        GameEnemyKind.WALKER -> 72f + safeLevel * 2.4f
                    }
                )

                if (safeLevel >= 8 && segment % 5 == 0 && platformWidth > 390f) {
                    enemies += GameEnemy(
                        x = x + platformWidth * 0.70f,
                        y = 568f,
                        range = 72f + safeLevel * 4f,
                        detectionRange = 410f + safeLevel * 16f,
                        health = 2 + safeLevel / 10,
                        kind = if (safeLevel >= 15 && segment % 10 == 0) GameEnemyKind.JUMPER else GameEnemyKind.WALKER,
                        speed = 76f + safeLevel * 2.2f
                    )
                }

                if (safeLevel >= 17 && segment % 7 == 0 && platformWidth > 500f) {
                    enemies += GameEnemy(
                        x = x + platformWidth * 0.52f,
                        y = 395f,
                        range = 120f,
                        detectionRange = 620f,
                        health = 3,
                        kind = GameEnemyKind.FLYER,
                        speed = 112f + safeLevel * 2.2f
                    )
                }
            }

            if (safeLevel >= 4 && segment > 2 && segment % 5 == 0) {
                crates += GameCrate(x + 82f, 566f)
            }

            if (switches.size < requiredMechanisms && segment > 3 && (segment + safeLevel) % switchEvery == 0 && platformWidth > 330f) {
                val switchIndex = switches.size
                val barrierX = x + platformWidth - 52f
                switches += GameSwitch(
                    x = x + 78f,
                    y = 570f,
                    opensAtX = barrierX + 60f
                )
                barriers += GameBarrier(x = barrierX, switchIndex = switchIndex)
            }

            val pickupEvery = 7 + safeLevel / 7
            if (segment > 2 && segment % pickupEvery == 0) {
                val kind = when ((segment + safeLevel) % 3) {
                    0 -> GamePickupKind.ENERGY
                    1 -> GamePickupKind.SHIELD
                    else -> GamePickupKind.POWER
                }
                pickups += GamePickup(x + platformWidth * 0.72f, 530f, kind)
            }

            x += platformWidth + gap
            segment++
        }
        platforms += GamePlatform((width - 760f).coerceAtLeast(0f), 620f, 760f)

        val groundPlatforms = platforms.filter { it.y >= 600f && it.width >= 300f }
        var fallbackIndex = 1
        while (switches.size < requiredMechanisms && fallbackIndex < groundPlatforms.lastIndex) {
            val position = ((fallbackIndex.toFloat() / (requiredMechanisms + 1)) * groundPlatforms.size).toInt()
                .coerceIn(1, groundPlatforms.lastIndex - 1)
            val platform = groundPlatforms[position]
            val switchIndex = switches.size
            val barrierX = platform.x + platform.width - 54f
            if (switches.none { kotlin.math.abs(it.x - (platform.x + 76f)) < 40f }) {
                switches += GameSwitch(platform.x + 76f, 570f, barrierX + 62f)
                barriers += GameBarrier(x = barrierX, switchIndex = switchIndex)
            }
            fallbackIndex++
        }

        fun reachableCrystal(ratio: Float): GameCrystal {
            val targetX = width * ratio
            val platform = platforms.minByOrNull { candidate ->
                when {
                    targetX < candidate.x -> candidate.x - targetX
                    targetX > candidate.x + candidate.width -> targetX - (candidate.x + candidate.width)
                    else -> 0f
                }
            } ?: platforms.first()
            val crystalX = targetX.coerceIn(
                platform.x + 45f,
                (platform.x + platform.width - 45f).coerceAtLeast(platform.x + 45f)
            )
            return GameCrystal(crystalX, platform.y - 92f)
        }

        val companion = when (safeLevel) {
            in 5..10, in 17..20 -> "Luma"
            in 11..16 -> "Taro"
            else -> null
        }
        val objective = when (safeLevel) {
            in 1..3 -> "Aprende el doble salto, evita las primeras trampas y activa la compuerta del refugio."
            in 4..6 -> "Combina saltos, enemigos y mecanismos mientras GEO recupera movilidad."
            in 7..10 -> "Cruza plataformas móviles, protege a Luma y abre las barreras del bosque."
            in 11..14 -> "Supera tiradores, rutas elevadas y mecanismos separados dentro de las ruinas."
            in 15..17 -> "Enfrenta grupos coordinados, trampas dobles y guardianes de la torre."
            in 18..19 -> "Avanza bajo presión del Acechante y supera las combinaciones más exigentes."
            else -> "Completa la prueba final: activa cuatro mecanismos y atraviesa todas las amenazas hasta la nave."
        }
        val difficultyLabel = when (safeLevel) {
            in 1..3 -> "Aprendizaje"
            in 4..6 -> "Fácil"
            in 7..10 -> "Intermedio"
            in 11..14 -> "Difícil"
            in 15..17 -> "Experto"
            in 18..19 -> "Extremo"
            else -> "Final"
        }

        return AdventureLevel(
            number = safeLevel,
            worldName = GeoGameRules.worldName(safeLevel),
            levelName = names[safeLevel - 1],
            objective = objective,
            difficultyLabel = difficultyLabel,
            width = width,
            platforms = platforms,
            movingPlatforms = movingPlatforms,
            hazards = hazards,
            barriers = barriers,
            enemies = enemies,
            crystals = listOf(reachableCrystal(0.20f), reachableCrystal(0.49f), reachableCrystal(0.80f)),
            crates = crates,
            switches = switches,
            requiredMechanisms = requiredMechanisms.coerceAtMost(switches.size),
            pickups = pickups,
            goalX = width - 190f,
            parSeconds = 92 + safeLevel * 6,
            introStory = intros[safeLevel],
            outroStory = outros[safeLevel],
            companion = companion,
            injured = safeLevel <= 3,
            weaponEnabled = safeLevel >= 5,
            acechantePresent = safeLevel >= 18
        )
    }
}
