package com.ganageo.app.tools

data class GeoLifePackage(val code: String, val lives: Int, val creditCost: Int)

object GeoGameRules {
    const val DAILY_FREE_LIVES = 3
    const val PREMIUM_DAILY_LIMIT = 10
    const val PREMIUM_LIFE_CREDIT_COST = 2
    const val PREMIUM_ACTIVATION_SECONDS = 20
    const val LEVEL_COUNT = 20

    val lifePackages: List<GeoLifePackage> = listOf(
        GeoLifePackage("life_1", 1, 2),
        GeoLifePackage("life_5", 5, 10),
        GeoLifePackage("life_15", 15, 30)
    )

    fun packageByCode(code: String): GeoLifePackage? =
        lifePackages.firstOrNull { it.code == code }

    fun worldName(level: Int): String {
        require(level in 1..LEVEL_COUNT)
        return listOf(
            "Selva del impacto",
            "Refugios del bosque",
            "Ruinas del núcleo",
            "Montañas de la señal"
        )[(level - 1) / 5]
    }

    fun calculateStars(won: Boolean, collectedCrystals: Int, seconds: Int, parSeconds: Int): Int {
        if (!won) return 0
        return 1 +
            (if (collectedCrystals >= 3) 1 else 0) +
            (if (seconds <= parSeconds) 1 else 0)
    }
}
