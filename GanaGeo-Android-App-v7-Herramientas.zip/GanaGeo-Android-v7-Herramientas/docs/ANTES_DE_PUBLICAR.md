# Lista obligatoria antes de publicar

- [ ] Probar el login con al menos dos cuentas autorizadas.
- [ ] Confirmar que `ganageo://login-callback` está en Redirect URLs de Supabase.
- [ ] Ejecutar `supabase/02_secure_app_functions.sql`.
- [ ] Confirmar que ningún archivo contiene `service_role` o Client Secret de Google.
- [ ] Crear clave de firma release y guardar copias seguras.
- [ ] Crear OAuth Android con `com.ganageo.app` y SHA-1 release.
- [ ] Contratar proveedores reales antes de activar encuestas, ofertas o anuncios.
- [ ] Crear panel administrativo para verificar y pagar retiros.
- [ ] Publicar política de privacidad y términos reales.
- [ ] Realizar pruebas antifraude y límites de retiros. El UUID local no sustituye una solución antifraude profesional.
- [ ] Revisar impuestos y obligaciones aplicables antes de pagar recompensas.

## Herramientas y packs

- [ ] Ejecutar `supabase/03_tool_credits.sql`.
- [ ] Crear `pack_geo_50` y `pack_geo_100` como productos consumibles en Play Console.
- [ ] Implementar/verificar el backend de Google Play Developer API antes de acreditar créditos reales.
- [ ] Confirmar que una compra de prueba nunca habilite retiro real.
- [ ] Probar reserva, finalización y cancelación de créditos con archivos válidos y dañados.
- [ ] Probar PDF grandes, protegidos y sin páginas válidas.
- [ ] Revisar que los archivos permanezcan en el dispositivo y no se carguen al servidor.
- [ ] Quitar o mantener ocultos todos los controles de prueba en compilaciones release.
- [ ] Mantener claramente separados créditos de herramientas y Geo Rewards retirables.
