package com.ganageo.app.data

import com.ganageo.app.model.DashboardData
import com.ganageo.app.model.LedgerEntry
import com.ganageo.app.model.Profile
import com.ganageo.app.model.ToolCreditAccount
import com.ganageo.app.model.ToolOperationReservation
import com.ganageo.app.model.ToolOperationResult
import com.ganageo.app.model.Wallet
import com.ganageo.app.model.Withdrawal
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.Google
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class GanaGeoRepository(
    private val client: SupabaseClient
) {
    private companion object {
        const val AUTH_REDIRECT_URL = "ganageo://login-callback"
    }
    suspend fun signInWithGoogle() {
        client.auth.signInWith(Google, redirectUrl = AUTH_REDIRECT_URL)
    }

    suspend fun signOut() {
        client.auth.signOut()
    }

    fun currentUserId(): String? = client.auth.currentSessionOrNull()?.user?.id

    suspend fun loadDashboard(installationId: String): DashboardData {
        val userId = currentUserId() ?: error("No hay una sesión activa.")

        val profile = client.from("profiles")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeSingle<Profile>()

        val wallet = client.from("wallets")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeSingle<Wallet>()

        val ledger = client.from("ledger_entries")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeList<LedgerEntry>()
            .sortedByDescending { it.createdAt.orEmpty() }
            .take(50)

        val withdrawals = client.from("withdrawals")
            .select {
                filter { eq("user_id", userId) }
            }
            .decodeList<Withdrawal>()
            .sortedByDescending { it.requestedAt.orEmpty() }
            .take(50)

        val deviceNotice = try {
            client.postgrest.rpc(
                function = "register_my_device",
                parameters = buildJsonObject {
                    put("p_installation_hash", installationId)
                }
            )
            null
        } catch (error: Throwable) {
            val raw = error.message.orEmpty()
            val functionMissing = raw.contains("PGRST202", ignoreCase = true) ||
                raw.contains("Could not find the function", ignoreCase = true) ||
                (raw.contains("register_my_device", ignoreCase = true) &&
                    raw.contains("not found", ignoreCase = true))

            if (functionMissing) {
                "El control de instalación aún no está activado en Supabase. Ejecuta el SQL seguro incluido."
            } else {
                throw error
            }
        }

        val toolCredits = try {
            client.from("tool_credit_accounts")
                .select {
                    filter { eq("user_id", userId) }
                }
                .decodeSingle<ToolCreditAccount>()
        } catch (_: Throwable) {
            ToolCreditAccount(userId = userId)
        }

        return DashboardData(
            profile = profile,
            wallet = wallet,
            ledger = ledger,
            withdrawals = withdrawals,
            deviceNotice = deviceNotice,
            toolCredits = toolCredits
        )
    }


    suspend fun beginToolOperation(toolCode: String, creditCost: Long): ToolOperationReservation {
        return client.postgrest.rpc(
            function = "begin_tool_operation",
            parameters = buildJsonObject {
                put("p_tool_code", toolCode)
                put("p_credit_cost", creditCost)
            }
        ).decodeList<ToolOperationReservation>().single()
    }

    suspend fun completeToolOperation(operationId: String): ToolOperationResult {
        return client.postgrest.rpc(
            function = "complete_tool_operation",
            parameters = buildJsonObject {
                put("p_operation_id", operationId)
            }
        ).decodeList<ToolOperationResult>().single()
    }

    suspend fun cancelToolOperation(operationId: String) {
        client.postgrest.rpc(
            function = "cancel_tool_operation",
            parameters = buildJsonObject {
                put("p_operation_id", operationId)
            }
        )
    }

    suspend fun requestWithdrawal(
        amount: Double,
        paymentMethod: String,
        destination: String
    ) {
        client.postgrest.rpc(
            function = "request_withdrawal",
            parameters = buildJsonObject {
                put("p_amount", amount)
                put("p_payment_method", paymentMethod)
                put("p_payment_destination", destination.trim())
            }
        )
    }

    suspend fun cancelWithdrawal(withdrawalId: String) {
        client.postgrest.rpc(
            function = "cancel_my_withdrawal",
            parameters = buildJsonObject {
                put("p_withdrawal_id", withdrawalId)
            }
        )
    }

    private fun Throwable.cleanMessage(): String =
        message
            ?.replace("PostgrestRestException", "Error de Supabase")
            ?.take(180)
            ?: "error desconocido"
}
