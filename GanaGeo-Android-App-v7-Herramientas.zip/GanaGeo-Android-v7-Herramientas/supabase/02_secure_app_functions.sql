-- Gana Geo: funciones seguras que la app puede invocar.
-- Ejecutar UNA sola vez en Supabase > SQL Editor, después del bloque inicial de tablas.
-- No usa service_role dentro de la app y nunca permite que el APK cambie saldos libremente.

begin;

-- =========================================================
-- 1. REGISTRAR UNA INSTALACION ACTIVA POR CUENTA/DISPOSITIVO
-- =========================================================

create or replace function public.register_my_device(
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_device_id uuid;
    v_owner_id uuid;
    v_current_hash text;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    if p_installation_hash is null or length(trim(p_installation_hash)) < 16 then
        raise exception 'Invalid installation identifier';
    end if;

    if not exists (
        select 1
          from public.profiles
         where user_id = v_user_id
           and account_status = 'active'
    ) then
        raise exception 'Account is not active';
    end if;

    -- Impide que una instalación activa pertenezca a otra cuenta.
    select id, user_id
      into v_device_id, v_owner_id
      from public.devices
     where installation_hash = trim(p_installation_hash)
       and device_status = 'active'
     for update;

    if v_device_id is not null and v_owner_id <> v_user_id then
        raise exception 'This device is already linked to another account';
    end if;

    v_device_id := null;

    -- Impide que una cuenta activa cambie de dispositivo sin revisión.
    select id, installation_hash
      into v_device_id, v_current_hash
      from public.devices
     where user_id = v_user_id
       and device_status = 'active'
     for update;

    if v_device_id is not null then
        if v_current_hash <> trim(p_installation_hash) then
            raise exception 'This account is already linked to another active device';
        end if;

        update public.devices
           set last_seen_at = now()
         where id = v_device_id;
    else
        insert into public.devices (
            user_id,
            installation_hash,
            device_status,
            first_seen_at,
            last_seen_at
        ) values (
            v_user_id,
            trim(p_installation_hash),
            'active',
            now(),
            now()
        );
    end if;

    update public.profiles
       set last_seen_at = now()
     where user_id = v_user_id;
end;
$$;

-- =========================================================
-- 2. SOLICITAR RETIRO Y BLOQUEAR EL SALDO EN UNA TRANSACCION
-- =========================================================

create or replace function public.request_withdrawal(
    p_amount numeric,
    p_payment_method text,
    p_payment_destination text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_currency text;
    v_withdrawal_id uuid;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    if p_amount is null or p_amount < 5 then
        raise exception 'Withdrawal amount must be at least S/5';
    end if;

    if p_amount <> round(p_amount, 2) then
        raise exception 'Withdrawal amount can have at most two decimals';
    end if;

    if lower(trim(p_payment_method)) not in ('yape', 'plin', 'paypal') then
        raise exception 'Unsupported payment method';
    end if;

    if p_payment_destination is null or length(trim(p_payment_destination)) < 5 then
        raise exception 'Invalid payment destination';
    end if;

    if not exists (
        select 1
          from public.profiles
         where user_id = v_user_id
           and account_status = 'active'
    ) then
        raise exception 'Account is not active';
    end if;

    select currency
      into v_currency
      from public.wallets
     where user_id = v_user_id
     for update;

    if v_currency is null then
        raise exception 'Wallet not found';
    end if;

    update public.wallets
       set available_amount = available_amount - p_amount,
           locked_amount = locked_amount + p_amount,
           updated_at = now()
     where user_id = v_user_id
       and available_amount >= p_amount;

    if not found then
        raise exception 'Insufficient available balance';
    end if;

    insert into public.withdrawals (
        user_id,
        amount,
        currency,
        payment_method,
        payment_destination,
        status,
        requested_at,
        updated_at
    ) values (
        v_user_id,
        p_amount,
        v_currency,
        lower(trim(p_payment_method)),
        trim(p_payment_destination),
        'pending',
        now(),
        now()
    )
    returning id into v_withdrawal_id;

    insert into public.ledger_entries (
        user_id,
        entry_type,
        points_delta,
        cash_delta,
        cash_bucket,
        currency,
        provider,
        external_transaction_id,
        description,
        metadata
    ) values (
        v_user_id,
        'withdrawal',
        0,
        -p_amount,
        'available',
        v_currency,
        'gana_geo',
        v_withdrawal_id::text,
        'Retiro solicitado',
        jsonb_build_object(
            'withdrawal_id', v_withdrawal_id,
            'status', 'pending',
            'payment_method', lower(trim(p_payment_method))
        )
    );

    return v_withdrawal_id;
end;
$$;

-- =========================================================
-- 3. CANCELAR UN RETIRO PENDIENTE Y LIBERAR EL SALDO
-- =========================================================

create or replace function public.cancel_my_withdrawal(
    p_withdrawal_id uuid
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_amount numeric(14,2);
    v_currency text;
    v_status text;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    select amount, currency, status
      into v_amount, v_currency, v_status
      from public.withdrawals
     where id = p_withdrawal_id
       and user_id = v_user_id
     for update;

    if v_amount is null then
        raise exception 'Withdrawal not found';
    end if;

    if v_status not in ('pending', 'under_review') then
        raise exception 'This withdrawal can no longer be cancelled';
    end if;

    update public.wallets
       set available_amount = available_amount + v_amount,
           locked_amount = locked_amount - v_amount,
           updated_at = now()
     where user_id = v_user_id
       and locked_amount >= v_amount;

    if not found then
        raise exception 'Wallet locked balance is inconsistent';
    end if;

    update public.withdrawals
       set status = 'cancelled',
           updated_at = now(),
           processed_at = now()
     where id = p_withdrawal_id;

    insert into public.ledger_entries (
        user_id,
        entry_type,
        points_delta,
        cash_delta,
        cash_bucket,
        currency,
        provider,
        external_transaction_id,
        description,
        metadata
    ) values (
        v_user_id,
        'reversal',
        0,
        v_amount,
        'available',
        v_currency,
        'gana_geo_cancel',
        p_withdrawal_id::text,
        'Retiro cancelado',
        jsonb_build_object(
            'withdrawal_id', p_withdrawal_id,
            'status', 'cancelled'
        )
    );
end;
$$;

-- =========================================================
-- 4. PERMISOS MINIMOS
-- =========================================================

revoke all on function public.register_my_device(text)
from public, anon;

grant execute on function public.register_my_device(text)
to authenticated;

revoke all on function public.request_withdrawal(numeric, text, text)
from public, anon;

grant execute on function public.request_withdrawal(numeric, text, text)
to authenticated;

revoke all on function public.cancel_my_withdrawal(uuid)
from public, anon;

grant execute on function public.cancel_my_withdrawal(uuid)
to authenticated;

commit;
