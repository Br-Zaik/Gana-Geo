package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.net.Uri
import android.util.Xml
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

@Composable
fun PdfViewerScreen(
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val horizontalScrollState = rememberScrollState()
    var uriText by rememberSaveable { mutableStateOf<String?>(null) }
    val uri = uriText?.let(Uri::parse)
    var pageCount by rememberSaveable { mutableIntStateOf(0) }
    var loadingDocument by remember { mutableStateOf(false) }
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    var showOverview by rememberSaveable { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selected,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            uriText = selected.toString()
            pageCount = 0
            zoom = 1f
            showOverview = false
        }
    }

    LaunchedEffect(uriText) {
        val selected = uri ?: run {
            pageCount = 0
            onImmersiveChanged(false)
            return@LaunchedEffect
        }
        onImmersiveChanged(true)
        horizontalScrollState.scrollTo(0)
        listState.scrollToItem(0)
        loadingDocument = true
        runCatching { ToolFileUtils.pdfPageCount(context, selected) }
            .onSuccess { pageCount = it }
            .onFailure {
                pageCount = 0
                onMessage(it.message ?: "No se pudo abrir el PDF.")
            }
        loadingDocument = false
    }

    DisposableEffect(Unit) {
        onDispose { onImmersiveChanged(false) }
    }

    if (uri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Visor gratuito · el archivo no se modifica", onBack)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Ningún PDF seleccionado", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { launcher.launch(arrayOf("application/pdf")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                        Text(" Abrir PDF")
                    }
                }
            }
        }
        return
    }

    val fileName = remember(uriText) { ToolFileUtils.displayName(context, uri) }
    val currentPage by remember {
        derivedStateOf {
            if (pageCount <= 0) 0
            else (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding(),
            color = Color(0xFF202124),
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = Color.White)
                }
                Text(
                    fileName,
                    modifier = Modifier.weight(1f),
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = { launcher.launch(arrayOf("application/pdf")) }) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = "Cambiar PDF", tint = Color.White)
                }
            }
        }

        if (loadingDocument || pageCount <= 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = NeonGreen)
            }
        } else if (showOverview) {
            PdfOverview(
                uri = uri,
                pageCount = pageCount,
                onSelectPage = { index ->
                    showOverview = false
                    zoom = 1f
                    scope.launch {
                        kotlinx.coroutines.yield()
                        horizontalScrollState.scrollTo(0)
                        listState.scrollToItem(index)
                    }
                },
                onMessage = onMessage
            )
        } else {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212))
            ) {
                val viewerWidth = maxWidth * zoom
                val renderWidth = when {
                    zoom >= 2.4f -> 2400
                    zoom >= 1.5f -> 1900
                    else -> 1300
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(uriText) {
                            awaitEachGesture {
                                do {
                                    val event = awaitPointerEvent()
                                    val pressed = event.changes.filter { it.pressed }
                                    if (pressed.size >= 2) {
                                        val gestureZoom = event.calculateZoom()
                                        val pan = event.calculatePan()
                                        val oldZoom = zoom
                                        val newZoom = (oldZoom * gestureZoom).coerceIn(1f, 4f)
                                        zoom = newZoom

                                        if (newZoom <= 1.01f) {
                                            horizontalScrollState.dispatchRawDelta(
                                                -horizontalScrollState.value.toFloat()
                                            )
                                        } else if (pan.x != 0f) {
                                            horizontalScrollState.dispatchRawDelta(-pan.x)
                                        }

                                        if (pan.y != 0f) {
                                            listState.dispatchRawDelta(-pan.y)
                                        }
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                        .pointerInput(uriText) {
                            detectTapGestures(
                                onDoubleTap = { tap ->
                                    val oldZoom = zoom
                                    val newZoom = if (oldZoom > 1.1f) 1f else 2f
                                    zoom = newZoom
                                    scope.launch {
                                        kotlinx.coroutines.yield()
                                        if (newZoom == 1f) {
                                            horizontalScrollState.animateScrollTo(0)
                                        } else {
                                            val scaleChange = newZoom / oldZoom.coerceAtLeast(1f)
                                            val target = (
                                                (horizontalScrollState.value + tap.x) * scaleChange - tap.x
                                            ).toInt().coerceIn(0, horizontalScrollState.maxValue)
                                            horizontalScrollState.animateScrollTo(target)
                                        }
                                    }
                                }
                            )
                        }
                        .horizontalScroll(horizontalScrollState)
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .width(viewerWidth)
                            .fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = 4.dp,
                            end = 4.dp,
                            top = 4.dp,
                            bottom = 20.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(
                            count = pageCount,
                            key = { index -> "pdf_page_$index" },
                            contentType = { "pdf_page" }
                        ) { index ->
                            ContinuousPdfPage(
                                uri = uri,
                                pageIndex = index,
                                renderWidth = renderWidth,
                                onMessage = onMessage
                            )
                        }
                    }
                }

                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 10.dp, end = 12.dp)
                        .clickable { showOverview = true },
                    color = Color.White.copy(alpha = 0.94f),
                    contentColor = Color(0xFF303134),
                    shape = RoundedCornerShape(18.dp),
                    shadowElevation = 3.dp
                ) {
                    Row(
                        modifier = Modifier.padding(start = 12.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            "$currentPage/$pageCount",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        PdfGridGlyph()
                    }
                }

                val progress = if (pageCount <= 1) 0f
                else (currentPage - 1).toFloat() / (pageCount - 1).toFloat()

                BoxWithConstraints(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxSize()
                        .padding(top = 54.dp, bottom = 18.dp)
                ) {
                    val thumbHeight = 48.dp
                    val travel = (maxHeight - thumbHeight).coerceAtLeast(0.dp)
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .width(28.dp)
                            .height(maxHeight)
                            .pointerInput(pageCount) {
                                fun jumpTo(y: Float) {
                                    if (pageCount <= 1 || size.height <= 0) return
                                    val fraction = (y / size.height.toFloat()).coerceIn(0f, 1f)
                                    val target = (fraction * (pageCount - 1)).toInt()
                                    scope.launch { listState.scrollToItem(target) }
                                }
                                detectVerticalDragGestures(
                                    onDragStart = { offset -> jumpTo(offset.y) },
                                    onVerticalDrag = { change, _ ->
                                        change.consume()
                                        jumpTo(change.position.y)
                                    }
                                )
                            }
                    ) {
                        Surface(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .offset(y = travel * progress)
                                .width(18.dp)
                                .height(thumbHeight),
                            color = Color(0xFF7A7A7A).copy(alpha = 0.86f),
                            shape = RoundedCornerShape(10.dp),
                            shadowElevation = 2.dp
                        ) {}
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfGridGlyph() {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(3) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                repeat(3) {
                    Box(
                        modifier = Modifier
                            .size(3.dp)
                            .background(Color(0xFF5F6368), RoundedCornerShape(1.dp))
                    )
                }
            }
        }
    }
}

@Composable
private fun PdfOverview(
    uri: Uri,
    pageCount: Int,
    onSelectPage: (Int) -> Unit,
    onMessage: (String) -> Unit
) {
    val rowCount = (pageCount + 2) / 3
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF171717)),
        contentPadding = PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(count = rowCount, key = { "pdf_overview_row_$it" }) { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                repeat(3) { column ->
                    val pageIndex = row * 3 + column
                    if (pageIndex < pageCount) {
                        PdfThumbnail(
                            uri = uri,
                            pageIndex = pageIndex,
                            modifier = Modifier.weight(1f),
                            onClick = { onSelectPage(pageIndex) },
                            onMessage = onMessage
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfThumbnail(
    uri: Uri,
    pageIndex: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var bitmap by remember(uri, pageIndex) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(uri, pageIndex) {
        runCatching {
            ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = 360)
        }.onSuccess { fresh ->
            val previous = bitmap
            bitmap = fresh
            previous?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure {
            onMessage(it.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
        }
    }

    DisposableEffect(uri, pageIndex) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    Column(
        modifier = modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            val current = bitmap
            if (current != null) {
                Image(
                    bitmap = current.asImageBitmap(),
                    contentDescription = "Página ${pageIndex + 1}",
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = NeonGreen,
                        strokeWidth = 2.dp
                    )
                }
            }
        }
        Text(
            "${pageIndex + 1}",
            color = Color.White.copy(alpha = 0.78f),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun ContinuousPdfPage(
    uri: Uri,
    pageIndex: Int,
    renderWidth: Int,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var bitmap by remember(uri, pageIndex, renderWidth) { mutableStateOf<Bitmap?>(null) }
    var loading by remember(uri, pageIndex, renderWidth) { mutableStateOf(true) }

    LaunchedEffect(uri, pageIndex, renderWidth) {
        loading = true
        runCatching {
            ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = renderWidth)
        }.onSuccess { fresh ->
            val previous = bitmap
            bitmap = fresh
            previous?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure {
            onMessage(it.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
        }
        loading = false
    }

    DisposableEffect(uri, pageIndex, renderWidth) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        val current = bitmap
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = "Página ${pageIndex + 1}",
                contentScale = ContentScale.FillWidth,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                if (loading) CircularProgressIndicator(color = NeonGreen)
            }
        }
    }
}

enum class OfficeViewerType(val label: String, val extensions: String, val mimeTypes: Array<String>) {
    WORD("Word", "DOCX", arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")),
    EXCEL("Excel", "XLSX", arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")),
    POWERPOINT("PowerPoint", "PPTX", arrayOf("application/vnd.openxmlformats-officedocument.presentationml.presentation"))
}

@Composable
fun OfficeViewerScreen(
    tool: ToolId,
    type: OfficeViewerType,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var uriText by rememberSaveable { mutableStateOf<String?>(null) }
    val uri = uriText?.let { Uri.parse(it) }
    var sections by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selected,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            uriText = selected.toString()
            scope.launch {
                loading = true
                runCatching {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(selected)?.use { stream ->
                            val bytes = stream.readBytes()
                            when (type) {
                                OfficeViewerType.WORD -> parseDocx(bytes)
                                OfficeViewerType.EXCEL -> parseXlsx(bytes)
                                OfficeViewerType.POWERPOINT -> parsePptx(bytes)
                            }
                        } ?: error("No se pudo leer el archivo.")
                    }
                }.onSuccess { sections = it }
                    .onFailure { onMessage(it.message ?: "No se pudo abrir el archivo ${type.extensions}.") }
                loading = false
            }
        }
    }

    val filtered = remember(sections, query) {
        if (query.isBlank()) sections
        else sections.mapNotNull { (title, body) ->
            val lines = body.lineSequence().filter { it.contains(query, ignoreCase = true) }.toList()
            if (lines.isEmpty() && !title.contains(query, ignoreCase = true)) null
            else title to (if (lines.isEmpty()) body else lines.joinToString("\n"))
        }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Visor gratuito ${type.extensions} · sin edición", onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            uri?.let { ToolFileUtils.displayName(context, it) } ?: "Ningún archivo seleccionado",
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedButton(onClick = { launcher.launch(type.mimeTypes) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                            Text(" Abrir ${type.label}")
                        }
                        Text(
                            "Vista básica local. Conserva el contenido y la estructura principal; diseños complejos pueden verse simplificados.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (loading) item { Box(Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = NeonGreen) } }
            if (sections.isNotEmpty()) {
                item {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it.take(80) },
                        label = { Text("Buscar dentro del archivo") },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                itemsIndexed(filtered) { index, item ->
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(item.first.ifBlank { "Sección ${index + 1}" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(item.second.ifBlank { "Sin texto visible" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

private fun unzipEntries(bytes: ByteArray): Map<String, ByteArray> {
    val result = linkedMapOf<String, ByteArray>()
    ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
        while (true) {
            val entry = zip.nextEntry ?: break
            if (!entry.isDirectory) {
                val out = ByteArrayOutputStream()
                zip.copyTo(out)
                result[entry.name] = out.toByteArray()
            }
            zip.closeEntry()
        }
    }
    return result
}

private fun extractXmlText(bytes: ByteArray, lineBreakTags: Set<String>): String {
    val parser = Xml.newPullParser().apply {
        setInput(ByteArrayInputStream(bytes), "UTF-8")
    }
    val out = StringBuilder()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.TEXT -> {
                val text = parser.text.orEmpty()
                if (text.isNotBlank()) out.append(text)
            }
            XmlPullParser.END_TAG -> if (parser.name in lineBreakTags) {
                if (out.isNotEmpty() && out.last() != '\n') out.append('\n')
            }
        }
        event = parser.next()
    }
    return out.toString().replace(Regex("[ \\t]+\n"), "\n").replace(Regex("\n{3,}"), "\n\n").trim()
}

private fun parseDocx(bytes: ByteArray): List<Pair<String, String>> {
    val entries = unzipEntries(bytes)
    val document = entries["word/document.xml"] ?: error("El DOCX no contiene un documento legible.")
    val text = extractXmlText(document, setOf("p", "tr", "tc"))
    return listOf("Documento" to text)
}

private fun parsePptx(bytes: ByteArray): List<Pair<String, String>> {
    val entries = unzipEntries(bytes)
    val slides = entries.filterKeys { it.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
        .toList()
        .sortedBy { it.first.filter(Char::isDigit).toIntOrNull() ?: 0 }
    if (slides.isEmpty()) error("El PPTX no contiene diapositivas legibles.")
    return slides.mapIndexed { index, (_, data) ->
        "Diapositiva ${index + 1}" to extractXmlText(data, setOf("p", "br"))
    }
}

private fun parseXlsx(bytes: ByteArray): List<Pair<String, String>> {
    val entries = unzipEntries(bytes)
    val shared = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) }.orEmpty()
    val sheets = entries.filterKeys { it.matches(Regex("xl/worksheets/sheet\\d+\\.xml")) }
        .toList()
        .sortedBy { it.first.filter(Char::isDigit).toIntOrNull() ?: 0 }
    if (sheets.isEmpty()) error("El XLSX no contiene hojas legibles.")
    return sheets.mapIndexed { index, (_, data) ->
        "Hoja ${index + 1}" to parseWorksheet(data, shared)
    }
}

private fun parseSharedStrings(bytes: ByteArray): List<String> {
    val parser = Xml.newPullParser().apply { setInput(ByteArrayInputStream(bytes), "UTF-8") }
    val values = mutableListOf<String>()
    var insideSi = false
    var current = StringBuilder()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> if (parser.name == "si") { insideSi = true; current = StringBuilder() }
            XmlPullParser.TEXT -> if (insideSi) current.append(parser.text.orEmpty())
            XmlPullParser.END_TAG -> if (parser.name == "si") { values += current.toString(); insideSi = false }
        }
        event = parser.next()
    }
    return values
}

private fun parseWorksheet(bytes: ByteArray, shared: List<String>): String {
    val parser = Xml.newPullParser().apply { setInput(ByteArrayInputStream(bytes), "UTF-8") }
    val out = StringBuilder()
    var cellType: String? = null
    var cellRef = ""
    var inValue = false
    var value = ""
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> when (parser.name) {
                "row" -> if (out.isNotEmpty() && out.last() != '\n') out.append('\n')
                "c" -> {
                    cellType = parser.getAttributeValue(null, "t")
                    cellRef = parser.getAttributeValue(null, "r").orEmpty()
                    value = ""
                }
                "v", "t" -> inValue = true
            }
            XmlPullParser.TEXT -> if (inValue) value += parser.text.orEmpty()
            XmlPullParser.END_TAG -> when (parser.name) {
                "v", "t" -> inValue = false
                "c" -> {
                    val shown = if (cellType == "s") shared.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value
                    if (shown.isNotBlank()) out.append(if (cellRef.isBlank()) "" else "$cellRef: ").append(shown).append("    ")
                }
            }
        }
        event = parser.next()
    }
    return out.toString().trim()
}
