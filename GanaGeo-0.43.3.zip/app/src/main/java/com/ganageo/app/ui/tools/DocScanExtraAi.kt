package com.ganageo.app.ui.tools

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import com.ganageo.app.tools.ScanReader
import com.ganageo.app.tools.ScanUnwarp
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Segundo lector de letras: PP-OCRv5 latino (PaddleOCR, Apache 2.0, incluye español),
 * con ONNX Runtime (MIT). Va dentro de la app (lo baja GitHub al compilar). Se usa
 * para volver a leer lo dudoso y comparar con el lector del celular.
 *
 * Al abrirlo se prueba solo: lee una frase dibujada por la app; si no la lee bien
 * (modelo dañado o distinto), no se usa y todo sigue como antes.
 */
internal object DocScanReaderAi {
    private const val MODEL = "models/latin_rec.onnx"
    private const val DICT = "models/latin_dict.txt"
    private const val TEST = "Horario de Educación 2026"

    private val lock = Any()
    @Volatile private var session: OrtSession? = null
    @Volatile private var dict: List<String> = emptyList()
    @Volatile private var height = 48
    @Volatile private var failed = false
    @Volatile var lastError: String? = null
        private set

    fun ready(context: Context): Boolean = open(context) != null

    private fun open(context: Context): OrtSession? {
        session?.let { return it }
        if (failed) return null
        synchronized(lock) {
            session?.let { return it }
            if (failed) return null
            try {
                val app = context.applicationContext
                val bytes = runCatching { app.assets.open(MODEL).use { it.readBytes() } }.getOrNull()
                val words = runCatching {
                    app.assets.open(DICT).bufferedReader(Charsets.UTF_8).use { it.readText() }
                }.getOrNull()
                if (bytes == null || words == null) {
                    failed = true
                    return null
                }
                // Una letra por renglón (sin borrar nada: el orden es el número de cada letra).
                val lines = words.split('\n').map { it.removeSuffix("\r") }.let { if (it.lastOrNull()?.isEmpty() == true) it.dropLast(1) else it }
                val options = OrtSession.SessionOptions()
                options.setIntraOpNumThreads(2)
                val opened = OrtEnvironment.getEnvironment().createSession(bytes, options)
                val shape = (opened.inputInfo.values.first().info as? TensorInfo)?.shape
                val fixed = shape?.getOrNull(2)?.toInt() ?: -1
                height = if (fixed > 0) fixed else 48
                dict = lines
                session = opened
                // Prueba: si no lee bien una frase clara, no se usa.
                val check = selfTest()
                if (check == null || similarity(check, TEST) < 0.75f) {
                    runCatching { opened.close() }
                    session = null
                    failed = true
                    lastError = "Prueba fallida: \"${check ?: "nada"}\""
                    return null
                }
                lastError = null
                return opened
            } catch (error: Throwable) {
                failed = true
                session = null
                lastError = error.message?.take(120) ?: error.javaClass.simpleName
                return null
            }
        }
    }

    private fun selfTest(): String? {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 40f
            typeface = Typeface.SANS_SERIF
        }
        val width = paint.measureText(TEST).roundToInt() + 40
        val bitmap = Bitmap.createBitmap(width, 64, Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)
            canvas.drawText(TEST, 20f, 46f, paint)
            return readPixels(bitmap, Rect(0, 0, width, 64))?.text
        } finally {
            bitmap.recycle()
        }
    }

    /** Lee el pedazo [box] de [bitmap] como un renglón. null si no hay lector. */
    fun read(context: Context, bitmap: Bitmap, box: Rect): ScanReader.Read? {
        if (open(context) == null) return null
        return runCatching { readPixels(bitmap, box) }.getOrNull()
    }

    private fun readPixels(bitmap: Bitmap, box: Rect): ScanReader.Read? {
        val current = session ?: return null
        val pad = max(2, (box.height() * 0.12f).roundToInt())
        val crop = Rect(box.left - pad, box.top - pad, box.right + pad, box.bottom + pad)
        if (!crop.intersect(0, 0, bitmap.width, bitmap.height)) return null
        if (crop.width() < 4 || crop.height() < 4) return null
        val pixels = IntArray(crop.width() * crop.height())
        bitmap.getPixels(pixels, 0, crop.width(), crop.left, crop.top, crop.width(), crop.height())
        val input = ScanReader.prepare(pixels, crop.width(), crop.height(), height)
        val env = OrtEnvironment.getEnvironment()
        OnnxTensor.createTensor(env, FloatBuffer.wrap(input.data), longArrayOf(1, 3, input.height.toLong(), input.width.toLong())).use { tensor ->
            current.run(mapOf(current.inputNames.first() to tensor)).use { result ->
                val output = result.get(0) as? OnnxTensor ?: return null
                val shape = output.info.shape
                if (shape.size != 3) return null
                val steps = shape[1].toInt()
                val classes = shape[2].toInt()
                val buffer = output.floatBuffer
                val data = FloatArray(buffer.remaining())
                buffer.get(data)
                return ScanReader.decode(data, steps, classes, dict)
            }
        }
    }

    /** Parecido entre dos textos (0..1), sin fijarse en mayúsculas. */
    fun similarity(a: String, b: String): Float {
        val x = a.lowercase()
        val y = b.lowercase()
        if (x.isEmpty() && y.isEmpty()) return 1f
        val previous = IntArray(y.length + 1) { it }
        val current = IntArray(y.length + 1)
        for (i in 1..x.length) {
            current[0] = i
            for (j in 1..y.length) {
                val cost = if (x[i - 1] == y[j - 1]) 0 else 1
                current[j] = min(min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost)
            }
            System.arraycopy(current, 0, previous, 0, current.size)
        }
        return 1f - previous[y.length] / max(x.length, y.length).toFloat()
    }
}

/**
 * Aplanar hojas dobladas: UVDoc (PaddleOCR, Apache 2.0) con ONNX Runtime. Va dentro de
 * la app. Solo se usa si la hoja sigue doblada después del enderezado de siempre, y
 * el resultado solo se queda si las rayas quedaron claramente más derechas.
 */
internal object DocScanUnwarpAi {
    private const val MODEL = "models/uvdoc.onnx"
    /** Lado mayor con que se aplana (más grande gasta mucha memoria). */
    const val EDGE = 1800

    private val lock = Any()
    @Volatile private var session: OrtSession? = null
    @Volatile private var failed = false
    @Volatile var lastError: String? = null
        private set

    private fun open(context: Context): OrtSession? {
        session?.let { return it }
        if (failed) return null
        synchronized(lock) {
            session?.let { return it }
            if (failed) return null
            return try {
                val bytes = runCatching { context.applicationContext.assets.open(MODEL).use { it.readBytes() } }.getOrNull()
                if (bytes == null) {
                    failed = true
                    null
                } else {
                    val options = OrtSession.SessionOptions()
                    options.setIntraOpNumThreads(2)
                    OrtEnvironment.getEnvironment().createSession(bytes, options).also { session = it }
                }
            } catch (error: Throwable) {
                failed = true
                lastError = error.message?.take(120) ?: error.javaClass.simpleName
                null
            }
        }
    }

    /**
     * Hoja [pixels] ([width]×[height], ya del tamaño EDGE o menos) aplanada, del mismo
     * tamaño. null si no hay IA o falló.
     */
    fun flatten(context: Context, pixels: IntArray, width: Int, height: Int): IntArray? {
        val current = open(context) ?: return null
        return try {
            val env = OrtEnvironment.getEnvironment()
            val input = ScanUnwarp.input(pixels, width, height)
            OnnxTensor.createTensor(env, FloatBuffer.wrap(input), longArrayOf(1, 3, height.toLong(), width.toLong())).use { tensor ->
                current.run(mapOf(current.inputNames.first() to tensor)).use { result ->
                    val output = result.get(0) as? OnnxTensor ?: return null
                    val shape = output.info.shape
                    if (shape.size != 4) return null
                    val channels = shape[1].toInt()
                    val outH = shape[2].toInt()
                    val outW = shape[3].toInt()
                    val buffer = output.floatBuffer
                    val data = FloatArray(buffer.remaining())
                    buffer.get(data)
                    when {
                        // La hoja ya aplanada, del mismo tamaño.
                        channels == 3 && outW == width && outH == height -> ScanUnwarp.image(data, width, height)
                        // Solo la malla: se arma aquí.
                        channels == 2 && outW >= 2 && outH >= 2 -> ScanUnwarp.sampleGrid(pixels, width, height, data, outW, outH)
                        else -> null
                    }
                }
            }
        } catch (error: Throwable) {
            lastError = error.message?.take(120) ?: error.javaClass.simpleName
            null
        }
    }
}
