package com.ganageo.app.tools

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Colores parejos para la hoja nueva sacada de una FOTO: la luz de la foto no es
 * igual en toda la hoja (arriba a la izquierda más clara), entonces la letra se
 * medía gris clarito en un lado y negra en otro, y las celdas de un mismo color
 * salían de dos tonos. Una hoja de Word o PDF tiene la letra pareja.
 *
 * - [inks]: la letra gris sobre fondo claro queda oscura y pareja (como la más
 *   oscura de la hoja); la letra de color muy clara se oscurece un poco (sin perder
 *   su color). Sobre fondo oscuro (letra blanca en barras) no se toca.
 * - [fills]: celdas del mismo color (aunque una salió más lavada) quedan iguales,
 *   con el tono más vivo del grupo.
 */
object ScanTone {

    private fun lum(c: Int) = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
    private fun sat(c: Int): Int {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return max(r, max(g, b)) - min(r, min(g, b))
    }
    private fun gray(v: Int): Int { val x = v.coerceIn(0, 255); return (0xFF shl 24) or (x shl 16) or (x shl 8) or x }

    /** Letra pareja: [backgrounds] es el fondo de cada letra (mismo largo). */
    fun inks(inks: IntArray, backgrounds: IntArray): IntArray {
        val out = inks.copyOf()
        val neutral = inks.indices.filter { lum(backgrounds[it]) >= 165 && sat(inks[it]) < 60 }
        if (neutral.isNotEmpty()) {
            val lums = neutral.map { lum(inks[it]) }.sorted()
            val darkest = lums[(lums.size * 0.25f).toInt().coerceAtMost(lums.size - 1)]
            val target = min(darkest, 55)
            for (i in neutral) {
                // Gris muy clarito a propósito (más de 110 más claro): se deja.
                if (lum(inks[i]) - darkest < 110) out[i] = gray(target)
            }
        }
        // Sobre una celda de color, la letra se mide teñida del fondo (sus bordes se
        // mezclan con él): si tiene el mismo matiz del fondo, es letra oscura normal.
        val darkInk = if (neutral.isNotEmpty()) {
            val lums = neutral.map { lum(inks[it]) }.sorted()
            min(lums[(lums.size * 0.25f).toInt().coerceAtMost(lums.size - 1)], 55)
        } else 40
        for (i in inks.indices) {
            val bg = backgrounds[i]
            if (sat(bg) < 40 || lum(bg) < 120) continue
            if (lum(inks[i]) >= lum(bg) - 40) continue
            if (sat(inks[i]) < 60 || hueDiff(inks[i], bg) < 30f) out[i] = gray(darkInk)
        }
        for (i in inks.indices) {
            if (lum(backgrounds[i]) < 165 || sat(inks[i]) < 60) continue
            if (sat(backgrounds[i]) >= 40 && hueDiff(inks[i], backgrounds[i]) < 30f) continue
            val l = lum(inks[i])
            if (l > 120) {
                val k = 120f / l
                val c = inks[i]
                out[i] = (0xFF shl 24) or
                    ((((c shr 16) and 255) * k).roundToInt() shl 16) or
                    ((((c shr 8) and 255) * k).roundToInt() shl 8) or
                    ((c and 255) * k).roundToInt()
            }
        }
        return out
    }

    /** Celdas del mismo color, iguales (el tono más vivo de su grupo). */
    fun fills(fills: List<Int?>): List<Int?> {
        val colors = fills.mapIndexedNotNull { index, c -> c?.let { index to it } }
        if (colors.size < 2) return fills
        val groups = ArrayList<MutableList<Int>>()
        for ((index, c) in colors) {
            val group = groups.firstOrNull { g -> ScanBars.dist(fills[g.first()]!!, c) < 90 && hueClose(fills[g.first()]!!, c) }
            if (group != null) group += index else groups += mutableListOf(index)
        }
        val out = fills.toMutableList()
        for (group in groups) {
            if (group.size < 2) continue
            val best = group.maxBy { sat(fills[it]!!) }
            val pick = fills[best]!!
            for (i in group) out[i] = pick
        }
        return out
    }

    private fun hue(c: Int): Float {
        val r = ((c shr 16) and 255) / 255f
        val g = ((c shr 8) and 255) / 255f
        val bl = (c and 255) / 255f
        val mx = max(r, max(g, bl))
        val mn = min(r, min(g, bl))
        val d = (mx - mn).coerceAtLeast(1e-4f)
        val h = when (mx) {
            r -> ((g - bl) / d) % 6f
            g -> (bl - r) / d + 2f
            else -> (r - g) / d + 4f
        } * 60f
        return if (h < 0) h + 360f else h
    }

    private fun hueDiff(a: Int, b: Int): Float {
        val diff = kotlin.math.abs(hue(a) - hue(b))
        return min(diff, 360f - diff)
    }

    private fun hueClose(a: Int, b: Int): Boolean {
        // Grises con grises; colores con colores de matiz parecido.
        if (sat(a) < 25 || sat(b) < 25) return sat(a) < 25 && sat(b) < 25
        return hueDiff(a, b) < 9f
    }
}
