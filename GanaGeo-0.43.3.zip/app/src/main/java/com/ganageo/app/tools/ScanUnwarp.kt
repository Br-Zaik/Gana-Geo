package com.ganageo.app.tools

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Aplanar hojas dobladas con la IA UVDoc (PaddleOCR, Apache 2.0): lo que no depende
 * del celular. La IA da una malla (dónde buscar cada punto en la foto) o la hoja ya
 * aplanada; aquí se arma la imagen final. Todo local.
 */
object ScanUnwarp {
    /** Entrada: [3, alto, ancho] azul-verde-rojo, 0..1 (como la entrenó PaddleOCR). */
    fun input(pixels: IntArray, width: Int, height: Int): FloatArray {
        val plane = width * height
        val out = FloatArray(3 * plane)
        for (i in 0 until plane) {
            val c = pixels[i]
            out[i] = (c and 255) / 255f
            out[plane + i] = ((c shr 8) and 255) / 255f
            out[2 * plane + i] = ((c shr 16) and 255) / 255f
        }
        return out
    }

    /** Salida imagen [3, alto, ancho] azul-verde-rojo (0..1 o 0..255) → píxeles. */
    fun image(data: FloatArray, width: Int, height: Int): IntArray {
        val plane = width * height
        var top = 0f
        for (i in 0 until min(data.size, 3 * plane)) top = max(top, data[i])
        val k = if (top > 2f) 1f else 255f
        return IntArray(plane) { i ->
            val b = (data[i] * k).roundToInt().coerceIn(0, 255)
            val g = (data[plane + i] * k).roundToInt().coerceIn(0, 255)
            val r = (data[2 * plane + i] * k).roundToInt().coerceIn(0, 255)
            (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
    }

    /**
     * Malla [2, gh, gw] (canal 0 = x, 1 = y, de -1 a 1) → la hoja aplanada del tamaño de
     * la foto: cada punto toma el color de donde dice la malla (como grid_sample con
     * esquinas alineadas).
     */
    fun sampleGrid(src: IntArray, width: Int, height: Int, grid: FloatArray, gw: Int, gh: Int): IntArray {
        val out = IntArray(width * height)
        val plane = gw * gh
        for (y in 0 until height) {
            val fy = if (height > 1) y * (gh - 1) / (height - 1).toFloat() else 0f
            val y0 = fy.toInt().coerceIn(0, gh - 1)
            val y1 = min(gh - 1, y0 + 1)
            val ty = fy - y0
            for (x in 0 until width) {
                val fx = if (width > 1) x * (gw - 1) / (width - 1).toFloat() else 0f
                val x0 = fx.toInt().coerceIn(0, gw - 1)
                val x1 = min(gw - 1, x0 + 1)
                val tx = fx - x0
                fun at(channel: Int): Float {
                    val base = channel * plane
                    val a = grid[base + y0 * gw + x0] * (1 - tx) + grid[base + y0 * gw + x1] * tx
                    val b = grid[base + y1 * gw + x0] * (1 - tx) + grid[base + y1 * gw + x1] * tx
                    return a * (1 - ty) + b * ty
                }
                val sx = (at(0) + 1f) / 2f * (width - 1)
                val sy = (at(1) + 1f) / 2f * (height - 1)
                out[y * width + x] = bilinear(src, width, height, sx, sy)
            }
        }
        return out
    }

    private fun bilinear(src: IntArray, width: Int, height: Int, x: Float, y: Float): Int {
        // Fuera de la foto: papel blanco.
        if (x < -1f || y < -1f || x > width || y > height) return -1
        val cx = x.coerceIn(0f, (width - 1).toFloat())
        val cy = y.coerceIn(0f, (height - 1).toFloat())
        val x0 = cx.toInt()
        val y0 = cy.toInt()
        val x1 = min(width - 1, x0 + 1)
        val y1 = min(height - 1, y0 + 1)
        val tx = cx - x0
        val ty = cy - y0
        val a = src[y0 * width + x0]
        val b = src[y0 * width + x1]
        val c = src[y1 * width + x0]
        val d = src[y1 * width + x1]
        var out = 0xFF shl 24
        for (shift in intArrayOf(0, 8, 16)) {
            val top = ((a shr shift) and 255) * (1 - tx) + ((b shr shift) and 255) * tx
            val bottom = ((c shr shift) and 255) * (1 - tx) + ((d shr shift) and 255) * tx
            out = out or ((top * (1 - ty) + bottom * ty).roundToInt().coerceIn(0, 255) shl shift)
        }
        return out
    }

    /**
     * ¿Se acepta lo aplanado? Solo si las rayas quedaron claramente más derechas
     * ([before] y [after] de ScanPhoto.bend) y el papel no se llenó de blanco nuevo.
     */
    fun better(before: Float, after: Float, blankBefore: Float, blankAfter: Float): Boolean =
        before >= 1.2f && after <= before * 0.7f && blankAfter <= blankBefore + 0.04f
}
