package com.ganageo.app.ui.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.CropFree
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ganageo.app.tools.ScanFilters
import com.ganageo.app.tools.ScanPhoto
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------
// Fotos de galería, archivos o cámara simple:
// 1. Recortar: esquinas halladas solas, que se pueden mover (con lupa), girar o "Todo".
// 2. Animación: la hoja se endereza y una línea la va limpiando.
// 3. Filtros con miniaturas de la propia hoja, "Comparar" y "Listo".
// ---------------------------------------------------------------------------

private val CropBackground = Color(0xFF070D0A)
private val CropBar = Color(0xFF101D16)
private val CropInk = Color(0xFFE6EFE9)
private val CropMuted = Color(0xFF8FA398)

/** Lado mayor de la foto en la pantalla de recorte (rápido y nítido en el celular). */
private const val CROP_PREVIEW_EDGE = 1400

/** Lado mayor de la hoja que se ve en Filtros. */
private const val FILTER_PREVIEW_EDGE = 1300

/** Ancho de las miniaturas de los filtros. */
private const val FILTER_THUMB_WIDTH = 120

private val FULL_QUAD = floatArrayOf(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f)

/** Foto lista para recortar: copia mediana (sin girar) y lo que se halló en ella. */
internal class DocScanCropItem(val source: Uri, val preview: Bitmap, val found: ScanPhoto.Found, val autoQuad: FloatArray?)

/** Cómo quedó el recorte de una foto: esquinas (0..1, ya giradas), giros y si la persona las movió. */
internal data class DocScanCropEdit(val quad: FloatArray, val quarters: Int, val touched: Boolean)

/** Hoja ya derecha: sin emparejar la luz ([plain]) y con la luz pareja ([even]). */
internal class DocScanFlat(val plain: java.io.File, val even: java.io.File, val clean: Boolean)

private enum class CropStage { LOADING, CROP, PROCESS, FILTER, SAVING }

private fun cropAuto(item: DocScanCropItem): DocScanCropEdit =
    DocScanCropEdit((item.autoQuad ?: FULL_QUAD).copyOf(), 0, false)

/** Gira las esquinas un cuarto de vuelta (derecha o izquierda) y las vuelve a ordenar. */
private fun cropRotateQuad(quad: FloatArray, right: Boolean): FloatArray {
    val mapped = FloatArray(8)
    for (i in 0 until 4) {
        val u = quad[i * 2]
        val v = quad[i * 2 + 1]
        mapped[i * 2] = if (right) 1f - v else v
        mapped[i * 2 + 1] = if (right) u else 1f - u
    }
    val out = FloatArray(8)
    for (i in 0 until 4) {
        val from = if (right) (i + 3) % 4 else (i + 1) % 4
        out[i * 2] = mapped[from * 2]
        out[i * 2 + 1] = mapped[from * 2 + 1]
    }
    return out
}

private fun cropClamp(quad: FloatArray) = FloatArray(8) { quad[it].coerceIn(0f, 1f) }

private fun cropIsFull(quad: FloatArray) = (0 until 8).all { abs(quad[it] - FULL_QUAD[it]) < 0.004f }

/** Las 4 esquinas forman una hoja de verdad (sin cruzarse y no muy chica). */
internal fun docScanQuadOk(q: FloatArray): Boolean {
    var sign = 0
    for (i in 0 until 4) {
        val ax = q[i * 2]; val ay = q[i * 2 + 1]
        val bx = q[(i + 1) % 4 * 2]; val by = q[(i + 1) % 4 * 2 + 1]
        val cx = q[(i + 2) % 4 * 2]; val cy = q[(i + 2) % 4 * 2 + 1]
        val cross = (bx - ax) * (cy - by) - (by - ay) * (cx - bx)
        val s = if (cross > 0f) 1 else if (cross < 0f) -1 else 0
        if (s == 0) return false
        if (sign == 0) sign = s else if (s != sign) return false
    }
    var area = 0f
    for (i in 0 until 4) {
        val j = (i + 1) % 4
        area += q[i * 2] * q[j * 2 + 1] - q[j * 2] * q[i * 2 + 1]
    }
    return abs(area) / 2f > 0.04f
}

private fun cropRotateBitmap(source: Bitmap, quarters: Int): Bitmap {
    val q = ((quarters % 4) + 4) % 4
    if (q == 0) return source
    val matrix = android.graphics.Matrix()
    matrix.postRotate(90f * q)
    return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
}

private suspend fun cropLoad(context: Context, uri: Uri): DocScanCropItem? = withContext(Dispatchers.Default) {
    try {
        val bitmap = ToolFileUtils.loadBitmap(context, uri, CROP_PREVIEW_EDGE)
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        val found = ScanPhoto.detect(pixels, w, h)
        val auto = found.quad?.let { quad -> FloatArray(8) { quad.points[it] / if (it % 2 == 0) w else h } }
        DocScanCropItem(uri, bitmap, found, auto)
    } catch (cancelled: kotlinx.coroutines.CancellationException) {
        throw cancelled
    } catch (error: Throwable) {
        null
    }
}

/** Endereza una foto con su recorte y guarda las dos versiones (sin y con luz pareja). */
private suspend fun cropProcess(
    context: Context, item: DocScanCropItem, edit: DocScanCropEdit, index: Int, stamp: Long
): DocScanFlat = withContext(Dispatchers.Default) {
    val bitmap = ToolFileUtils.loadBitmap(context, item.source, DOC_SCAN_PHOTO_EDGE)
    var w = bitmap.width
    var h = bitmap.height
    var pixels = IntArray(w * h)
    bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
    bitmap.recycle()
    if (edit.quarters % 4 != 0) {
        val turned = ScanFilters.rotate(pixels, w, h, edit.quarters)
        pixels = turned.first
        w = turned.second
        h = turned.third
    }
    kotlinx.coroutines.yield()
    val untouchedClean = item.found.clean && (!edit.touched || cropIsFull(edit.quad))
    val result = when {
        untouchedClean -> ScanPhoto.Result(pixels, w, h, null, "ya limpia", pixels)
        !edit.touched && item.autoQuad == null ->
            ScanPhoto.flattenWith(pixels, w, h, null, "sin cambio", DOC_SCAN_PAGE_EDGE, light = true, keepPlain = true)
        else -> {
            val quad = ScanPhoto.Quad(FloatArray(8) { edit.quad[it] * if (it % 2 == 0) w else h }, "recorte")
            val method = if (edit.touched) "manual" else item.found.method
            ScanPhoto.flattenWith(pixels, w, h, quad, method, DOC_SCAN_PAGE_EDGE, light = true, keepPlain = true)
        }
    }
    kotlinx.coroutines.yield()
    // Hoja muy grande (foto limpia sin recortar): al tamaño de las páginas.
    var outW = result.width
    var outH = result.height
    var even = result.pixels
    var plain = result.plain ?: result.pixels
    // Hoja que sigue doblada: la IA la aplana (solo se queda si quedó más derecha).
    if (!untouchedClean && !item.found.clean) {
        val flat = runCatching { cropUnwarp(context, plain, outW, outH) }.getOrElse {
            if (it is kotlinx.coroutines.CancellationException) throw it
            null
        }
        if (flat != null) {
            plain = flat.first
            even = flat.second
            outW = flat.third
            outH = plain.size / outW
        }
    }
    val directory = java.io.File(context.cacheDir, "camera").apply { mkdirs() }
    fun save(data: IntArray, name: String): java.io.File {
        var sheet = Bitmap.createBitmap(data, outW, outH, Bitmap.Config.ARGB_8888)
        val edge = max(outW, outH)
        if (edge > DOC_SCAN_PAGE_EDGE) {
            val s = DOC_SCAN_PAGE_EDGE / edge.toFloat()
            val scaled = Bitmap.createScaledBitmap(sheet, (outW * s).roundToInt().coerceAtLeast(1), (outH * s).roundToInt().coerceAtLeast(1), true)
            sheet.recycle()
            sheet = scaled
        }
        val file = java.io.File(directory, "docscan_${stamp}_${index + 1}_$name.jpg")
        try {
            file.outputStream().use { sheet.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        } finally {
            sheet.recycle()
        }
        return file
    }
    val plainFile = save(plain, "plain")
    val evenFile = if (plain === even) plainFile else save(even, "even")
    DocScanFlat(plainFile, evenFile, item.found.clean)
}

/** Parte de la hoja casi blanca (para ver si al aplanar se llenó de papel nuevo). */
private fun cropBlank(pixels: IntArray): Float {
    var n = 0
    var i = 0
    var total = 0
    while (i < pixels.size) {
        val c = pixels[i]
        if (((c shr 16) and 255) >= 250 && ((c shr 8) and 255) >= 250 && (c and 255) >= 250) n++
        total++
        i += 5
    }
    return n / total.coerceAtLeast(1).toFloat()
}

/**
 * Aplana con la IA una hoja que sigue doblada. Devuelve (sin luz, con luz pareja, ancho)
 * o null si no hacía falta, no hay IA o no quedó mejor.
 */
private fun cropUnwarp(context: Context, plain: IntArray, width: Int, height: Int): Triple<IntArray, IntArray, Int>? {
    val before = ScanPhoto.bend(plain, width, height)
    if (before < 1.2f) return null
    var w = width
    var h = height
    var source = plain
    val edge = max(width, height)
    if (edge > DocScanUnwarpAi.EDGE) {
        val s = DocScanUnwarpAi.EDGE / edge.toFloat()
        w = (width * s).roundToInt().coerceAtLeast(8)
        h = (height * s).roundToInt().coerceAtLeast(8)
        val big = Bitmap.createBitmap(plain, width, height, Bitmap.Config.ARGB_8888)
        val small = Bitmap.createScaledBitmap(big, w, h, true)
        big.recycle()
        source = IntArray(w * h)
        small.getPixels(source, 0, w, 0, 0, w, h)
        small.recycle()
    }
    val flat = DocScanUnwarpAi.flatten(context, source, w, h) ?: return null
    val after = ScanPhoto.bend(flat, w, h)
    if (!com.ganageo.app.tools.ScanUnwarp.better(ScanPhoto.bend(source, w, h), after, cropBlank(source), cropBlank(flat))) return null
    val even = flat.copyOf()
    ScanPhoto.evenLight(even, w, h)
    ScanPhoto.clearOutside(even, w, h, minLum = 205, maxSat = 45)
    for (i in even.indices) if ((even[i] ushr 24) == 0) even[i] = -1
    return Triple(flat, even, w)
}

/** Píxeles de una hoja guardada, con el lado mayor ≤ [edge] (null = tamaño real). */
private fun cropDecode(file: java.io.File, edge: Int?): Triple<IntArray, Int, Int>? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    if (edge != null) while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= edge) sample *= 2
    val options = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    var bitmap = BitmapFactory.decodeFile(file.path, options) ?: return null
    if (edge != null && max(bitmap.width, bitmap.height) > edge) {
        val s = edge / max(bitmap.width, bitmap.height).toFloat()
        val scaled = Bitmap.createScaledBitmap(bitmap, (bitmap.width * s).roundToInt().coerceAtLeast(1), (bitmap.height * s).roundToInt().coerceAtLeast(1), true)
        bitmap.recycle()
        bitmap = scaled
    }
    val w = bitmap.width
    val h = bitmap.height
    val pixels = IntArray(w * h)
    bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
    bitmap.recycle()
    return Triple(pixels, w, h)
}

/** Lo que se ve en Filtros de una hoja: sus dos versiones medianas y las miniaturas. */
private class FilterView(val plain: IntArray, val even: IntArray, val width: Int, val height: Int, val thumbs: List<ImageBitmap>)

private fun cropFilterView(flat: DocScanFlat): FilterView? {
    val plain = cropDecode(flat.plain, FILTER_PREVIEW_EDGE) ?: return null
    val even = if (flat.even == flat.plain) plain else cropDecode(flat.even, FILTER_PREVIEW_EDGE) ?: return null
    val w = min(plain.second, even.second)
    val h = min(plain.third, even.third)
    if (plain.second != even.second || plain.third != even.third) return null
    // Miniaturas: la misma hoja chiquita con cada filtro.
    val tw = FILTER_THUMB_WIDTH
    val th = (h * tw / w.toFloat()).roundToInt().coerceAtLeast(1)
    fun small(data: IntArray): IntArray {
        val big = Bitmap.createBitmap(data, w, h, Bitmap.Config.ARGB_8888)
        val tiny = Bitmap.createScaledBitmap(big, tw, th, true)
        big.recycle()
        val out = IntArray(tw * th)
        tiny.getPixels(out, 0, tw, 0, 0, tw, th)
        tiny.recycle()
        return out
    }
    val sp = small(plain.first)
    val se = if (even === plain) sp else small(even.first)
    val thumbs = ScanFilters.ALL.map { kind ->
        Bitmap.createBitmap(ScanFilters.apply(kind, sp, se, tw, th), tw, th, Bitmap.Config.ARGB_8888).asImageBitmap()
    }
    return FilterView(plain.first, even.first, w, h, thumbs)
}

private fun cropFiltered(view: FilterView, kind: Int): Bitmap =
    Bitmap.createBitmap(ScanFilters.apply(kind, view.plain, view.even, view.width, view.height), view.width, view.height, Bitmap.Config.ARGB_8888)

/** Hoja final con su filtro (tamaño real). */
private suspend fun cropFinish(context: Context, flat: DocScanFlat, kind: Int, index: Int, stamp: Long): Uri? = withContext(Dispatchers.Default) {
    val directory = java.io.File(context.cacheDir, "camera").apply { mkdirs() }
    val target = java.io.File(directory, "docscan_${stamp}_${index + 1}_hoja.jpg")
    if (kind == ScanFilters.ORIGINAL) {
        flat.plain.copyTo(target, overwrite = true)
    } else {
        val plain = cropDecode(flat.plain, null) ?: return@withContext null
        val even = if (flat.even == flat.plain) plain else cropDecode(flat.even, null) ?: return@withContext null
        if (plain.second != even.second || plain.third != even.third) return@withContext null
        kotlinx.coroutines.yield()
        val out = ScanFilters.apply(kind, plain.first, even.first, plain.second, plain.third)
        val sheet = Bitmap.createBitmap(out, plain.second, plain.third, Bitmap.Config.ARGB_8888)
        try {
            target.outputStream().use { sheet.compress(Bitmap.CompressFormat.JPEG, 94, it) }
        } finally {
            sheet.recycle()
        }
    }
    androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", target)
}

/** Dónde cabe una imagen de [w]×[h] dentro de [boxW]×[boxH] (centrada). */
private fun cropFit(w: Float, h: Float, boxW: Float, boxH: Float): android.graphics.RectF {
    val s = min(boxW / w, boxH / h)
    val dw = w * s
    val dh = h * s
    val left = (boxW - dw) / 2f
    val top = (boxH - dh) / 2f
    return android.graphics.RectF(left, top, left + dw, top + dh)
}

@Composable
internal fun DocScanCropFlow(
    sources: List<Uri>,
    animate: Boolean,
    onCancel: () -> Unit,
    onDone: (List<Pair<Uri, Uri?>>) -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val stamp = remember { System.currentTimeMillis() }
    var stage by remember { mutableStateOf(CropStage.LOADING) }
    val items = remember { mutableStateListOf<DocScanCropItem>() }
    val edits = remember { mutableStateListOf<DocScanCropEdit>() }
    val flats = remember { mutableStateListOf<DocScanFlat?>() }
    val filters = remember { mutableStateListOf<Int>() }
    var page by remember { mutableIntStateOf(0) }
    // Se volvió a Recortar desde Filtros: al terminar se regresa a Filtros.
    var backToFilters by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val loaded = ArrayList<DocScanCropItem>()
        for (uri in sources) cropLoad(context, uri)?.let { loaded += it }
        if (loaded.isEmpty()) {
            onMessage("No se pudieron abrir esas fotos.")
            onCancel()
            return@LaunchedEffect
        }
        if (loaded.size < sources.size) onMessage("Algunas fotos no se pudieron abrir.")
        items.addAll(loaded)
        loaded.forEach { item ->
            edits += cropAuto(item)
            flats += null
            filters += if (item.found.clean) ScanFilters.ORIGINAL else ScanFilters.MEJORAR
        }
        stage = CropStage.CROP
    }

    BackHandler {
        when (stage) {
            CropStage.CROP -> if (backToFilters) { stage = CropStage.FILTER } else if (page > 0) page-- else onCancel()
            CropStage.FILTER -> { backToFilters = true; stage = CropStage.CROP }
            else -> onCancel()
        }
    }

    Box(Modifier.fillMaxSize().background(CropBackground)) {
        when (stage) {
            CropStage.LOADING -> CropWaiting("Buscando la hoja…")
            CropStage.CROP -> if (page < items.size) {
                val item = items[page]
                val edit = edits[page]
                CropScreen(
                    item = item,
                    edit = edit,
                    pageLabel = if (items.size > 1) "${page + 1} de ${items.size}" else null,
                    last = backToFilters || page == items.size - 1,
                    onBack = {
                        if (backToFilters) stage = CropStage.FILTER
                        else if (page > 0) page-- else onCancel()
                    },
                    onChange = { changed ->
                        if (changed != edits[page]) {
                            edits[page] = changed
                            flats[page] = null
                        }
                    },
                    onNext = {
                        val now = edits[page]
                        if (now.touched && !docScanQuadOk(now.quad)) {
                            onMessage("Las esquinas están cruzadas o muy juntas. Muévelas a las puntas de la hoja.")
                        } else if (backToFilters || page == items.size - 1) {
                            stage = CropStage.PROCESS
                        } else {
                            page++
                        }
                    }
                )
            }
            CropStage.PROCESS -> CropProcessing(
                items = items,
                edits = edits,
                flats = flats,
                filters = filters,
                animate = animate,
                stamp = stamp,
                onFailed = {
                    onMessage("No se pudo enderezar una foto. Intenta otra vez.")
                    onCancel()
                },
                onFinished = {
                    backToFilters = false
                    page = page.coerceIn(0, items.size - 1)
                    stage = CropStage.FILTER
                }
            )
            CropStage.FILTER -> CropFilters(
                flats = flats,
                filters = filters,
                page = page,
                animate = animate,
                onPage = { page = it },
                onRecrop = {
                    backToFilters = true
                    stage = CropStage.CROP
                },
                onBack = {
                    backToFilters = true
                    stage = CropStage.CROP
                },
                onDone = { stage = CropStage.SAVING }
            )
            CropStage.SAVING -> {
                CropWaiting(if (items.size > 1) "Guardando las hojas…" else "Guardando la hoja…")
                LaunchedEffect(Unit) {
                    val out = ArrayList<Pair<Uri, Uri?>>()
                    for (i in items.indices) {
                        val flat = flats[i]
                        val made = if (flat == null) null else runCatching { cropFinish(context, flat, filters[i], i, stamp) }.getOrNull()
                        out += if (made != null) made to items[i].source else items[i].source to null
                    }
                    onDone(out)
                }
            }
        }
    }
}

@Composable
private fun CropWaiting(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = NeonGreen)
            Spacer(Modifier.height(12.dp))
            Text(text, color = CropInk)
        }
    }
}

@Composable
private fun CropTopBar(title: String, pageLabel: String?, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CropBar)
            .statusBarsPadding()
            .height(56.dp)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "Atrás", tint = CropInk)
        }
        Text(title, color = CropInk, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        if (pageLabel != null) {
            Spacer(Modifier.width(10.dp))
            Text(pageLabel, color = CropMuted, fontSize = 14.sp)
        }
        Spacer(Modifier.weight(1f))
        trailing()
    }
}

@Composable
private fun CropAction(icon: ImageVector, label: String, tint: Color = CropInk, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, color = tint, fontSize = 12.sp)
    }
}

@Composable
private fun CropDone(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(NeonGreen)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Check, contentDescription = null, tint = Color(0xFF06140C), modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color(0xFF06140C), fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** Arrastre en curso: qué agarradera (0-3 esquinas, 4-7 lados) y dónde está el dedo. */
private class CropDrag {
    var handle = -1
    var finger = android.graphics.PointF()
    var fit = android.graphics.RectF()
    /** Esquinas mientras se arrastra (no se pierde ningún movimiento entre cuadros). */
    var quad = FULL_QUAD.copyOf()
}

@Composable
private fun CropScreen(
    item: DocScanCropItem,
    edit: DocScanCropEdit,
    pageLabel: String?,
    last: Boolean,
    onBack: () -> Unit,
    onChange: (DocScanCropEdit) -> Unit,
    onNext: () -> Unit
) {
    val density = LocalDensity.current
    val shown = remember(item, edit.quarters) { cropRotateBitmap(item.preview, edit.quarters) }
    val currentEdit by rememberUpdatedState(edit)
    val currentChange by rememberUpdatedState(onChange)
    val drag = remember { CropDrag() }
    var dragging by remember { mutableIntStateOf(-1) }
    var fingerTick by remember { mutableIntStateOf(0) }
    val paint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG) }
    val path = remember { android.graphics.Path() }
    val matrix = remember { android.graphics.Matrix() }
    val handleR = with(density) { 11.dp.toPx() }
    val hitR = with(density) { 40.dp.toPx() }
    val line = with(density) { 2.dp.toPx() }
    val loupeR = with(density) { 58.dp.toPx() }
    val pad = with(density) { 22.dp.toPx() }
    val green = android.graphics.Color.rgb(0x39, 0xFF, 0x88)

    Column(Modifier.fillMaxSize()) {
        CropTopBar("Recortar", pageLabel, onBack)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .pointerInput(item) {
                    detectDragGestures(
                        onDragStart = { start ->
                            val fit = drag.fit
                            val shownQuad = cropClamp(currentEdit.quad)
                            var best = -1
                            var bestDistance = hitR
                            for (i in 0 until 8) {
                                val (hx, hy) = if (i < 4) {
                                    fit.left + shownQuad[i * 2] * fit.width() to fit.top + shownQuad[i * 2 + 1] * fit.height()
                                } else {
                                    val a = i - 4
                                    val b = (a + 1) % 4
                                    fit.left + (shownQuad[a * 2] + shownQuad[b * 2]) / 2f * fit.width() to
                                        fit.top + (shownQuad[a * 2 + 1] + shownQuad[b * 2 + 1]) / 2f * fit.height()
                                }
                                // Las esquinas ganan si están casi igual de cerca.
                                val d = hypot(start.x - hx, start.y - hy) + if (i < 4) 0f else 8f
                                if (d < bestDistance) { bestDistance = d; best = i }
                            }
                            drag.handle = best
                            drag.finger.set(start.x, start.y)
                            drag.quad = shownQuad
                            dragging = best
                        },
                        onDragEnd = { drag.handle = -1; dragging = -1 },
                        onDragCancel = { drag.handle = -1; dragging = -1 },
                        onDrag = { change, delta ->
                            val handle = drag.handle
                            if (handle < 0) return@detectDragGestures
                            change.consume()
                            drag.finger.set(change.position.x, change.position.y)
                            val fit = drag.fit
                            if (fit.width() <= 0f || fit.height() <= 0f) return@detectDragGestures
                            val du = delta.x / fit.width()
                            val dv = delta.y / fit.height()
                            val q = drag.quad
                            val moved = if (handle < 4) listOf(handle) else listOf(handle - 4, (handle - 3) % 4)
                            for (corner in moved) {
                                q[corner * 2] = (q[corner * 2] + du).coerceIn(0f, 1f)
                                q[corner * 2 + 1] = (q[corner * 2 + 1] + dv).coerceIn(0f, 1f)
                            }
                            currentChange(currentEdit.copy(quad = q.copyOf(), touched = true))
                            fingerTick++
                        }
                    )
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                fingerTick
                val fit = cropFit(shown.width.toFloat(), shown.height.toFloat(), size.width - pad * 2, size.height - pad * 2)
                fit.offset(pad, pad)
                drag.fit = fit
                val q = cropClamp(edit.quad)
                val px = FloatArray(4) { fit.left + q[it * 2] * fit.width() }
                val py = FloatArray(4) { fit.top + q[it * 2 + 1] * fit.height() }
                drawIntoCanvas { canvas ->
                    val native = canvas.nativeCanvas
                    paint.reset()
                    paint.isAntiAlias = true
                    paint.isFilterBitmap = true
                    native.drawBitmap(shown, null, fit, paint)
                    // Fuera de la hoja: más oscuro.
                    path.reset()
                    path.fillType = android.graphics.Path.FillType.EVEN_ODD
                    path.addRect(fit, android.graphics.Path.Direction.CW)
                    path.moveTo(px[0], py[0])
                    for (i in 1 until 4) path.lineTo(px[i], py[i])
                    path.close()
                    paint.style = android.graphics.Paint.Style.FILL
                    paint.color = android.graphics.Color.argb(140, 0, 0, 0)
                    native.drawPath(path, paint)
                    // Borde de la hoja.
                    path.reset()
                    path.moveTo(px[0], py[0])
                    for (i in 1 until 4) path.lineTo(px[i], py[i])
                    path.close()
                    paint.style = android.graphics.Paint.Style.STROKE
                    paint.strokeWidth = line
                    paint.color = green
                    native.drawPath(path, paint)
                    // Agarraderas: puntos en las esquinas, rayitas en el medio de cada lado.
                    for (i in 0 until 4) {
                        val j = (i + 1) % 4
                        val mx = (px[i] + px[j]) / 2f
                        val my = (py[i] + py[j]) / 2f
                        val angle = Math.toDegrees(kotlin.math.atan2((py[j] - py[i]).toDouble(), (px[j] - px[i]).toDouble())).toFloat()
                        native.save()
                        native.rotate(angle, mx, my)
                        paint.style = android.graphics.Paint.Style.FILL
                        paint.color = if (dragging == i + 4) green else android.graphics.Color.WHITE
                        native.drawRoundRect(mx - handleR * 1.3f, my - handleR * 0.38f, mx + handleR * 1.3f, my + handleR * 0.38f, handleR, handleR, paint)
                        native.restore()
                    }
                    for (i in 0 until 4) {
                        paint.style = android.graphics.Paint.Style.FILL
                        paint.color = if (dragging == i) green else android.graphics.Color.WHITE
                        native.drawCircle(px[i], py[i], handleR, paint)
                        paint.style = android.graphics.Paint.Style.STROKE
                        paint.strokeWidth = line
                        paint.color = green
                        native.drawCircle(px[i], py[i], handleR, paint)
                    }
                    // Lupa: al mover una esquina, se ve aumentada para ponerla justo en la punta.
                    if (dragging in 0..3) {
                        val cx0 = px[dragging]
                        val cy0 = py[dragging]
                        val leftSide = cx0 < size.width / 2f
                        val lx = if (leftSide) size.width - loupeR - pad else loupeR + pad
                        val ly = loupeR + pad
                        native.save()
                        path.reset()
                        path.addCircle(lx, ly, loupeR, android.graphics.Path.Direction.CW)
                        native.clipPath(path)
                        native.drawColor(android.graphics.Color.BLACK)
                        val zoom = 2.6f
                        val s = fit.width() / shown.width
                        matrix.reset()
                        matrix.postScale(s * zoom, s * zoom)
                        matrix.postTranslate(lx - (cx0 - fit.left) * zoom, ly - (cy0 - fit.top) * zoom)
                        paint.style = android.graphics.Paint.Style.FILL
                        native.drawBitmap(shown, matrix, paint)
                        // Las dos rayas de la hoja que llegan a esa esquina, también aumentadas.
                        paint.style = android.graphics.Paint.Style.STROKE
                        paint.strokeWidth = line
                        paint.color = green
                        for (other in intArrayOf((dragging + 1) % 4, (dragging + 3) % 4)) {
                            native.drawLine(lx, ly, lx + (px[other] - cx0) * zoom, ly + (py[other] - cy0) * zoom, paint)
                        }
                        native.restore()
                        paint.color = android.graphics.Color.WHITE
                        paint.strokeWidth = line * 1.5f
                        native.drawCircle(lx, ly, loupeR, paint)
                        paint.strokeWidth = line
                        native.drawLine(lx - 10f, ly, lx + 10f, ly, paint)
                        native.drawLine(lx, ly - 10f, lx, ly + 10f, paint)
                    }
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CropBar)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CropAction(Icons.Rounded.RotateRight, "Girar") {
                onChange(edit.copy(quad = cropRotateQuad(edit.quad, right = true), quarters = (edit.quarters + 1) % 4))
            }
            val full = cropIsFull(cropClamp(edit.quad))
            if (full && item.autoQuad != null) {
                CropAction(Icons.Rounded.Crop, "Auto") {
                    var auto = item.autoQuad.copyOf()
                    repeat(edit.quarters) { auto = cropRotateQuad(auto, right = true) }
                    onChange(edit.copy(quad = auto, touched = false))
                }
            } else {
                CropAction(Icons.Rounded.CropFree, "Todo") {
                    onChange(edit.copy(quad = FULL_QUAD.copyOf(), touched = true))
                }
            }
            CropDone(if (last) "Listo" else "Siguiente", onNext)
        }
    }
}

/**
 * Endereza y limpia las fotos pendientes. Con animaciones: la hoja se endereza
 * ("Recortando imagen") y luego una línea baja limpiándola ("Mejorando imagen").
 * La animación corre mientras se trabaja: no agrega espera.
 */
@Composable
private fun CropProcessing(
    items: List<DocScanCropItem>,
    edits: List<DocScanCropEdit>,
    flats: MutableList<DocScanFlat?>,
    filters: List<Int>,
    animate: Boolean,
    stamp: Long,
    onFailed: () -> Unit,
    onFinished: () -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val pending = remember { items.indices.filter { flats[it] == null } }
    var current by remember { mutableIntStateOf(pending.firstOrNull() ?: 0) }
    var step by remember { mutableIntStateOf(0) }
    var phase by remember { mutableIntStateOf(0) }
    var before by remember { mutableStateOf<Bitmap?>(null) }
    var after by remember { mutableStateOf<Bitmap?>(null) }
    val morph = remember { Animatable(0f) }
    val sweep = remember { Animatable(0f) }
    val paint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG) }
    val path = remember { android.graphics.Path() }
    val matrix = remember { android.graphics.Matrix() }
    val pad = with(density) { 28.dp.toPx() }
    val line = with(density) { 2.5.dp.toPx() }
    val glow = with(density) { 36.dp.toPx() }
    val green = android.graphics.Color.rgb(0x39, 0xFF, 0x88)

    LaunchedEffect(Unit) {
        try {
            for ((n, i) in pending.withIndex()) {
                current = i
                step = n
                phase = 0
                before = null
                after = null
                morph.snapTo(0f)
                sweep.snapTo(0f)
                val work = async(Dispatchers.Default) { cropProcess(context, items[i], edits[i], i, stamp) }
                if (animate) morph.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
                val flat = work.await()
                flats[i] = flat
                if (animate) {
                    val pair = withContext(Dispatchers.Default) {
                        val plain = cropDecode(flat.plain, 900)
                        val even = if (flat.even == flat.plain) plain else cropDecode(flat.even, 900)
                        if (plain == null || even == null || plain.second != even.second || plain.third != even.third) null
                        else Bitmap.createBitmap(plain.first, plain.second, plain.third, Bitmap.Config.ARGB_8888) to
                            Bitmap.createBitmap(ScanFilters.apply(filters[i], plain.first, even.first, plain.second, plain.third), plain.second, plain.third, Bitmap.Config.ARGB_8888)
                    }
                    if (pair != null) {
                        before = pair.first
                        after = pair.second
                        phase = 1
                        sweep.animateTo(1f, tween(800, easing = LinearEasing))
                    }
                }
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            onFailed()
            return@LaunchedEffect
        }
        onFinished()
    }

    val item = items[current]
    val edit = edits[current]
    val shown = remember(item, edit.quarters) { cropRotateBitmap(item.preview, edit.quarters) }
    val total = pending.size.coerceAtLeast(1)
    val label = if (phase == 0) "Recortando imagen" else "Mejorando imagen"

    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(CropBar)
                .statusBarsPadding()
                .height(56.dp)
        )
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            if (!animate) {
                CropWaiting(if (total > 1) "Enderezando y limpiando… ${step + 1} de $total" else "Enderezando y limpiando la hoja…")
            } else {
                Canvas(Modifier.fillMaxSize()) {
                    val boxW = size.width - pad * 2
                    val boxH = size.height - pad * 2
                    drawIntoCanvas { canvas ->
                        val native = canvas.nativeCanvas
                        paint.reset()
                        paint.isAntiAlias = true
                        paint.isFilterBitmap = true
                        val b0 = before
                        val a0 = after
                        if (phase == 1 && b0 != null && a0 != null) {
                            // Línea que baja: arriba ya limpia, abajo todavía la foto (más oscura).
                            val fit = cropFit(a0.width.toFloat(), a0.height.toFloat(), boxW, boxH)
                            fit.offset(pad, pad)
                            val y = fit.top + fit.height() * sweep.value
                            native.drawBitmap(b0, null, fit, paint)
                            paint.color = android.graphics.Color.argb(110, 0, 0, 0)
                            native.drawRect(fit.left, y, fit.right, fit.bottom, paint)
                            native.save()
                            native.clipRect(fit.left, fit.top, fit.right, y)
                            native.drawBitmap(a0, null, fit, paint)
                            native.restore()
                            paint.shader = android.graphics.LinearGradient(
                                0f, y - glow, 0f, y,
                                android.graphics.Color.argb(0, 0x39, 0xFF, 0x88), android.graphics.Color.argb(90, 0x39, 0xFF, 0x88),
                                android.graphics.Shader.TileMode.CLAMP
                            )
                            native.drawRect(fit.left, (y - glow).coerceAtLeast(fit.top), fit.right, y, paint)
                            paint.shader = null
                            paint.color = green
                            native.drawRect(fit.left, y - line / 2f, fit.right, y + line / 2f, paint)
                        } else {
                            // La hoja se levanta de la foto y queda derecha.
                            val fit = cropFit(shown.width.toFloat(), shown.height.toFloat(), boxW, boxH)
                            fit.offset(pad, pad)
                            val q = edit.quad
                            val src = FloatArray(8) { q[it] * if (it % 2 == 0) shown.width else shown.height }
                            val screen = FloatArray(8) { if (it % 2 == 0) fit.left + q[it] * fit.width() else fit.top + q[it] * fit.height() }
                            val (ow, oh) = ScanPhoto.Quad(src, "").size()
                            val target = cropFit(ow.toFloat(), oh.toFloat(), boxW, boxH)
                            target.offset(pad, pad)
                            val corners = floatArrayOf(target.left, target.top, target.right, target.top, target.right, target.bottom, target.left, target.bottom)
                            val t = morph.value
                            val dst = FloatArray(8) { screen[it] + (corners[it] - screen[it]) * t }
                            paint.alpha = ((1f - t) * 110).roundToInt().coerceIn(0, 255)
                            native.drawBitmap(shown, null, fit, paint)
                            paint.alpha = 255
                            if (matrix.setPolyToPoly(src, 0, dst, 0, 4)) {
                                native.save()
                                path.reset()
                                path.moveTo(dst[0], dst[1])
                                for (k in 1 until 4) path.lineTo(dst[k * 2], dst[k * 2 + 1])
                                path.close()
                                native.clipPath(path)
                                paint.color = android.graphics.Color.WHITE
                                native.drawPath(path, paint)
                                native.drawBitmap(shown, matrix, paint)
                                native.restore()
                            }
                        }
                    }
                }
            }
        }
        // Barra de avance y qué se está haciendo.
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(CropBar)
                .navigationBarsPadding()
                .padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val progress = ((step + if (phase == 0) morph.value * 0.5f else 0.5f + sweep.value * 0.5f) / total).coerceIn(0f, 1f)
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF22352A))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(if (animate) progress else (step + 0.5f) / total)
                        .height(3.dp)
                        .background(NeonGreen)
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                if (total > 1) "$label · ${step + 1} de $total" else label,
                color = CropInk,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun CropFilters(
    flats: List<DocScanFlat?>,
    filters: MutableList<Int>,
    page: Int,
    animate: Boolean,
    onPage: (Int) -> Unit,
    onRecrop: () -> Unit,
    onBack: () -> Unit,
    onDone: () -> Unit
) {
    val density = LocalDensity.current
    val flat = flats.getOrNull(page)
    var view by remember(flat) { mutableStateOf<FilterView?>(null) }
    var shownKind by remember(flat) { mutableIntStateOf(-1) }
    var shown by remember(flat) { mutableStateOf<Bitmap?>(null) }
    var previous by remember(flat) { mutableStateOf<Bitmap?>(null) }
    var plainBitmap by remember(flat) { mutableStateOf<Bitmap?>(null) }
    var comparing by remember { mutableStateOf(false) }
    val reveal = remember { Animatable(1f) }
    val kind = filters.getOrElse(page) { ScanFilters.MEJORAR }
    val paint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG) }
    val pad = with(density) { 18.dp.toPx() }
    val glow = with(density) { 44.dp.toPx() }

    LaunchedEffect(flat) {
        if (flat == null) return@LaunchedEffect
        val made = withContext(Dispatchers.Default) { runCatching { cropFilterView(flat) }.getOrNull() }
        view = made
        if (made != null) plainBitmap = withContext(Dispatchers.Default) {
            Bitmap.createBitmap(made.plain, made.width, made.height, Bitmap.Config.ARGB_8888)
        }
    }
    LaunchedEffect(view, kind) {
        val v = view ?: return@LaunchedEffect
        if (shownKind == kind && shown != null) return@LaunchedEffect
        val next = withContext(Dispatchers.Default) { cropFiltered(v, kind) }
        val old = shown
        previous = old
        shown = next
        shownKind = kind
        // Brillo que baja mostrando el filtro nuevo.
        if (animate && old != null) {
            reveal.snapTo(0f)
            reveal.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
        } else {
            reveal.snapTo(1f)
        }
        previous = null
    }

    Column(Modifier.fillMaxSize()) {
        CropTopBar("Filtros", if (flats.size > 1) "${page + 1} de ${flats.size}" else null, onBack) {
            // Comparar: mientras se mantiene apretado se ve la hoja sin filtro.
            Row(
                modifier = Modifier
                    .padding(end = 10.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (comparing) NeonGreen else Color(0xFF1A2B22))
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            comparing = true
                            tryAwaitRelease()
                            comparing = false
                        })
                    }
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Comparar", color = if (comparing) Color(0xFF06140C) else CropInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val current = shown
            if (current == null) {
                CircularProgressIndicator(color = NeonGreen)
            } else {
                Canvas(Modifier.fillMaxSize()) {
                    val fit = cropFit(current.width.toFloat(), current.height.toFloat(), size.width - pad * 2, size.height - pad * 2)
                    fit.offset(pad, pad)
                    drawIntoCanvas { canvas ->
                        val native = canvas.nativeCanvas
                        paint.reset()
                        paint.isAntiAlias = true
                        paint.isFilterBitmap = true
                        // Sombra suave de la hoja.
                        paint.color = android.graphics.Color.argb(70, 0, 0, 0)
                        native.drawRect(fit.left + 4f, fit.top + 6f, fit.right + 4f, fit.bottom + 6f, paint)
                        val plain = plainBitmap
                        if (comparing && plain != null) {
                            native.drawBitmap(plain, null, fit, paint)
                            return@drawIntoCanvas
                        }
                        val old = previous
                        val t = reveal.value
                        if (old != null && t < 1f) {
                            val y = fit.top + fit.height() * t
                            native.drawBitmap(old, null, fit, paint)
                            native.save()
                            native.clipRect(fit.left, fit.top, fit.right, y)
                            native.drawBitmap(current, null, fit, paint)
                            native.restore()
                            paint.shader = android.graphics.LinearGradient(
                                0f, y - glow, 0f, y,
                                android.graphics.Color.argb(0, 255, 255, 255), android.graphics.Color.argb(150, 255, 255, 255),
                                android.graphics.Shader.TileMode.CLAMP
                            )
                            native.drawRect(fit.left, (y - glow).coerceAtLeast(fit.top), fit.right, y, paint)
                            paint.shader = null
                        } else {
                            native.drawBitmap(current, null, fit, paint)
                        }
                    }
                }
            }
            if (flats.size > 1) {
                Row(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xCC101D16)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { if (page > 0) onPage(page - 1) }, enabled = page > 0) {
                        Icon(Icons.Rounded.ChevronLeft, contentDescription = "Hoja anterior", tint = if (page > 0) CropInk else CropMuted)
                    }
                    Text("${page + 1} / ${flats.size}", color = CropInk, fontSize = 14.sp)
                    IconButton(onClick = { if (page < flats.size - 1) onPage(page + 1) }, enabled = page < flats.size - 1) {
                        Icon(Icons.Rounded.ChevronRight, contentDescription = "Hoja siguiente", tint = if (page < flats.size - 1) CropInk else CropMuted)
                    }
                }
            }
        }
        // Fila de filtros con la hoja en miniatura (el elegido en verde). Vale para todas las hojas.
        Column(Modifier.fillMaxWidth().background(CropBar).navigationBarsPadding()) {
            val thumbs = view?.thumbs
            // Pocos filtros, repartidos en todo el ancho (sin apretarse ni deslizar).
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 10.dp, end = 10.dp, top = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ScanFilters.ALL.forEachIndexed { index, option ->
                    val selected = option == kind
                    Column(
                        modifier = Modifier
                            .width(64.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                for (i in filters.indices) filters[i] = option
                            }
                            .padding(vertical = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .size(width = 56.dp, height = 74.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(if (selected) 2.5.dp else 1.dp, if (selected) NeonGreen else Color(0xFF2A3B31), RoundedCornerShape(8.dp))
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            val thumb = thumbs?.getOrNull(index)
                            if (thumb != null) {
                                Image(thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            ScanFilters.label(option),
                            color = if (selected) NeonGreen else CropMuted,
                            fontSize = 12.sp,
                            maxLines = 2,
                            lineHeight = 14.sp,
                            textAlign = TextAlign.Center,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CropAction(Icons.Rounded.Crop, "Recortar", onClick = onRecrop)
                CropDone("Listo", onDone)
            }
        }
    }
}
