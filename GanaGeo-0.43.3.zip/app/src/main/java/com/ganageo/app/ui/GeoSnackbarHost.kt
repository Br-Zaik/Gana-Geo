package com.ganageo.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView

/**
 * Avisos siempre completos: si el teclado o la barra de botones del celular
 * tapan el sitio del aviso, el aviso sube justo lo que haga falta.
 * Mide dónde quedó en la pantalla, así no deja espacio de más cuando ya
 * está encima de la barra de pestañas.
 */
@Composable
fun GeoSnackbarHost(state: SnackbarHostState, modifier: Modifier = Modifier) {
    val density = LocalDensity.current
    val view = LocalView.current
    val blocked = maxOf(WindowInsets.ime.getBottom(density), WindowInsets.navigationBars.getBottom(density))
    var gap by remember { mutableStateOf(-1) }
    val lift = if (gap < 0) blocked else (blocked - gap).coerceAtLeast(0)
    Box(
        modifier
            .fillMaxWidth()
            .onGloballyPositioned { c ->
                val bottom = c.positionInWindow().y + c.size.height
                val now = (view.rootView.height - bottom).toInt().coerceAtLeast(0)
                if (now != gap) gap = now
            }
    ) {
        SnackbarHost(state, Modifier.padding(bottom = with(density) { lift.toDp() }))
    }
}
