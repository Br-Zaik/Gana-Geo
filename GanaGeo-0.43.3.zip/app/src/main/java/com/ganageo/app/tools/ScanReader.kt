package com.ganageo.app.tools

import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Segundo lector de letras (PP-OCRv5 latino, PaddleOCR, Apache 2.0): lo que no
 * depende del celular. Arma la entrada de un renglón y traduce la salida a texto.
 * Todo local; el modelo va dentro de la app.
 */
object ScanReader {
    /** Ancho máximo de un renglón ya escalado (más largo se achica). */
    const val MAX_WIDTH = 1600

    /** Entrada del modelo: [3, alto, ancho] en orden azul-verde-rojo, valores -1..1. */
    class Input(val data: FloatArray, val width: Int, val height: Int)

    /**
     * Renglón [pixels] (ARGB, [width]×[height]) al alto [targetHeight] del modelo,
     * con el ancho proporcional (múltiplo de 8; lo que sobra queda gris medio = 0).
     */
    fun prepare(pixels: IntArray, width: Int, height: Int, targetHeight: Int): Input {
        val h = targetHeight
        val ratio = width / height.coerceAtLeast(1).toFloat()
        val used = (h * ratio).roundToInt().coerceIn(8, MAX_WIDTH)
        val w = ((used + 7) / 8) * 8
        val out = FloatArray(3 * h * w)
        val plane = h * w
        val sx = width / used.toFloat()
        val sy = height / h.toFloat()
        for (y in 0 until h) {
            val fy = ((y + 0.5f) * sy - 0.5f).coerceIn(0f, (height - 1).toFloat())
            val y0 = fy.toInt()
            val y1 = min(height - 1, y0 + 1)
            val ty = fy - y0
            for (x in 0 until used) {
                val fx = ((x + 0.5f) * sx - 0.5f).coerceIn(0f, (width - 1).toFloat())
                val x0 = fx.toInt()
                val x1 = min(width - 1, x0 + 1)
                val tx = fx - x0
                val a = pixels[y0 * width + x0]
                val b = pixels[y0 * width + x1]
                val c = pixels[y1 * width + x0]
                val d = pixels[y1 * width + x1]
                for (ch in 0 until 3) {
                    // Canal 0 = azul, 1 = verde, 2 = rojo (como lo entrenó PaddleOCR).
                    val shift = ch * 8
                    val top = ((a shr shift) and 255) * (1 - tx) + ((b shr shift) and 255) * tx
                    val bottom = ((c shr shift) and 255) * (1 - tx) + ((d shr shift) and 255) * tx
                    val v = top * (1 - ty) + bottom * ty
                    out[ch * plane + y * w + x] = (v / 255f - 0.5f) / 0.5f
                }
            }
        }
        return Input(out, w, h)
    }

    /** Texto leído y qué tan seguro está (0..1). */
    class Read(val text: String, val confidence: Float)

    /**
     * Salida [probs] de [steps]×[classes] (CTC): 0 = vacío, 1..n = [dict], n+1 = espacio
     * si el modelo lo tiene. Si vienen sin normalizar, se normaliza cada paso.
     */
    fun decode(probs: FloatArray, steps: Int, classes: Int, dict: List<String>): Read? {
        if (steps <= 0 || classes < 2 || probs.size < steps * classes) return null
        val hasSpace = classes == dict.size + 2
        if (!hasSpace && classes != dict.size + 1) return null
        val text = StringBuilder()
        var confidence = 0f
        var kept = 0
        var previous = -1
        for (t in 0 until steps) {
            val base = t * classes
            var best = 0
            var bestValue = probs[base]
            var sum = 0f
            var maxValue = probs[base]
            for (c in 1 until classes) {
                val v = probs[base + c]
                if (v > bestValue) { bestValue = v; best = c }
                if (v > maxValue) maxValue = v
            }
            // ¿Ya son probabilidades (0..1 que suman 1)? Si no, softmax para la confianza.
            var minValue = probs[base]
            for (c in 0 until classes) {
                val v = probs[base + c]
                sum += v
                if (v < minValue) minValue = v
            }
            val probability = if (minValue >= 0f && sum in 0.98f..1.02f) bestValue else {
                var total = 0f
                for (c in 0 until classes) total += exp(probs[base + c] - maxValue)
                1f / total
            }
            if (best != 0 && best != previous) {
                val char = when {
                    best <= dict.size -> dict[best - 1]
                    hasSpace -> " "
                    else -> ""
                }
                text.append(char)
                confidence += probability
                kept++
            }
            previous = best
        }
        val clean = text.toString().replace(Regex(" {2,}"), " ").trim()
        if (clean.isEmpty()) return Read("", 0f)
        return Read(clean, confidence / kept.coerceAtLeast(1))
    }

    /**
     * Cajas aproximadas de cada palabra de un renglón leído por el segundo lector
     * (no da cajas): el ancho del renglón se reparte según las letras.
     */
    fun wordBoxes(text: String, left: Int, right: Int): List<Pair<String, IntArray>> {
        val words = text.split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val total = words.sumOf { it.length } + (words.size - 1)
        val unit = (right - left) / total.coerceAtLeast(1).toFloat()
        var x = left.toFloat()
        return words.map { word ->
            val start = x
            x += word.length * unit
            val box = intArrayOf(start.roundToInt(), 0, max(start.roundToInt() + 1, x.roundToInt()), 0)
            x += unit
            word to box
        }
    }

    /**
     * Palabra dudosa para revisar: con letras, de 3 o más, sin números, que no está en
     * el diccionario (ni en minúsculas). Siglas cortas en mayúsculas (RUC, IGV) no.
     */
    fun doubtful(word: String, known: (String) -> Boolean): Boolean {
        val clean = word.trim { !it.isLetterOrDigit() }
        if (clean.length < 3) return false
        if (clean.any { it.isDigit() }) return false
        if (!clean.all { it.isLetter() || it == '-' || it == '\'' }) return true
        if (clean.length <= 4 && clean.all { it.isUpperCase() }) return false
        return !known(clean) && !known(clean.lowercase())
    }

    /**
     * Cambia la palabra [old] (entera, la primera vez que aparece) por [new] en [text].
     * Devuelve null si no está.
     */
    fun replaceWord(text: String, old: String, new: String): String? {
        if (old.isEmpty()) return null
        var from = 0
        while (true) {
            val at = text.indexOf(old, from)
            if (at < 0) return null
            val beforeOk = at == 0 || !text[at - 1].isLetterOrDigit()
            val end = at + old.length
            val afterOk = end >= text.length || !text[end].isLetterOrDigit()
            if (beforeOk && afterOk) return text.substring(0, at) + new + text.substring(end)
            from = at + 1
        }
    }
}
