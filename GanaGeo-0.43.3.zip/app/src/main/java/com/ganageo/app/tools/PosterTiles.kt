package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Papelote en hojas: una imagen grande repartida en varias hojas para imprimir,
 * cortar y pegar. Solo cuentas (sin Android): dónde va cada pedazo.
 * Medidas en puntos de PDF (1 pt = 1/72 de pulgada; 1 mm = 2,835 pt).
 */
object PosterTiles {
    const val MM = 72f / 25.4f

    /** Tamaños de hoja (parada): nombre, ancho y alto en pt. */
    class Paper(val name: String, val width: Float, val height: Float)

    val PAPERS = listOf(
        Paper("A4", 595.28f, 841.89f),
        Paper("Oficio", 612.28f, 935.43f),
        Paper("Carta", 612f, 792f)
    )

    /**
     * Opciones. Cada hoja que recibe a otra (las de la derecha y las de abajo) lleva
     * una franja blanca de [overlapMm] para pegar: la hoja vecina se pone encima,
     * juntando la imagen. Los bordes de afuera del papelote van sin margen, salvo
     * [borderMm] si la impresora no imprime hasta el borde (0 = imagen hasta el borde).
     * [fill]: la imagen llena todo el papelote (se corta un poco) o entra completa.
     */
    class Options(
        val rows: Int,
        val cols: Int,
        val paper: Paper,
        val landscape: Boolean,
        val borderMm: Float,
        val overlapMm: Float,
        val fill: Boolean
    ) {
        val sheetWidth get() = if (landscape) paper.height else paper.width
        val sheetHeight get() = if (landscape) paper.width else paper.height
        val border get() = borderMm * MM
        /** Franja para pegar (no pasa del 40 % de la hoja). */
        val glue get() = (overlapMm * MM).coerceAtMost(min(sheetWidth, sheetHeight) * 0.4f)

        /** Margen izquierdo / de arriba de la hoja: franja si recibe a otra, si no el borde. */
        fun leftOf(col: Int) = if (col > 0) glue else border
        fun topOf(row: Int) = if (row > 0) glue else border

        /** Ancho y alto de imagen de cada columna / fila. */
        fun colWidth(col: Int) = (sheetWidth - leftOf(col) - border).coerceAtLeast(36f)
        fun rowHeight(row: Int) = (sheetHeight - topOf(row) - border).coerceAtLeast(36f)
        fun colX(col: Int): Float { var x = 0f; for (c in 0 until col) x += colWidth(c); return x }
        fun rowY(row: Int): Float { var y = 0f; for (r in 0 until row) y += rowHeight(r); return y }

        /** Tamaño del papelote armado (pt): las imágenes de las hojas, una junto a otra. */
        val posterWidth get() = colX(cols)
        val posterHeight get() = rowY(rows)
    }

    /** Dónde queda la imagen en el papelote: escala (pt por píxel) y esquina. */
    class Placement(val scale: Float, val x: Float, val y: Float, val width: Float, val height: Float)

    fun place(imageWidth: Int, imageHeight: Int, options: Options): Placement {
        val sx = options.posterWidth / imageWidth.coerceAtLeast(1)
        val sy = options.posterHeight / imageHeight.coerceAtLeast(1)
        val scale = if (options.fill) max(sx, sy) else min(sx, sy)
        val w = imageWidth * scale
        val h = imageHeight * scale
        return Placement(scale, (options.posterWidth - w) / 2f, (options.posterHeight - h) / 2f, w, h)
    }

    /**
     * Una hoja: [row], [col], su número (1, 2, 3… de izquierda a derecha y de arriba
     * abajo). [left]/[top]/[width]/[height] = su parte de imagen en el papelote.
     * [source] = pedazo de la imagen (px: izq, arriba, der, abajo) y [target] = dónde se
     * dibuja dentro de su parte (pt, igual orden). null si no le toca imagen.
     */
    class Tile(
        val row: Int,
        val col: Int,
        val number: Int,
        val left: Float,
        val top: Float,
        val width: Float,
        val height: Float,
        val source: FloatArray?,
        val target: FloatArray?
    ) {
        val label get() = "$number"
    }

    /** Nombre de la hoja con letra y número (A1, B2…), para la guía. */
    fun label(row: Int, col: Int): String {
        var n = row
        val letters = StringBuilder()
        do {
            letters.insert(0, ('A' + n % 26))
            n = n / 26 - 1
        } while (n >= 0)
        return "$letters${col + 1}"
    }

    fun tiles(imageWidth: Int, imageHeight: Int, options: Options): List<Tile> {
        val placement = place(imageWidth, imageHeight, options)
        val out = ArrayList<Tile>()
        for (row in 0 until options.rows) for (col in 0 until options.cols) {
            val left = options.colX(col)
            val top = options.rowY(row)
            val width = options.colWidth(col)
            val height = options.rowHeight(row)
            val number = row * options.cols + col + 1
            val l = max(left, placement.x)
            val t = max(top, placement.y)
            val r = min(left + width, placement.x + placement.width)
            val b = min(top + height, placement.y + placement.height)
            if (r - l < 0.5f || b - t < 0.5f) {
                out += Tile(row, col, number, left, top, width, height, null, null)
                continue
            }
            val source = floatArrayOf(
                ((l - placement.x) / placement.scale).coerceIn(0f, imageWidth.toFloat()),
                ((t - placement.y) / placement.scale).coerceIn(0f, imageHeight.toFloat()),
                ((r - placement.x) / placement.scale).coerceIn(0f, imageWidth.toFloat()),
                ((b - placement.y) / placement.scale).coerceIn(0f, imageHeight.toFloat())
            )
            out += Tile(row, col, number, left, top, width, height, source, floatArrayOf(l - left, t - top, r - left, b - top))
        }
        return out
    }

    /**
     * Filas × columnas para [sheets] hojas que mejor calzan con la forma de la imagen
     * (el papelote queda lo más parecido a la imagen, sin espacio perdido).
     */
    fun bestGrid(sheets: Int, imageWidth: Int, imageHeight: Int, paper: Paper, landscape: Boolean): Pair<Int, Int> {
        val n = sheets.coerceIn(1, 100)
        val imageRatio = imageWidth / imageHeight.coerceAtLeast(1).toFloat()
        val sheetRatio = if (landscape) paper.height / paper.width else paper.width / paper.height
        var best = 1 to n
        var bestScore = Float.MAX_VALUE
        for (rows in 1..n) {
            if (n % rows != 0) continue
            val cols = n / rows
            val ratio = cols * sheetRatio / rows
            val score = abs(kotlin.math.ln(ratio / imageRatio))
            if (score < bestScore) { bestScore = score; best = rows to cols }
        }
        return best
    }

    /**
     * Qué tan nítida sale (puntos de imagen por pulgada del papelote). Menos de 60 se
     * ve borrosa de cerca; de lejos (como en una exposición) igual se entiende.
     */
    fun dpi(imageWidth: Int, imageHeight: Int, options: Options): Int {
        val placement = place(imageWidth, imageHeight, options)
        return (72f / placement.scale.coerceAtLeast(0.0001f)).roundToInt()
    }

    /** Tamaño del papelote armado en centímetros (ancho, alto). */
    fun sizeCm(options: Options): Pair<Float, Float> =
        options.posterWidth / MM / 10f to options.posterHeight / MM / 10f
}
