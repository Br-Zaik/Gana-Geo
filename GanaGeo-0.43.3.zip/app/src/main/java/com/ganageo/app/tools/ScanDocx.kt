package com.ganageo.app.tools

import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * Word (.docx) "igual a la hoja": cada página lleva sus formas (barras, líneas),
 * sus imágenes (logos, fotos, firmas) y sus cuadros de texto, todo en el mismo
 * lugar que en la hoja. El texto se puede editar en Word.
 * Escrito a mano (un .docx es un ZIP con XML), sin librerías. Sin Android.
 * Medidas en puntos (1/72 de pulgada), desde arriba a la izquierda de la hoja.
 */
object ScanDocx {

    /**
     * Forma de fondo. [color2]: degradado hasta este color (izquierda→derecha, o
     * arriba→abajo si [vertical]). [insets]: cuánto entra cada esquina (arriba-izq,
     * arriba-der, abajo-der, abajo-izq) en puntos, para una punta inclinada.
     */
    class Shape(
        val x: Float,
        val y: Float,
        val width: Float,
        val height: Float,
        val color: Int,
        val radius: Float = 0f,
        val color2: Int? = null,
        val vertical: Boolean = false,
        val insets: FloatArray? = null
    )

    /** Imagen ya codificada: PNG (con transparencia) o JPG. */
    /** [rotation]: giro en grados a favor del reloj, alrededor de su centro. */
    class Image(val bytes: ByteArray, val png: Boolean, val x: Float, val y: Float, val width: Float, val height: Float, val rotation: Float = 0f)

    /** Cuadro de texto. [align]: "left", "center", "right" o "both" (justificado). */
    class TextBox(
        val x: Float,
        val y: Float,
        val width: Float,
        val height: Float,
        val paragraphs: List<String>,
        val font: String,
        val sizePt: Float,
        val bold: Boolean,
        val italic: Boolean,
        val color: Int,
        val align: String,
        /** Distancia entre renglones (exacta). */
        val lineSpacingPt: Float,
        /** Ancho de la letra en % (100 = normal). */
        val scalePercent: Int = 100,
        /** Un solo renglón: no se corta aunque la letra de Word sea un poco más ancha. */
        val singleLine: Boolean = false
    )

    class Page(
        val widthPt: Float,
        val heightPt: Float,
        val shapes: List<Shape>,
        val images: List<Image>,
        val boxes: List<TextBox>,
        val tables: List<Table> = emptyList()
    )

    /** Celda de una tabla de Word. [align]: "left", "center", "right". */
    class TableCell(
        val row: Int,
        val col: Int,
        val colSpan: Int,
        val text: String,
        val bold: Boolean,
        val italic: Boolean,
        val color: Int,
        val align: String,
        val fill: Int?,
        /** Filas que ocupa hacia abajo (celda unida: en Word, vMerge). */
        val rowSpan: Int = 1
    )

    /** Tabla de Word de verdad (se edita como tabla). Medidas en puntos. */
    class Table(
        /** Esquina de arriba a la izquierda en la hoja (solo para la tabla flotante). */
        val x: Float,
        val y: Float,
        val colWidths: List<Float>,
        val rowHeights: List<Float>,
        val cells: List<TableCell>,
        val font: String,
        val sizePt: Float,
        val borderColor: Int,
        val borderPt: Float,
        /** [borde de fila][columna] y [borde de columna][fila]: hay raya. */
        val hRules: List<List<Boolean>>,
        val vRules: List<List<Boolean>>
    )

    /**
     * XML de una tabla. [floating]: queda fija en su lugar de la hoja (Word "igual a
     * la hoja"); si no, va en el texto corrido.
     */
    fun tableXml(table: Table, floating: Boolean): String {
        val out = StringBuilder()
        fun twips(pt: Float) = (pt * 20f).roundToInt().coerceAtLeast(0)
        val total = table.colWidths.sum()
        out.append("<w:tbl><w:tblPr>")
        if (floating) {
            out.append("<w:tblpPr w:leftFromText=\"0\" w:rightFromText=\"0\" w:topFromText=\"0\" w:bottomFromText=\"0\"")
                .append(" w:vertAnchor=\"page\" w:horzAnchor=\"page\" w:tblpX=\"").append(twips(table.x))
                .append("\" w:tblpY=\"").append(twips(table.y)).append("\"/>")
            out.append("<w:tblOverlap w:val=\"overlap\"/>")
        }
        out.append("<w:tblW w:w=\"").append(twips(total)).append("\" w:type=\"dxa\"/>")
        out.append("<w:tblLayout w:type=\"fixed\"/>")
        val side = twips(table.sizePt * 0.35f)
        out.append("<w:tblCellMar><w:top w:w=\"0\" w:type=\"dxa\"/><w:left w:w=\"").append(side)
            .append("\" w:type=\"dxa\"/><w:bottom w:w=\"0\" w:type=\"dxa\"/><w:right w:w=\"").append(side)
            .append("\" w:type=\"dxa\"/></w:tblCellMar>")
        out.append("<w:tblLook w:val=\"0000\"/></w:tblPr><w:tblGrid>")
        for (width in table.colWidths) out.append("<w:gridCol w:w=\"").append(twips(width)).append("\"/>")
        out.append("</w:tblGrid>")
        val halfPoints = (table.sizePt * 2f).roundToInt().coerceIn(2, 3276)
        val font = xml(table.font)
        val size = (table.borderPt * 8f).roundToInt().coerceIn(2, 96)
        val color = hex(table.borderColor)
        fun border(name: String, on: Boolean) {
            if (on) {
                out.append("<w:").append(name).append(" w:val=\"single\" w:sz=\"").append(size)
                    .append("\" w:space=\"0\" w:color=\"").append(color).append("\"/>")
            } else {
                out.append("<w:").append(name).append(" w:val=\"nil\"/>")
            }
        }
        for (row in table.rowHeights.indices) {
            out.append("<w:tr><w:trPr><w:trHeight w:val=\"").append(twips(table.rowHeights[row]))
                .append("\" w:hRule=\"atLeast\"/></w:trPr>")
            // Celdas que empiezan en esta fila y las que vienen unidas desde arriba.
            val starting = table.cells.filter { it.row == row }
            val continuing = table.cells.filter { it.rowSpan > 1 && row > it.row && row < it.row + it.rowSpan }
            val cells = (starting + continuing).sortedBy { it.col }
            var col = 0
            for (cell in cells) {
                val isContinuation = cell.row != row
                val lastRow = cell.row + cell.rowSpan.coerceAtLeast(1) - 1
                // Columnas sin celda (no debería pasar): celda vacía.
                while (col < cell.col) {
                    out.append("<w:tc><w:tcPr><w:tcW w:w=\"").append(twips(table.colWidths.getOrElse(col) { 0f }))
                        .append("\" w:type=\"dxa\"/></w:tcPr><w:p/></w:tc>")
                    col++
                }
                val span = cell.colSpan.coerceIn(1, (table.colWidths.size - cell.col).coerceAtLeast(1))
                val width = (cell.col until cell.col + span).sumOf { table.colWidths.getOrElse(it) { 0f }.toDouble() }.toFloat()
                out.append("<w:tc><w:tcPr><w:tcW w:w=\"").append(twips(width)).append("\" w:type=\"dxa\"/>")
                if (span > 1) out.append("<w:gridSpan w:val=\"").append(span).append("\"/>")
                if (cell.rowSpan > 1) {
                    if (isContinuation) out.append("<w:vMerge/>") else out.append("<w:vMerge w:val=\"restart\"/>")
                }
                out.append("<w:tcBorders>")
                border("top", !isContinuation && (cell.col until cell.col + span).any { table.hRules.getOrNull(row)?.getOrNull(it) == true })
                border("left", table.vRules.getOrNull(cell.col)?.getOrNull(row) == true)
                border("bottom", row == lastRow && (cell.col until cell.col + span).any { table.hRules.getOrNull(row + 1)?.getOrNull(it) == true })
                border("right", table.vRules.getOrNull(cell.col + span)?.getOrNull(row) == true)
                out.append("</w:tcBorders>")
                if (isContinuation) {
                    out.append("<w:vAlign w:val=\"center\"/></w:tcPr><w:p/></w:tc>")
                    col = cell.col + span
                    continue
                }
                cell.fill?.let { out.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(hex(it)).append("\"/>") }
                out.append("<w:vAlign w:val=\"center\"/></w:tcPr>")
                val runProperties = StringBuilder()
                runProperties.append("<w:rPr><w:rFonts w:ascii=\"").append(font).append("\" w:hAnsi=\"").append(font)
                    .append("\" w:cs=\"").append(font).append("\"/>")
                if (cell.bold) runProperties.append("<w:b/><w:bCs/>")
                if (cell.italic) runProperties.append("<w:i/><w:iCs/>")
                runProperties.append("<w:color w:val=\"").append(hex(cell.color)).append("\"/>")
                runProperties.append("<w:sz w:val=\"").append(halfPoints).append("\"/><w:szCs w:val=\"").append(halfPoints).append("\"/></w:rPr>")
                for (text in cell.text.split('\n')) {
                    out.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\"/><w:jc w:val=\"").append(cell.align).append("\"/>")
                        .append(runProperties).append("</w:pPr>")
                    if (text.isNotEmpty()) {
                        out.append("<w:r>").append(runProperties).append("<w:t xml:space=\"preserve\">").append(xml(text)).append("</w:t></w:r>")
                    }
                    out.append("</w:p>")
                }
                out.append("</w:tc>")
                col = cell.col + span
            }
            while (col < table.colWidths.size) {
                out.append("<w:tc><w:tcPr><w:tcW w:w=\"").append(twips(table.colWidths[col])).append("\" w:type=\"dxa\"/></w:tcPr><w:p/></w:tc>")
                col++
            }
            out.append("</w:tr>")
        }
        out.append("</w:tbl>")
        return out.toString()
    }

    private const val EMU_PER_PT = 12700L

    private fun emu(pt: Float): Long = (pt * EMU_PER_PT).roundToLong().coerceAtLeast(0L)

    private fun hex(color: Int): String = String.format(
        Locale.ROOT, "%02X%02X%02X", (color shr 16) and 0xFF, (color shr 8) and 0xFF, color and 0xFF
    )

    fun xml(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .filter { it == '\t' || it >= ' ' }

    private class Counter {
        var docPr = 1
        var image = 1
        var height = 10
    }

    private fun anchorStart(
        out: StringBuilder,
        counter: Counter,
        x: Float,
        y: Float,
        width: Float,
        height: Float,
        behind: Boolean,
        name: String
    ) {
        val id = counter.docPr++
        out.append("<w:r><w:drawing>")
        out.append("<wp:anchor distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"")
            .append(counter.height++).append("\" behindDoc=\"").append(if (behind) 1 else 0)
            .append("\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\">")
        out.append("<wp:simplePos x=\"0\" y=\"0\"/>")
        out.append("<wp:positionH relativeFrom=\"page\"><wp:posOffset>").append(emu(x)).append("</wp:posOffset></wp:positionH>")
        out.append("<wp:positionV relativeFrom=\"page\"><wp:posOffset>").append(emu(y)).append("</wp:posOffset></wp:positionV>")
        out.append("<wp:extent cx=\"").append(max(1L, emu(width))).append("\" cy=\"").append(max(1L, emu(height))).append("\"/>")
        out.append("<wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/>")
        out.append("<wp:wrapNone/>")
        out.append("<wp:docPr id=\"").append(id).append("\" name=\"").append(name).append(' ').append(id).append("\"/>")
        out.append("<wp:cNvGraphicFramePr/>")
    }

    private fun anchorEnd(out: StringBuilder) {
        out.append("</wp:anchor></w:drawing></w:r>")
    }

    private fun xfrm(out: StringBuilder, width: Float, height: Float, rotation: Float = 0f) {
        out.append("<a:xfrm")
        // Word: el giro va en sesenta milésimas de grado (0 a 360°).
        val turn = (((rotation % 360f) + 360f) % 360f * 60000f).roundToLong()
        if (turn != 0L && turn < 21600000L) out.append(" rot=\"").append(turn).append("\"")
        out.append("><a:off x=\"0\" y=\"0\"/><a:ext cx=\"").append(max(1L, emu(width)))
            .append("\" cy=\"").append(max(1L, emu(height))).append("\"/></a:xfrm>")
    }

    private fun shape(out: StringBuilder, counter: Counter, shape: Shape) {
        anchorStart(out, counter, shape.x, shape.y, shape.width, shape.height, behind = true, name = "Forma")
        out.append("<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">")
        out.append("<a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\">")
        out.append("<wps:wsp><wps:cNvSpPr/><wps:spPr>")
        xfrm(out, shape.width, shape.height)
        val shortSide = min(shape.width, shape.height)
        val insets = shape.insets
        if (insets != null && insets.any { it > 0.3f }) {
            // Figura con punta inclinada (contorno propio).
            val w = emu(shape.width).coerceAtLeast(1L)
            val h = emu(shape.height).coerceAtLeast(1L)
            fun pt(x: Float, y: Float) = "<a:pt x=\"" + emu(x).coerceIn(0L, w) + "\" y=\"" + emu(y).coerceIn(0L, h) + "\"/>"
            out.append("<a:custGeom><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l=\"0\" t=\"0\" r=\"r\" b=\"b\"/>")
            out.append("<a:pathLst><a:path w=\"").append(w).append("\" h=\"").append(h).append("\">")
            out.append("<a:moveTo>").append(pt(insets[0], 0f)).append("</a:moveTo>")
            out.append("<a:lnTo>").append(pt(shape.width - insets[1], 0f)).append("</a:lnTo>")
            out.append("<a:lnTo>").append(pt(shape.width - insets[2], shape.height)).append("</a:lnTo>")
            out.append("<a:lnTo>").append(pt(insets[3], shape.height)).append("</a:lnTo>")
            out.append("<a:close/></a:path></a:pathLst></a:custGeom>")
        } else if (shape.radius > 0.3f && shortSide > 0f) {
            val adjust = (shape.radius / shortSide * 100000f).roundToInt().coerceIn(0, 50000)
            out.append("<a:prstGeom prst=\"roundRect\"><a:avLst><a:gd name=\"adj\" fmla=\"val ").append(adjust).append("\"/></a:avLst></a:prstGeom>")
        } else {
            out.append("<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom>")
        }
        val end = shape.color2
        if (end != null) {
            out.append("<a:gradFill rotWithShape=\"1\"><a:gsLst><a:gs pos=\"0\"><a:srgbClr val=\"").append(hex(shape.color))
                .append("\"/></a:gs><a:gs pos=\"100000\"><a:srgbClr val=\"").append(hex(end))
                .append("\"/></a:gs></a:gsLst><a:lin ang=\"").append(if (shape.vertical) 5400000 else 0).append("\" scaled=\"0\"/></a:gradFill>")
        } else {
            out.append("<a:solidFill><a:srgbClr val=\"").append(hex(shape.color)).append("\"/></a:solidFill>")
        }
        out.append("<a:ln><a:noFill/></a:ln>")
        out.append("</wps:spPr><wps:bodyPr/></wps:wsp>")
        out.append("</a:graphicData></a:graphic>")
        anchorEnd(out)
    }

    private fun image(out: StringBuilder, counter: Counter, image: Image, relId: String) {
        anchorStart(out, counter, image.x, image.y, image.width, image.height, behind = false, name = "Imagen")
        val id = counter.docPr - 1
        out.append("<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">")
        out.append("<a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">")
        out.append("<pic:pic><pic:nvPicPr><pic:cNvPr id=\"").append(id).append("\" name=\"Imagen ").append(id).append("\"/><pic:cNvPicPr/></pic:nvPicPr>")
        out.append("<pic:blipFill><a:blip r:embed=\"").append(relId).append("\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>")
        out.append("<pic:spPr>")
        xfrm(out, image.width, image.height, image.rotation)
        out.append("<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>")
        out.append("</a:graphicData></a:graphic>")
        anchorEnd(out)
    }

    private fun textBox(out: StringBuilder, counter: Counter, box: TextBox) {
        anchorStart(out, counter, box.x, box.y, box.width, box.height, behind = false, name = "Texto")
        out.append("<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">")
        out.append("<a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\">")
        out.append("<wps:wsp><wps:cNvSpPr txBox=\"1\"/><wps:spPr>")
        xfrm(out, box.width, box.height)
        out.append("<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></wps:spPr>")
        out.append("<wps:txbx><w:txbxContent>")
        val halfPoints = (box.sizePt * 2f).roundToInt().coerceIn(2, 3276)
        val line = (box.lineSpacingPt * 20f).roundToInt().coerceAtLeast(20)
        val font = xml(box.font)
        val runProperties = StringBuilder()
        runProperties.append("<w:rPr><w:rFonts w:ascii=\"").append(font).append("\" w:hAnsi=\"").append(font)
            .append("\" w:cs=\"").append(font).append("\"/>")
        if (box.bold) runProperties.append("<w:b/><w:bCs/>")
        if (box.italic) runProperties.append("<w:i/><w:iCs/>")
        runProperties.append("<w:color w:val=\"").append(hex(box.color)).append("\"/>")
        if (box.scalePercent != 100) runProperties.append("<w:w w:val=\"").append(box.scalePercent.coerceIn(1, 600)).append("\"/>")
        runProperties.append("<w:sz w:val=\"").append(halfPoints).append("\"/><w:szCs w:val=\"").append(halfPoints).append("\"/></w:rPr>")
        val paragraphs = box.paragraphs.ifEmpty { listOf("") }
        for (text in paragraphs) {
            out.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"").append(line)
                .append("\" w:lineRule=\"exact\"/>")
            // Viñetas y listas numeradas: los renglones de abajo van alineados al texto.
            val prefix = ScanRebuild.listPrefix(text)
            if (prefix > 0) {
                val hanging = (box.sizePt * 0.55f * prefix * 20f).roundToInt().coerceIn(100, 1400)
                out.append("<w:ind w:left=\"").append(hanging).append("\" w:hanging=\"").append(hanging).append("\"/>")
            }
            out.append("<w:jc w:val=\"").append(box.align).append("\"/>")
            out.append(runProperties)
            out.append("</w:pPr>")
            if (text.isNotEmpty()) {
                out.append("<w:r>").append(runProperties).append("<w:t xml:space=\"preserve\">").append(xml(text)).append("</w:t></w:r>")
            }
            out.append("</w:p>")
        }
        out.append("</w:txbxContent></wps:txbx>")
        out.append("<wps:bodyPr rot=\"0\" vert=\"horz\" wrap=\"").append(if (box.singleLine) "none" else "square").append("\" lIns=\"0\" tIns=\"0\" rIns=\"0\" bIns=\"0\" anchor=\"t\" anchorCtr=\"0\"><a:spAutoFit/></wps:bodyPr>")
        out.append("</wps:wsp></a:graphicData></a:graphic>")
        anchorEnd(out)
    }

    private fun section(page: Page): String {
        val width = (page.widthPt * 20f).roundToInt()
        val height = (page.heightPt * 20f).roundToInt()
        val orient = if (page.widthPt > page.heightPt) " w:orient=\"landscape\"" else ""
        return "<w:sectPr><w:pgSz w:w=\"$width\" w:h=\"$height\"$orient/>" +
            "<w:pgMar w:top=\"0\" w:right=\"0\" w:bottom=\"0\" w:left=\"0\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/>" +
            "</w:sectPr>"
    }

    fun write(output: OutputStream, pages: List<Page>) {
        val counter = Counter()
        val body = StringBuilder()
        val media = ArrayList<Pair<String, ByteArray>>()
        val rels = StringBuilder()
        pages.forEachIndexed { pageIndex, page ->
            // Tablas flotantes: fijas en su lugar de esta hoja (van antes de su párrafo).
            for (table in page.tables) body.append(tableXml(table, floating = true))
            body.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\"/>")
            if (pageIndex < pages.lastIndex) body.append(section(page))
            body.append("</w:pPr>")
            // Primero las formas (detrás), luego imágenes, luego el texto (encima).
            for (item in page.shapes) shape(body, counter, item)
            for (item in page.images) {
                val number = counter.image++
                val name = "image$number." + if (item.png) "png" else "jpeg"
                val relId = "rIdImg$number"
                media += name to item.bytes
                rels.append("<Relationship Id=\"").append(relId)
                    .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/")
                    .append(name).append("\"/>")
                image(body, counter, item, relId)
            }
            for (item in page.boxes) textBox(body, counter, item)
            body.append("</w:p>")
        }
        val last = pages.lastOrNull() ?: Page(595f, 842f, emptyList(), emptyList(), emptyList())
        writePackage(output, body.toString() + section(last), media, rels.toString())
    }

    private fun writePackage(output: OutputStream, bodyXml: String, media: List<Pair<String, ByteArray>>, rels: String) {
        val documentXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document" +
            " xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"" +
            " xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"" +
            " xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\"" +
            " xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\"" +
            " xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"" +
            " xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\">" +
            "<w:body>" + bodyXml + "</w:body></w:document>"
        val types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Default Extension=\"png\" ContentType=\"image/png\"/>" +
            "<Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"
        val rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"
        val documentRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" + rels + "</Relationships>"
        ZipOutputStream(output).use { zip ->
            fun put(name: String, bytes: ByteArray) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(bytes)
                zip.closeEntry()
            }
            put("[Content_Types].xml", types.toByteArray(Charsets.UTF_8))
            put("_rels/.rels", rootRels.toByteArray(Charsets.UTF_8))
            put("word/document.xml", documentXml.toByteArray(Charsets.UTF_8))
            put("word/_rels/document.xml.rels", documentRels.toByteArray(Charsets.UTF_8))
            for ((name, bytes) in media) put("word/media/$name", bytes)
        }
    }

    // -----------------------------------------------------------------------
    // Word "editable" (en flujo): se abre igual en Word, Google Docs y WPS.
    // Sin cuadros de texto flotantes: párrafos, tablas e imágenes en línea, de
    // arriba abajo. Lo que va lado a lado (logo y título) va en una tabla sin rayas.
    // -----------------------------------------------------------------------

    /** Margen de la hoja en Word editable (≈ 1 cm). */
    private const val FLOW_MARGIN = 28f

    private class FlowItem(val left: Float, val top: Float, val right: Float, val bottom: Float, val box: TextBox?, val image: Image?, val table: Table?) {
        val height get() = bottom - top
    }

    private fun runProps(font: String, sizePt: Float, bold: Boolean, italic: Boolean, color: Int, scalePercent: Int = 100): String {
        val halfPoints = (sizePt * 2f).roundToInt().coerceIn(2, 3276)
        val name = xml(font)
        val out = StringBuilder()
        out.append("<w:rPr><w:rFonts w:ascii=\"").append(name).append("\" w:hAnsi=\"").append(name).append("\" w:cs=\"").append(name).append("\"/>")
        if (bold) out.append("<w:b/><w:bCs/>")
        if (italic) out.append("<w:i/><w:iCs/>")
        out.append("<w:color w:val=\"").append(hex(color)).append("\"/>")
        if (scalePercent != 100) out.append("<w:w w:val=\"").append(scalePercent.coerceIn(1, 600)).append("\"/>")
        out.append("<w:sz w:val=\"").append(halfPoints).append("\"/><w:szCs w:val=\"").append(halfPoints).append("\"/></w:rPr>")
        return out.toString()
    }

    /** Párrafos de un cuadro de texto, en flujo. [indent]: sangría izquierda (pt). */
    private fun flowParagraphs(out: StringBuilder, box: TextBox, beforePt: Float, indent: Float, shade: Int?) {
        val props = runProps(box.font, box.sizePt, box.bold, box.italic, box.color, box.scalePercent)
        val line = (box.lineSpacingPt * 20f).roundToInt().coerceAtLeast(20)
        box.paragraphs.ifEmpty { listOf("") }.forEachIndexed { index, text ->
            out.append("<w:p><w:pPr>")
            if (shade != null) out.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(hex(shade)).append("\"/>")
            out.append("<w:spacing w:before=\"").append(if (index == 0) (beforePt * 20f).roundToInt().coerceIn(0, 4000) else 0)
                .append("\" w:after=\"0\" w:line=\"").append(line).append("\" w:lineRule=\"atLeast\"/>")
            val prefix = ScanRebuild.listPrefix(text)
            val left = (indent * 20f).roundToInt().coerceAtLeast(0)
            if (prefix > 0) {
                val hanging = (box.sizePt * 0.55f * prefix * 20f).roundToInt().coerceIn(100, 1400)
                out.append("<w:ind w:left=\"").append(left + hanging).append("\" w:hanging=\"").append(hanging).append("\"/>")
            } else if (left > 0 && box.align != "center" && box.align != "right") {
                out.append("<w:ind w:left=\"").append(left).append("\"/>")
            }
            out.append("<w:jc w:val=\"").append(box.align).append("\"/>").append(props).append("</w:pPr>")
            if (text.isNotEmpty()) out.append("<w:r>").append(props).append("<w:t xml:space=\"preserve\">").append(xml(text)).append("</w:t></w:r>")
            out.append("</w:p>")
        }
    }

    /** Imagen en línea con el texto (no flota): [maxWidth] para que entre. */
    private fun inlineImage(out: StringBuilder, counter: Counter, image: Image, relId: String, maxWidth: Float) {
        val scale = min(1f, maxWidth / image.width.coerceAtLeast(1f))
        val width = image.width * scale
        val height = image.height * scale
        val id = counter.docPr++
        out.append("<w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\">")
        out.append("<wp:extent cx=\"").append(max(1L, emu(width))).append("\" cy=\"").append(max(1L, emu(height))).append("\"/>")
        out.append("<wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/>")
        out.append("<wp:docPr id=\"").append(id).append("\" name=\"Imagen ").append(id).append("\"/><wp:cNvGraphicFramePr/>")
        out.append("<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">")
        out.append("<a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">")
        out.append("<pic:pic><pic:nvPicPr><pic:cNvPr id=\"").append(id).append("\" name=\"Imagen ").append(id).append("\"/><pic:cNvPicPr/></pic:nvPicPr>")
        out.append("<pic:blipFill><a:blip r:embed=\"").append(relId).append("\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>")
        out.append("<pic:spPr>")
        xfrm(out, width, height, image.rotation)
        out.append("<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>")
        out.append("</a:graphicData></a:graphic></wp:inline></w:drawing></w:r>")
    }

    /** Párrafo vacío de [pt] de alto (para dejar el espacio de arriba). */
    private fun spacer(out: StringBuilder, pt: Float) {
        val twips = (pt * 20f).roundToInt()
        if (twips < 40) return
        out.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"").append(twips.coerceAtMost(8000))
            .append("\" w:lineRule=\"exact\"/><w:rPr><w:sz w:val=\"2\"/></w:rPr></w:pPr></w:p>")
    }

    /** Color de la forma que hay detrás del texto (barra de título), si hay una. */
    private fun shadeFor(item: FlowItem, shapes: List<Shape>): Int? {
        val cx = (item.left + item.right) / 2f
        val cy = (item.top + item.bottom) / 2f
        return shapes.lastOrNull { cx >= it.x && cx <= it.x + it.width && cy >= it.y && cy <= it.y + it.height && it.width >= (item.right - item.left) * 0.8f }?.color
    }

    fun writeFlow(output: OutputStream, pages: List<Page>) {
        val counter = Counter()
        val body = StringBuilder()
        val media = ArrayList<Pair<String, ByteArray>>()
        val rels = StringBuilder()
        fun imageRel(image: Image): String {
            val number = counter.image++
            val name = "image$number." + if (image.png) "png" else "jpeg"
            val relId = "rIdImg$number"
            media += name to image.bytes
            rels.append("<Relationship Id=\"").append(relId)
                .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/")
                .append(name).append("\"/>")
            return relId
        }
        pages.forEachIndexed { pageIndex, page ->
            val usable = (page.widthPt - FLOW_MARGIN * 2).coerceAtLeast(72f)
            val items = ArrayList<FlowItem>()
            page.boxes.forEach { items += FlowItem(it.x, it.y, it.x + it.width, it.y + it.height, it, null, null) }
            page.images.forEach { items += FlowItem(it.x, it.y, it.x + it.width, it.y + it.height, null, it, null) }
            page.tables.forEach { items += FlowItem(it.x, it.y, it.x + it.colWidths.sum(), it.y + it.rowHeights.sum(), null, null, it) }
            items.sortWith(compareBy({ it.top }, { it.left }))
            // Filas: lo que se toca de alto va lado a lado. Las tablas van solas.
            val rows = ArrayList<MutableList<FlowItem>>()
            var rowBottom = -1f
            for (item in items) {
                val current = rows.lastOrNull()
                val joins = current != null && item.table == null && current.none { it.table != null } &&
                    item.top < rowBottom - min(item.height, 12f) * 0.5f
                if (joins) {
                    current!!.add(item)
                    rowBottom = max(rowBottom, item.bottom)
                } else {
                    rows += mutableListOf(item)
                    rowBottom = item.bottom
                }
            }
            var previousBottom = FLOW_MARGIN
            for (row in rows) {
                row.sortBy { it.left }
                val top = row.minOf { it.top }
                val gap = (top - previousBottom).coerceIn(0f, 200f)
                if (row.size == 1) {
                    val item = row[0]
                    val indent = (item.left - FLOW_MARGIN).coerceIn(0f, usable * 0.8f)
                    when {
                        item.box != null -> flowParagraphs(body, item.box, gap, indent, shadeFor(item, page.shapes))
                        item.image != null -> {
                            val relId = imageRel(item.image)
                            val center = (item.left + item.right) / 2f
                            val align = when {
                                center < page.widthPt * 0.4f -> "left"
                                center > page.widthPt * 0.6f -> "right"
                                else -> "center"
                            }
                            body.append("<w:p><w:pPr><w:spacing w:before=\"").append((gap * 20f).roundToInt()).append("\" w:after=\"0\"/>")
                            if (align == "left" && indent > 0f) body.append("<w:ind w:left=\"").append((indent * 20f).roundToInt()).append("\"/>")
                            body.append("<w:jc w:val=\"").append(align).append("\"/></w:pPr>")
                            inlineImage(body, counter, item.image, relId, usable)
                            body.append("</w:p>")
                        }
                        item.table != null -> {
                            spacer(body, gap)
                            val table = item.table
                            // Si es más ancha que la hoja, se achica toda por igual.
                            val total = table.colWidths.sum()
                            val k = if (total > usable) usable / total else 1f
                            val fitted = Table(
                                0f, 0f, table.colWidths.map { it * k }, table.rowHeights, table.cells, table.font,
                                (table.sizePt * if (k < 1f) max(k, 0.7f) else 1f), table.borderColor, table.borderPt, table.hRules, table.vRules
                            )
                            val xml = tableXml(fitted, floating = false)
                            val shift = ((item.left - FLOW_MARGIN) * 20f).roundToInt().coerceIn(0, ((usable - total * k) * 20f).roundToInt().coerceAtLeast(0))
                            body.append(if (shift > 0) xml.replaceFirst("<w:tblPr>", "<w:tblPr><w:tblInd w:w=\"$shift\" w:type=\"dxa\"/>") else xml)
                        }
                    }
                } else {
                    // Lado a lado: tabla sin rayas de una fila.
                    spacer(body, gap)
                    val lefts = row.map { (it.left - FLOW_MARGIN).coerceIn(0f, usable) }
                    val widths = row.indices.map { i ->
                        val start = if (i == 0) 0f else lefts[i]
                        val end = if (i == row.lastIndex) usable else lefts[i + 1]
                        (end - start).coerceAtLeast(24f)
                    }
                    val scale = min(1f, usable / widths.sum())
                    body.append("<w:tbl><w:tblPr><w:tblW w:w=\"").append((widths.sum() * scale * 20f).roundToInt())
                        .append("\" w:type=\"dxa\"/><w:tblLayout w:type=\"fixed\"/>")
                    body.append("<w:tblBorders><w:top w:val=\"nil\"/><w:left w:val=\"nil\"/><w:bottom w:val=\"nil\"/><w:right w:val=\"nil\"/><w:insideH w:val=\"nil\"/><w:insideV w:val=\"nil\"/></w:tblBorders>")
                    body.append("<w:tblCellMar><w:top w:w=\"0\" w:type=\"dxa\"/><w:left w:w=\"0\" w:type=\"dxa\"/><w:bottom w:w=\"0\" w:type=\"dxa\"/><w:right w:w=\"0\" w:type=\"dxa\"/></w:tblCellMar>")
                    body.append("<w:tblLook w:val=\"0000\"/></w:tblPr><w:tblGrid>")
                    widths.forEach { body.append("<w:gridCol w:w=\"").append((it * scale * 20f).roundToInt()).append("\"/>") }
                    body.append("</w:tblGrid><w:tr>")
                    row.forEachIndexed { i, item ->
                        val cellWidth = widths[i] * scale
                        body.append("<w:tc><w:tcPr><w:tcW w:w=\"").append((cellWidth * 20f).roundToInt()).append("\" w:type=\"dxa\"/><w:vAlign w:val=\"top\"/></w:tcPr>")
                        val inside = (item.left - FLOW_MARGIN - (if (i == 0) 0f else lefts[i])).coerceIn(0f, cellWidth * 0.6f)
                        val drop = item.top - top
                        when {
                            item.box != null -> flowParagraphs(body, item.box, drop, inside, shadeFor(item, page.shapes))
                            item.image != null -> {
                                val relId = imageRel(item.image)
                                body.append("<w:p><w:pPr><w:spacing w:before=\"").append((drop * 20f).roundToInt()).append("\" w:after=\"0\"/>")
                                if (inside > 0f) body.append("<w:ind w:left=\"").append((inside * 20f).roundToInt()).append("\"/>")
                                body.append("</w:pPr>")
                                inlineImage(body, counter, item.image, relId, (cellWidth - inside).coerceAtLeast(12f))
                                body.append("</w:p>")
                            }
                            else -> body.append("<w:p/>")
                        }
                        body.append("</w:tc>")
                    }
                    body.append("</w:tr></w:tbl>")
                }
                previousBottom = max(previousBottom, row.maxOf { it.bottom })
            }
            // Fin de la página: su tamaño y márgenes; la siguiente empieza en hoja nueva.
            if (pageIndex < pages.lastIndex) body.append("<w:p><w:pPr>").append(flowSection(page)).append("</w:pPr></w:p>")
        }
        val last = pages.lastOrNull() ?: Page(595f, 842f, emptyList(), emptyList(), emptyList())
        writePackage(output, body.toString() + flowSection(last), media, rels.toString())
    }

    private fun flowSection(page: Page): String {
        val width = (page.widthPt * 20f).roundToInt()
        val height = (page.heightPt * 20f).roundToInt()
        val margin = (FLOW_MARGIN * 20f).roundToInt()
        val orient = if (page.widthPt > page.heightPt) " w:orient=\"landscape\"" else ""
        return "<w:sectPr><w:pgSz w:w=\"$width\" w:h=\"$height\"$orient/>" +
            "<w:pgMar w:top=\"$margin\" w:right=\"$margin\" w:bottom=\"$margin\" w:left=\"$margin\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/>" +
            "</w:sectPr>"
    }
}
