package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Encuentra en la hoja (ya sin texto) los logos, fotos e íconos que están
 * sobre el papel, para poder moverlos, agrandarlos o borrarlos como piezas.
 *
 * - Se buscan manchas que no son del color del papel y se juntan las cercanas
 *   (las partes de un mismo logo).
 * - Se quedan las que tienen "dibujo" adentro (fotos, logos, íconos). Las barras
 *   de color lisas, las líneas y los recuadros vacíos no son piezas: quedan en el fondo.
 * - Solo las que están sobre el papel (alrededor hay papel); así al moverlas el
 *   hueco se rellena limpio.
 *
 * Trabaja sobre un arreglo de colores ARGB (sin Android) para poder probarlo.
 */
object ScanObjects {
    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun dist(a: Int, b: Int) = abs(red(a) - red(b)) + abs(green(a) - green(b)) + abs(blue(a) - blue(b))
    private fun rgb(r: Int, g: Int, b: Int): Int =
        -0x1000000 or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    /** Color del papel: el color claro y sin tinte que más se repite. */
    fun paperColor(pixels: IntArray, width: Int, height: Int): Int {
        val counts = HashMap<Int, Int>()
        val step = max(1, (width * height / 40_000.0).let { kotlin.math.sqrt(it) }.toInt())
        for (y in 0 until height step step) for (x in 0 until width step step) {
            val c = pixels[y * width + x]
            val key = ((red(c) shr 3) shl 10) or ((green(c) shr 3) shl 5) or (blue(c) shr 3)
            counts[key] = (counts[key] ?: 0) + 1
        }
        val best = counts.entries.filter { (key, _) ->
            val r = (key shr 10) shl 3
            val g = ((key shr 5) and 31) shl 3
            val b = (key and 31) shl 3
            max(r, max(g, b)) - min(r, min(g, b)) < 40 && (r + g + b) / 3 > 150
        }.maxByOrNull { it.value } ?: return -1
        val key = best.key
        return rgb(((key shr 10) shl 3) + 4, (((key shr 5) and 31) shl 3) + 4, ((key and 31) shl 3) + 4)
    }

    /** Piezas encontradas: [izquierda, arriba, derecha, abajo) en píxeles. */
    fun find(pixels: IntArray, width: Int, height: Int, paper: Int): List<IntArray> {
        if (width < 20 || height < 20) return emptyList()
        // Se trabaja achicado (rápido); el resultado vuelve al tamaño real.
        val factor = max(1, (max(width, height) + 599) / 600)
        val w = width / factor
        val h = height / factor
        if (w < 10 || h < 10) return emptyList()
        val small = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var r = 0
            var g = 0
            var b = 0
            for (dy in 0 until factor) for (dx in 0 until factor) {
                val c = pixels[(y * factor + dy) * width + x * factor + dx]
                r += red(c)
                g += green(c)
                b += blue(c)
            }
            val n = factor * factor
            small[y * w + x] = rgb(r / n, g / n, b / n)
        }
        val content = BooleanArray(w * h) { dist(small[it], paper) > 54 }
        // Puntos con dibujo (bordes): diferencia con los vecinos.
        val busy = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            // Cambio de color con los vecinos (también entre colores de igual brillo).
            val e = dist(small[i + 1], small[i - 1]) + dist(small[i + w], small[i - w])
            busy[i] = e > 80
        }
        // Zonas con mucho dibujo junto (se agranda un poco para unir lo cercano).
        val grow = max(2, (min(w, h) * 0.006f).toInt())
        val near = dilate(busy, w, h, grow)
        val pageArea = w.toFloat() * h
        val minSide = max(5, (min(w, h) * 0.025f).toInt())
        val busyBoxes = components(near, w, h)
        val contentBoxes = components(content, w, h)
        val contentLabel = contentBoxes.second

        val candidates = ArrayList<IntArray>()
        for (box in busyBoxes.first) {
            val boxWidth = box[2] - box[0]
            val boxHeight = box[3] - box[1]
            if (boxWidth < minSide || boxHeight < minSide) continue
            // Renglón de texto que quedó (ancho y bajito): no es pieza.
            if (boxHeight < h * 0.04f && boxWidth > boxHeight * 5) continue
            var dense = 0
            for (y in box[1] until box[3]) for (x in box[0] until box[2]) if (busy[y * w + x]) dense++
            if (dense < boxWidth * boxHeight * 0.22f) continue // pocas manchas sueltas
            // Si está dentro de una foto con partes lisas (cielo), se toma la foto entera.
            var best = box
            val labels = HashSet<Int>()
            for (y in box[1] until box[3]) for (x in box[0] until box[2]) {
                val l = contentLabel[y * w + x]
                if (l >= 0) labels += l
            }
            if (labels.size == 1) {
                val whole = contentBoxes.first[labels.first()]
                val wholeArea = (whole[2] - whole[0]).toFloat() * (whole[3] - whole[1])
                if (wholeArea <= boxWidth.toFloat() * boxHeight * 1.35f) best = whole
            }
            candidates += intArrayOf(min(best[0], box[0]), min(best[1], box[1]), max(best[2], box[2]), max(best[3], box[3]))
        }
        // Se juntan las que se tocan (partes de un mismo logo).
        var merged = true
        while (merged) {
            merged = false
            loop@ for (i in candidates.indices) for (j in i + 1 until candidates.size) {
                val a = candidates[i]
                val b = candidates[j]
                if (a[0] <= b[2] && b[0] <= a[2] && a[1] <= b[3] && b[1] <= a[3]) {
                    candidates[i] = intArrayOf(min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))
                    candidates.removeAt(j)
                    merged = true
                    break@loop
                }
            }
        }
        val result = ArrayList<IntArray>()
        for (box in candidates) {
            val boxWidth = box[2] - box[0]
            val boxHeight = box[3] - box[1]
            if (boxWidth.toFloat() * boxHeight > pageArea * 0.16f) continue
            // Pegada a dos bordes de la hoja: es parte del diseño (fondo), no una pieza.
            var edges = 0
            if (box[0] <= 1) edges++
            if (box[1] <= 1) edges++
            if (box[2] >= w - 1) edges++
            if (box[3] >= h - 1) edges++
            if (edges >= 2) continue
            // Alrededor tiene que haber papel (si no, está dentro de una barra o foto mayor).
            var ring = 0
            var paperRing = 0
            val pad = grow + 1
            for (y in box[1] - pad until box[3] + pad) for (x in box[0] - pad until box[2] + pad) {
                if (x in box[0] until box[2] && y in box[1] until box[3]) continue
                if (x !in 0 until w || y !in 0 until h) continue
                ring++
                if (!content[y * w + x]) paperRing++
            }
            if (ring == 0 || paperRing * 10 < ring * 7) continue
            result += intArrayOf(
                (box[0] * factor - factor).coerceAtLeast(0),
                (box[1] * factor - factor).coerceAtLeast(0),
                ((box[2] + 1) * factor).coerceAtMost(width),
                ((box[3] + 1) * factor).coerceAtMost(height)
            )
        }
        return result
    }

    private fun dilate(mask: BooleanArray, w: Int, h: Int, radius: Int): BooleanArray {
        val horizontal = BooleanArray(w * h)
        for (y in 0 until h) {
            var last = -radius - 1
            for (x in 0 until w) {
                if (mask[y * w + x]) last = x
                if (x - last <= radius) horizontal[y * w + x] = true
            }
            last = w + radius + 1
            for (x in w - 1 downTo 0) {
                if (mask[y * w + x]) last = x
                if (last - x <= radius) horizontal[y * w + x] = true
            }
        }
        val result = BooleanArray(w * h)
        for (x in 0 until w) {
            var last = -radius - 1
            for (y in 0 until h) {
                if (horizontal[y * w + x]) last = y
                if (y - last <= radius) result[y * w + x] = true
            }
            last = h + radius + 1
            for (y in h - 1 downTo 0) {
                if (horizontal[y * w + x]) last = y
                if (last - y <= radius) result[y * w + x] = true
            }
        }
        return result
    }

    /** Manchas unidas (8 vecinos): cajas [izq, arriba, der, abajo) y la etiqueta de cada punto. */
    private fun components(mask: BooleanArray, w: Int, h: Int): Pair<List<IntArray>, IntArray> {
        val label = IntArray(w * h) { -1 }
        val boxes = ArrayList<IntArray>()
        val queue = IntArray(w * h)
        for (start in 0 until w * h) {
            if (!mask[start] || label[start] >= 0) continue
            val id = boxes.size
            var head = 0
            var tail = 0
            queue[tail++] = start
            label[start] = id
            var left = w
            var top = h
            var right = 0
            var bottom = 0
            while (head < tail) {
                val i = queue[head++]
                val x = i % w
                val y = i / w
                left = min(left, x)
                right = max(right, x)
                top = min(top, y)
                bottom = max(bottom, y)
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx !in 0 until w || ny !in 0 until h) continue
                    val n = ny * w + nx
                    if (mask[n] && label[n] < 0) {
                        label[n] = id
                        queue[tail++] = n
                    }
                }
            }
            boxes += intArrayOf(left, top, right + 1, bottom + 1)
        }
        return boxes to label
    }

    /**
     * Forma de una pieza (dónde hay dibujo dentro de su caja): 255 = parte de la
     * pieza, 0 = papel. Se agranda un poco para incluir el borde suave.
     */
    fun alpha(pixels: IntArray, width: Int, box: IntArray, paper: Int): ByteArray {
        val w = box[2] - box[0]
        val h = box[3] - box[1]
        val mask = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            mask[y * w + x] = dist(pixels[(box[1] + y) * width + box[0] + x], paper) > 30
        }
        val result = ByteArray(w * h)
        val radius = 2
        for (y in 0 until h) for (x in 0 until w) {
            var on = false
            loop@ for (dy in -radius..radius) {
                val yy = y + dy
                if (yy !in 0 until h) continue
                for (dx in -radius..radius) {
                    val xx = x + dx
                    if (xx in 0 until w && mask[yy * w + xx]) {
                        on = true
                        break@loop
                    }
                }
            }
            if (on) result[y * w + x] = 0xFF.toByte()
        }
        return result
    }

    /**
     * Pieza recortada con borde suave y sin halo: adentro opaca; en el borde, más
     * transparente mientras más se parece al papel, y al color se le quita el papel
     * mezclado (así sobre otro fondo no queda una aureola blanca o gris).
     * Devuelve los píxeles ARGB de la caja y la forma (255 = se borra del papel).
     */
    fun cutout(pixels: IntArray, width: Int, box: IntArray, paper: Int): Pair<IntArray, ByteArray> {
        val w = box[2] - box[0]
        val h = box[3] - box[1]
        val grown = alpha(pixels, width, box, paper)
        val core = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            core[y * w + x] = dist(pixels[(box[1] + y) * width + box[0] + x], paper) > 30
        }
        // Adentro de verdad: dibujo con dibujo alrededor (1 px).
        val inside = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (!core[i]) continue
            var all = true
            loop@ for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx
                val yy = y + dy
                if (xx !in 0 until w || yy !in 0 until h) continue
                if (!core[yy * w + xx]) { all = false; break@loop }
            }
            inside[i] = all
        }
        val pr = (paper shr 16) and 255
        val pg = (paper shr 8) and 255
        val pb = paper and 255
        val out = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (grown[i] == 0.toByte()) continue
            val c = pixels[(box[1] + y) * width + box[0] + x]
            if (inside[i]) {
                out[i] = c or (0xFF shl 24)
                continue
            }
            // Cuánto dibujo tiene: lo lejos que está del papel comparado con el dibujo de al
            // lado (si no hay dibujo cerca, con una escala fija).
            var near = -1
            var nearDist = Int.MAX_VALUE
            for (dy in -2..2) for (dx in -2..2) {
                val xx = x + dx
                val yy = y + dy
                if (xx !in 0 until w || yy !in 0 until h) continue
                val j = yy * w + xx
                if (!inside[j]) continue
                val d = dx * dx + dy * dy
                if (d < nearDist) { nearDist = d; near = j }
            }
            val full = if (near >= 0) dist(pixels[(box[1] + near / w) * width + box[0] + near % w], paper) else 150
            val a = ((dist(c, paper) - 8) / (full - 8).coerceAtLeast(30).toFloat()).coerceIn(0f, 1f)
            if (a <= 0.02f) continue
            // Sin el papel mezclado: color = (visto - (1 - a) × papel) / a.
            fun clean(v: Int, p: Int) = ((v - (1 - a) * p) / a).roundToInt().coerceIn(0, 255)
            val r = clean((c shr 16) and 255, pr)
            val g = clean((c shr 8) and 255, pg)
            val b = clean(c and 255, pb)
            out[i] = ((a * 255).roundToInt() shl 24) or (r shl 16) or (g shl 8) or b
        }
        return out to grown
    }
}
