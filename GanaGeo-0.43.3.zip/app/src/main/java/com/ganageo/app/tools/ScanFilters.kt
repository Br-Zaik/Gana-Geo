package com.ganageo.app.tools

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Filtros de la hoja enderezada (como un escáner de verdad). Todo local y rápido:
 * una pasada por píxel, salvo Blanco y negro (umbral por zona con tabla de sumas).
 *
 * Entran dos versiones de la misma hoja, del mismo tamaño:
 * - [original]: solo recortada y derecha (colores de la foto).
 * - [even]: con la luz pareja (sin sombra ni tono azul o amarillo).
 */
object ScanFilters {
    const val ORIGINAL = 0
    const val ACLARAR = 1
    const val MEJORAR = 2
    const val SIN_SOMBRA = 3
    const val BYN = 4
    const val AHORRO = 5
    const val GRIS = 6

    /** Los que se muestran (pocos y bien distintos). */
    val ALL = intArrayOf(ORIGINAL, MEJORAR, SIN_SOMBRA, BYN, GRIS)

    fun label(kind: Int): String = when (kind) {
        ORIGINAL -> "Original"
        ACLARAR -> "Aclarar"
        MEJORAR -> "Mejorar"
        SIN_SOMBRA -> "Sin sombra"
        BYN -> "Blanco y negro"
        AHORRO -> "Ahorro de tinta"
        else -> "Gris"
    }

    private fun lum(c: Int) = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
    private fun sat(c: Int): Int {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return max(r, max(g, b)) - min(r, min(g, b))
    }
    private fun rgb(r: Int, g: Int, b: Int) =
        (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
    private fun gray(v: Int) = rgb(v, v, v)

    /** Tabla de 256 valores: [lo]→0, [hi]→255, con curva [gamma]. */
    private fun curve(lo: Int, hi: Int, gamma: Float): IntArray {
        val span = (hi - lo).coerceAtLeast(1).toFloat()
        return IntArray(256) { v ->
            val t = ((v - lo) / span).coerceIn(0f, 1f)
            (255f * t.pow(gamma)).roundToInt()
        }
    }

    /** Percentil de luz (muestra 1 de cada [step] píxeles: rápido). */
    private fun percentile(pixels: IntArray, p: Float, step: Int = 7): Int {
        val hist = IntArray(256)
        var n = 0
        var i = 0
        while (i < pixels.size) { hist[lum(pixels[i])]++; n++; i += step }
        val target = (n * p).toInt()
        var acc = 0
        for (v in 0..255) { acc += hist[v]; if (acc > target) return v }
        return 255
    }

    fun apply(kind: Int, original: IntArray, even: IntArray, width: Int, height: Int): IntArray = when (kind) {
        ORIGINAL -> original.copyOf()
        ACLARAR -> brighten(original)
        MEJORAR -> enhance(even, width, height)
        SIN_SOMBRA -> whiten(even, width, height)
        BYN -> blackWhite(whiten(even, width, height), width, height, ink = 0)
        AHORRO -> saver(whiten(even, width, height), width, height)
        else -> grayscale(whiten(even, width, height))
    }

    /** Aclarar: la foto tal cual pero con el papel claro (estira la luz, sin tocar el tono). */
    fun brighten(src: IntArray): IntArray {
        val lo = percentile(src, 0.01f)
        val hi = percentile(src, 0.90f).coerceAtLeast(lo + 40)
        val table = curve(lo, hi, 0.85f)
        return IntArray(src.size) { i ->
            val c = src[i]
            rgb(table[(c shr 16) and 255], table[(c shr 8) and 255], table[c and 255])
        }
    }

    /** Mejorar: papel blanco y parejo (sin tono azul ni sombra), letra más negra y colores vivos. */
    fun enhance(src: IntArray, width: Int, height: Int): IntArray {
        val flat = divideByPaper(src, width, height) ?: src.copyOf()
        val lo = (percentile(flat, 0.01f) - 10).coerceIn(0, 110)
        // Lo casi blanco (lo que se transparenta de la otra cara) → blanco.
        val table = curve(lo, 242, 1.15f)
        for (i in flat.indices) {
            val c = flat[i]
            var r = table[(c shr 16) and 255]
            var g = table[(c shr 8) and 255]
            var b = table[c and 255]
            val l = (r * 299 + g * 587 + b * 114) / 1000
            // Saturación +15% (las celdas de color se ven como en el papel).
            r = l + (r - l) * 23 / 20
            g = l + (g - l) * 23 / 20
            b = l + (b - l) * 23 / 20
            flat[i] = rgb(r, g, b)
        }
        return flat
    }

    /** Sin sombra: como escáner, papel blanco puro; la letra y los colores se quedan. */
    fun whiten(src: IntArray, width: Int, height: Int): IntArray {
        val out = divideByPaper(src, width, height) ?: return enhance(src, width, height)
        val table = curve((percentile(out, 0.01f) + 12).coerceAtMost(120), 236, 1.25f)
        for (i in out.indices) {
            val c = out[i]
            out[i] = rgb(table[(c shr 16) and 255], table[(c shr 8) and 255], table[c and 255])
        }
        return out
    }

    /**
     * Cada zona se divide por el color de su papel: la sombra, la luz de costado y el
     * tono azul o amarillo desaparecen. El papel de cada zona es lo más claro de ella;
     * las zonas sin papel (celdas de color) y las celdas sueltas de color pálido toman
     * el papel de sus vecinas (mediana de 5×5 zonas), así su color se queda.
     * Lo que ya era blanco puro (afuera de la hoja) no cuenta como papel.
     */
    private fun divideByPaper(src: IntArray, width: Int, height: Int): IntArray? {
        val cell = (max(width, height) / 28).coerceIn(24, 96)
        val gw = (width + cell - 1) / cell
        val gh = (height + cell - 1) / cell
        val pr = FloatArray(gw * gh)
        val pg = FloatArray(gw * gh)
        val pb = FloatArray(gw * gh)
        val ok = BooleanArray(gw * gh)
        val hist = IntArray(256)
        for (gy in 0 until gh) for (gx in 0 until gw) {
            java.util.Arrays.fill(hist, 0)
            val x0 = gx * cell; val x1 = min(width, x0 + cell)
            val y0 = gy * cell; val y1 = min(height, y0 + cell)
            var n = 0
            var all = 0
            for (y in y0 until y1 step 2) for (x in x0 until x1 step 2) {
                val c = src[y * width + x]
                all++
                if (((c shr 16) and 255) >= 252 && ((c shr 8) and 255) >= 252 && (c and 255) >= 252) continue
                hist[lum(c)]++
                n++
            }
            if (n < all / 4 || n == 0) continue
            var acc = 0
            var cut = 255
            for (v in 255 downTo 0) { acc += hist[v]; if (acc >= n * 0.2f) { cut = v; break } }
            var r = 0L; var g = 0L; var b = 0L; var k = 0
            for (y in y0 until y1 step 2) for (x in x0 until x1 step 2) {
                val c = src[y * width + x]
                if (((c shr 16) and 255) >= 252 && ((c shr 8) and 255) >= 252 && (c and 255) >= 252) continue
                if (lum(c) >= cut) { r += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255; k++ }
            }
            if (k == 0) continue
            val i = gy * gw + gx
            pr[i] = r / k.toFloat(); pg[i] = g / k.toFloat(); pb[i] = b / k.toFloat()
            val l = (pr[i] * 299 + pg[i] * 587 + pb[i] * 114) / 1000f
            val sat = max(pr[i], max(pg[i], pb[i])) - min(pr[i], min(pg[i], pb[i]))
            ok[i] = l >= 150f && sat <= 40f
        }
        if (ok.none { it }) return null
        // Zonas sin papel: el papel de las vecinas (crece de a un paso).
        var pending = ok.count { !it }
        while (pending > 0) {
            val next = ok.copyOf()
            var filled = 0
            for (gy in 0 until gh) for (gx in 0 until gw) {
                val i = gy * gw + gx
                if (ok[i]) continue
                var r = 0f; var g = 0f; var b = 0f; var k = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val x = gx + dx; val y = gy + dy
                    if (x !in 0 until gw || y !in 0 until gh) continue
                    val j = y * gw + x
                    if (ok[j]) { r += pr[j]; g += pg[j]; b += pb[j]; k++ }
                }
                if (k > 0) { pr[i] = r / k; pg[i] = g / k; pb[i] = b / k; next[i] = true; filled++ }
            }
            pending -= filled
            System.arraycopy(next, 0, ok, 0, ok.size)
            if (filled == 0) break
        }
        // Mediana de 5×5 zonas: una celda pálida suelta no se toma por papel.
        if (gw >= 3 && gh >= 3) {
            fun median(a: FloatArray): FloatArray {
                val out = FloatArray(a.size)
                val buf = FloatArray(25)
                for (gy in 0 until gh) for (gx in 0 until gw) {
                    var k = 0
                    for (dy in -2..2) for (dx in -2..2) {
                        val x = gx + dx; val y = gy + dy
                        if (x in 0 until gw && y in 0 until gh) buf[k++] = a[y * gw + x]
                    }
                    java.util.Arrays.sort(buf, 0, k)
                    out[gy * gw + gx] = buf[k / 2]
                }
                return out
            }
            val mr = median(pr); val mg = median(pg); val mb = median(pb)
            System.arraycopy(mr, 0, pr, 0, pr.size)
            System.arraycopy(mg, 0, pg, 0, pg.size)
            System.arraycopy(mb, 0, pb, 0, pb.size)
        }
        val out = IntArray(src.size)
        for (y in 0 until height) {
            val fy = ((y + 0.5f) / cell - 0.5f).coerceIn(0f, (gh - 1).toFloat())
            val y0 = fy.toInt(); val y1 = min(gh - 1, y0 + 1); val ty = fy - y0
            for (x in 0 until width) {
                val fx = ((x + 0.5f) / cell - 0.5f).coerceIn(0f, (gw - 1).toFloat())
                val x0 = fx.toInt(); val x1 = min(gw - 1, x0 + 1); val tx = fx - x0
                fun at(a: FloatArray): Float {
                    val top = a[y0 * gw + x0] * (1 - tx) + a[y0 * gw + x1] * tx
                    val bottom = a[y1 * gw + x0] * (1 - tx) + a[y1 * gw + x1] * tx
                    return (top * (1 - ty) + bottom * ty).coerceAtLeast(40f)
                }
                val c = src[y * width + x]
                val r = (((c shr 16) and 255) * 255f / at(pr) * 1.03f).roundToInt()
                val g = (((c shr 8) and 255) * 255f / at(pg) * 1.03f).roundToInt()
                val b = ((c and 255) * 255f / at(pb) * 1.03f).roundToInt()
                out[y * width + x] = rgb(r, g, b)
            }
        }
        return out
    }

    /** Gris parejo, con la letra oscura. */
    fun grayscale(src: IntArray): IntArray {
        val table = curve((percentile(src, 0.01f) - 10).coerceAtLeast(0), 248, 1.1f)
        return IntArray(src.size) { i -> gray(table[lum(src[i])]) }
    }

    /**
     * Blanco y negro nítido: cada punto se compara con la luz de su zona (así una celda
     * de color o una sombra no quedan negras; solo la letra y las rayas).
     */
    fun blackWhite(src: IntArray, width: Int, height: Int, ink: Int = 0): IntArray {
        val luma = IntArray(src.size) { lum(src[it]) }
        val mean = boxMean(luma, width, height, (min(width, height) / 40).coerceIn(8, 40))
        val inkColor = gray(ink)
        return IntArray(src.size) { i ->
            // Oscuro respecto a su zona (o muy oscuro siempre): tinta.
            if (luma[i] < mean[i] - 18 || luma[i] < 70) inkColor else -1
        }
    }

    /**
     * Ahorro de tinta: solo la letra y las rayas, en gris oscuro; los fondos de color y
     * las manchas quedan blancos.
     */
    fun saver(src: IntArray, width: Int, height: Int): IntArray = blackWhite(src, width, height, ink = 70)

    /** Promedio de luz en un cuadrado de lado 2r+1 (tabla de sumas: una pasada). */
    fun boxMean(values: IntArray, width: Int, height: Int, radius: Int): IntArray {
        val stride = width + 1
        // Con Int alcanza hasta ~8 millones de píxeles (255 × 8M < 2^31).
        val sums = if (values.size < 8_000_000) IntArray(stride * (height + 1)) else null
        val longSums = if (sums == null) LongArray(stride * (height + 1)) else null
        for (y in 0 until height) {
            var row = 0L
            for (x in 0 until width) {
                row += values[y * width + x]
                val at = (y + 1) * stride + x + 1
                if (sums != null) sums[at] = sums[y * stride + x + 1] + row.toInt()
                else longSums!![at] = longSums[y * stride + x + 1] + row
            }
        }
        val out = IntArray(values.size)
        for (y in 0 until height) {
            val y0 = max(0, y - radius)
            val y1 = min(height, y + radius + 1)
            for (x in 0 until width) {
                val x0 = max(0, x - radius)
                val x1 = min(width, x + radius + 1)
                val total = if (sums != null) {
                    (sums[y1 * stride + x1] - sums[y0 * stride + x1] - sums[y1 * stride + x0] + sums[y0 * stride + x0]).toLong()
                } else {
                    longSums!![y1 * stride + x1] - longSums[y0 * stride + x1] - longSums[y1 * stride + x0] + longSums[y0 * stride + x0]
                }
                out[y * width + x] = (total / ((y1 - y0) * (x1 - x0))).toInt()
            }
        }
        return out
    }

    /** Gira la hoja [quarters] cuartos de vuelta a la derecha. Devuelve píxeles, ancho y alto. */
    fun rotate(src: IntArray, width: Int, height: Int, quarters: Int): Triple<IntArray, Int, Int> {
        val q = ((quarters % 4) + 4) % 4
        if (q == 0) return Triple(src, width, height)
        if (q == 2) {
            val out = IntArray(src.size)
            for (i in src.indices) out[src.size - 1 - i] = src[i]
            return Triple(out, width, height)
        }
        val out = IntArray(src.size)
        val nw = height
        for (y in 0 until height) {
            val row = y * width
            for (x in 0 until width) {
                // Derecha: (x, y) → (alto-1-y, x). Izquierda: (x, y) → (y, ancho-1-x).
                if (q == 1) out[x * nw + (height - 1 - y)] = src[row + x]
                else out[(width - 1 - x) * nw + y] = src[row + x]
            }
        }
        return Triple(out, height, width)
    }
}
