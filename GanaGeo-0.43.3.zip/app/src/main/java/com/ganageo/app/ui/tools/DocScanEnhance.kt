package com.ganageo.app.ui.tools

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.ganageo.app.tools.ScanUpscale
import java.io.File
import java.nio.FloatBuffer
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * "Mejorar imágenes" del Escáner: logos, fotos e íconos sacados de la hoja pasan por
 * una IA local (Real-ESRGAN realesr-animevideov3, BSD 3-Clause; la misma de Zeta
 * Paint). Va dentro de la app (1,2 MB) y funciona sin internet.
 *
 * Rápido y sin repetir trabajo:
 *  - Cada pieza mejorada se guarda en el celular (memoria temporal de la app) por su
 *    contenido: la hoja, el PDF, Word y la imagen usan el mismo resultado sin volver
 *    a calcular. Se borra solo lo más viejo si pasa de [CACHE_LIMIT].
 *  - Primero las piezas chicas (íconos: se ven mejor al toque), al final las fotos.
 *  - Una sola mejora a la vez (no se pelean por el procesador) y se puede cancelar.
 *  - Si algo falla, queda la pieza como estaba (nunca rompe la hoja).
 */
internal object DocScanEnhance {
    const val OFF = 0
    const val ORIGINAL = 1
    const val X2 = 2

    private const val ASSET = "models/realesr_anime_x4.onnx"
    private const val CACHE_DIR = "mejorar"
    private const val CACHE_LIMIT = 120L * 1024 * 1024
    /** Pieza x2 más grande que esto (píxeles al final) queda en Original. */
    private const val MAX_OUT_PIXELS = 9_000_000L

    private val lock = Mutex()
    private val sessionLock = Any()
    @Volatile private var session: OrtSession? = null
    @Volatile private var inputName: String = "input"
    @Volatile private var broken = false

    fun label(mode: Int): String = when (mode) {
        ORIGINAL -> "Original"
        X2 -> "x2"
        else -> "Apagado"
    }

    private fun session(context: Context): OrtSession? {
        session?.let { return it }
        if (broken) return null
        synchronized(sessionLock) {
            session?.let { return it }
            if (broken) return null
            return try {
                val bytes = context.applicationContext.assets.open(ASSET).use { it.readBytes() }
                val options = OrtSession.SessionOptions()
                try {
                    options.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                    // Deja un núcleo libre: la pantalla sigue fluida mientras se mejora.
                    options.setIntraOpNumThreads((Runtime.getRuntime().availableProcessors() - 1).coerceIn(1, 3))
                    options.setInterOpNumThreads(1)
                    // La memoria vuelve al sistema entre pedazos.
                    options.setCPUArenaAllocator(false)
                    options.setMemoryPatternOptimization(false)
                    OrtEnvironment.getEnvironment().createSession(bytes, options).also {
                        inputName = it.inputNames.firstOrNull() ?: "input"
                        session = it
                    }
                } finally {
                    options.close()
                }
            } catch (error: Throwable) {
                broken = true
                null
            }
        }
    }

    /** true si la IA no pudo abrirse en este celular (se sigue sin mejorar). */
    fun failed(): Boolean = broken

    /** ¿La IA de mejorar está en este celular? */
    fun available(context: Context): Boolean = session(context) != null

    private class Net(private val session: OrtSession, private val name: String) : ScanUpscale.Model {
        private val env = OrtEnvironment.getEnvironment()
        override fun run(chw: FloatArray, height: Int, width: Int): FloatArray {
            OnnxTensor.createTensor(env, FloatBuffer.wrap(chw), longArrayOf(1, 3, height.toLong(), width.toLong())).use { tensor ->
                session.run(mapOf(name to tensor)).use { result ->
                    val buffer = (result.get(0) as OnnxTensor).floatBuffer
                    val out = FloatArray(buffer.remaining())
                    buffer.get(out)
                    return out
                }
            }
        }
    }

    /** Lado de cada pedazo según la memoria del celular. */
    private fun tileSide(): Int = if (Runtime.getRuntime().maxMemory() >= 384L * 1024 * 1024) 160 else 112

    private fun cacheDir(context: Context) = File(context.applicationContext.cacheDir, CACHE_DIR)

    private fun trimCache(context: Context) {
        val files = cacheDir(context).listFiles()?.filter { it.isFile } ?: return
        var total = files.sumOf { it.length() }
        if (total <= CACHE_LIMIT) return
        for (file in files.sortedBy { it.lastModified() }) {
            if (total <= CACHE_LIMIT * 3 / 4) break
            total -= file.length()
            file.delete()
        }
    }

    /**
     * Hoja con sus piezas mejoradas ([mode] Original o x2). Las piezas nuevas son
     * imágenes nuevas; con [recycleOld] se sueltan las de antes (al guardar).
     * [onProgress] (hechas, total). Devuelve [cleaned] tal cual si la IA no está.
     */
    /**
     * Mejora una imagen entera (por ejemplo el papelote): [ORIGINAL] la limpia y deja
     * más nítida, [X2] además la dobla (si el resultado pasa [maxPixels], queda en
     * Original). [onProgress] (hechos, total). null si no hay IA o se canceló.
     */
    suspend fun enhanceImage(
        context: Context,
        bitmap: Bitmap,
        mode: Int,
        maxPixels: Long,
        onProgress: (Int, Int) -> Unit = { _, _ -> }
    ): Bitmap? = withContext(Dispatchers.Default) {
        if (mode != ORIGINAL && mode != X2) return@withContext null
        if (bitmap.isRecycled || bitmap.width < ScanUpscale.MIN_SIDE || bitmap.height < ScanUpscale.MIN_SIDE) return@withContext null
        lock.withLock {
            val model = session(context) ?: return@withLock null
            val net = Net(model, inputName)
            val job = coroutineContext[Job]
            val width = bitmap.width
            val height = bitmap.height
            val scale = ScanUpscale.safeScale(width, height, mode, maxPixels)
            val pixels = IntArray(width * height)
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
            val out = try {
                ScanUpscale.enhance(pixels, width, height, scale, tileSide(), net) { done, total ->
                    onProgress(done, total)
                    job?.isActive != false
                }
            } catch (error: OutOfMemoryError) {
                null
            }
            coroutineContext.ensureActive()
            out?.let { Bitmap.createBitmap(it, width * scale, height * scale, Bitmap.Config.ARGB_8888) }
        }
    }

    suspend fun apply(
        context: Context,
        cleaned: DocScanCleaned,
        mode: Int,
        recycleOld: Boolean = false,
        onProgress: (Int, Int) -> Unit = { _, _ -> }
    ): DocScanCleaned = withContext(Dispatchers.Default) {
        if (mode != ORIGINAL && mode != X2) return@withContext cleaned
        val targets = cleaned.objects.withIndex()
            .filter { (_, piece) -> !piece.bitmap.isRecycled && piece.bitmap.width >= ScanUpscale.MIN_SIDE && piece.bitmap.height >= ScanUpscale.MIN_SIDE }
            .sortedBy { (_, piece) -> piece.bitmap.width.toLong() * piece.bitmap.height }
        if (targets.isEmpty()) return@withContext cleaned
        lock.withLock {
            val model = session(context) ?: return@withLock cleaned
            val net = Net(model, inputName)
            val job = coroutineContext[Job]
            val folder = cacheDir(context).apply { mkdirs() }
            val replaced = arrayOfNulls<DocScanObject>(cleaned.objects.size)
            var done = 0
            onProgress(0, targets.size)
            for ((index, piece) in targets) {
                coroutineContext.ensureActive()
                val source = piece.bitmap
                val width = source.width
                val height = source.height
                val scale = ScanUpscale.safeScale(width, height, mode, MAX_OUT_PIXELS)
                val pixels = IntArray(width * height)
                source.getPixels(pixels, 0, width, 0, 0, width, height)
                val file = File(folder, "v1_${scale}_${ScanUpscale.fingerprint(pixels, width, height)}.png")
                var better: Bitmap? = null
                if (file.isFile) {
                    better = runCatching {
                        BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 })
                    }.getOrNull()?.takeIf { it.width == width * scale && it.height == height * scale }
                    if (better != null) file.setLastModified(System.currentTimeMillis())
                }
                if (better == null) {
                    val out = try {
                        ScanUpscale.enhance(pixels, width, height, scale, tileSide(), net) { _, _ -> job?.isActive != false }
                    } catch (error: OutOfMemoryError) {
                        null
                    } catch (error: Throwable) {
                        null
                    }
                    coroutineContext.ensureActive()
                    if (out != null) {
                        better = Bitmap.createBitmap(out, width * scale, height * scale, Bitmap.Config.ARGB_8888)
                        runCatching {
                            val temp = File(folder, file.name + ".part")
                            temp.outputStream().use { better.compress(Bitmap.CompressFormat.PNG, 100, it) }
                            temp.renameTo(file)
                        }
                    }
                }
                if (better != null) replaced[index] = DocScanObject(piece.id, piece.rect, better)
                done++
                onProgress(done, targets.size)
            }
            runCatching { trimCache(context) }
            val objects = cleaned.objects.mapIndexed { index, piece ->
                val now = replaced[index]
                if (now == null) piece else {
                    if (recycleOld) piece.bitmap.recycle()
                    now
                }
            }
            DocScanCleaned(cleaned.base, objects, cleaned.shapes, cleaned.rebuilt)
        }
    }
}
