package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanResidueTest {
    private val paper = 0xFFFFFFFF.toInt()
    private val ink = 0xFF0B2545.toInt()

    private fun page(width: Int, height: Int) = IntArray(width * height) { paper }

    private fun fill(pixels: IntArray, width: Int, left: Int, top: Int, right: Int, bottom: Int, color: Int) {
        for (y in top until bottom) for (x in left until right) pixels[y * width + x] = color
    }

    @Test
    fun cajaAngostaSeEstiraHastaElPalitoDeLaLetra() {
        val width = 200
        val height = 60
        val pixels = page(width, height)
        // "P": palito de x=40 a 46; el lector dio la caja desde x=48.
        fill(pixels, width, 40, 10, 46, 50, ink)
        fill(pixels, width, 46, 10, 70, 16, ink)
        fill(pixels, width, 80, 10, 120, 50, ink)
        val wide = ScanResidue.widen(pixels, width, height, intArrayOf(48, 10, 120, 50), ink, paper)
        assertTrue("izquierda=${wide[0]}", wide[0] <= 40)
        assertEquals(120, wide[2])
    }

    @Test
    fun noSeComeUnIconoSeparado() {
        val width = 200
        val height = 60
        val pixels = page(width, height)
        // Ícono a 14 px (más de un hueco) de la caja del texto.
        fill(pixels, width, 20, 15, 34, 45, ink)
        fill(pixels, width, 48, 10, 120, 50, ink)
        val wide = ScanResidue.widen(pixels, width, height, intArrayOf(48, 10, 120, 50), ink, paper)
        assertEquals(48, wide[0])
    }

    @Test
    fun noSeEstiraSobreUnaLineaLarga() {
        val width = 300
        val height = 60
        val pixels = page(width, height)
        // Raya del mismo color que sigue hasta el borde: es un borde, no una letra.
        fill(pixels, width, 0, 28, 100, 32, ink)
        fill(pixels, width, 100, 10, 160, 50, ink)
        val wide = ScanResidue.widen(pixels, width, height, intArrayOf(100, 10, 160, 50), ink, paper)
        assertEquals(100, wide[0])
    }

    @Test
    fun restoPegadoAlRenglonEsResto() {
        val lines = listOf(intArrayOf(100, 10, 400, 50))
        // Palito de 5 px pegado a la izquierda, del color de la letra.
        assertTrue(ScanResidue.isResidue(intArrayOf(93, 12, 98, 48), ink, lines, listOf(ink)))
        // Viñeta separada (a 0.4 del alto): no es resto.
        assertFalse(ScanResidue.isResidue(intArrayOf(76, 25, 84, 33), ink, lines, listOf(ink)))
        // Ícono de otro color pegado: no es resto.
        assertFalse(ScanResidue.isResidue(intArrayOf(80, 12, 98, 48), 0xFF4FC3F7.toInt(), lines, listOf(ink)))
        // Logo más alto que el renglón: no es resto.
        assertFalse(ScanResidue.isResidue(intArrayOf(60, 0, 98, 60), ink, lines, listOf(ink)))
    }

    @Test
    fun colorPrincipalDeLaPieza() {
        val width = 20
        val pixels = page(width, 20)
        fill(pixels, width, 5, 5, 10, 15, ink)
        val color = ScanResidue.mainColor(pixels, width, intArrayOf(0, 0, 20, 20), paper)
        assertEquals(ink, color)
    }

    @Test
    fun bordeDelPapelNoEsPieza() {
        val width = 200
        val height = 200
        val pixels = page(width, height)
        // Franja gris azulada pegada al borde izquierdo (sombra del papel).
        fill(pixels, width, 0, 20, 12, 180, 0xFFC8CCDA.toInt())
        assertTrue(ScanResidue.isPaperEdge(pixels, width, intArrayOf(0, 20, 12, 180), paper, width, height))
        // Logo oscuro en medio de la hoja: sí es pieza.
        fill(pixels, width, 80, 80, 120, 120, ink)
        assertTrue(!ScanResidue.isPaperEdge(pixels, width, intArrayOf(80, 80, 120, 120), paper, width, height))
    }

    @Test
    fun chincheLejosDeLoEscritoNoVa() {
        val content = intArrayOf(100, 200, 900, 1100)
        // Chinche arriba, lejos del texto: fuera.
        assertTrue(ScanResidue.isStray(intArrayOf(480, 20, 520, 60), content, 1000, 1300))
        // Logo pegado al texto: se queda.
        assertTrue(!ScanResidue.isStray(intArrayOf(100, 150, 180, 195), content, 1000, 1300))
        // Algo grande (foto) lejos: se queda.
        assertTrue(!ScanResidue.isStray(intArrayOf(100, 1150, 600, 1290), content, 1000, 1300))
        // Sin nada escrito: no se quita nada.
        assertTrue(!ScanResidue.isStray(intArrayOf(480, 20, 520, 60), null, 1000, 1300))
    }
}
