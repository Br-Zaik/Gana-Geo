package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanToneTest {
    private val white = 0xFFF5F5F5.toInt()
    private fun lum(c: Int) = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000

    @Test
    fun letraGrisLavadaQuedaOscuraYPareja() {
        // Arriba a la izquierda la foto tenía mucha luz: letra gris clarita (130); abajo negra (45).
        val inks = intArrayOf(0xFF828282.toInt(), 0xFF7A7A80.toInt(), 0xFF2D2D2D.toInt(), 0xFF303030.toInt(), 0xFF2A2A2E.toInt())
        val out = ScanTone.inks(inks, IntArray(inks.size) { white })
        assertTrue(out.all { lum(it) <= 55 })
        assertEquals(1, out.toSet().size)
    }

    @Test
    fun letraBlancaSobreBarraOscuraNoSeToca() {
        val inks = intArrayOf(0xFFFFFFFF.toInt(), 0xFF303030.toInt())
        val backs = intArrayOf(0xFF0B2545.toInt(), white)
        val out = ScanTone.inks(inks, backs)
        assertEquals(0xFFFFFFFF.toInt(), out[0])
    }

    @Test
    fun letraDeColorClaraSeOscureceSinPerderSuColor() {
        val blue = 0xFF6FA0E0.toInt()
        val out = ScanTone.inks(intArrayOf(blue), intArrayOf(white))[0]
        assertTrue(lum(out) <= 121)
        assertTrue((out and 255) > ((out shr 16) and 255)) // sigue azul
    }

    @Test
    fun celdasDelMismoColorQuedanIguales() {
        // Amarillo vivo y amarillo lavado (misma celda en dos partes de la foto); verde aparte.
        val fills = listOf(0xFFFFE680.toInt(), 0xFFFFF0B0.toInt(), null, 0xFFA8D8A0.toInt())
        val out = ScanTone.fills(fills)
        assertEquals(0xFFFFE680.toInt(), out[0])
        assertEquals(0xFFFFE680.toInt(), out[1])
        assertEquals(null, out[2])
        assertEquals(0xFFA8D8A0.toInt(), out[3])
    }

    @Test
    fun naranjaYAmarilloNoSeJuntan() {
        val fills = listOf(0xFFFCD5A8.toInt(), 0xFFFFE699.toInt())
        assertEquals(fills, ScanTone.fills(fills))
    }

    @Test
    fun letraTenidaPorLaCeldaQuedaOscura() {
        val yellow = 0xFFFFE699.toInt()
        val tinted = 0xFF8A7A30.toInt()
        val blueInk = 0xFF1F3FBF.toInt()
        val out = ScanTone.inks(intArrayOf(0xFF222222.toInt(), tinted, blueInk), intArrayOf(white, yellow, yellow))
        // Teñida del amarillo: oscura neutra. Azul de verdad sobre amarillo: se queda azul.
        assertTrue(lum(out[1]) <= 60)
        assertEquals((out[1] shr 16) and 255, out[1] and 255)
        assertEquals(blueInk, out[2])
    }
}
