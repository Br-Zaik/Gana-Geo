package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PosterTilesTest {
    private val a4 = PosterTiles.PAPERS[0]

    @Test
    fun franjaSoloEnLasHojasQueRecibenYSinMargenAfuera() {
        val options = PosterTiles.Options(2, 2, a4, landscape = false, borderMm = 0f, overlapMm = 10f, fill = true)
        // Hoja 1: imagen hasta todos sus bordes (sin margen).
        assertEquals(0f, options.leftOf(0), 0.01f)
        assertEquals(0f, options.topOf(0), 0.01f)
        assertEquals(a4.width, options.colWidth(0), 0.01f)
        // Hojas 2 y 4 (derecha): franja de 10 mm a la izquierda; 3 y 4 (abajo): arriba.
        assertEquals(10f * PosterTiles.MM, options.leftOf(1), 0.01f)
        assertEquals(10f * PosterTiles.MM, options.topOf(1), 0.01f)
        assertEquals(a4.width - 10f * PosterTiles.MM, options.colWidth(1), 0.01f)
        val tiles = PosterTiles.tiles(2000, 2800, options)
        assertEquals(listOf("1", "2", "3", "4"), tiles.map { it.label })
        // Las imágenes se juntan sin repetirse: la hoja 2 empieza donde termina la 1.
        assertEquals(tiles[0].source!![2], tiles[1].source!![0], 0.01f)
        assertEquals(tiles[0].source!![3], tiles[2].source!![1], 0.01f)
    }

    @Test
    fun completaDejaBlancoSinCortar() {
        val options = PosterTiles.Options(1, 3, a4, landscape = true, borderMm = 0f, overlapMm = 0f, fill = false)
        val tiles = PosterTiles.tiles(1000, 1000, options)
        assertEquals(0f, tiles.mapNotNull { it.source }.minOf { it[0] }, 0.5f)
        assertEquals(1000f, tiles.mapNotNull { it.source }.maxOf { it[2] }, 0.5f)
    }

    @Test
    fun mejorCuadriculaSegunLaImagen() {
        assertEquals(1 to 2, PosterTiles.bestGrid(2, 3000, 1000, a4, landscape = true))
        assertEquals(2 to 1, PosterTiles.bestGrid(2, 1000, 3000, a4, landscape = false))
        assertEquals(2 to 2, PosterTiles.bestGrid(4, 1000, 1414, a4, landscape = false))
    }

    @Test
    fun tamanoArmado() {
        val options = PosterTiles.Options(2, 2, a4, landscape = false, borderMm = 0f, overlapMm = 10f, fill = true)
        val (w, h) = PosterTiles.sizeCm(options)
        // 21 + (21 − 1) = 41 cm; 29,7 + (29,7 − 1) = 58,4 cm.
        assertEquals(41f, w, 0.1f)
        assertEquals(58.4f, h, 0.1f)
        assertTrue(PosterTiles.dpi(3000, 4000, options) in 120..220)
        assertEquals("AA1", PosterTiles.label(26, 0))
    }

    @Test
    fun hojaSinImagenQuedaEnBlanco() {
        val options = PosterTiles.Options(1, 4, a4, landscape = true, borderMm = 0f, overlapMm = 0f, fill = false)
        // Imagen alta en un papelote muy ancho: las hojas de los costados quedan blancas.
        val tiles = PosterTiles.tiles(500, 2000, options)
        assertNull(tiles.first().source)
    }
}
