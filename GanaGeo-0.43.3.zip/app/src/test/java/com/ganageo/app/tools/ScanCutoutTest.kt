package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanCutoutTest {
    @Test
    fun bordeSuaveSinAureola() {
        val w = 20
        val h = 20
        val paper = (0xFF shl 24) or (240 shl 16) or (240 shl 8) or 240
        val red = (0xFF shl 24) or (200 shl 16) or (20 shl 8) or 20
        // Cuadrado rojo de 6..13 con un borde mitad rojo, mitad papel.
        fun mix(t: Float): Int {
            val r = (200 * t + 240 * (1 - t)).toInt()
            val g = (20 * t + 240 * (1 - t)).toInt()
            return (0xFF shl 24) or (r shl 16) or (g shl 8) or g
        }
        val px = IntArray(w * h) { i ->
            val x = i % w
            val y = i / w
            when {
                x in 6..13 && y in 6..13 -> red
                x == 5 && y in 6..13 -> mix(0.5f)
                else -> paper
            }
        }
        val (piece, mask) = ScanObjects.cutout(px, w, intArrayOf(0, 0, w, h), paper)
        // Adentro: rojo opaco.
        assertEquals(red, piece[10 * w + 10])
        // Borde mezclado: medio transparente y de color rojo (sin el gris del papel).
        val edge = piece[10 * w + 5]
        val a = edge ushr 24
        assertTrue("alfa $a", a in 60..230)
        assertTrue("rojo limpio", ((edge shr 16) and 255) in 185..215 && ((edge shr 8) and 255) < 60)
        // Papel lejos: transparente y no se borra.
        assertEquals(0, piece[0])
        assertEquals(0.toByte(), mask[0])
    }
}
