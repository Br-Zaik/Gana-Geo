package com.ganageo.app.tools

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

class ScanDocxFlowTest {
    private fun box(x: Float, y: Float, w: Float, text: String, size: Float = 11f, align: String = "left") =
        ScanDocx.TextBox(x, y, w, size * 1.3f, listOf(text), "Arial", size, false, false, 0xFF222222.toInt(), align, size * 1.2f)

    private fun png(): ByteArray {
        val image = java.awt.image.BufferedImage(60, 60, java.awt.image.BufferedImage.TYPE_INT_ARGB)
        val g = image.createGraphics()
        g.color = java.awt.Color(31, 78, 121)
        g.fillOval(4, 4, 52, 52)
        g.dispose()
        val out = ByteArrayOutputStream()
        javax.imageio.ImageIO.write(image, "png", out)
        return out.toByteArray()
    }

    private fun sample(): List<ScanDocx.Page> {
        val cells = listOf(
            ScanDocx.TableCell(0, 0, 1, "HORAS", true, false, 0xFF000000.toInt(), "center", 0xFFFFE699.toInt()),
            ScanDocx.TableCell(0, 1, 1, "LUNES", true, false, 0xFF000000.toInt(), "center", null),
            ScanDocx.TableCell(1, 0, 1, "8:00", false, false, 0xFF000000.toInt(), "center", null),
            ScanDocx.TableCell(1, 1, 1, "Educación & <Arte>", false, false, 0xFF000000.toInt(), "center", 0xFF9FE2BF.toInt())
        )
        val rules = listOf(listOf(true, true), listOf(true, true), listOf(true, true))
        val table = ScanDocx.Table(60f, 200f, listOf(120f, 200f), listOf(20f, 20f), cells, "Arial", 10f, 0xFF000000.toInt(), 0.75f, rules, rules)
        val page = ScanDocx.Page(
            595f, 842f,
            shapes = listOf(ScanDocx.Shape(40f, 120f, 515f, 30f, 0xFF1F4E79.toInt())),
            images = listOf(ScanDocx.Image(png(), true, 40f, 40f, 60f, 60f)),
            boxes = listOf(
                box(120f, 50f, 400f, "INSTITUTO DE EDUCACIÓN SUPERIOR", 14f, "center"),
                box(60f, 125f, 470f, "HORARIO GENERAL 2026 - II", 12f, "center"),
                box(60f, 400f, 470f, "Docentes: Ing. Antonio Barrionuevo")
            ),
            tables = listOf(table)
        )
        return listOf(page, page)
    }

    private fun documentXml(bytes: ByteArray): String {
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.name == "word/document.xml") return zip.readBytes().toString(Charsets.UTF_8)
            }
        }
        error("sin document.xml")
    }

    @Test
    fun wordEditableSinCuadrosFlotantesYBienFormado() {
        val out = ByteArrayOutputStream()
        ScanDocx.writeFlow(out, sample())
        System.getenv("DOCX_OUT")?.let { java.io.File(it).writeBytes(out.toByteArray()) }
        val xml = documentXml(out.toByteArray())
        // XML válido (si no, Word no lo abre).
        DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }.newDocumentBuilder()
            .parse(ByteArrayInputStream(xml.toByteArray(Charsets.UTF_8)))
        assertFalse(xml.contains("txbx"))
        assertFalse(xml.contains("wp:anchor"))
        assertFalse(xml.contains("tblpPr"))
        assertTrue(xml.contains("wp:inline"))
        assertTrue(xml.contains("Educación &amp; &lt;Arte&gt;"))
        assertTrue(xml.contains("w:fill=\"1F4E79\""))
    }

    @Test
    fun wordFielSigueIgual() {
        val out = ByteArrayOutputStream()
        ScanDocx.write(out, sample())
        System.getenv("DOCX_FIEL")?.let { java.io.File(it).writeBytes(out.toByteArray()) }
        val xml = documentXml(out.toByteArray())
        DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }.newDocumentBuilder()
            .parse(ByteArrayInputStream(xml.toByteArray(Charsets.UTF_8)))
        assertTrue(xml.contains("txbx"))
    }
}
