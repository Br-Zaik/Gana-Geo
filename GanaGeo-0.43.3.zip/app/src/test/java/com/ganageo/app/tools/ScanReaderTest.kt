package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

class ScanReaderTest {
    private fun steps(vararg best: Int, classes: Int): FloatArray {
        val out = FloatArray(best.size * classes)
        for ((t, c) in best.withIndex()) {
            for (k in 0 until classes) out[t * classes + k] = 0.02f
            out[t * classes + c] = 1f - 0.02f * (classes - 1)
        }
        return out
    }

    @Test
    fun leeConVaciosRepetidosYEspacio() {
        val dict = listOf("a", "b", "c")
        // 0 = vacío, 4 = espacio (dict + 2 clases).
        val read = ScanReader.decode(steps(1, 1, 0, 2, 4, 3, 3, classes = 5), 7, 5, dict)!!
        assertEquals("ab c", read.text)
        assertTrue(read.confidence > 0.8f)
    }

    @Test
    fun salidaQueNoCalzaConElDiccionarioNoSeUsa() {
        assertNull(ScanReader.decode(FloatArray(20), 2, 10, listOf("a", "b")))
    }

    @Test
    fun entradaAzulVerdeRojoYAnchoProporcional() {
        val red = (0xFF shl 24) or (255 shl 16)
        val input = ScanReader.prepare(IntArray(100 * 20) { red }, 100, 20, 48)
        assertEquals(48, input.height)
        assertEquals(240, input.width)
        val plane = input.width * input.height
        assertEquals(-1f, input.data[0], 0.01f) // azul
        assertEquals(1f, input.data[2 * plane], 0.01f) // rojo
    }

    @Test
    fun palabrasDudosas() {
        val known = setOf("horario", "general")
        assertTrue(ScanReader.doubtful("Hrario", known::contains))
        assertFalse(ScanReader.doubtful("HORARIO", known::contains))
        assertFalse(ScanReader.doubtful("RUC", known::contains))
        assertFalse(ScanReader.doubtful("2026", known::contains))
        assertFalse(ScanReader.doubtful("de", known::contains))
    }

    @Test
    fun cambiaSoloLaPalabraEntera() {
        assertEquals("MANEJO Y CONTROL", ScanReader.replaceWord("MANEJ OY CONTROL", "MANEJ OY", "MANEJO Y"))
        assertEquals("el sol y la sal", ScanReader.replaceWord("el sol y la sl", "sl", "sal"))
        assertNull(ScanReader.replaceWord("solamente", "sol", "luz"))
    }

    @Test
    fun cajasDePalabrasRepartidas() {
        val boxes = ScanReader.wordBoxes("ab cd", 0, 50)
        assertEquals(2, boxes.size)
        assertTrue(boxes[0].second[2] <= boxes[1].second[0])
        assertEquals(50, boxes[1].second[2])
    }

    @Test
    fun mallaIgualDejaLaFotoIgual() {
        val w = 30
        val h = 20
        val src = IntArray(w * h) { (0xFF shl 24) or ((it * 7) and 0xFFFFFF) }
        val gw = 4
        val gh = 3
        val grid = FloatArray(2 * gw * gh)
        for (y in 0 until gh) for (x in 0 until gw) {
            grid[y * gw + x] = -1f + 2f * x / (gw - 1)
            grid[gw * gh + y * gw + x] = -1f + 2f * y / (gh - 1)
        }
        val out = ScanUnwarp.sampleGrid(src, w, h, grid, gw, gh)
        var same = 0
        for (i in src.indices) if (src[i] == out[i]) same++
        assertTrue(same > src.size * 0.95f)
    }

    @Test
    fun imagenDeSalidaAColor() {
        val w = 2
        val h = 1
        // Azul, verde, rojo (0..1).
        val data = floatArrayOf(0f, 0f, 0f, 0f, 1f, 1f)
        val out = ScanUnwarp.image(data, w, h)
        assertEquals((0xFF shl 24) or (255 shl 16), out[0])
    }

    @Test
    fun rayasDobladasSeMidenMasQueDerechas() {
        val w = 600
        val h = 800
        fun sheet(curve: Float): IntArray {
            val px = IntArray(w * h) { -1 }
            for (k in 1..9) {
                val base = k * 80
                for (x in 20 until w - 20) {
                    val y = (base + curve * sin(x / (w - 40f) * Math.PI).toFloat()).toInt()
                    for (t in 0..1) if (y + t in 0 until h) px[(y + t) * w + x] = (0xFF shl 24)
                }
            }
            return px
        }
        val straight = ScanPhoto.bend(sheet(0f), w, h)
        val bent = ScanPhoto.bend(sheet(25f), w, h)
        assertTrue("derecha $straight doblada $bent", bent > straight + 1f)
        assertTrue(ScanUnwarp.better(bent, straight, 0.5f, 0.5f))
        assertFalse(ScanUnwarp.better(bent, bent * 0.9f, 0.5f, 0.5f))
    }
}
