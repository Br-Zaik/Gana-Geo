package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanFiltersTest {
    private fun lum(c: Int) = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    /** Hoja de 200×200: papel con luz que baja de izquierda a derecha, una raya de letra y una celda amarilla. */
    private fun sheet(): IntArray {
        val w = 200
        return IntArray(w * w) { i ->
            val x = i % w
            val y = i / w
            val light = 235 - x * 60 / w
            when {
                y in 40..44 && x in 20..180 -> rgb(40, 40, 50)
                x in 120..180 && y in 100..160 -> rgb(light, light * 85 / 100, light * 35 / 100)
                else -> rgb(light, light, light + 8 coerceAtMost 255)
            }
        }
    }

    private infix fun Int.coerceAtMost(max: Int) = if (this > max) max else this

    @Test
    fun sinSombraDejaElPapelBlancoYGuardaLaCelda() {
        val src = sheet()
        val out = ScanFilters.whiten(src, 200, 200)
        // Papel a la izquierda y a la derecha (con sombra): los dos blancos.
        assertTrue(lum(out[70 * 200 + 10]) >= 250)
        assertTrue(lum(out[70 * 200 + 110]) >= 245)
        // Letra: oscura.
        assertTrue(lum(out[42 * 200 + 100]) < 70)
        // Celda amarilla: sigue amarilla (no se vuelve blanca).
        val cell = out[130 * 200 + 150]
        val r = (cell shr 16) and 255
        val b = cell and 255
        assertTrue("celda $r/$b", r - b > 80)
    }

    @Test
    fun blancoYNegroSoloLetra() {
        val out = ScanFilters.blackWhite(sheet(), 200, 200)
        assertEquals(0xFF000000.toInt(), out[42 * 200 + 100])
        assertEquals(-1, out[70 * 200 + 10])
        // El centro de la celda de color no queda negro.
        assertEquals(-1, out[130 * 200 + 150])
    }

    @Test
    fun todosLosFiltrosDanElMismoTamano() {
        val src = sheet()
        for (kind in ScanFilters.ALL) {
            assertEquals(src.size, ScanFilters.apply(kind, src, src, 200, 200).size)
        }
        assertEquals(5, ScanFilters.ALL.size)
    }

    @Test
    fun girarCuatroVecesVuelveIgual() {
        val w = 3
        val h = 2
        val src = IntArray(w * h) { it }
        val right = ScanFilters.rotate(src, w, h, 1)
        assertEquals(2, right.second)
        assertEquals(3, right.third)
        // Arriba-izquierda tras girar a la derecha = abajo-izquierda de antes.
        assertEquals(src[(h - 1) * w], right.first[0])
        var cur = Triple(src, w, h)
        repeat(4) { cur = ScanFilters.rotate(cur.first, cur.second, cur.third, 1) }
        assertTrue(cur.first.contentEquals(src))
        val left = ScanFilters.rotate(src, w, h, -1)
        val back = ScanFilters.rotate(left.first, left.second, left.third, 1)
        assertTrue(back.first.contentEquals(src))
    }

    @Test
    fun recorteManualGuardaCopiaSinLuz() {
        val w = 120
        val h = 160
        val src = IntArray(w * h) { rgb(200, 205, 230) }
        val quad = ScanPhoto.Quad(floatArrayOf(10f, 10f, 110f, 10f, 110f, 150f, 10f, 150f), "recorte")
        val result = ScanPhoto.flattenWith(src, w, h, quad, "manual", 2400, light = true, keepPlain = true)
        val plain = result.plain!!
        assertEquals(result.pixels.size, plain.size)
        // La copia sin luz conserva el tono azulado; la otra queda más blanca.
        assertTrue(lum(result.pixels[result.pixels.size / 2]) >= lum(plain[plain.size / 2]))
    }
}
