package com.ganageo.app.ui.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.BorderOuter
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Collections
import androidx.compose.material.icons.rounded.CropLandscape
import androidx.compose.material.icons.rounded.CropPortrait
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.ViewModule
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.PosterTiles
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------
// Papelote en hojas: una imagen grande repartida en varias hojas para imprimir
// en casa, cortar y pegar (para exposiciones). Gratis y sin internet.
// ---------------------------------------------------------------------------

/** Lado mayor con que se abre la imagen (nítida en papelotes grandes, sin gastar memoria de más). */
private const val POSTER_EDGE = 4000

/** Puntos por pulgada máximos que se guardan en el PDF (más no se nota al imprimir). */
private const val POSTER_MAX_DPI = 220f

private val SHEET_CHOICES = listOf(2, 3, 4, 6, 8, 9, 12, 16)

/** Abre la imagen (o la 1.ª página de un PDF) con su lado mayor ≤ [edge]. */
private fun posterLoad(context: Context, uri: Uri, edge: Int): Bitmap {
    val type = runCatching { context.contentResolver.getType(uri) }.getOrNull().orEmpty()
    if (type == "application/pdf" || uri.toString().lowercase().endsWith(".pdf")) {
        val descriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: error("No se pudo abrir el PDF.")
        descriptor.use { fd ->
            PdfRenderer(fd).use { renderer ->
                if (renderer.pageCount == 0) error("El PDF no tiene páginas.")
                renderer.openPage(0).use { page ->
                    val scale = edge / max(page.width, page.height).toFloat()
                    val w = (page.width * scale).roundToInt().coerceAtLeast(1)
                    val h = (page.height * scale).roundToInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    return bitmap
                }
            }
        }
    }
    return ToolFileUtils.loadBitmap(context, uri, edge)
}

/** Hoja guía (va al final): el papelote armado con el número de cada hoja y los pasos. */
private fun drawGuide(canvas: android.graphics.Canvas, bitmap: Bitmap, options: PosterTiles.Options, tiles: List<PosterTiles.Tile>) {
    val sheetW = options.sheetWidth
    val sheetH = options.sheetHeight
    val placement = PosterTiles.place(bitmap.width, bitmap.height, options)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    val text = Paint(Paint.ANTI_ALIAS_FLAG)
    val (cmW, cmH) = PosterTiles.sizeCm(options)
    canvas.drawColor(android.graphics.Color.WHITE)
    val m = 36f
    text.textSize = 18f
    text.isFakeBoldText = true
    text.color = android.graphics.Color.rgb(20, 20, 20)
    canvas.drawText("Cómo armar tu papelote", m, m + 14f, text)
    text.isFakeBoldText = false
    text.textSize = 11f
    text.color = android.graphics.Color.rgb(70, 70, 70)
    canvas.drawText("${tiles.size} hojas · armado mide ${"%.0f".format(cmW)} × ${"%.0f".format(cmH)} cm", m, m + 32f, text)
    val boxTop = m + 48f
    val boxH = sheetH * 0.5f
    val k = min((sheetW - 2 * m) / options.posterWidth, boxH / options.posterHeight)
    val ox = (sheetW - options.posterWidth * k) / 2f
    val oy = boxTop
    canvas.save()
    canvas.clipRect(ox, oy, ox + options.posterWidth * k, oy + options.posterHeight * k)
    canvas.drawBitmap(bitmap, null, RectF(ox + placement.x * k, oy + placement.y * k, ox + (placement.x + placement.width) * k, oy + (placement.y + placement.height) * k), paint)
    canvas.restore()
    val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = android.graphics.Color.rgb(230, 40, 60)
    }
    val tag = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 20f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
        color = android.graphics.Color.rgb(200, 20, 40)
    }
    val tagBack = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.argb(220, 255, 255, 255) }
    for (tile in tiles) {
        val l = ox + tile.left * k
        val t = oy + tile.top * k
        canvas.drawRect(l, t, l + tile.width * k, t + tile.height * k, grid)
        val cx = l + tile.width * k / 2f
        val cy = t + tile.height * k / 2f
        canvas.drawCircle(cx, cy - 6f, 15f, tagBack)
        canvas.drawText(tile.label, cx, cy + 1f, tag)
    }
    var y = oy + options.posterHeight * k + 30f
    text.textSize = 13f
    text.isFakeBoldText = true
    text.color = android.graphics.Color.rgb(20, 20, 20)
    canvas.drawText("Pasos", m, y, text)
    text.isFakeBoldText = false
    text.textSize = 10f
    val steps = buildList {
        add("1. Imprime en \"Tamaño real\" o al 100 %. No uses \"Ajustar a la página\".")
        if (options.glue > 0f) {
            add("2. Las hojas de la derecha y de abajo tienen una franja blanca que dice \"pega aquí\"")
            add("    y el número de la hoja que va encima. Pon pegamento en la franja.")
            add("3. Pon encima esa hoja, juntando bien la imagen con la línea roja, y presiona.")
        } else {
            add("2. Junta las hojas borde con borde y pégalas por detrás con cinta.")
        }
        add("${if (options.glue > 0f) 4 else 3}. Orden: 1, 2, 3… de izquierda a derecha y de arriba abajo, como en el dibujo.")
        if (options.border > 0f) add("    Si queda una rayita blanca en el borde donde se juntan, córtala.")
    }
    for (line in steps) {
        y += 17f
        if (y > sheetH - m) break
        canvas.drawText(line, m, y, text)
    }
}

/**
 * Una hoja (medidas en puntos): su pedazo de imagen hasta el borde, y si recibe a
 * otra hoja (izquierda o arriba), la franja blanca para pegar con el número de la
 * hoja que va encima y una línea roja donde se junta la imagen. Los bordes de afuera
 * del papelote y los lados que van encima de otra hoja no llevan nada.
 */
private fun drawSheet(canvas: android.graphics.Canvas, bitmap: Bitmap, options: PosterTiles.Options, tile: PosterTiles.Tile) {
    val sheetW = options.sheetWidth
    val sheetH = options.sheetHeight
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    canvas.drawColor(android.graphics.Color.WHITE)
    val originX = options.leftOf(tile.col)
    val originY = options.topOf(tile.row)
    val source = tile.source
    val target = tile.target
    if (source != null && target != null) {
        val src = android.graphics.Rect(
            source[0].toInt().coerceIn(0, bitmap.width - 1), source[1].toInt().coerceIn(0, bitmap.height - 1),
            source[2].roundToInt().coerceIn(1, bitmap.width), source[3].roundToInt().coerceIn(1, bitmap.height)
        )
        if (src.width() > 0 && src.height() > 0) {
            val dst = RectF(originX + target[0], originY + target[1], originX + target[2], originY + target[3])
            // El pedazo, a lo más ~220 puntos por pulgada (el archivo no pesa de más).
            val maxW = (dst.width() / 72f * POSTER_MAX_DPI).roundToInt().coerceAtLeast(1)
            val maxH = (dst.height() / 72f * POSTER_MAX_DPI).roundToInt().coerceAtLeast(1)
            var piece = Bitmap.createBitmap(bitmap, src.left, src.top, src.width(), src.height())
            if (piece.width > maxW * 1.15f || piece.height > maxH * 1.15f) {
                val scaled = Bitmap.createScaledBitmap(piece, min(piece.width, maxW), min(piece.height, maxH), true)
                if (piece !== bitmap) piece.recycle()
                piece = scaled
            }
            canvas.drawBitmap(piece, null, dst, paint)
            if (piece !== bitmap) piece.recycle()
        }
    }
    val glue = options.glue
    if (glue > 0f) {
        val hatch = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.6f
            color = android.graphics.Color.rgb(235, 200, 205)
        }
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1f
            color = android.graphics.Color.rgb(220, 30, 50)
            pathEffect = DashPathEffect(floatArrayOf(4f, 3f), 0f)
        }
        val name = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
            color = android.graphics.Color.rgb(200, 20, 40)
        }
        /** Franja blanca rayada: "pega aquí" y el número de la hoja que va encima. */
        fun tab(l: Float, t: Float, r: Float, b: Float, neighbor: Int, vertical: Boolean) {
            canvas.save()
            canvas.clipRect(l, t, r, b)
            var d = -(b - t)
            while (d < (r - l) + (b - t)) {
                canvas.drawLine(l + d, b, l + d + (b - t), t, hatch)
                d += 8f
            }
            canvas.restore()
            val thick = if (vertical) r - l else b - t
            name.textSize = (thick * 0.38f).coerceIn(6f, 14f)
            val words = "pega aquí la hoja $neighbor"
            val along = if (vertical) b - t else r - l
            for (frac in floatArrayOf(0.25f, 0.75f)) {
                canvas.save()
                if (vertical) {
                    val cx = (l + r) / 2f
                    val cy = t + along * frac
                    canvas.rotate(-90f, cx, cy)
                    canvas.drawText(words, cx, cy + name.textSize * 0.35f, name)
                } else {
                    val cx = l + along * frac
                    val cy = (t + b) / 2f
                    canvas.drawText(words, cx, cy + name.textSize * 0.35f, name)
                }
                canvas.restore()
            }
        }
        val imageRight = sheetW - options.border
        val imageBottom = sheetH - options.border
        if (tile.col > 0) {
            // Franja a la izquierda: aquí va encima la hoja de la izquierda.
            tab(0f, if (tile.row > 0) glue else 0f, glue, imageBottom, tile.number - 1, vertical = true)
            canvas.drawLine(glue, originY, glue, imageBottom, edge)
        }
        if (tile.row > 0) {
            // Franja arriba: aquí va encima la hoja de arriba.
            tab(if (tile.col > 0) glue else 0f, 0f, imageRight, glue, tile.number - options.cols, vertical = false)
            canvas.drawLine(originX, glue, imageRight, glue, edge)
        }
        if (tile.col > 0 && tile.row > 0) {
            // Esquina: va debajo de las dos (solo rayada).
            canvas.save()
            canvas.clipRect(0f, 0f, glue, glue)
            var d = -glue
            while (d < glue * 2) { canvas.drawLine(d, glue, d + glue, 0f, hatch); d += 8f }
            canvas.restore()
        }
    }
    // Su número, chiquito, en una esquina que queda tapada o al borde.
    val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 9f
        isFakeBoldText = true
        color = android.graphics.Color.rgb(200, 20, 40)
    }
    val mark = "${tile.number}"
    if (glue > 0f && (tile.col > 0 || tile.row > 0)) {
        canvas.drawText(mark, 3f, 11f, text)
    } else {
        // Hoja 1 (o sin franja): el número va muy chico atrás de la esquina, casi no se ve.
        text.textSize = 7f
        text.color = android.graphics.Color.argb(150, 255, 255, 255)
        canvas.drawText(mark, sheetW - options.border - 8f, sheetH - options.border - 3f, text)
    }
}

/** El PDF: una hoja por pedazo (hoja 1 = página 1) y al final la guía. */
private fun posterWritePdf(bitmap: Bitmap, options: PosterTiles.Options, output: OutputStream, onProgress: (Float) -> Unit) {
    val document = PdfDocument()
    try {
        val w = options.sheetWidth.roundToInt()
        val h = options.sheetHeight.roundToInt()
        val tiles = PosterTiles.tiles(bitmap.width, bitmap.height, options)
        tiles.forEachIndexed { index, tile ->
            val page = document.startPage(PdfDocument.PageInfo.Builder(w, h, index + 1).create())
            drawSheet(page.canvas, bitmap, options, tile)
            document.finishPage(page)
            onProgress((index + 1) / tiles.size.toFloat())
        }
        document.startPage(PdfDocument.PageInfo.Builder(w, h, tiles.size + 1).create()).also { page ->
            drawGuide(page.canvas, bitmap, options, tiles)
            document.finishPage(page)
        }
        document.writeTo(output)
    } finally {
        document.close()
    }
}

/** Las mismas hojas como imágenes JPG (200 ppp), una por archivo, en la carpeta elegida. */
private fun posterWriteImages(context: Context, tree: Uri, bitmap: Bitmap, options: PosterTiles.Options, onProgress: (Float) -> Unit): Int {
    val folder = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, tree) ?: error("No se pudo abrir la carpeta.")
    val k = 200f / 72f
    val w = (options.sheetWidth * k).roundToInt()
    val h = (options.sheetHeight * k).roundToInt()
    val tiles = PosterTiles.tiles(bitmap.width, bitmap.height, options)
    val total = tiles.size + 1
    val stamp = java.text.SimpleDateFormat("HHmmss", java.util.Locale.ROOT).format(java.util.Date())
    var saved = 0
    for (index in 0 until total) {
        val sheet = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        try {
            val canvas = android.graphics.Canvas(sheet)
            canvas.scale(k, k)
            val name = if (index == tiles.size) {
                drawGuide(canvas, bitmap, options, tiles)
                "papelote_${stamp}_guia.jpg"
            } else {
                val tile = tiles[index]
                drawSheet(canvas, bitmap, options, tile)
                "papelote_${stamp}_hoja_${tile.number}.jpg"
            }
            val file = folder.createFile("image/jpeg", name) ?: error("No se pudo crear $name.")
            context.contentResolver.openOutputStream(file.uri)?.use { sheet.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                ?: error("No se pudo guardar $name.")
            saved++
        } finally {
            sheet.recycle()
        }
        onProgress((index + 1) / total.toFloat())
    }
    return saved
}

/** Botón chico con ícono y una palabra (elegido = verde). */
@Composable
private fun PosterChoice(icon: ImageVector?, label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) NeonGreen else Color(0x14FFFFFF))
            .border(1.dp, if (selected) NeonGreen else Color(0x33FFFFFF), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        if (icon != null) Icon(icon, contentDescription = null, tint = if (selected) DeepGreen else NeonGreen, modifier = Modifier.size(22.dp))
        Text(
            label,
            color = if (selected) DeepGreen else MaterialTheme.colorScheme.onSurface,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

/** Tarjeta con ícono y título corto. */
@Composable
private fun PosterSection(icon: ImageVector, title: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(icon, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            content()
        }
    }
}

/** Imagen lista para guardar, mejorada si se pidió (si la IA no está, la normal). */
private suspend fun posterPrepare(
    context: Context,
    uri: Uri,
    enhance: Int,
    onStep: (String, Float?) -> Unit
): Bitmap {
    fun load(edge: Int): Bitmap = try {
        posterLoad(context, uri, edge)
    } catch (error: OutOfMemoryError) {
        System.gc()
        posterLoad(context, uri, min(edge, 2500))
    }
    if (enhance == DocScanEnhance.OFF) return load(POSTER_EDGE)
    // Tamaño de entrada para que el resultado no pase de ~12 millones de puntos.
    val limit = if (enhance == DocScanEnhance.X2) POSTER_X2_PIXELS / 4 else POSTER_CLEAN_PIXELS
    val probe = load(1000)
    val ratio = max(probe.width, probe.height) / min(probe.width, probe.height).coerceAtLeast(1).toFloat()
    probe.recycle()
    val edge = kotlin.math.sqrt(limit * ratio.toDouble()).toInt().coerceIn(600, POSTER_EDGE)
    val base = load(edge)
    onStep("Mejorando", 0f)
    val better = DocScanEnhance.enhanceImage(context, base, enhance, POSTER_X2_PIXELS) { done, total ->
        onStep("Mejorando", done / total.coerceAtLeast(1).toFloat())
    }
    return if (better != null) {
        base.recycle()
        better
    } else {
        base
    }
}

/** Puntos máximos de la imagen mejorada x2 (memoria del celular). */
private const val POSTER_X2_PIXELS = 12_000_000L

/** Puntos máximos al solo mejorar (sin agrandar): tarda menos. */
private const val POSTER_CLEAN_PIXELS = 6_000_000L

@Composable
fun PosterTilesScreen(tool: ToolId, onBack: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf<Uri?>(null) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(false) }
    var sheets by rememberSaveable { mutableStateOf(4) }
    var landscape by rememberSaveable { mutableStateOf(false) }
    var paperIndex by rememberSaveable { mutableStateOf(0) }
    var fill by rememberSaveable { mutableStateOf(true) }
    var overlapMm by rememberSaveable { mutableStateOf(10f) }
    var borderMm by rememberSaveable { mutableStateOf(0f) }
    var enhance by rememberSaveable { mutableStateOf(DocScanEnhance.OFF) }
    // Forma elegida (filas × columnas) entre las que dan esa cantidad de hojas.
    var gridChoice by rememberSaveable { mutableStateOf(-1) }
    var working by remember { mutableStateOf<Pair<String, Float?>?>(null) }
    // Lado mayor de la imagen original (hasta 4000 px), para saber qué tan nítida sale.
    var fullLong by remember { mutableStateOf(POSTER_EDGE) }

    val paper = PosterTiles.PAPERS[paperIndex]
    val image = preview
    val grids = remember(sheets) { (1..sheets).filter { sheets % it == 0 }.map { it to sheets / it } }
    val auto = if (image != null) PosterTiles.bestGrid(sheets, image.width, image.height, paper, landscape) else grids.first()
    val grid = grids.getOrNull(gridChoice) ?: auto
    val options = PosterTiles.Options(grid.first, grid.second, paper, landscape, borderMm, overlapMm, fill)

    // Nitidez del papelote con la imagen que se usará (x2 la duplica, hasta su límite).
    val dpi = if (image == null) 0 else {
        val ratio = max(image.width, image.height) / min(image.width, image.height).coerceAtLeast(1).toFloat()
        val x2Long = kotlin.math.sqrt(POSTER_X2_PIXELS * ratio.toDouble()).toInt()
        val long = when (enhance) {
            DocScanEnhance.X2 -> min(fullLong * 2, x2Long)
            else -> fullLong
        }
        val grow = long / max(image.width, image.height).coerceAtLeast(1).toFloat()
        PosterTiles.dpi((image.width * grow).roundToInt(), (image.height * grow).roundToInt(), options)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        source = uri
        loading = true
        scope.launch {
            val opened = runCatching { withContext(Dispatchers.IO) { posterLoad(context, uri, 1400) } }
            fullLong = runCatching {
                withContext(Dispatchers.IO) {
                    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
                    val long = max(bounds.outWidth, bounds.outHeight)
                    if (long > 0) min(long, POSTER_EDGE) else POSTER_EDGE
                }
            }.getOrDefault(POSTER_EDGE)
            loading = false
            opened.onSuccess { preview = it; gridChoice = -1 }
                .onFailure { onMessage(it.message ?: "No se pudo abrir esa imagen.") }
        }
    }

    // Guardar (PDF o imágenes): prepara la imagen (y la mejora si se pidió) y arma las hojas.
    fun save(write: suspend (Bitmap, PosterTiles.Options) -> String) {
        val input = source ?: return
        val chosen = options
        val quality = enhance
        working = "Preparando" to null
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val full = posterPrepare(context, input, quality) { step, progress -> scope.launch { working = step to progress } }
                    try {
                        write(full, chosen)
                    } finally {
                        full.recycle()
                    }
                }
            }
            working = null
            result.onSuccess { onMessage(it) }.onFailure { onMessage(it.message ?: "No se pudo guardar.") }
        }
    }
    val pdfSaver = rememberLauncherForActivityResult(TrackedCreateDocument("application/pdf")) { target ->
        if (target == null) return@rememberLauncherForActivityResult
        save { full, chosen ->
            scope.launch { working = "Armando el PDF" to 0f }
            val stream = context.contentResolver.openOutputStream(target, "w") ?: error("No se pudo guardar.")
            stream.use { out -> posterWritePdf(full, chosen, out) { p -> scope.launch { working = "Armando el PDF" to p } } }
            "PDF listo: ${chosen.rows * chosen.cols} hojas y al final la guía."
        }
    }
    val imageSaver = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if (tree == null) return@rememberLauncherForActivityResult
        save { full, chosen ->
            scope.launch { working = "Guardando imágenes" to 0f }
            val count = posterWriteImages(context, tree, full, chosen) { p -> scope.launch { working = "Guardando imágenes" to p } }
            "$count imágenes guardadas (una por hoja y la guía)."
        }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Gratis · tu imagen en varias hojas para pegar", onBack)
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                if (image == null) {
                    // Sin imagen: un botón grande.
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(CardGreen)
                            .border(2.dp, NeonGreen.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                            .clickable { picker.launch(arrayOf("image/*", "application/pdf")) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        if (loading) LinearProgressIndicator(modifier = Modifier.padding(horizontal = 40.dp).fillMaxWidth())
                        else {
                            Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(56.dp))
                            Text("Elegir imagen", fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(top = 8.dp))
                            Text("foto · dibujo · PDF", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        }
                    }
                } else {
                    // Vista previa: el papelote con cada hoja (A1, A2…) y la franja para pegar.
                    val (cmW, cmH) = PosterTiles.sizeCm(options)
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(300.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF15261D))
                            ) {
                                PosterPreview(image, options)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Rounded.Straighten, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(18.dp))
                                Text("${"%.0f".format(cmW)} × ${"%.0f".format(cmH)} cm", fontWeight = FontWeight.Bold)
                                Text("·  ${options.cols * options.rows} hojas ${paper.name}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                                Icon(
                                    Icons.Rounded.SwapHoriz, contentDescription = "Cambiar imagen", tint = NeonGreen,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { picker.launch(arrayOf("image/*", "application/pdf")) }
                                        .padding(3.dp)
                                )
                            }
                            // Nitidez: verde bien, amarillo regular, rojo borrosa (con consejo).
                            val (sharpColor, sharpText) = when {
                                dpi >= 120 -> Color(0xFF7CF3A6) to "Nítida"
                                dpi >= 60 -> Gold to "Algo borrosa de cerca · prueba Mejorar x2"
                                else -> Color(0xFFFF7D7D) to "Borrosa · usa x2 o menos hojas"
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(if (dpi >= 120) Icons.Rounded.CheckCircle else Icons.Rounded.Warning, contentDescription = null, tint = sharpColor, modifier = Modifier.size(18.dp))
                                Text(sharpText, color = sharpColor, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
            item {
                PosterSection(Icons.Rounded.GridView, "Hojas") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        SHEET_CHOICES.take(4).forEach { n ->
                            PosterChoice(null, "$n", sheets == n, Modifier.weight(1f)) { sheets = n; gridChoice = -1 }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        SHEET_CHOICES.drop(4).forEach { n ->
                            PosterChoice(null, "$n", sheets == n, Modifier.weight(1f)) { sheets = n; gridChoice = -1 }
                        }
                    }
                    if (grids.size > 1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            grids.forEachIndexed { index, (rows, cols) ->
                                PosterChoice(Icons.Rounded.ViewModule, "$cols × $rows", grid == (rows to cols), Modifier.weight(1f)) { gridChoice = index }
                            }
                        }
                    }
                }
            }
            item {
                PosterSection(Icons.Rounded.Description, "Papel") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        PosterChoice(Icons.Rounded.CropPortrait, "Parada", !landscape, Modifier.weight(1f)) { landscape = false; gridChoice = -1 }
                        PosterChoice(Icons.Rounded.CropLandscape, "Echada", landscape, Modifier.weight(1f)) { landscape = true; gridChoice = -1 }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        PosterTiles.PAPERS.forEachIndexed { index, p ->
                            PosterChoice(null, p.name, paperIndex == index, Modifier.weight(1f)) { paperIndex = index }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        PosterChoice(Icons.Rounded.Fullscreen, "Llenar", fill, Modifier.weight(1f)) { fill = true }
                        PosterChoice(Icons.Rounded.FitScreen, "Completa", !fill, Modifier.weight(1f)) { fill = false }
                    }
                }
            }
            item {
                PosterSection(Icons.Rounded.Layers, "Franja para pegar · ${overlapMm.roundToInt()} mm") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf(0f to "Sin", 5f to "Chica", 10f to "Normal", 20f to "Grande").forEach { (mm, name) ->
                            PosterChoice(null, name, overlapMm.roundToInt() == mm.roundToInt(), Modifier.weight(1f)) { overlapMm = mm }
                        }
                    }
                    Slider(value = overlapMm, onValueChange = { overlapMm = it.roundToInt().toFloat() }, valueRange = 0f..30f)
                }
            }
            item {
                PosterSection(Icons.Rounded.BorderOuter, if (borderMm < 0.5f) "Borde · sin borde" else "Borde · ${borderMm.roundToInt()} mm") {
                    Slider(value = borderMm, onValueChange = { borderMm = it.roundToInt().toFloat() }, valueRange = 0f..15f)
                    Text("0 = imagen hasta el borde. Súbelo solo si tu impresora corta la imagen.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
            }
            item {
                PosterSection(Icons.Rounded.AutoAwesome, "Calidad") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        PosterChoice(Icons.Rounded.Image, "Normal", enhance == DocScanEnhance.OFF, Modifier.weight(1f)) { enhance = DocScanEnhance.OFF }
                        PosterChoice(Icons.Rounded.AutoFixHigh, "Mejorar", enhance == DocScanEnhance.ORIGINAL, Modifier.weight(1f)) { enhance = DocScanEnhance.ORIGINAL }
                        PosterChoice(Icons.Rounded.ZoomIn, "x2", enhance == DocScanEnhance.X2, Modifier.weight(1f)) { enhance = DocScanEnhance.X2 }
                    }
                    if (enhance != DocScanEnhance.OFF) {
                        Text("Con IA, en tu celular. Tarda un poco más al guardar.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    }
                }
            }
            item {
                val now = working
                if (now != null) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 6.dp)) {
                        Text("${now.first}…", fontWeight = FontWeight.Bold)
                        val p = now.second
                        if (p == null) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        else LinearProgressIndicator(progress = { p.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.ROOT).format(java.util.Date())
                            pdfSaver.launch("Papelote_$stamp.pdf")
                        },
                        enabled = image != null && now == null,
                        modifier = Modifier.weight(1f).height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                    ) {
                        Icon(Icons.Rounded.PictureAsPdf, contentDescription = null)
                        Text(" PDF", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { imageSaver.launch(null) },
                        enabled = image != null && now == null,
                        modifier = Modifier.weight(1f).height(54.dp)
                    ) {
                        Icon(Icons.Rounded.Collections, contentDescription = null)
                        Text(" Imágenes")
                    }
                }
            }
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Gold.copy(alpha = 0.10f))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Rounded.Print, contentDescription = null, tint = Gold)
                    Text("Imprime al 100 % (tamaño real). La última hoja es la guía.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            }
        }
    }
}

/** Dibujo del papelote armado: la imagen, dónde se junta cada hoja y su número. */
@Composable
private fun PosterPreview(image: Bitmap, options: PosterTiles.Options) {
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG) }
    val line = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE } }
    val tag = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true } }
    val tagBack = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.argb(200, 0, 0, 0) } }
    Canvas(Modifier.fillMaxSize()) {
        val pad = 12.dp.toPx()
        val boxW = size.width - pad * 2
        val boxH = size.height - pad * 2
        val k = min(boxW / options.posterWidth, boxH / options.posterHeight)
        val ox = (size.width - options.posterWidth * k) / 2f
        val oy = (size.height - options.posterHeight * k) / 2f
        val placement = PosterTiles.place(image.width, image.height, options)
        drawIntoCanvas { c ->
            val canvas = c.nativeCanvas
            canvas.save()
            canvas.clipRect(ox, oy, ox + options.posterWidth * k, oy + options.posterHeight * k)
            canvas.drawColor(android.graphics.Color.WHITE)
            canvas.drawBitmap(
                image, null,
                RectF(ox + placement.x * k, oy + placement.y * k, ox + (placement.x + placement.width) * k, oy + (placement.y + placement.height) * k),
                paint
            )
            canvas.restore()
            line.strokeWidth = 1.5.dp.toPx()
            line.color = android.graphics.Color.rgb(255, 70, 90)
            tag.textSize = 13.dp.toPx()
            val tiles = PosterTiles.tiles(image.width, image.height, options)
            for (tile in tiles) {
                val l = ox + tile.left * k
                val t = oy + tile.top * k
                val r = l + tile.width * k
                val b = t + tile.height * k
                canvas.drawRect(l, t, r, b, line)
                val cx = (l + r) / 2f
                val cy = (t + b) / 2f
                canvas.drawCircle(cx, cy - 4.dp.toPx(), 12.dp.toPx(), tagBack)
                tag.color = android.graphics.Color.WHITE
                canvas.drawText(tile.label, cx, cy + 1.dp.toPx(), tag)
            }
        }
    }
}
