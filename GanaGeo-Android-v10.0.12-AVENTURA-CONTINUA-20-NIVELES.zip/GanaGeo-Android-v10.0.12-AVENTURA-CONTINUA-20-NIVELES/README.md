# Gana Geo Android v10.0.12

Rediseño integral de **Geo Aventuras** como una aventura continua de 20 niveles. Los niveles avanzan desde el bosque de día hacia el atardecer, el subsuelo, las cavernas nocturnas y el desierto al amanecer.

Cambios principales:

- 20 niveles reconstruidos con terreno vertical, entradas y salidas diferentes.
- Continuidad narrativa y visual entre la salida de un nivel y la entrada del siguiente.
- Fondos animados por bioma, optimizados para conservar la velocidad.
- Pinchos conectados a suelo, techo o pared; sin trampas flotantes sin soporte.
- Llaves ocultas y puertas cerradas en niveles seleccionados.
- Muros, árboles y rocas que desaparecen o se convierten en caminos útiles.
- Manzanas y objetos temporales desaparecen después de completar su acción.
- Paso automático al siguiente nivel; con 0 vidas se regresa a la selección.
- Se mantienen 15 vidas internas por nivel.

Consulta `CAMBIOS_V10_0_12_AVENTURA_CONTINUA_20_NIVELES.txt` y `VALIDACION_V10_0_12.txt`.
