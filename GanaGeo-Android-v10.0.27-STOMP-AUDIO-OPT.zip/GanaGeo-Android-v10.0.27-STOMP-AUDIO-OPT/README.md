# Gana Geo Android v0.10.27

Geo Aventuras mantiene la reconstrucción **FULL TROLL** de los 20 niveles de v0.10.26, pero esta versión corrige el pisotón sobre enemigos, reduce la carga de audio y aligera la entrada a la sección/nivel de Geo Aventuras. La lógica de inicio de sesión, Google, Supabase y sesión no se modifica.

## Cambios principales

- El pisotón sobre enemigos usa ahora contacto superior barrido entre la posición anterior y actual de GEO y del enemigo; ya no depende de acertar una condición estrecha en un solo frame.
- Cuando el pisotón es válido, GEO se resuelve exactamente sobre la cabeza, rebota y recibe una protección de contacto con enemigos de 180 ms para evitar una muerte inmediata por solapamiento.
- Los enemigos terrestres demasiado juntos se separan automáticamente sobre soporte permanente, evitando que un pisotón correcto sobre uno termine en choque instantáneo con el vecino.
- La música de los 20 niveles se reemplaza por ambientes mucho más suaves en AAC-LC mono, 22.05 kHz, ~16 kbps y 12 s por loop.
- La música se prepara de forma asíncrona; entrar a un nivel ya no bloquea esperando al decodificador.
- SoundPool baja a 5 streams, precarga solo los efectos esenciales, carga los demás bajo demanda y limita sonidos repetitivos para reducir trabajo de audio y GC.
- El volumen base de música se reduce a 8.5 % para que el ambiente no domine el juego.
- La pantalla de Geo Aventuras ya no construye los 20 mapas completos para mostrar nombres/dificultad. Usa metadatos ligeros.
- El nivel seleccionado se genera/cachea fuera del hilo de interfaz antes de iniciar la partida; las siguientes lecturas reutilizan la instancia inmutable cacheada.
- Se conservan la dificultad FULL TROLL, trampas ocultas/deterministas, mínimo 30 amenazas por nivel y las rutas físicas de la versión anterior.

## Validación local

- **43/43 pruebas PASS** con runner Kotlin local.
- Incluye pruebas de los 20 niveles, rutas, densidad troll, hitbox, soporte, índice espacial y las nuevas pruebas de pisotón barrido.
- Nueva regresión: enemigos terrestres cercanos deben conservar al menos 72 px de separación horizontal cuando comparten altura, para dejar una ventana limpia de pisotón.
- `GameAudioController.kt` compila contra stubs Android equivalentes de su API usada.
- 20/20 ambientes nuevos verificados como AAC mono de 22.05 kHz y 12 s.

## Protección de módulos

No se modifican login, Google, Supabase, sesión, persistencia, créditos, Geo Rewards, referidos, retiros ni las demás herramientas de Gana Geo. Los archivos protegidos se verifican por SHA-256 antes del empaquetado.

## Build Android

El proyecto usa el script `gradlew` que descarga Gradle 8.13. Si `services.gradle.org` no es accesible desde este entorno, el APK completo debe compilarse mediante GitHub Actions o un entorno con acceso a esa distribución. Las pruebas locales no sustituyen una prueba final en teléfono.
