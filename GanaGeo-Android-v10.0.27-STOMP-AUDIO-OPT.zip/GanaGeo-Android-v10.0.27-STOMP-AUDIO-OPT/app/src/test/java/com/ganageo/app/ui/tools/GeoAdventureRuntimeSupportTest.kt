package com.ganageo.app.ui.tools

import com.ganageo.app.tools.GeoAdventureLevelFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeoAdventureRuntimeSupportTest {
    @Test
    fun fixedClockAdvancesAt120HzWithoutFrameRateDependentSlowMotion() {
        val clock = GeoFixedStepClock()
        val first = clock.consumeFrame(16_666_666L)
        assertEquals(2, first)
        repeat(first) { clock.advanceOneStep() }
        val second = clock.consumeFrame(33_333_332L)
        assertEquals(4, second)
        repeat(second) { clock.advanceOneStep() }
        assertTrue(clock.elapsedMs in 49L..51L)
    }

    @Test
    fun fixedClockBoundsLongStallsInsteadOfCreatingAnEndlessCatchupSpiral() {
        val clock = GeoFixedStepClock()
        val steps = clock.consumeFrame(900_000_000L)
        assertTrue(steps in 1..8)
        repeat(steps) { clock.advanceOneStep() }
        val next = clock.consumeFrame(16_666_666L)
        assertTrue(next in 1..4)
    }

    @Test
    fun spatialIndexMatchesBruteForceForAllAuthoredPlatforms() {
        (1..20).forEach { number ->
            val level = GeoAdventureLevelFactory.build(number)
            val index = GeoPlatformSpatialIndex(level.platforms)
            val out = ArrayList<Int>()
            var x = -300f
            while (x <= level.width + 300f) {
                val minX = x
                val maxX = x + 720f
                index.queryIndices(minX, maxX, out)
                val indexed = out.toSet()
                val brute = level.platforms.indices.filter { i ->
                    val p = level.platforms[i]
                    p.x + p.width >= minX && p.x <= maxX
                }.toSet()
                assertEquals("Nivel $number ventana $minX..$maxX", brute, indexed)
                x += 310f
            }
        }
    }
    @Test
    fun stompAcceptsDiagonalHeadContactAgainstMovingEnemy() {
        assertTrue(
            isTopStompContact(
                playerPreviousX = 103f,
                playerPreviousY = 121f,
                playerX = 109f,
                playerY = 126f,
                playerWidth = 44f,
                playerHeight = 58f,
                enemyPreviousX = 120f,
                enemyPreviousY = 181f,
                enemyX = 118f,
                enemyY = 179f,
                playerVelocityY = 420f,
                enemyVelocityY = -120f
            )
        )
    }

    @Test
    fun stompRejectsSideCollision() {
        assertTrue(
            !isTopStompContact(
                playerPreviousX = 70f,
                playerPreviousY = 178f,
                playerX = 79f,
                playerY = 180f,
                playerWidth = 44f,
                playerHeight = 58f,
                enemyPreviousX = 118f,
                enemyPreviousY = 180f,
                enemyX = 116f,
                enemyY = 180f,
                playerVelocityY = 80f,
                enemyVelocityY = 0f
            )
        )
    }

}
