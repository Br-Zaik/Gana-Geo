package com.ganageo.app.ui.tools

import com.ganageo.app.tools.GamePlatform
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.reflect.KProperty

/**
 * Deterministic simulation clock. Rendering can run at any display refresh rate while
 * gameplay advances in fixed-size steps, avoiding slow-motion when a frame is late.
 */
internal class GeoFixedStepClock(
    private val stepNanos: Long = 8_333_333L,
    private val maxFrameNanos: Long = 80_000_000L,
    private val maxStepsPerFrame: Int = 8
) {
    private var accumulatorNanos: Long = 0L
    var elapsedNanos: Long = 0L
        private set

    val elapsedMs: Long
        get() = elapsedNanos / 1_000_000L

    val stepSeconds: Float
        get() = stepNanos / 1_000_000_000f

    fun reset() {
        accumulatorNanos = 0L
        elapsedNanos = 0L
    }

    fun consumeFrame(frameDeltaNanos: Long): Int {
        val safeDelta = frameDeltaNanos.coerceIn(0L, maxFrameNanos)
        accumulatorNanos += safeDelta
        var steps = (accumulatorNanos / stepNanos).toInt()
        if (steps <= 0) return 0
        steps = min(steps, maxStepsPerFrame)
        accumulatorNanos -= steps * stepNanos
        // Do not allow a very long stall to create a permanent catch-up spiral.
        if (steps == maxStepsPerFrame && accumulatorNanos > stepNanos * 2L) {
            accumulatorNanos %= stepNanos
        }
        return steps
    }

    fun advanceOneStep() {
        elapsedNanos += stepNanos
    }

    fun interpolationAlpha(): Float = (accumulatorNanos.toDouble() / stepNanos.toDouble()).toFloat().coerceIn(0f, 1f)
}

/**
 * Immutable x-axis spatial index for authored terrain. Platforms are inserted into every
 * cell they touch, so local collision queries do not scan the full level each frame.
 */
internal class GeoPlatformSpatialIndex(
    private val platforms: List<GamePlatform>,
    private val cellSize: Float = 420f
) {
    private val minCell: Int
    private val bins: Array<IntArray>
    private val visitStamp = IntArray(platforms.size)
    private var generation = 1

    init {
        if (platforms.isEmpty()) {
            minCell = 0
            bins = emptyArray()
        } else {
            minCell = floor(platforms.minOf { it.x } / cellSize).toInt()
            val maxCell = floor(platforms.maxOf { it.x + it.width } / cellSize).toInt()
            val mutableBins = Array(maxCell - minCell + 1) { ArrayList<Int>() }
            platforms.forEachIndexed { index, platform ->
                val start = floor(platform.x / cellSize).toInt()
                val end = floor((platform.x + max(1f, platform.width)) / cellSize).toInt()
                for (cell in start..end) {
                    val slot = cell - minCell
                    if (slot in mutableBins.indices) mutableBins[slot].add(index)
                }
            }
            bins = Array(mutableBins.size) { slot -> mutableBins[slot].toIntArray() }
        }
    }

    fun queryIndices(minX: Float, maxX: Float, out: MutableList<Int>) {
        out.clear()
        if (platforms.isEmpty() || bins.isEmpty() || maxX < minX) return
        if (generation == Int.MAX_VALUE) {
            visitStamp.fill(0)
            generation = 1
        } else {
            generation++
        }
        val startCell = floor(minX / cellSize).toInt()
        val endCell = floor(maxX / cellSize).toInt()
        val from = max(0, startCell - minCell)
        val to = min(bins.lastIndex, endCell - minCell)
        if (from > to) return
        for (slot in from..to) {
            val bin = bins[slot]
            for (platformIndex in bin) {
                if (visitStamp[platformIndex] == generation) continue
                visitStamp[platformIndex] = generation
                val p = platforms[platformIndex]
                if (p.x + p.width >= minX && p.x <= maxX) out.add(platformIndex)
            }
        }
    }
}


/**
 * Tiny non-snapshot delegate for simulation data. Compose should observe a single render pulse,
 * not every physics variable mutation. This keeps the game loop off the snapshot/recomposition path.
 */
internal class GeoRuntimeVar<T>(initial: T) {
    private var value: T = initial

    operator fun getValue(thisRef: Any?, property: KProperty<*>): T = value

    operator fun setValue(thisRef: Any?, property: KProperty<*>, newValue: T) {
        value = newValue
    }
}


/**
 * Swept top-contact test used for stomping enemies. It compares the previous and current
 * positions of both bodies so a valid head stomp is not lost between fixed simulation steps.
 * The tolerances are deliberately wider than the visual hitboxes because touch controls need
 * a small landing allowance, while the center-side check still rejects lateral collisions.
 */
internal fun isTopStompContact(
    playerPreviousX: Float,
    playerPreviousY: Float,
    playerX: Float,
    playerY: Float,
    playerWidth: Float,
    playerHeight: Float,
    enemyPreviousX: Float,
    enemyPreviousY: Float,
    enemyX: Float,
    enemyY: Float,
    enemyWidth: Float = 50f,
    enemyHeight: Float = 58f,
    playerVelocityY: Float,
    enemyVelocityY: Float
): Boolean {
    val previousPlayerBottom = playerPreviousY + playerHeight
    val currentPlayerBottom = playerY + playerHeight
    val previousEnemyTop = enemyPreviousY
    val currentEnemyTop = enemyY

    val relativeVerticalSpeed = playerVelocityY - enemyVelocityY
    val relativeTravel =
        (currentPlayerBottom - currentEnemyTop) - (previousPlayerBottom - previousEnemyTop)
    val descendingOntoEnemy = relativeVerticalSpeed > 18f || relativeTravel > 0.35f
    if (!descendingOntoEnemy) return false

    // With a 120 Hz simulation a fast fall advances only a few pixels per step. The extra
    // tolerance covers diagonal touch-control landings and an enemy moving upward into GEO.
    val crossedEnemyTop =
        previousPlayerBottom <= previousEnemyTop + 26f &&
            currentPlayerBottom >= currentEnemyTop - 10f
    if (!crossedEnemyTop) return false

    val sweptPlayerLeft = min(playerPreviousX, playerX) + 6f
    val sweptPlayerRight = max(playerPreviousX + playerWidth, playerX + playerWidth) - 6f
    val sweptEnemyLeft = min(enemyPreviousX, enemyX) + 2f
    val sweptEnemyRight = max(enemyPreviousX + enemyWidth, enemyX + enemyWidth) - 2f
    if (sweptPlayerRight <= sweptEnemyLeft || sweptPlayerLeft >= sweptEnemyRight) return false

    val playerCenterY = playerY + playerHeight / 2f
    val enemyCenterY = enemyY + enemyHeight / 2f
    return playerCenterY <= enemyCenterY + 5f
}

internal fun approachFloat(current: Float, target: Float, maxDelta: Float): Float {
    if (current < target) return min(current + maxDelta, target)
    if (current > target) return max(current - maxDelta, target)
    return target
}

/** Lightweight render-only camera smoother. It is intentionally not Compose state. */
internal class GeoCameraSmoother {
    private var initialized = false
    private var lastNanos = 0L
    private var fastCatchUpUntilNanos = 0L
    var x: Float = 0f
        private set

    fun snap(target: Float, nowNanos: Long = System.nanoTime()): Float {
        initialized = true
        lastNanos = nowNanos
        x = target
        return x
    }

    fun boostAfterRespawn(nowNanos: Long = System.nanoTime(), durationMs: Long = 260L) {
        fastCatchUpUntilNanos = nowNanos + durationMs * 1_000_000L
    }

    fun update(target: Float, nowNanos: Long = System.nanoTime(), maxSpeedPxPerSecond: Float = 1_950f): Float {
        if (!initialized) return snap(target, nowNanos)
        val dt = ((nowNanos - lastNanos).coerceAtLeast(0L) / 1_000_000_000f).coerceAtMost(0.05f)
        lastNanos = nowNanos
        val effectiveSpeed = if (nowNanos < fastCatchUpUntilNanos) max(maxSpeedPxPerSecond, 4_800f) else maxSpeedPxPerSecond
        val maxDelta = effectiveSpeed * dt
        x = approachFloat(x, target, maxDelta)
        return x
    }
}
