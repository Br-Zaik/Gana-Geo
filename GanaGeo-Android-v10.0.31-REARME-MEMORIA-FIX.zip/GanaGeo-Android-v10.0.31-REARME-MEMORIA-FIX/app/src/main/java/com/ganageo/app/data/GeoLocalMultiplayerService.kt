package com.ganageo.app.data

import android.content.Context
import com.ganageo.app.model.GeoLocalRoomBeacon
import com.ganageo.app.model.GeoMultiplayerLobbyState
import com.ganageo.app.model.GeoMultiplayerMode
import com.ganageo.app.model.GeoMultiplayerPlayer
import com.ganageo.app.model.GeoMultiplayerRoom
import com.ganageo.app.model.GeoMultiplayerWireMessage
import com.ganageo.app.model.GeoSkin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class GeoLocalMultiplayerService(
    context: Context,
    private val baseUnlockedLevels: Set<Int>,
    private var selectedSkin: GeoSkin,
    private val progressScope: String = "guest",
    private val allowPremiumSkins: Boolean = false
) {
    companion object {
        const val TCP_PORT = 38291
        const val UDP_PORT = 38292
        const val PROTOCOL = "GANAGEO_LOCAL_V1"

        fun localIpv4Addresses(): List<String> = runCatching {
            buildList {
                val interfaces = NetworkInterface.getNetworkInterfaces()
                while (interfaces.hasMoreElements()) {
                    val network = interfaces.nextElement()
                    if (!network.isUp || network.isLoopback) continue
                    val addresses = network.inetAddresses
                    while (addresses.hasMoreElements()) {
                        val address = addresses.nextElement()
                        if (address is Inet4Address && !address.isLoopbackAddress && !address.isLinkLocalAddress) {
                            address.hostAddress?.let(::add)
                        }
                    }
                }
            }.distinct()
        }.getOrDefault(emptyList())
    }

    private data class Peer(val socket: Socket, val writer: BufferedWriter, var playerId: String)

    private val appContext = context.applicationContext
    private val progressStore = GeoMultiplayerLocalProgressStore(appContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val peers = ConcurrentHashMap<String, Peer>()
    private val _state = MutableStateFlow<GeoMultiplayerLobbyState?>(null)
    val state: StateFlow<GeoMultiplayerLobbyState?> = _state.asStateFlow()
    private val _beacons = MutableStateFlow<List<GeoLocalRoomBeacon>>(emptyList())
    val beacons: StateFlow<List<GeoLocalRoomBeacon>> = _beacons.asStateFlow()
    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var clientWriter: BufferedWriter? = null
    private var hostMode = false
    private var localName = "GEO"
    private var myId = "local-${UUID.randomUUID()}"
    private var hostAddress = ""
    private var discoveryJob: Job? = null
    private var broadcastJob: Job? = null
    private var serverJob: Job? = null
    private var clientJob: Job? = null
    private var lastPersistedMatch = -1L

    suspend fun createRoom(name: String): GeoMultiplayerLobbyState {
        closeNetworkOnly()
        hostMode = true
        localName = name.trim().take(20).ifBlank { "GEO" }
        myId = "local-${UUID.randomUUID()}"
        val levels = progressStore.unlockedLevels(baseUnlockedLevels.maxOrNull() ?: 1, progressScope)
        val premiums = if (allowPremiumSkins) progressStore.premiumSkins(progressScope) else emptySet()
        if (selectedSkin.premium && selectedSkin.code !in premiums) selectedSkin = GeoSkin.GREEN
        val roomId = UUID.randomUUID().toString()
        val room = GeoMultiplayerRoom(roomId, roomId.replace("-", "").take(6).uppercase(), myId, selectedLevel = levels.minOrNull() ?: 1)
        val me = GeoMultiplayerPlayer(myId, "LOCAL-HOST", localName, selectedSkin.code, isHost = true, isReady = true)
        val fresh = GeoMultiplayerLobbyState(GeoMultiplayerMode.LOCAL, room, listOf(me), myId, levels, premiums)
        startServer()
        _state.value = fresh
        startBeaconBroadcast()
        return fresh
    }

    fun startDiscovery() {
        if (discoveryJob?.isActive == true) return
        discoveryJob = scope.launch {
            val socket = runCatching {
                DatagramSocket(null as java.net.SocketAddress?).apply {
                    reuseAddress = true
                    broadcast = true
                    bind(InetSocketAddress(UDP_PORT))
                    soTimeout = 1100
                }
            }.getOrNull() ?: return@launch
            val seen = linkedMapOf<String, GeoLocalRoomBeacon>()
            try {
                while (isActive) {
                    val buffer = ByteArray(4096)
                    val packet = DatagramPacket(buffer, buffer.size)
                    runCatching { socket.receive(packet) }.onSuccess {
                        val text = String(packet.data, 0, packet.length, Charsets.UTF_8)
                        val beacon = runCatching { json.decodeFromString<GeoLocalRoomBeacon>(text) }.getOrNull()
                        if (beacon?.protocol == PROTOCOL) {
                            seen[beacon.roomId] = beacon.copy(hostAddress = packet.address.hostAddress ?: beacon.hostAddress)
                        }
                    }
                    val cutoff = System.currentTimeMillis() - 4_000L
                    seen.entries.removeAll { it.value.sentAt < cutoff }
                    _beacons.value = seen.values.sortedBy { it.hostName }
                }
            } finally { socket.close() }
        }
    }

    suspend fun join(beacon: GeoLocalRoomBeacon, name: String): GeoMultiplayerLobbyState = joinAddress(beacon.hostAddress, name)

    suspend fun joinAddress(address: String, name: String): GeoMultiplayerLobbyState = withContext(Dispatchers.IO) {
        closeNetworkOnly()
        hostMode = false
        localName = name.trim().take(20).ifBlank { "GEO" }
        myId = "local-${UUID.randomUUID()}"
        hostAddress = address.trim()
        require(hostAddress.isNotBlank()) { "Escribe la IP del anfitrión." }
        val myLevels = progressStore.unlockedLevels(baseUnlockedLevels.maxOrNull() ?: 1, progressScope)
        val myPremium = if (allowPremiumSkins) progressStore.premiumSkins(progressScope) else emptySet()
        if (selectedSkin.premium && selectedSkin.code !in myPremium) selectedSkin = GeoSkin.GREEN

        val socket = Socket()
        try {
            socket.connect(InetSocketAddress(hostAddress, TCP_PORT), 4_500)
            socket.tcpNoDelay = true
            socket.keepAlive = true
            socket.soTimeout = 5_000
            clientSocket = socket
            val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream()))
            clientWriter = writer
            val join = GeoMultiplayerWireMessage(
                type = "join", protocol = PROTOCOL,
                player = GeoMultiplayerPlayer(
                    myId,
                    "LOCAL-${myId.takeLast(5).uppercase()}",
                    localName,
                    selectedSkin.code,
                    isReady = true
                )
            )
            send(writer, join)
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val firstLine = reader.readLine() ?: error("El anfitrión cerró la sala.")
            val firstMessage = json.decodeFromString<GeoMultiplayerWireMessage>(firstLine)
            if (firstMessage.type == "error") error(firstMessage.name ?: "No se pudo entrar a la sala.")
            val initial = firstMessage.state ?: error("La sala local no respondió correctamente.")
            socket.soTimeout = 0
            _state.value = initial.copy(myPlayerId = myId, unlockedLevels = myLevels, premiumSkins = myPremium)
            startClientReader(reader)
            _state.value!!
        } catch (error: Throwable) {
            runCatching { socket.close() }
            clientSocket = null
            clientWriter = null
            if (error is IllegalStateException && !error.message.isNullOrBlank()) throw error
            throw IllegalStateException(
                "No se pudo conectar con el anfitrión en $hostAddress:$TCP_PORT. " +
                    "Verifica que ambos teléfonos sigan en la misma Wi-Fi o hotspot. " +
                    "Detalle: ${error.message ?: error.javaClass.simpleName}",
                error
            )
        }
    }

    fun setSkin(skin: GeoSkin) {
        if (skin.premium && (!allowPremiumSkins || skin.code !in (_state.value?.premiumSkins ?: emptySet()))) return
        selectedSkin = skin
        scope.launch { progressStore.setSelectedSkin(skin) }
        mutateMe { it.copy(skinCode = skin.code) }
        if (!hostMode) sendClient(GeoMultiplayerWireMessage("skin", PROTOCOL, skinCode = skin.code, playerId = myId)) else broadcastState()
    }

    fun setReady(ready: Boolean) {
        if (hostMode) return
        mutateMe { it.copy(isReady = ready) }
        sendClient(GeoMultiplayerWireMessage("ready", PROTOCOL, ready = ready, playerId = myId))
    }

    fun setLevel(level: Int) {
        val current = _state.value ?: return
        if (!hostMode || level !in current.unlockedLevels || current.room.status != "lobby") return
        _state.value = current.copy(room = current.room.copy(selectedLevel = level, updatedAtMs = System.currentTimeMillis()))
        broadcastState()
    }

    fun startMatch(): Result<Unit> = runCatching {
        val current = _state.value ?: error("No hay sala local.")
        check(hostMode) { "Solo el anfitrión puede iniciar." }
        check(current.players.size in 2..3) { "Se necesitan entre 2 y 3 jugadores." }
        check(current.players.filterNot { it.isHost }.all { it.isReady }) { "Todos deben estar listos." }
        val nextMatch = current.room.matchNo + 1
        val players = current.players.map { it.copy(lives = 15, isEliminated = false, isSpectator = false, x = 0f, y = 0f, velocityX = 0f, velocityY = 0f, checkpoint = -1, worldState = "", seq = 0) }
        _state.value = current.copy(room = current.room.copy(status = "playing", matchNo = nextMatch, winnerId = null, result = null, startedAtMs = System.currentTimeMillis()), players = players)
        broadcastState()
    }

    fun updatePlayer(player: GeoMultiplayerPlayer) {
        if (hostMode) {
            replacePlayer(player.copy(isHost = player.playerId == _state.value?.room?.hostId))
            maybeFinishLoss()
            broadcastState()
        } else {
            replacePlayer(player)
            sendClient(GeoMultiplayerWireMessage("update", PROTOCOL, player = player, playerId = myId, seq = player.seq))
        }
    }

    fun reportWin(winnerId: String) {
        if (hostMode) finishMatchHost(true, winnerId)
        else sendClient(GeoMultiplayerWireMessage("win", PROTOCOL, winnerId = winnerId, playerId = myId))
    }

    fun resetLobby() {
        if (!hostMode) return
        val current = _state.value ?: return
        if (current.room.status != "finished") return
        val players = current.players.map { it.copy(isReady = it.playerId == current.room.hostId, lives = 15, isEliminated = false, isSpectator = false, x = 0f, y = 0f, velocityX = 0f, velocityY = 0f, checkpoint = -1, worldState = "", seq = 0) }
        _state.value = current.copy(room = current.room.copy(status = "lobby", winnerId = null, result = null, startedAtMs = 0), players = players)
        broadcastState()
    }

    fun leave() {
        if (!hostMode) sendClient(GeoMultiplayerWireMessage("leave", PROTOCOL, playerId = myId))
        closeNetworkOnly()
        _state.value = null
    }

    fun close() { leave(); scope.coroutineContext[Job]?.cancel() }

    private suspend fun startServer() {
        val server = withContext(Dispatchers.IO) {
            ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(TCP_PORT))
            }
        }
        serverSocket = server
        serverJob = scope.launch {
            while (isActive && !server.isClosed) {
                val socket = runCatching { server.accept() }.getOrNull() ?: break
                socket.tcpNoDelay = true
                launch { handlePeer(socket) }
            }
        }
    }

    private suspend fun handlePeer(socket: Socket) {
        val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
        val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream()))
        var peerId = ""
        try {
            while (scope.coroutineContext[Job]?.isActive != false) {
                val line = reader.readLine() ?: break
                val msg = runCatching { json.decodeFromString<GeoMultiplayerWireMessage>(line) }.getOrNull() ?: continue
                if (msg.protocol != PROTOCOL) continue
                when (msg.type) {
                    "join" -> {
                        val incoming = msg.player ?: continue
                        val current = _state.value ?: break
                        if (current.room.status != "lobby" || (current.players.size >= 3 && current.players.none { it.playerId == incoming.playerId })) {
                            send(writer, GeoMultiplayerWireMessage("error", PROTOCOL, name = "Sala llena o en partida.")); break
                        }
                        peerId = incoming.playerId
                        peers[peerId] = Peer(socket, writer, peerId)
                        val joined = incoming.copy(isHost = false, isReady = true, lives = 15)
                        _state.value = current.copy(players = (current.players.filterNot { it.playerId == peerId } + joined).take(3))
                        send(writer, GeoMultiplayerWireMessage("state", PROTOCOL, state = _state.value))
                        broadcastState()
                    }
                    "ready" -> replacePeer(peerId) { it.copy(isReady = msg.ready == true) }
                    "skin" -> replacePeer(peerId) { it.copy(skinCode = msg.skinCode ?: it.skinCode) }
                    "update" -> msg.player?.takeIf { it.playerId == peerId }?.let { incoming ->
                        val old = _state.value?.players?.firstOrNull { it.playerId == peerId }
                        if (old == null || incoming.seq >= old.seq) replacePlayer(incoming.copy(isHost = false))
                        maybeFinishLoss()
                    }
                    "win" -> if (msg.winnerId == peerId) finishMatchHost(true, peerId)
                    "leave" -> break
                }
                if (msg.type in setOf("ready", "skin", "update")) broadcastState()
            }
        } catch (_: Throwable) {
        } finally {
            if (peerId.isNotBlank()) {
                peers.remove(peerId)
                val current = _state.value
                if (current != null) {
                    _state.value = current.copy(players = current.players.filterNot { it.playerId == peerId })
                    if (current.room.status == "playing") maybeFinishLoss()
                    broadcastState()
                }
            }
            runCatching { socket.close() }
        }
    }

    private fun startClientReader(reader: BufferedReader) {
        clientJob = scope.launch {
            try {
                while (isActive) {
                    val line = reader.readLine() ?: break
                    val msg = runCatching { json.decodeFromString<GeoMultiplayerWireMessage>(line) }.getOrNull() ?: continue
                    if (msg.protocol != PROTOCOL) continue
                    if (msg.type == "state") {
                        val fresh = msg.state ?: continue
                        val previous = _state.value
                        _state.value = fresh.copy(
                            myPlayerId = myId,
                            unlockedLevels = previous?.unlockedLevels ?: setOf(1),
                            premiumSkins = previous?.premiumSkins ?: emptySet()
                        )
                        if (fresh.room.status == "finished" && fresh.room.result == "won" && fresh.room.matchNo != lastPersistedMatch) {
                            lastPersistedMatch = fresh.room.matchNo
                            progressStore.unlock(fresh.room.selectedLevel, progressScope)
                            _state.value = _state.value?.copy(unlockedLevels = (_state.value?.unlockedLevels ?: emptySet()) + fresh.room.selectedLevel)
                        }
                    }
                }
            } catch (_: Throwable) {
            } finally {
                _state.value = _state.value?.copy(connected = false, message = "Se perdió la conexión con el anfitrión.")
            }
        }
    }

    private fun startBeaconBroadcast() {
        broadcastJob = scope.launch {
            val socket = runCatching { DatagramSocket().apply { broadcast = true } }.getOrNull() ?: return@launch
            try {
                while (isActive && hostMode) {
                    val current = _state.value
                    if (current != null) {
                        val beacon = GeoLocalRoomBeacon(PROTOCOL, current.room.roomId, current.room.roomCode, localIpv4Addresses().firstOrNull().orEmpty(), localName, current.players.size, current.room.selectedLevel, TCP_PORT)
                        val bytes = json.encodeToString(beacon).toByteArray(Charsets.UTF_8)
                        broadcastTargets().forEach { address -> runCatching { socket.send(DatagramPacket(bytes, bytes.size, address, UDP_PORT)) } }
                    }
                    delay(900L)
                }
            } finally { socket.close() }
        }
    }

    private fun broadcastTargets(): Set<InetAddress> = buildSet {
        runCatching { add(InetAddress.getByName("255.255.255.255")) }
        runCatching {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val network = interfaces.nextElement()
                if (!network.isUp || network.isLoopback) continue
                network.interfaceAddresses.mapNotNull { it.broadcast }.forEach(::add)
            }
        }
    }

    private fun broadcastState() {
        if (!hostMode) return
        val state = _state.value ?: return
        val message = GeoMultiplayerWireMessage("state", PROTOCOL, state = state)
        peers.values.forEach { peer -> runCatching { send(peer.writer, message) } }
    }

    private fun sendClient(message: GeoMultiplayerWireMessage) {
        val writer = clientWriter ?: return
        scope.launch { runCatching { send(writer, message) } }
    }

    @Synchronized
    private fun send(writer: BufferedWriter, message: GeoMultiplayerWireMessage) {
        writer.write(json.encodeToString(message)); writer.newLine(); writer.flush()
    }

    private fun replacePeer(id: String, transform: (GeoMultiplayerPlayer) -> GeoMultiplayerPlayer) {
        val current = _state.value ?: return
        _state.value = current.copy(players = current.players.map { if (it.playerId == id) transform(it) else it })
    }

    private fun mutateMe(transform: (GeoMultiplayerPlayer) -> GeoMultiplayerPlayer) = replacePeer(myId, transform)

    private fun replacePlayer(player: GeoMultiplayerPlayer) {
        val current = _state.value ?: return
        _state.value = current.copy(players = current.players.map { if (it.playerId == player.playerId) player else it })
    }

    private fun maybeFinishLoss() {
        val current = _state.value ?: return
        if (!hostMode || current.room.status != "playing" || current.players.isEmpty()) return
        if (current.players.all { it.lives <= 0 || it.isEliminated }) finishMatchHost(false, null)
    }

    private fun finishMatchHost(won: Boolean, winnerId: String?) {
        val current = _state.value ?: return
        if (!hostMode || current.room.status != "playing") return
        val level = current.room.selectedLevel
        _state.value = current.copy(room = current.room.copy(status = "finished", winnerId = winnerId, result = if (won) "won" else "lost", updatedAtMs = System.currentTimeMillis()))
        if (won) {
            scope.launch {
                progressStore.unlock(level, progressScope)
                _state.value = _state.value?.copy(unlockedLevels = (_state.value?.unlockedLevels ?: emptySet()) + level)
                broadcastState()
            }
        } else broadcastState()
    }

    private fun closeNetworkOnly() {
        discoveryJob?.cancel(); broadcastJob?.cancel(); serverJob?.cancel(); clientJob?.cancel()
        runCatching { serverSocket?.close() }; runCatching { clientSocket?.close() }
        peers.values.forEach { runCatching { it.socket.close() } }; peers.clear()
        serverSocket = null; clientSocket = null; clientWriter = null
        hostMode = false
    }
}
