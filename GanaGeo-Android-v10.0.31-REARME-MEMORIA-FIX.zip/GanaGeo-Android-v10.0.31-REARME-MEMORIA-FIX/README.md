# Gana Geo Android v0.10.31

Version enfocada en **rearme seguro de trampas transitorias** y **optimizacion adaptativa de memoria/render** sobre la v0.10.30. No cambia saltos, velocidad, dificultad, timings de movimiento ni geometria de los 20 niveles.

## Rearme de trampas

- Las trampas transitorias dejan de depender de la muerte para volver a funcionar.
- Plataforma desaparecible/caediza: completa su efecto, espera cooldown y se rearma cuando GEO ya salio de su zona.
- Pinchos ocultos: revelan, atacan, se retraen y vuelven a quedar armados.
- Plantas: un ataque por entrada; se esconden y se rearman al quedar libre la zona.
- Rocas, bolas, frutas/cajas que caen, agujeros perseguidores, lanzadores, crushers y cajas explosivas vuelven a su estado inicial despues de completar su ciclo.
- El rearmado no ocurre debajo/encima de GEO y exige abandonar la zona antes de que el trigger pueda dispararse otra vez.
- En multijugador local, el estado transitorio se mantiene por jugador: un jugador adelantado no consume para siempre la plataforma/trampa del jugador que viene detras. Solo interruptores y llaves/progreso persistente se comparten.

## Rendimiento y memoria

- No se activa `largeHeap` ni se fuerza una cantidad de RAM.
- El juego consulta `ActivityManager.memoryClass` e `isLowRamDevice` y usa un presupuesto interno adaptado al dispositivo.
- Reutilizacion/pooling de proyectiles para reducir asignaciones y GC durante la partida.
- Scratch buffers de colision/render dimensionados segun memoria disponible.
- En gama baja se reduce solamente decoracion secundaria y margen de render; las colisiones, niveles, trampas y fisica permanecen iguales.
- SoundPool usa menos streams y menos precarga en dispositivos low-RAM; la musica sigue fuera del loop de fisica.
- El estado multijugador enviado durante la partida ya no transporta listas completas de trampas transitorias; solo progreso persistente pequeño.

## Multijugador local

Se mantiene el lobby y conexion LAN de v0.10.30. No se requiere SQL 08 para jugar Local. Online continua como PROXIMAMENTE.

## Proteccion

No se modifican login, Google, Supabase, sesion, persistencia, creditos, Geo Rewards, referidos ni retiros.

## Validacion

- Compilacion Kotlin aislada de reglas/fabrica/runtime: PASS.
- 39 pruebas puras de Geo Aventuras (31 niveles + 8 runtime): PASS.
- Politica de rearmado y presupuesto de memoria: PASS.
- Los 20 niveles siguen construyendo correctamente.
- El build Android completo debe confirmarse en GitHub Actions si el entorno local no puede descargar Gradle 8.13.
