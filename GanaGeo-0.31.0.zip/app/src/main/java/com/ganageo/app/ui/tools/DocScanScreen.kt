package com.ganageo.app.ui.tools

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.RectF
import android.net.Uri
import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.DocumentScanner
import androidx.compose.material.icons.rounded.Draw
import androidx.compose.material.icons.rounded.FormatAlignCenter
import androidx.compose.material.icons.rounded.FormatAlignJustify
import androidx.compose.material.icons.rounded.FormatAlignLeft
import androidx.compose.material.icons.rounded.FormatAlignRight
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Redo
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextGeometricTransform
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.ScanGuides
import com.ganageo.app.tools.ScanRebuild
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Colores propios del escáner.
private val DocScanBackground = Color(0xFF0B1410)
private val DocScanBar = Color(0xFF101D16)
private val DocScanChipIdle = Color(0xFF1A2B22)
private val DocScanChipOn = Color(0xFF2A4A1A)
private val DocScanInk = Color(0xFFE6EFE9)
private val DocScanMuted = Color(0xFF8FA398)
private val DocScanFocus = Color(0xFF3D8BFF)
private val DocScanGuide = Color(0xFFFF3DA5)
private val DocScanDanger = Color(0xFFFF8A80)
private const val DocScanSignatureInk = 0xFF10233F.toInt()

private const val DOC_SCAN_FORMAT_PDF = 0
private const val DOC_SCAN_FORMAT_WORD = 1
private const val DOC_SCAN_FORMAT_IMAGE = 2
private const val DOC_SCAN_UNDO_LIMIT = 60
private const val DOC_SCAN_TYPING_PAUSE_MS = 1500L

private val DocScanPalette = listOf(
    0xFF000000.toInt(),
    0xFF3C3C3C.toInt(),
    0xFFFFFFFF.toInt(),
    0xFFC62828.toInt(),
    0xFF1565C0.toInt(),
    0xFF1B2A41.toInt(),
    0xFF2E7D32.toInt(),
    0xFFEF6C00.toInt(),
    0xFF6A1B9A.toInt()
)

/** Lo que está elegido en la hoja. */
private sealed interface DocScanSel {
    val pageId: Int
}

private data class DocScanSelBlock(override val pageId: Int, val blockId: Int) : DocScanSel
private data class DocScanSelText(override val pageId: Int, val textId: Int) : DocScanSel
private data class DocScanSelSign(override val pageId: Int, val signId: Int) : DocScanSel
private data class DocScanSelObject(override val pageId: Int, val objectId: Int) : DocScanSel

/** Qué le falta a la imagen de la hoja (eso se dibuja aparte, en vivo). */
private data class DocScanSheetKey(val pageId: Int, val hiddenBlock: Int, val hiddenObject: Int)

private fun docScanActivity(context: Context): Activity? {
    var current: Context? = context
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}

private fun docScanFilterLabel(filter: DocumentImageFilter): String = when (filter) {
    DocumentImageFilter.ORIGINAL -> "Original"
    DocumentImageFilter.DOCUMENT -> "Documento (más nítido)"
    DocumentImageFilter.GRAYSCALE -> "Gris"
    DocumentImageFilter.ENHANCE -> "Color mejorado"
}

/** Caja de lo elegido, en píxeles de la hoja encajada. */
private fun docScanSelectionRect(
    selection: DocScanSel?,
    pageId: Int,
    layout: DocScanLayout?,
    objects: List<DocScanObject>,
    edits: DocScanPageEdits,
    width: Float,
    height: Float,
    addedFamily: Int,
    paint: android.graphics.Paint
): RectF? {
    if (selection == null || selection.pageId != pageId || width <= 0f || height <= 0f) return null
    return when (selection) {
        is DocScanSelBlock -> {
            val block = layout?.block(selection.blockId) ?: return null
            val scaleX = width / layout.width.coerceAtLeast(1)
            val scaleY = height / layout.height.coerceAtLeast(1)
            RectF(block.rect.left * scaleX, block.rect.top * scaleY, block.rect.right * scaleX, block.rect.bottom * scaleY)
        }
        is DocScanSelObject -> {
            val piece = objects.firstOrNull { it.id == selection.objectId } ?: return null
            val rect = docScanObjectRect(piece.rect, edits.objects[piece.id])
            val pageWidth = layout?.width?.toFloat() ?: return null
            val pageHeight = layout.height.toFloat()
            RectF(rect.left * width / pageWidth, rect.top * height / pageHeight, rect.right * width / pageWidth, rect.bottom * height / pageHeight)
        }
        is DocScanSelText -> edits.texts.firstOrNull { it.id == selection.textId }
            ?.let { docScanAddedBounds(it, width, height, addedFamily, paint) }
        is DocScanSelSign -> edits.signs.firstOrNull { it.id == selection.signId }
            ?.let { docScanSignRect(it, width, height) }
    }
}

/** Lo que se está arrastrando, movido en vivo (solo para dibujar). dx, dy en fracción de la hoja. */
private fun docScanPreview(edits: DocScanPageEdits, selection: DocScanSel?, dx: Float, dy: Float): DocScanPageEdits =
    when (selection) {
        is DocScanSelText -> edits.copy(
            texts = edits.texts.map { if (it.id == selection.textId) it.copy(x = it.x + dx, y = it.y + dy) else it }
        )
        is DocScanSelSign -> edits.copy(
            signs = edits.signs.map { if (it.id == selection.signId) it.movedBy(dx, dy) else it }
        )
        else -> edits
    }

/**
 * Escáner de documentos.
 *
 * 1. Entrada: "Escanear" (escáner de Google: encuentra la hoja, la recorta y la
 *    endereza) o "Elegir de tus fotos" (selector de fotos de Android).
 * 2. Hoja reconstruida: se borra el texto de la foto y se escribe encima el
 *    texto de verdad (mismo lugar, tamaño, color y negrita). Se toca un párrafo
 *    y se escribe directo encima, como en Word. Manteniendo presionado se mueve,
 *    con guías para alinear.
 * 3. Guardar: PDF (con texto real editable), Word (párrafos con formato) o imagen.
 */
@Composable
fun DocumentScannerScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Teclado: la pantalla se achica una sola vez (sin esto Android además la empuja
    // hacia arriba y queda un espacio vacío entre el panel y el teclado).
    DisposableEffect(context) {
        val window = docScanActivity(context)?.window
        val previous = window?.attributes?.softInputMode
        window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        onDispose {
            if (window != null && previous != null) window.setSoftInputMode(previous)
        }
    }
    val scope = rememberCoroutineScope()
    var pages by remember { mutableStateOf<List<DocScanPage>>(emptyList()) }
    var nextPageId by remember { mutableIntStateOf(1) }
    var session by remember { mutableIntStateOf(0) }
    var importing by remember { mutableStateOf(false) }
    var scannerOpening by remember { mutableStateOf(false) }
    // true = las páginas que lleguen se agregan al documento abierto.
    var appending by remember { mutableStateOf(false) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }

    // Copias de escaneos de otras veces: se borran al entrar.
    LaunchedEffect(Unit) {
        runCatching { docScanCleanCache(context, emptySet()) }
    }

    fun receivePages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val base = if (appending) pages else emptyList()
        val room = DOC_SCAN_MAX_PAGES - base.size
        if (room <= 0) {
            onMessage("Máximo $DOC_SCAN_MAX_PAGES páginas por documento.")
            return
        }
        val accepted = uris.take(room)
        var id = nextPageId
        val created = accepted.map { DocScanPage(id++, it) }
        nextPageId = id
        if (!appending) session++
        pages = base + created
        if (uris.size > room) onMessage("Se agregaron ${accepted.size} páginas. Máximo $DOC_SCAN_MAX_PAGES.")
    }

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(DOC_SCAN_MAX_PAGES)
    ) { uris -> receivePages(uris) }

    val googleScanner = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        scannerOpening = false
        if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val scan = runCatching { GmsDocumentScanningResult.fromActivityResultIntent(result.data) }.getOrNull()
        val sources = scan?.pages.orEmpty().map { it.imageUri }
        if (sources.isEmpty()) {
            onMessage("No se pudo leer el escaneo. Intenta otra vez.")
            return@rememberLauncherForActivityResult
        }
        importing = true
        scope.launch {
            val copied = runCatching { docScanCopyToCache(context, sources) }.getOrDefault(emptyList())
            importing = false
            if (copied.isEmpty()) onMessage("No se pudo leer el escaneo. Intenta otra vez.") else receivePages(copied)
        }
    }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
        val uri = cameraUri
        cameraUri = null
        if (saved && uri != null) receivePages(listOf(uri))
    }

    fun openPlainCamera() {
        val uri = runCatching { ToolFileUtils.createCameraImageUri(context) }.getOrNull()
        if (uri == null) {
            onMessage("No se pudo abrir la cámara.")
            return
        }
        cameraUri = uri
        runCatching { takePicture.launch(uri) }.onFailure {
            cameraUri = null
            onMessage("No se pudo abrir la cámara.")
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openPlainCamera() else onMessage("Da permiso de cámara para tomar la foto.")
    }

    // Respaldo: celular sin Servicios de Google o con poca memoria.
    fun cameraFallback() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openPlainCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    fun startScan(append: Boolean) {
        if (scannerOpening || importing) return
        appending = append
        val room = DOC_SCAN_MAX_PAGES - (if (append) pages.size else 0)
        if (room <= 0) {
            onMessage("Máximo $DOC_SCAN_MAX_PAGES páginas por documento.")
            return
        }
        val activity = docScanActivity(context)
        if (activity == null) {
            cameraFallback()
            return
        }
        scannerOpening = true
        runCatching {
            val options = GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(false)
                .setPageLimit(room)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build()
            GmsDocumentScanning.getClient(options)
                .getStartScanIntent(activity)
                .addOnSuccessListener { sender ->
                    runCatching { googleScanner.launch(IntentSenderRequest.Builder(sender).build()) }
                        .onFailure {
                            scannerOpening = false
                            cameraFallback()
                        }
                }
                .addOnFailureListener {
                    scannerOpening = false
                    cameraFallback()
                }
        }.onFailure {
            scannerOpening = false
            cameraFallback()
        }
    }

    fun pickPhotos(append: Boolean) {
        if (importing) return
        appending = append
        runCatching {
            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }.onFailure { onMessage("No se pudieron abrir tus fotos.") }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DocScanBackground)
    ) {
        if (pages.isEmpty()) {
            DocScanHome(
                tool = tool,
                busy = scannerOpening || importing,
                animate = uiState.animationsEnabled,
                onBack = onBack,
                onScan = { startScan(append = false) },
                onPhotos = { pickPhotos(append = false) }
            )
        } else {
            key(session) {
                DocScanWorkspace(
                    viewModel = viewModel,
                    tool = tool,
                    pages = pages,
                    onMessage = onMessage,
                    onClose = {
                        pages = emptyList()
                        scope.launch { runCatching { docScanCleanCache(context, emptySet()) } }
                    },
                    onAddScan = { startScan(append = true) },
                    onAddPhotos = { pickPhotos(append = true) },
                    onRemovePage = { id -> pages = pages.filterNot { it.id == id } }
                )
            }
        }

        if (importing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xB3000000))
                    .pointerInput(Unit) { detectTapGestures { } },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = NeonGreen)
                    Spacer(Modifier.height(12.dp))
                    Text("Preparando páginas…", color = DocScanInk)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Entrada
// ---------------------------------------------------------------------------

@Composable
private fun DocScanHome(
    tool: ToolId,
    busy: Boolean,
    animate: Boolean,
    onBack: () -> Unit,
    onScan: () -> Unit,
    onPhotos: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ToolHeader(tool.title, "Escanea, edita y guarda tus hojas", onBack)

        // Dibujo grande: una hoja que se escanea (llena la pantalla, sin texto de más).
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF143323), Color(0xFF0D1F16))))
        ) {
            DocScanHeroArt(
                animate = animate,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(start = 28.dp, end = 28.dp, top = 22.dp, bottom = 70.dp)
            )
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                DocScanFeature(Icons.Rounded.TextFields, "Editar texto")
                DocScanFeature(Icons.Rounded.Draw, "Firmar")
                DocScanFeature(Icons.Rounded.PictureAsPdf, "PDF y Word")
            }
        }

        // Botones abajo, a la mano del pulgar.
        Column(
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            DocScanBigButton(
                icon = Icons.Rounded.DocumentScanner,
                title = if (busy) "Abriendo…" else "Escanear documento",
                primary = true,
                enabled = !busy,
                onClick = onScan
            )
            DocScanBigButton(
                icon = Icons.Rounded.PhotoLibrary,
                title = "Elegir de tus fotos",
                primary = false,
                enabled = !busy,
                onClick = onPhotos
            )
            Text(
                "Editar es gratis · Guardar o copiar: ${tool.creditCost} créditos",
                color = DocScanMuted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun DocScanFeature(icon: ImageVector, label: String) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x33000000))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, color = DocScanInk, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun DocScanBigButton(
    icon: ImageVector,
    title: String,
    primary: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (primary) 62.dp else 54.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (primary) NeonGreen else CardGreen)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (primary) DeepGreen else NeonGreen, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        Text(
            title,
            color = if (primary) DeepGreen else DocScanInk,
            fontWeight = FontWeight.Black,
            fontSize = if (primary) 17.sp else 16.sp
        )
    }
}

/**
 * Hoja que se escanea: una línea de luz baja por la hoja y lo que ya pasó queda
 * nítido. Liviana: solo se vuelve a dibujar el lienzo, en bucle suave.
 */
@Composable
private fun DocScanHeroArt(animate: Boolean, modifier: Modifier) {
    val progress = if (animate) {
        val transition = rememberInfiniteTransition(label = "escaneo")
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(durationMillis = 2800, easing = LinearEasing), RepeatMode.Restart),
            label = "linea"
        )
    } else {
        null
    }
    Canvas(modifier) {
        val t = progress?.value ?: 0.62f
        // Hoja centrada (proporción A4).
        val sheetHeight = min(size.height, size.width / 0.72f)
        val sheetWidth = sheetHeight * 0.72f
        val left = (size.width - sheetWidth) / 2f
        val top = (size.height - sheetHeight) / 2f
        val corner = sheetWidth * 0.04f
        drawRoundRect(
            color = Color(0x40000000),
            topLeft = Offset(left + 6f, top + 10f),
            size = Size(sheetWidth, sheetHeight),
            cornerRadius = CornerRadius(corner, corner)
        )
        drawRoundRect(
            color = Color(0xFFF7F8F6),
            topLeft = Offset(left, top),
            size = Size(sheetWidth, sheetHeight),
            cornerRadius = CornerRadius(corner, corner)
        )
        val pad = sheetWidth * 0.11f
        val scanY = top + sheetHeight * (0.06f + 0.88f * t)
        // Título, logo y renglones: arriba de la línea ya escaneados (oscuros).
        fun ink(y: Float) = if (y < scanY) Color(0xFF26332C) else Color(0xFFD5DAD6)
        val logo = sheetWidth * 0.14f
        drawRoundRect(
            color = if (top + pad < scanY) Color(0xFF2E7D32) else Color(0xFFD5DAD6),
            topLeft = Offset(left + pad, top + pad),
            size = Size(logo, logo),
            cornerRadius = CornerRadius(logo * 0.25f, logo * 0.25f)
        )
        val lineHeight = sheetHeight * 0.022f
        val titleY = top + pad + logo * 0.2f
        drawRoundRect(
            color = ink(titleY),
            topLeft = Offset(left + pad + logo * 1.3f, titleY),
            size = Size(sheetWidth * 0.42f, lineHeight * 1.5f),
            cornerRadius = CornerRadius(lineHeight, lineHeight)
        )
        drawRoundRect(
            color = ink(titleY + lineHeight * 2.4f),
            topLeft = Offset(left + pad + logo * 1.3f, titleY + lineHeight * 2.4f),
            size = Size(sheetWidth * 0.28f, lineHeight),
            cornerRadius = CornerRadius(lineHeight, lineHeight)
        )
        val widths = floatArrayOf(0.78f, 0.72f, 0.76f, 0.5f, 0f, 0.78f, 0.7f, 0.74f, 0.66f, 0.42f, 0f, 0.6f, 0.74f, 0.56f)
        var y = top + pad + logo + sheetHeight * 0.06f
        for (share in widths) {
            if (y > top + sheetHeight - pad) break
            if (share > 0f) {
                drawRoundRect(
                    color = ink(y),
                    topLeft = Offset(left + pad, y),
                    size = Size(sheetWidth * share, lineHeight),
                    cornerRadius = CornerRadius(lineHeight / 2f, lineHeight / 2f)
                )
            }
            y += lineHeight * 2.3f
        }
        // Línea de luz con brillo.
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color(0x00B8FF00), Color(0x55B8FF00)),
                startY = scanY - sheetHeight * 0.12f,
                endY = scanY
            ),
            topLeft = Offset(left, scanY - sheetHeight * 0.12f),
            size = Size(sheetWidth, sheetHeight * 0.12f)
        )
        drawLine(
            color = NeonGreen,
            start = Offset(left - sheetWidth * 0.04f, scanY),
            end = Offset(left + sheetWidth * 1.04f, scanY),
            strokeWidth = 3.dp.toPx(),
            cap = StrokeCap.Round
        )
        // Esquinas del visor.
        val arm = sheetWidth * 0.12f
        val gap = sheetWidth * 0.05f
        val stroke = 3.dp.toPx()
        val l = left - gap
        val r = left + sheetWidth + gap
        val tp = top - gap
        val b = top + sheetHeight + gap
        listOf(
            Triple(Offset(l, tp), 1f, 1f),
            Triple(Offset(r, tp), -1f, 1f),
            Triple(Offset(l, b), 1f, -1f),
            Triple(Offset(r, b), -1f, -1f)
        ).forEach { (corner0, sx, sy) ->
            drawLine(NeonGreen, corner0, Offset(corner0.x + arm * sx, corner0.y), stroke, StrokeCap.Round)
            drawLine(NeonGreen, corner0, Offset(corner0.x, corner0.y + arm * sy), stroke, StrokeCap.Round)
        }
    }
}

// ---------------------------------------------------------------------------
// Hoja de trabajo
// ---------------------------------------------------------------------------

@Composable
private fun DocScanWorkspace(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    pages: List<DocScanPage>,
    onMessage: (String) -> Unit,
    onClose: () -> Unit,
    onAddScan: () -> Unit,
    onAddPhotos: () -> Unit,
    onRemovePage: (Int) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val density = LocalDensity.current
    val haptics = LocalHapticFeedback.current

    var currentId by remember { mutableIntStateOf(pages.first().id) }
    val currentPage = pages.firstOrNull { it.id == currentId } ?: pages.first()
    val pageNumber = pages.indexOf(currentPage) + 1

    val analyses = remember { mutableStateMapOf<Int, DocScanAnalysis>() }
    val thumbs = remember { mutableStateMapOf<Int, ImageBitmap>() }
    var edits by remember { mutableStateOf<Map<Int, DocScanPageEdits>>(emptyMap()) }
    var undoStack by remember { mutableStateOf<List<Map<Int, DocScanPageEdits>>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<Map<Int, DocScanPageEdits>>>(emptyList()) }
    var typingKey by remember { mutableStateOf<String?>(null) }
    var typingAt by remember { mutableLongStateOf(0L) }

    var filter by remember { mutableStateOf(DocumentImageFilter.ORIGINAL) }
    var fontChoice by remember { mutableIntStateOf(DOC_SCAN_FONT_AUTO) }
    var paperChoice by remember { mutableIntStateOf(DOC_SCAN_PAPER_AUTO) }
    var showBoxes by remember { mutableStateOf(false) }
    var showOriginal by remember { mutableStateOf(false) }

    var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var cleaned by remember { mutableStateOf<DocScanCleaned?>(null) }
    var cleanPageId by remember { mutableIntStateOf(-1) }
    var cleanPaper by remember { mutableStateOf(true) }
    var bitmapPageId by remember { mutableIntStateOf(-1) }
    var loadingPage by remember { mutableStateOf(false) }
    var analyzing by remember { mutableStateOf(false) }
    var analyzeStep by remember { mutableStateOf("Leyendo el texto…") }

    // Hoja lista para mostrar (una sola imagen: fondo + logos + texto).
    var sheet by remember { mutableStateOf<ImageBitmap?>(null) }
    var sheetKey by remember { mutableStateOf(DocScanSheetKey(-1, -1, -1)) }

    var selection by remember { mutableStateOf<DocScanSel?>(null) }
    var newTextId by remember { mutableIntStateOf(-1) }
    // Donde se tocó el párrafo (para poner el cursor ahí), en píxeles de la hoja encajada.
    var tapAt by remember { mutableStateOf<Offset?>(null) }
    // Mover: con pulsación larga (pressMoving) o con la manija mientras se escribe (handleMoving).
    var pressMoving by remember { mutableStateOf(false) }
    var handleMoving by remember { mutableStateOf(false) }
    var dragPreview by remember { mutableStateOf(Offset.Zero) }
    var showColors by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    var showText by remember { mutableStateOf(false) }
    var showSignature by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var textPaid by remember { mutableStateOf(false) }
    var flingJob by remember { mutableStateOf<Job?>(null) }

    val zoom = remember { DocScanZoomState() }
    val measurePaint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }
    val layoutPaint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }
    val livePaint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }
    val textPaths = remember { DocScanTextPaths() }
    val fieldFocus = remember { FocusRequester() }
    val filterMatrix = remember(filter) { docScanFilterMatrix(filter) }
    val composeFilter = remember(filterMatrix) { filterMatrix?.let { ColorFilter.colorMatrix(ColorMatrix(it)) } }
    val liveColorFilter = remember(filterMatrix) { filterMatrix?.let { android.graphics.ColorMatrixColorFilter(it) } }

    val analysis = analyses[currentPage.id]
    val currentEdits = edits[currentPage.id] ?: DocScanPageEdits()
    val shownBitmap = pageBitmap.takeIf { bitmapPageId == currentPage.id }
    val shownCleaned = cleaned.takeIf { cleanPageId == currentPage.id }
    val pieces = shownCleaned?.objects.orEmpty()
    // La hoja armada (texto de verdad) se recalcula solo cuando cambia un párrafo.
    val pageLayout = remember(analysis, currentEdits.blocks, fontChoice) {
        analysis?.takeIf { it.blocks.isNotEmpty() }?.let { docScanLayout(it, currentEdits.blocks, fontChoice, layoutPaint) }
    }
    val addedFamily = docScanAddedFamily(analysis, fontChoice)
    val paperLabel = analysis?.let {
        val paper = if (paperChoice >= 0) paperChoice else it.paper
        docScanPaperLabel(paper, it.landscape)
    }.orEmpty()
    val sheetReady = sheet != null && sheetKey.pageId == currentPage.id && shownCleaned != null
    // Se reconstruye cuando la hoja está lista; si no, se ve la foto.
    val rebuilt = sheetReady && !showOriginal

    // Lo elegido no va en la imagen de la hoja: se dibuja aparte (para moverlo o escribir encima).
    val selectedBlockId = (selection as? DocScanSelBlock)?.takeIf { it.pageId == currentPage.id }?.blockId ?: -1
    val selectedObjectId = (selection as? DocScanSelObject)?.takeIf { it.pageId == currentPage.id }?.objectId ?: -1
    val selectedTextId = (selection as? DocScanSelText)?.takeIf { it.pageId == currentPage.id }?.textId ?: -1
    val selectedBlockDeleted = selectedBlockId >= 0 && currentEdits.blocks[selectedBlockId]?.deleted == true
    // Se escribe directo encima: párrafo o texto agregado elegido (no mientras se mueve con pulsación larga).
    val writingBlock = rebuilt && selectedBlockId >= 0 && !selectedBlockDeleted && !pressMoving
    val writingText = rebuilt && selectedTextId >= 0 && !pressMoving
    val stillRuns = remember(pageLayout, selectedBlockId) {
        pageLayout?.runs?.filter { it.blockId != selectedBlockId }.orEmpty()
    }

    // ---------------- Página actual: foto y lectura ----------------
    LaunchedEffect(currentPage.id) {
        val page = currentPage
        selection = null
        dragPreview = Offset.Zero
        pressMoving = false
        handleMoving = false
        showColors = false
        loadingPage = true
        val loaded = try {
            ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            null
        } finally {
            loadingPage = false
        }
        if (loaded == null) {
            onMessage("No se pudo abrir esta página.")
            return@LaunchedEffect
        }
        pageBitmap = loaded
        bitmapPageId = page.id
        analyzing = true
        val known = analyses[page.id]
        val (read, straight) = try {
            if (known != null) {
                known to withContext(Dispatchers.Default) { docScanStraighten(loaded, known.rotation) }
            } else {
                // Puede tardar: se lee, se endereza, se revisa de cerca y se compara la letra.
                val result = docScanAnalyze(context, loaded) { step -> analyzeStep = step }
                result.analysis to result.bitmap
            }
        } finally {
            analyzing = false
        }
        // Primero la foto enderezada y después la lectura (así se limpia una sola vez).
        if (straight !== loaded) pageBitmap = straight
        if (known == null) analyses[page.id] = read
    }

    // Hoja limpia: sin texto, con el papel parejo y los logos y fotos como piezas.
    val cleanSource = shownBitmap
    LaunchedEffect(cleanSource, analysis, cleanPaper) {
        val source = cleanSource ?: return@LaunchedEffect
        val read = analysis ?: return@LaunchedEffect
        // Aunque no se lea texto, la hoja se limpia igual (para escribir y firmar encima).
        if (source.width != read.width || source.height != read.height) return@LaunchedEffect
        val pageId = currentPage.id
        analyzing = true
        analyzeStep = "Limpiando la hoja…"
        try {
            cleaned = docScanCleanPage(source, read, cleanPaper)
            cleanPageId = pageId
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            // Sin hoja limpia se queda la foto original.
        } finally {
            analyzing = false
        }
    }

    // Imagen de la hoja: se dibuja aparte (procesador), así las letras salen
    // completas y el zoom va fluido. Escribir en un párrafo no la rehace.
    val sheetObjects = currentEdits.objects
    LaunchedEffect(shownCleaned, analysis, stillRuns, sheetObjects, selectedObjectId) {
        val clean = shownCleaned ?: return@LaunchedEffect
        val read = analysis ?: return@LaunchedEffect
        val pageId = currentPage.id
        val hiddenBlock = selectedBlockId
        val hiddenObject = selectedObjectId
        val runs = stillRuns
        val rendered = withContext(Dispatchers.Default) {
            runCatching { docScanRenderSheet(clean, read.width, read.height, runs, sheetObjects, hiddenObject) }.getOrNull()
        }
        if (rendered != null) {
            sheet = rendered.asImageBitmap()
            sheetKey = DocScanSheetKey(pageId, hiddenBlock, hiddenObject)
        }
    }

    // Miniaturas para cambiar de página.
    LaunchedEffect(pages) {
        if (pages.size < 2) return@LaunchedEffect
        for (page in pages) {
            if (thumbs.containsKey(page.id)) continue
            val small = runCatching { ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_THUMB_EDGE) }.getOrNull() ?: continue
            thumbs[page.id] = small.asImageBitmap()
        }
    }

    // ---------------- Cambios y deshacer ----------------
    fun commit(next: Map<Int, DocScanPageEdits>, typing: String? = null) {
        if (next == edits) return
        val now = SystemClock.elapsedRealtime()
        val sameTyping = typing != null && typing == typingKey && now - typingAt < DOC_SCAN_TYPING_PAUSE_MS
        if (!sameTyping) undoStack = (undoStack + listOf(edits)).takeLast(DOC_SCAN_UNDO_LIMIT)
        redoStack = emptyList()
        typingKey = typing
        typingAt = now
        edits = next
    }

    fun updatePage(pageId: Int, typing: String? = null, change: (DocScanPageEdits) -> DocScanPageEdits) {
        val updated = change(edits[pageId] ?: DocScanPageEdits())
        commit(if (updated.isEmpty) edits - pageId else edits + (pageId to updated), typing)
    }

    fun undo() {
        val previous = undoStack.lastOrNull() ?: return
        undoStack = undoStack.dropLast(1)
        redoStack = (redoStack + listOf(edits)).takeLast(DOC_SCAN_UNDO_LIMIT)
        typingKey = null
        edits = previous
    }

    fun redo() {
        val next = redoStack.lastOrNull() ?: return
        redoStack = redoStack.dropLast(1)
        undoStack = (undoStack + listOf(edits)).takeLast(DOC_SCAN_UNDO_LIMIT)
        typingKey = null
        edits = next
    }

    fun setBlockEdit(pageId: Int, block: DocScanBlock, edit: DocScanBlockEdit, typing: Boolean = false) {
        updatePage(pageId, if (typing) "block:$pageId:${block.id}" else null) { page ->
            val blocks = if (edit == block.originalEdit()) page.blocks - block.id else page.blocks + (block.id to edit)
            page.copy(blocks = blocks)
        }
    }

    fun setAddedText(pageId: Int, textId: Int, typing: Boolean = false, update: (DocScanAddedText) -> DocScanAddedText) {
        updatePage(pageId, if (typing) "text:$pageId:$textId" else null) { page ->
            page.copy(texts = page.texts.map { if (it.id == textId) update(it) else it })
        }
    }

    fun deselect() {
        selection = null
        showColors = false
        tapAt = null
        pressMoving = false
        handleMoving = false
        dragPreview = Offset.Zero
        focusManager.clearFocus()
    }

    // ---------------- Toques en la hoja ----------------
    fun hitTest(point: Offset): DocScanSel? {
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (width <= 0f || height <= 0f) return null
        val slack = 10f / zoom.scale
        currentEdits.signs.asReversed().firstOrNull { sign ->
            docScanSignRect(sign, width, height).apply { inset(-slack, -slack) }.contains(point.x, point.y)
        }?.let { return DocScanSelSign(currentPage.id, it.id) }
        currentEdits.texts.asReversed().firstOrNull { text ->
            docScanAddedBounds(text, width, height, addedFamily, measurePaint).apply { inset(-slack, -slack) }.contains(point.x, point.y)
        }?.let { return DocScanSelText(currentPage.id, it.id) }
        val read = analysis ?: return null
        val scaleX = width / read.width.coerceAtLeast(1)
        val scaleY = height / read.height.coerceAtLeast(1)
        var best: DocScanPlacedBlock? = null
        var bestArea = Float.MAX_VALUE
        for (block in pageLayout?.blocks.orEmpty()) {
            val rect = RectF(block.rect.left * scaleX, block.rect.top * scaleY, block.rect.right * scaleX, block.rect.bottom * scaleY)
            rect.inset(-slack, -slack * 0.6f)
            if (rect.contains(point.x, point.y)) {
                val area = rect.width() * rect.height()
                if (area < bestArea) {
                    best = block
                    bestArea = area
                }
            }
        }
        best?.let { return DocScanSelBlock(currentPage.id, it.id) }
        // Logos y fotos (están debajo del texto).
        val piece = pieces.asReversed().firstOrNull { item ->
            val edit = currentEdits.objects[item.id]
            if (edit?.deleted == true) return@firstOrNull false
            val rect = docScanObjectRect(item.rect, edit)
            RectF(rect.left * scaleX, rect.top * scaleY, rect.right * scaleX, rect.bottom * scaleY)
                .apply { inset(-slack, -slack) }.contains(point.x, point.y)
        }
        return piece?.let { DocScanSelObject(currentPage.id, it.id) }
    }

    // Cajas (en píxeles de la foto) para las guías al mover.
    fun boxOf(sel: DocScanSel, read: DocScanAnalysis): ScanGuides.Box? {
        val pageWidth = read.width.toFloat()
        val pageHeight = read.height.toFloat()
        val rect: RectF = when (sel) {
            is DocScanSelBlock -> pageLayout?.block(sel.blockId)?.rect ?: return null
            is DocScanSelObject -> {
                val piece = pieces.firstOrNull { it.id == sel.objectId } ?: return null
                docScanObjectRect(piece.rect, currentEdits.objects[piece.id])
            }
            is DocScanSelText -> currentEdits.texts.firstOrNull { it.id == sel.textId }
                ?.let { docScanAddedBounds(it, pageWidth, pageHeight, addedFamily, measurePaint) } ?: return null
            is DocScanSelSign -> currentEdits.signs.firstOrNull { it.id == sel.signId }
                ?.let { docScanSignRect(it, pageWidth, pageHeight) } ?: return null
        }
        return ScanGuides.Box(rect.left, rect.top, rect.right, rect.bottom)
    }

    fun otherBoxes(sel: DocScanSel, read: DocScanAnalysis): List<ScanGuides.Box> {
        val pageWidth = read.width.toFloat()
        val pageHeight = read.height.toFloat()
        val result = ArrayList<ScanGuides.Box>()
        for (block in pageLayout?.blocks.orEmpty()) {
            if (block.deleted || block.text.isBlank()) continue
            if (sel is DocScanSelBlock && sel.blockId == block.id) continue
            result += ScanGuides.Box(block.rect.left, block.rect.top, block.rect.right, block.rect.bottom)
        }
        for (piece in pieces) {
            val edit = currentEdits.objects[piece.id]
            if (edit?.deleted == true) continue
            if (sel is DocScanSelObject && sel.objectId == piece.id) continue
            val rect = docScanObjectRect(piece.rect, edit)
            result += ScanGuides.Box(rect.left, rect.top, rect.right, rect.bottom)
        }
        for (text in currentEdits.texts) {
            if (sel is DocScanSelText && sel.textId == text.id) continue
            val rect = docScanAddedBounds(text, pageWidth, pageHeight, addedFamily, measurePaint)
            result += ScanGuides.Box(rect.left, rect.top, rect.right, rect.bottom)
        }
        for (sign in currentEdits.signs) {
            if (sel is DocScanSelSign && sel.signId == sign.id) continue
            val rect = docScanSignRect(sign, pageWidth, pageHeight)
            result += ScanGuides.Box(rect.left, rect.top, rect.right, rect.bottom)
        }
        return result
    }

    val guideThresholdPx = with(density) { 9.dp.toPx() }

    /** Imán para un arrastre [raw] (píxeles de la hoja encajada). Resultado en píxeles de la foto. */
    fun snapFor(raw: Offset): ScanGuides.Snap? {
        val sel = selection ?: return null
        val read = analysis ?: return null
        if (zoom.contentWidth <= 0f) return null
        val k = zoom.contentWidth / read.width.coerceAtLeast(1)
        val box = boxOf(sel, read) ?: return null
        val threshold = guideThresholdPx / (k * zoom.scale)
        return ScanGuides.snap(
            box, raw.x / k, raw.y / k, otherBoxes(sel, read),
            read.width.toFloat(), read.height.toFloat(), read.margins, threshold
        )
    }

    /** Arrastre ya con imán, en píxeles de la hoja encajada. */
    fun snappedOffset(raw: Offset): Offset {
        if (raw == Offset.Zero) return Offset.Zero
        val read = analysis ?: return raw
        val snap = snapFor(raw) ?: return raw
        val k = zoom.contentWidth / read.width.coerceAtLeast(1)
        return Offset(snap.dx * k, snap.dy * k)
    }

    val handleTap: (Offset) -> Unit = { screen ->
        if (!rebuilt) {
            if (analyzing) onMessage("Espera un momento: se está preparando la hoja.")
        } else {
            val content = zoom.toContent(screen)
            val hit = hitTest(content)
            if (hit == null) {
                deselect()
            } else {
                if (hit != selection) {
                    showColors = false
                    selection = hit
                }
                tapAt = content
            }
        }
    }
    val handleDoubleTap: (Offset) -> Unit = { screen ->
        scope.launch { zoom.toggleAt(screen) }
    }
    // Mantener presionado: se elige y se mueve (con guías para alinear).
    val handleLongPress: (Offset) -> Boolean = { point ->
        val hit = if (rebuilt) hitTest(point) else null
        val movable = when (hit) {
            null -> false
            is DocScanSelBlock -> currentEdits.blocks[hit.blockId]?.deleted != true
            is DocScanSelObject -> currentEdits.objects[hit.objectId]?.deleted != true
            else -> true
        }
        if (hit != null && movable) {
            focusManager.clearFocus()
            showColors = false
            tapAt = null
            selection = hit
            dragPreview = Offset.Zero
            pressMoving = true
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            true
        } else {
            false
        }
    }
    val onItemDrag: (Offset) -> Unit = { delta -> dragPreview += delta }
    val onItemDragEnd: () -> Unit = {
        val raw = dragPreview
        val wasPress = pressMoving
        val sel = selection
        val read = analysis
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (sel != null && width > 0f && height > 0f && (abs(raw.x) > 0.5f || abs(raw.y) > 0.5f)) {
            // Movimiento final en píxeles de la foto (con el imán de las guías).
            val snap = snapFor(raw)
            val moveX: Float
            val moveY: Float
            if (snap != null && read != null) {
                moveX = snap.dx
                moveY = snap.dy
            } else {
                moveX = raw.x / width * (read?.width ?: 1)
                moveY = raw.y / height * (read?.height ?: 1)
            }
            val pageWidth = (read?.width ?: 1).toFloat()
            val pageHeight = (read?.height ?: 1).toFloat()
            when (sel) {
                is DocScanSelText -> setAddedText(sel.pageId, sel.textId) {
                    it.copy(
                        x = (it.x + moveX / pageWidth).coerceIn(-0.2f, 0.98f),
                        y = (it.y + moveY / pageHeight).coerceIn(0.01f, 1.1f)
                    )
                }
                is DocScanSelSign -> updatePage(sel.pageId) { page ->
                    page.copy(signs = page.signs.map { if (it.id == sel.signId) it.movedBy(moveX / pageWidth, moveY / pageHeight) else it })
                }
                is DocScanSelBlock -> {
                    val block = read?.blocks?.firstOrNull { it.id == sel.blockId }
                    if (block != null) {
                        val edit = currentEdits.blocks[block.id] ?: block.originalEdit()
                        setBlockEdit(sel.pageId, block, edit.copy(dx = edit.dx + moveX, dy = edit.dy + moveY))
                    }
                }
                is DocScanSelObject -> updatePage(sel.pageId) { page ->
                    val edit = page.objects[sel.objectId] ?: DocScanObjectEdit()
                    page.copy(objects = page.objects + (sel.objectId to edit.copy(dx = edit.dx + moveX, dy = edit.dy + moveY)))
                }
            }
        }
        dragPreview = Offset.Zero
        pressMoving = false
        handleMoving = false
        // Un texto movido con pulsación larga se suelta (se toca para escribir).
        if (wasPress && (sel is DocScanSelBlock || sel is DocScanSelText)) deselect()
    }
    val latestTap by rememberUpdatedState(handleTap)
    val latestDoubleTap by rememberUpdatedState(handleDoubleTap)
    val latestLongPress by rememberUpdatedState(handleLongPress)
    val latestDrag by rememberUpdatedState(onItemDrag)
    val latestDragEnd by rememberUpdatedState(onItemDragEnd)

    // ---------------- Agregar ----------------
    fun addText() {
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (width <= 0f || height <= 0f) return
        val center = zoom.visibleCenter()
        val lines = analysis?.lines.orEmpty()
        val pageHeight = (analysis?.height ?: 1).coerceAtLeast(1).toFloat()
        val heights = lines.map { (it.bottom - it.top) / pageHeight }.sorted()
        val size = if (heights.isEmpty()) 0.022f else (heights[heights.size / 2] * 0.95f).coerceIn(0.008f, 0.08f)
        // Color de letra más común de la hoja (la tinta "del medio" por brillo).
        val inks = lines.map { it.ink }.sortedBy {
            android.graphics.Color.red(it) * 299 + android.graphics.Color.green(it) * 587 + android.graphics.Color.blue(it) * 114
        }
        val color = if (inks.isEmpty()) android.graphics.Color.BLACK else inks[inks.size / 2]
        val id = (currentEdits.texts.maxOfOrNull { it.id } ?: 0) + 1
        // Empieza en el margen izquierdo de la hoja (alineado con el texto).
        val marginX = analysis?.let { it.margins.left / it.width.coerceAtLeast(1) } ?: 0.1f
        val x = marginX.coerceIn(0.02f, 0.9f)
        val y = (center.y / height).coerceIn(0.05f, 0.97f)
        updatePage(currentPage.id) { it.copy(texts = it.texts + DocScanAddedText(id, x, y, "Texto", size, color)) }
        newTextId = id
        tapAt = null
        selection = DocScanSelText(currentPage.id, id)
    }

    fun addSign(bitmap: Bitmap) {
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (width <= 0f || height <= 0f || bitmap.width < 2) return
        val center = zoom.visibleCenter()
        val signWidth = 0.32f
        val signHeight = signWidth * width * bitmap.height / bitmap.width / height
        val id = (currentEdits.signs.maxOfOrNull { it.id } ?: 0) + 1
        updatePage(currentPage.id) {
            it.copy(
                signs = it.signs + DocScanSign(
                    id,
                    (center.x / width - signWidth / 2f).coerceIn(0f, 1f - signWidth),
                    (center.y / height - signHeight / 2f).coerceIn(0f, 0.95f),
                    signWidth,
                    bitmap
                )
            )
        }
        selection = DocScanSelSign(currentPage.id, id)
    }

    fun setObjectEdit(pageId: Int, objectId: Int, edit: DocScanObjectEdit) {
        updatePage(pageId) { page ->
            page.copy(objects = if (edit == DocScanObjectEdit()) page.objects - objectId else page.objects + (objectId to edit))
        }
    }

    // Imagen de la galería: se pega como una pieza que se mueve y se agranda.
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val image = runCatching { ToolFileUtils.loadBitmap(context, uri, 1400) }.getOrNull()
                if (image == null) onMessage("No se pudo abrir la imagen.") else addSign(image)
            }
        }
    }

    // ---------------- Guardar ----------------
    fun runSave(output: Uri, format: Int) {
        if (saving) return
        saving = true
        val pagesNow = pages
        val pageIds = pagesNow.map { it.id }.toSet()
        val editsNow = edits.filterKeys { it in pageIds }
        val known = analyses.toMap()
        val page = currentPage
        val fontNow = fontChoice
        val paperNow = paperChoice
        val cleanNow = cleanPaper
        val matrix = filterMatrix
        scope.launch {
            val result = runPaidTool(viewModel, tool) {
                withContext(Dispatchers.IO) {
                    val stream = context.contentResolver.openOutputStream(output, "w") ?: error("No se pudo crear el archivo.")
                    stream.use { out ->
                        when (format) {
                            DOC_SCAN_FORMAT_PDF -> docScanWritePdf(context, out, pagesNow, known, editsNow, fontNow, paperNow, cleanNow, matrix)
                            DOC_SCAN_FORMAT_WORD -> {
                                val all = docScanEnsureAnalyses(context, pagesNow, known)
                                val wordPages = withContext(Dispatchers.Default) {
                                    pagesNow.map { item ->
                                        val itemEdits = editsNow[item.id] ?: DocScanPageEdits()
                                        val itemAnalysis = all[item.id]
                                        val itemLayout = itemAnalysis?.let { docScanLayout(it, itemEdits.blocks, fontNow) }
                                        DocScanWordPage(
                                            docScanParagraphs(itemLayout, itemEdits, docScanAddedFamily(itemAnalysis, fontNow)),
                                            if (paperNow >= 0) paperNow else itemAnalysis?.paper ?: 0,
                                            itemAnalysis?.landscape ?: false
                                        )
                                    }
                                }
                                docScanWriteDocx(out, wordPages)
                            }
                            else -> docScanWriteImage(
                                context,
                                out,
                                page,
                                known[page.id],
                                editsNow[page.id] ?: DocScanPageEdits(),
                                fontNow,
                                cleanNow,
                                matrix
                            )
                        }
                    }
                }
            }
            saving = false
            val label = when (format) {
                DOC_SCAN_FORMAT_PDF -> "PDF guardado."
                DOC_SCAN_FORMAT_WORD -> "Word guardado."
                else -> "Imagen guardada."
            }
            result
                .onSuccess { onMessage(successMessage(label, it)) }
                .onFailure { onMessage(it.message ?: "No se pudo guardar el archivo.") }
        }
    }

    val savePdf = rememberLauncherForActivityResult(TrackedCreateDocument("application/pdf")) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_PDF)
    }
    val saveWord = rememberLauncherForActivityResult(TrackedCreateDocument(DOC_SCAN_DOCX_MIME)) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_WORD)
    }
    val saveImage = rememberLauncherForActivityResult(TrackedCreateDocument("image/jpeg")) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_IMAGE)
    }

    fun chooseFormat(format: Int) {
        showSave = false
        val stamp = System.currentTimeMillis() / 1000
        launchPaidExport(viewModel, tool, onMessage) {
            when (format) {
                DOC_SCAN_FORMAT_PDF -> savePdf.launch("Escaneo_$stamp.pdf")
                DOC_SCAN_FORMAT_WORD -> saveWord.launch("Escaneo_$stamp.docx")
                else -> saveImage.launch("Escaneo_${stamp}_p$pageNumber.jpg")
            }
        }
    }

    // Copiar o compartir el texto se cobra una sola vez por documento.
    fun withPaidText(text: String, action: (String) -> Unit) {
        if (text.isBlank()) {
            onMessage("No hay texto para copiar.")
            return
        }
        if (textPaid) {
            action(text)
            return
        }
        launchPaidExport(viewModel, tool, onMessage) {
            scope.launch {
                runPaidTool(viewModel, tool) { }
                    .onSuccess {
                        textPaid = true
                        action(text)
                        onMessage(successMessage("Listo.", it))
                    }
                    .onFailure { onMessage(it.message ?: "No se pudo completar.") }
            }
        }
    }

    fun handleBack() {
        when {
            showSignature -> showSignature = false
            showText -> showText = false
            showSave -> showSave = false
            showSettings -> showSettings = false
            selection != null -> deselect()
            edits.isNotEmpty() -> confirmExit = true
            else -> onClose()
        }
    }
    BackHandler { handleBack() }

    // Al elegir un texto para escribir, sale el teclado.
    val selectionKey = selection?.let { sel ->
        when (sel) {
            is DocScanSelBlock -> "b:${sel.pageId}:${sel.blockId}"
            is DocScanSelText -> "t:${sel.pageId}:${sel.textId}"
            is DocScanSelSign -> "s:${sel.pageId}:${sel.signId}"
            is DocScanSelObject -> "o:${sel.pageId}:${sel.objectId}"
        }
    }
    val wantsKeyboard = writingBlock || writingText
    LaunchedEffect(selectionKey, wantsKeyboard) {
        if (wantsKeyboard) {
            delay(80)
            runCatching { fieldFocus.requestFocus() }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DocScanBackground)
                .imePadding()
        ) {
            // ---------------- Barra de arriba ----------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DocScanBar)
                    .statusBarsPadding()
                    .height(56.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { handleBack() }) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = DocScanInk)
                }
                Column(Modifier.weight(1f)) {
                    Text("Escáner", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        (if (pages.size > 1) "Página $pageNumber de ${pages.size}" else "1 página") +
                            if (paperLabel.isNotEmpty()) " · $paperLabel" else "",
                        color = DocScanMuted,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }
                IconButton(onClick = { undo() }, enabled = undoStack.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Undo,
                        contentDescription = "Deshacer",
                        tint = if (undoStack.isNotEmpty()) DocScanInk else Color(0xFF4A5A51)
                    )
                }
                IconButton(onClick = { redo() }, enabled = redoStack.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Redo,
                        contentDescription = "Rehacer",
                        tint = if (redoStack.isNotEmpty()) DocScanInk else Color(0xFF4A5A51)
                    )
                }
                Box {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Rounded.Tune, contentDescription = "Ajustes", tint = DocScanInk)
                    }
                    DropdownMenu(expanded = showSettings, onDismissRequest = { showSettings = false }) {
                        DocScanMenuLabel("Imagen")
                        DocumentImageFilter.entries.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(docScanFilterLabel(option)) },
                                onClick = {
                                    filter = option
                                    showSettings = false
                                },
                                trailingIcon = {
                                    if (filter == option) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen)
                                }
                            )
                        }
                        HorizontalDivider()
                        DocScanMenuLabel("Letra")
                        (listOf(DOC_SCAN_FONT_AUTO) + (0 until DocScanFonts.count)).forEach { option ->
                            DropdownMenuItem(
                                text = {
                                    Text(if (option == DOC_SCAN_FONT_AUTO) "Automática (como la foto)" else DocScanFonts.labels[option])
                                },
                                onClick = {
                                    fontChoice = option
                                    showSettings = false
                                },
                                trailingIcon = {
                                    if (fontChoice == option) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen)
                                }
                            )
                        }
                        HorizontalDivider()
                        DocScanMenuLabel("Tamaño de hoja")
                        (listOf(DOC_SCAN_PAPER_AUTO) + (0..3)).forEach { option ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        if (option == DOC_SCAN_PAPER_AUTO) {
                                            val detected = analysis?.let { docScanPaperLabel(it.paper, it.landscape) }.orEmpty()
                                            if (detected.isEmpty()) "Automático" else "Automático ($detected)"
                                        } else {
                                            ScanRebuild.papers[option].first
                                        }
                                    )
                                },
                                onClick = {
                                    paperChoice = option
                                    showSettings = false
                                },
                                trailingIcon = {
                                    if (paperChoice == option) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen)
                                }
                            )
                        }
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Hoja limpia (papel blanco)") },
                            onClick = {
                                cleanPaper = !cleanPaper
                                showSettings = false
                            },
                            trailingIcon = { if (cleanPaper) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen) }
                        )
                        DropdownMenuItem(
                            text = { Text("Marcar los párrafos") },
                            onClick = { showBoxes = !showBoxes },
                            trailingIcon = { if (showBoxes) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen) }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Agregar páginas con la cámara") },
                            onClick = {
                                showSettings = false
                                onAddScan()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Agregar páginas de tus fotos") },
                            onClick = {
                                showSettings = false
                                onAddPhotos()
                            }
                        )
                        if (pages.size > 1) {
                            DropdownMenuItem(
                                text = { Text("Quitar esta página", color = DocScanDanger) },
                                onClick = {
                                    showSettings = false
                                    val index = pages.indexOf(currentPage)
                                    val removed = currentPage.id
                                    currentId = pages.getOrNull(index + 1)?.id ?: pages.getOrNull(index - 1)?.id ?: removed
                                    edits = edits - removed
                                    onRemovePage(removed)
                                }
                            )
                        }
                    }
                }
                Box(
                    modifier = Modifier
                        .padding(start = 2.dp, end = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (saving) Color(0xFF5E7F1A) else NeonGreen)
                        .clickable(enabled = !saving) {
                            deselect()
                            showSave = true
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        if (saving) "Guardando…" else "Guardar",
                        color = DeepGreen,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            }
            if (saving) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = NeonGreen)

            // ---------------- Hoja ----------------
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clipToBounds()
            ) {
                val viewWidth = constraints.maxWidth.toFloat()
                val viewHeight = constraints.maxHeight.toFloat()
                // El alto más grande visto: al salir el teclado la hoja no se achica, solo se mueve.
                val stableHeight = remember { FloatArray(1) }
                if (viewHeight > stableHeight[0]) stableHeight[0] = viewHeight
                val bitmap = shownBitmap
                val readablePx = with(density) { 17.sp.toPx() }

                if (bitmap != null) {
                    val margin = with(density) { 12.dp.toPx() }
                    val aspect = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
                    val contentWidth = min(viewWidth - 2f * margin, (stableHeight[0] - 2f * margin) * aspect).coerceAtLeast(10f)
                    val contentHeight = contentWidth / aspect
                    zoom.setSizes(currentPage.id, viewWidth, viewHeight, contentWidth, contentHeight)
                    val picture = remember(bitmap) { bitmap.asImageBitmap() }
                    val sheetPicture = sheet.takeIf { sheetReady }
                    // Píxeles de la foto → píxeles de la hoja encajada.
                    val k = analysis?.let { contentWidth / it.width.coerceAtLeast(1) } ?: 1f

                    // Para escribir: la hoja se acerca y deja el párrafo arriba del teclado.
                    LaunchedEffect(selectionKey, constraints.maxHeight, writingBlock, writingText) {
                        if (!writingBlock && !writingText) return@LaunchedEffect
                        delay(200)
                        val read = analysis ?: return@LaunchedEffect
                        val kk = zoom.contentWidth / read.width.coerceAtLeast(1)
                        if (writingBlock) {
                            val placed = pageLayout?.block(selectedBlockId) ?: return@LaunchedEffect
                            val area = Rect(
                                min(placed.areaLeft, placed.rect.left) * kk,
                                placed.rect.top * kk,
                                maxOf(placed.areaRight, placed.rect.right) * kk,
                                placed.rect.bottom * kk
                            )
                            zoom.focusOn(area, placed.size * kk, readablePx)
                        } else {
                            val text = currentEdits.texts.firstOrNull { it.id == selectedTextId } ?: return@LaunchedEffect
                            val box = docScanAddedBounds(text, zoom.contentWidth, zoom.contentHeight, addedFamily, measurePaint)
                            zoom.focusOn(
                                Rect(box.left, box.top, box.right + zoom.contentWidth * 0.2f, box.bottom),
                                text.size * zoom.contentHeight,
                                readablePx
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onDoubleTap = { latestDoubleTap(it) },
                                    onTap = { latestTap(it) }
                                )
                            }
                            .pointerInput(zoom) {
                                // Un dedo mueve la hoja (con inercia); dos dedos acercan donde están
                                // los dedos. Mantener presionado algo lo elige y arrastrarlo lo mueve.
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false)
                                    flingJob?.cancel()
                                    val tracker = VelocityTracker()
                                    tracker.addPosition(down.uptimeMillis, down.position)
                                    val slop = viewConfiguration.touchSlop
                                    var travelled = Offset.Zero
                                    var lifted = false
                                    var startedEarly = false
                                    // 1) ¿Se queda quieto el dedo (pulsación larga) o se mueve?
                                    val heldStill = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                        while (!lifted && !startedEarly) {
                                            val event = awaitPointerEvent()
                                            val pressed = event.changes.filter { it.pressed }
                                            if (pressed.isEmpty()) {
                                                lifted = true
                                            } else {
                                                travelled += event.calculatePan()
                                                if (pressed.size >= 2 || travelled.getDistance() > slop) startedEarly = true
                                                val lead = pressed.first()
                                                tracker.addPosition(lead.uptimeMillis, lead.position)
                                            }
                                        }
                                        false
                                    } == null
                                    if (!lifted) {
                                        var movingItem = heldStill && latestLongPress(zoom.toContent(down.position))
                                        var active = startedEarly || movingItem
                                        var pinched = false
                                        var pointerCount = 1
                                        while (true) {
                                            val event = awaitPointerEvent()
                                            val pressed = event.changes.filter { it.pressed }
                                            if (pressed.isEmpty()) {
                                                // Al soltar lo que se movía no cuenta como toque.
                                                if (movingItem) event.changes.forEach { it.consume() }
                                                break
                                            }
                                            if (pressed.size != pointerCount) {
                                                pointerCount = pressed.size
                                                tracker.resetTracking()
                                            }
                                            val zoomChange = event.calculateZoom()
                                            val pan = event.calculatePan()
                                            if (!active) {
                                                travelled += pan
                                                if (pressed.size >= 2 || travelled.getDistance() > slop) active = true
                                            }
                                            if (active) {
                                                if (pressed.size >= 2) {
                                                    pinched = true
                                                    if (movingItem) {
                                                        movingItem = false
                                                        latestDragEnd()
                                                    }
                                                    val centroid = event.calculateCentroid(useCurrent = true)
                                                    if (centroid.isSpecified) zoom.zoomBy(zoomChange, centroid, pan)
                                                } else if (movingItem) {
                                                    latestDrag(Offset(pan.x / zoom.scale, pan.y / zoom.scale))
                                                } else {
                                                    zoom.panBy(pan)
                                                }
                                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                                            }
                                            if (movingItem) event.changes.forEach { it.consume() }
                                            val lead = pressed.first()
                                            tracker.addPosition(lead.uptimeMillis, lead.position)
                                        }
                                        if (movingItem) {
                                            latestDragEnd()
                                        } else if (active && !pinched) {
                                            val velocity = tracker.calculateVelocity()
                                            flingJob = scope.launch { zoom.fling(velocity) }
                                        }
                                        if (pinched && zoom.scale < 1f) scope.launch { zoom.animateToFit() }
                                    }
                                }
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(
                                    with(density) { contentWidth.toDp() },
                                    with(density) { contentHeight.toDp() }
                                )
                                .graphicsLayer {
                                    transformOrigin = TransformOrigin(0f, 0f)
                                    scaleX = zoom.scale
                                    scaleY = zoom.scale
                                    translationX = zoom.offsetX
                                    translationY = zoom.offsetY
                                }
                                .background(Color.White)
                        ) {
                            // La hoja: una sola imagen (fondo limpio + logos + texto) o la foto tal cual.
                            Image(
                                bitmap = if (rebuilt && sheetPicture != null) sheetPicture else picture,
                                contentDescription = "Página $pageNumber",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.FillBounds,
                                colorFilter = composeFilter
                            )
                            // Encima, en vivo: lo que se mueve, los textos agregados, las firmas,
                            // la marca de lo elegido y las guías para alinear.
                            Canvas(Modifier.fillMaxSize()) {
                                val width = size.width
                                val height = size.height
                                val read = analysis
                                val layoutNow = pageLayout
                                val sel = selection
                                val raw = dragPreview
                                val moving = (pressMoving || handleMoving) && raw != Offset.Zero
                                val snap = if (moving) snapFor(raw) else null
                                val kk = if (read != null) width / read.width.coerceAtLeast(1) else 1f
                                val shift = if (snap != null) Offset(snap.dx * kk, snap.dy * kk) else if (moving) raw else Offset.Zero

                                if (rebuilt && read != null) {
                                    // Párrafo y pieza que no están en la imagen de la hoja.
                                    val liveBlock = sheetKey.hiddenBlock
                                    val liveObject = sheetKey.hiddenObject
                                    val blockShift = if (sel is DocScanSelBlock && sel.blockId == liveBlock) shift else Offset.Zero
                                    val objectShift = if (sel is DocScanSelObject && sel.objectId == liveObject) shift else Offset.Zero
                                    drawIntoCanvas { canvas ->
                                        val native = canvas.nativeCanvas
                                        native.save()
                                        native.scale(kk, kk)
                                        if (liveObject >= 0) {
                                            val piece = pieces.firstOrNull { it.id == liveObject }
                                            if (piece != null) {
                                                livePaint.colorFilter = liveColorFilter
                                                docScanDrawObjects(
                                                    native, listOf(piece), currentEdits.objects, livePaint,
                                                    piece.id, objectShift.x / kk, objectShift.y / kk
                                                )
                                            }
                                        }
                                        val writingThis = writingBlock && selectedBlockId == liveBlock
                                        if (liveBlock >= 0 && !writingThis && layoutNow != null) {
                                            val runs = layoutNow.runs.filter { it.blockId == liveBlock }
                                            if (runs.isNotEmpty()) {
                                                native.translate(blockShift.x / kk, blockShift.y / kk)
                                                livePaint.colorFilter = liveColorFilter
                                                textPaths.drawRuns(native, runs, livePaint)
                                            }
                                        }
                                        native.restore()
                                    }
                                }
                                if (showBoxes && layoutNow != null && rebuilt) {
                                    for (block in layoutNow.blocks) {
                                        if (block.deleted) continue
                                        drawRect(
                                            color = DocScanFocus.copy(alpha = 0.09f),
                                            topLeft = Offset(block.rect.left * kk, block.rect.top * kk),
                                            size = Size(block.rect.width() * kk, block.rect.height() * kk)
                                        )
                                    }
                                }
                                // Textos agregados y firmas.
                                val drawn = if (moving && (sel is DocScanSelText || sel is DocScanSelSign)) {
                                    docScanPreview(currentEdits, sel, shift.x / width, shift.y / height)
                                } else {
                                    currentEdits
                                }
                                drawIntoCanvas { canvas ->
                                    livePaint.colorFilter = liveColorFilter
                                    docScanDrawAdded(
                                        canvas.nativeCanvas, width, height, drawn, addedFamily, livePaint,
                                        paths = textPaths,
                                        hiddenText = if (writingText) selectedTextId else -1
                                    )
                                    livePaint.colorFilter = null
                                }
                                // Marca de lo elegido: línea fina (no tapa la hoja).
                                val line = 1.5.dp.toPx() / zoom.scale
                                val rect = docScanSelectionRect(sel, currentPage.id, layoutNow, pieces, drawn, width, height, addedFamily, measurePaint)
                                    ?.apply { if (sel is DocScanSelBlock || sel is DocScanSelObject) offset(shift.x, shift.y) }
                                if (rect != null && !(writingBlock && !handleMoving) && !writingText) {
                                    val pad = 3.dp.toPx() / zoom.scale
                                    drawRoundRect(
                                        color = DocScanFocus.copy(alpha = 0.06f),
                                        topLeft = Offset(rect.left - pad, rect.top - pad),
                                        size = Size(rect.width() + pad * 2f, rect.height() + pad * 2f),
                                        cornerRadius = CornerRadius(pad, pad)
                                    )
                                    drawRoundRect(
                                        color = DocScanFocus,
                                        topLeft = Offset(rect.left - pad, rect.top - pad),
                                        size = Size(rect.width() + pad * 2f, rect.height() + pad * 2f),
                                        cornerRadius = CornerRadius(pad, pad),
                                        style = Stroke(width = line)
                                    )
                                    if (sel is DocScanSelObject || sel is DocScanSelSign) {
                                        val knob = 4.dp.toPx() / zoom.scale
                                        listOf(
                                            Offset(rect.left - pad, rect.top - pad),
                                            Offset(rect.right + pad, rect.top - pad),
                                            Offset(rect.left - pad, rect.bottom + pad),
                                            Offset(rect.right + pad, rect.bottom + pad)
                                        ).forEach { center ->
                                            drawCircle(Color.White, radius = knob, center = center)
                                            drawCircle(DocScanFocus, radius = knob, center = center, style = Stroke(width = line))
                                        }
                                    }
                                }
                                // Guías para alinear (rosadas, como en los editores de diseño).
                                if (snap != null) {
                                    val guideStroke = 1.5.dp.toPx() / zoom.scale
                                    for (guide in snap.guides) {
                                        if (guide.vertical) {
                                            drawLine(
                                                DocScanGuide,
                                                Offset(guide.position * kk, guide.start * kk),
                                                Offset(guide.position * kk, guide.end * kk),
                                                guideStroke
                                            )
                                        } else {
                                            drawLine(
                                                DocScanGuide,
                                                Offset(guide.start * kk, guide.position * kk),
                                                Offset(guide.end * kk, guide.position * kk),
                                                guideStroke
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ---------------- Escribir directo sobre la hoja ----------------
                    val read = analysis
                    if (writingBlock && read != null) {
                        val placed = pageLayout?.block(selectedBlockId)
                        val block = read.blocks.firstOrNull { it.id == selectedBlockId }
                        if (placed != null && block != null) {
                            val edit = currentEdits.blocks[block.id] ?: block.originalEdit()
                            DocScanInlineEditor(
                                zoom = zoom,
                                fieldKey = "b:${currentPage.id}:${block.id}",
                                text = edit.text,
                                selectAll = false,
                                left = placed.areaLeft * k,
                                baseline = placed.baseline * k,
                                width = (placed.areaRight - placed.areaLeft) * k,
                                fontSize = placed.size * k,
                                leading = placed.leading * k,
                                scaleX = placed.scaleX,
                                typeface = DocScanFonts.typeface(placed.family, edit.bold, edit.italic),
                                color = Color(docScanFilterColor(edit.color, filterMatrix)),
                                align = edit.align,
                                singleLine = false,
                                // Mientras la imagen de la hoja todavía tiene el párrafo, se tapa.
                                cover = if (sheetKey.hiddenBlock != block.id) {
                                    Color(docScanFilterColor(block.background, filterMatrix))
                                } else {
                                    null
                                },
                                pendingTap = tapAt,
                                onTapUsed = { tapAt = null },
                                dragOffset = { if (handleMoving) snappedOffset(dragPreview) else Offset.Zero },
                                focusRequester = fieldFocus,
                                onText = { setBlockEdit(currentPage.id, block, edit.copy(text = it), typing = true) },
                                onDone = { deselect() },
                                onMoveStart = {
                                    dragPreview = Offset.Zero
                                    handleMoving = true
                                },
                                onMove = { delta -> latestDrag(delta) },
                                onMoveEnd = { latestDragEnd() }
                            )
                        }
                    } else if (writingText && read != null) {
                        val added = currentEdits.texts.firstOrNull { it.id == selectedTextId }
                        if (added != null) {
                            val pageW = zoom.contentWidth
                            val pageH = zoom.contentHeight
                            DocScanInlineEditor(
                                zoom = zoom,
                                fieldKey = "t:${currentPage.id}:${added.id}",
                                text = added.text,
                                selectAll = newTextId == added.id,
                                left = added.x * pageW,
                                baseline = added.y * pageH,
                                width = null,
                                fontSize = added.size * pageH,
                                leading = added.size * pageH * 1.22f,
                                scaleX = 1f,
                                typeface = DocScanFonts.typeface(addedFamily, added.bold, added.italic),
                                color = Color(docScanFilterColor(added.color, filterMatrix)),
                                align = DOC_SCAN_ALIGN_LEFT,
                                singleLine = true,
                                cover = null,
                                pendingTap = tapAt,
                                onTapUsed = { tapAt = null },
                                dragOffset = { if (handleMoving) snappedOffset(dragPreview) else Offset.Zero },
                                focusRequester = fieldFocus,
                                onText = { value ->
                                    newTextId = -1
                                    setAddedText(currentPage.id, added.id, typing = true) { it.copy(text = value) }
                                },
                                onDone = { deselect() },
                                onMoveStart = {
                                    dragPreview = Offset.Zero
                                    handleMoving = true
                                },
                                onMove = { delta -> latestDrag(delta) },
                                onMoveEnd = { latestDragEnd() }
                            )
                        }
                    }
                }

                // Avisos sobre la hoja.
                when {
                    loadingPage || bitmap == null -> {
                        CircularProgressIndicator(color = NeonGreen, modifier = Modifier.align(Alignment.Center))
                    }
                    analyzing -> DocScanStatusChip(analyzeStep, Modifier.align(Alignment.TopCenter))
                    showOriginal -> DocScanStatusChip("Foto original · toca \"Original\" para volver", Modifier.align(Alignment.TopCenter))
                    analysis != null && (analysis.failed || analysis.lines.isEmpty()) ->
                        DocScanStatusChip("No se encontró texto en esta página", Modifier.align(Alignment.TopCenter))
                    pressMoving -> DocScanStatusChip("Arrastra · las líneas rosadas te ayudan a alinear", Modifier.align(Alignment.TopCenter))
                }
            }

            // ---------------- Barra de abajo ----------------
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DocScanBar)
                    .navigationBarsPadding()
                    .padding(vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val sel = selection
                val selectedBlock = (sel as? DocScanSelBlock)?.let { blockSel ->
                    analysis?.blocks?.firstOrNull { it.id == blockSel.blockId }
                }
                val selectedText = (sel as? DocScanSelText)?.let { textSel ->
                    currentEdits.texts.firstOrNull { it.id == textSel.textId }
                }
                val selectedSign = (sel as? DocScanSelSign)?.let { signSel ->
                    currentEdits.signs.firstOrNull { it.id == signSel.signId }
                }
                val selectedObject = (sel as? DocScanSelObject)?.let { objectSel ->
                    pieces.firstOrNull { it.id == objectSel.objectId }
                }

                when {
                    pressMoving -> {
                        DocScanHint("Suelta para dejarlo ahí. Deshacer lo regresa.")
                    }

                    selectedBlock != null -> {
                        val block = selectedBlock
                        val edit = currentEdits.blocks[block.id] ?: block.originalEdit()
                        val changed = currentEdits.blocks.containsKey(block.id)
                        if (edit.deleted) {
                            DocScanRow {
                                Text("Párrafo borrado", color = DocScanMuted, fontSize = 13.sp)
                                DocScanChip(active = false, onClick = { setBlockEdit(currentPage.id, block, edit.copy(deleted = false)) }) {
                                    DocScanLabel("Recuperar")
                                }
                                DocScanChip(active = false, onClick = { deselect() }) {
                                    Text("Listo", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        } else {
                            DocScanEditBar(
                                bold = edit.bold,
                                italic = edit.italic,
                                color = edit.color,
                                align = edit.align,
                                showColors = showColors,
                                changed = changed,
                                onBold = { setBlockEdit(currentPage.id, block, edit.copy(bold = !edit.bold)) },
                                onItalic = { setBlockEdit(currentPage.id, block, edit.copy(italic = !edit.italic)) },
                                onColors = { showColors = !showColors },
                                onSmaller = { setBlockEdit(currentPage.id, block, edit.copy(scale = (edit.scale * 0.92f).coerceAtLeast(0.4f))) },
                                onBigger = { setBlockEdit(currentPage.id, block, edit.copy(scale = (edit.scale * 1.08f).coerceAtMost(3f))) },
                                onAlign = { setBlockEdit(currentPage.id, block, edit.copy(align = docScanNextAlign(edit.align))) },
                                onDelete = {
                                    setBlockEdit(currentPage.id, block, edit.copy(deleted = true))
                                    deselect()
                                    onMessage("Párrafo borrado. Deshacer lo regresa.")
                                },
                                onRestore = { setBlockEdit(currentPage.id, block, block.originalEdit()) },
                                onDone = { deselect() }
                            )
                            if (showColors) {
                                DocScanPaletteRow(selected = edit.color) { color ->
                                    setBlockEdit(currentPage.id, block, edit.copy(color = color))
                                }
                            }
                        }
                    }

                    selectedObject != null -> {
                        val piece = selectedObject
                        val edit = currentEdits.objects[piece.id] ?: DocScanObjectEdit()
                        if (edit.deleted) {
                            DocScanRow {
                                Text("Imagen quitada", color = DocScanMuted, fontSize = 13.sp)
                                DocScanChip(active = false, onClick = { setObjectEdit(currentPage.id, piece.id, edit.copy(deleted = false)) }) {
                                    DocScanLabel("Recuperar")
                                }
                                DocScanChip(active = false, onClick = { deselect() }) {
                                    Text("Listo", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        } else {
                            DocScanRow {
                                DocScanChip(active = false, onClick = {
                                    setObjectEdit(currentPage.id, piece.id, edit.copy(scale = (edit.scale * 0.9f).coerceAtLeast(0.2f)))
                                }) { DocScanLabel("Más chica") }
                                DocScanChip(active = false, onClick = {
                                    setObjectEdit(currentPage.id, piece.id, edit.copy(scale = (edit.scale * 1.1f).coerceAtMost(4f)))
                                }) { DocScanLabel("Más grande") }
                                DocScanChip(active = false, onClick = {
                                    setObjectEdit(currentPage.id, piece.id, edit.copy(deleted = true))
                                    deselect()
                                }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = DocScanDanger, modifier = Modifier.size(20.dp))
                                }
                                if (edit != DocScanObjectEdit()) {
                                    DocScanChip(active = false, onClick = { setObjectEdit(currentPage.id, piece.id, DocScanObjectEdit()) }) {
                                        Icon(Icons.Rounded.Refresh, contentDescription = "Como estaba", tint = DocScanInk, modifier = Modifier.size(20.dp))
                                    }
                                }
                                DocScanDoneChip { deselect() }
                            }
                            DocScanHint("Mantén presionada la imagen para moverla.")
                        }
                    }

                    selectedText != null -> {
                        val added = selectedText
                        DocScanEditBar(
                            bold = added.bold,
                            italic = added.italic,
                            color = added.color,
                            align = null,
                            showColors = showColors,
                            changed = false,
                            onBold = { setAddedText(currentPage.id, added.id) { it.copy(bold = !it.bold) } },
                            onItalic = { setAddedText(currentPage.id, added.id) { it.copy(italic = !it.italic) } },
                            onColors = { showColors = !showColors },
                            onSmaller = { setAddedText(currentPage.id, added.id) { it.copy(size = (it.size * 0.92f).coerceAtLeast(0.005f)) } },
                            onBigger = { setAddedText(currentPage.id, added.id) { it.copy(size = (it.size * 1.08f).coerceAtMost(0.2f)) } },
                            onAlign = {},
                            onDelete = {
                                updatePage(currentPage.id) { page -> page.copy(texts = page.texts.filterNot { it.id == added.id }) }
                                deselect()
                            },
                            onRestore = {},
                            onDone = { deselect() }
                        )
                        if (showColors) {
                            DocScanPaletteRow(selected = added.color) { color -> setAddedText(currentPage.id, added.id) { it.copy(color = color) } }
                        }
                    }

                    selectedSign != null -> {
                        val sign = selectedSign
                        DocScanRow {
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page ->
                                    page.copy(signs = page.signs.map { if (it.id == sign.id) it.resizedBy(0.9f) else it })
                                }
                            }) { DocScanLabel("Más chica") }
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page ->
                                    page.copy(signs = page.signs.map { if (it.id == sign.id) it.resizedBy(1.1f) else it })
                                }
                            }) { DocScanLabel("Más grande") }
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page -> page.copy(signs = page.signs.filterNot { it.id == sign.id }) }
                                deselect()
                            }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Quitar", tint = DocScanDanger, modifier = Modifier.size(20.dp))
                            }
                            DocScanDoneChip { deselect() }
                        }
                        DocScanHint("Mantén presionada para moverla.")
                    }

                    else -> {
                        if (pages.size > 1) {
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(horizontal = 10.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                itemsIndexed(pages, key = { _, page -> page.id }) { index, page ->
                                    val current = page.id == currentPage.id
                                    Box(
                                        modifier = Modifier
                                            .size(width = 42.dp, height = 54.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF22352B))
                                            .border(
                                                width = if (current) 2.dp else 1.dp,
                                                color = if (current) NeonGreen else Color(0xFF2E4237),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable { if (!current) currentId = page.id },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        val thumb = thumbs[page.id]
                                        if (thumb != null) {
                                            Image(
                                                bitmap = thumb,
                                                contentDescription = "Página ${index + 1}",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                        Text(
                                            "${index + 1}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .background(Color(0x99000000), RoundedCornerShape(topStart = 6.dp))
                                                .padding(horizontal = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            DocScanToolButton(Icons.Rounded.Description, "Texto", active = false) {
                                deselect()
                                showText = true
                            }
                            DocScanToolButton(Icons.Rounded.TextFields, "Escribir", active = false) { addText() }
                            DocScanToolButton(Icons.Rounded.Draw, "Firma", active = false) { showSignature = true }
                            DocScanToolButton(Icons.Rounded.Image, "Imagen", active = false) {
                                pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                            DocScanToolButton(Icons.Rounded.Visibility, "Original", active = showOriginal) {
                                if (shownCleaned != null) showOriginal = !showOriginal
                            }
                        }
                        DocScanHint("Toca para escribir · Mantén presionado para mover")
                    }
                }
            }
        }

        // ---------------- Ventanas ----------------
        if (showText) {
            DocScanTextMode(
                pages = pages,
                currentPageId = currentPage.id,
                analyses = analyses,
                edits = edits,
                fontChoice = fontChoice,
                paid = textPaid,
                cost = tool.creditCost,
                onClose = { showText = false },
                onBlockText = { pageId, block, text ->
                    val edit = edits[pageId]?.blocks?.get(block.id) ?: block.originalEdit()
                    setBlockEdit(pageId, block, edit.copy(text = text, deleted = false), typing = true)
                },
                onAddedText = { pageId, textId, text ->
                    setAddedText(pageId, textId, typing = true) { it.copy(text = text) }
                },
                onCopy = { text ->
                    withPaidText(text) { value ->
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        runCatching { clipboard?.setPrimaryClip(ClipData.newPlainText("Texto escaneado", value)) }
                        onMessage("Texto copiado.")
                    }
                },
                onShare = { text ->
                    withPaidText(text) { value ->
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, value)
                        }
                        runCatching { context.startActivity(Intent.createChooser(send, "Compartir texto")) }
                    }
                }
            )
        }

        if (showSignature) {
            DocScanSignaturePad(
                onCancel = { showSignature = false },
                onDone = { bitmap ->
                    showSignature = false
                    addSign(bitmap)
                }
            )
        }

        if (showSave) {
            AlertDialog(
                onDismissRequest = { showSave = false },
                containerColor = CardGreen,
                title = { Text("Guardar como", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DocScanFormatOption(
                            "PDF",
                            if (pages.size > 1) "Las ${pages.size} páginas, como se ven. Con texto real que se puede editar y copiar."
                            else "Como se ve la hoja. Con texto real que se puede editar y copiar."
                        ) { chooseFormat(DOC_SCAN_FORMAT_PDF) }
                        DocScanFormatOption("Word", "Los párrafos con su tamaño, negrita, color y alineación.") {
                            chooseFormat(DOC_SCAN_FORMAT_WORD)
                        }
                        DocScanFormatOption(
                            "Imagen JPG",
                            if (pages.size > 1) "Esta página (la $pageNumber), como se ve." else "La hoja, como se ve."
                        ) { chooseFormat(DOC_SCAN_FORMAT_IMAGE) }
                        Text(
                            "Cada archivo cuesta ${tool.creditCost} créditos.",
                            color = DocScanMuted,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showSave = false }) { Text("Cancelar") }
                }
            )
        }

        if (confirmExit) {
            AlertDialog(
                onDismissRequest = { confirmExit = false },
                containerColor = CardGreen,
                title = { Text("¿Salir sin guardar?", fontWeight = FontWeight.Bold) },
                text = { Text("Se perderán los cambios que hiciste en este documento.") },
                confirmButton = {
                    TextButton(onClick = {
                        confirmExit = false
                        onClose()
                    }) { Text("Salir", color = DocScanDanger) }
                },
                dismissButton = {
                    TextButton(onClick = { confirmExit = false }) { Text("Seguir editando") }
                }
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Piezas de la interfaz
// ---------------------------------------------------------------------------

/** Izquierda → centro → derecha → justificado → izquierda. */
private fun docScanNextAlign(align: Int): Int = when (align) {
    DOC_SCAN_ALIGN_LEFT -> DOC_SCAN_ALIGN_CENTER
    DOC_SCAN_ALIGN_CENTER -> DOC_SCAN_ALIGN_RIGHT
    DOC_SCAN_ALIGN_RIGHT -> DOC_SCAN_ALIGN_JUSTIFY
    else -> DOC_SCAN_ALIGN_LEFT
}

private fun docScanAlignIcon(align: Int): ImageVector = when (align) {
    DOC_SCAN_ALIGN_CENTER -> Icons.Rounded.FormatAlignCenter
    DOC_SCAN_ALIGN_RIGHT -> Icons.Rounded.FormatAlignRight
    DOC_SCAN_ALIGN_JUSTIFY -> Icons.Rounded.FormatAlignJustify
    else -> Icons.Rounded.FormatAlignLeft
}

@Composable
private fun DocScanStatusChip(text: String, modifier: Modifier) {
    Text(
        text,
        color = DocScanInk,
        fontSize = 13.sp,
        modifier = modifier
            .padding(top = 10.dp)
            .clip(RoundedCornerShape(50))
            .background(Color(0xE6101D16))
            .padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
private fun DocScanMenuLabel(text: String) {
    Text(
        text,
        color = DocScanMuted,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
    )
}

@Composable
private fun DocScanHint(text: String) {
    Text(
        text,
        color = DocScanMuted,
        fontSize = 12.sp,
        textAlign = TextAlign.Center,
        maxLines = 1,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
    )
}

@Composable
private fun DocScanRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        content()
    }
}

@Composable
private fun DocScanChip(
    active: Boolean,
    onClick: () -> Unit,
    enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .height(42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) DocScanChipOn else DocScanChipIdle)
            .border(
                width = 1.dp,
                color = if (active) NeonGreen.copy(alpha = 0.7f) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        content()
    }
}

/** Botón cuadrado de la barra de formato. */
@Composable
private fun DocScanIconChip(active: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .size(width = 44.dp, height = 42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) DocScanChipOn else DocScanChipIdle)
            .border(
                width = 1.dp,
                color = if (active) NeonGreen.copy(alpha = 0.7f) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
private fun DocScanDoneChip(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(width = 52.dp, height = 42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(NeonGreen)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.Check, contentDescription = "Listo", tint = DeepGreen, modifier = Modifier.size(24.dp))
    }
}

/** Botón grande de la barra de abajo (ícono y nombre corto). */
@Composable
private fun DocScanToolButton(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(66.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (active) DocScanChipOn else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = if (active) NeonGreen else DocScanInk, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (active) NeonGreen else DocScanInk, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun DocScanLabel(text: String) {
    Text(text, color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 13.sp)
}

/**
 * Barra de formato mientras se escribe: una sola fila encima del teclado.
 * [align] null = sin botón de alineación (textos agregados).
 */
@Composable
private fun DocScanEditBar(
    bold: Boolean,
    italic: Boolean,
    color: Int,
    align: Int?,
    showColors: Boolean,
    changed: Boolean,
    onBold: () -> Unit,
    onItalic: () -> Unit,
    onColors: () -> Unit,
    onSmaller: () -> Unit,
    onBigger: () -> Unit,
    onAlign: () -> Unit,
    onDelete: () -> Unit,
    onRestore: () -> Unit,
    onDone: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DocScanIconChip(active = bold, onClick = onBold) {
                Text("B", color = DocScanInk, fontWeight = FontWeight.Black, fontSize = 17.sp)
            }
            DocScanIconChip(active = italic, onClick = onItalic) {
                Text("I", color = DocScanInk, fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            DocScanIconChip(active = showColors, onClick = onColors) {
                Box(
                    Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(Color(color))
                        .border(1.dp, DocScanMuted, CircleShape)
                )
            }
            DocScanIconChip(active = false, onClick = onSmaller) {
                Text("A−", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            DocScanIconChip(active = false, onClick = onBigger) {
                Text("A+", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            if (align != null) {
                DocScanIconChip(active = false, onClick = onAlign) {
                    Icon(docScanAlignIcon(align), contentDescription = "Alinear", tint = DocScanInk, modifier = Modifier.size(22.dp))
                }
            }
            DocScanIconChip(active = false, onClick = onDelete) {
                Icon(Icons.Rounded.Delete, contentDescription = "Borrar", tint = DocScanDanger, modifier = Modifier.size(21.dp))
            }
            if (changed) {
                DocScanIconChip(active = false, onClick = onRestore) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Como estaba", tint = DocScanInk, modifier = Modifier.size(21.dp))
                }
            }
        }
        Spacer(Modifier.width(6.dp))
        DocScanDoneChip(onDone)
    }
}

@Composable
private fun DocScanPaletteRow(selected: Int, onPick: (Int) -> Unit) {
    DocScanRow {
        DocScanPalette.forEach { swatch ->
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(swatch))
                    .border(
                        width = if (selected == swatch) 2.dp else 1.dp,
                        color = if (selected == swatch) NeonGreen else DocScanMuted,
                        shape = CircleShape
                    )
                    .clickable { onPick(swatch) }
            )
        }
    }
}

@Composable
private fun DocScanFormatOption(title: String, detail: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF123524))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(title, fontWeight = FontWeight.Bold, color = NeonGreen)
        Text(detail, style = MaterialTheme.typography.bodySmall, color = DocScanInk.copy(alpha = 0.85f))
    }
}

/**
 * Escribir directo sobre la hoja, como en Word: un campo de texto puesto justo
 * encima del párrafo, con la misma letra, tamaño, color, ancho y alineación.
 * La hoja se ve detrás. Todo va en píxeles de la hoja encajada ([left], [baseline],
 * [width], [fontSize], [leading]); el zoom lo lleva a la pantalla.
 * Arriba tiene una manija para arrastrarlo.
 */
@Composable
private fun DocScanInlineEditor(
    zoom: DocScanZoomState,
    fieldKey: String,
    text: String,
    selectAll: Boolean,
    left: Float,
    baseline: Float,
    width: Float?,
    fontSize: Float,
    leading: Float,
    scaleX: Float,
    typeface: android.graphics.Typeface,
    color: Color,
    align: Int,
    singleLine: Boolean,
    cover: Color?,
    pendingTap: Offset?,
    onTapUsed: () -> Unit,
    dragOffset: () -> Offset,
    focusRequester: FocusRequester,
    onText: (String) -> Unit,
    onDone: () -> Unit,
    onMoveStart: () -> Unit,
    onMove: (Offset) -> Unit,
    onMoveEnd: () -> Unit
) {
    val density = LocalDensity.current
    val scale = zoom.scale
    val screenFont = (fontSize * scale).coerceAtLeast(2f)
    val screenLeading = (leading * scale).coerceAtLeast(screenFont)
    var field by remember(fieldKey) {
        mutableStateOf(TextFieldValue(text, if (selectAll) TextRange(0, text.length) else TextRange(text.length)))
    }
    // Si el texto cambió por fuera (deshacer, rehacer, modo texto), se muestra el del documento.
    val shown = if (field.text == text) field else TextFieldValue(text, TextRange(text.length))
    var firstBaseline by remember(fieldKey) { mutableFloatStateOf(Float.NaN) }
    var textLayout by remember(fieldKey) { mutableStateOf<TextLayoutResult?>(null) }
    val latestTap by rememberUpdatedState(pendingTap)
    val latestTapUsed by rememberUpdatedState(onTapUsed)
    val latestMoveStart by rememberUpdatedState(onMoveStart)
    val latestMove by rememberUpdatedState(onMove)
    val latestMoveEnd by rememberUpdatedState(onMoveEnd)
    val fontFamily = remember(typeface) { FontFamily(androidx.compose.ui.text.font.Typeface(typeface)) }
    val style = TextStyle(
        color = color,
        fontSize = with(density) { screenFont.toSp() },
        lineHeight = with(density) { screenLeading.toSp() },
        fontFamily = fontFamily,
        textAlign = when (align) {
            DOC_SCAN_ALIGN_CENTER -> TextAlign.Center
            DOC_SCAN_ALIGN_RIGHT -> TextAlign.Right
            DOC_SCAN_ALIGN_JUSTIFY -> TextAlign.Justify
            else -> TextAlign.Left
        },
        textGeometricTransform = TextGeometricTransform(scaleX = scaleX),
        lineBreak = LineBreak.Simple
    )
    val handleSize = 34.dp
    val handlePx = with(density) { handleSize.toPx() }

    // Esquina de arriba a la izquierda del campo, en la pantalla (la línea base cae justo
    // donde estaba el texto de la hoja).
    fun topLeft(): Offset {
        val drag = dragOffset()
        val base = if (firstBaseline.isNaN()) screenFont * 0.8f else firstBaseline
        return Offset(
            left * zoom.scale + zoom.offsetX + drag.x * zoom.scale,
            baseline * zoom.scale + zoom.offsetY + drag.y * zoom.scale - base
        )
    }

    // El cursor siempre a la vista: si se sale de la pantalla al escribir, la hoja se corre.
    LaunchedEffect(shown.selection, textLayout) {
        val result = textLayout ?: return@LaunchedEffect
        val length = result.layoutInput.text.text.length
        val cursor = result.getCursorRect(shown.selection.end.coerceIn(0, length))
        val origin = topLeft()
        zoom.keepVisible(origin.x + cursor.left, origin.y + cursor.top, origin.y + cursor.bottom)
    }

    BasicTextField(
        value = shown,
        onValueChange = { next ->
            field = next
            if (next.text != text) onText(next.text)
        },
        textStyle = style,
        singleLine = singleLine,
        cursorBrush = SolidColor(DocScanFocus),
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.Sentences,
            imeAction = if (singleLine) ImeAction.Done else ImeAction.Default
        ),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        onTextLayout = { result ->
            firstBaseline = result.firstBaseline
            textLayout = result
            val tap = latestTap
            if (tap != null) {
                // El cursor va donde se tocó la hoja.
                val screen = zoom.toScreen(tap)
                val fieldLeft = left * zoom.scale + zoom.offsetX
                val fieldTop = baseline * zoom.scale + zoom.offsetY - result.firstBaseline
                val offset = result.getOffsetForPosition(Offset(screen.x - fieldLeft, screen.y - fieldTop))
                field = TextFieldValue(result.layoutInput.text.text, TextRange(offset))
                latestTapUsed()
            }
        },
        modifier = Modifier
            .offset {
                val point = topLeft()
                IntOffset(point.x.roundToInt(), point.y.roundToInt())
            }
            .wrapContentSize(Alignment.TopStart, unbounded = true)
            .then(
                if (width != null) {
                    Modifier.width(with(density) { (width * scale).coerceAtLeast(8f).toDp() })
                } else {
                    Modifier.widthIn(min = 20.dp)
                }
            )
            .then(if (cover != null) Modifier.background(cover) else Modifier)
            .focusRequester(focusRequester)
    )

    // Manija para mover (arriba a la izquierda del párrafo).
    Box(
        modifier = Modifier
            .offset {
                val point = topLeft()
                IntOffset((point.x - handlePx * 0.2f).roundToInt(), (point.y - handlePx - 8f).roundToInt())
            }
            .size(handleSize)
            .clip(CircleShape)
            .background(DocScanFocus)
            .pointerInput(fieldKey) {
                detectDragGestures(
                    onDragStart = { latestMoveStart() },
                    onDrag = { change, amount ->
                        change.consume()
                        latestMove(Offset(amount.x / zoom.scale, amount.y / zoom.scale))
                    },
                    onDragEnd = { latestMoveEnd() },
                    onDragCancel = { latestMoveEnd() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.OpenWith, contentDescription = "Mover", tint = Color.White, modifier = Modifier.size(20.dp))
    }
}

/** Un párrafo en el modo texto. */
private class DocScanNote(
    val key: String,
    val top: Float,
    val left: Float,
    val text: String,
    val bold: Boolean,
    val block: DocScanBlock?,
    val textId: Int
)

/**
 * Modo texto: la hoja como un bloc de notas. Cada párrafo se edita como texto
 * normal y el cambio pasa a la hoja (en su lugar, con su letra). Desde aquí
 * también se copia o comparte todo el texto, en orden.
 */
@Composable
private fun DocScanTextMode(
    pages: List<DocScanPage>,
    currentPageId: Int,
    analyses: MutableMap<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    fontChoice: Int,
    paid: Boolean,
    cost: Int,
    onClose: () -> Unit,
    onBlockText: (Int, DocScanBlock, String) -> Unit,
    onAddedText: (Int, Int, String) -> Unit,
    onCopy: (String) -> Unit,
    onShare: (String) -> Unit
) {
    val context = LocalContext.current
    var allPages by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }

    // Para "Todas las páginas" se leen las que todavía no se abrieron.
    LaunchedEffect(allPages) {
        if (!allPages) return@LaunchedEffect
        if (pages.all { analyses[it.id] != null }) return@LaunchedEffect
        loading = true
        try {
            val read = docScanEnsureAnalyses(context, pages, analyses.toMap())
            read.forEach { (id, value) -> analyses[id] = value }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            // Se muestra lo que se pudo leer.
        } finally {
            loading = false
        }
    }

    val analysis = analyses[currentPageId]
    val pageEdits = edits[currentPageId] ?: DocScanPageEdits()
    val layout = remember(analysis, pageEdits.blocks, fontChoice) {
        analysis?.takeIf { it.blocks.isNotEmpty() }?.let { docScanLayout(it, pageEdits.blocks, fontChoice) }
    }
    val notes = remember(layout, pageEdits.texts, analysis) {
        val list = ArrayList<DocScanNote>()
        val read = analysis
        if (read != null && layout != null) {
            for (placed in layout.blocks) {
                if (placed.deleted) continue
                val block = read.blocks.firstOrNull { it.id == placed.id } ?: continue
                list += DocScanNote("b${placed.id}", placed.rect.top, placed.rect.left, placed.text, placed.bold, block, -1)
            }
        }
        val pageWidth = (read?.width ?: 1).toFloat()
        val pageHeight = (read?.height ?: 1).toFloat()
        for (added in pageEdits.texts) {
            list += DocScanNote(
                "t${added.id}", (added.y - added.size) * pageHeight, added.x * pageWidth, added.text, added.bold, null, added.id
            )
        }
        list.sortedWith(compareBy<DocScanNote>({ it.top }, { it.left }))
    }
    val pageIndex = pages.indexOfFirst { it.id == currentPageId }
    val copyText = when {
        loading -> ""
        else -> docScanAllText(
            if (allPages) pages else listOfNotNull(pages.getOrNull(pageIndex)),
            analyses,
            edits,
            fontChoice
        )
    }
    val price = if (paid) "" else " · $cost créditos"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DocScanBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = DocScanInk)
            }
            Column(Modifier.weight(1f)) {
                Text("Texto de la hoja", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    (if (pages.size > 1) "Página ${pageIndex + 1} · " else "") + "Toca y escribe: pasa a la hoja",
                    color = DocScanMuted,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }
            Box(
                modifier = Modifier
                    .padding(end = 8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(NeonGreen)
                    .clickable { onClose() }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text("Ver hoja", color = DeepGreen, fontWeight = FontWeight.Black, fontSize = 14.sp)
            }
        }

        // La hoja como bloc de notas.
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFFFAFBF8))
        ) {
            if (notes.isEmpty()) {
                Text(
                    if (analysis == null) "Espera a que termine de leer la hoja." else "No se encontró texto en esta página.",
                    color = Color(0xFF5A665F),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(notes, key = { it.key }) { note ->
                        DocScanNoteField(
                            fieldKey = note.key,
                            text = note.text,
                            bold = note.bold,
                            onText = { value ->
                                val block = note.block
                                if (block != null) onBlockText(currentPageId, block, value) else onAddedText(currentPageId, note.textId, value)
                            }
                        )
                        HorizontalDivider(
                            color = Color(0xFFE3E8E4),
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            }
        }

        if (pages.size > 1) {
            Spacer(Modifier.height(8.dp))
            DocScanRow {
                Text("Copiar:", color = DocScanMuted, fontSize = 13.sp)
                DocScanChip(active = !allPages, onClick = { allPages = false }) { DocScanLabel("Esta página") }
                DocScanChip(active = allPages, onClick = { allPages = true }) { DocScanLabel("Todas") }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(DocScanChipIdle)
                    .clickable(enabled = !loading && copyText.isNotBlank()) { onCopy(copyText) },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = DocScanInk, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Copiar$price", color = DocScanInk, fontWeight = FontWeight.Bold)
            }
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(DocScanChipIdle)
                    .clickable(enabled = !loading && copyText.isNotBlank()) { onShare(copyText) },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Share, contentDescription = null, tint = DocScanInk, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Compartir$price", color = DocScanInk, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Un párrafo editable del modo texto. */
@Composable
private fun DocScanNoteField(fieldKey: String, text: String, bold: Boolean, onText: (String) -> Unit) {
    var field by remember(fieldKey) { mutableStateOf(TextFieldValue(text, TextRange(text.length))) }
    val shown = if (field.text == text) field else TextFieldValue(text, TextRange(text.length))
    BasicTextField(
        value = shown,
        onValueChange = { next ->
            field = next
            if (next.text != text) onText(next.text)
        },
        textStyle = TextStyle(
            color = Color(0xFF1C2420),
            fontSize = 16.sp,
            lineHeight = 23.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        ),
        cursorBrush = SolidColor(DocScanFocus),
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 11.dp)
    )
}

/** Cuadro para firmar con el dedo. Devuelve la firma como imagen con fondo transparente. */
@Composable
private fun DocScanSignaturePad(onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    val live = remember { mutableStateListOf<Offset>() }
    val strokeWidthPx = with(LocalDensity.current) { 3.dp.toPx() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xE6000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 18.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(DocScanBar)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Firma con el dedo", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { start ->
                                live.clear()
                                live.add(start)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                live.add(change.position)
                            },
                            onDragEnd = {
                                if (live.size > 1) strokes.add(live.toList())
                                live.clear()
                            },
                            onDragCancel = { live.clear() }
                        )
                    }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val ink = Color(DocScanSignatureInk)
                    fun line(points: List<Offset>) {
                        for (index in 1 until points.size) {
                            drawLine(
                                color = ink,
                                start = points[index - 1],
                                end = points[index],
                                strokeWidth = strokeWidthPx,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                    strokes.forEach { line(it) }
                    line(live.toList())
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DocScanChip(active = false, onClick = {
                    strokes.clear()
                    live.clear()
                }) { DocScanLabel("Limpiar") }
                Spacer(Modifier.weight(1f))
                DocScanChip(active = false, onClick = onCancel) { DocScanLabel("Cancelar") }
                DocScanChip(active = true, enabled = strokes.isNotEmpty(), onClick = {
                    val bitmap = docScanSignatureBitmap(strokes.toList(), strokeWidthPx)
                    if (bitmap != null) onDone(bitmap) else onCancel()
                }) {
                    Text("Usar", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

/** Pasa los trazos a una imagen recortada justo al tamaño de la firma. */
private fun docScanSignatureBitmap(strokes: List<List<Offset>>, strokeWidthPx: Float): Bitmap? {
    val points = strokes.flatten()
    if (points.size < 2) return null
    val margin = strokeWidthPx * 2f + 4f
    val left = points.minOf { it.x } - margin
    val top = points.minOf { it.y } - margin
    val width = (points.maxOf { it.x } + margin - left).roundToInt().coerceIn(8, 4000)
    val height = (points.maxOf { it.y } + margin - top).roundToInt().coerceIn(8, 4000)
    return runCatching {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = DocScanSignatureInk
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = strokeWidthPx
            strokeCap = android.graphics.Paint.Cap.ROUND
            strokeJoin = android.graphics.Paint.Join.ROUND
        }
        strokes.forEach { stroke ->
            if (stroke.size < 2) return@forEach
            val path = android.graphics.Path()
            path.moveTo(stroke[0].x - left, stroke[0].y - top)
            for (index in 1 until stroke.size) path.lineTo(stroke[index].x - left, stroke[index].y - top)
            canvas.drawPath(path, paint)
        }
        bitmap
    }.getOrNull()
}
