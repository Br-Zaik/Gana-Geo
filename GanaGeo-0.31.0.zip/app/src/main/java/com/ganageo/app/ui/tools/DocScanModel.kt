package com.ganageo.app.ui.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.InkLook
import com.ganageo.app.tools.OcrLine
import com.ganageo.app.tools.OcrTextRefiner
import com.ganageo.app.tools.ScanDictionary
import com.ganageo.app.tools.ScanFontMatch
import com.ganageo.app.tools.ScanGuides
import com.ganageo.app.tools.ScanInpaint
import com.ganageo.app.tools.ScanLook
import com.ganageo.app.tools.ScanObjects
import com.ganageo.app.tools.ScanPaper
import com.ganageo.app.tools.ScanRebuild
import com.ganageo.app.tools.ToolFileUtils
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType0Font
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.util.Matrix
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Escáner de documentos: reconstrucción de la hoja (como "editar un escaneo"
// en Acrobat). Todo pasa en el celular.
//
// 1. Se lee el texto (lector de Google). Si la hoja está chueca o volteada, se
//    endereza y se vuelve a leer. Las partes dudosas o de letra chica se leen
//    otra vez de cerca (ampliadas).
// 2. Se juntan los pedazos de renglón y se quitan los repetidos.
// 3. Se mide cada renglón: color del fondo, de la letra y dónde está la tinta.
// 4. Se elige la letra más parecida (se dibuja cada palabra con cada letra
//    disponible y se compara con la foto) y el tamaño exacto (por el alto real
//    de la tinta). Un mismo estilo queda con un mismo tamaño en toda la hoja.
// 5. Se borran de la foto SOLO los puntos de las letras: fondos, barras de
//    color, fotos y líneas quedan iguales.
// 6. Encima se escribe el texto de verdad. Se edita por párrafo.
// ---------------------------------------------------------------------------

/** Lado más largo con que se trabaja cada página (lectura, vista y guardado). */
internal const val DOC_SCAN_PAGE_EDGE = 2200
internal const val DOC_SCAN_THUMB_EDGE = 256
internal const val DOC_SCAN_MAX_PAGES = 20
internal const val DOC_SCAN_DOCX_MIME =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

private const val DOC_SCAN_DESCENDERS = "gjpqyQ,;()[]{}|"

internal const val DOC_SCAN_ALIGN_LEFT = OcrTextRefiner.ALIGN_LEFT
internal const val DOC_SCAN_ALIGN_CENTER = OcrTextRefiner.ALIGN_CENTER
internal const val DOC_SCAN_ALIGN_RIGHT = OcrTextRefiner.ALIGN_RIGHT
internal const val DOC_SCAN_ALIGN_JUSTIFY = OcrTextRefiner.ALIGN_JUSTIFY

/** Letra automática (la que se parece a la foto). */
internal const val DOC_SCAN_FONT_AUTO = -1

/** Tamaño de hoja automático (el que se detecta en la foto). */
internal const val DOC_SCAN_PAPER_AUTO = -1

// ---------------------------------------------------------------------------
// Letras incluidas (gratis, de uso libre; ver assets/fonts/LICENCIAS.txt).
// Se usan las mismas en la pantalla y dentro del PDF: se ve igual en los dos.
// ---------------------------------------------------------------------------

internal object DocScanFonts {
    /** Nombre que se muestra. */
    val labels = listOf("Arial", "Times", "Calibri", "Cambria", "Angosta", "Moderna")

    /** Nombre de la letra en Word (las primeras tienen las mismas medidas). */
    val wordNames = listOf("Arial", "Times New Roman", "Calibri", "Cambria", "Arial Narrow", "Poppins")

    /** Archivos: normal, negrita, cursiva, negrita cursiva. */
    private val files = listOf(
        listOf("LiberationSans-Regular", "LiberationSans-Bold", "LiberationSans-Italic", "LiberationSans-BoldItalic"),
        listOf("LiberationSerif-Regular", "LiberationSerif-Bold", "LiberationSerif-Italic", "LiberationSerif-BoldItalic"),
        listOf("Carlito-Regular", "Carlito-Bold", "Carlito-Italic", "Carlito-BoldItalic"),
        listOf("Caladea-Regular", "Caladea-Bold", "Caladea-Italic", "Caladea-BoldItalic"),
        listOf("DejaVuSansCondensed", "DejaVuSansCondensed-Bold", "DejaVuSansCondensed-Oblique", "DejaVuSansCondensed-BoldOblique"),
        listOf("Poppins-Regular", "Poppins-Bold", "Poppins-Italic", "Poppins-BoldItalic")
    )

    val count: Int get() = files.size

    private val cache = arrayOfNulls<Typeface>(files.size * 4)

    @Volatile
    private var assets: android.content.res.AssetManager? = null

    fun init(context: Context) {
        if (assets == null) assets = context.applicationContext.assets
    }

    private fun style(bold: Boolean, italic: Boolean) = (if (bold) 1 else 0) + (if (italic) 2 else 0)

    fun file(family: Int, bold: Boolean, italic: Boolean): String =
        "fonts/" + files[family.coerceIn(0, files.lastIndex)][style(bold, italic)] + ".ttf"

    fun typeface(family: Int, bold: Boolean, italic: Boolean): Typeface {
        val safe = family.coerceIn(0, files.lastIndex)
        val index = safe * 4 + style(bold, italic)
        cache[index]?.let { return it }
        val loaded = runCatching { assets?.let { Typeface.createFromAsset(it, file(safe, bold, italic)) } }.getOrNull()
            ?: Typeface.create(
                if (safe == 1 || safe == 3) Typeface.SERIF else Typeface.SANS_SERIF,
                when {
                    bold && italic -> Typeface.BOLD_ITALIC
                    bold -> Typeface.BOLD
                    italic -> Typeface.ITALIC
                    else -> Typeface.NORMAL
                }
            )
        cache[index] = loaded
        return loaded
    }

    fun open(context: Context, family: Int, bold: Boolean, italic: Boolean): java.io.InputStream =
        context.assets.open(file(family, bold, italic))
}

/** Lista de palabras en español para corregir lo mal leído (se carga una vez). */
internal object DocScanWords {
    @Volatile
    private var loaded: ScanDictionary? = null

    fun get(context: Context): ScanDictionary? {
        loaded?.let { return it }
        return synchronized(this) {
            loaded ?: runCatching {
                context.applicationContext.assets.open("dict/es.txt.gz").use { raw ->
                    java.util.zip.GZIPInputStream(raw).bufferedReader(Charsets.UTF_8).use { it.readText() }
                }
            }.getOrNull()?.let { ScanDictionary(it) }?.also { loaded = it }
        }
    }
}

// ---------------------------------------------------------------------------
// Datos
// ---------------------------------------------------------------------------

/** Una página del documento: la foto tal como llegó. */
internal data class DocScanPage(val id: Int, val uri: Uri)

/** Palabra leída (en píxeles de la foto enderezada). */
internal class DocScanWord(val text: String, val box: Rect)

/** Renglón leído, en píxeles de la foto enderezada, con su aspecto. */
internal class DocScanLine(
    val id: Int,
    val text: String,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val background: Int,
    val ink: Int,
    val bold: Boolean,
    /** Borde real de la tinta (sin tildes sueltas); vacío si no se pudo medir. */
    val inkBox: RectF?
)

/** Párrafo: renglones seguidos del mismo estilo. Es lo que se toca y se edita. */
internal class DocScanBlock(
    val id: Int,
    val lines: List<DocScanLine>,
    val text: String,
    val align: Int,
    val ink: Int,
    val background: Int,
    val bold: Boolean,
    /** Letra más parecida (índice en [DocScanFonts]). */
    val family: Int,
    /** Tamaño de letra en píxeles de la foto. */
    val size: Float,
    /** Ancho de la letra respecto a la normal (1 = igual). */
    val scaleX: Float,
    /** Hasta dónde puede crecer a la derecha un título de un solo renglón. */
    val maxRight: Float,
    /** Hasta dónde puede crecer a la izquierda (lo que hay al lado en el mismo renglón). */
    val minLeft: Float = 0f
) {
    val left: Float = lines.minOf { it.left }
    val top: Float = lines.minOf { it.top }
    val right: Float = lines.maxOf { it.right }
    val bottom: Float = lines.maxOf { it.bottom }
}

/** Resultado de leer una página (medidas en píxeles de la foto enderezada). */
internal class DocScanAnalysis(
    val width: Int,
    val height: Int,
    val lines: List<DocScanLine>,
    val blocks: List<DocScanBlock>,
    /** Giro aplicado a la foto para enderezarla (grados). */
    val rotation: Float = 0f,
    /** Hoja detectada (índice en ScanRebuild.papers) o -1. */
    val paper: Int = -1,
    /** Letra principal de la hoja (para el texto que se agregue). */
    val mainFamily: Int = 0,
    /** Logos, fotos e íconos sobre el papel: [izq, arriba, der, abajo) en px. */
    val objects: List<IntArray> = emptyList(),
    val failed: Boolean = false
) {
    val landscape: Boolean get() = width > height

    /** Márgenes reales del texto de la hoja (para centrar y alinear como en Word). */
    val margins: ScanGuides.Margins by lazy {
        ScanGuides.margins(lines.map { it.left }, lines.map { it.right }, width.toFloat())
    }
}

/** Lectura terminada: el análisis y la foto ya enderezada. */
internal class DocScanRead(val analysis: DocScanAnalysis, val bitmap: Bitmap)

/** Cambio hecho por la persona a un párrafo. */
internal data class DocScanBlockEdit(
    val text: String,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val align: Int,
    val scale: Float = 1f,
    val deleted: Boolean = false,
    /** Movido (en píxeles de la foto). */
    val dx: Float = 0f,
    val dy: Float = 0f
)

/** Cambio hecho a un logo o foto de la hoja. */
internal data class DocScanObjectEdit(
    val dx: Float = 0f,
    val dy: Float = 0f,
    val scale: Float = 1f,
    val deleted: Boolean = false
)

/** Logo, foto o ícono recortado de la hoja (con su forma: fuera de ella es transparente). */
internal class DocScanObject(val id: Int, val rect: Rect, val bitmap: Bitmap)

/** Hoja lista para mostrar: el fondo (sin texto ni piezas) y las piezas. */
internal class DocScanCleaned(val base: Bitmap, val objects: List<DocScanObject>) {
    fun recycle() {
        base.recycle()
        objects.forEach { it.bitmap.recycle() }
    }
}

/** Dónde queda una pieza con su cambio (en píxeles de la foto). */
internal fun docScanObjectRect(rect: Rect, edit: DocScanObjectEdit?): RectF {
    if (edit == null) return RectF(rect)
    val width = rect.width() * edit.scale
    val height = rect.height() * edit.scale
    val left = rect.left + edit.dx - (width - rect.width()) / 2f
    val top = rect.top + edit.dy - (height - rect.height()) / 2f
    return RectF(left, top, left + width, top + height)
}

internal fun DocScanBlock.originalEdit() = DocScanBlockEdit(text, bold, false, ink, align)

/** Texto nuevo agregado en la hoja. x = borde izquierdo, y = línea base (de 0 a 1). */
internal data class DocScanAddedText(
    val id: Int,
    val x: Float,
    val y: Float,
    val text: String,
    /** Tamaño de la letra como fracción del alto de la página. */
    val size: Float,
    val color: Int,
    val bold: Boolean = false,
    val italic: Boolean = false
)

/** Firma o imagen pegada. x, y = esquina de arriba a la izquierda; width = fracción del ancho. */
internal class DocScanSign(
    val id: Int,
    val x: Float,
    val y: Float,
    val width: Float,
    val bitmap: Bitmap
) {
    fun movedBy(dx: Float, dy: Float) =
        DocScanSign(id, (x + dx).coerceIn(-0.2f, 0.98f), (y + dy).coerceIn(-0.2f, 0.98f), width, bitmap)

    fun resizedBy(factor: Float) = DocScanSign(id, x, y, (width * factor).coerceIn(0.05f, 1f), bitmap)
}

/** Todo lo que se cambió en una página. */
internal data class DocScanPageEdits(
    val blocks: Map<Int, DocScanBlockEdit> = emptyMap(),
    val objects: Map<Int, DocScanObjectEdit> = emptyMap(),
    val texts: List<DocScanAddedText> = emptyList(),
    val signs: List<DocScanSign> = emptyList()
) {
    val isEmpty: Boolean get() = blocks.isEmpty() && objects.isEmpty() && texts.isEmpty() && signs.isEmpty()
}

/** "A4 vertical", "Carta horizontal"… o "" si no se reconoce. */
internal fun docScanPaperLabel(paper: Int, landscape: Boolean): String {
    val name = ScanRebuild.papers.getOrNull(paper)?.first ?: return ""
    return name + if (landscape) " horizontal" else " vertical"
}

// ---------------------------------------------------------------------------
// Lectura
// ---------------------------------------------------------------------------

private suspend fun docScanRecognize(recognizer: TextRecognizer, bitmap: Bitmap): Text =
    suspendCancellableCoroutine { continuation ->
        val task = recognizer.process(InputImage.fromBitmap(bitmap, 0))
        task.addOnSuccessListener { result -> if (continuation.isActive) continuation.resume(result) }
        task.addOnFailureListener { error -> if (continuation.isActive) continuation.resumeWithException(error) }
        task.addOnCanceledListener { if (continuation.isActive) continuation.cancel() }
    }

/** Renglón tal como lo entrega el lector (en píxeles de la foto enderezada). */
private class DocScanRawLine(val text: String, val box: Rect, val words: List<DocScanWord>)

private fun docScanMapRect(rect: Rect, scale: Float, offsetX: Int, offsetY: Int) = Rect(
    (rect.left / scale).roundToInt() + offsetX,
    (rect.top / scale).roundToInt() + offsetY,
    (rect.right / scale).roundToInt() + offsetX,
    (rect.bottom / scale).roundToInt() + offsetY
)

private fun docScanRawLines(block: Text.TextBlock, scale: Float = 1f, offsetX: Int = 0, offsetY: Int = 0): List<DocScanRawLine> {
    val result = ArrayList<DocScanRawLine>()
    for (line in block.lines) {
        val box = line.boundingBox ?: continue
        val words = line.elements.mapNotNull { element ->
            element.boundingBox?.let { DocScanWord(element.text, docScanMapRect(it, scale, offsetX, offsetY)) }
        }
        result += DocScanRawLine(line.text, docScanMapRect(box, scale, offsetX, offsetY), words)
    }
    return result
}

/** Ángulo de los renglones (grados): 0 = derecho, 90/180/-90 = hoja girada. */
private fun docScanSkew(result: Text): Float {
    val angles = ArrayList<Float>()
    for (block in result.textBlocks) for (line in block.lines) {
        if (line.text.length < 6) continue
        val points = line.cornerPoints ?: continue
        if (points.size < 2) continue
        val dx = (points[1].x - points[0].x).toDouble()
        val dy = (points[1].y - points[0].y).toDouble()
        if (dx == 0.0 && dy == 0.0) continue
        angles += Math.toDegrees(atan2(dy, dx)).toFloat()
    }
    if (angles.size < 3) return 0f
    fun quarterOf(angle: Float) = Math.floorMod((angle / 90f).roundToInt(), 4)
    val votes = IntArray(4)
    angles.forEach { votes[quarterOf(it)]++ }
    val quarter = votes.indices.maxByOrNull { votes[it] } ?: 0
    val residuals = angles.filter { quarterOf(it) == quarter }.map {
        var value = it - quarter * 90f
        while (value > 180f) value -= 360f
        while (value < -180f) value += 360f
        value
    }
    val residual = ScanRebuild.medianAngle(residuals)
    if (abs(residual) > 15f) return 0f
    val base = when (quarter) {
        1 -> 90f
        2 -> 180f
        3 -> -90f
        else -> 0f
    }
    return base + residual
}

/** Color del papel (mediana de los bordes de la foto), para rellenar al girar. */
private fun docScanPaperColor(bitmap: Bitmap): Int {
    val samples = ArrayList<Int>()
    val stepX = max(1, bitmap.width / 40)
    val stepY = max(1, bitmap.height / 40)
    for (x in 0 until bitmap.width step stepX) {
        samples += bitmap.getPixel(x, 2.coerceAtMost(bitmap.height - 1))
        samples += bitmap.getPixel(x, (bitmap.height - 3).coerceAtLeast(0))
    }
    for (y in 0 until bitmap.height step stepY) {
        samples += bitmap.getPixel(2.coerceAtMost(bitmap.width - 1), y)
        samples += bitmap.getPixel((bitmap.width - 3).coerceAtLeast(0), y)
    }
    if (samples.isEmpty()) return android.graphics.Color.WHITE
    fun channel(shift: Int) = samples.map { (it shr shift) and 0xFF }.sorted()[samples.size / 2]
    return android.graphics.Color.rgb(channel(16), channel(8), channel(0))
}

/** Gira la foto [rotation] grados (para enderezarla). Si no hace falta, devuelve la misma. */
internal fun docScanStraighten(source: Bitmap, rotation: Float): Bitmap {
    if (abs(rotation) < 0.05f) return source
    val quarter = (rotation / 90f).roundToInt()
    val swap = Math.floorMod(quarter, 2) == 1
    val outWidth = if (swap) source.height else source.width
    val outHeight = if (swap) source.width else source.height
    val output = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    canvas.drawColor(docScanPaperColor(source))
    val matrix = android.graphics.Matrix()
    matrix.postTranslate(-source.width / 2f, -source.height / 2f)
    matrix.postRotate(rotation)
    matrix.postTranslate(outWidth / 2f, outHeight / 2f)
    canvas.drawBitmap(source, matrix, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    return output
}

/** Quita íconos leídos como letras al principio o al final ("E PERFIL") y arregla viñetas. */
private fun docScanTrimIcons(line: DocScanRawLine): DocScanRawLine {
    if (line.words.size < 2) return line
    var words = line.words.sortedBy { it.box.left }
    val height = line.box.height().coerceAtLeast(1)
    fun junk(word: DocScanWord) =
        word.text.length <= 3 && word.text.count { it.isLetterOrDigit() } <= 1 && !word.text.all { it.isDigit() }
    var changed = false
    while (words.size >= 2 && junk(words.first()) && words[1].box.left - words.first().box.right > height * 0.9f) {
        // Viñeta leída como letra: "e Ejercicios" → "• Ejercicios".
        val first = words.first()
        if (first.text in setOf("e", "o", "°", "*", "•", "·") && words[1].text.firstOrNull()?.isUpperCase() == true) break
        words = words.drop(1)
        changed = true
    }
    while (words.size >= 2 && junk(words.last()) && words.last().box.left - words[words.size - 2].box.right > height * 0.9f) {
        words = words.dropLast(1)
        changed = true
    }
    val first = words.first()
    if (words.size >= 2 && first.text in setOf("e", "o", "°", "*") &&
        words[1].text.firstOrNull()?.isUpperCase() == true &&
        words[1].box.left - first.box.right > height * 0.3f
    ) {
        words = listOf(DocScanWord("•", first.box)) + words.drop(1)
        changed = true
    }
    if (!changed) return line
    val box = Rect(words.first().box)
    words.forEach { box.union(it.box) }
    return DocScanRawLine(words.joinToString(" ") { it.text }, box, words)
}

/** Muestra de una palabra para comparar letras: forma de la tinta a tamaño chico. */
private class DocScanSample(val text: String, val map: FloatArray, val width: Int, val height: Int)

/** Dibuja palabras con cada letra y las compara con la foto. */
private class DocScanFontJudge {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bounds = Rect()
    private var bitmap: Bitmap? = null
    private var canvas: Canvas? = null
    private var pixels = IntArray(0)

    fun score(sample: DocScanSample, family: Int, bold: Boolean): Float? {
        val text = ScanFontMatch.withoutMarks(sample.text)
        paint.typeface = DocScanFonts.typeface(family, bold, false)
        paint.textSize = 100f
        paint.textScaleX = 1f
        paint.getTextBounds(text, 0, text.length, bounds)
        if (bounds.width() <= 0 || bounds.height() <= 0) return null
        val width = sample.width
        val height = sample.height
        var target = bitmap
        if (target == null || target.width < width || target.height < height) {
            target?.recycle()
            target = Bitmap.createBitmap(max(width, 600), max(height, 40), Bitmap.Config.ARGB_8888)
            bitmap = target
            canvas = Canvas(target)
        }
        val drawCanvas = canvas ?: return null
        target.eraseColor(0)
        drawCanvas.save()
        drawCanvas.scale(width / bounds.width().toFloat(), height / bounds.height().toFloat())
        drawCanvas.drawText(text, -bounds.left.toFloat(), -bounds.top.toFloat(), paint)
        drawCanvas.restore()
        if (pixels.size < width * height) pixels = IntArray(width * height)
        target.getPixels(pixels, 0, width, 0, 0, width, height)
        val drawn = FloatArray(width * height) { ((pixels[it] ushr 24) and 0xFF) / 255f }
        val ratio = (bounds.width() * height / bounds.height().toFloat()) / width
        return ScanFontMatch.score(ScanFontMatch.similarity(sample.map, ScanFontMatch.sharpen(drawn)), ratio)
    }

    /** Tamaño (px) y ancho relativo de un renglón con esta letra, por el alto real de la tinta. */
    fun measure(text: String, inkBox: RectF, family: Int, bold: Boolean): Pair<Float, Float>? {
        val clean = ScanFontMatch.withoutMarks(text)
        paint.typeface = DocScanFonts.typeface(family, bold, false)
        paint.textSize = 100f
        paint.textScaleX = 1f
        paint.getTextBounds(clean, 0, clean.length, bounds)
        if (bounds.width() <= 0 || bounds.height() <= 0 || inkBox.height() < 3f) return null
        val size = 100f * inkBox.height() / bounds.height()
        val scaleX = inkBox.width() / (bounds.width() * size / 100f)
        return size to scaleX
    }

    fun close() {
        bitmap?.recycle()
        bitmap = null
        canvas = null
    }
}

private fun docScanColorDistance(a: Int, b: Int): Int =
    abs(android.graphics.Color.red(a) - android.graphics.Color.red(b)) +
        abs(android.graphics.Color.green(a) - android.graphics.Color.green(b)) +
        abs(android.graphics.Color.blue(a) - android.graphics.Color.blue(b))

private fun docScanPixels(bitmap: Bitmap, rect: Rect): IntArray? {
    val left = rect.left.coerceIn(0, bitmap.width)
    val top = rect.top.coerceIn(0, bitmap.height)
    val right = rect.right.coerceIn(left, bitmap.width)
    val bottom = rect.bottom.coerceIn(top, bitmap.height)
    if (right - left < 1 || bottom - top < 1) return null
    rect.set(left, top, right, bottom)
    val pixels = IntArray(rect.width() * rect.height())
    bitmap.getPixels(pixels, 0, rect.width(), left, top, rect.width(), rect.height())
    return pixels
}

/**
 * Lee la página y la deja lista para reconstruir. Puede tardar unos segundos:
 * se lee dos veces lo dudoso y se compara cada letra. [onStep] avisa qué está haciendo.
 */
internal suspend fun docScanAnalyze(
    context: Context,
    source: Bitmap,
    onStep: (String) -> Unit = {}
): DocScanRead {
    DocScanFonts.init(context)
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    try {
        onStep("Leyendo el texto…")
        var bitmap = source
        var result = try {
            docScanRecognize(recognizer, bitmap)
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            return DocScanRead(DocScanAnalysis(source.width, source.height, emptyList(), emptyList(), failed = true), source)
        }

        // 1) Enderezar si está chueca o girada, y volver a leer.
        var rotation = 0f
        val skew = withContext(Dispatchers.Default) { docScanSkew(result) }
        if (abs(skew) >= 0.35f) {
            onStep("Enderezando la hoja…")
            rotation = -skew
            bitmap = withContext(Dispatchers.Default) { docScanStraighten(source, rotation) }
            result = runCatching { docScanRecognize(recognizer, bitmap) }.getOrElse {
                if (it is kotlinx.coroutines.CancellationException) throw it
                rotation = 0f
                if (bitmap !== source) bitmap.recycle()
                bitmap = source
                result
            }
        }

        // 2) Lo dudoso o de letra chica se vuelve a leer ampliado.
        onStep("Revisando de cerca…")
        val raw = ArrayList<DocScanRawLine>()
        for (block in result.textBlocks) {
            val first = docScanRawLines(block)
            if (first.isEmpty()) continue
            var chosen = first
            val heights = first.map { it.box.height() }.sorted()
            val lineHeight = heights[heights.size / 2]
            val text = first.joinToString(" ") { it.text }
            val quality = ScanRebuild.textScore(text)
            val area = Rect(block.boundingBox ?: first.first().box)
            first.forEach { area.union(it.box) }
            if (lineHeight >= 6 && (lineHeight < 30 || quality < 0.96f)) {
                val margin = (lineHeight * 0.6f).roundToInt()
                val crop = Rect(area.left - margin, area.top - margin, area.right + margin, area.bottom + margin)
                crop.intersect(0, 0, bitmap.width, bitmap.height)
                var factor = (44f / lineHeight).coerceIn(1.3f, 3f)
                val pixelsAfter = crop.width().toFloat() * crop.height() * factor * factor
                if (pixelsAfter > 9_000_000f) factor = sqrt(9_000_000f / (crop.width().toFloat() * crop.height()))
                if (factor >= 1.15f && crop.width() > 4 && crop.height() > 4) {
                    val again = runCatching {
                        val piece = Bitmap.createBitmap(bitmap, crop.left, crop.top, crop.width(), crop.height())
                        val scaled = Bitmap.createScaledBitmap(
                            piece, (crop.width() * factor).roundToInt(), (crop.height() * factor).roundToInt(), true
                        )
                        if (piece !== bitmap && piece !== scaled) piece.recycle()
                        try {
                            val read = docScanRecognize(recognizer, scaled)
                            read.textBlocks.flatMap { docScanRawLines(it, factor, crop.left, crop.top) }
                        } finally {
                            scaled.recycle()
                        }
                    }.getOrElse {
                        if (it is kotlinx.coroutines.CancellationException) throw it
                        emptyList()
                    }.filter { line ->
                        val centerX = line.box.exactCenterX()
                        val centerY = line.box.exactCenterY()
                        centerX >= area.left - margin / 2 && centerX <= area.right + margin / 2 &&
                            centerY >= area.top - margin / 2 && centerY <= area.bottom + margin / 2
                    }
                    if (again.isNotEmpty()) {
                        val againText = again.joinToString(" ") { it.text }
                        val ratio = againText.length / text.length.coerceAtLeast(1).toFloat()
                        val againQuality = ScanRebuild.textScore(againText)
                        if (ratio in 0.8f..1.3f && againQuality > quality + 0.015f) chosen = again
                    }
                }
            }
            raw += chosen
        }

        onStep("Corrigiendo palabras…")
        val dictionary = withContext(Dispatchers.IO) { DocScanWords.get(context) }
        onStep("Midiendo la letra y buscando logos y fotos…")
        val analysis = withContext(Dispatchers.Default) { docScanMeasure(bitmap, raw, rotation, dictionary) }
        return DocScanRead(analysis, bitmap)
    } finally {
        runCatching { recognizer.close() }
    }
}

/** Junta renglones, mide colores, arma párrafos y elige letra y tamaño. */
private fun docScanMeasure(
    bitmap: Bitmap,
    raw: List<DocScanRawLine>,
    rotation: Float,
    dictionary: ScanDictionary?
): DocScanAnalysis {
    val width = bitmap.width
    val height = bitmap.height

    // Pedazos del mismo renglón juntos; repetidos fuera; íconos fuera.
    val trimmed = raw.map { docScanTrimIcons(it) }
    val groups = runCatching {
        ScanRebuild.mergeLines(trimmed.map { OcrLine(it.text, it.box.left, it.box.top, it.box.right, it.box.bottom) })
    }.getOrElse { trimmed.indices.map { intArrayOf(it) } }
    val mergedAndObjects = groups.map { group ->
        if (group.size == 1) {
            trimmed[group[0]]
        } else {
            val parts = group.map { trimmed[it] }
            val box = Rect(parts.first().box)
            parts.forEach { box.union(it.box) }
            DocScanRawLine(parts.joinToString(" ") { it.text }, box, parts.flatMap { it.words })
        }
    }.mapNotNull { line ->
        val box = Rect(line.box)
        if (!box.intersect(0, 0, width, height) || box.width() < 2 || box.height() < 4) return@mapNotNull null
        val fixed = OcrTextRefiner.fixLine(line.text).trim()
        val text = dictionary?.let { runCatching { it.fixText(fixed) }.getOrDefault(fixed) } ?: fixed
        if (text.none { it.isLetterOrDigit() }) return@mapNotNull null
        DocScanRawLine(text, box, line.words)
    }.let { found -> docScanFindObjects(bitmap, found) }
    val merged = mergedAndObjects.first
    val objects = mergedAndObjects.second

    // Aspecto de cada renglón y borde real de la tinta.
    val looks = ArrayList<InkLook>(merged.size)
    val inkBoxes = ArrayList<RectF?>(merged.size)
    for (line in merged) {
        val box = line.box
        val pad = max(3, box.height() / 3)
        val zone = Rect(box.left - pad, box.top - pad, box.right + pad, box.bottom + pad)
        val pixels = docScanPixels(bitmap, zone)
        val look = if (pixels == null) {
            InkLook(android.graphics.Color.WHITE, android.graphics.Color.BLACK, 0f)
        } else {
            runCatching {
                ScanLook.measure(
                    pixels, zone.width(), zone.height(),
                    box.left - zone.left, box.top - zone.top, box.right - zone.left, box.bottom - zone.top
                )
            }.getOrElse { InkLook(android.graphics.Color.WHITE, android.graphics.Color.BLACK, 0f) }
        }
        looks += look
        val inner = Rect(box.left - 1, box.top - 1, box.right + 1, box.bottom + 1)
        val innerPixels = docScanPixels(bitmap, inner)
        inkBoxes += innerPixels?.let {
            val map = ScanFontMatch.inkMap(it, inner.width(), inner.height(), look.background, look.ink)
            ScanFontMatch.inkBounds(map, inner.width(), inner.height())?.let { b ->
                RectF((inner.left + b[0]).toFloat(), (inner.top + b[1]).toFloat(), (inner.left + b[2]).toFloat(), (inner.top + b[3]).toFloat())
            }
        }
    }
    val bold = ScanLook.boldFlags(
        FloatArray(merged.size) { looks[it].stroke },
        FloatArray(merged.size) { merged[it].box.height().toFloat() }
    )
    val lines = merged.mapIndexed { index, line ->
        DocScanLine(
            id = index,
            text = line.text,
            left = line.box.left.toFloat(),
            top = line.box.top.toFloat(),
            right = line.box.right.toFloat(),
            bottom = line.box.bottom.toFloat(),
            background = looks[index].background,
            ink = looks[index].ink,
            bold = bold[index],
            inkBox = inkBoxes[index]
        )
    }
    if (lines.isEmpty()) {
        return DocScanAnalysis(width, height, emptyList(), emptyList(), rotation, ScanRebuild.paperOf(width, height), objects = objects)
    }

    // Párrafos.
    val located = lines.map {
        OcrLine(it.text, it.left.roundToInt(), it.top.roundToInt(), it.right.roundToInt(), it.bottom.roundToInt())
    }
    val paragraphGroups = runCatching {
        OcrTextRefiner.paragraphs(located, width) { a, b ->
            val first = lines[a]
            val second = lines[b]
            val firstHeight = first.bottom - first.top
            val secondHeight = second.bottom - second.top
            first.bold == second.bold &&
                abs(firstHeight - secondHeight) <= max(firstHeight, secondHeight) * 0.25f &&
                docScanColorDistance(first.ink, second.ink) < 120 &&
                docScanColorDistance(first.background, second.background) < 90
        }
    }.getOrElse { lines.indices.map { intArrayOf(it) } }.mapNotNull { group -> group.map { lines[it] }.takeIf { it.isNotEmpty() } }

    // Letra más parecida: se vota por tipo de texto (normal / negrita, chico / grande).
    val judge = DocScanFontJudge()
    try {
        val sortedHeights = lines.map { it.bottom - it.top }.sorted()
        val typicalHeight = sortedHeights[sortedHeights.size / 2]
        fun kind(line: DocScanLine, isBold: Boolean) = (if (isBold) 1 else 0) + (if (line.bottom - line.top > typicalHeight * 1.6f) 2 else 0)
        val totals = Array(4) { FloatArray(DocScanFonts.count) }
        val wordRect = Rect()
        for (members in paragraphGroups) {
            val blockBold = members.count { it.bold } * 2 > members.size
            for (line in members) {
                val rawLine = merged[line.id]
                val words = rawLine.words.filter { word -> word.text.count { it.isLetter() } >= 3 }
                    .sortedByDescending { it.text.length }.take(5)
                for (word in words) {
                    wordRect.set(word.box.left - 2, word.box.top - 2, word.box.right + 2, word.box.bottom + 2)
                    val pixels = docScanPixels(bitmap, wordRect) ?: continue
                    val map = ScanFontMatch.inkMap(pixels, wordRect.width(), wordRect.height(), line.background, line.ink)
                    val b = ScanFontMatch.inkBounds(map, wordRect.width(), wordRect.height()) ?: continue
                    val inkWidth = b[2] - b[0]
                    val inkHeight = b[3] - b[1]
                    if (inkHeight < 8 || inkWidth < 4) continue
                    val sampleHeight = min(inkHeight, 40)
                    val sampleWidth = (inkWidth * sampleHeight / inkHeight.toFloat()).roundToInt().coerceIn(4, 600)
                    val sample = DocScanSample(
                        word.text,
                        ScanFontMatch.resample(map, wordRect.width(), b, sampleWidth, sampleHeight),
                        sampleWidth,
                        sampleHeight
                    )
                    val bucket = totals[kind(line, blockBold)]
                    for (family in 0 until DocScanFonts.count) {
                        val score = judge.score(sample, family, blockBold) ?: continue
                        bucket[family] += score * word.text.length
                    }
                }
            }
        }
        fun bestFamily(kind: Int): Int {
            val order = listOf(kind, kind xor 2, kind xor 1, 0)
            for (candidate in order) {
                val bucket = totals[candidate]
                if (bucket.any { it != 0f }) return bucket.indices.maxByOrNull { bucket[it] } ?: 0
            }
            return 0
        }

        // Párrafos con su letra, tamaño y ancho.
        class Draft(val members: List<DocScanLine>, val bold: Boolean, val family: Int, var size: Float, var scaleX: Float, val align: Int)
        val drafts = paragraphGroups.map { members ->
            val blockBold = members.count { it.bold } * 2 > members.size
            val family = bestFamily(kind(members.first(), blockBold))
            val measured = members.mapNotNull { line -> line.inkBox?.let { judge.measure(line.text, it, family, blockBold) } }
                .filter { (size, _) -> size > 2f }
            val boxHeights = members.map { it.bottom - it.top }.sorted()
            val fallbackSize = boxHeights[boxHeights.size / 2] * 0.9f
            val size = if (measured.isEmpty()) fallbackSize else ScanRebuild.quantile(measured.map { it.first }, 0.5f)
                .coerceIn(fallbackSize * 0.5f, fallbackSize * 2.4f)
            val align = if (members.size == 1) {
                val line = members.first()
                val center = (line.left + line.right) / 2f
                if (abs(center - width / 2f) < width * 0.025f && line.left > width * 0.12f) DOC_SCAN_ALIGN_CENTER else DOC_SCAN_ALIGN_LEFT
            } else {
                OcrTextRefiner.alignmentOf(members.map { located[it.id] }, width)
            }
            val widths = measured.map { it.second }
            val scaleX = when {
                widths.isEmpty() -> 1f
                align == DOC_SCAN_ALIGN_JUSTIFY -> ScanRebuild.quantile(widths, 0.25f)
                else -> ScanRebuild.quantile(widths, 0.5f)
            }.coerceIn(0.8f, 1.25f)
            Draft(members, blockBold, family, size, scaleX, align)
        }

        // Mismo estilo = mismo tamaño en toda la hoja (así no queda una letra más grande).
        drafts.groupBy { it.family * 2 + if (it.bold) 1 else 0 }.values.forEach { same ->
            val sorted = same.sortedBy { it.size }
            var start = 0
            while (start < sorted.size) {
                var end = start + 1
                while (end < sorted.size && sorted[end].size <= sorted[start].size * 1.08f) end++
                val cluster = sorted.subList(start, end)
                val size = ScanRebuild.quantile(cluster.map { it.size }, 0.5f)
                val scaleX = ScanRebuild.quantile(cluster.map { it.scaleX }, 0.5f)
                cluster.forEach {
                    it.size = size
                    it.scaleX = scaleX
                }
                start = end
            }
        }

        val blocks = drafts.mapIndexed { index, draft ->
            val members = draft.members
            val left = members.minOf { it.left }
            val top = members.minOf { it.top }
            val right = members.maxOf { it.right }
            val bottom = members.maxOf { it.bottom }
            val lineHeight = bottom - top
            var limit = width * 0.98f
            var leftLimit = width * 0.02f
            if (members.size == 1) {
                for (other in drafts) {
                    if (other === draft) continue
                    val otherTop = other.members.minOf { it.top }
                    val otherBottom = other.members.maxOf { it.bottom }
                    val otherLeft = other.members.minOf { it.left }
                    val otherRight = other.members.maxOf { it.right }
                    val overlap = min(bottom, otherBottom) - max(top, otherTop)
                    if (overlap > lineHeight * 0.4f && otherLeft >= right - lineHeight * 0.2f) {
                        limit = min(limit, otherLeft - lineHeight * 0.3f)
                    }
                    if (overlap > lineHeight * 0.4f && otherRight <= left + lineHeight * 0.2f) {
                        leftLimit = max(leftLimit, otherRight + lineHeight * 0.3f)
                    }
                }
            }
            DocScanBlock(
                id = index,
                lines = members,
                text = ScanRebuild.joinLines(members.map { it.text }),
                align = draft.align,
                ink = members.first().ink,
                background = members.first().background,
                bold = draft.bold,
                family = draft.family,
                size = draft.size,
                scaleX = draft.scaleX,
                maxRight = max(right, limit),
                minLeft = min(left, leftLimit)
            )
        }
        val usage = IntArray(DocScanFonts.count)
        blocks.filter { !it.bold }.forEach { usage[it.family] += it.text.length }
        val mainFamily = usage.indices.maxByOrNull { usage[it] }?.takeIf { usage[it] > 0 } ?: blocks.first().family
        return DocScanAnalysis(width, height, lines, blocks, rotation, ScanRebuild.paperOf(width, height), mainFamily, objects)
    } finally {
        judge.close()
    }
}

/** Cajas de borrado de cada renglón (con un pequeño margen). */
private fun docScanEraseBoxes(lines: List<Rect>, scaleX: Float = 1f, scaleY: Float = 1f): List<IntArray> = lines.map { box ->
    val lineHeight = box.height() * scaleY
    val padX = max(1f, lineHeight * 0.08f)
    val padY = max(1f, lineHeight * 0.06f)
    intArrayOf(
        (box.left * scaleX - padX).toInt(),
        (box.top * scaleY - padY).toInt(),
        (box.right * scaleX + padX).toInt() + 1,
        (box.bottom * scaleY + padY).toInt() + 1
    )
}

/**
 * Busca logos, fotos e íconos sobre el papel (en una copia sin texto).
 * El texto que está DENTRO de un logo (letras chicas del escudo) se deja como
 * parte del logo: no se borra ni se reescribe.
 */
private fun docScanFindObjects(bitmap: Bitmap, lines: List<DocScanRawLine>): Pair<List<DocScanRawLine>, List<IntArray>> {
    val width = bitmap.width
    val height = bitmap.height
    val found = runCatching {
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        ScanInpaint.eraseInk(pixels, width, height, docScanEraseBoxes(lines.map { it.box }))
        ScanPaper.whiten(pixels, width, height)
        val paper = ScanObjects.paperColor(pixels, width, height)
        if (paper == -1) emptyList() else ScanObjects.find(pixels, width, height, paper)
    }.getOrElse { emptyList() }
    if (found.isEmpty()) return lines to emptyList()
    val keep = BooleanArray(lines.size) { true }
    val objects = ArrayList<IntArray>()
    for (box in found) {
        val inside = lines.indices.filter { index ->
            val line = lines[index].box
            line.exactCenterX() >= box[0] && line.exactCenterX() <= box[2] &&
                line.exactCenterY() >= box[1] && line.exactCenterY() <= box[3]
        }
        // Con texto de verdad adentro (un párrafo, una tarjeta): no es una pieza.
        val small = inside.size <= 3 && inside.all { index ->
            lines[index].box.height() < height * 0.03f && lines[index].text.length <= 40
        }
        if (inside.isNotEmpty() && !small) continue
        inside.forEach { keep[it] = false }
        objects += box
    }
    return lines.filterIndexed { index, _ -> keep[index] } to objects
}

/**
 * Hoja lista: la foto sin las letras leídas (solo los puntos de tinta), con el
 * papel blanco parejo si [cleanPaper], y los logos y fotos separados como piezas.
 * Devuelve imágenes nuevas.
 */
internal suspend fun docScanCleanPage(source: Bitmap, analysis: DocScanAnalysis, cleanPaper: Boolean): DocScanCleaned =
    withContext(Dispatchers.Default) {
        val width = source.width
        val height = source.height
        val scaleX = width / analysis.width.coerceAtLeast(1).toFloat()
        val scaleY = height / analysis.height.coerceAtLeast(1).toFloat()
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)
        val boxes = docScanEraseBoxes(
            analysis.lines.map { Rect(it.left.toInt(), it.top.toInt(), it.right.roundToInt(), it.bottom.roundToInt()) },
            scaleX,
            scaleY
        )
        ScanInpaint.eraseInk(pixels, width, height, boxes)
        if (cleanPaper) ScanPaper.whiten(pixels, width, height)
        val paper = ScanObjects.paperColor(pixels, width, height).takeIf { it != -1 } ?: android.graphics.Color.WHITE

        // Piezas: se recortan con su forma y su lugar queda del color del papel.
        val objects = ArrayList<DocScanObject>()
        analysis.objects.forEachIndexed { index, raw ->
            val box = intArrayOf(
                (raw[0] * scaleX).toInt().coerceIn(0, width),
                (raw[1] * scaleY).toInt().coerceIn(0, height),
                (raw[2] * scaleX).roundToInt().coerceIn(0, width),
                (raw[3] * scaleY).roundToInt().coerceIn(0, height)
            )
            val boxWidth = box[2] - box[0]
            val boxHeight = box[3] - box[1]
            if (boxWidth < 2 || boxHeight < 2) return@forEachIndexed
            val alpha = ScanObjects.alpha(pixels, width, box, paper)
            val piece = IntArray(boxWidth * boxHeight)
            for (y in 0 until boxHeight) for (x in 0 until boxWidth) {
                val offset = (box[1] + y) * width + box[0] + x
                val on = alpha[y * boxWidth + x] != 0.toByte()
                piece[y * boxWidth + x] = if (on) pixels[offset] else 0
                if (on) pixels[offset] = paper
            }
            val bitmap = Bitmap.createBitmap(piece, boxWidth, boxHeight, Bitmap.Config.ARGB_8888)
            // La pieza queda en píxeles de la foto analizada (para moverla con el texto).
            objects += DocScanObject(
                index,
                Rect(
                    (box[0] / scaleX).roundToInt(), (box[1] / scaleY).roundToInt(),
                    (box[2] / scaleX).roundToInt(), (box[3] / scaleY).roundToInt()
                ),
                bitmap
            )
        }
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        output.setPixels(pixels, 0, width, 0, 0, width, height)
        DocScanCleaned(output, objects)
    }

// ---------------------------------------------------------------------------
// Filtros de imagen (se aplican al dibujar: no se copia la foto)
// ---------------------------------------------------------------------------

internal fun docScanFilterMatrix(filter: DocumentImageFilter): FloatArray? {
    if (filter == DocumentImageFilter.ORIGINAL) return null
    val contrast = when (filter) {
        DocumentImageFilter.DOCUMENT -> 1.28f
        DocumentImageFilter.ENHANCE -> 1.08f
        else -> 1f
    }
    val saturation = when (filter) {
        DocumentImageFilter.GRAYSCALE, DocumentImageFilter.DOCUMENT -> 0f
        DocumentImageFilter.ENHANCE -> 1.18f
        else -> 1f
    }
    val matrix = ColorMatrix()
    matrix.setSaturation(saturation)
    val translate = (-0.5f * contrast + 0.5f) * 255f
    matrix.postConcat(
        ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )
    return matrix.array.copyOf()
}

/** Aplica la matriz del filtro a un color (para que el texto combine con la foto filtrada). */
internal fun docScanFilterColor(color: Int, matrix: FloatArray?): Int {
    if (matrix == null) return color
    val r = android.graphics.Color.red(color).toFloat()
    val g = android.graphics.Color.green(color).toFloat()
    val b = android.graphics.Color.blue(color).toFloat()
    fun channel(row: Int): Int =
        (matrix[row * 5] * r + matrix[row * 5 + 1] * g + matrix[row * 5 + 2] * b + matrix[row * 5 + 3] * 255f + matrix[row * 5 + 4])
            .roundToInt().coerceIn(0, 255)
    return android.graphics.Color.rgb(channel(0), channel(1), channel(2))
}

// ---------------------------------------------------------------------------
// Armado del texto de la hoja (sirve igual para la pantalla, el PDF y la imagen)
// ---------------------------------------------------------------------------

/** Un renglón de texto listo para dibujar. width = ancho final; justify = repartir palabras. */
internal data class DocScanRun(
    /** Párrafo al que pertenece (-1 = texto agregado). */
    val blockId: Int,
    val text: String,
    val x: Float,
    val baseline: Float,
    val size: Float,
    val scaleX: Float,
    val width: Float,
    val family: Int,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val justify: Boolean
)

/**
 * Párrafo ya armado: dónde quedó y con qué formato (para tocarlo, copiarlo y el Word).
 * También guarda su "caja de escritura" (ancho, primera línea base, interlineado) para
 * escribir directo encima de la hoja con la misma letra.
 */
internal class DocScanPlacedBlock(
    val id: Int,
    val rect: RectF,
    val text: String,
    val size: Float,
    val family: Int,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val align: Int,
    val background: Int,
    val deleted: Boolean,
    /** Ancho donde se acomoda el texto (ya movido). */
    val areaLeft: Float = rect.left,
    val areaRight: Float = rect.right,
    /** Línea base del primer renglón (ya movida). */
    val baseline: Float = rect.bottom,
    /** Distancia entre renglones. */
    val leading: Float = size * 1.22f,
    /** Ancho de la letra respecto a la normal. */
    val scaleX: Float = 1f
)

/** Hoja armada, en píxeles de la foto. */
internal class DocScanLayout(
    val width: Int,
    val height: Int,
    val runs: List<DocScanRun>,
    val blocks: List<DocScanPlacedBlock>
) {
    private val byId = blocks.associateBy { it.id }
    fun block(id: Int): DocScanPlacedBlock? = byId[id]
}

private val docScanBounds = ThreadLocal.withInitial { Rect() }

/** Dónde empieza y en qué línea base va un renglón leído, según su tinta real. */
private fun docScanPlaceLine(line: DocScanLine, paint: Paint, size: Float, scaleX: Float): Pair<Float, Float> {
    val ink = line.inkBox
    if (ink == null) {
        val lineHeight = (line.bottom - line.top).coerceAtLeast(1f)
        val hasDescender = line.text.any { it in DOC_SCAN_DESCENDERS }
        val baseline = if (hasDescender) line.bottom - paint.descent() * 0.8f else line.bottom - lineHeight * 0.04f
        return line.left to baseline
    }
    val bounds = docScanBounds.get() ?: Rect()
    val clean = ScanFontMatch.withoutMarks(line.text)
    val saved = paint.textSize
    paint.textSize = 100f
    paint.textScaleX = 1f
    paint.getTextBounds(clean, 0, clean.length, bounds)
    paint.textSize = saved
    paint.textScaleX = scaleX
    val k = size / 100f
    return (ink.left - bounds.left * k * scaleX) to (ink.top - bounds.top * k)
}

/**
 * Ancho donde se acomoda un párrafo con la alineación [align] (sin moverlo).
 * Un párrafo de varios renglones usa su columna. Un renglón solo:
 * - con su alineación de siempre crece hacia su lado hasta el margen;
 * - si se cambia la alineación, va entre los márgenes de la hoja (como en Word),
 *   sin pisar lo que haya al lado en el mismo renglón.
 */
private fun docScanArea(
    analysis: DocScanAnalysis,
    block: DocScanBlock,
    align: Int,
    startX: Float
): Pair<Float, Float> {
    val margins = analysis.margins
    if (block.lines.size > 1) {
        return startX to max(block.right, block.lines.maxOf { it.inkBox?.right ?: it.right })
    }
    val rowLeft = min(block.left, max(margins.left, block.minLeft))
    val rowRight = max(block.right, min(margins.right, block.maxRight))
    if (align != block.align) return rowLeft to rowRight
    return when (align) {
        DOC_SCAN_ALIGN_CENTER -> {
            val center = (block.left + block.right) / 2f
            val half = max((block.right - block.left) / 2f, min(center - rowLeft, rowRight - center))
            (center - half) to (center + half)
        }
        DOC_SCAN_ALIGN_RIGHT -> rowLeft to block.right
        else -> startX to max(block.right, rowRight)
    }
}

/**
 * Arma todo el texto de la hoja. Lo que no se cambió queda en el mismo lugar,
 * con la letra y el tamaño de la foto. Un párrafo cambiado se vuelve a cortar
 * en renglones dentro de su ancho, con su alineación.
 * [fontChoice]: DOC_SCAN_FONT_AUTO o una letra fija para toda la hoja.
 */
internal fun docScanLayout(
    analysis: DocScanAnalysis,
    edits: Map<Int, DocScanBlockEdit>,
    fontChoice: Int,
    paint: Paint = Paint(Paint.ANTI_ALIAS_FLAG)
): DocScanLayout {
    val runs = ArrayList<DocScanRun>()
    val placed = ArrayList<DocScanPlacedBlock>(analysis.blocks.size)
    for (block in analysis.blocks) {
        val lines = block.lines
        val family = if (fontChoice >= 0) fontChoice else block.family
        val edit = edits[block.id]
        val baseSize = block.size
        val scaleX = block.scaleX
        paint.typeface = DocScanFonts.typeface(family, block.bold, false)
        paint.textSize = baseSize
        paint.textScaleX = scaleX
        val positions = lines.map { docScanPlaceLine(it, paint, baseSize, scaleX) }
        val firstBaseline = positions.first().second
        val baseLeading = if (lines.size >= 2) {
            val gaps = (1 until lines.size).map { positions[it].second - positions[it - 1].second }.filter { it > 0f }
            if (gaps.isEmpty()) baseSize * 1.2f else ScanRebuild.quantile(gaps, 0.5f)
        } else {
            baseSize * 1.22f
        }
        val startX = positions.minOf { it.first }
        val dx = edit?.dx ?: 0f
        val dy = edit?.dy ?: 0f

        // Sin cambio de texto, tamaño ni alineación: los renglones quedan donde estaban
        // (si se movió, todos juntos), con el color, negrita o cursiva elegidos.
        val keepLines = edit == null || (!edit.deleted && edit.text == block.text && edit.scale == 1f && edit.align == block.align)
        if (keepLines) {
            val runBold = edit?.bold ?: block.bold
            val runItalic = edit?.italic ?: false
            val runColor = edit?.color ?: block.ink
            lines.forEachIndexed { index, line ->
                val (x0, baseline) = positions[index]
                paint.textScaleX = scaleX
                val advance = paint.measureText(line.text)
                val target = line.inkBox?.width() ?: (line.right - line.left)
                // Ancho de la tinta dibujada (sin el aire de los costados).
                val bounds = docScanBounds.get() ?: Rect()
                paint.textScaleX = 1f
                paint.getTextBounds(line.text, 0, line.text.length, bounds)
                paint.textScaleX = scaleX
                val drawnInk = (bounds.width() * scaleX).coerceAtLeast(1f)
                val lastLine = index == lines.lastIndex
                val justify = block.align == DOC_SCAN_ALIGN_JUSTIFY && !lastLine &&
                    line.text.contains(' ') && drawnInk < target * 0.985f
                val lineScale = if (justify) scaleX else (scaleX * target / drawnInk).coerceIn(scaleX * 0.9f, scaleX * 1.1f)
                val width = if (justify) advance + (target - drawnInk) else advance * lineScale / scaleX
                runs += DocScanRun(
                    block.id, line.text, x0 + dx, baseline + dy, baseSize, lineScale, width,
                    family, runBold, runItalic, runColor, justify
                )
            }
            val (areaLeft, areaRight) = docScanArea(analysis, block, block.align, startX)
            placed += DocScanPlacedBlock(
                block.id, RectF(block.left + dx, block.top + dy, block.right + dx, block.bottom + dy), block.text,
                baseSize, family, runBold, runItalic, runColor, block.align, block.background, deleted = false,
                areaLeft = areaLeft + dx, areaRight = max(areaRight, areaLeft + baseSize) + dx,
                baseline = firstBaseline + dy, leading = baseLeading, scaleX = scaleX
            )
            continue
        }
        edit!!

        if (edit.deleted || edit.text.isBlank()) {
            placed += DocScanPlacedBlock(
                block.id, RectF(block.left + dx, block.top + dy, block.right + dx, block.bottom + dy), "",
                baseSize, family, edit.bold, edit.italic, edit.color, edit.align, block.background,
                deleted = edit.deleted,
                areaLeft = startX + dx, areaRight = max(block.right, startX + baseSize) + dx,
                baseline = firstBaseline + dy, leading = baseLeading, scaleX = scaleX
            )
            continue
        }

        val size = baseSize * edit.scale.coerceIn(0.4f, 3f)
        val leading = baseLeading * size / baseSize
        val (areaLeft, areaRight) = docScanArea(analysis, block, edit.align, startX)
        val areaWidth = (areaRight - areaLeft).coerceAtLeast(size)
        paint.typeface = DocScanFonts.typeface(family, edit.bold, edit.italic)
        paint.textSize = size
        paint.textScaleX = scaleX
        // Renglón, ¿cierra su párrafo?, sangría (viñetas: los renglones de abajo van alineados al texto).
        val wrapped = ArrayList<Triple<String, Boolean, Float>>()
        for (paragraph in edit.text.split('\n')) {
            val prefix = ScanRebuild.listPrefix(paragraph)
            val indent = if (prefix > 0) paint.measureText(paragraph, 0, prefix).coerceAtMost(areaWidth * 0.4f) else 0f
            val pieces = ScanRebuild.wrap(paragraph, areaWidth, areaWidth - indent) { paint.measureText(it) }
            pieces.forEachIndexed { index, piece ->
                wrapped += Triple(piece, index == pieces.lastIndex, if (index == 0) 0f else indent)
            }
        }
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        wrapped.forEachIndexed { index, (text, closes, indent) ->
            val natural = paint.measureText(text)
            val lineWidth = areaWidth - indent
            val justify = edit.align == DOC_SCAN_ALIGN_JUSTIFY && !closes && text.contains(' ')
            val width = if (justify) lineWidth else natural
            val x = dx + when (edit.align) {
                DOC_SCAN_ALIGN_CENTER -> areaLeft + indent + (lineWidth - width) / 2f
                DOC_SCAN_ALIGN_RIGHT -> areaLeft + areaWidth - width
                else -> areaLeft + indent
            }
            if (text.isNotEmpty()) {
                runs += DocScanRun(
                    block.id, text, x, firstBaseline + dy + index * leading, size, scaleX, width,
                    family, edit.bold, edit.italic, edit.color, justify
                )
            }
            minX = min(minX, x)
            maxX = max(maxX, x + width)
        }
        val ascent = paint.ascent()
        val descent = paint.descent()
        val rect = RectF(
            min(minX, areaLeft + dx),
            firstBaseline + ascent + dy,
            max(maxX, areaLeft + dx + size),
            firstBaseline + (wrapped.size - 1) * leading + descent + dy
        )
        placed += DocScanPlacedBlock(
            block.id, rect, edit.text, size, family, edit.bold, edit.italic, edit.color, edit.align, block.background,
            deleted = false,
            areaLeft = areaLeft + dx, areaRight = areaLeft + areaWidth + dx,
            baseline = firstBaseline + dy, leading = leading, scaleX = scaleX
        )
    }
    paint.textScaleX = 1f
    return DocScanLayout(analysis.width, analysis.height, runs, placed)
}

/** Dibuja los renglones armados (en píxeles de la foto: el lienzo ya viene escalado). */
internal fun docScanDrawRuns(canvas: Canvas, runs: List<DocScanRun>, paint: Paint) {
    for (run in runs) {
        paint.typeface = DocScanFonts.typeface(run.family, run.bold, run.italic)
        paint.textSize = run.size
        paint.textScaleX = run.scaleX
        paint.color = run.color
        if (!run.justify) {
            canvas.drawText(run.text, run.x, run.baseline, paint)
            continue
        }
        val words = run.text.split(' ').filter { it.isNotEmpty() }
        if (words.size < 2) {
            canvas.drawText(run.text, run.x, run.baseline, paint)
            continue
        }
        val widths = FloatArray(words.size) { paint.measureText(words[it]) }
        val gap = (run.width - widths.sum()) / (words.size - 1)
        var x = run.x
        for (index in words.indices) {
            canvas.drawText(words[index], x, run.baseline, paint)
            x += widths[index] + gap
        }
    }
    paint.textScaleX = 1f
}

/**
 * Texto dibujado como trazos (la forma de cada letra), para lo que se mueve en
 * vivo sobre la pantalla. Con zoom grande la tarjeta gráfica a veces corta o
 * mezcla las letras de su memoria de letras; los trazos siempre salen bien.
 * Guarda las formas ya hechas para no rehacerlas en cada cuadro.
 */
internal class DocScanTextPaths(private val limit: Int = 400) {
    private val cache = object : LinkedHashMap<String, android.graphics.Path>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, android.graphics.Path>?): Boolean = size > limit
    }

    private fun piece(canvas: Canvas, key: String, text: String, x: Float, y: Float, paint: Paint) {
        val path = cache.getOrPut(key) {
            android.graphics.Path().also { paint.getTextPath(text, 0, text.length, 0f, 0f, it) }
        }
        canvas.save()
        canvas.translate(x, y)
        canvas.drawPath(path, paint)
        canvas.restore()
    }

    /** Un texto suelto con la letra que ya tiene [paint] ([style] = letra, tamaño y ancho). */
    fun drawText(canvas: Canvas, style: String, text: String, x: Float, y: Float, paint: Paint) {
        if (text.isEmpty()) return
        piece(canvas, "$style|$text", text, x, y, paint)
    }

    fun drawRuns(canvas: Canvas, runs: List<DocScanRun>, paint: Paint) {
        paint.style = Paint.Style.FILL
        for (run in runs) {
            paint.typeface = DocScanFonts.typeface(run.family, run.bold, run.italic)
            paint.textSize = run.size
            paint.textScaleX = run.scaleX
            paint.color = run.color
            val style = "${run.family}|${run.bold}|${run.italic}|${run.size}|${run.scaleX}"
            val words = if (run.justify) run.text.split(' ').filter { it.isNotEmpty() } else emptyList()
            if (words.size < 2) {
                drawText(canvas, style, run.text, run.x, run.baseline, paint)
                continue
            }
            val widths = FloatArray(words.size) { paint.measureText(words[it]) }
            val gap = (run.width - widths.sum()) / (words.size - 1)
            var x = run.x
            for (index in words.indices) {
                drawText(canvas, style, words[index], x, run.baseline, paint)
                x += widths[index] + gap
            }
        }
        paint.textScaleX = 1f
    }
}

/**
 * La hoja como se ve, en una imagen (fondo limpio + logos y fotos + texto), dibujada
 * por el procesador: las letras salen siempre completas y el zoom va fluido porque
 * es una sola imagen. Sin filtro de color (se aplica al mostrarla).
 * [hiddenObject] no se dibuja (se está moviendo y va aparte).
 */
internal fun docScanRenderSheet(
    cleaned: DocScanCleaned,
    pageWidth: Int,
    pageHeight: Int,
    runs: List<DocScanRun>,
    objectEdits: Map<Int, DocScanObjectEdit>,
    hiddenObject: Int
): Bitmap {
    val base = cleaned.base
    val output = Bitmap.createBitmap(base.width, base.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    canvas.drawColor(android.graphics.Color.WHITE)
    val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    canvas.drawBitmap(base, 0f, 0f, imagePaint)
    canvas.save()
    canvas.scale(base.width / pageWidth.coerceAtLeast(1).toFloat(), base.height / pageHeight.coerceAtLeast(1).toFloat())
    val pieces = if (hiddenObject >= 0) cleaned.objects.filter { it.id != hiddenObject } else cleaned.objects
    docScanDrawObjects(canvas, pieces, objectEdits, imagePaint)
    docScanDrawRuns(canvas, runs, Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG))
    canvas.restore()
    return output
}

/** Caja de un texto agregado. */
internal fun docScanAddedBounds(text: DocScanAddedText, width: Float, height: Float, family: Int, paint: Paint): RectF {
    paint.textScaleX = 1f
    paint.typeface = DocScanFonts.typeface(family, text.bold, text.italic)
    paint.textSize = (text.size * height).coerceAtLeast(2f)
    val textWidth = paint.measureText(text.text.ifEmpty { " " })
    val x = text.x * width
    val y = text.y * height
    return RectF(x, y + paint.ascent(), x + textWidth, y + paint.descent())
}

/** Caja de una firma. */
internal fun docScanSignRect(sign: DocScanSign, width: Float, height: Float): RectF {
    val signWidth = sign.width * width
    val ratio = sign.bitmap.height.toFloat() / sign.bitmap.width.coerceAtLeast(1)
    val left = sign.x * width
    val top = sign.y * height
    return RectF(left, top, left + signWidth, top + signWidth * ratio)
}

/** Textos agregados (con filtro de color) y firmas (sin filtro: quedan con su tinta). */
internal fun docScanDrawAdded(
    canvas: Canvas,
    width: Float,
    height: Float,
    edits: DocScanPageEdits,
    family: Int,
    paint: Paint,
    drawSigns: Boolean = true,
    /** En la pantalla: letras como trazos (ver [DocScanTextPaths]). */
    paths: DocScanTextPaths? = null,
    /** Texto agregado que no se dibuja (se está escribiendo encima). */
    hiddenText: Int = -1
) {
    paint.textScaleX = 1f
    for (text in edits.texts) {
        if (text.text.isBlank() || text.id == hiddenText) continue
        paint.typeface = DocScanFonts.typeface(family, text.bold, text.italic)
        paint.textSize = (text.size * height).coerceAtLeast(2f)
        paint.color = text.color
        if (paths != null) {
            paths.drawText(canvas, "$family|${text.bold}|${text.italic}|${paint.textSize}", text.text, text.x * width, text.y * height, paint)
        } else {
            canvas.drawText(text.text, text.x * width, text.y * height, paint)
        }
    }
    if (!drawSigns) return
    val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    for (sign in edits.signs) {
        if (!sign.bitmap.isRecycled) canvas.drawBitmap(sign.bitmap, null, docScanSignRect(sign, width, height), imagePaint)
    }
}

/** Letra de los textos agregados: la elegida o la principal de la hoja. */
internal fun docScanAddedFamily(analysis: DocScanAnalysis?, fontChoice: Int): Int =
    if (fontChoice >= 0) fontChoice else analysis?.mainFamily ?: 0

/** Dibuja los logos y fotos (en píxeles de la foto: el lienzo ya viene escalado). */
internal fun docScanDrawObjects(
    canvas: Canvas,
    objects: List<DocScanObject>,
    edits: Map<Int, DocScanObjectEdit>,
    paint: Paint,
    movingId: Int = -1,
    movingDx: Float = 0f,
    movingDy: Float = 0f
) {
    for (piece in objects) {
        if (piece.bitmap.isRecycled) continue
        val edit = edits[piece.id]
        if (edit?.deleted == true) continue
        val rect = docScanObjectRect(piece.rect, edit)
        if (piece.id == movingId) rect.offset(movingDx, movingDy)
        canvas.drawBitmap(piece.bitmap, null, rect, paint)
    }
}

/** Hoja completa en una imagen nueva: fondo limpio + piezas + filtro + texto + agregados. */
internal fun docScanRender(
    cleaned: DocScanCleaned,
    layout: DocScanLayout,
    edits: DocScanPageEdits,
    addedFamily: Int,
    filter: FloatArray?,
    withText: Boolean = true
): Bitmap {
    val clean = cleaned.base
    val width = clean.width
    val height = clean.height
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    canvas.drawColor(android.graphics.Color.WHITE)
    val colorFilter = filter?.let { ColorMatrixColorFilter(it) }
    val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply { this.colorFilter = colorFilter }
    canvas.drawBitmap(clean, 0f, 0f, imagePaint)
    canvas.save()
    canvas.scale(width / layout.width.coerceAtLeast(1).toFloat(), height / layout.height.coerceAtLeast(1).toFloat())
    docScanDrawObjects(canvas, cleaned.objects, edits.objects, imagePaint)
    canvas.restore()
    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply { this.colorFilter = colorFilter }
    if (withText) {
        canvas.save()
        canvas.scale(width / layout.width.coerceAtLeast(1).toFloat(), height / layout.height.coerceAtLeast(1).toFloat())
        docScanDrawRuns(canvas, layout.runs, textPaint)
        canvas.restore()
        docScanDrawAdded(canvas, width.toFloat(), height.toFloat(), edits, addedFamily, textPaint)
    } else {
        // Para el PDF: solo las firmas e imágenes van en la foto; el texto va como texto real.
        docScanDrawAdded(canvas, width.toFloat(), height.toFloat(), edits.copy(texts = emptyList()), addedFamily, textPaint)
    }
    return output
}

// ---------------------------------------------------------------------------
// Texto de la hoja (para copiar, compartir y Word)
// ---------------------------------------------------------------------------

/** Un párrafo para copiar o para el Word, en orden de lectura. */
internal class DocScanParagraph(
    val text: String,
    /** Tamaño de letra como fracción del ancho de la página. */
    val size: Float,
    val family: Int,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val align: Int,
    val background: Int
)

/** Párrafos de la página en orden de lectura, con los cambios y los textos agregados. */
internal fun docScanParagraphs(layout: DocScanLayout?, edits: DocScanPageEdits, addedFamily: Int): List<DocScanParagraph> {
    if (layout == null) return emptyList()
    val width = layout.width.coerceAtLeast(1).toFloat()
    val height = layout.height.toFloat()
    val result = ArrayList<Pair<Float, DocScanParagraph>>()
    for (block in layout.blocks) {
        if (block.deleted || block.text.isBlank()) continue
        result += block.rect.top to DocScanParagraph(
            block.text, block.size / width, block.family, block.bold, block.italic, block.color, block.align, block.background
        )
    }
    // Los textos agregados van antes del primer párrafo que esté más abajo.
    for (added in edits.texts.sortedBy { it.y }) {
        if (added.text.isBlank()) continue
        val y = added.y * height
        val paragraph = DocScanParagraph(
            added.text, added.size * height / width, addedFamily, added.bold, added.italic, added.color,
            DOC_SCAN_ALIGN_LEFT, android.graphics.Color.WHITE
        )
        val at = result.indexOfFirst { it.first > y }
        if (at < 0) result += y to paragraph else result.add(at, y to paragraph)
    }
    return result.map { it.second }
}

internal fun docScanPageText(layout: DocScanLayout?, edits: DocScanPageEdits, addedFamily: Int): String =
    docScanParagraphs(layout, edits, addedFamily).joinToString("\n\n") { it.text }

/** Lee las páginas que falten (para Word y para copiar el texto de todas). */
internal suspend fun docScanEnsureAnalyses(
    context: Context,
    pages: List<DocScanPage>,
    known: Map<Int, DocScanAnalysis>,
    onStep: (String) -> Unit = {}
): Map<Int, DocScanAnalysis> {
    val result = HashMap(known)
    pages.forEachIndexed { index, page ->
        if (result[page.id] != null) return@forEachIndexed
        val source = ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
        try {
            val read = docScanAnalyze(context, source) { step -> onStep("Página ${index + 1}: $step") }
            result[page.id] = read.analysis
            if (read.bitmap !== source) read.bitmap.recycle()
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }
    return result
}

/** Texto de todas las páginas, separadas. */
internal fun docScanAllText(
    pages: List<DocScanPage>,
    analyses: Map<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    fontChoice: Int
): String {
    fun pageText(page: DocScanPage): String {
        val pageEdits = edits[page.id] ?: DocScanPageEdits()
        val analysis = analyses[page.id]
        val layout = analysis?.let { docScanLayout(it, pageEdits.blocks, fontChoice) }
        return docScanPageText(layout, pageEdits, docScanAddedFamily(analysis, fontChoice))
    }
    if (pages.size == 1) return pageText(pages.first())
    return pages.mapIndexed { index, page -> "— Página ${index + 1} —\n\n" + pageText(page) }.joinToString("\n\n")
}

// ---------------------------------------------------------------------------
// Guardado
// ---------------------------------------------------------------------------

/** Una página lista para guardar: fondo limpio, lectura y armado. */
private class DocScanPrepared(val cleaned: DocScanCleaned, val analysis: DocScanAnalysis, val layout: DocScanLayout)

private suspend fun docScanPreparePage(
    context: Context,
    page: DocScanPage,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    fontChoice: Int,
    cleanPaper: Boolean
): DocScanPrepared {
    val source = ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
    var straight: Bitmap = source
    try {
        val read = if (analysis != null) {
            straight = withContext(Dispatchers.Default) { docScanStraighten(source, analysis.rotation) }
            analysis
        } else {
            val result = docScanAnalyze(context, source)
            straight = result.bitmap
            result.analysis
        }
        val cleaned = docScanCleanPage(straight, read, cleanPaper)
        val layout = withContext(Dispatchers.Default) { docScanLayout(read, edits.blocks, fontChoice) }
        return DocScanPrepared(cleaned, read, layout)
    } finally {
        if (straight !== source && !straight.isRecycled) straight.recycle()
        if (!source.isRecycled) source.recycle()
    }
}

/** Medidas de la hoja en puntos de PDF (1/72 de pulgada). */
private fun docScanPageSize(analysis: DocScanAnalysis, paperChoice: Int): Pair<Float, Float> {
    val paper = if (paperChoice >= 0) paperChoice else analysis.paper
    val landscape = analysis.landscape
    val known = ScanRebuild.papers.getOrNull(paper)
    if (known != null) {
        val width = known.second * 72f / 25.4f
        val height = known.third * 72f / 25.4f
        return if (landscape) height to width else width to height
    }
    val ratio = analysis.width.toFloat() / analysis.height.coerceAtLeast(1)
    return if (ratio >= 1f) 842f to 842f / ratio else 595f to 595f / ratio
}

/**
 * PDF reconstruido: cada página es el fondo limpio (fotos, logos, barras) y
 * encima el texto REAL, visible, con la misma letra de la pantalla (va dentro
 * del PDF), en su lugar, tamaño, color y negrita. Se puede seleccionar, copiar,
 * buscar y editar en cualquier lector de PDF. La hoja sale en su tamaño (A4, Carta…).
 */
internal suspend fun docScanWritePdf(
    context: Context,
    output: OutputStream,
    pages: List<DocScanPage>,
    analyses: Map<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    fontChoice: Int,
    paperChoice: Int,
    cleanPaper: Boolean,
    filter: FloatArray?
) = withContext(Dispatchers.IO) {
    PDFBoxResourceLoader.init(context.applicationContext)
    DocScanFonts.init(context)
    val measure = Paint(Paint.ANTI_ALIAS_FLAG)
    PDDocument().use { document ->
        val fonts = HashMap<Int, PDFont>()
        fun pdfFont(family: Int, bold: Boolean, italic: Boolean): PDFont {
            val key = family * 4 + (if (bold) 1 else 0) + (if (italic) 2 else 0)
            return fonts.getOrPut(key) {
                runCatching {
                    DocScanFonts.open(context, family, bold, italic).use { PDType0Font.load(document, it) }
                }.getOrElse {
                    when {
                        bold && italic -> PDType1Font.HELVETICA_BOLD_OBLIQUE
                        bold -> PDType1Font.HELVETICA_BOLD
                        italic -> PDType1Font.HELVETICA_OBLIQUE
                        else -> PDType1Font.HELVETICA
                    }
                }
            }
        }
        val encodable = HashMap<Pair<PDFont, Char>, Boolean>()
        fun clean(font: PDFont, text: String): String = buildString {
            for (char in text) {
                val ok = encodable.getOrPut(font to char) { runCatching { font.encode(char.toString()); true }.getOrDefault(false) }
                append(if (ok) char else ' ')
            }
        }

        for (page in pages) {
            val pageEdits = edits[page.id] ?: DocScanPageEdits()
            val prepared = docScanPreparePage(context, page, analyses[page.id], pageEdits, fontChoice, cleanPaper)
            val addedFamily = docScanAddedFamily(prepared.analysis, fontChoice)
            val background = try {
                withContext(Dispatchers.Default) {
                    docScanRender(prepared.cleaned, prepared.layout, pageEdits, addedFamily, filter, withText = false)
                }
            } finally {
                prepared.cleaned.recycle()
            }
            val bytes = try {
                ByteArrayOutputStream().also { background.compress(Bitmap.CompressFormat.JPEG, 88, it) }.toByteArray()
            } finally {
                background.recycle()
            }
            val (pageWidth, pageHeight) = docScanPageSize(prepared.analysis, paperChoice)
            val pdfPage = PDPage(PDRectangle(pageWidth, pageHeight))
            document.addPage(pdfPage)
            val image = PDImageXObject.createFromByteArray(document, bytes, "pagina")

            // Todos los renglones (los leídos y los agregados) en píxeles de la foto.
            val layout = prepared.layout
            val runs = ArrayList(layout.runs)
            measure.textScaleX = 1f
            for (added in pageEdits.texts) {
                if (added.text.isBlank()) continue
                val size = added.size * layout.height
                measure.typeface = DocScanFonts.typeface(addedFamily, added.bold, added.italic)
                measure.textSize = size
                runs += DocScanRun(
                    -1, added.text, added.x * layout.width, added.y * layout.height, size, 1f,
                    measure.measureText(added.text), addedFamily, added.bold, added.italic, added.color, false
                )
            }
            // La foto ocupa toda la hoja: puede estirarse apenas para llenar A4/Carta exacto.
            val kx = pageWidth / layout.width.coerceAtLeast(1)
            val ky = pageHeight / layout.height.coerceAtLeast(1)

            PDPageContentStream(document, pdfPage).use { stream ->
                stream.drawImage(image, 0f, 0f, pageWidth, pageHeight)
                for (run in runs) {
                    val font = pdfFont(run.family, run.bold, run.italic)
                    val color = docScanFilterColor(run.color, filter)
                    measure.typeface = DocScanFonts.typeface(run.family, run.bold, run.italic)
                    measure.textSize = run.size
                    measure.textScaleX = run.scaleX
                    val words = run.text.split(' ').filter { it.isNotEmpty() }
                    val pieces = ArrayList<Pair<String, Float>>() // texto y su x (px de la foto)
                    val targets = ArrayList<Float>() // ancho que debe ocupar cada pedazo (px)
                    if (run.justify && words.size >= 2) {
                        val widths = words.map { measure.measureText(it) }
                        val gap = (run.width - widths.sum()) / (words.size - 1)
                        var x = run.x
                        for (index in words.indices) {
                            pieces += words[index] to x
                            targets += widths[index]
                            x += widths[index] + gap
                        }
                    } else {
                        pieces += run.text to run.x
                        targets += run.width
                    }
                    val sizePt = run.size * ky
                    if (sizePt < 0.5f) continue
                    pieces.forEachIndexed { index, (text, x) ->
                        val cleaned = clean(font, text)
                        if (cleaned.isBlank()) return@forEachIndexed
                        val units = runCatching { font.getStringWidth(cleaned) }.getOrDefault(0f)
                        if (units <= 0f) return@forEachIndexed
                        val pdfWidth = units / 1000f * sizePt
                        val stretch = (targets[index] * kx / pdfWidth).coerceIn(0.4f, 2.5f)
                        runCatching {
                            stream.beginText()
                            stream.setFont(font, sizePt)
                            stream.setNonStrokingColor(
                                PDColor(
                                    floatArrayOf(
                                        android.graphics.Color.red(color) / 255f,
                                        android.graphics.Color.green(color) / 255f,
                                        android.graphics.Color.blue(color) / 255f
                                    ),
                                    PDDeviceRGB.INSTANCE
                                )
                            )
                            stream.setTextMatrix(Matrix(stretch, 0f, 0f, 1f, x * kx, pageHeight - run.baseline * ky))
                            stream.showText(cleaned)
                            stream.endText()
                        }
                    }
                }
            }
        }
        document.save(output)
    }
}

/** Imagen JPG de una página, igual a lo que se ve. */
internal suspend fun docScanWriteImage(
    context: Context,
    output: OutputStream,
    page: DocScanPage,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    fontChoice: Int,
    cleanPaper: Boolean,
    filter: FloatArray?
) = withContext(Dispatchers.IO) {
    DocScanFonts.init(context)
    val prepared = docScanPreparePage(context, page, analysis, edits, fontChoice, cleanPaper)
    val rendered = try {
        withContext(Dispatchers.Default) {
            docScanRender(prepared.cleaned, prepared.layout, edits, docScanAddedFamily(prepared.analysis, fontChoice), filter)
        }
    } finally {
        prepared.cleaned.recycle()
    }
    try {
        check(rendered.compress(Bitmap.CompressFormat.JPEG, 92, output)) { "No se pudo guardar la imagen" }
    } finally {
        rendered.recycle()
    }
}

private fun docScanXml(value: String): String = value
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")
    .filter { it == '\t' || it == '\n' || it >= ' ' }

private fun docScanZip(zip: ZipOutputStream, name: String, text: String) {
    zip.putNextEntry(ZipEntry(name))
    zip.write(text.toByteArray(Charsets.UTF_8))
    zip.closeEntry()
}

/** Una página para el Word: sus párrafos y el tamaño de hoja. */
internal class DocScanWordPage(val paragraphs: List<DocScanParagraph>, val paper: Int, val landscape: Boolean)

/**
 * Word (.docx) armado a mano, sin librerías: los párrafos de cada página en
 * orden, con su letra, tamaño, negrita, cursiva, color, alineación y fondo de
 * color (títulos en barras). Cada página en su hoja y en su tamaño (A4, Carta…).
 */
internal fun docScanWriteDocx(output: OutputStream, pages: List<DocScanWordPage>) {
    fun hex(color: Int): String = String.format(
        java.util.Locale.ROOT, "%02X%02X%02X",
        android.graphics.Color.red(color), android.graphics.Color.green(color), android.graphics.Color.blue(color)
    )
    fun light(color: Int): Boolean =
        android.graphics.Color.red(color) * 299 + android.graphics.Color.green(color) * 587 +
            android.graphics.Color.blue(color) * 114 > 160_000
    fun section(page: DocScanWordPage): String {
        val known = ScanRebuild.papers.getOrNull(page.paper) ?: ScanRebuild.papers[0]
        var width = (known.second / 25.4f * 1440f).roundToInt()
        var height = (known.third / 25.4f * 1440f).roundToInt()
        if (page.landscape) width = height.also { height = width }
        val orient = if (page.landscape) " w:orient=\"landscape\"" else ""
        return "<w:sectPr><w:pgSz w:w=\"$width\" w:h=\"$height\"$orient/>" +
            "<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"709\" w:footer=\"709\" w:gutter=\"0\"/>" +
            "</w:sectPr>"
    }

    val body = StringBuilder()
    pages.forEachIndexed { pageIndex, page ->
        val paragraphs = page.paragraphs
        val pageWidthPt = (ScanRebuild.papers.getOrNull(page.paper) ?: ScanRebuild.papers[0]).let {
            (if (page.landscape) it.third else it.second) * 72f / 25.4f
        }
        if (paragraphs.isEmpty()) body.append("<w:p/>")
        paragraphs.forEachIndexed { index, paragraph ->
            val halfPoints = (paragraph.size * pageWidthPt * 2f).roundToInt().coerceIn(12, 120)
            val shaded = !light(paragraph.background)
            val textColor = if (!shaded && light(paragraph.color)) android.graphics.Color.BLACK else paragraph.color
            val justify = when (paragraph.align) {
                DOC_SCAN_ALIGN_CENTER -> "center"
                DOC_SCAN_ALIGN_RIGHT -> "right"
                DOC_SCAN_ALIGN_JUSTIFY -> "both"
                else -> "left"
            }
            val font = DocScanFonts.wordNames.getOrElse(paragraph.family) { "Arial" }
            body.append("<w:p><w:pPr>")
            if (shaded) body.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(hex(paragraph.background)).append("\"/>")
            body.append("<w:spacing w:after=\"120\"/>")
            // Viñetas y listas numeradas: los renglones de abajo van alineados al texto.
            if (ScanRebuild.listPrefix(paragraph.text) > 0) body.append("<w:ind w:left=\"360\" w:hanging=\"360\"/>")
            body.append("<w:jc w:val=\"").append(justify).append("\"/>")
            // Al terminar una página (menos la última) va su tamaño de hoja: empieza otra hoja.
            if (index == paragraphs.lastIndex && pageIndex < pages.lastIndex) body.append(section(page))
            body.append("</w:pPr>")
            val runProperties = StringBuilder("<w:rPr><w:rFonts w:ascii=\"$font\" w:hAnsi=\"$font\" w:cs=\"$font\"/>")
            if (paragraph.bold) runProperties.append("<w:b/>")
            if (paragraph.italic) runProperties.append("<w:i/>")
            runProperties.append("<w:color w:val=\"").append(hex(textColor)).append("\"/>")
            runProperties.append("<w:sz w:val=\"$halfPoints\"/><w:szCs w:val=\"$halfPoints\"/></w:rPr>")
            paragraph.text.split('\n').forEachIndexed { lineIndex, line ->
                if (lineIndex > 0) body.append("<w:r><w:br/></w:r>")
                body.append("<w:r>").append(runProperties)
                body.append("<w:t xml:space=\"preserve\">").append(docScanXml(line)).append("</w:t></w:r>")
            }
            body.append("</w:p>")
        }
        if (paragraphs.isEmpty() && pageIndex < pages.lastIndex) body.append("<w:p><w:pPr>").append(section(page)).append("</w:pPr></w:p>")
    }
    val last = pages.lastOrNull() ?: DocScanWordPage(emptyList(), 0, false)
    val documentXml =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
            "<w:body>" + body + section(last) + "</w:body></w:document>"
    val types =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"
    val rootRels =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"
    ZipOutputStream(output).use { zip ->
        docScanZip(zip, "[Content_Types].xml", types)
        docScanZip(zip, "_rels/.rels", rootRels)
        docScanZip(zip, "word/document.xml", documentXml)
    }
}

/**
 * Copia las páginas del escáner de Google a la carpeta temporal de la app.
 * El escáner borra sus archivos en el siguiente escaneo; con la copia no se pierden.
 */
internal suspend fun docScanCopyToCache(context: Context, sources: List<Uri>): List<Uri> = withContext(Dispatchers.IO) {
    val directory = java.io.File(context.cacheDir, "camera").apply { mkdirs() }
    val stamp = System.currentTimeMillis()
    val copied = ArrayList<Uri>()
    sources.forEachIndexed { index, source ->
        val target = java.io.File(directory, "docscan_${stamp}_${index + 1}.jpg")
        val ok = runCatching {
            context.contentResolver.openInputStream(source)?.use { input ->
                target.outputStream().use { out -> input.copyTo(out) }
            } != null
        }.getOrDefault(false)
        if (ok && target.length() > 0L) {
            copied += androidx.core.content.FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                target
            )
        }
    }
    copied
}

/** Borra las copias de escaneos viejos (de otras sesiones). */
internal suspend fun docScanCleanCache(context: Context, keep: Set<String>) = withContext(Dispatchers.IO) {
    val directory = java.io.File(context.cacheDir, "camera")
    directory.listFiles()?.forEach { file ->
        if (file.name.startsWith("docscan_") && file.name !in keep) runCatching { file.delete() }
    }
}
