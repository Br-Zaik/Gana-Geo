package com.ganageo.app.data

import android.content.Context
import com.ganageo.app.model.DashboardData
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Cache local de solo lectura para abrir el panel sin esperar la red.
 * Supabase sigue siendo la fuente de verdad; este cache nunca confirma
 * retiros, créditos ni operaciones sensibles.
 */
class DashboardCacheStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun read(userId: String): DashboardData? {
        if (userId.isBlank()) return null
        val key = keyFor(userId)
        val raw = preferences.getString(key, null) ?: return null

        return runCatching {
            val cached = json.decodeFromString<CachedDashboard>(raw)
            val dashboard = cached.dashboard
            if (cached.schemaVersion != SCHEMA_VERSION ||
                cached.userId != userId ||
                dashboard.profile.userId != userId ||
                dashboard.wallet.userId != userId
            ) {
                error("Dashboard cache incompatible")
            }
            dashboard
        }.getOrElse {
            preferences.edit().remove(key).apply()
            null
        }
    }

    fun write(userId: String, dashboard: DashboardData) {
        if (userId.isBlank() ||
            dashboard.profile.userId != userId ||
            dashboard.wallet.userId != userId
        ) {
            return
        }

        runCatching {
            val payload = CachedDashboard(
                schemaVersion = SCHEMA_VERSION,
                userId = userId,
                savedAtMs = System.currentTimeMillis(),
                dashboard = dashboard
            )
            preferences.edit()
                .putString(keyFor(userId), json.encodeToString(payload))
                .apply()
        }
    }

    fun clear(userId: String?) {
        if (userId.isNullOrBlank()) return
        preferences.edit().remove(keyFor(userId)).apply()
    }

    private fun keyFor(userId: String): String = "dashboard_$userId"

    @Serializable
    private data class CachedDashboard(
        val schemaVersion: Int,
        val userId: String,
        val savedAtMs: Long,
        val dashboard: DashboardData
    )

    private companion object {
        const val PREFS_NAME = "gana_geo_dashboard_cache"
        const val SCHEMA_VERSION = 1
    }
}
