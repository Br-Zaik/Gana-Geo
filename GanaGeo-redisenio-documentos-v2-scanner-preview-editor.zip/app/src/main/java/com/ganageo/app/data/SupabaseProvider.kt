package com.ganageo.app.data

import com.ganageo.app.BuildConfig
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest

object SupabaseProvider {
    val isConfigured: Boolean
        get() = BuildConfig.SUPABASE_URL.startsWith("https://") &&
            BuildConfig.SUPABASE_ANON_KEY.isNotBlank() &&
            !BuildConfig.SUPABASE_ANON_KEY.contains("PEGA_AQUI", ignoreCase = true)

    val client: SupabaseClient? by lazy {
        if (!isConfigured) return@lazy null

        // La conectividad o una restauracion local de Auth nunca debe impedir que
        // la interfaz de Gana Geo arranque. Si la construccion del cliente falla,
        // el ViewModel entra de forma segura como invitado y permite reintentar
        // en una siguiente apertura en lugar de cerrar todo el proceso.
        runCatching {
            createSupabaseClient(
                supabaseUrl = BuildConfig.SUPABASE_URL,
                supabaseKey = BuildConfig.SUPABASE_ANON_KEY
            ) {
                install(Auth)
                install(Postgrest)
            }
        }.getOrNull()
    }
}
