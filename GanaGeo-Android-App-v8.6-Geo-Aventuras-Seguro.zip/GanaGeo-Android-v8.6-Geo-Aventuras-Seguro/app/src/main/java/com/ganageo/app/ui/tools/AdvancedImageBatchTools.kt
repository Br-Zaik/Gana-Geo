package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.AdvancedFileUtils
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch

@Composable
fun ImageBatchStudioScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val inputs = remember { mutableStateListOf<Uri>() }
    var modeIndex by rememberSaveable { mutableIntStateOf(AdvancedFileUtils.BatchImageMode.COMPRESS.ordinal) }
    var formatIndex by rememberSaveable { mutableIntStateOf(0) }
    var quality by rememberSaveable { mutableFloatStateOf(85f) }
    var maxEdgeText by rememberSaveable { mutableStateOf("1600") }
    var colorIndex by rememberSaveable { mutableIntStateOf(0) }
    var columns by rememberSaveable { mutableFloatStateOf(2f) }
    var frameWidth by rememberSaveable { mutableFloatStateOf(24f) }
    var passportWidth by rememberSaveable { mutableStateOf("35") }
    var passportHeight by rememberSaveable { mutableStateOf("45") }
    var passportCopies by rememberSaveable { mutableStateOf("8") }
    var processing by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }

    val formats = listOf("JPG", "PNG", "WebP")
    val colors = listOf("Blanco", "Negro", "Gris", "Azul claro")
    val colorValues = listOf(Color.WHITE, Color.BLACK, Color.LTGRAY, Color.rgb(220, 235, 255))
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected ->
        val remaining = (50 - inputs.size).coerceAtLeast(0)
        inputs += selected.take(remaining)
        if (selected.size > remaining) onMessage("Puedes procesar hasta 50 imágenes")
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { folder ->
        if (folder == null || inputs.isEmpty()) return@rememberLauncherForActivityResult
        val mode = AdvancedFileUtils.BatchImageMode.entries[modeIndex]
        val format = when (formatIndex) {
            1 -> Bitmap.CompressFormat.PNG
            2 -> Bitmap.CompressFormat.WEBP
            else -> Bitmap.CompressFormat.JPEG
        }
        val options = AdvancedFileUtils.BatchImageOptions(
            mode = mode,
            outputFormat = format,
            quality = quality.toInt(),
            maxEdge = maxEdgeText.toIntOrNull() ?: 1600,
            backgroundColor = colorValues[colorIndex],
            frameWidth = frameWidth.toInt(),
            columns = columns.toInt(),
            passportWidthMm = passportWidth.replace(',', '.').toDoubleOrNull() ?: 35.0,
            passportHeightMm = passportHeight.replace(',', '.').toDoubleOrNull() ?: 45.0,
            passportCopies = passportCopies.toIntOrNull() ?: 8
        )
        processing = true
        progress = 0f
        scope.launch {
            runPaidTool(viewModel, tool) {
                AdvancedFileUtils.processImageBatch(context, inputs.toList(), folder, options) { done, total ->
                    scope.launch { progress = done.toFloat() / total.coerceAtLeast(1) }
                }.size
            }.onSuccess { awarded -> onMessage(successMessage("Lote procesado correctamente", awarded)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar el lote") }
            processing = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, tool.subtitle, onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("1. Selecciona imágenes", style = MaterialTheme.typography.titleLarge)
                        OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !processing) {
                            Icon(Icons.Rounded.Folder, null); Text(" Elegir imágenes")
                        }
                        Text("${inputs.size} imágenes · ${ToolFileUtils.readableSize(inputs.sumOf { ToolFileUtils.fileSize(context, it) })}")
                        if (inputs.isNotEmpty()) {
                            inputs.take(8).forEachIndexed { index, uri ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${index + 1}. ${ToolFileUtils.displayName(context, uri)}", modifier = Modifier.weight(1f), maxLines = 1)
                                    OutlinedButton(onClick = { inputs.remove(uri) }) { Icon(Icons.Rounded.Delete, "Quitar") }
                                }
                            }
                            if (inputs.size > 8) Text("… y ${inputs.size - 8} más", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            OutlinedButton(onClick = { inputs.clear() }, modifier = Modifier.fillMaxWidth()) { Text("Quitar todas") }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("2. Elige la operación", style = MaterialTheme.typography.titleLarge)
                        SimpleDropdown("Operación", AdvancedFileUtils.BatchImageMode.entries.map { it.label }, modeIndex) { modeIndex = it }
                        val mode = AdvancedFileUtils.BatchImageMode.entries[modeIndex]
                        if (mode != AdvancedFileUtils.BatchImageMode.ZIP_ORIGINALS) {
                            SimpleDropdown("Formato de salida", formats, formatIndex) { formatIndex = it }
                            Text("Calidad: ${quality.toInt()} %")
                            Slider(quality, { quality = it }, valueRange = 30f..100f)
                        }
                        if (mode in listOf(AdvancedFileUtils.BatchImageMode.COMPRESS, AdvancedFileUtils.BatchImageMode.RESIZE, AdvancedFileUtils.BatchImageMode.JOIN_VERTICAL, AdvancedFileUtils.BatchImageMode.JOIN_HORIZONTAL, AdvancedFileUtils.BatchImageMode.COLLAGE)) {
                            OutlinedTextField(maxEdgeText, { maxEdgeText = it.filter(Char::isDigit).take(5) }, label = { Text("Lado máximo por imagen") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                        }
                        if (mode in listOf(AdvancedFileUtils.BatchImageMode.SOLID_BACKGROUND, AdvancedFileUtils.BatchImageMode.FRAME, AdvancedFileUtils.BatchImageMode.JOIN_VERTICAL, AdvancedFileUtils.BatchImageMode.JOIN_HORIZONTAL, AdvancedFileUtils.BatchImageMode.COLLAGE)) {
                            SimpleDropdown("Color de fondo", colors, colorIndex) { colorIndex = it }
                        }
                        if (mode == AdvancedFileUtils.BatchImageMode.FRAME) {
                            Text("Grosor del marco: ${frameWidth.toInt()} px")
                            Slider(frameWidth, { frameWidth = it }, valueRange = 2f..160f)
                        }
                        if (mode == AdvancedFileUtils.BatchImageMode.COLLAGE) {
                            Text("Columnas: ${columns.toInt()}")
                            Slider(columns, { columns = it }, valueRange = 1f..5f, steps = 3)
                        }
                        if (mode == AdvancedFileUtils.BatchImageMode.PASSPORT_SHEET) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(passportWidth, { passportWidth = it.filter { c -> c.isDigit() || c in ".," }.take(6) }, label = { Text("Ancho mm") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                                OutlinedTextField(passportHeight, { passportHeight = it.filter { c -> c.isDigit() || c in ".," }.take(6) }, label = { Text("Alto mm") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                            }
                            OutlinedTextField(passportCopies, { passportCopies = it.filter(Char::isDigit).take(2) }, label = { Text("Cantidad de copias") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            Text("Se genera una hoja A4 a 300 dpi.", color = Gold)
                        }
                    }
                }
            }
            if (processing) item {
                Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Procesando imágenes", fontWeight = FontWeight.Bold)
                        LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item {
                Button(onClick = {
                    val maxEdge = maxEdgeText.toIntOrNull()
                    if (inputs.isEmpty()) onMessage("Selecciona imágenes")
                    else if (maxEdge == null || maxEdge !in 256..8192) onMessage("El lado máximo debe estar entre 256 y 8192")
                    else launchPaidExport(viewModel, tool, onMessage) { folderPicker.launch(null) }
                }, enabled = inputs.isNotEmpty() && !processing, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                    Icon(Icons.Rounded.Image, null); Text(" Procesar lote · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
                }
            }
            item { Text("Las operaciones se realizan en el teléfono. Quitar metadatos vuelve a guardar la imagen sin información EXIF.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
