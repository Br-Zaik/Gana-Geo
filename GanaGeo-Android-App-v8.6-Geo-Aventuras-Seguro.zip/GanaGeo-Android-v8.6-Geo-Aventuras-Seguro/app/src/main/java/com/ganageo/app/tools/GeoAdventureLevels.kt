package com.ganageo.app.tools

import kotlin.math.min

data class GamePlatform(val x: Float, val y: Float, val width: Float, val height: Float = 34f)
data class GameHazard(val x: Float, val y: Float, val width: Float = 58f, val height: Float = 42f)
data class GameEnemy(val x: Float, val y: Float, val range: Float = 90f)
data class GameCrystal(val x: Float, val y: Float)

data class AdventureLevel(
    val number: Int,
    val worldName: String,
    val width: Float,
    val platforms: List<GamePlatform>,
    val hazards: List<GameHazard>,
    val enemies: List<GameEnemy>,
    val crystals: List<GameCrystal>,
    val goalX: Float,
    val parSeconds: Int
)

object GeoAdventureLevelFactory {
    fun build(number: Int): AdventureLevel {
        val safeLevel = number.coerceIn(1, GeoGameRules.LEVEL_COUNT)
        val worldIndex = (safeLevel - 1) / 5
        val width = 6_600f + safeLevel * 110f
        val platforms = mutableListOf<GamePlatform>()
        val hazards = mutableListOf<GameHazard>()
        val enemies = mutableListOf<GameEnemy>()

        var x = 0f
        var segment = 0
        while (x < width - 500f) {
            val gap = if (segment > 1 && (segment + safeLevel) % 5 == 0) {
                115f + worldIndex * 18f
            } else {
                35f
            }
            val length = 470f + ((segment * 73 + safeLevel * 31) % 220)
            platforms += GamePlatform(x, 620f, min(length, width - x))

            if (segment > 0 && (segment + safeLevel) % 3 == 0) {
                platforms += GamePlatform(x + 150f, 500f - (segment % 2) * 15f, 190f)
            }
            if (segment > 1 && (segment + safeLevel) % 4 == 0) {
                hazards += GameHazard(x + length * 0.58f, 578f)
            }
            if (segment > 1 && (segment + safeLevel) % 6 == 0) {
                enemies += GameEnemy(x + length * 0.35f, 568f, 70f + worldIndex * 18f)
            }
            x += length + gap
            segment++
        }
        platforms += GamePlatform((width - 650f).coerceAtLeast(0f), 620f, 650f)

        fun reachableCrystal(ratio: Float): GameCrystal {
            val targetX = width * ratio
            val platform = platforms.minByOrNull { candidate ->
                when {
                    targetX < candidate.x -> candidate.x - targetX
                    targetX > candidate.x + candidate.width -> targetX - (candidate.x + candidate.width)
                    else -> 0f
                }
            } ?: platforms.first()
            val crystalX = targetX.coerceIn(
                platform.x + 45f,
                (platform.x + platform.width - 45f).coerceAtLeast(platform.x + 45f)
            )
            return GameCrystal(crystalX, platform.y - 80f)
        }

        return AdventureLevel(
            number = safeLevel,
            worldName = GeoGameRules.worldName(safeLevel),
            width = width,
            platforms = platforms,
            hazards = hazards,
            enemies = enemies,
            crystals = listOf(
                reachableCrystal(0.25f),
                reachableCrystal(0.52f),
                reachableCrystal(0.78f)
            ),
            goalX = width - 150f,
            parSeconds = 55 + safeLevel * 2
        )
    }
}
