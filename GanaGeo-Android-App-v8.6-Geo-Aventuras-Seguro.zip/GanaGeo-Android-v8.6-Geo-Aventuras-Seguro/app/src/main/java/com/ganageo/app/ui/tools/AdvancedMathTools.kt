package com.ganageo.app.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.StudentExpenseStore
import com.ganageo.app.tools.BasicCalculus
import com.ganageo.app.tools.MatrixCalculator
import com.ganageo.app.tools.PeriodicTableData
import com.ganageo.app.tools.SequenceCalculator
import com.ganageo.app.tools.StudentFinanceCalculator
import com.ganageo.app.tools.VectorCalculator
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import kotlinx.coroutines.launch

@Composable
fun AdvancedMathScreen(onBack: () -> Unit) {
    val modes = listOf("Matrices", "Sistema 3×3", "Vectores", "Sucesiones", "Derivada", "Integral")
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var inputA by rememberSaveable { mutableStateOf("1 2\n3 4") }
    var inputB by rememberSaveable { mutableStateOf("5 6\n7 8") }
    var constants by rememberSaveable { mutableStateOf("1, 2, 3") }
    var vectorA by rememberSaveable { mutableStateOf("2, 1") }
    var vectorB by rememberSaveable { mutableStateOf("-1, 2") }
    var first by rememberSaveable { mutableStateOf("2") }
    var difference by rememberSaveable { mutableStateOf("3") }
    var count by rememberSaveable { mutableStateOf("8") }
    var sequenceType by rememberSaveable { mutableIntStateOf(0) }
    var polynomial by rememberSaveable { mutableStateOf("3x^2-4x+7") }
    var result by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var expenseDescription by rememberSaveable { mutableStateOf("") }
    var expenseCategory by rememberSaveable { mutableStateOf("Materiales") }
    var expenseAmount by rememberSaveable { mutableStateOf("") }
    var expenseMessage by rememberSaveable { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Matemática avanzada", "Matrices, vectores, sucesiones y cálculo básico", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SimpleDropdown("Tema", modes, mode) { mode = it; result = ""; error = null }
                        when (mode) {
                            0 -> {
                                Text("Una fila por línea. Separa valores con espacios o comas.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                OutlinedTextField(inputA, { inputA = it.take(500) }, label = { Text("Matriz A") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                                OutlinedTextField(inputB, { inputB = it.take(500) }, label = { Text("Matriz B") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                            }
                            1 -> {
                                OutlinedTextField(inputA, { inputA = it.take(500) }, label = { Text("Coeficientes 3×3") }, placeholder = { Text("1 2 3\n2 -1 1\n3 1 -2") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                                OutlinedTextField(constants, { constants = it.take(100) }, label = { Text("Resultados b₁, b₂, b₃") }, modifier = Modifier.fillMaxWidth())
                            }
                            2 -> {
                                OutlinedTextField(vectorA, { vectorA = it.take(100) }, label = { Text("Vector A") }, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(vectorB, { vectorB = it.take(100) }, label = { Text("Vector B") }, modifier = Modifier.fillMaxWidth())
                            }
                            3 -> {
                                SimpleDropdown("Tipo", listOf("Aritmética", "Geométrica"), sequenceType) { sequenceType = it }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AdvancedNumberField(first, { first = it }, "Primer término", Modifier.weight(1f))
                                    AdvancedNumberField(difference, { difference = it }, if (sequenceType == 0) "Diferencia" else "Razón", Modifier.weight(1f))
                                }
                                AdvancedNumberField(count, { count = it.filter(Char::isDigit) }, "Cantidad de términos", Modifier.fillMaxWidth(), integer = true)
                            }
                            4, 5 -> {
                                OutlinedTextField(polynomial, { polynomial = it.take(160) }, label = { Text("Polinomio") }, placeholder = { Text("3x^2-4x+7") }, modifier = Modifier.fillMaxWidth())
                                Text("Admite polinomios con exponentes enteros de 0 a 20.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Button(onClick = {
                            runCatching {
                                when (mode) {
                                    0 -> {
                                        val a = MatrixCalculator.parse(inputA)
                                        val b = MatrixCalculator.parse(inputB)
                                        buildString {
                                            appendLine("det(A) = ${MatrixCalculator.formatNumber(MatrixCalculator.determinant(a))}")
                                            if (a.size == a.first().size) appendLine("\nA⁻¹:\n${MatrixCalculator.format(MatrixCalculator.inverse(a))}")
                                            if (a.first().size == b.size) appendLine("\nA × B:\n${MatrixCalculator.format(MatrixCalculator.multiply(a, b))}")
                                        }
                                    }
                                    1 -> {
                                        val a = MatrixCalculator.parse(inputA, 3)
                                        val values = constants.split(',', ';', ' ').map(String::trim).filter(String::isNotBlank).map { it.replace(',', '.').toDouble() }.toDoubleArray()
                                        val solution = MatrixCalculator.solve3(a, values)
                                        "x = ${MatrixCalculator.formatNumber(solution[0])}\ny = ${MatrixCalculator.formatNumber(solution[1])}\nz = ${MatrixCalculator.formatNumber(solution[2])}\n\nMétodo: regla de Cramer con determinantes."
                                    }
                                    2 -> {
                                        val r = VectorCalculator.analyze(VectorCalculator.parse(vectorA), VectorCalculator.parse(vectorB))
                                        "|A| = ${MatrixCalculator.formatNumber(r.magnitudeA)}\n|B| = ${MatrixCalculator.formatNumber(r.magnitudeB)}\nA · B = ${MatrixCalculator.formatNumber(r.dotProduct)}\nÁngulo = ${r.angleDegrees?.let(MatrixCalculator::formatNumber) ?: "No definido"}°\nA + B = ${r.sum.joinToString(prefix = "(", postfix = ")") { MatrixCalculator.formatNumber(it) }}\nA − B = ${r.difference.joinToString(prefix = "(", postfix = ")") { MatrixCalculator.formatNumber(it) }}"
                                    }
                                    3 -> {
                                        val a = first.replace(',', '.').toDouble()
                                        val d = difference.replace(',', '.').toDouble()
                                        val n = count.toInt()
                                        val r = if (sequenceType == 0) SequenceCalculator.arithmetic(a, d, n) else SequenceCalculator.geometric(a, d, n)
                                        "${r.formula}\n\nTérminos: ${r.terms.take(30).joinToString { MatrixCalculator.formatNumber(it) }}${if (r.terms.size > 30) "…" else ""}\n\naₙ = ${MatrixCalculator.formatNumber(r.nthTerm)}\nSₙ = ${MatrixCalculator.formatNumber(r.sum)}"
                                    }
                                    4 -> BasicCalculus.derivative(polynomial).steps.joinToString("\n")
                                    else -> BasicCalculus.integral(polynomial).steps.joinToString("\n")
                                }
                            }.onSuccess { result = it; error = null }.onFailure { error = it.message ?: "Datos inválidos" }
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                            Text("Calcular", fontWeight = FontWeight.Bold)
                        }
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            if (result.isNotBlank()) item {
                Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.09f)), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Resultado y procedimiento", color = NeonGreen, fontWeight = FontWeight.Bold)
                        Text(result)
                    }
                }
            }
        }
    }
}

@Composable
fun PeriodicTableScreen(onBack: () -> Unit) {
    var search by rememberSaveable { mutableStateOf("") }
    val results = PeriodicTableData.search(search)
    Column(Modifier.fillMaxSize()) {
        ToolHeader("Tabla periódica", "Consulta rápida sin conexión", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                OutlinedTextField(search, { search = it.take(40) }, label = { Text("Buscar nombre, símbolo o número") }, modifier = Modifier.fillMaxWidth())
                Text("Incluye los 118 elementos. Busca por nombre, símbolo, número atómico o categoría.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
            }
            items(results, key = { it.atomicNumber }) { element ->
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(element.symbol, color = NeonGreen, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Column(Modifier.weight(1f)) {
                            Text("${element.atomicNumber}. ${element.name}", fontWeight = FontWeight.Bold)
                            Text("Masa atómica: ${element.atomicMass}")
                            Text("${element.category} · Grupo ${element.group ?: "—"} · Período ${element.period}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StudentFinanceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val expenseStore = remember(context) { StudentExpenseStore(context.applicationContext) }
    val expenses by expenseStore.expenses.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val modes = listOf("Interés simple", "Interés compuesto", "Cuota de préstamo", "Dividir gastos")
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var amount by rememberSaveable { mutableStateOf("1000") }
    var rate by rememberSaveable { mutableStateOf("10") }
    var time by rememberSaveable { mutableStateOf("1") }
    var frequency by rememberSaveable { mutableStateOf("12") }
    var people by rememberSaveable { mutableStateOf("4") }
    var result by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        ToolHeader("Finanzas para estudiantes", "Interés, cuotas y gastos compartidos", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SimpleDropdown("Cálculo", modes, mode) { mode = it; result = "" }
                        AdvancedNumberField(amount, { amount = it }, if (mode == 3) "Gasto total (S/)" else "Monto principal (S/)", Modifier.fillMaxWidth())
                        if (mode != 3) AdvancedNumberField(rate, { rate = it }, "Tasa anual (%)", Modifier.fillMaxWidth())
                        when (mode) {
                            0, 1 -> AdvancedNumberField(time, { time = it }, "Tiempo en años", Modifier.fillMaxWidth())
                            2 -> AdvancedNumberField(time, { time = it.filter(Char::isDigit) }, "Plazo en meses", Modifier.fillMaxWidth(), integer = true)
                            3 -> AdvancedNumberField(people, { people = it.filter(Char::isDigit) }, "Cantidad de personas", Modifier.fillMaxWidth(), integer = true)
                        }
                        if (mode == 1) AdvancedNumberField(frequency, { frequency = it.filter(Char::isDigit) }, "Capitalizaciones por año", Modifier.fillMaxWidth(), integer = true)
                        Button(onClick = {
                            runCatching {
                                val principal = amount.replace(',', '.').toDouble()
                                when (mode) {
                                    0 -> StudentFinanceCalculator.simpleInterest(principal, rate.replace(',', '.').toDouble(), time.replace(',', '.').toDouble())
                                    1 -> StudentFinanceCalculator.compoundInterest(principal, rate.replace(',', '.').toDouble(), time.replace(',', '.').toDouble(), frequency.toInt())
                                    2 -> StudentFinanceCalculator.loanPayment(principal, rate.replace(',', '.').toDouble(), time.toInt())
                                    else -> {
                                        val n = people.toInt(); require(n > 0) { "La cantidad de personas debe ser mayor que cero" }
                                        result = "Cada persona paga: S/ ${"%.2f".format(principal / n)}"
                                        null
                                    }
                                }
                            }.onSuccess { data ->
                                if (data != null) result = buildString {
                                    appendLine("Capital: S/ ${"%.2f".format(data.principal)}")
                                    appendLine("Interés: S/ ${"%.2f".format(data.interest)}")
                                    appendLine("Total: S/ ${"%.2f".format(data.total)}")
                                    data.payment?.let { append("Cuota mensual: S/ ${"%.2f".format(it)}") }
                                }
                                error = null
                            }.onFailure { error = it.message ?: "Datos inválidos" }
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) { Text("Calcular", fontWeight = FontWeight.Bold) }
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            if (result.isNotBlank()) item {
                Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.09f)), shape = RoundedCornerShape(18.dp)) { Text(result, modifier = Modifier.padding(16.dp), fontWeight = FontWeight.Bold) }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Registro local de gastos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Se guarda únicamente en este teléfono.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedTextField(expenseDescription, { expenseDescription = it.take(120); expenseMessage = null }, label = { Text("Descripción") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(expenseCategory, { expenseCategory = it.take(60); expenseMessage = null }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth())
                        AdvancedNumberField(expenseAmount, { expenseAmount = it; expenseMessage = null }, "Monto (S/)", Modifier.fillMaxWidth())
                        Button(
                            onClick = {
                                scope.launch {
                                    runCatching { expenseStore.add(expenseDescription, expenseCategory, expenseAmount.replace(',', '.').toDouble()) }
                                        .onSuccess { expenseDescription = ""; expenseAmount = ""; expenseMessage = "Gasto guardado" }
                                        .onFailure { expenseMessage = it.message ?: "No se pudo guardar" }
                                }
                            },
                            enabled = expenseDescription.isNotBlank() && expenseAmount.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                        ) { Text("Guardar gasto", fontWeight = FontWeight.Bold) }
                        expenseMessage?.let { Text(it, color = if (it.startsWith("No")) MaterialTheme.colorScheme.error else NeonGreen) }
                    }
                }
            }
            if (expenses.isNotEmpty()) {
                item {
                    val totalCents = expenses.sumOf { it.amountCents }
                    val categoryTotals = expenses.groupBy { it.category }.mapValues { entry -> entry.value.sumOf { it.amountCents } }
                    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.09f)), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Total registrado: S/ ${"%.2f".format(totalCents / 100.0)}", fontWeight = FontWeight.Bold, color = NeonGreen)
                            categoryTotals.entries.sortedByDescending { it.value }.take(6).forEach { (category, cents) ->
                                Text("$category: S/ ${"%.2f".format(cents / 100.0)}")
                            }
                            OutlinedButton(onClick = { scope.launch { expenseStore.clear() } }, modifier = Modifier.fillMaxWidth()) { Text("Borrar todos los gastos") }
                        }
                    }
                }
                items(expenses.sortedByDescending { it.timestamp }, key = { it.id }) { expense ->
                    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(expense.description, fontWeight = FontWeight.Bold)
                                Text(expense.category, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("S/ ${"%.2f".format(expense.amountCents / 100.0)}", color = NeonGreen)
                            }
                            OutlinedButton(onClick = { scope.launch { expenseStore.delete(expense.id) } }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar")
                            }
                        }
                    }
                }
            }
            item { Text("Resultados educativos y aproximados. Verifica tasas, comisiones y condiciones reales antes de contratar un producto financiero.", color = Gold) }
        }
    }
}

@Composable
private fun AdvancedNumberField(value: String, onValue: (String) -> Unit, label: String, modifier: Modifier, integer: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw -> onValue(raw.filter { it.isDigit() || (!integer && it in ".,-") }.take(30)) },
        label = { Text(label) },
        modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = if (integer) KeyboardType.Number else KeyboardType.Decimal),
        singleLine = true
    )
}
