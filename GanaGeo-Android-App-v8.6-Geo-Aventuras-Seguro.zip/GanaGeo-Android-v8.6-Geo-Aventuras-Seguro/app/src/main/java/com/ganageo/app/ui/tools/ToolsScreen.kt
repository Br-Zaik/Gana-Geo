package com.ganageo.app.ui.tools

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ganageo.app.BuildConfig
import com.ganageo.app.GanaGeoUiState
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolCategory
import com.ganageo.app.model.ToolId
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen

@Composable
fun ToolsScreen(
    uiState: GanaGeoUiState,
    viewModel: GanaGeoViewModel
) {
    var selectedToolName by rememberSaveable { mutableStateOf<String?>(null) }
    val selectedTool = selectedToolName?.let { name ->
        ToolId.entries.firstOrNull { it.name == name }
    }
    val snackbar = remember { SnackbarHostState() }
    var localMessage by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = selectedTool != null) {
        selectedToolName = null
    }

    LaunchedEffect(selectedToolName) {
        if (selectedToolName == null) viewModel.retryPendingToolCompletions()
    }

    LaunchedEffect(localMessage) {
        localMessage?.let {
            snackbar.showSnackbar(it)
            localMessage = null
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (selectedTool == null) {
                ToolsHome(
                    uiState = uiState,
                    onOpen = { selectedToolName = it.name },
                    onAddTestCredits = viewModel::addTestToolCredits
                )
            } else {
                ToolDestination(
                    tool = selectedTool,
                    viewModel = viewModel,
                    onBack = { selectedToolName = null },
                    onMessage = { localMessage = it }
                )
            }
        }
    }
}

@Composable
private fun ToolsHome(
    uiState: GanaGeoUiState,
    onOpen: (ToolId) -> Unit,
    onAddTestCredits: (Long) -> Unit
) {
    val realCredits = uiState.dashboard?.toolCredits?.availableCredits ?: 0
    val testCredits = if (BuildConfig.DEBUG) uiState.testToolBalance.availableCredits else 0
    val rewardPoints = uiState.dashboard?.wallet?.internalPoints ?: 0
    val testRewards = if (BuildConfig.DEBUG) uiState.testToolBalance.rewardPoints else 0

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Herramientas Geo", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(5.dp))
            Text(
                "Utilidades offline y funciones con créditos para estudiar, preparar documentos y trabajar con imágenes, sin APIs externas ni IA.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            CreditHero(
                realCredits = realCredits,
                realRewardPoints = rewardPoints,
                testCredits = testCredits,
                testRewardPoints = testRewards,
                realProgress = uiState.dashboard?.toolCredits?.rewardProgress ?: 0,
                testProgress = if (BuildConfig.DEBUG) uiState.testToolBalance.rewardProgress else 0
            )
        }

        item {
            Text("Packs de créditos", style = MaterialTheme.typography.titleLarge)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PackCard(
                    title = "Pack Geo 50",
                    price = "S/5",
                    credits = "50 créditos",
                    reward = "Hasta 250 Rewards",
                    modifier = Modifier.weight(1f),
                    onClick = { if (BuildConfig.DEBUG) onAddTestCredits(50) }
                )
                PackCard(
                    title = "Pack Geo 100",
                    price = "S/10",
                    credits = "100 créditos",
                    reward = "Hasta 500 Rewards",
                    modifier = Modifier.weight(1f),
                    onClick = { if (BuildConfig.DEBUG) onAddTestCredits(100) }
                )
            }
        }

        item {
            InfoBanner(
                if (BuildConfig.DEBUG) {
                    "Modo de prueba: los botones de los packs agregan créditos simulados. No cobran dinero ni generan saldo retirable real."
                } else {
                    "Las compras se habilitarán mediante Google Play cuando los productos pack_geo_50 y pack_geo_100 estén configurados y verificados en el servidor."
                }
            )
        }

        ToolCategory.entries.forEach { category ->
            item {
                Column {
                    Text(category.title, style = MaterialTheme.typography.titleLarge)
                    Text(category.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(ToolId.entries.filter { it.category == category }, key = { it.name }) { tool ->
                ToolCard(tool = tool, onClick = { onOpen(tool) })
            }
        }

        item {
            InfoBanner(
                "Las herramientas gratuitas no generan Rewards. En las herramientas pagadas, los créditos se descuentan al iniciar y los Rewards se confirman al terminar; si falla antes de crear el archivo, los créditos se devuelven."
            )
        }
    }
}

@Composable
private fun CreditHero(
    realCredits: Long,
    realRewardPoints: Long,
    testCredits: Long,
    testRewardPoints: Long,
    realProgress: Long,
    testProgress: Long
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = NeonGreen)
                Spacer(Modifier.width(8.dp))
                Text("Créditos para herramientas", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallInfo("Créditos disponibles", realCredits.toString(), Icons.Rounded.CheckCircle, Modifier.weight(1f))
                SmallInfo("Geo Rewards", realRewardPoints.toString(), Icons.Rounded.CheckCircle, Modifier.weight(1f))
            }
            Text(
                "Progreso para los próximos 50 Rewards: $realProgress/10 créditos comprados usados",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium
            )
            if (BuildConfig.DEBUG) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SmallInfo("Créditos de prueba", testCredits.toString(), Icons.Rounded.Info, Modifier.weight(1f))
                    SmallInfo("Rewards de prueba", testRewardPoints.toString(), Icons.Rounded.Info, Modifier.weight(1f))
                }
                Text(
                    "Progreso de prueba: $testProgress/10",
                    color = Gold,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun SmallInfo(label: String, value: String, icon: ImageVector, modifier: Modifier) {
    Row(
        modifier = modifier
            .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(value, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PackCard(
    title: String,
    price: String,
    credits: String,
    reward: String,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(enabled = BuildConfig.DEBUG, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = NeonGreen)
            Spacer(Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(price, color = NeonGreen, style = MaterialTheme.typography.titleLarge)
            Text(credits, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(reward, color = Gold, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                if (BuildConfig.DEBUG) "Agregar para probar" else "Google Play",
                color = if (BuildConfig.DEBUG) NeonGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun ToolCard(tool: ToolId, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(NeonGreen.copy(alpha = 0.15f), RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(tool.icon, contentDescription = null, tint = NeonGreen)
            }
            Spacer(Modifier.width(13.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(tool.title, fontWeight = FontWeight.Bold)
                Text(tool.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (tool.creditCost > 0) {
                Column(horizontalAlignment = Alignment.End) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = Gold, modifier = Modifier.size(18.dp))
                    Text("${tool.creditCost} cr.", color = Gold, fontWeight = FontWeight.Bold)
                }
            } else {
                Text("Gratis", color = NeonGreen, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun InfoBanner(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.10f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Rounded.Info, contentDescription = null, tint = Gold)
            Spacer(Modifier.width(10.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun ToolHeader(title: String, subtitle: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver")
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun ToolDestination(
    tool: ToolId,
    viewModel: GanaGeoViewModel,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    when (tool) {
        ToolId.SCIENTIFIC_CALCULATOR -> ScientificCalculatorScreen(onBack)
        ToolId.UNIT_CONVERTER -> UnitConverterScreen(onBack)
        ToolId.PERCENT_RULE -> PercentRuleScreen(onBack)
        ToolId.GRADES_AVERAGES -> GradesAverageScreen(onBack)
        ToolId.GEOMETRY -> GeometryScreen(onBack)
        ToolId.ADVANCED_MATH -> AdvancedMathScreen(onBack)
        ToolId.EQUATION_SOLVER -> EquationSolverScreen(onBack)
        ToolId.FUNCTION_GRAPHER -> FunctionGrapherScreen(onBack)
        ToolId.STATISTICS -> StatisticsScreen(onBack)
        ToolId.PHYSICS_CALCULATOR -> PhysicsCalculatorScreen(onBack)
        ToolId.PERIODIC_TABLE -> PeriodicTableScreen(onBack)
        ToolId.CHEMISTRY_CALCULATOR -> ChemistryCalculatorScreen(onBack)
        ToolId.NUMBER_SYSTEMS -> NumberSystemsScreen(onBack)
        ToolId.CITATION_GENERATOR -> CitationGeneratorScreen(onBack)
        ToolId.EXAM_BUILDER -> ExamBuilderScreen(onBack, onMessage)
        ToolId.STUDY_PLANNER_PRO -> StudyPlannerProScreen(onBack, onMessage)
        ToolId.FINANCE_CALCULATOR -> StudentFinanceScreen(onBack)
        ToolId.FLASHCARDS -> FlashcardsScreen(onBack)
        ToolId.ACADEMIC_PLANNER -> AcademicPlannerScreen(onBack)
        ToolId.TEXT_TOOLKIT -> TextToolkitScreen(onBack)
        ToolId.GEO_ADVENTURES -> GeoAdventuresScreen(viewModel, onBack, onMessage)
        ToolId.DOCUMENT_SCANNER -> DocumentScannerScreen(viewModel, tool, onBack, onMessage)
        ToolId.TEXT_TO_PDF -> TextToPdfScreen(viewModel, tool, onBack, onMessage)
        ToolId.PDF_WATERMARK_SECURITY -> PdfWatermarkSecurityScreen(viewModel, tool, onBack, onMessage)
        ToolId.IMAGES_TO_PDF -> ImagesToPdfScreen(viewModel, tool, onBack, onMessage)
        ToolId.PDF_ORGANIZER -> PdfOrganizerScreen(viewModel, tool, onBack, onMessage)
        ToolId.PDF_TO_IMAGES -> PdfToImagesScreen(viewModel, tool, onBack, onMessage)
        ToolId.SIGN_PDF -> SignPdfScreen(viewModel, tool, onBack, onMessage)
        ToolId.IMAGE_BATCH_STUDIO -> ImageBatchStudioScreen(viewModel, tool, onBack, onMessage)
        ToolId.COMPRESS_IMAGE,
        ToolId.RESIZE_IMAGE,
        ToolId.CONVERT_IMAGE,
        ToolId.CROP_ROTATE_IMAGE,
        ToolId.WATERMARK_IMAGE -> ImageToolScreen(viewModel, tool, onBack, onMessage)
        ToolId.QR_TOOL -> QrToolScreen(onBack, onMessage)
        ToolId.WORD_COUNTER -> WordCounterScreen(onBack)
        ToolId.STOPWATCH_TIMER -> StopwatchTimerScreen(onBack)
    }
}
