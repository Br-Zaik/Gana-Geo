package com.ganageo.app.tools

import android.net.Uri

data class PdfImagePage(
    val uri: Uri,
    val rotationDegrees: Int = 0
)

enum class PdfPaperSize(
    val label: String,
    val widthPoints: Int,
    val heightPoints: Int
) {
    AUTOMATIC("Ajuste automático", 0, 0),
    A3("A3 · 29.7 × 42.0 cm", 842, 1191),
    A4("A4 · 21.0 × 29.7 cm", 595, 842),
    A5("A5 · 14.8 × 21.0 cm", 420, 595),
    B4("B4 · 25.0 × 35.3 cm", 709, 1001),
    B5("B5 · 17.6 × 25.0 cm", 499, 709),
    LETTER("Carta · 21.6 × 27.9 cm", 612, 792),
    LEGAL("Legal · 21.6 × 35.6 cm", 612, 1008),
    EXECUTIVE("Ejecutivo · 18.4 × 26.7 cm", 522, 756)
}

enum class PdfOrientation(val label: String) {
    AUTOMATIC("Automática"),
    PORTRAIT("Vertical"),
    LANDSCAPE("Horizontal")
}

enum class PdfMargin(val label: String, val points: Int) {
    NONE("Sin márgenes", 0),
    SMALL("Pequeños", 12),
    NORMAL("Normales", 28),
    LARGE("Amplios", 48)
}

enum class PdfCompression(
    val label: String,
    val detail: String,
    val maxImageEdge: Int
) {
    MAXIMUM("Máxima", "Archivo más pequeño, menor detalle", 1100),
    MEDIUM("Media", "Buen equilibrio entre peso y lectura", 1600),
    NORMAL("Normal", "Calidad alta para tareas y documentos", 2300),
    LOW("Baja", "Calidad cercana al original", 3200)
}

enum class PdfImageFit(val label: String) {
    CONTAIN("Encajar completa"),
    FILL("Llenar página")
}

enum class DocumentImageFilter(val label: String) {
    ORIGINAL("Original"),
    DOCUMENT("Documento"),
    GRAYSCALE("Escala de grises"),
    ENHANCE("Mejorar color")
}

data class ImagesToPdfOptions(
    val paperSize: PdfPaperSize = PdfPaperSize.A4,
    val orientation: PdfOrientation = PdfOrientation.AUTOMATIC,
    val margin: PdfMargin = PdfMargin.NORMAL,
    val compression: PdfCompression = PdfCompression.NORMAL,
    val fit: PdfImageFit = PdfImageFit.CONTAIN,
    val filter: DocumentImageFilter = DocumentImageFilter.ORIGINAL,
    val brightness: Int = 0,
    val contrast: Float = 1f,
    val password: String? = null
)

enum class SignaturePosition(val label: String, val xFraction: Float, val yFraction: Float) {
    TOP_LEFT("Arriba izquierda", 0f, 1f),
    TOP_CENTER("Arriba centro", 0.5f, 1f),
    TOP_RIGHT("Arriba derecha", 1f, 1f),
    CENTER_LEFT("Centro izquierda", 0f, 0.5f),
    CENTER("Centro", 0.5f, 0.5f),
    CENTER_RIGHT("Centro derecha", 1f, 0.5f),
    BOTTOM_LEFT("Abajo izquierda", 0f, 0f),
    BOTTOM_CENTER("Abajo centro", 0.5f, 0f),
    BOTTOM_RIGHT("Abajo derecha", 1f, 0f)
}

data class SignaturePlacement(
    val position: SignaturePosition = SignaturePosition.BOTTOM_RIGHT,
    val widthPercent: Int = 28,
    val label: String = ""
)
