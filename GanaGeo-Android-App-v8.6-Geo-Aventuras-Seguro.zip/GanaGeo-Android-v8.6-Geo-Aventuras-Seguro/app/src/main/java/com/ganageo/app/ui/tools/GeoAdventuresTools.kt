package com.ganageo.app.ui.tools

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.GeoGameRunStart
import com.ganageo.app.model.GeoGameStatus
import com.ganageo.app.tools.GeoGameRules
import com.ganageo.app.tools.GeoLifePackage
import com.ganageo.app.tools.AdventureLevel
import com.ganageo.app.tools.GeoAdventureLevelFactory
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.sin

@Composable
fun GeoAdventuresScreen(
    viewModel: GanaGeoViewModel,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<GeoGameStatus?>(null) }
    var loading by remember { mutableStateOf(true) }
    var localMode by remember { mutableStateOf(false) }
    var activeRun by remember { mutableStateOf<GeoGameRunStart?>(null) }
    var activeLevel by remember { mutableIntStateOf(1) }
    var pendingPurchase by remember { mutableStateOf<GeoLifePackage?>(null) }

    fun reload(preferLocal: Boolean = localMode) {
        scope.launch {
            loading = true
            viewModel.loadGeoGameStatus(preferLocal)
                .onSuccess {
                    status = it
                    localMode = it.isLocalTest
                }
                .onFailure { onMessage(it.message ?: "No se pudo cargar Geo Aventuras.") }
            loading = false
        }
    }

    fun buyPackage(packageInfo: GeoLifePackage) {
        scope.launch {
            loading = true
            viewModel.buyGeoGameLives(packageInfo.code)
                .onSuccess { purchase ->
                    localMode = purchase.isLocalTest
                    onMessage(
                        "Recibiste ${purchase.livesAdded} vida(s) amarilla(s). " +
                            "Los Rewards se liberan al usarlas."
                    )
                    status = viewModel.loadGeoGameStatus(localMode).getOrNull() ?: status
                }
                .onFailure { onMessage(it.message ?: "No se pudieron comprar vidas.") }
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload(false) }

    pendingPurchase?.let { pack ->
        AlertDialog(
            onDismissRequest = { if (!loading) pendingPurchase = null },
            title = { Text("Confirmar compra de vidas") },
            text = {
                Text(
                    "Comprarás ${pack.lives} vida(s) amarilla(s) por ${pack.creditCost} créditos. " +
                        "La compra no entrega Rewards todavía; se liberan al utilizar cada vida."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingPurchase = null
                        buyPackage(pack)
                    },
                    enabled = !loading
                ) { Text("Comprar") }
            },
            dismissButton = {
                TextButton(onClick = { pendingPurchase = null }, enabled = !loading) {
                    Text("Cancelar")
                }
            }
        )
    }

    if (activeRun != null) {
        GeoAdventureGame(
            level = GeoAdventureLevelFactory.build(activeLevel),
            run = activeRun!!,
            viewModel = viewModel,
            onMessage = onMessage,
            onExit = {
                activeRun = null
                reload(localMode)
            }
        )
        return
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(
            "Geo Aventuras",
            "20 niveles originales con vidas rojas y amarillas",
            onBack
        )

        if (loading && status == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NeonGreen)
            }
            return@Column
        }

        val current = status ?: GeoGameStatus(isLocalTest = true)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Tus vidas", style = MaterialTheme.typography.titleLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            LifeInfo(
                                symbol = "❤️",
                                value = current.freeLives.toString(),
                                label = "Rojas gratis",
                                modifier = Modifier.weight(1f)
                            )
                            LifeInfo(
                                symbol = "💛",
                                value = current.premiumLives.toString(),
                                label = "Amarillas premium",
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Text(
                            "Cada día vuelves a tener hasta 3 vidas rojas. No generan Rewards. " +
                                "Cada vida amarilla usada suma al progreso la parte pagada con créditos comprados: cada 10 créditos comprados y usados liberan 50 Rewards.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "Vidas amarillas usadas hoy: ${current.premiumUsedToday}/${current.premiumDailyLimit}",
                            color = Gold,
                            fontWeight = FontWeight.Bold
                        )
                        if (current.isLocalTest) {
                            Text(
                                "Modo de prueba: usa los créditos simulados del panel de Herramientas.",
                                color = NeonGreen
                            )
                        }
                    }
                }
            }

            item {
                Text("Comprar vidas amarillas", style = MaterialTheme.typography.titleLarge)
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LifePackCard("1 vida", "2 créditos", "life_1", enabled = !loading, modifier = Modifier.weight(1f)) { code ->
                        pendingPurchase = GeoGameRules.packageByCode(code)
                    }
                    LifePackCard("5 vidas", "10 créditos", "life_5", enabled = !loading, modifier = Modifier.weight(1f)) { code ->
                        pendingPurchase = GeoGameRules.packageByCode(code)
                    }
                    LifePackCard("15 vidas", "30 créditos", "life_15", enabled = !loading, modifier = Modifier.weight(1f)) { code ->
                        pendingPurchase = GeoGameRules.packageByCode(code)
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardGreen),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Progreso", fontWeight = FontWeight.Bold)
                            Text("Nivel desbloqueado: ${current.unlockedLevel}/20")
                            Text("Estrellas: ${current.totalStars}  ·  Mejor puntaje: ${current.bestScore}")
                        }
                        IconButton(onClick = { reload(localMode) }) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar", tint = NeonGreen)
                        }
                    }
                }
            }

            item {
                Text("Selecciona un nivel", style = MaterialTheme.typography.titleLarge)
            }

            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxWidth().height(430.dp),
                    userScrollEnabled = false,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items((1..20).toList()) { level ->
                        LevelButton(
                            level = level,
                            unlocked = level <= current.unlockedLevel,
                            onClick = { activeLevel = level }
                        )
                    }
                }
            }

            item {
                val levelUnlocked = activeLevel <= current.unlockedLevel
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardGreen),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "Nivel $activeLevel · ${GeoAdventureLevelFactory.build(activeLevel).worldName}",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            "Recoge 3 cristales, evita obstáculos y llega al portal. Ganar o perder no cambia los Rewards.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = {
                                scope.launch {
                                    viewModel.startGeoGameRun(activeLevel, "free", current.isLocalTest)
                                        .onSuccess { activeRun = it }
                                        .onFailure { onMessage(it.message ?: "No se pudo iniciar con vida roja.") }
                                }
                            },
                            enabled = levelUnlocked && current.freeLives > 0 && !loading,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD84343),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Rounded.Favorite, contentDescription = null)
                            Text(" Jugar con vida roja")
                        }
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    viewModel.startGeoGameRun(activeLevel, "premium", current.isLocalTest)
                                        .onSuccess { activeRun = it }
                                        .onFailure { onMessage(it.message ?: "No se pudo iniciar con vida amarilla.") }
                                }
                            },
                            enabled = levelUnlocked && current.premiumLives > 0 &&
                                current.premiumUsedToday < current.premiumDailyLimit && !loading,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.Star, contentDescription = null, tint = Gold)
                            Text(" Jugar con vida amarilla")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LifeInfo(symbol: String, value: String, label: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(14.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(symbol, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun LifePackCard(
    title: String,
    cost: String,
    code: String,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onBuy: (String) -> Unit
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = Gold)
            Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(cost, color = NeonGreen, textAlign = TextAlign.Center)
            FilledTonalButton(onClick = { onBuy(code) }, enabled = enabled, contentPadding = PaddingValues(horizontal = 9.dp)) {
                Text("Comprar")
            }
        }
    }
}

@Composable
private fun LevelButton(level: Int, unlocked: Boolean, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        enabled = unlocked,
        modifier = Modifier.height(64.dp),
        contentPadding = PaddingValues(4.dp)
    ) {
        if (unlocked) {
            Text(level.toString(), fontWeight = FontWeight.Bold)
        } else {
            Icon(Icons.Rounded.Lock, contentDescription = "Bloqueado", modifier = Modifier.size(18.dp))
        }
    }
}

private enum class GameOutcome { WON, LOST }

@Composable
private fun GeoAdventureGame(
    level: AdventureLevel,
    run: GeoGameRunStart,
    viewModel: GanaGeoViewModel,
    onMessage: (String) -> Unit,
    onExit: () -> Unit
) {
    val playerWidth = 46f
    val playerHeight = 58f
    var playerX by remember(level.number) { mutableFloatStateOf(70f) }
    var playerY by remember(level.number) { mutableFloatStateOf(520f) }
    var velocityY by remember(level.number) { mutableFloatStateOf(0f) }
    var moveDirection by remember { mutableFloatStateOf(0f) }
    var jumpQueued by remember { mutableStateOf(false) }
    var onGround by remember { mutableStateOf(false) }
    var elapsedMs by remember { mutableLongStateOf(0L) }
    var collected by remember { mutableStateOf(setOf<Int>()) }
    var outcome by remember { mutableStateOf<GameOutcome?>(null) }
    var activated by remember(run.runId) { mutableStateOf(!run.needsActivation) }
    var activating by remember { mutableStateOf(false) }
    var activationRewards by remember { mutableLongStateOf(0L) }
    var reportingResult by remember { mutableStateOf(false) }
    var resultSaved by remember { mutableStateOf(false) }
    var resultError by remember { mutableStateOf<String?>(null) }
    var reportAttempt by remember { mutableIntStateOf(0) }

    fun endGame(result: GameOutcome) {
        if (outcome == null) outcome = result
    }

    BackHandler {
        if (outcome == null) {
            endGame(GameOutcome.LOST)
        } else if (resultSaved) {
            onExit()
        }
    }

    LaunchedEffect(level.number, outcome) {
        if (outcome != null) return@LaunchedEffect
        var previousNanos = withFrameNanos { it }
        while (outcome == null) {
            val now = withFrameNanos { it }
            val dt = ((now - previousNanos) / 1_000_000_000f).coerceIn(0f, 0.035f)
            previousNanos = now
            elapsedMs += (dt * 1000).toLong()

            val previousBottom = playerY + playerHeight
            val speed = 245f + level.number * 2.5f
            playerX = (playerX + moveDirection * speed * dt).coerceIn(0f, level.width - playerWidth)

            if (jumpQueued) {
                if (onGround) {
                    velocityY = -590f
                    onGround = false
                }
                jumpQueued = false
            }

            velocityY += 1_260f * dt
            var nextY = playerY + velocityY * dt
            onGround = false

            val nextBottom = nextY + playerHeight
            level.platforms.forEach { platform ->
                val overlapsX = playerX + playerWidth > platform.x && playerX < platform.x + platform.width
                if (overlapsX && velocityY >= 0f && previousBottom <= platform.y + 8f && nextBottom >= platform.y) {
                    nextY = platform.y - playerHeight
                    velocityY = 0f
                    onGround = true
                }
            }
            playerY = nextY

            val playerRect = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)
            level.crystals.forEachIndexed { index, crystal ->
                if (index !in collected && playerRect.overlaps(Rect(crystal.x - 22f, crystal.y - 22f, crystal.x + 22f, crystal.y + 22f))) {
                    collected = collected + index
                }
            }

            val hitHazard = level.hazards.any { hazard ->
                playerRect.overlaps(Rect(hazard.x, hazard.y, hazard.x + hazard.width, hazard.y + hazard.height))
            }
            val elapsedSeconds = elapsedMs / 1000f
            val hitEnemy = level.enemies.anyIndexed { index, enemy ->
                val enemyX = enemy.x + sin(elapsedSeconds * (1.2f + index * 0.1f)) * enemy.range
                playerRect.overlaps(Rect(enemyX, enemy.y, enemyX + 48f, enemy.y + 52f))
            }

            if (hitHazard || hitEnemy || playerY > 760f || elapsedMs > 140_000L) {
                endGame(GameOutcome.LOST)
            } else if (playerX + playerWidth >= level.goalX) {
                endGame(GameOutcome.WON)
            }
        }
    }

    val elapsedSeconds = (elapsedMs / 1000L).toInt()
    LaunchedEffect(run.runId, elapsedSeconds, activated, outcome) {
        if (run.needsActivation && !activated && !activating && outcome == null && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            activating = true
            viewModel.activateGeoGameRun(run)
                .onSuccess {
                    activated = true
                    activationRewards = it.awardedPoints
                    if (it.awardedPoints > 0) {
                        onMessage("Vida amarilla usada: ganaste ${it.awardedPoints} Geo Rewards.")
                    } else {
                        onMessage("Vida amarilla usada: el progreso de Rewards se actualizó según el origen de los créditos.")
                    }
                }
                .onFailure {
                    if (!it.message.orEmpty().contains("not ready", ignoreCase = true)) {
                        onMessage(it.message ?: "No se pudo activar la vida amarilla.")
                    }
                }
            activating = false
        }
    }

    LaunchedEffect(outcome, reportAttempt) {
        val finalOutcome = outcome ?: return@LaunchedEffect
        if (resultSaved || reportingResult) return@LaunchedEffect
        reportingResult = true
        resultError = null

        var canFinish = activated
        if (run.needsActivation && !canFinish && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            viewModel.activateGeoGameRun(run)
                .onSuccess {
                    canFinish = true
                    activated = true
                    activationRewards = it.awardedPoints
                    if (it.awardedPoints > 0) {
                        onMessage("Vida amarilla usada: ganaste ${it.awardedPoints} Geo Rewards.")
                    } else {
                        onMessage("Vida amarilla usada: el progreso de Rewards se actualizó según el origen de los créditos.")
                    }
                }
                .onFailure {
                    resultError = it.message ?: "No se pudo confirmar la vida amarilla."
                }
        }

        if (run.needsActivation && !canFinish) {
            if (elapsedSeconds < GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
                runCatching { viewModel.cancelGeoGameRun(run) }
                    .onSuccess {
                        onMessage("La partida terminó antes de activar la vida amarilla; la vida fue devuelta.")
                        resultSaved = true
                    }
                    .onFailure {
                        resultError = it.message ?: "No se pudo devolver la vida todavía."
                    }
            }
            reportingResult = false
            return@LaunchedEffect
        }

        val won = finalOutcome == GameOutcome.WON
        val stars = GeoGameRules.calculateStars(
            won = won,
            collectedCrystals = collected.size,
            seconds = elapsedSeconds,
            parSeconds = level.parSeconds
        )
        val score = (playerX / 5f).toLong() + collected.size * 500L + if (won) 1_000L else 0L
        viewModel.finishGeoGameRun(run, won, stars, score, elapsedMs)
            .onSuccess { resultSaved = true }
            .onFailure { resultError = it.message ?: "No se pudo guardar el resultado de la partida." }
        reportingResult = false
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF081B2D))) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    if (outcome == null) endGame(GameOutcome.LOST)
                    else if (resultSaved) onExit()
                },
                enabled = outcome == null || resultSaved
            ) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Salir")
            }
            Column(Modifier.weight(1f)) {
                Text("Nivel ${level.number} · ${level.worldName}", fontWeight = FontWeight.Bold)
                Text(
                    "${if (run.lifeType == "premium") "💛" else "❤️"}  " +
                        "Cristales ${collected.size}/3  ·  ${elapsedSeconds}s",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (run.needsActivation && !activated) {
                Text(
                    if (activating) "Activando…" else "Rewards en ${max(GeoGameRules.PREMIUM_ACTIVATION_SECONDS - elapsedSeconds, 0)}s",
                    color = Gold,
                    fontWeight = FontWeight.Bold
                )
            } else if (activationRewards > 0) {
                Text("+$activationRewards", color = Gold, fontWeight = FontWeight.Bold)
            }
        }

        Box(Modifier.fillMaxWidth().weight(1f)) {
            Canvas(Modifier.fillMaxSize()) {
                val viewportWidth = size.width
                val viewportHeight = size.height
                val scaleY = viewportHeight / 720f
                val cameraX = (playerX - viewportWidth * 0.32f).coerceIn(0f, max(level.width - viewportWidth, 0f))

                drawRect(Color(0xFF123C5A), size = size)
                drawCircle(Color(0xFFFFD166), radius = 55f, center = Offset(size.width - 90f, 85f))

                fun sy(value: Float): Float = value * scaleY
                level.platforms.forEach { platform ->
                    drawRoundRect(
                        color = Color(0xFF2E7D32),
                        topLeft = Offset(platform.x - cameraX, sy(platform.y)),
                        size = Size(platform.width, sy(platform.height))
                    )
                    drawRect(
                        color = Color(0xFF6D4C41),
                        topLeft = Offset(platform.x - cameraX, sy(platform.y + 18f)),
                        size = Size(platform.width, sy(platform.height - 18f))
                    )
                }

                level.hazards.forEach { hazard ->
                    val path = Path().apply {
                        moveTo(hazard.x - cameraX, sy(hazard.y + hazard.height))
                        lineTo(hazard.x + hazard.width / 2f - cameraX, sy(hazard.y))
                        lineTo(hazard.x + hazard.width - cameraX, sy(hazard.y + hazard.height))
                        close()
                    }
                    drawPath(path, Color(0xFFE53935))
                }

                level.enemies.forEachIndexed { index, enemy ->
                    val enemyX = enemy.x + sin(elapsedMs / 1000f * (1.2f + index * 0.1f)) * enemy.range
                    drawRoundRect(
                        color = Color(0xFF7B1FA2),
                        topLeft = Offset(enemyX - cameraX, sy(enemy.y)),
                        size = Size(48f, sy(52f)),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
                    )
                    drawCircle(Color.White, 5f, Offset(enemyX + 14f - cameraX, sy(enemy.y + 17f)))
                    drawCircle(Color.White, 5f, Offset(enemyX + 34f - cameraX, sy(enemy.y + 17f)))
                }

                level.crystals.forEachIndexed { index, crystal ->
                    if (index !in collected) {
                        val path = Path().apply {
                            moveTo(crystal.x - cameraX, sy(crystal.y - 23f))
                            lineTo(crystal.x + 18f - cameraX, sy(crystal.y))
                            lineTo(crystal.x - cameraX, sy(crystal.y + 23f))
                            lineTo(crystal.x - 18f - cameraX, sy(crystal.y))
                            close()
                        }
                        drawPath(path, Color(0xFF00E5FF))
                    }
                }

                drawRoundRect(
                    color = Gold,
                    topLeft = Offset(level.goalX - cameraX, sy(500f)),
                    size = Size(26f, sy(120f)),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
                )
                drawCircle(NeonGreen, 40f, Offset(level.goalX + 13f - cameraX, sy(485f)))

                drawRoundRect(
                    color = if (run.lifeType == "premium") Gold else Color(0xFFE53935),
                    topLeft = Offset(playerX - cameraX, sy(playerY)),
                    size = Size(playerWidth, sy(playerHeight)),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
                )
                drawCircle(Color.White, 5f, Offset(playerX + 14f - cameraX, sy(playerY + 18f)))
                drawCircle(Color.White, 5f, Offset(playerX + 33f - cameraX, sy(playerY + 18f)))
            }

            if (outcome != null) {
                Box(
                    Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.62f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Column(
                            Modifier.padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                if (outcome == GameOutcome.WON) "¡Nivel completado!" else "Fin de la partida",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text("Cristales: ${collected.size}/3 · Tiempo: ${elapsedSeconds}s")
                            if (run.needsActivation && !activated &&
                                elapsedSeconds < GeoGameRules.PREMIUM_ACTIVATION_SECONDS
                            ) {
                                Text("La vida amarilla será devuelta.", color = Gold)
                            }
                            resultError?.let { error ->
                                Text(error, color = Color(0xFFFFB4AB), textAlign = TextAlign.Center)
                            }
                            Button(
                                onClick = {
                                    if (resultSaved) onExit() else reportAttempt++
                                },
                                enabled = !reportingResult,
                                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                            ) {
                                when {
                                    reportingResult -> {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(20.dp),
                                            strokeWidth = 2.dp,
                                            color = DeepGreen
                                        )
                                        Text(" Guardando…")
                                    }
                                    resultSaved -> {
                                        Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                                        Text(" Volver a niveles")
                                    }
                                    else -> {
                                        Icon(Icons.Rounded.Refresh, contentDescription = null)
                                        Text(" Reintentar confirmación")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HoldButton(Icons.Rounded.ArrowBack, "Izquierda") { pressed ->
                    moveDirection = if (pressed) -1f else if (moveDirection < 0f) 0f else moveDirection
                }
                HoldButton(Icons.Rounded.ArrowForward, "Derecha") { pressed ->
                    moveDirection = if (pressed) 1f else if (moveDirection > 0f) 0f else moveDirection
                }
            }
            HoldButton(Icons.Rounded.PlayArrow, "Saltar", accent = Gold) { pressed ->
                if (pressed) jumpQueued = true
            }
        }
    }
}

private inline fun <T> Iterable<T>.anyIndexed(predicate: (Int, T) -> Boolean): Boolean {
    var index = 0
    for (item in this) {
        if (predicate(index, item)) return true
        index++
    }
    return false
}

@Composable
private fun HoldButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    accent: Color = NeonGreen,
    onPressed: (Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .background(accent.copy(alpha = 0.18f), CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        onPressed(true)
                        tryAwaitRelease()
                        onPressed(false)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = accent, modifier = Modifier.size(36.dp))
    }
}
