package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException
import java.util.UUID

private val Context.academicPlannerDataStore by preferencesDataStore(name = "gana_geo_academic_planner")

@Serializable
data class AcademicTask(
    val id: String,
    val title: String,
    val course: String,
    val dueDate: String,
    val completed: Boolean,
    val createdAt: Long
)

class AcademicPlannerStore(private val context: Context) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val tasks: Flow<List<AcademicTask>> = context.academicPlannerDataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { preferences ->
            decode(preferences[TASKS_KEY])
                .sortedWith(
                    compareBy<AcademicTask> { it.completed }
                        .thenBy { if (it.dueDate.isBlank()) "9999-99-99" else normalizedDate(it.dueDate) }
                        .thenByDescending { it.createdAt }
                )
        }

    suspend fun addTask(title: String, course: String, dueDate: String) {
        val cleanTitle = title.trim()
        val cleanCourse = course.trim()
        val cleanDate = dueDate.trim()
        require(cleanTitle.isNotBlank()) { "Escribe una tarea" }
        require(cleanTitle.length <= 300) { "La tarea es demasiado larga" }
        require(cleanCourse.length <= 120) { "El nombre del curso es demasiado largo" }
        require(cleanDate.length <= 20) { "La fecha es demasiado larga" }

        context.academicPlannerDataStore.edit { preferences ->
            val current = decode(preferences[TASKS_KEY]).toMutableList()
            require(current.size < MAX_TASKS) { "Puedes guardar hasta $MAX_TASKS tareas" }
            current += AcademicTask(
                id = UUID.randomUUID().toString(),
                title = cleanTitle,
                course = cleanCourse,
                dueDate = cleanDate,
                completed = false,
                createdAt = System.currentTimeMillis()
            )
            preferences[TASKS_KEY] = json.encodeToString(current)
        }
    }

    suspend fun toggleCompleted(id: String) {
        context.academicPlannerDataStore.edit { preferences ->
            preferences[TASKS_KEY] = json.encodeToString(
                decode(preferences[TASKS_KEY]).map { task ->
                    if (task.id == id) task.copy(completed = !task.completed) else task
                }
            )
        }
    }

    suspend fun deleteTask(id: String) {
        context.academicPlannerDataStore.edit { preferences ->
            preferences[TASKS_KEY] = json.encodeToString(
                decode(preferences[TASKS_KEY]).filterNot { it.id == id }
            )
        }
    }

    suspend fun clearCompleted() {
        context.academicPlannerDataStore.edit { preferences ->
            preferences[TASKS_KEY] = json.encodeToString(
                decode(preferences[TASKS_KEY]).filterNot { it.completed }
            )
        }
    }

    private fun decode(raw: String?): List<AcademicTask> = raw
        ?.let { runCatching { json.decodeFromString<List<AcademicTask>>(it) }.getOrNull() }
        .orEmpty()

    private fun normalizedDate(value: String): String {
        val parts = value.split('/', '-', '.').map(String::trim)
        if (parts.size != 3) return value
        val day = parts[0].toIntOrNull() ?: return value
        val month = parts[1].toIntOrNull() ?: return value
        val year = parts[2].toIntOrNull() ?: return value
        return "%04d-%02d-%02d".format(year, month, day)
    }

    private companion object {
        val TASKS_KEY = stringPreferencesKey("tasks_json")
        const val MAX_TASKS = 500
    }
}
