package com.ganageo.app.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.MultiFormatWriter
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.BitMatrix
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

object ToolFileUtils {
    private const val MAX_BITMAP_EDGE = 4096
    private const val MAX_OUTPUT_EDGE = 8192
    private const val MAX_OUTPUT_PIXELS = 32_000_000L
    const val MAX_IMAGES_PER_PDF = 100
    const val MAX_PDF_PAGES = 300

    suspend fun loadBitmap(
        context: Context,
        uri: Uri,
        maxEdge: Int = MAX_BITMAP_EDGE
    ): Bitmap = withContext(Dispatchers.IO) {
        require(maxEdge in 256..MAX_OUTPUT_EDGE) { "Tamaño de imagen no válido." }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val sourceMaxEdge = max(info.size.width, info.size.height)
                if (sourceMaxEdge > maxEdge) {
                    decoder.setTargetSampleSize(
                        ceil(sourceMaxEdge.toDouble() / maxEdge.toDouble()).toInt().coerceAtLeast(1)
                    )
                }
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            require(bounds.outWidth > 0 && bounds.outHeight > 0) { "No se pudo leer la imagen." }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxEdge) sample *= 2
            val options = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            } ?: error("No se pudo abrir la imagen.")
        }
    }

    fun createCameraImageUri(context: Context): Uri {
        val directory = File(context.cacheDir, "camera").apply { mkdirs() }
        val file = File(directory, "gana_geo_${System.currentTimeMillis()}.jpg").apply {
            if (!exists()) createNewFile()
        }
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun displayName(context: Context, uri: Uri): String {
        if (uri.scheme == "file") return uri.lastPathSegment ?: "archivo"
        return context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: uri.lastPathSegment ?: "archivo"
    }

    fun fileSize(context: Context, uri: Uri): Long {
        if (uri.scheme == "file") return runCatching { File(uri.path.orEmpty()).length() }.getOrDefault(0L)
        return context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.SIZE),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0) else 0L
        } ?: 0L
    }

    fun readableSize(bytes: Long): String = when {
        bytes <= 0L -> "Tamaño desconocido"
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> String.format("%.1f KB", bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
        else -> String.format("%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    }

    suspend fun writeBitmap(
        context: Context,
        bitmap: Bitmap,
        output: Uri,
        format: Bitmap.CompressFormat,
        quality: Int
    ) = withContext(Dispatchers.IO) {
        val writable = if (format == Bitmap.CompressFormat.JPEG && bitmap.hasAlpha()) {
            flattenOnWhite(bitmap)
        } else bitmap
        try {
            context.contentResolver.openOutputStream(output, "w")?.use { stream ->
                check(writable.compress(format, quality.coerceIn(1, 100), stream)) {
                    "No se pudo guardar la imagen."
                }
            } ?: error("No se pudo abrir el archivo de destino.")
        } finally {
            if (writable !== bitmap && !writable.isRecycled) writable.recycle()
        }
    }

    suspend fun createPdfFromImages(
        context: Context,
        imageUris: List<Uri>,
        output: Uri
    ) = createPdfFromImages(
        context = context,
        pages = imageUris.map(::PdfImagePage),
        output = output,
        options = ImagesToPdfOptions()
    )

    suspend fun createPdfFromImages(
        context: Context,
        pages: List<PdfImagePage>,
        output: Uri,
        options: ImagesToPdfOptions,
        onProgress: (completed: Int, total: Int) -> Unit = { _, _ -> }
    ) = withContext(Dispatchers.IO) {
        require(pages.isNotEmpty()) { "Selecciona al menos una imagen." }
        require(pages.size <= MAX_IMAGES_PER_PDF) {
            "Puedes combinar hasta $MAX_IMAGES_PER_PDF imágenes por PDF."
        }
        val password = options.password?.trim().orEmpty()
        if (password.isNotEmpty()) require(password.length >= 4) {
            "La contraseña debe tener por lo menos 4 caracteres."
        }

        val rawFile = File(context.cacheDir, "images_pdf_${UUID.randomUUID()}.pdf")
        val finalFile = if (password.isNotEmpty()) {
            File(context.cacheDir, "images_pdf_secure_${UUID.randomUUID()}.pdf")
        } else rawFile
        val document = PdfDocument()
        try {
            pages.forEachIndexed { index, pageModel ->
                var bitmap = loadBitmap(context, pageModel.uri, maxEdge = MAX_BITMAP_EDGE)
                try {
                    bitmap = replaceBitmap(bitmap, rotateFlip(bitmap, pageModel.rotationDegrees.toFloat(), false, false))
                    bitmap = replaceBitmap(
                        bitmap,
                        applyImageAdjustments(
                            bitmap,
                            filter = options.filter,
                            brightness = options.brightness,
                            contrast = options.contrast
                        )
                    )
                    bitmap = replaceBitmap(bitmap, scaleDown(bitmap, options.compression.maxImageEdge))

                    val (pageWidth, pageHeight) = resolvePageSize(bitmap, options)
                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                    val page = document.startPage(pageInfo)
                    val canvas = page.canvas
                    canvas.drawColor(Color.WHITE)
                    val margin = options.margin.points.toFloat()
                    val destination = if (options.fit == PdfImageFit.FILL) {
                        fillRect(
                            bitmap.width.toFloat(),
                            bitmap.height.toFloat(),
                            margin,
                            margin,
                            pageWidth - margin,
                            pageHeight - margin
                        )
                    } else {
                        fitRect(
                            bitmap.width.toFloat(),
                            bitmap.height.toFloat(),
                            margin,
                            margin,
                            pageWidth - margin,
                            pageHeight - margin
                        )
                    }
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    canvas.save()
                    canvas.clipRect(margin, margin, pageWidth - margin, pageHeight - margin)
                    canvas.drawBitmap(bitmap, null, destination, paint)
                    canvas.restore()
                    document.finishPage(page)
                } finally {
                    if (!bitmap.isRecycled) bitmap.recycle()
                }
                onProgress(index + 1, pages.size)
            }
            FileOutputStream(rawFile).use(document::writeTo)
            if (password.isNotEmpty()) {
                encryptPdf(context, rawFile, finalFile, password)
            }
            copyFileToUri(context, finalFile, output)
        } finally {
            document.close()
            rawFile.delete()
            if (finalFile !== rawFile) finalFile.delete()
        }
    }

    suspend fun renderPdfPage(
        context: Context,
        input: Uri,
        pageIndex: Int,
        maxWidth: Int = 900
    ): Bitmap = withContext(Dispatchers.IO) {
        val pfd = context.contentResolver.openFileDescriptor(input, "r")
            ?: error("No se pudo abrir el PDF.")
        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                require(renderer.pageCount > 0) { "El PDF no contiene páginas." }
                require(pageIndex in 0 until renderer.pageCount) { "La página indicada no existe." }
                renderer.openPage(pageIndex).use { page ->
                    var width = min(maxWidth, page.width * 2).coerceAtLeast(240)
                    var height = (width.toFloat() / page.width * page.height).roundToInt().coerceAtLeast(240)
                    val previewPixels = width.toLong() * height.toLong()
                    val maxPreviewPixels = 8_000_000L
                    if (previewPixels > maxPreviewPixels) {
                        val scale = sqrt(maxPreviewPixels.toDouble() / previewPixels.toDouble()).toFloat()
                        width = max(1, (width * scale).roundToInt())
                        height = max(1, (height * scale).roundToInt())
                    }
                    Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
                        eraseColor(Color.WHITE)
                        page.render(this, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    }
                }
            }
        }
    }

    suspend fun pdfPageCount(context: Context, uri: Uri): Int = withContext(Dispatchers.IO) {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: error("No se pudo abrir el PDF.")
        pfd.use { descriptor -> PdfRenderer(descriptor).use { it.pageCount } }
    }

    suspend fun pdfToImages(
        context: Context,
        input: Uri,
        outputTree: Uri,
        format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG,
        quality: Int = 92,
        selectedPages: List<Int> = emptyList(),
        maxWidth: Int = 1800,
        filePrefix: String = "pagina",
        onProgress: (completed: Int, total: Int) -> Unit = { _, _ -> }
    ): Int = withContext(Dispatchers.IO) {
        require(maxWidth in 600..3200) { "Resolución de salida no válida." }
        val folder = DocumentFile.fromTreeUri(context, outputTree)
            ?: error("No se pudo abrir la carpeta elegida.")
        val pfd = context.contentResolver.openFileDescriptor(input, "r")
            ?: error("No se pudo abrir el PDF.")
        var count = 0
        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                require(renderer.pageCount in 1..MAX_PDF_PAGES) {
                    "El PDF supera el límite de $MAX_PDF_PAGES páginas."
                }
                val pages = if (selectedPages.isEmpty()) {
                    (1..renderer.pageCount).toList()
                } else {
                    selectedPages.also { list ->
                        list.forEach { page ->
                            require(page in 1..renderer.pageCount) {
                                "La página $page no existe."
                            }
                        }
                    }
                }
                pages.forEachIndexed { listIndex, pageNumber ->
                    renderer.openPage(pageNumber - 1).use { page ->
                        val targetWidth = maxWidth
                        val targetHeight = (targetWidth.toFloat() / page.width * page.height)
                            .roundToInt()
                            .coerceAtLeast(1)
                        require(targetWidth.toLong() * targetHeight.toLong() <= MAX_OUTPUT_PIXELS) {
                            "La página $pageNumber supera el tamaño seguro de imagen."
                        }
                        val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
                        try {
                            bitmap.eraseColor(Color.WHITE)
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            val extension = if (format == Bitmap.CompressFormat.PNG) "png" else "jpg"
                            val mime = if (format == Bitmap.CompressFormat.PNG) "image/png" else "image/jpeg"
                            val safePrefix = filePrefix.trim().ifBlank { "pagina" }.replace(Regex("[^A-Za-z0-9_-]"), "_")
                            val file = folder.createFile(
                                mime,
                                "${safePrefix}_${pageNumber.toString().padStart(3, '0')}.$extension"
                            ) ?: error("No se pudo crear la imagen $pageNumber.")
                            context.contentResolver.openOutputStream(file.uri, "w")?.use { stream ->
                                check(bitmap.compress(format, quality.coerceIn(20, 100), stream))
                            } ?: error("No se pudo escribir la imagen $pageNumber.")
                        } finally {
                            bitmap.recycle()
                        }
                        count++
                        onProgress(listIndex + 1, pages.size)
                    }
                }
            }
        }
        count
    }

    suspend fun mergePdfs(context: Context, inputs: List<Uri>, output: Uri) = withContext(Dispatchers.IO) {
        require(inputs.size >= 2) { "Selecciona dos o más PDF." }
        require(inputs.size <= 20) { "Puedes unir hasta 20 PDF por operación." }
        initializePdfBox(context)
        val tempFiles = inputs.map { copyUriToTemp(context, it, ".pdf") }
        val destination = File(context.cacheDir, "merge_${UUID.randomUUID()}.pdf")
        try {
            val totalPages = tempFiles.sumOf { file ->
                PDDocument.load(file).use { it.numberOfPages }
            }
            require(totalPages in 1..MAX_PDF_PAGES) {
                "El resultado tendría $totalPages páginas. El límite es $MAX_PDF_PAGES."
            }
            PDFMergerUtility().apply {
                tempFiles.forEach(::addSource)
                destinationFileName = destination.absolutePath
                mergeDocuments(MemoryUsageSetting.setupTempFileOnly())
            }
            copyFileToUri(context, destination, output)
        } finally {
            tempFiles.forEach(File::delete)
            destination.delete()
        }
    }

    suspend fun organizePdf(
        context: Context,
        input: Uri,
        output: Uri,
        pageOrder: List<Int>,
        rotation: Int = 0,
        rotationPages: Set<Int> = emptySet()
    ) = withContext(Dispatchers.IO) {
        initializePdfBox(context)
        val sourceFile = copyUriToTemp(context, input, ".pdf")
        val targetFile = File(context.cacheDir, "organized_${UUID.randomUUID()}.pdf")
        try {
            PDDocument.load(sourceFile).use { source ->
                require(source.numberOfPages in 1..MAX_PDF_PAGES) {
                    "El PDF supera el límite de $MAX_PDF_PAGES páginas."
                }
                val indexes = if (pageOrder.isEmpty()) {
                    (0 until source.numberOfPages).toList()
                } else {
                    pageOrder.map { requested ->
                        require(requested in 1..source.numberOfPages) {
                            "La página $requested no existe. El PDF tiene ${source.numberOfPages} páginas."
                        }
                        requested - 1
                    }
                }
                PDDocument().use { target ->
                    indexes.forEach { sourceIndex ->
                        val imported = target.importPage(source.getPage(sourceIndex))
                        val sourcePageNumber = sourceIndex + 1
                        if (rotation != 0 && (rotationPages.isEmpty() || sourcePageNumber in rotationPages)) {
                            imported.rotation = ((imported.rotation + rotation) % 360 + 360) % 360
                        }
                    }
                    target.save(targetFile)
                }
            }
            copyFileToUri(context, targetFile, output)
        } finally {
            sourceFile.delete()
            targetFile.delete()
        }
    }

    suspend fun splitPdf(
        context: Context,
        input: Uri,
        outputTree: Uri,
        pageGroups: List<List<Int>>,
        baseName: String = "parte"
    ): Int = withContext(Dispatchers.IO) {
        require(pageGroups.isNotEmpty()) { "Escribe los rangos que deseas separar." }
        val folder = DocumentFile.fromTreeUri(context, outputTree)
            ?: error("No se pudo abrir la carpeta elegida.")
        initializePdfBox(context)
        val sourceFile = copyUriToTemp(context, input, ".pdf")
        try {
            PDDocument.load(sourceFile).use { source ->
                require(source.numberOfPages in 1..MAX_PDF_PAGES) {
                    "El PDF supera el límite de $MAX_PDF_PAGES páginas."
                }
                pageGroups.forEachIndexed { groupIndex, pages ->
                    PDDocument().use { target ->
                        pages.forEach { pageNumber ->
                            require(pageNumber in 1..source.numberOfPages) {
                                "La página $pageNumber no existe."
                            }
                            target.importPage(source.getPage(pageNumber - 1))
                        }
                        val temp = File(context.cacheDir, "split_${UUID.randomUUID()}.pdf")
                        try {
                            target.save(temp)
                            val safeName = baseName.trim().ifBlank { "parte" }
                                .replace(Regex("[^A-Za-z0-9_-]"), "_")
                            val file = folder.createFile(
                                "application/pdf",
                                "${safeName}_${(groupIndex + 1).toString().padStart(2, '0')}.pdf"
                            ) ?: error("No se pudo crear la parte ${groupIndex + 1}.")
                            copyFileToUri(context, temp, file.uri)
                        } finally {
                            temp.delete()
                        }
                    }
                }
            }
        } finally {
            sourceFile.delete()
        }
        pageGroups.size
    }

    suspend fun compressPdf(
        context: Context,
        input: Uri,
        output: Uri,
        maxRenderWidth: Int,
        onProgress: (completed: Int, total: Int) -> Unit = { _, _ -> }
    ) = withContext(Dispatchers.IO) {
        require(maxRenderWidth in 800..2600) { "Nivel de compresión no válido." }
        val pfd = context.contentResolver.openFileDescriptor(input, "r")
            ?: error("No se pudo abrir el PDF.")
        val temp = File(context.cacheDir, "compressed_${UUID.randomUUID()}.pdf")
        val result = PdfDocument()
        try {
            pfd.use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    require(renderer.pageCount in 1..MAX_PDF_PAGES) {
                        "El PDF supera el límite de $MAX_PDF_PAGES páginas."
                    }
                    for (index in 0 until renderer.pageCount) {
                        renderer.openPage(index).use { sourcePage ->
                            val renderWidth = maxRenderWidth
                            val renderHeight = (renderWidth.toFloat() / sourcePage.width * sourcePage.height)
                                .roundToInt()
                                .coerceAtLeast(1)
                            require(renderWidth.toLong() * renderHeight.toLong() <= MAX_OUTPUT_PIXELS) {
                                "La página ${index + 1} es demasiado grande."
                            }
                            val bitmap = Bitmap.createBitmap(renderWidth, renderHeight, Bitmap.Config.ARGB_8888)
                            try {
                                bitmap.eraseColor(Color.WHITE)
                                sourcePage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                                val pageInfo = PdfDocument.PageInfo.Builder(
                                    sourcePage.width.coerceAtLeast(1),
                                    sourcePage.height.coerceAtLeast(1),
                                    index + 1
                                ).create()
                                val page = result.startPage(pageInfo)
                                page.canvas.drawColor(Color.WHITE)
                                page.canvas.drawBitmap(
                                    bitmap,
                                    null,
                                    RectF(0f, 0f, sourcePage.width.toFloat(), sourcePage.height.toFloat()),
                                    Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                                )
                                result.finishPage(page)
                            } finally {
                                bitmap.recycle()
                            }
                            onProgress(index + 1, renderer.pageCount)
                        }
                    }
                }
            }
            FileOutputStream(temp).use(result::writeTo)
            copyFileToUri(context, temp, output)
        } finally {
            result.close()
            temp.delete()
        }
    }

    suspend fun signPdf(
        context: Context,
        input: Uri,
        output: Uri,
        signature: Bitmap,
        pageNumber: Int
    ) = signPdf(
        context,
        input,
        output,
        signature,
        pageNumber,
        SignaturePlacement()
    )

    suspend fun signPdf(
        context: Context,
        input: Uri,
        output: Uri,
        signature: Bitmap,
        pageNumber: Int,
        placement: SignaturePlacement
    ) = withContext(Dispatchers.IO) {
        initializePdfBox(context)
        val sourceFile = copyUriToTemp(context, input, ".pdf")
        val targetFile = File(context.cacheDir, "signed_${UUID.randomUUID()}.pdf")
        try {
            PDDocument.load(sourceFile).use { document ->
                require(document.numberOfPages in 1..MAX_PDF_PAGES) {
                    "El PDF supera el límite de $MAX_PDF_PAGES páginas."
                }
                require(pageNumber in 1..document.numberOfPages) { "La página indicada no existe." }
                val page = document.getPage(pageNumber - 1)
                val bytes = ByteArrayOutputStream().use { buffer ->
                    signature.compress(Bitmap.CompressFormat.PNG, 100, buffer)
                    buffer.toByteArray()
                }
                val image = PDImageXObject.createFromByteArray(document, bytes, "firma")
                val box = page.mediaBox
                val desiredWidth = (box.width * placement.widthPercent.coerceIn(10, 60) / 100f)
                    .coerceAtMost(box.width - 36f)
                val desiredHeight = desiredWidth * signature.height / signature.width.toFloat()
                val padding = 18f
                val availableX = max(0f, box.width - desiredWidth - padding * 2)
                val availableY = max(0f, box.height - desiredHeight - padding * 2)
                val x = box.lowerLeftX + padding + availableX * placement.position.xFraction
                val y = box.lowerLeftY + padding + availableY * placement.position.yFraction
                PDPageContentStream(
                    document,
                    page,
                    PDPageContentStream.AppendMode.APPEND,
                    true,
                    true
                ).use { stream ->
                    stream.drawImage(image, x, y, desiredWidth, desiredHeight)
                    if (placement.label.isNotBlank()) {
                        stream.beginText()
                        stream.setNonStrokingColor(40, 40, 40)
                        stream.setFont(com.tom_roush.pdfbox.pdmodel.font.PDType1Font.HELVETICA, 9f)
                        stream.newLineAtOffset(x, max(box.lowerLeftY + 6f, y - 12f))
                        stream.showText(placement.label.take(80).replace("\n", " ").replace(Regex("[^\u0020-\u007E]"), ""))
                        stream.endText()
                    }
                }
                document.save(targetFile)
            }
            copyFileToUri(context, targetFile, output)
        } finally {
            sourceFile.delete()
            targetFile.delete()
        }
    }

    fun resize(bitmap: Bitmap, width: Int, height: Int, keepAspect: Boolean): Bitmap {
        require(width > 0 && height > 0) { "Las dimensiones deben ser mayores que cero." }
        require(width <= MAX_OUTPUT_EDGE && height <= MAX_OUTPUT_EDGE) {
            "El ancho y el alto máximos son $MAX_OUTPUT_EDGE px."
        }
        val targetWidth: Int
        val targetHeight: Int
        if (keepAspect) {
            val scale = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
            targetWidth = max(1, (bitmap.width * scale).roundToInt())
            targetHeight = max(1, (bitmap.height * scale).roundToInt())
        } else {
            targetWidth = width
            targetHeight = height
        }
        require(targetWidth.toLong() * targetHeight.toLong() <= MAX_OUTPUT_PIXELS) {
            "La imagen resultante supera el límite seguro de 32 megapíxeles."
        }
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }

    fun resizeByPercent(bitmap: Bitmap, percent: Int): Bitmap {
        require(percent in 5..200) { "El porcentaje debe estar entre 5 y 200." }
        return resize(
            bitmap,
            max(1, bitmap.width * percent / 100),
            max(1, bitmap.height * percent / 100),
            keepAspect = false
        )
    }

    fun centerCrop(bitmap: Bitmap, ratioWidth: Int, ratioHeight: Int): Bitmap {
        require(ratioWidth > 0 && ratioHeight > 0)
        val targetRatio = ratioWidth.toFloat() / ratioHeight
        val currentRatio = bitmap.width.toFloat() / bitmap.height
        val cropWidth: Int
        val cropHeight: Int
        if (currentRatio > targetRatio) {
            cropHeight = bitmap.height
            cropWidth = (cropHeight * targetRatio).roundToInt()
        } else {
            cropWidth = bitmap.width
            cropHeight = (cropWidth / targetRatio).roundToInt()
        }
        val left = (bitmap.width - cropWidth) / 2
        val top = (bitmap.height - cropHeight) / 2
        return Bitmap.createBitmap(bitmap, left, top, cropWidth, cropHeight)
    }

    fun rotateFlip(bitmap: Bitmap, degrees: Float, flipHorizontal: Boolean, flipVertical: Boolean): Bitmap {
        val normalized = ((degrees % 360f) + 360f) % 360f
        if (normalized == 0f && !flipHorizontal && !flipVertical) return bitmap
        val matrix = Matrix().apply {
            postScale(if (flipHorizontal) -1f else 1f, if (flipVertical) -1f else 1f)
            postRotate(normalized)
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    fun applyImageAdjustments(
        bitmap: Bitmap,
        filter: DocumentImageFilter = DocumentImageFilter.ORIGINAL,
        brightness: Int = 0,
        contrast: Float = 1f
    ): Bitmap {
        val adjustedContrast = when (filter) {
            DocumentImageFilter.DOCUMENT -> max(1.28f, contrast)
            DocumentImageFilter.ENHANCE -> max(1.08f, contrast)
            else -> contrast
        }.coerceIn(0.5f, 1.8f)
        val adjustedBrightness = brightness.coerceIn(-80, 80)
        if (filter == DocumentImageFilter.ORIGINAL && adjustedBrightness == 0 && adjustedContrast == 1f) {
            return bitmap
        }
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val saturationMatrix = ColorMatrix().apply {
            setSaturation(
                when (filter) {
                    DocumentImageFilter.GRAYSCALE, DocumentImageFilter.DOCUMENT -> 0f
                    DocumentImageFilter.ENHANCE -> 1.18f
                    else -> 1f
                }
            )
        }
        val translate = (-0.5f * adjustedContrast + 0.5f) * 255f + adjustedBrightness
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                adjustedContrast, 0f, 0f, 0f, translate,
                0f, adjustedContrast, 0f, 0f, translate,
                0f, 0f, adjustedContrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        saturationMatrix.postConcat(contrastMatrix)
        Canvas(result).drawBitmap(
            bitmap,
            0f,
            0f,
            Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                colorFilter = ColorMatrixColorFilter(saturationMatrix)
            }
        )
        return result
    }

    fun addWatermark(
        bitmap: Bitmap,
        text: String,
        opacity: Int,
        textSizePercent: Int,
        position: String = "Abajo derecha",
        repeat: Boolean = false,
        darkText: Boolean = false
    ): Bitmap {
        require(text.isNotBlank()) { "Escribe el texto de la marca de agua." }
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)
        val size = max(18f, result.width * textSizePercent.coerceIn(2, 20) / 100f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (darkText) Color.BLACK else Color.WHITE
            alpha = (255 * opacity.coerceIn(5, 100) / 100f).roundToInt()
            textSize = size
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(3f, 1f, 1f, if (darkText) Color.WHITE else Color.BLACK)
        }
        if (repeat) {
            val stepX = max(paint.measureText(text) + size, result.width / 2f)
            val stepY = max(size * 3f, result.height / 4f)
            canvas.save()
            canvas.rotate(-25f, result.width / 2f, result.height / 2f)
            var y = -result.height.toFloat()
            while (y < result.height * 2f) {
                var x = -result.width.toFloat()
                while (x < result.width * 2f) {
                    canvas.drawText(text, x, y, paint)
                    x += stepX
                }
                y += stepY
            }
            canvas.restore()
        } else {
            val width = paint.measureText(text)
            val x = when {
                "izquierda" in position.lowercase() -> 24f
                "centro" in position.lowercase() -> (result.width - width) / 2f
                else -> max(24f, result.width - width - 24f)
            }
            val y = when {
                "arriba" in position.lowercase() -> size + 24f
                "centro" in position.lowercase() -> result.height / 2f
                else -> result.height - 24f
            }
            canvas.drawText(text, x, y, paint)
        }
        return result
    }

    fun generateQr(text: String, size: Int = 900): Bitmap {
        require(text.isNotBlank()) { "Escribe el contenido del QR." }
        val matrix: BitMatrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val pixels = IntArray(size * size)
        for (y in 0 until size) {
            val offset = y * size
            for (x in 0 until size) pixels[offset + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
        }
        return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, size, 0, 0, size, size)
        }
    }

    fun generateBarcode(text: String, format: BarcodeFormat, width: Int = 1200, height: Int = 420): Bitmap {
        require(text.isNotBlank()) { "Escribe el contenido del código." }
        require(format != BarcodeFormat.QR_CODE) { "Usa generateQr para códigos QR." }
        val safeWidth = width.coerceIn(400, 2400)
        val safeHeight = height.coerceIn(180, 1000)
        val matrix = MultiFormatWriter().encode(text.trim(), format, safeWidth, safeHeight)
        val pixels = IntArray(safeWidth * safeHeight)
        for (y in 0 until safeHeight) {
            val offset = y * safeWidth
            for (x in 0 until safeWidth) pixels[offset + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
        }
        return Bitmap.createBitmap(safeWidth, safeHeight, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, safeWidth, 0, 0, safeWidth, safeHeight)
        }
    }

    fun decodeQr(bitmap: Bitmap): String {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val source = RGBLuminanceSource(width, height, pixels)
        val result = MultiFormatReader().decode(BinaryBitmap(HybridBinarizer(source)))
        return result.text
    }

    private fun resolvePageSize(bitmap: Bitmap, options: ImagesToPdfOptions): Pair<Int, Int> {
        var width: Int
        var height: Int
        if (options.paperSize == PdfPaperSize.AUTOMATIC) {
            val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
            if (ratio >= 1f) {
                width = 842
                height = (width / ratio).roundToInt().coerceIn(320, 842)
            } else {
                height = 842
                width = (height * ratio).roundToInt().coerceIn(320, 842)
            }
        } else {
            width = options.paperSize.widthPoints
            height = options.paperSize.heightPoints
        }
        val landscape = when (options.orientation) {
            PdfOrientation.LANDSCAPE -> true
            PdfOrientation.PORTRAIT -> false
            PdfOrientation.AUTOMATIC -> bitmap.width > bitmap.height
        }
        if (landscape && width < height) {
            val temp = width
            width = height
            height = temp
        } else if (!landscape && width > height) {
            val temp = width
            width = height
            height = temp
        }
        return width to height
    }

    private fun scaleDown(bitmap: Bitmap, maxEdge: Int): Bitmap {
        val currentMax = max(bitmap.width, bitmap.height)
        if (currentMax <= maxEdge) return bitmap
        val scale = maxEdge.toFloat() / currentMax.toFloat()
        val width = max(1, (bitmap.width * scale).roundToInt())
        val height = max(1, (bitmap.height * scale).roundToInt())
        return Bitmap.createScaledBitmap(bitmap, width, height, true)
    }

    private fun replaceBitmap(current: Bitmap, next: Bitmap): Bitmap {
        if (next !== current && !current.isRecycled) current.recycle()
        return next
    }

    private fun flattenOnWhite(bitmap: Bitmap): Bitmap = Bitmap.createBitmap(
        bitmap.width,
        bitmap.height,
        Bitmap.Config.ARGB_8888
    ).also { output ->
        val canvas = Canvas(output)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(bitmap, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }

    private fun fitRect(
        sourceWidth: Float,
        sourceHeight: Float,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float
    ): RectF {
        val availableWidth = max(1f, right - left)
        val availableHeight = max(1f, bottom - top)
        val scale = min(availableWidth / sourceWidth, availableHeight / sourceHeight)
        val width = sourceWidth * scale
        val height = sourceHeight * scale
        val x = left + (availableWidth - width) / 2f
        val y = top + (availableHeight - height) / 2f
        return RectF(x, y, x + width, y + height)
    }

    private fun fillRect(
        sourceWidth: Float,
        sourceHeight: Float,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float
    ): RectF {
        val availableWidth = max(1f, right - left)
        val availableHeight = max(1f, bottom - top)
        val scale = max(availableWidth / sourceWidth, availableHeight / sourceHeight)
        val width = sourceWidth * scale
        val height = sourceHeight * scale
        val x = left + (availableWidth - width) / 2f
        val y = top + (availableHeight - height) / 2f
        return RectF(x, y, x + width, y + height)
    }

    private fun encryptPdf(context: Context, input: File, output: File, password: String) {
        initializePdfBox(context)
        PDDocument.load(input).use { document ->
            val accessPermission = AccessPermission().apply {
                setCanPrint(true)
                setCanExtractContent(false)
                setCanModify(false)
            }
            val policy = StandardProtectionPolicy(
                "${password}_GanaGeo_${UUID.randomUUID()}",
                password,
                accessPermission
            ).apply {
                setEncryptionKeyLength(128)
                setPermissions(accessPermission)
            }
            document.protect(policy)
            document.save(output)
        }
    }

    private fun initializePdfBox(context: Context) {
        PDFBoxResourceLoader.init(context.applicationContext)
    }

    private fun copyUriToTemp(context: Context, uri: Uri, suffix: String): File {
        val file = File(context.cacheDir, "tool_${UUID.randomUUID()}$suffix")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(file).use(input::copyTo)
        } ?: error("No se pudo leer el archivo.")
        return file
    }

    private fun copyFileToUri(context: Context, source: File, output: Uri) {
        context.contentResolver.openOutputStream(output, "w")?.use { destination ->
            source.inputStream().use { it.copyTo(destination) }
        } ?: error("No se pudo escribir el archivo de salida.")
    }
}
