package com.ganageo.app.ui.tools

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.ImagesToPdfOptions
import com.ganageo.app.tools.PageSelectionParser
import com.ganageo.app.tools.PdfCompression
import com.ganageo.app.tools.PdfImageFit
import com.ganageo.app.tools.PdfImagePage
import com.ganageo.app.tools.PdfMargin
import com.ganageo.app.tools.PdfOrientation
import com.ganageo.app.tools.PdfPaperSize
import com.ganageo.app.tools.SignaturePlacement
import com.ganageo.app.tools.SignaturePosition
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch

@Composable
fun ImagesToPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val pages = remember { mutableStateListOf<PdfImagePage>() }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var paperIndex by rememberSaveable { mutableStateOf(PdfPaperSize.A4.ordinal) }
    var orientationIndex by rememberSaveable { mutableStateOf(PdfOrientation.AUTOMATIC.ordinal) }
    var marginIndex by rememberSaveable { mutableStateOf(PdfMargin.NORMAL.ordinal) }
    var compressionIndex by rememberSaveable { mutableStateOf(PdfCompression.NORMAL.ordinal) }
    var fitIndex by rememberSaveable { mutableStateOf(PdfImageFit.CONTAIN.ordinal) }
    var filterIndex by rememberSaveable { mutableStateOf(DocumentImageFilter.ORIGINAL.ordinal) }
    var brightness by rememberSaveable { mutableStateOf(0f) }
    var contrast by rememberSaveable { mutableStateOf(1f) }
    var passwordEnabled by rememberSaveable { mutableStateOf(false) }
    var password by rememberSaveable { mutableStateOf("") }
    var outputName by rememberSaveable { mutableStateOf("documento_gana_geo.pdf") }
    var processing by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }

    val selectLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected ->
        val available = (ToolFileUtils.MAX_IMAGES_PER_PDF - pages.size).coerceAtLeast(0)
        pages.addAll(selected.take(available).map(::PdfImagePage))
        if (selected.size > available) onMessage("Solo se permiten ${ToolFileUtils.MAX_IMAGES_PER_PDF} imágenes por PDF.")
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val uri = pendingCameraUri
        if (success && uri != null && pages.size < ToolFileUtils.MAX_IMAGES_PER_PDF) pages.add(PdfImagePage(uri))
        pendingCameraUri = null
    }
    fun launchCameraCapture() {
        runCatching { ToolFileUtils.createCameraImageUri(context) }
            .onSuccess {
                pendingCameraUri = it
                cameraLauncher.launch(it)
            }
            .onFailure { onMessage(it.message ?: "No se pudo abrir la cámara.") }
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCameraCapture() else onMessage("Se necesita permiso de cámara para tomar una foto.")
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        if (output == null || pages.isEmpty()) return@rememberLauncherForActivityResult
        val options = ImagesToPdfOptions(
            paperSize = PdfPaperSize.entries[paperIndex],
            orientation = PdfOrientation.entries[orientationIndex],
            margin = PdfMargin.entries[marginIndex],
            compression = PdfCompression.entries[compressionIndex],
            fit = PdfImageFit.entries[fitIndex],
            filter = DocumentImageFilter.entries[filterIndex],
            brightness = brightness.toInt(),
            contrast = contrast,
            password = password.takeIf { passwordEnabled }
        )
        processing = true
        progress = 0f
        scope.launch {
            runPaidTool(viewModel, tool) {
                ToolFileUtils.createPdfFromImages(
                    context = context,
                    pages = pages.toList(),
                    output = output,
                    options = options,
                    onProgress = { completed, total ->
                        scope.launch { progress = completed.toFloat() / total.coerceAtLeast(1) }
                    }
                )
            }.onSuccess {
                onMessage(successMessage("PDF creado con ${pages.size} páginas.", it))
            }.onFailure {
                onMessage(it.message ?: "No se pudo crear el PDF.")
            }
            processing = false
        }
    }

    val totalInputBytes = pages.sumOf { ToolFileUtils.fileSize(context, it.uri) }

    ToolPage(tool, onBack) {
        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("1. Selecciona y ordena", style = MaterialTheme.typography.titleLarge)
                Text(
                    if (pages.isEmpty()) "Agrega fotografías o capturas." else "${pages.size} páginas · ${ToolFileUtils.readableSize(totalInputBytes)} en imágenes",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { selectLauncher.launch(arrayOf("image/*")) },
                        modifier = Modifier.weight(1f),
                        enabled = !processing
                    ) {
                        Icon(Icons.Rounded.Folder, contentDescription = null)
                        Text(" Galería")
                    }
                    OutlinedButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                launchCameraCapture()
                            } else {
                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        enabled = !processing
                    ) {
                        Icon(Icons.Rounded.AddAPhoto, contentDescription = null)
                        Text(" Cámara")
                    }
                }
            }
        }

        if (pages.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(pages, key = { index, page -> "${page.uri}-$index" }) { index, page ->
                    val moveUp: (() -> Unit)? = if (index > 0) {
                        {
                            val item = pages.removeAt(index)
                            pages.add(index - 1, item)
                        }
                    } else null
                    val moveDown: (() -> Unit)? = if (index < pages.lastIndex) {
                        {
                            val item = pages.removeAt(index)
                            pages.add(index + 1, item)
                        }
                    } else null
                    PdfImagePageCard(
                        page = page,
                        pageNumber = index + 1,
                        filter = DocumentImageFilter.entries[filterIndex],
                        brightness = brightness.toInt(),
                        contrast = contrast,
                        onMoveUp = moveUp,
                        onMoveDown = moveDown,
                        onRotate = {
                            pages[index] = page.copy(rotationDegrees = (page.rotationDegrees + 90) % 360)
                        },
                        onDelete = { pages.removeAt(index) }
                    )
                }
            }
            OutlinedButton(
                onClick = { pages.clear() },
                modifier = Modifier.fillMaxWidth(),
                enabled = !processing
            ) {
                Icon(Icons.Rounded.Delete, contentDescription = null)
                Text(" Quitar todas")
            }
        }

        SettingSection("2. Mejora de imagen") {
            SimpleDropdown(
                "Filtro",
                DocumentImageFilter.entries.map { it.label },
                filterIndex
            ) { filterIndex = it }
            Text("Brillo: ${brightness.toInt()}")
            Slider(value = brightness, onValueChange = { brightness = it }, valueRange = -50f..50f)
            Text("Contraste: ${String.format("%.2f", contrast)}")
            Slider(value = contrast, onValueChange = { contrast = it }, valueRange = 0.7f..1.5f)
            Text(
                "Los ajustes se aplican a todas las páginas. Cada página puede girarse por separado.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SettingSection("3. Página y calidad") {
            SimpleDropdown("Tamaño de papel", PdfPaperSize.entries.map { it.label }, paperIndex) { paperIndex = it }
            SimpleDropdown("Orientación", PdfOrientation.entries.map { it.label }, orientationIndex) { orientationIndex = it }
            SimpleDropdown("Márgenes", PdfMargin.entries.map { it.label }, marginIndex) { marginIndex = it }
            SimpleDropdown("Ajuste de imagen", PdfImageFit.entries.map { it.label }, fitIndex) { fitIndex = it }
            SimpleDropdown(
                "Compresión",
                PdfCompression.entries.map { "${it.label} · ${it.detail}" },
                compressionIndex
            ) { compressionIndex = it }
        }

        SettingSection("4. Nombre y seguridad") {
            OutlinedTextField(
                value = outputName,
                onValueChange = { value ->
                    outputName = value.replace(Regex("[\\/:*?\"<>|]"), "_").take(80)
                },
                label = { Text("Nombre del PDF") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = passwordEnabled, onCheckedChange = { passwordEnabled = it })
                Icon(Icons.Rounded.Lock, contentDescription = null, tint = Gold)
                Spacer(Modifier.width(7.dp))
                Text("Proteger con contraseña")
            }
            if (passwordEnabled) {
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it.take(40) },
                    label = { Text("Contraseña (mínimo 4 caracteres)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        }

        if (processing) {
            ProcessingCard("Creando PDF", progress)
        }

        Button(
            onClick = {
                if (passwordEnabled && password.length < 4) {
                    onMessage("La contraseña debe tener por lo menos 4 caracteres.")
                } else {
                    launchPaidExport(viewModel, tool, onMessage) {
                        val normalizedName = outputName.trim().ifBlank { "documento_gana_geo.pdf" }
                        saveLauncher.launch(if (normalizedName.endsWith(".pdf", true)) normalizedName else "$normalizedName.pdf")
                    }
                }
            },
            enabled = pages.isNotEmpty() && !processing,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null)
            Text(" Convertir a PDF · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
        }
        InfoToolText("El PDF se procesa dentro del teléfono. El archivo original y las imágenes no se modifican.")
    }
}

@Composable
fun PdfToImagesScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var pageCount by remember { mutableStateOf(0) }
    var formatIndex by rememberSaveable { mutableStateOf(0) }
    var pagesText by rememberSaveable { mutableStateOf("") }
    var quality by rememberSaveable { mutableStateOf(90f) }
    var resolutionIndex by rememberSaveable { mutableStateOf(1) }
    var prefix by rememberSaveable { mutableStateOf("pagina") }
    var processing by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    val formats = listOf("JPG", "PNG")
    val widths = listOf(1200, 1800, 2400)
    val resolutionLabels = listOf("Ligera · 1200 px", "Normal · 1800 px", "Alta · 2400 px")

    val inputLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        input = uri
        pageCount = 0
        if (uri != null) scope.launch {
            runCatching { ToolFileUtils.pdfPageCount(context, uri) }
                .onSuccess { pageCount = it }
                .onFailure { onMessage(it.message ?: "No se pudo abrir el PDF.") }
        }
    }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        val source = input
        if (tree == null || source == null) return@rememberLauncherForActivityResult
        val selected = runCatching { PageSelectionParser.parse(pagesText, pageCount.takeIf { it > 0 }) }
            .getOrElse {
                onMessage(it.message ?: "Revisa las páginas indicadas.")
                return@rememberLauncherForActivityResult
            }
        processing = true
        progress = 0f
        scope.launch {
            runPaidTool(viewModel, tool) {
                ToolFileUtils.pdfToImages(
                    context = context,
                    input = source,
                    outputTree = tree,
                    format = if (formats[formatIndex] == "PNG") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,
                    quality = quality.toInt(),
                    selectedPages = selected,
                    maxWidth = widths[resolutionIndex],
                    filePrefix = prefix,
                    onProgress = { completed, total ->
                        scope.launch { progress = completed.toFloat() / total.coerceAtLeast(1) }
                    }
                )
            }.onSuccess { onMessage(successMessage("Páginas exportadas en la carpeta seleccionada.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo convertir el PDF.") }
            processing = false
        }
    }

    ToolPage(tool, onBack) {
        FileSelectionCard(
            "PDF seleccionado",
            input?.let {
                "${ToolFileUtils.displayName(context, it)} · ${pageCount.takeIf { it > 0 } ?: "…"} páginas · ${ToolFileUtils.readableSize(ToolFileUtils.fileSize(context, it))}"
            } ?: "Selecciona un archivo PDF.",
            "Elegir PDF"
        ) { inputLauncher.launch(arrayOf("application/pdf")) }
        input?.let { PdfFirstPagePreview(it) }
        SettingSection("Opciones de exportación") {
            SimpleDropdown("Formato", formats, formatIndex) { formatIndex = it }
            SimpleDropdown("Resolución", resolutionLabels, resolutionIndex) { resolutionIndex = it }
            if (formatIndex == 0) {
                Text("Calidad JPG: ${quality.toInt()} %")
                Slider(value = quality, onValueChange = { quality = it }, valueRange = 45f..100f)
            }
            OutlinedTextField(
                value = pagesText,
                onValueChange = { pagesText = sanitizePageInput(it) },
                label = { Text("Páginas (vacío = todas)") },
                supportingText = { Text("Ejemplo: 1-3, 7, 10") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = prefix,
                onValueChange = { prefix = it.replace(Regex("[^A-Za-z0-9_-]"), "_").take(30) },
                label = { Text("Prefijo de archivos") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }
        if (processing) ProcessingCard("Exportando páginas", progress)
        Button(
            onClick = {
                runCatching { PageSelectionParser.parse(pagesText, pageCount.takeIf { it > 0 }) }
                    .onSuccess { launchPaidExport(viewModel, tool, onMessage) { folderLauncher.launch(null) } }
                    .onFailure { onMessage(it.message ?: "Revisa las páginas indicadas.") }
            },
            enabled = input != null && !processing,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null)
            Text(" Elegir carpeta y convertir · ${tool.creditCost} créditos")
        }
        InfoToolText("Cada página se guarda con su número original. El PDF no se modifica.")
    }
}

@Composable
fun PdfOrganizerScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val modes = listOf(
        "Unir PDF",
        "Reordenar o extraer",
        "Eliminar páginas",
        "Girar páginas",
        "Invertir orden",
        "Dividir en varios PDF",
        "Comprimir PDF"
    )
    var modeIndex by rememberSaveable { mutableStateOf(0) }
    val inputs = remember { mutableStateListOf<Uri>() }
    var pageCount by remember { mutableStateOf(0) }
    var pagesText by rememberSaveable { mutableStateOf("") }
    var rotationIndex by rememberSaveable { mutableStateOf(0) }
    var splitBaseName by rememberSaveable { mutableStateOf("parte") }
    var compressionIndex by rememberSaveable { mutableStateOf(1) }
    var processing by remember { mutableStateOf(false) }
    val compressionLabels = listOf("Máxima · archivo pequeño", "Media · recomendada", "Normal · más detalle", "Baja · calidad alta")
    val compressionWidths = listOf(900, 1300, 1800, 2400)

    fun updateSingle(uri: Uri?) {
        inputs.clear()
        pageCount = 0
        if (uri != null) {
            inputs.add(uri)
            scope.launch {
                runCatching { ToolFileUtils.pdfPageCount(context, uri) }
                    .onSuccess { pageCount = it }
                    .onFailure { onMessage(it.message ?: "No se pudo abrir el PDF.") }
            }
        }
    }

    val multiLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected ->
        inputs.clear()
        inputs.addAll(selected.take(20))
    }
    val singleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument(), ::updateSingle)
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        if (output == null || inputs.isEmpty()) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                when (modeIndex) {
                    0 -> ToolFileUtils.mergePdfs(context, inputs.toList(), output)
                    1 -> ToolFileUtils.organizePdf(
                        context,
                        inputs.first(),
                        output,
                        PageSelectionParser.parse(pagesText, pageCount)
                    )
                    2 -> {
                        val removed = PageSelectionParser.parse(pagesText, pageCount).toSet()
                        val remaining = (1..pageCount).filterNot(removed::contains)
                        require(remaining.isNotEmpty()) { "No puedes eliminar todas las páginas." }
                        ToolFileUtils.organizePdf(context, inputs.first(), output, remaining)
                    }
                    3 -> ToolFileUtils.organizePdf(
                        context = context,
                        input = inputs.first(),
                        output = output,
                        pageOrder = emptyList(),
                        rotation = listOf(90, 180, 270)[rotationIndex],
                        rotationPages = PageSelectionParser.parse(pagesText, pageCount).toSet()
                    )
                    4 -> ToolFileUtils.organizePdf(
                        context,
                        inputs.first(),
                        output,
                        (pageCount downTo 1).toList()
                    )
                    6 -> ToolFileUtils.compressPdf(
                        context,
                        inputs.first(),
                        output,
                        compressionWidths[compressionIndex]
                    )
                    else -> error("Operación de PDF no válida.")
                }
            }.onSuccess { onMessage(successMessage("PDF procesado correctamente.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar el PDF.") }
            processing = false
        }
    }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        val input = inputs.firstOrNull()
        if (tree == null || input == null) return@rememberLauncherForActivityResult
        val groups = runCatching { PageSelectionParser.parseGroups(pagesText, pageCount) }
            .getOrElse {
                onMessage(it.message ?: "Revisa los rangos.")
                return@rememberLauncherForActivityResult
            }
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                ToolFileUtils.splitPdf(context, input, tree, groups, splitBaseName)
            }.onSuccess { onMessage(successMessage("Se crearon ${groups.size} archivos PDF.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo dividir el PDF.") }
            processing = false
        }
    }

    ToolPage(tool, onBack) {
        SimpleDropdown("Operación", modes, modeIndex) {
            modeIndex = it
            inputs.clear()
            pageCount = 0
            pagesText = ""
        }
        FileSelectionCard(
            title = if (modeIndex == 0) "PDF seleccionados" else "PDF seleccionado",
            detail = when {
                inputs.isEmpty() -> "No hay archivos elegidos."
                modeIndex == 0 -> "${inputs.size} archivos · se unirán en el orden mostrado."
                else -> "${ToolFileUtils.displayName(context, inputs.first())} · ${pageCount.takeIf { it > 0 } ?: "…"} páginas"
            },
            button = if (modeIndex == 0) "Elegir varios PDF" else "Elegir PDF",
            onClick = {
                if (modeIndex == 0) multiLauncher.launch(arrayOf("application/pdf"))
                else singleLauncher.launch(arrayOf("application/pdf"))
            }
        )
        if (modeIndex == 0 && inputs.isNotEmpty()) {
            inputs.forEachIndexed { index, uri ->
                FileOrderRow(
                    name = ToolFileUtils.displayName(context, uri),
                    index = index,
                    total = inputs.size,
                    onUp = {
                        val item = inputs.removeAt(index)
                        inputs.add(index - 1, item)
                    },
                    onDown = {
                        val item = inputs.removeAt(index)
                        inputs.add(index + 1, item)
                    },
                    onDelete = { inputs.removeAt(index) }
                )
            }
        } else {
            inputs.firstOrNull()?.let { PdfFirstPagePreview(it) }
        }

        when (modeIndex) {
            1 -> PageListField(pagesText, { pagesText = it }, "Nuevo orden o páginas", "Ejemplo: 3,1,2,4 o 1-5,9")
            2 -> PageListField(pagesText, { pagesText = it }, "Páginas a eliminar", "Ejemplo: 2,5-7")
            3 -> {
                PageListField(pagesText, { pagesText = it }, "Páginas a girar", "Vacío = todas; ejemplo: 1,3-5")
                SimpleDropdown("Rotación", listOf("90°", "180°", "270°"), rotationIndex) { rotationIndex = it }
            }
            5 -> {
                PageListField(pagesText, { pagesText = it }, "Grupos separados por ;", "Ejemplo: 1-3; 4-6; 7-10")
                OutlinedTextField(
                    value = splitBaseName,
                    onValueChange = { splitBaseName = it.replace(Regex("[^A-Za-z0-9_-]"), "_").take(30) },
                    label = { Text("Nombre base") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            6 -> {
                SimpleDropdown("Nivel de compresión", compressionLabels, compressionIndex) { compressionIndex = it }
                Text(
                    "La compresión crea una copia más ligera rasterizando cada página. Puede reducir el detalle de fotografías o planos.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (processing) ProcessingCard("Procesando PDF", null)
        Button(
            onClick = {
                val validation = runCatching {
                    when (modeIndex) {
                        0 -> require(inputs.size >= 2) { "Selecciona dos o más PDF." }
                        1, 2 -> PageSelectionParser.parse(pagesText, pageCount).also { require(it.isNotEmpty()) { "Indica las páginas." } }
                        3 -> if (pagesText.isNotBlank()) PageSelectionParser.parse(pagesText, pageCount)
                        4 -> require(pageCount > 0) { "Espera a que se lea el documento." }
                        5 -> PageSelectionParser.parseGroups(pagesText, pageCount)
                        6 -> require(pageCount > 0) { "Espera a que se lea el documento." }
                        else -> error("Operación de PDF no válida.")
                    }
                }
                validation.onFailure {
                    onMessage(it.message ?: "Revisa los datos.")
                    return@Button
                }
                launchPaidExport(viewModel, tool, onMessage) {
                    if (modeIndex == 5) folderLauncher.launch(null)
                    else saveLauncher.launch(
                        when (modeIndex) {
                            0 -> "pdf_unido.pdf"
                            1 -> "pdf_reordenado.pdf"
                            2 -> "pdf_sin_paginas.pdf"
                            3 -> "pdf_girado.pdf"
                            4 -> "pdf_invertido.pdf"
                            else -> "pdf_comprimido.pdf"
                        }
                    )
                }
            },
            enabled = inputs.isNotEmpty() && !processing,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(if (modeIndex == 5) Icons.Rounded.Folder else Icons.Rounded.Save, contentDescription = null)
            Text(" ${if (modeIndex == 5) "Elegir carpeta" else "Guardar resultado"} · ${tool.creditCost} créditos")
        }
        InfoToolText("Nunca se reemplaza el original. Los PDF dañados o con contraseña pueden no abrirse.")
    }
}

@Composable
fun SignPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var pageCount by remember { mutableStateOf(0) }
    var pageText by rememberSaveable { mutableStateOf("1") }
    var positionIndex by rememberSaveable { mutableStateOf(SignaturePosition.BOTTOM_RIGHT.ordinal) }
    var sizePercent by rememberSaveable { mutableStateOf(28f) }
    var label by rememberSaveable { mutableStateOf("") }
    val strokes = remember { mutableStateListOf<SnapshotStateList<Offset>>() }
    var signaturePadSize by remember { mutableStateOf(IntSize.Zero) }
    var processing by remember { mutableStateOf(false) }

    val inputLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        input = uri
        pageCount = 0
        if (uri != null) scope.launch {
            runCatching { ToolFileUtils.pdfPageCount(context, uri) }
                .onSuccess { pageCount = it }
                .onFailure { onMessage(it.message ?: "No se pudo abrir el PDF.") }
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val source = input
        val page = pageText.toIntOrNull()
        if (output == null || source == null || page == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                val signature = signatureBitmap(strokes, signaturePadSize)
                try {
                    ToolFileUtils.signPdf(
                        context = context,
                        input = source,
                        output = output,
                        signature = signature,
                        pageNumber = page,
                        placement = SignaturePlacement(
                            position = SignaturePosition.entries[positionIndex],
                            widthPercent = sizePercent.toInt(),
                            label = label
                        )
                    )
                } finally {
                    if (!signature.isRecycled) signature.recycle()
                }
            }.onSuccess { onMessage(successMessage("Documento firmado y guardado.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo firmar el PDF.") }
            processing = false
        }
    }

    ToolPage(tool, onBack) {
        FileSelectionCard(
            "PDF seleccionado",
            input?.let { "${ToolFileUtils.displayName(context, it)} · ${pageCount.takeIf { it > 0 } ?: "…"} páginas" }
                ?: "Selecciona el documento que deseas firmar.",
            "Elegir PDF"
        ) { inputLauncher.launch(arrayOf("application/pdf")) }
        input?.let {
            val previewPage = ((pageText.toIntOrNull() ?: 1) - 1).coerceAtLeast(0)
            PdfPagePreview(it, previewPage)
        }
        SettingSection("Ubicación de la firma") {
            OutlinedTextField(
                value = pageText,
                onValueChange = { pageText = it.filter(Char::isDigit).take(4) },
                label = { Text("Página") },
                supportingText = { Text(if (pageCount > 0) "Entre 1 y $pageCount" else "Selecciona un PDF") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            SimpleDropdown("Posición", SignaturePosition.entries.map { it.label }, positionIndex) { positionIndex = it }
            Text("Tamaño: ${sizePercent.toInt()} % del ancho de página")
            Slider(value = sizePercent, onValueChange = { sizePercent = it }, valueRange = 12f..55f)
            OutlinedTextField(
                value = label,
                onValueChange = { label = it.take(80) },
                label = { Text("Texto debajo (opcional)") },
                placeholder = { Text("Nombre o fecha") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        Text("Dibuja tu firma", fontWeight = FontWeight.Bold)
        SignaturePad(strokes, onSizeChanged = { signaturePadSize = it })
        OutlinedButton(onClick = { strokes.clear() }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.Refresh, contentDescription = null)
            Text(" Limpiar firma")
        }
        if (processing) ProcessingCard("Firmando documento", null)
        Button(
            onClick = {
                val page = pageText.toIntOrNull()
                when {
                    page == null || page < 1 -> onMessage("Indica una página válida.")
                    pageCount > 0 && page > pageCount -> onMessage("El documento solo tiene $pageCount páginas.")
                    strokes.isEmpty() -> onMessage("Dibuja tu firma antes de continuar.")
                    else -> launchPaidExport(viewModel, tool, onMessage) { saveLauncher.launch("documento_firmado.pdf") }
                }
            },
            enabled = input != null && strokes.isNotEmpty() && !processing,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.Save, contentDescription = null)
            Text(" Firmar y guardar · ${tool.creditCost} créditos")
        }
        InfoToolText("La firma se coloca en una copia nueva. Revisa siempre el documento antes de compartirlo.")
    }
}

@Composable
private fun PdfImagePageCard(
    page: PdfImagePage,
    pageNumber: Int,
    filter: DocumentImageFilter,
    brightness: Int,
    contrast: Float,
    onMoveUp: (() -> Unit)?,
    onMoveDown: (() -> Unit)?,
    onRotate: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.width(170.dp)
    ) {
        Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            AdjustedUriImage(
                uri = page.uri,
                rotation = page.rotationDegrees,
                filter = filter,
                brightness = brightness,
                contrast = contrast,
                modifier = Modifier.fillMaxWidth().height(190.dp)
            )
            Text("Página $pageNumber", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                IconButton(onClick = { onMoveUp?.invoke() }, enabled = onMoveUp != null) {
                    Icon(Icons.Rounded.ArrowUpward, contentDescription = "Mover antes")
                }
                IconButton(onClick = { onMoveDown?.invoke() }, enabled = onMoveDown != null) {
                    Icon(Icons.Rounded.ArrowDownward, contentDescription = "Mover después")
                }
                IconButton(onClick = onRotate) {
                    Icon(Icons.Rounded.RotateRight, contentDescription = "Girar")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun AdjustedUriImage(
    uri: Uri,
    rotation: Int,
    filter: DocumentImageFilter,
    brightness: Int,
    contrast: Float,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var bitmap by remember(uri, rotation, filter, brightness, contrast) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(uri, rotation, filter, brightness, contrast) {
        runCatching {
            var current = ToolFileUtils.loadBitmap(context, uri, maxEdge = 650)
            val rotated = ToolFileUtils.rotateFlip(current, rotation.toFloat(), false, false)
            if (rotated !== current) {
                current.recycle()
                current = rotated
            }
            val adjusted = ToolFileUtils.applyImageAdjustments(current, filter, brightness, contrast)
            if (adjusted !== current) {
                current.recycle()
                current = adjusted
            }
            current
        }.onSuccess { newBitmap ->
            val old = bitmap
            bitmap = newBitmap
            if (old != null && old !== newBitmap && !old.isRecycled) old.recycle()
        }
    }
    DisposableEffect(Unit) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }
    Box(modifier.background(Color.Black.copy(alpha = 0.18f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
        bitmap?.let {
            Image(it.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        } ?: CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
    }
}

@Composable
private fun PdfFirstPagePreview(uri: Uri) = PdfPagePreview(uri, 0)

@Composable
private fun PdfPagePreview(uri: Uri, pageIndex: Int) {
    val context = LocalContext.current
    var bitmap by remember(uri, pageIndex) { mutableStateOf<Bitmap?>(null) }
    var error by remember(uri, pageIndex) { mutableStateOf<String?>(null) }
    LaunchedEffect(uri, pageIndex) {
        runCatching { ToolFileUtils.renderPdfPage(context, uri, pageIndex.coerceAtLeast(0), maxWidth = 750) }
            .onSuccess { newBitmap ->
                val old = bitmap
                bitmap = newBitmap
                error = null
                if (old != null && old !== newBitmap && !old.isRecycled) old.recycle()
            }
            .onFailure { error = it.message ?: "No se pudo mostrar la vista previa." }
    }
    DisposableEffect(Unit) { onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() } }
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Box(
            modifier = Modifier.fillMaxWidth().height(260.dp).padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            bitmap?.let {
                Image(it.asImageBitmap(), contentDescription = "Vista previa PDF", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            } ?: if (error != null) {
                Text(error.orEmpty(), color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            } else CircularProgressIndicator()
        }
    }
}

@Composable
private fun FileOrderRow(
    name: String,
    index: Int,
    total: Int,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onDelete: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${index + 1}", color = NeonGreen, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
            Text(name, modifier = Modifier.weight(1f), maxLines = 2)
            IconButton(onClick = onUp, enabled = index > 0) { Icon(Icons.Rounded.ArrowUpward, null) }
            IconButton(onClick = onDown, enabled = index < total - 1) { Icon(Icons.Rounded.ArrowDownward, null) }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun SignaturePad(
    strokes: SnapshotStateList<SnapshotStateList<Offset>>,
    onSizeChanged: (IntSize) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)
            .background(Color.White, RoundedCornerShape(16.dp))
            .onSizeChanged(onSizeChanged)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { point -> strokes.add(mutableStateListOf(point)) },
                    onDrag = { change, _ ->
                        change.consume()
                        strokes.lastOrNull()?.add(change.position)
                    }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            strokes.forEach { stroke ->
                if (stroke.size == 1) drawCircle(Color.Black, radius = 2.5f, center = stroke.first())
                else {
                    val path = Path().apply {
                        moveTo(stroke.first().x, stroke.first().y)
                        stroke.drop(1).forEach { lineTo(it.x, it.y) }
                    }
                    drawPath(path, Color.Black, style = Stroke(width = 5f, cap = StrokeCap.Round))
                }
            }
        }
    }
}

private fun signatureBitmap(strokes: List<List<Offset>>, padSize: IntSize): Bitmap {
    require(strokes.isNotEmpty()) { "Dibuja una firma antes de continuar." }
    require(padSize.width > 0 && padSize.height > 0) { "La firma todavía no está lista." }
    val bitmap = Bitmap.createBitmap(900, 300, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    canvas.drawColor(AndroidColor.TRANSPARENT)
    val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.BLACK
        strokeWidth = 8f
        style = AndroidPaint.Style.STROKE
        strokeCap = AndroidPaint.Cap.ROUND
        strokeJoin = AndroidPaint.Join.ROUND
    }
    val scaleX = 900f / padSize.width.toFloat()
    val scaleY = 300f / padSize.height.toFloat()
    strokes.forEach { stroke ->
        if (stroke.size >= 2) {
            val path = android.graphics.Path().apply {
                moveTo(stroke.first().x * scaleX, stroke.first().y * scaleY)
                stroke.drop(1).forEach { lineTo(it.x * scaleX, it.y * scaleY) }
            }
            canvas.drawPath(path, paint)
        }
    }
    return bitmap
}

@Composable
private fun ToolPage(tool: ToolId, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Costo por exportación: ${tool.creditCost} créditos", onBack)
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item { Column(verticalArrangement = Arrangement.spacedBy(14.dp)) { content() } }
        }
    }
}

@Composable
private fun SettingSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            content()
        }
    }
}

@Composable
private fun FileSelectionCard(title: String, detail: String, button: String, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Folder, contentDescription = null)
                Text(" $button")
            }
        }
    }
}

@Composable
private fun PageListField(value: String, onChange: (String) -> Unit, label: String, hint: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(sanitizePageInput(it)) },
        label = { Text(label) },
        supportingText = { Text(hint) },
        modifier = Modifier.fillMaxWidth()
    )
}

private fun sanitizePageInput(value: String): String =
    value.filter { ch -> ch.isDigit() || ch == ',' || ch == '-' || ch == ';' || ch.isWhitespace() }.take(400)

@Composable
private fun ProcessingCard(title: String, progress: Float?) {
    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.12f)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (progress == null) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            else {
                LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                Text("${(progress * 100).toInt()} %", color = NeonGreen)
            }
            Text("No cierres la aplicación hasta terminar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun InfoToolText(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
        Text(text, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
