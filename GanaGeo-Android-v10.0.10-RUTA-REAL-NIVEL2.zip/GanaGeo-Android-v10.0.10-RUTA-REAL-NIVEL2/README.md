# Gana Geo Android v10.0.10

Corrección puntual del tramo imposible del nivel 2 y refuerzo del modo pantalla completa. Consulta `CAMBIOS_V10_0_10_RUTA_REAL_NIVEL2.txt` y `VALIDACION_V10_0_10.txt`.

# Gana Geo Android v0.10.9 — Pantalla total y árbol pasable

Versión basada en v0.10.8. Mantiene intactos el inicio de sesión, Supabase, créditos, Geo Rewards, referidos, retiros y las herramientas ajenas a Geo Aventuras.

## Correcciones principales

- Se eliminaron los insets laterales de los tres contenedores Compose que envolvían Geo Aventuras.
- El juego vuelve a aplicar el modo inmersivo al recuperar el foco y dibuja bajo las barras y el recorte de pantalla.
- El fondo de la ventana durante el juego usa el mismo tono oscuro del escenario para evitar franjas blancas o verdes.
- El árbol del nivel 1 muestra un aviso corto antes de caer.
- El árbol solo mata durante la caída; cuando queda horizontal deja de ser letal.
- El tronco caído se convierte en una plataforma sólida y sirve para superar el fuego y continuar la ruta.
- La colisión mortal del árbol se redujo para ajustarse mejor a su forma visible.

## Validación

- 21 pruebas puras de reglas y niveles aprobadas.
- 20 niveles generados correctamente.
- Validación estática de pantalla inmersiva, plataforma del árbol y límite temporal de daño aprobada.
- Compilación Android pendiente de GitHub Actions porque el entorno local no dispone de Gradle 8.13 descargado.
