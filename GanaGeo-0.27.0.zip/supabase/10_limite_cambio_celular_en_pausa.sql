-- 10_limite_cambio_celular_en_pausa  (YA APLICADA en el servidor el 13/11/2026)
--
-- El límite de 3 cambios de celular por mes queda EN PAUSA mientras la app
-- está en pruebas: cada instalación nueva cuenta como "celular nuevo" y
-- bloqueaba al dueño con la pantalla "No se puede abrir aquí".
--
-- Cómo quedó:
--   · Nueva función public.device_change_limit() que devuelve 1000.
--   · link_my_device y replace_my_device comparan contra esa función
--     (antes tenían el 3 escrito adentro). Todo lo demás quedó igual.
--   · La app no puede llamar a device_change_limit() directamente.
--
-- PARA ACTIVAR EL LÍMITE AL LANZAR (una sola línea):
create or replace function public.device_change_limit()
returns int
language sql
stable
set search_path to ''
as $$ select 1000 $$;   -- cambiar 1000 por 3 al publicar en Google Play
