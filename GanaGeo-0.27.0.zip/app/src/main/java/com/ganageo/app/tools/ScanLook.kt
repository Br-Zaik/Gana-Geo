package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Cómo se ve un renglón en la foto: color del papel detrás, color de la letra y grosor del trazo. */
data class InkLook(val background: Int, val ink: Int, val stroke: Float)

/**
 * Lee de la foto el aspecto de cada renglón para que el texto editado se vea igual:
 * el papel se tapa con su mismo color y la letra nueva sale del color original.
 *
 * Trabaja sobre un arreglo de colores ARGB (sin Android) para poder probarlo.
 */
object ScanLook {
    private const val BLACK = -0x1000000
    private const val WHITE = -1

    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun dist(a: Int, b: Int) = abs(red(a) - red(b)) + abs(green(a) - green(b)) + abs(blue(a) - blue(b))
    private fun lum(c: Int) = (red(c) * 299 + green(c) * 587 + blue(c) * 114) / 1000
    private fun rgb(r: Int, g: Int, b: Int): Int =
        BLACK or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    /**
     * pixels: una zona de la foto (ancho x alto) que contiene el renglón con un margen alrededor.
     * El renglón ocupa [boxLeft, boxRight) x [boxTop, boxBottom) dentro de esa zona.
     */
    fun measure(
        pixels: IntArray,
        width: Int,
        height: Int,
        boxLeft: Int,
        boxTop: Int,
        boxRight: Int,
        boxBottom: Int
    ): InkLook {
        if (width <= 0 || height <= 0 || pixels.size < width * height) return InkLook(WHITE, BLACK, 0f)
        val left = boxLeft.coerceIn(0, width)
        val right = boxRight.coerceIn(left, width)
        val top = boxTop.coerceIn(0, height)
        val bottom = boxBottom.coerceIn(top, height)

        // ---- Papel: mediana del borde que rodea al renglón ----
        val histR = IntArray(256)
        val histG = IntArray(256)
        val histB = IntArray(256)
        var ring = 0
        for (y in 0 until height) {
            val inside = y >= top && y < bottom
            for (x in 0 until width) {
                if (inside && x >= left && x < right) continue
                val c = pixels[y * width + x]
                histR[red(c)]++
                histG[green(c)]++
                histB[blue(c)]++
                ring++
            }
        }
        if (ring < 8) {
            // Sin borde (renglón pegado a la orilla): se usa la propia caja.
            java.util.Arrays.fill(histR, 0)
            java.util.Arrays.fill(histG, 0)
            java.util.Arrays.fill(histB, 0)
            ring = 0
            for (y in top until bottom) for (x in left until right) {
                val c = pixels[y * width + x]
                histR[red(c)]++
                histG[green(c)]++
                histB[blue(c)]++
                ring++
            }
        }
        val background = if (ring == 0) WHITE else rgb(median(histR, ring), median(histG, ring), median(histB, ring))

        if (right - left < 2 || bottom - top < 2) return InkLook(background, contrastInk(background), 0f)

        // ---- Letra: lo que más se aleja del papel dentro del renglón ----
        var maxDistance = 0
        for (y in top until bottom) for (x in left until right) {
            val d = dist(pixels[y * width + x], background)
            if (d > maxDistance) maxDistance = d
        }
        if (maxDistance < 80) return InkLook(background, contrastInk(background), 0f)

        // Solo el centro del trazo: los bordes suavizados aclaran el color.
        val inkThreshold = max(80, maxDistance * 7 / 10)
        var sumR = 0L
        var sumG = 0L
        var sumB = 0L
        var count = 0
        for (y in top until bottom) for (x in left until right) {
            val c = pixels[y * width + x]
            if (dist(c, background) >= inkThreshold) {
                sumR += red(c)
                sumG += green(c)
                sumB += blue(c)
                count++
            }
        }
        val ink = if (count == 0) {
            contrastInk(background)
        } else {
            rgb((sumR / count).toInt(), (sumG / count).toInt(), (sumB / count).toInt())
        }

        // ---- Grosor: largo medio de los tramos de tinta en cada fila ----
        val strokeThreshold = max(60, maxDistance * 45 / 100)
        val maxRun = max(2, (bottom - top) * 35 / 100)
        var runTotal = 0L
        var runCount = 0
        for (y in top until bottom) {
            var run = 0
            for (x in left until right) {
                if (dist(pixels[y * width + x], background) >= strokeThreshold) {
                    run++
                } else if (run > 0) {
                    if (run <= maxRun) {
                        runTotal += run
                        runCount++
                    }
                    run = 0
                }
            }
            if (run in 1..maxRun) {
                runTotal += run
                runCount++
            }
        }
        val stroke = if (runCount < 6) 0f else runTotal.toFloat() / runCount
        return InkLook(background, ink, stroke)
    }

    /**
     * Negrita: el trazo es claramente más grueso que el del resto de la hoja,
     * medido contra el alto del renglón (un título grande no cuenta como negrita).
     */
    fun boldFlags(strokes: FloatArray, heights: FloatArray): BooleanArray {
        val count = min(strokes.size, heights.size)
        val result = BooleanArray(count)
        val ratios = FloatArray(count)
        val measured = ArrayList<Float>()
        val measuredHeights = ArrayList<Float>()
        for (index in 0 until count) {
            if (strokes[index] <= 0f || heights[index] < 12f) continue
            ratios[index] = strokes[index] / heights[index]
            measured += ratios[index]
            measuredHeights += heights[index]
        }
        if (measured.size < 3) return result
        val typical = medianOf(measured)
        val typicalHeight = medianOf(measuredHeights)
        if (typical <= 0f) return result
        for (index in 0 until count) {
            if (ratios[index] >= typical * 1.3f && heights[index] >= typicalHeight * 0.85f) result[index] = true
        }
        return result
    }

    private fun contrastInk(background: Int): Int = if (lum(background) > 140) BLACK else WHITE

    private fun median(histogram: IntArray, total: Int): Int {
        val half = total / 2
        var seen = 0
        for (value in 0..255) {
            seen += histogram[value]
            if (seen > half) return value
        }
        return 255
    }

    private fun medianOf(values: List<Float>): Float {
        val sorted = values.sorted()
        return sorted[sorted.size / 2]
    }
}
