package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Una línea leída por el OCR con su posición en la foto (en píxeles). */
data class OcrLine(
    val text: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val width: Int get() = max(1, right - left)
    val height: Int get() = max(1, bottom - top)
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
}

/**
 * Ordena y limpia el texto que devuelve el OCR. Todo es geometría y reglas simples:
 * no usa internet ni modelos extra.
 *
 *  - Orden de lectura: de arriba abajo; si la hoja tiene dos columnas de texto,
 *    primero la izquierda y luego la derecha.
 *  - Une los renglones que son la misma oración (títulos de dos líneas, párrafos).
 *  - Corrige las confusiones típicas entre letras y números (GEODESIC0 → GEODESICO).
 *
 * No agrega tildes ni cambia palabras: el documento se respeta tal como está escrito.
 */
object OcrTextRefiner {

    // ------------------------------------------------------------------
    // Orden de lectura
    // ------------------------------------------------------------------

    fun order(lines: List<OcrLine>, pageWidth: Int): List<OcrLine> {
        if (lines.size < 2) return lines
        val rows = sortByRows(lines)
        val gutter = findColumnGutter(rows, pageWidth) ?: return rows

        val result = ArrayList<OcrLine>(rows.size)
        val leftColumn = ArrayList<OcrLine>()
        val rightColumn = ArrayList<OcrLine>()
        fun flush() {
            result.addAll(leftColumn)
            result.addAll(rightColumn)
            leftColumn.clear()
            rightColumn.clear()
        }
        for (line in rows) {
            when {
                line.left < gutter && line.right > gutter -> {
                    // Título o línea que cruza las dos columnas: corta el bloque.
                    flush()
                    result.add(line)
                }
                line.right <= gutter -> leftColumn.add(line)
                else -> rightColumn.add(line)
            }
        }
        flush()
        return result
    }

    /** De arriba abajo; lo que está en el mismo renglón, de izquierda a derecha. */
    private fun sortByRows(lines: List<OcrLine>): List<OcrLine> {
        val byTop = lines.sortedBy { it.centerY }
        val result = ArrayList<OcrLine>(lines.size)
        val row = ArrayList<OcrLine>()
        var rowTop = 0
        var rowBottom = 0
        fun flushRow() {
            row.sortBy { it.left }
            result.addAll(row)
            row.clear()
        }
        for (line in byTop) {
            if (row.isEmpty()) {
                row.add(line)
                rowTop = line.top
                rowBottom = line.bottom
                continue
            }
            val overlap = min(rowBottom, line.bottom) - max(rowTop, line.top)
            val smaller = min(rowBottom - rowTop, line.height).coerceAtLeast(1)
            if (overlap >= smaller * 0.5f) {
                row.add(line)
            } else {
                flushRow()
                row.add(line)
                rowTop = line.top
                rowBottom = line.bottom
            }
        }
        flushRow()
        return result
    }

    /**
     * Busca la franja vacía entre dos columnas de texto. Devuelve su posición x,
     * o null si la hoja es de una sola columna (o es un formulario/tabla, que se
     * lee por filas).
     */
    private fun findColumnGutter(lines: List<OcrLine>, pageWidth: Int): Int? {
        if (pageWidth <= 0 || lines.size < 8) return null
        var bestX = -1
        var bestCrossing = Int.MAX_VALUE
        val step = max(1, pageWidth / 100)
        var x = (pageWidth * 0.30f).toInt()
        val end = (pageWidth * 0.70f).toInt()
        while (x <= end) {
            var crossing = 0
            var leftCount = 0
            var rightCount = 0
            for (line in lines) {
                when {
                    line.left < x && line.right > x -> crossing++
                    line.right <= x -> leftCount++
                    else -> rightCount++
                }
            }
            if (leftCount >= 4 && rightCount >= 4 && crossing < bestCrossing) {
                bestCrossing = crossing
                bestX = x
            }
            x += step
        }
        if (bestX < 0 || bestCrossing > lines.size * 0.25f) return null

        val leftSide = lines.filter { it.right <= bestX }
        val rightSide = lines.filter { it.left >= bestX }
        if (leftSide.size < 4 || rightSide.size < 4) return null

        // Columnas de verdad: los renglones llenan casi todo el ancho de su columna.
        // En un formulario o una tabla los textos son cortos y se leen por filas.
        val leftColumnWidth = (bestX - leftSide.minOf { it.left }).coerceAtLeast(1)
        val rightColumnWidth = (rightSide.maxOf { it.right } - bestX).coerceAtLeast(1)
        val leftFill = median(leftSide.map { it.width.toFloat() }) / leftColumnWidth
        val rightFill = median(rightSide.map { it.width.toFloat() }) / rightColumnWidth
        if (leftFill < 0.6f || rightFill < 0.6f) return null

        // Las dos columnas deben estar una al lado de la otra, no una debajo de otra.
        val overlapTop = max(leftSide.minOf { it.top }, rightSide.minOf { it.top })
        val overlapBottom = min(leftSide.maxOf { it.bottom }, rightSide.maxOf { it.bottom })
        val shorter = min(
            leftSide.maxOf { it.bottom } - leftSide.minOf { it.top },
            rightSide.maxOf { it.bottom } - rightSide.minOf { it.top }
        ).coerceAtLeast(1)
        if (overlapBottom - overlapTop < shorter * 0.5f) return null
        return bestX
    }

    // ------------------------------------------------------------------
    // Texto final con párrafos
    // ------------------------------------------------------------------

    fun buildText(lines: List<OcrLine>, pageWidth: Int): String {
        val clean = lines.mapNotNull { line ->
            val fixed = fixLine(line.text)
            if (fixed.isBlank()) null else line.copy(text = fixed)
        }
        if (clean.isEmpty()) return ""
        val ordered = order(clean, pageWidth)
        val width = if (pageWidth > 0) pageWidth else ordered.maxOf { it.right }.coerceAtLeast(1)
        val medianHeight = median(ordered.map { it.height.toFloat() })
        val pageLeft = ordered.minOf { it.left }

        val builder = StringBuilder(ordered.first().text)
        for (index in 1 until ordered.size) {
            val previous = ordered[index - 1]
            val line = ordered[index]
            val gap = line.top - previous.bottom
            val smallerHeight = min(previous.height, line.height)
            val verticalOverlap = min(previous.bottom, line.bottom) - max(previous.top, line.top)
            val sameRow = verticalOverlap >= smallerHeight * 0.5f && line.left >= previous.left

            when {
                sameRow -> builder.append("  ").append(line.text)
                continuesSentence(previous, line, ordered, width, pageLeft) -> {
                    val endsWithHyphen = builder.isNotEmpty() && builder.last() == '-' &&
                        builder.length >= 2 && builder[builder.length - 2].isLetter() &&
                        line.text.first().isLowerCase()
                    if (endsWithHyphen) {
                        builder.setLength(builder.length - 1)
                    } else {
                        builder.append(' ')
                    }
                    builder.append(line.text)
                }
                gap > medianHeight * 0.9f || line.top < previous.top -> builder.append("\n\n").append(line.text)
                else -> builder.append('\n').append(line.text)
            }
        }
        return builder.toString().trim()
    }

    /** ¿El renglón de abajo es la continuación del de arriba? */
    private fun continuesSentence(
        previous: OcrLine,
        line: OcrLine,
        all: List<OcrLine>,
        pageWidth: Int,
        pageLeft: Int
    ): Boolean {
        val gap = line.top - previous.bottom
        val smallerHeight = min(previous.height, line.height)
        if (gap < -smallerHeight * 0.5f || gap > smallerHeight * 0.75f) return false
        val ratio = previous.height.toFloat() / line.height.toFloat()
        if (ratio < 0.72f || ratio > 1.38f) return false
        val horizontalOverlap = min(previous.right, line.right) - max(previous.left, line.left)
        if (horizontalOverlap <= 0) return false
        if (startsWithListMarker(line.text)) return false

        // Título centrado en dos líneas.
        val centered = abs(previous.centerX - line.centerX) < pageWidth * 0.03f &&
            previous.left > pageLeft + pageWidth * 0.05f &&
            line.left > pageLeft + pageWidth * 0.05f
        if (centered) return true

        // Párrafo: el renglón de arriba llega hasta el borde derecho de su bloque.
        val blockRight = all.asSequence()
            .filter { other ->
                abs(other.centerY - previous.centerY) < previous.height * 4f &&
                    min(other.right, previous.right) - max(other.left, previous.left) > 0
            }
            .maxOf { it.right }
        val reachesRight = previous.right >= blockRight - pageWidth * 0.07f
        val alignedLeft = line.left <= previous.left + pageWidth * 0.08f
        return reachesRight && alignedLeft
    }

    // ------------------------------------------------------------------
    // Párrafos (para el editor)
    // ------------------------------------------------------------------

    const val ALIGN_LEFT = 0
    const val ALIGN_CENTER = 1
    const val ALIGN_RIGHT = 2
    const val ALIGN_JUSTIFY = 3

    /**
     * Agrupa los renglones en párrafos, en orden de lectura. Cada grupo trae los
     * índices de la lista original. Dos renglones van juntos si uno continúa al
     * otro y además tienen el mismo estilo (color, negrita, tamaño parecido).
     */
    fun paragraphs(
        lines: List<OcrLine>,
        pageWidth: Int,
        sameStyle: (Int, Int) -> Boolean
    ): List<IntArray> {
        if (lines.isEmpty()) return emptyList()
        val indexOf = java.util.IdentityHashMap<OcrLine, Int>()
        lines.forEachIndexed { index, line -> indexOf[line] = index }
        val ordered = order(lines, pageWidth)
        val width = if (pageWidth > 0) pageWidth else ordered.maxOf { it.right }.coerceAtLeast(1)
        val pageLeft = ordered.minOf { it.left }

        val groups = ArrayList<IntArray>()
        var current = ArrayList<Int>()
        for (position in ordered.indices) {
            val line = ordered[position]
            val index = indexOf[line] ?: continue
            if (current.isEmpty()) {
                current.add(index)
                continue
            }
            val previous = ordered[position - 1]
            val previousIndex = indexOf[previous] ?: -1
            val joins = previousIndex >= 0 &&
                continuesSentence(previous, line, ordered, width, pageLeft) &&
                sameStyle(previousIndex, index)
            if (joins) {
                current.add(index)
            } else {
                groups.add(current.toIntArray())
                current = ArrayList()
                current.add(index)
            }
        }
        if (current.isNotEmpty()) groups.add(current.toIntArray())
        return groups
    }

    /** Cómo está alineado un párrafo, mirando los bordes de sus renglones. */
    fun alignmentOf(group: List<OcrLine>, pageWidth: Int): Int {
        if (group.size < 2) return ALIGN_LEFT
        val tolerance = max(2f, pageWidth * 0.015f)
        fun spread(values: List<Float>): Float = values.maxOf { it } - values.minOf { it }
        val leftAligned = spread(group.map { it.left.toFloat() }) <= tolerance
        val rightAligned = spread(group.map { it.right.toFloat() }) <= tolerance
        val centerAligned = spread(group.map { it.centerX }) <= tolerance
        val body = group.dropLast(1)
        val bodyRightAligned = spread(body.map { it.right.toFloat() }) <= tolerance
        val lastFits = group.last().right <= body.maxOf { it.right } + tolerance
        return when {
            leftAligned && group.size >= 3 && bodyRightAligned && lastFits -> ALIGN_JUSTIFY
            leftAligned -> ALIGN_LEFT
            centerAligned -> ALIGN_CENTER
            rightAligned -> ALIGN_RIGHT
            else -> ALIGN_LEFT
        }
    }

    private val listMarker = Regex("^(\\d{1,3}\\s?[.)\\-°º]|[a-zA-Z]\\s?[.)]\\s|[•●▪■◦○\\-–—*✓➤►]\\s)")

    private fun startsWithListMarker(text: String): Boolean = listMarker.containsMatchIn(text)

    // ------------------------------------------------------------------
    // Limpieza de cada renglón
    // ------------------------------------------------------------------

    private val manySpaces = Regex("\\s+")
    private val spaceBeforePunctuation = Regex("\\s+([,.;:?!)\\]])")
    private val spaceAfterOpening = Regex("([¿¡(\\[])\\s+")

    fun fixLine(raw: String): String {
        var text = raw.replace('\n', ' ').replace(manySpaces, " ").trim()
        if (text.isEmpty()) return text
        // Rayas sueltas que el OCR inventa en los bordes de la hoja.
        while (text.startsWith("| ") || text.startsWith("|")) text = text.removePrefix("|").trimStart()
        while (text.endsWith(" |")) text = text.removeSuffix("|").trimEnd()
        text = text.split(' ').joinToString(" ") { fixToken(it) }
        text = text.replace(spaceBeforePunctuation, "$1")
        text = text.replace(spaceAfterOpening, "$1")
        return text.trim()
    }

    /** Corrige 0/O y 1/l/I dentro de una palabra o de un número. */
    internal fun fixToken(token: String): String {
        if (token.length < 3) return token
        var first = 0
        var last = token.length - 1
        while (first <= last && !token[first].isLetterOrDigit()) first++
        while (last >= first && !token[last].isLetterOrDigit()) last--
        if (last - first + 1 < 3) return token
        val core = token.substring(first, last + 1)
        if (!core.all { it.isLetterOrDigit() }) return token

        val letters = core.count { it.isLetter() }
        val digits = core.length - letters
        if (letters == 0 || digits == 0) return token

        val fixed = when {
            // Palabra con un cero o un uno colado: GEODESIC0, TOP0GRAFIA, n1vel.
            letters >= 4 && digits <= 2 && core.all { it.isLetter() || it == '0' || it == '1' } ->
                fixDigitsInsideWord(core)
            // Número con una letra colada: 1O5, 2O24, 4l0.
            digits >= 2 && core.all { it.isDigit() || it == 'O' || it == 'o' || it == 'l' || it == 'I' } ->
                fixLettersInsideNumber(core)
            else -> core
        }
        if (fixed == core) return token
        return token.substring(0, first) + fixed + token.substring(last + 1)
    }

    private fun fixDigitsInsideWord(core: String): String {
        val chars = core.toCharArray()
        for (index in chars.indices) {
            val current = chars[index]
            if (current != '0' && current != '1') continue
            val before = if (index > 0) core[index - 1] else null
            val after = if (index < core.length - 1) core[index + 1] else null
            // Dos números juntos son un número de verdad (Windows10): no se toca.
            if ((before != null && before.isDigit()) || (after != null && after.isDigit())) return core
            val neighbor = before ?: after ?: return core
            val upper = neighbor.isUpperCase() && (after == null || !after.isLowerCase())
            when (current) {
                '0' -> {
                    // Al inicio no se toca (0km). En medio o al final, es una O.
                    if (before == null) return core
                    chars[index] = if (upper) 'O' else 'o'
                }
                '1' -> {
                    // Solo en medio de la palabra: "Grupo1" o "Anexo1" se respetan.
                    if (before == null || after == null) return core
                    chars[index] = if (upper) 'I' else 'l'
                }
            }
        }
        return String(chars)
    }

    private fun fixLettersInsideNumber(core: String): String {
        val chars = core.toCharArray()
        for (index in chars.indices) {
            when (chars[index]) {
                'O', 'o' -> chars[index] = '0'
                // Solo entre números: al inicio puede ser un código (I10) y al final
                // una unidad (10l = 10 litros). Esos se respetan.
                'l', 'I' -> if (index > 0 && index < chars.size - 1) chars[index] = '1'
            }
        }
        return String(chars)
    }

    private fun median(values: List<Float>): Float {
        if (values.isEmpty()) return 0f
        val sorted = values.sorted()
        return sorted[sorted.size / 2]
    }
}
