package com.ganageo.app.ui.tools

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.RectF
import android.net.Uri
import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DocumentScanner
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Redo
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.NeonGreen
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Colores propios del escáner.
private val DocScanBackground = Color(0xFF0B1410)
private val DocScanBar = Color(0xFF101D16)
private val DocScanChipIdle = Color(0xFF1A2B22)
private val DocScanChipOn = Color(0xFF2A4A1A)
private val DocScanInk = Color(0xFFE6EFE9)
private val DocScanMuted = Color(0xFF8FA398)
private val DocScanFocus = Color(0xFF3D8BFF)
private val DocScanDanger = Color(0xFFFF8A80)
private const val DocScanSignatureInk = 0xFF10233F.toInt()

private const val DOC_SCAN_FORMAT_PDF = 0
private const val DOC_SCAN_FORMAT_WORD = 1
private const val DOC_SCAN_FORMAT_IMAGE = 2
private const val DOC_SCAN_UNDO_LIMIT = 60
private const val DOC_SCAN_TYPING_PAUSE_MS = 1500L

private val DocScanPalette = listOf(
    0xFF000000.toInt(),
    0xFF3C3C3C.toInt(),
    0xFFFFFFFF.toInt(),
    0xFFC62828.toInt(),
    0xFF1565C0.toInt(),
    0xFF1B2A41.toInt(),
    0xFF2E7D32.toInt(),
    0xFFEF6C00.toInt(),
    0xFF6A1B9A.toInt()
)

/** Lo que está elegido en la hoja. */
private sealed interface DocScanSel {
    val pageId: Int
}

private data class DocScanSelLine(override val pageId: Int, val lineId: Int) : DocScanSel
private data class DocScanSelText(override val pageId: Int, val textId: Int) : DocScanSel
private data class DocScanSelSign(override val pageId: Int, val signId: Int) : DocScanSel

private fun docScanActivity(context: Context): Activity? {
    var current: Context? = context
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}

private fun docScanFilterLabel(filter: DocumentImageFilter): String = when (filter) {
    DocumentImageFilter.ORIGINAL -> "Original"
    DocumentImageFilter.DOCUMENT -> "Documento (más nítido)"
    DocumentImageFilter.GRAYSCALE -> "Gris"
    DocumentImageFilter.ENHANCE -> "Color mejorado"
}

/** Caja de lo elegido, en píxeles de la hoja encajada. */
private fun docScanSelectionRect(
    selection: DocScanSel?,
    pageId: Int,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    width: Float,
    height: Float,
    serif: Boolean,
    paint: android.graphics.Paint
): RectF? {
    if (selection == null || selection.pageId != pageId || width <= 0f || height <= 0f) return null
    return when (selection) {
        is DocScanSelLine -> {
            val lines = analysis?.lines ?: return null
            val line = lines.firstOrNull { it.id == selection.lineId } ?: return null
            val edit = edits.lines[line.id]
            if (edit != null) {
                docScanPlace(line, edit, lines, width, height, serif, paint).cover
            } else {
                RectF(line.left * width, line.top * height, line.right * width, line.bottom * height)
            }
        }
        is DocScanSelText -> edits.texts.firstOrNull { it.id == selection.textId }
            ?.let { docScanAddedBounds(it, width, height, serif, paint) }
        is DocScanSelSign -> edits.signs.firstOrNull { it.id == selection.signId }
            ?.let { docScanSignRect(it, width, height) }
    }
}

/** Lo que se está arrastrando, movido en vivo (solo para dibujar). */
private fun docScanPreview(edits: DocScanPageEdits, selection: DocScanSel?, dx: Float, dy: Float): DocScanPageEdits =
    when (selection) {
        is DocScanSelText -> edits.copy(
            texts = edits.texts.map { if (it.id == selection.textId) it.copy(x = it.x + dx, y = it.y + dy) else it }
        )
        is DocScanSelSign -> edits.copy(
            signs = edits.signs.map { if (it.id == selection.signId) it.movedBy(dx, dy) else it }
        )
        else -> edits
    }

/**
 * Escáner de documentos.
 *
 * 1. Entrada: "Escanear" (escáner de Google: encuentra la hoja, la recorta y la
 *    endereza) o "Elegir de tus fotos" (selector de fotos de Android).
 * 2. Hoja: se ve la foto original, idéntica. Se toca un texto y se cambia; solo
 *    cambia lo que se toca. Zoom como en la galería.
 * 3. Guardar: PDF (idéntico y con texto que se puede buscar), Word (texto
 *    editable) o imagen.
 */
@Composable
fun DocumentScannerScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pages by remember { mutableStateOf<List<DocScanPage>>(emptyList()) }
    var nextPageId by remember { mutableIntStateOf(1) }
    var session by remember { mutableIntStateOf(0) }
    var importing by remember { mutableStateOf(false) }
    var scannerOpening by remember { mutableStateOf(false) }
    // true = las páginas que lleguen se agregan al documento abierto.
    var appending by remember { mutableStateOf(false) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }

    // Copias de escaneos de otras veces: se borran al entrar.
    LaunchedEffect(Unit) {
        runCatching { docScanCleanCache(context, emptySet()) }
    }

    fun receivePages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val base = if (appending) pages else emptyList()
        val room = DOC_SCAN_MAX_PAGES - base.size
        if (room <= 0) {
            onMessage("Máximo $DOC_SCAN_MAX_PAGES páginas por documento.")
            return
        }
        val accepted = uris.take(room)
        var id = nextPageId
        val created = accepted.map { DocScanPage(id++, it) }
        nextPageId = id
        if (!appending) session++
        pages = base + created
        if (uris.size > room) onMessage("Se agregaron ${accepted.size} páginas. Máximo $DOC_SCAN_MAX_PAGES.")
    }

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(DOC_SCAN_MAX_PAGES)
    ) { uris -> receivePages(uris) }

    val googleScanner = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        scannerOpening = false
        if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val scan = runCatching { GmsDocumentScanningResult.fromActivityResultIntent(result.data) }.getOrNull()
        val sources = scan?.pages.orEmpty().map { it.imageUri }
        if (sources.isEmpty()) {
            onMessage("No se pudo leer el escaneo. Intenta otra vez.")
            return@rememberLauncherForActivityResult
        }
        importing = true
        scope.launch {
            val copied = runCatching { docScanCopyToCache(context, sources) }.getOrDefault(emptyList())
            importing = false
            if (copied.isEmpty()) onMessage("No se pudo leer el escaneo. Intenta otra vez.") else receivePages(copied)
        }
    }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
        val uri = cameraUri
        cameraUri = null
        if (saved && uri != null) receivePages(listOf(uri))
    }

    fun openPlainCamera() {
        val uri = runCatching { ToolFileUtils.createCameraImageUri(context) }.getOrNull()
        if (uri == null) {
            onMessage("No se pudo abrir la cámara.")
            return
        }
        cameraUri = uri
        runCatching { takePicture.launch(uri) }.onFailure {
            cameraUri = null
            onMessage("No se pudo abrir la cámara.")
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openPlainCamera() else onMessage("Da permiso de cámara para tomar la foto.")
    }

    // Respaldo: celular sin Servicios de Google o con poca memoria.
    fun cameraFallback() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openPlainCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    fun startScan(append: Boolean) {
        if (scannerOpening || importing) return
        appending = append
        val room = DOC_SCAN_MAX_PAGES - (if (append) pages.size else 0)
        if (room <= 0) {
            onMessage("Máximo $DOC_SCAN_MAX_PAGES páginas por documento.")
            return
        }
        val activity = docScanActivity(context)
        if (activity == null) {
            cameraFallback()
            return
        }
        scannerOpening = true
        runCatching {
            val options = GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(false)
                .setPageLimit(room)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build()
            GmsDocumentScanning.getClient(options)
                .getStartScanIntent(activity)
                .addOnSuccessListener { sender ->
                    runCatching { googleScanner.launch(IntentSenderRequest.Builder(sender).build()) }
                        .onFailure {
                            scannerOpening = false
                            cameraFallback()
                        }
                }
                .addOnFailureListener {
                    scannerOpening = false
                    cameraFallback()
                }
        }.onFailure {
            scannerOpening = false
            cameraFallback()
        }
    }

    fun pickPhotos(append: Boolean) {
        if (importing) return
        appending = append
        runCatching {
            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }.onFailure { onMessage("No se pudieron abrir tus fotos.") }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DocScanBackground)
    ) {
        if (pages.isEmpty()) {
            DocScanHome(
                tool = tool,
                busy = scannerOpening || importing,
                onBack = onBack,
                onScan = { startScan(append = false) },
                onPhotos = { pickPhotos(append = false) }
            )
        } else {
            key(session) {
                DocScanWorkspace(
                    viewModel = viewModel,
                    tool = tool,
                    pages = pages,
                    onMessage = onMessage,
                    onClose = {
                        pages = emptyList()
                        scope.launch { runCatching { docScanCleanCache(context, emptySet()) } }
                    },
                    onAddScan = { startScan(append = true) },
                    onAddPhotos = { pickPhotos(append = true) },
                    onRemovePage = { id -> pages = pages.filterNot { it.id == id } }
                )
            }
        }

        if (importing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xB3000000))
                    .pointerInput(Unit) { detectTapGestures { } },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = NeonGreen)
                    Spacer(Modifier.height(12.dp))
                    Text("Preparando páginas…", color = DocScanInk)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Entrada
// ---------------------------------------------------------------------------

@Composable
private fun DocScanHome(
    tool: ToolId,
    busy: Boolean,
    onBack: () -> Unit,
    onScan: () -> Unit,
    onPhotos: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
    ) {
        ToolHeader(tool.title, "Escanea o elige fotos de tus documentos", onBack)
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DocScanHomeAction(
                icon = Icons.Rounded.DocumentScanner,
                title = if (busy) "Abriendo…" else "Escanear documento",
                detail = "La cámara encuentra la hoja, la recorta y la endereza. Puedes escanear varias páginas.",
                primary = true,
                enabled = !busy,
                onClick = onScan
            )
            DocScanHomeAction(
                icon = Icons.Rounded.PhotoLibrary,
                title = "Elegir de tus fotos",
                detail = "Hasta $DOC_SCAN_MAX_PAGES fotos. Cada foto es una página.",
                primary = false,
                enabled = !busy,
                onClick = onPhotos
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(CardGreen)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Qué puedes hacer", color = DocScanInk, fontWeight = FontWeight.Bold)
                DocScanBullet("Cambiar el texto sobre tu misma hoja. Lo que no tocas queda igual.")
                DocScanBullet("Copiar o compartir todo el texto, en orden.")
                DocScanBullet("Agregar texto y tu firma.")
                DocScanBullet("Guardar en PDF, Word o imagen.")
            }
            Text(
                "Ver y editar es gratis. Guardar o copiar el texto: ${tool.creditCost} créditos.",
                color = DocScanMuted,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
private fun DocScanHomeAction(
    icon: ImageVector,
    title: String,
    detail: String,
    primary: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val background = if (primary) NeonGreen else CardGreen
    val titleColor = if (primary) DeepGreen else DocScanInk
    val detailColor = if (primary) DeepGreen.copy(alpha = 0.78f) else DocScanMuted
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(background)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (primary) DeepGreen.copy(alpha = 0.12f) else Color(0xFF173626)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = if (primary) DeepGreen else NeonGreen, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = titleColor, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Spacer(Modifier.height(3.dp))
            Text(detail, color = detailColor, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun DocScanBullet(text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            Modifier
                .padding(top = 7.dp)
                .size(6.dp)
                .clip(CircleShape)
                .background(NeonGreen)
        )
        Spacer(Modifier.width(10.dp))
        Text(text, color = DocScanInk.copy(alpha = 0.9f), style = MaterialTheme.typography.bodyMedium)
    }
}

// ---------------------------------------------------------------------------
// Hoja de trabajo
// ---------------------------------------------------------------------------

@Composable
private fun DocScanWorkspace(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    pages: List<DocScanPage>,
    onMessage: (String) -> Unit,
    onClose: () -> Unit,
    onAddScan: () -> Unit,
    onAddPhotos: () -> Unit,
    onRemovePage: (Int) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val density = LocalDensity.current

    var currentId by remember { mutableIntStateOf(pages.first().id) }
    val currentPage = pages.firstOrNull { it.id == currentId } ?: pages.first()
    val pageNumber = pages.indexOf(currentPage) + 1

    val analyses = remember { mutableStateMapOf<Int, DocScanAnalysis>() }
    val thumbs = remember { mutableStateMapOf<Int, ImageBitmap>() }
    var edits by remember { mutableStateOf<Map<Int, DocScanPageEdits>>(emptyMap()) }
    var undoStack by remember { mutableStateOf<List<Map<Int, DocScanPageEdits>>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<Map<Int, DocScanPageEdits>>>(emptyList()) }
    var typingKey by remember { mutableStateOf<String?>(null) }
    var typingAt by remember { mutableLongStateOf(0L) }

    var filter by remember { mutableStateOf(DocumentImageFilter.ORIGINAL) }
    var serif by remember { mutableStateOf(false) }
    var showBoxes by remember { mutableStateOf(true) }

    var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var bitmapPageId by remember { mutableIntStateOf(-1) }
    var loadingPage by remember { mutableStateOf(false) }
    var analyzing by remember { mutableStateOf(false) }

    var selection by remember { mutableStateOf<DocScanSel?>(null) }
    var newTextId by remember { mutableIntStateOf(-1) }
    var dragPreview by remember { mutableStateOf(Offset.Zero) }
    var showColors by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    var showText by remember { mutableStateOf(false) }
    var showSignature by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var textPaid by remember { mutableStateOf(false) }
    var flingJob by remember { mutableStateOf<Job?>(null) }

    val zoom = remember { DocScanZoomState() }
    val measurePaint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }
    val fieldFocus = remember { FocusRequester() }
    val filterMatrix = remember(filter) { docScanFilterMatrix(filter) }
    val composeFilter = remember(filterMatrix) { filterMatrix?.let { ColorFilter.colorMatrix(ColorMatrix(it)) } }

    val analysis = analyses[currentPage.id]
    val currentEdits = edits[currentPage.id] ?: DocScanPageEdits()
    val shownBitmap = pageBitmap.takeIf { bitmapPageId == currentPage.id }

    // ---------------- Página actual: foto y lectura ----------------
    LaunchedEffect(currentPage.id) {
        val page = currentPage
        selection = null
        dragPreview = Offset.Zero
        showColors = false
        loadingPage = true
        val loaded = try {
            ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            null
        } finally {
            loadingPage = false
        }
        if (loaded == null) {
            onMessage("No se pudo abrir esta página.")
            return@LaunchedEffect
        }
        pageBitmap = loaded
        bitmapPageId = page.id
        if (analyses[page.id] == null) {
            analyzing = true
            try {
                analyses[page.id] = docScanAnalyze(loaded)
            } finally {
                analyzing = false
            }
        }
    }

    // Miniaturas para cambiar de página.
    LaunchedEffect(pages) {
        if (pages.size < 2) return@LaunchedEffect
        for (page in pages) {
            if (thumbs.containsKey(page.id)) continue
            val small = runCatching { ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_THUMB_EDGE) }.getOrNull() ?: continue
            thumbs[page.id] = small.asImageBitmap()
        }
    }

    // ---------------- Cambios y deshacer ----------------
    fun commit(next: Map<Int, DocScanPageEdits>, typing: String? = null) {
        if (next == edits) return
        val now = SystemClock.elapsedRealtime()
        val sameTyping = typing != null && typing == typingKey && now - typingAt < DOC_SCAN_TYPING_PAUSE_MS
        if (!sameTyping) undoStack = (undoStack + listOf(edits)).takeLast(DOC_SCAN_UNDO_LIMIT)
        redoStack = emptyList()
        typingKey = typing
        typingAt = now
        edits = next
    }

    fun updatePage(pageId: Int, typing: String? = null, change: (DocScanPageEdits) -> DocScanPageEdits) {
        val updated = change(edits[pageId] ?: DocScanPageEdits())
        commit(if (updated.isEmpty) edits - pageId else edits + (pageId to updated), typing)
    }

    fun undo() {
        val previous = undoStack.lastOrNull() ?: return
        undoStack = undoStack.dropLast(1)
        redoStack = (redoStack + listOf(edits)).takeLast(DOC_SCAN_UNDO_LIMIT)
        typingKey = null
        edits = previous
    }

    fun redo() {
        val next = redoStack.lastOrNull() ?: return
        redoStack = redoStack.dropLast(1)
        undoStack = (undoStack + listOf(edits)).takeLast(DOC_SCAN_UNDO_LIMIT)
        typingKey = null
        edits = next
    }

    fun originalEdit(line: DocScanLine) = DocScanLineEdit(line.text, line.bold, false, line.ink)

    fun setLineEdit(pageId: Int, line: DocScanLine, edit: DocScanLineEdit, typing: Boolean = false) {
        updatePage(pageId, if (typing) "line:$pageId:${line.id}" else null) { page ->
            val lines = if (edit == originalEdit(line)) page.lines - line.id else page.lines + (line.id to edit)
            page.copy(lines = lines)
        }
    }

    fun deselect() {
        selection = null
        showColors = false
        focusManager.clearFocus()
    }

    // ---------------- Toques en la hoja ----------------
    fun hitTest(point: Offset): DocScanSel? {
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (width <= 0f || height <= 0f) return null
        val slack = 10f / zoom.scale
        currentEdits.signs.asReversed().firstOrNull { sign ->
            docScanSignRect(sign, width, height).apply { inset(-slack, -slack) }.contains(point.x, point.y)
        }?.let { return DocScanSelSign(currentPage.id, it.id) }
        currentEdits.texts.asReversed().firstOrNull { text ->
            docScanAddedBounds(text, width, height, serif, measurePaint).apply { inset(-slack, -slack) }.contains(point.x, point.y)
        }?.let { return DocScanSelText(currentPage.id, it.id) }
        val lines = analysis?.lines ?: return null
        var best: DocScanLine? = null
        var bestArea = Float.MAX_VALUE
        for (line in lines) {
            val edit = currentEdits.lines[line.id]
            val rect = if (edit != null) {
                docScanPlace(line, edit, lines, width, height, serif, measurePaint).cover
            } else {
                RectF(line.left * width, line.top * height, line.right * width, line.bottom * height)
            }
            rect.inset(-slack, -slack * 0.6f)
            if (rect.contains(point.x, point.y)) {
                val area = rect.width() * rect.height()
                if (area < bestArea) {
                    best = line
                    bestArea = area
                }
            }
        }
        return best?.let { DocScanSelLine(currentPage.id, it.id) }
    }

    val handleTap: (Offset) -> Unit = { screen ->
        val hit = hitTest(zoom.toContent(screen))
        if (hit == null) deselect() else if (hit != selection) {
            showColors = false
            selection = hit
        }
    }
    val handleDoubleTap: (Offset) -> Unit = { screen ->
        scope.launch { zoom.toggleAt(screen) }
    }
    // Solo el texto agregado y la firma se arrastran (los renglones leídos quedan en su sitio).
    val canDragAt: (Offset) -> Boolean = { point ->
        val sel = selection
        if (sel == null || sel is DocScanSelLine) {
            false
        } else {
            val rect = docScanSelectionRect(sel, currentPage.id, analysis, currentEdits, zoom.contentWidth, zoom.contentHeight, serif, measurePaint)
            if (rect == null) {
                false
            } else {
                val slack = 18f / zoom.scale
                rect.inset(-slack, -slack)
                rect.contains(point.x, point.y)
            }
        }
    }
    val onItemDrag: (Offset) -> Unit = { delta -> dragPreview += delta }
    val onItemDragEnd: () -> Unit = {
        val moved = dragPreview
        dragPreview = Offset.Zero
        val sel = selection
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (sel != null && width > 0f && height > 0f && (abs(moved.x) > 0.5f || abs(moved.y) > 0.5f)) {
            val dx = moved.x / width
            val dy = moved.y / height
            when (sel) {
                is DocScanSelText -> updatePage(sel.pageId) { page ->
                    page.copy(texts = page.texts.map {
                        if (it.id == sel.textId) {
                            it.copy(x = (it.x + dx).coerceIn(-0.2f, 0.98f), y = (it.y + dy).coerceIn(0.01f, 1.1f))
                        } else it
                    })
                }
                is DocScanSelSign -> updatePage(sel.pageId) { page ->
                    page.copy(signs = page.signs.map { if (it.id == sel.signId) it.movedBy(dx, dy) else it })
                }
                else -> Unit
            }
        }
    }
    val latestTap by rememberUpdatedState(handleTap)
    val latestDoubleTap by rememberUpdatedState(handleDoubleTap)
    val latestCanDrag by rememberUpdatedState(canDragAt)
    val latestDrag by rememberUpdatedState(onItemDrag)
    val latestDragEnd by rememberUpdatedState(onItemDragEnd)

    // ---------------- Agregar ----------------
    fun addText() {
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (width <= 0f || height <= 0f) return
        val center = zoom.visibleCenter()
        val lines = analysis?.lines.orEmpty()
        val heights = lines.map { it.bottom - it.top }.sorted()
        val size = if (heights.isEmpty()) 0.022f else (heights[heights.size / 2] * 0.95f).coerceIn(0.008f, 0.08f)
        // Color de letra más común de la hoja (la tinta "del medio" por brillo).
        val inks = lines.map { it.ink }.sortedBy {
            android.graphics.Color.red(it) * 299 + android.graphics.Color.green(it) * 587 + android.graphics.Color.blue(it) * 114
        }
        val color = if (inks.isEmpty()) android.graphics.Color.BLACK else inks[inks.size / 2]
        val id = (currentEdits.texts.maxOfOrNull { it.id } ?: 0) + 1
        val x = (center.x / width - 0.08f).coerceIn(0.02f, 0.9f)
        val y = (center.y / height).coerceIn(0.05f, 0.97f)
        updatePage(currentPage.id) { it.copy(texts = it.texts + DocScanAddedText(id, x, y, "Texto", size, color)) }
        newTextId = id
        selection = DocScanSelText(currentPage.id, id)
    }

    fun addSign(bitmap: Bitmap) {
        val width = zoom.contentWidth
        val height = zoom.contentHeight
        if (width <= 0f || height <= 0f || bitmap.width < 2) return
        val center = zoom.visibleCenter()
        val signWidth = 0.32f
        val signHeight = signWidth * width * bitmap.height / bitmap.width / height
        val id = (currentEdits.signs.maxOfOrNull { it.id } ?: 0) + 1
        updatePage(currentPage.id) {
            it.copy(
                signs = it.signs + DocScanSign(
                    id,
                    (center.x / width - signWidth / 2f).coerceIn(0f, 1f - signWidth),
                    (center.y / height - signHeight / 2f).coerceIn(0f, 0.95f),
                    signWidth,
                    bitmap
                )
            )
        }
        selection = DocScanSelSign(currentPage.id, id)
    }

    // ---------------- Guardar ----------------
    fun runSave(output: Uri, format: Int) {
        if (saving) return
        saving = true
        val pagesNow = pages
        val pageIds = pagesNow.map { it.id }.toSet()
        val editsNow = edits.filterKeys { it in pageIds }
        val known = analyses.toMap()
        val page = currentPage
        val serifNow = serif
        val matrix = filterMatrix
        scope.launch {
            val result = runPaidTool(viewModel, tool) {
                withContext(Dispatchers.IO) {
                    val stream = context.contentResolver.openOutputStream(output, "w") ?: error("No se pudo crear el archivo.")
                    stream.use { out ->
                        when (format) {
                            DOC_SCAN_FORMAT_PDF -> docScanWritePdf(context, out, pagesNow, known, editsNow, serifNow, matrix)
                            DOC_SCAN_FORMAT_WORD -> {
                                val all = docScanEnsureAnalyses(context, pagesNow, known)
                                docScanWriteDocx(
                                    out,
                                    pagesNow.map { docScanPageText(all[it.id], editsNow[it.id] ?: DocScanPageEdits()) },
                                    serifNow
                                )
                            }
                            else -> docScanWriteImage(
                                context,
                                out,
                                page,
                                known[page.id],
                                editsNow[page.id] ?: DocScanPageEdits(),
                                serifNow,
                                matrix
                            )
                        }
                    }
                }
            }
            saving = false
            val label = when (format) {
                DOC_SCAN_FORMAT_PDF -> "PDF guardado."
                DOC_SCAN_FORMAT_WORD -> "Word guardado."
                else -> "Imagen guardada."
            }
            result
                .onSuccess { onMessage(successMessage(label, it)) }
                .onFailure { onMessage(it.message ?: "No se pudo guardar el archivo.") }
        }
    }

    val savePdf = rememberLauncherForActivityResult(TrackedCreateDocument("application/pdf")) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_PDF)
    }
    val saveWord = rememberLauncherForActivityResult(TrackedCreateDocument(DOC_SCAN_DOCX_MIME)) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_WORD)
    }
    val saveImage = rememberLauncherForActivityResult(TrackedCreateDocument("image/jpeg")) { uri ->
        if (uri != null) runSave(uri, DOC_SCAN_FORMAT_IMAGE)
    }

    fun chooseFormat(format: Int) {
        showSave = false
        val stamp = System.currentTimeMillis() / 1000
        launchPaidExport(viewModel, tool, onMessage) {
            when (format) {
                DOC_SCAN_FORMAT_PDF -> savePdf.launch("Escaneo_$stamp.pdf")
                DOC_SCAN_FORMAT_WORD -> saveWord.launch("Escaneo_$stamp.docx")
                else -> saveImage.launch("Escaneo_${stamp}_p$pageNumber.jpg")
            }
        }
    }

    // Copiar o compartir el texto se cobra una sola vez por documento.
    fun withPaidText(text: String, action: (String) -> Unit) {
        if (text.isBlank()) {
            onMessage("No hay texto para copiar.")
            return
        }
        if (textPaid) {
            action(text)
            return
        }
        launchPaidExport(viewModel, tool, onMessage) {
            scope.launch {
                runPaidTool(viewModel, tool) { }
                    .onSuccess {
                        textPaid = true
                        action(text)
                        onMessage(successMessage("Listo.", it))
                    }
                    .onFailure { onMessage(it.message ?: "No se pudo completar.") }
            }
        }
    }

    fun handleBack() {
        when {
            showSignature -> showSignature = false
            showText -> showText = false
            showSave -> showSave = false
            showSettings -> showSettings = false
            selection != null -> deselect()
            edits.isNotEmpty() -> confirmExit = true
            else -> onClose()
        }
    }
    BackHandler { handleBack() }

    // Al elegir un texto para escribir, sale el teclado.
    val selectionKey = selection?.let { sel ->
        when (sel) {
            is DocScanSelLine -> "l:${sel.pageId}:${sel.lineId}"
            is DocScanSelText -> "t:${sel.pageId}:${sel.textId}"
            is DocScanSelSign -> "s:${sel.pageId}:${sel.signId}"
        }
    }
    LaunchedEffect(selectionKey) {
        val sel = selection
        val wantsKeyboard = when (sel) {
            is DocScanSelLine -> currentEdits.lines[sel.lineId]?.deleted != true
            is DocScanSelText -> true
            else -> false
        }
        if (wantsKeyboard) {
            delay(80)
            runCatching { fieldFocus.requestFocus() }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DocScanBackground)
                .imePadding()
        ) {
            // ---------------- Barra de arriba ----------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DocScanBar)
                    .statusBarsPadding()
                    .height(56.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { handleBack() }) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = DocScanInk)
                }
                Column(Modifier.weight(1f)) {
                    Text("Escáner", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        if (pages.size > 1) "Página $pageNumber de ${pages.size}" else "1 página",
                        color = DocScanMuted,
                        fontSize = 12.sp
                    )
                }
                IconButton(onClick = { undo() }, enabled = undoStack.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Undo,
                        contentDescription = "Deshacer",
                        tint = if (undoStack.isNotEmpty()) DocScanInk else Color(0xFF4A5A51)
                    )
                }
                IconButton(onClick = { redo() }, enabled = redoStack.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Redo,
                        contentDescription = "Rehacer",
                        tint = if (redoStack.isNotEmpty()) DocScanInk else Color(0xFF4A5A51)
                    )
                }
                Box {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Rounded.Tune, contentDescription = "Ajustes", tint = DocScanInk)
                    }
                    DropdownMenu(expanded = showSettings, onDismissRequest = { showSettings = false }) {
                        DocScanMenuLabel("Imagen")
                        DocumentImageFilter.entries.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(docScanFilterLabel(option)) },
                                onClick = {
                                    filter = option
                                    showSettings = false
                                },
                                trailingIcon = {
                                    if (filter == option) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen)
                                }
                            )
                        }
                        HorizontalDivider()
                        DocScanMenuLabel("Letra de lo que edites")
                        DropdownMenuItem(
                            text = { Text("Arial (sin remates)") },
                            onClick = {
                                serif = false
                                showSettings = false
                            },
                            trailingIcon = { if (!serif) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen) }
                        )
                        DropdownMenuItem(
                            text = { Text("Times (con remates)") },
                            onClick = {
                                serif = true
                                showSettings = false
                            },
                            trailingIcon = { if (serif) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen) }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Marcar el texto detectado") },
                            onClick = { showBoxes = !showBoxes },
                            trailingIcon = { if (showBoxes) Icon(Icons.Rounded.Check, contentDescription = null, tint = NeonGreen) }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Agregar páginas con la cámara") },
                            onClick = {
                                showSettings = false
                                onAddScan()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Agregar páginas de tus fotos") },
                            onClick = {
                                showSettings = false
                                onAddPhotos()
                            }
                        )
                        if (pages.size > 1) {
                            DropdownMenuItem(
                                text = { Text("Quitar esta página", color = DocScanDanger) },
                                onClick = {
                                    showSettings = false
                                    val index = pages.indexOf(currentPage)
                                    val removed = currentPage.id
                                    currentId = pages.getOrNull(index + 1)?.id ?: pages.getOrNull(index - 1)?.id ?: removed
                                    edits = edits - removed
                                    onRemovePage(removed)
                                }
                            )
                        }
                    }
                }
                Box(
                    modifier = Modifier
                        .padding(start = 2.dp, end = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (saving) Color(0xFF5E7F1A) else NeonGreen)
                        .clickable(enabled = !saving) {
                            deselect()
                            showSave = true
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        if (saving) "Guardando…" else "Guardar",
                        color = DeepGreen,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }
            }
            if (saving) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = NeonGreen)

            // ---------------- Hoja ----------------
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clipToBounds()
            ) {
                val viewWidth = constraints.maxWidth.toFloat()
                val viewHeight = constraints.maxHeight.toFloat()
                // El alto más grande visto: al salir el teclado la hoja no se achica, solo se mueve.
                val stableHeight = remember { FloatArray(1) }
                if (viewHeight > stableHeight[0]) stableHeight[0] = viewHeight
                val bitmap = shownBitmap

                if (bitmap != null) {
                    val margin = with(density) { 12.dp.toPx() }
                    val aspect = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
                    val contentWidth = min(viewWidth - 2f * margin, (stableHeight[0] - 2f * margin) * aspect).coerceAtLeast(10f)
                    val contentHeight = contentWidth / aspect
                    zoom.setSizes(currentPage.id, viewWidth, viewHeight, contentWidth, contentHeight)
                    val picture = remember(bitmap) { bitmap.asImageBitmap() }

                    // Deja a la vista lo que se está editando (también cuando sale el teclado).
                    LaunchedEffect(selectionKey, constraints.maxHeight) {
                        val sel = selection ?: return@LaunchedEffect
                        if (sel is DocScanSelSign) return@LaunchedEffect
                        delay(220)
                        val rect = docScanSelectionRect(
                            sel, currentPage.id, analysis, currentEdits,
                            zoom.contentWidth, zoom.contentHeight, serif, measurePaint
                        ) ?: return@LaunchedEffect
                        zoom.reveal(Rect(rect.left, rect.top, rect.right, rect.bottom))
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onDoubleTap = { latestDoubleTap(it) },
                                    onTap = { latestTap(it) }
                                )
                            }
                            .pointerInput(zoom) {
                                // Un dedo mueve la hoja (con inercia); dos dedos acercan donde
                                // están los dedos. Si está elegida una firma o un texto agregado,
                                // arrastrarlo lo mueve.
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false)
                                    flingJob?.cancel()
                                    val tracker = VelocityTracker()
                                    tracker.addPosition(down.uptimeMillis, down.position)
                                    val slop = viewConfiguration.touchSlop
                                    var travelled = Offset.Zero
                                    var active = false
                                    var pinched = false
                                    var pointerCount = 1
                                    var movingItem = latestCanDrag(zoom.toContent(down.position))
                                    while (true) {
                                        val event = awaitPointerEvent()
                                        val pressed = event.changes.filter { it.pressed }
                                        if (pressed.isEmpty()) break
                                        if (pressed.size != pointerCount) {
                                            pointerCount = pressed.size
                                            tracker.resetTracking()
                                        }
                                        val zoomChange = event.calculateZoom()
                                        val pan = event.calculatePan()
                                        if (!active) {
                                            travelled += pan
                                            if (pressed.size >= 2 || travelled.getDistance() > slop) active = true
                                        }
                                        if (active) {
                                            if (pressed.size >= 2) {
                                                pinched = true
                                                if (movingItem) {
                                                    movingItem = false
                                                    latestDragEnd()
                                                }
                                                val centroid = event.calculateCentroid(useCurrent = true)
                                                if (centroid.isSpecified) zoom.zoomBy(zoomChange, centroid, pan)
                                            } else if (movingItem) {
                                                latestDrag(Offset(pan.x / zoom.scale, pan.y / zoom.scale))
                                            } else {
                                                zoom.panBy(pan)
                                            }
                                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                                        }
                                        val lead = pressed.first()
                                        tracker.addPosition(lead.uptimeMillis, lead.position)
                                    }
                                    if (movingItem && active) {
                                        latestDragEnd()
                                    } else if (active && !pinched) {
                                        val velocity = tracker.calculateVelocity()
                                        flingJob = scope.launch { zoom.fling(velocity) }
                                    }
                                    if (pinched && zoom.scale < 1f) scope.launch { zoom.animateToFit() }
                                }
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(
                                    with(density) { contentWidth.toDp() },
                                    with(density) { contentHeight.toDp() }
                                )
                                .graphicsLayer {
                                    transformOrigin = TransformOrigin(0f, 0f)
                                    scaleX = zoom.scale
                                    scaleY = zoom.scale
                                    translationX = zoom.offsetX
                                    translationY = zoom.offsetY
                                }
                                .background(Color.White)
                        ) {
                            Image(
                                bitmap = picture,
                                contentDescription = "Página $pageNumber",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.FillBounds,
                                colorFilter = composeFilter
                            )
                            Canvas(Modifier.fillMaxSize()) {
                                val width = size.width
                                val height = size.height
                                val preview = dragPreview
                                val sel = selection
                                val drawn = if (preview != Offset.Zero) {
                                    docScanPreview(currentEdits, sel, preview.x / width, preview.y / height)
                                } else {
                                    currentEdits
                                }
                                // Marca suave del texto que se puede cambiar.
                                if (showBoxes && analysis != null) {
                                    for (line in analysis.lines) {
                                        if (drawn.lines.containsKey(line.id)) continue
                                        drawRect(
                                            color = DocScanFocus.copy(alpha = 0.09f),
                                            topLeft = Offset(line.left * width, line.top * height),
                                            size = Size((line.right - line.left) * width, (line.bottom - line.top) * height)
                                        )
                                    }
                                }
                                drawIntoCanvas { canvas ->
                                    docScanDrawEdits(canvas.nativeCanvas, width, height, analysis, drawn, serif, filterMatrix)
                                }
                                val rect = docScanSelectionRect(sel, currentPage.id, analysis, drawn, width, height, serif, measurePaint)
                                if (rect != null) {
                                    val stroke = (width * 0.0025f).coerceAtLeast(1.5f)
                                    drawRect(
                                        color = DocScanFocus.copy(alpha = 0.10f),
                                        topLeft = Offset(rect.left - stroke, rect.top - stroke),
                                        size = Size(rect.width() + stroke * 2f, rect.height() + stroke * 2f)
                                    )
                                    drawRect(
                                        color = DocScanFocus,
                                        topLeft = Offset(rect.left - stroke, rect.top - stroke),
                                        size = Size(rect.width() + stroke * 2f, rect.height() + stroke * 2f),
                                        style = Stroke(width = stroke)
                                    )
                                }
                            }
                        }
                    }
                }

                // Avisos sobre la hoja.
                when {
                    loadingPage || bitmap == null -> {
                        CircularProgressIndicator(color = NeonGreen, modifier = Modifier.align(Alignment.Center))
                    }
                    analyzing -> DocScanStatusChip("Leyendo el texto…", Modifier.align(Alignment.TopCenter))
                    analysis != null && (analysis.failed || analysis.lines.isEmpty()) ->
                        DocScanStatusChip("No se encontró texto en esta página", Modifier.align(Alignment.TopCenter))
                }
            }

            // ---------------- Barra de abajo ----------------
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DocScanBar)
                    .navigationBarsPadding()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val sel = selection
                val selectedLine = (sel as? DocScanSelLine)?.let { lineSel ->
                    analysis?.lines?.firstOrNull { it.id == lineSel.lineId }
                }
                val selectedText = (sel as? DocScanSelText)?.let { textSel ->
                    currentEdits.texts.firstOrNull { it.id == textSel.textId }
                }
                val selectedSign = (sel as? DocScanSelSign)?.let { signSel ->
                    currentEdits.signs.firstOrNull { it.id == signSel.signId }
                }

                when {
                    selectedLine != null -> {
                        val line = selectedLine
                        val edit = currentEdits.lines[line.id] ?: originalEdit(line)
                        val changed = currentEdits.lines.containsKey(line.id)
                        if (edit.deleted) {
                            DocScanRow {
                                Text("Renglón borrado", color = DocScanMuted, fontSize = 13.sp)
                                DocScanChip(active = false, onClick = { setLineEdit(currentPage.id, line, originalEdit(line)) }) {
                                    DocScanLabel("Recuperar")
                                }
                                DocScanChip(active = false, onClick = { deselect() }) {
                                    Text("Listo", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        } else {
                            DocScanTextField(
                                fieldKey = "l:${currentPage.id}:${line.id}",
                                text = edit.text,
                                selectAll = false,
                                focusRequester = fieldFocus,
                                onText = { setLineEdit(currentPage.id, line, edit.copy(text = it), typing = true) },
                                onDone = { deselect() }
                            )
                            DocScanStyleRow(
                                bold = edit.bold,
                                italic = edit.italic,
                                color = edit.color,
                                showColors = showColors,
                                onBold = { setLineEdit(currentPage.id, line, edit.copy(bold = !edit.bold)) },
                                onItalic = { setLineEdit(currentPage.id, line, edit.copy(italic = !edit.italic)) },
                                onColors = { showColors = !showColors },
                                onSmaller = { setLineEdit(currentPage.id, line, edit.copy(scale = (edit.scale * 0.92f).coerceAtLeast(0.4f))) },
                                onBigger = { setLineEdit(currentPage.id, line, edit.copy(scale = (edit.scale * 1.08f).coerceAtMost(3f))) }
                            ) {
                                DocScanChip(active = false, onClick = { setLineEdit(currentPage.id, line, edit.copy(deleted = true)) }) {
                                    Text("Borrar", color = DocScanDanger, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                if (changed) {
                                    DocScanChip(active = false, onClick = { setLineEdit(currentPage.id, line, originalEdit(line)) }) {
                                        DocScanLabel("Original")
                                    }
                                }
                                DocScanChip(active = false, onClick = { deselect() }) {
                                    Text("Listo", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                            if (showColors) {
                                DocScanPaletteRow(selected = edit.color) { color ->
                                    setLineEdit(currentPage.id, line, edit.copy(color = color))
                                }
                            }
                        }
                    }

                    selectedText != null -> {
                        val added = selectedText
                        fun change(update: (DocScanAddedText) -> DocScanAddedText, typing: Boolean = false) {
                            updatePage(currentPage.id, if (typing) "text:${currentPage.id}:${added.id}" else null) { page ->
                                page.copy(texts = page.texts.map { if (it.id == added.id) update(it) else it })
                            }
                        }
                        DocScanTextField(
                            fieldKey = "t:${currentPage.id}:${added.id}",
                            text = added.text,
                            selectAll = newTextId == added.id,
                            focusRequester = fieldFocus,
                            onText = { value -> change({ it.copy(text = value) }, typing = true) },
                            onDone = { deselect() }
                        )
                        DocScanStyleRow(
                            bold = added.bold,
                            italic = added.italic,
                            color = added.color,
                            showColors = showColors,
                            onBold = { change({ it.copy(bold = !it.bold) }) },
                            onItalic = { change({ it.copy(italic = !it.italic) }) },
                            onColors = { showColors = !showColors },
                            onSmaller = { change({ it.copy(size = (it.size * 0.92f).coerceAtLeast(0.005f)) }) },
                            onBigger = { change({ it.copy(size = (it.size * 1.08f).coerceAtMost(0.2f)) }) }
                        ) {
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page -> page.copy(texts = page.texts.filterNot { it.id == added.id }) }
                                deselect()
                            }) {
                                Text("Quitar", color = DocScanDanger, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            DocScanChip(active = false, onClick = { deselect() }) {
                                Text("Listo", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                        if (showColors) {
                            DocScanPaletteRow(selected = added.color) { color -> change({ it.copy(color = color) }) }
                        }
                        DocScanHint("Arrastra el texto para moverlo.")
                    }

                    selectedSign != null -> {
                        val sign = selectedSign
                        DocScanRow {
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page ->
                                    page.copy(signs = page.signs.map { if (it.id == sign.id) it.resizedBy(0.9f) else it })
                                }
                            }) { DocScanLabel("Más chica") }
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page ->
                                    page.copy(signs = page.signs.map { if (it.id == sign.id) it.resizedBy(1.1f) else it })
                                }
                            }) { DocScanLabel("Más grande") }
                            DocScanChip(active = false, onClick = {
                                updatePage(currentPage.id) { page -> page.copy(signs = page.signs.filterNot { it.id == sign.id }) }
                                deselect()
                            }) {
                                Text("Quitar", color = DocScanDanger, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            DocScanChip(active = false, onClick = { deselect() }) {
                                Text("Listo", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                        DocScanHint("Arrastra la firma para moverla.")
                    }

                    else -> {
                        DocScanRow {
                            DocScanChip(active = false, onClick = { showText = true }) {
                                Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = DocScanInk, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                DocScanLabel("Copiar texto")
                            }
                            DocScanChip(active = false, onClick = { addText() }) { DocScanLabel("+ Texto") }
                            DocScanChip(active = false, onClick = { showSignature = true }) { DocScanLabel("+ Firma") }
                        }
                        if (pages.size > 1) {
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                itemsIndexed(pages, key = { _, page -> page.id }) { index, page ->
                                    val current = page.id == currentPage.id
                                    Box(
                                        modifier = Modifier
                                            .size(width = 46.dp, height = 60.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF22352B))
                                            .border(
                                                width = if (current) 2.dp else 1.dp,
                                                color = if (current) NeonGreen else Color(0xFF2E4237),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable { if (!current) currentId = page.id },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        val thumb = thumbs[page.id]
                                        if (thumb != null) {
                                            Image(
                                                bitmap = thumb,
                                                contentDescription = "Página ${index + 1}",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                        Text(
                                            "${index + 1}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .background(Color(0x99000000), RoundedCornerShape(topStart = 6.dp))
                                                .padding(horizontal = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                        DocScanHint("Toca un texto para cambiarlo · doble toque o dos dedos para acercar.")
                    }
                }
            }
        }

        // ---------------- Ventanas ----------------
        if (showText) {
            DocScanTextSheet(
                pages = pages,
                currentPageId = currentPage.id,
                analyses = analyses,
                edits = edits,
                paid = textPaid,
                cost = tool.creditCost,
                onClose = { showText = false },
                onCopy = { text ->
                    withPaidText(text) { value ->
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        runCatching { clipboard?.setPrimaryClip(ClipData.newPlainText("Texto escaneado", value)) }
                        onMessage("Texto copiado.")
                    }
                },
                onShare = { text ->
                    withPaidText(text) { value ->
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, value)
                        }
                        runCatching { context.startActivity(Intent.createChooser(send, "Compartir texto")) }
                    }
                }
            )
        }

        if (showSignature) {
            DocScanSignaturePad(
                onCancel = { showSignature = false },
                onDone = { bitmap ->
                    showSignature = false
                    addSign(bitmap)
                }
            )
        }

        if (showSave) {
            AlertDialog(
                onDismissRequest = { showSave = false },
                containerColor = CardGreen,
                title = { Text("Guardar como", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DocScanFormatOption(
                            "PDF",
                            if (pages.size > 1) "Las ${pages.size} páginas, idénticas. El texto se puede buscar y copiar."
                            else "Idéntico a la hoja. El texto se puede buscar y copiar."
                        ) { chooseFormat(DOC_SCAN_FORMAT_PDF) }
                        DocScanFormatOption("Word", "Solo el texto, en orden, para seguir escribiendo.") {
                            chooseFormat(DOC_SCAN_FORMAT_WORD)
                        }
                        DocScanFormatOption(
                            "Imagen JPG",
                            if (pages.size > 1) "Esta página (la $pageNumber), idéntica." else "La hoja, idéntica."
                        ) { chooseFormat(DOC_SCAN_FORMAT_IMAGE) }
                        Text(
                            "Cada archivo cuesta ${tool.creditCost} créditos.",
                            color = DocScanMuted,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showSave = false }) { Text("Cancelar") }
                }
            )
        }

        if (confirmExit) {
            AlertDialog(
                onDismissRequest = { confirmExit = false },
                containerColor = CardGreen,
                title = { Text("¿Salir sin guardar?", fontWeight = FontWeight.Bold) },
                text = { Text("Se perderán los cambios que hiciste en este documento.") },
                confirmButton = {
                    TextButton(onClick = {
                        confirmExit = false
                        onClose()
                    }) { Text("Salir", color = DocScanDanger) }
                },
                dismissButton = {
                    TextButton(onClick = { confirmExit = false }) { Text("Seguir editando") }
                }
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Piezas de la interfaz
// ---------------------------------------------------------------------------

@Composable
private fun DocScanStatusChip(text: String, modifier: Modifier) {
    Text(
        text,
        color = DocScanInk,
        fontSize = 13.sp,
        modifier = modifier
            .padding(top = 10.dp)
            .clip(RoundedCornerShape(50))
            .background(Color(0xE6101D16))
            .padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
private fun DocScanMenuLabel(text: String) {
    Text(
        text,
        color = DocScanMuted,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
    )
}

@Composable
private fun DocScanHint(text: String) {
    Text(
        text,
        color = DocScanMuted,
        fontSize = 12.sp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
    )
}

@Composable
private fun DocScanRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        content()
    }
}

@Composable
private fun DocScanChip(
    active: Boolean,
    onClick: () -> Unit,
    enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .height(42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) DocScanChipOn else DocScanChipIdle)
            .border(
                width = 1.dp,
                color = if (active) NeonGreen.copy(alpha = 0.7f) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        content()
    }
}

@Composable
private fun DocScanLabel(text: String) {
    Text(text, color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 13.sp)
}

@Composable
private fun DocScanTextField(
    fieldKey: String,
    text: String,
    selectAll: Boolean,
    focusRequester: FocusRequester,
    onText: (String) -> Unit,
    onDone: () -> Unit
) {
    var field by remember(fieldKey) {
        mutableStateOf(TextFieldValue(text, if (selectAll) TextRange(0, text.length) else TextRange(text.length)))
    }
    // Si el texto cambió por fuera (deshacer, rehacer), se muestra el del documento.
    val shown = if (field.text == text) field else TextFieldValue(text, TextRange(text.length))
    OutlinedTextField(
        value = shown,
        onValueChange = { next ->
            field = next
            if (next.text != text) onText(next.text)
        },
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyLarge,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp)
            .focusRequester(focusRequester)
    )
}

@Composable
private fun DocScanStyleRow(
    bold: Boolean,
    italic: Boolean,
    color: Int,
    showColors: Boolean,
    onBold: () -> Unit,
    onItalic: () -> Unit,
    onColors: () -> Unit,
    onSmaller: () -> Unit,
    onBigger: () -> Unit,
    extra: @Composable () -> Unit
) {
    DocScanRow {
        DocScanChip(active = bold, onClick = onBold) {
            Text("B", color = DocScanInk, fontWeight = FontWeight.Black, fontSize = 17.sp)
        }
        DocScanChip(active = italic, onClick = onItalic) {
            Text("I", color = DocScanInk, fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
        DocScanChip(active = showColors, onClick = onColors) {
            Box(
                Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(Color(color))
                    .border(1.dp, DocScanMuted, CircleShape)
            )
        }
        DocScanChip(active = false, onClick = onSmaller) {
            Text("A−", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        DocScanChip(active = false, onClick = onBigger) {
            Text("A+", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Box(
            Modifier
                .width(1.dp)
                .height(24.dp)
                .background(Color(0xFF2A3B31))
        )
        extra()
    }
}

@Composable
private fun DocScanPaletteRow(selected: Int, onPick: (Int) -> Unit) {
    DocScanRow {
        DocScanPalette.forEach { swatch ->
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(swatch))
                    .border(
                        width = if (selected == swatch) 2.dp else 1.dp,
                        color = if (selected == swatch) NeonGreen else DocScanMuted,
                        shape = CircleShape
                    )
                    .clickable { onPick(swatch) }
            )
        }
    }
}

@Composable
private fun DocScanFormatOption(title: String, detail: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF123524))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(title, fontWeight = FontWeight.Bold, color = NeonGreen)
        Text(detail, style = MaterialTheme.typography.bodySmall, color = DocScanInk.copy(alpha = 0.85f))
    }
}

/** Todo el texto de la hoja, en orden, para copiar o compartir. */
@Composable
private fun DocScanTextSheet(
    pages: List<DocScanPage>,
    currentPageId: Int,
    analyses: MutableMap<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    paid: Boolean,
    cost: Int,
    onClose: () -> Unit,
    onCopy: (String) -> Unit,
    onShare: (String) -> Unit
) {
    val context = LocalContext.current
    var allPages by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }

    // Para "Todas las páginas" se leen las que todavía no se abrieron.
    LaunchedEffect(allPages) {
        if (!allPages) return@LaunchedEffect
        if (pages.all { analyses[it.id] != null }) return@LaunchedEffect
        loading = true
        try {
            val read = docScanEnsureAnalyses(context, pages, analyses.toMap())
            read.forEach { (id, value) -> analyses[id] = value }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            // Se muestra lo que se pudo leer.
        } finally {
            loading = false
        }
    }

    val currentPage = pages.firstOrNull { it.id == currentPageId }
    val text = when {
        loading -> ""
        allPages -> docScanAllText(pages, analyses, edits)
        currentPage != null -> docScanPageText(analyses[currentPage.id], edits[currentPage.id] ?: DocScanPageEdits())
        else -> ""
    }
    val words = text.split(Regex("\\s+")).count { it.isNotBlank() }
    val price = if (paid) "" else " · $cost créditos"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DocScanBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = DocScanInk)
            }
            Column(Modifier.weight(1f)) {
                Text("Texto de la hoja", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("$words palabras · ${text.length} caracteres", color = DocScanMuted, fontSize = 12.sp)
            }
        }
        if (pages.size > 1) {
            DocScanRow {
                DocScanChip(active = !allPages, onClick = { allPages = false }) { DocScanLabel("Esta página") }
                DocScanChip(active = allPages, onClick = { allPages = true }) { DocScanLabel("Todas las páginas") }
            }
            Spacer(Modifier.height(8.dp))
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0F1D16))
                .border(1.dp, Color(0xFF22352B), RoundedCornerShape(16.dp))
        ) {
            if (loading) {
                CircularProgressIndicator(color = NeonGreen, modifier = Modifier.align(Alignment.Center))
            } else if (text.isBlank()) {
                Text(
                    "Todavía no hay texto. Espera a que termine de leer la hoja.",
                    color = DocScanMuted,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
            } else {
                SelectionContainer {
                    Text(
                        text,
                        color = DocScanInk,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    )
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(NeonGreen)
                    .clickable(enabled = !loading && text.isNotBlank()) { onCopy(text) },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = DeepGreen, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Copiar$price", color = DeepGreen, fontWeight = FontWeight.Black)
            }
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(DocScanChipIdle)
                    .clickable(enabled = !loading && text.isNotBlank()) { onShare(text) },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Share, contentDescription = null, tint = DocScanInk, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Compartir$price", color = DocScanInk, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Cuadro para firmar con el dedo. Devuelve la firma como imagen con fondo transparente. */
@Composable
private fun DocScanSignaturePad(onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    val live = remember { mutableStateListOf<Offset>() }
    val strokeWidthPx = with(LocalDensity.current) { 3.dp.toPx() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xE6000000))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 18.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(DocScanBar)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Firma con el dedo", color = DocScanInk, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { start ->
                                live.clear()
                                live.add(start)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                live.add(change.position)
                            },
                            onDragEnd = {
                                if (live.size > 1) strokes.add(live.toList())
                                live.clear()
                            },
                            onDragCancel = { live.clear() }
                        )
                    }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val ink = Color(DocScanSignatureInk)
                    fun line(points: List<Offset>) {
                        for (index in 1 until points.size) {
                            drawLine(
                                color = ink,
                                start = points[index - 1],
                                end = points[index],
                                strokeWidth = strokeWidthPx,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                    strokes.forEach { line(it) }
                    line(live.toList())
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DocScanChip(active = false, onClick = {
                    strokes.clear()
                    live.clear()
                }) { DocScanLabel("Limpiar") }
                Spacer(Modifier.weight(1f))
                DocScanChip(active = false, onClick = onCancel) { DocScanLabel("Cancelar") }
                DocScanChip(active = true, enabled = strokes.isNotEmpty(), onClick = {
                    val bitmap = docScanSignatureBitmap(strokes.toList(), strokeWidthPx)
                    if (bitmap != null) onDone(bitmap) else onCancel()
                }) {
                    Text("Usar", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

/** Pasa los trazos a una imagen recortada justo al tamaño de la firma. */
private fun docScanSignatureBitmap(strokes: List<List<Offset>>, strokeWidthPx: Float): Bitmap? {
    val points = strokes.flatten()
    if (points.size < 2) return null
    val margin = strokeWidthPx * 2f + 4f
    val left = points.minOf { it.x } - margin
    val top = points.minOf { it.y } - margin
    val width = (points.maxOf { it.x } + margin - left).roundToInt().coerceIn(8, 4000)
    val height = (points.maxOf { it.y } + margin - top).roundToInt().coerceIn(8, 4000)
    return runCatching {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = DocScanSignatureInk
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = strokeWidthPx
            strokeCap = android.graphics.Paint.Cap.ROUND
            strokeJoin = android.graphics.Paint.Join.ROUND
        }
        strokes.forEach { stroke ->
            if (stroke.size < 2) return@forEach
            val path = android.graphics.Path()
            path.moveTo(stroke[0].x - left, stroke[0].y - top)
            for (index in 1 until stroke.size) path.lineTo(stroke[index].x - left, stroke[index].y - top)
            canvas.drawPath(path, paint)
        }
        bitmap
    }.getOrNull()
}
