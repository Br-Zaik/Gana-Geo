package com.ganageo.app.ui.tools

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FloatExponentialDecaySpec
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.unit.Velocity
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Zoom tipo galería para la hoja.
 *
 * La hoja se dibuja una sola vez a su tamaño "encajado" y se agranda/mueve con
 * una transformación de la tarjeta gráfica (graphicsLayer). Así el zoom y el
 * arrastre no vuelven a armar la pantalla: van fluidos a 60 cuadros.
 *
 * pantalla = contenido × scale + offset
 */
@Stable
internal class DocScanZoomState {
    var scale by mutableFloatStateOf(1f)
        private set
    var offsetX by mutableFloatStateOf(0f)
        private set
    var offsetY by mutableFloatStateOf(0f)
        private set

    private var viewWidth = 0f
    private var viewHeight = 0f
    var contentWidth = 0f
        private set
    var contentHeight = 0f
        private set

    val maxScale = 6f

    private var pageKey = Int.MIN_VALUE

    /** Se llama al armar la pantalla. Si cambió la página o su tamaño, vuelve a encajarla. */
    fun setSizes(page: Int, viewW: Float, viewH: Float, contentW: Float, contentH: Float) {
        val contentChanged = page != pageKey ||
            abs(contentW - contentWidth) > 0.5f || abs(contentH - contentHeight) > 0.5f
        pageKey = page
        val viewChanged = abs(viewW - viewWidth) > 0.5f || abs(viewH - viewHeight) > 0.5f
        viewWidth = viewW
        viewHeight = viewH
        contentWidth = contentW
        contentHeight = contentH
        if (contentChanged) {
            set(1f, 0f, 0f)
        } else if (viewChanged) {
            set(scale, offsetX, offsetY)
        }
    }

    /** Lleva un punto de la pantalla a la hoja (en píxeles de la hoja encajada). */
    fun toContent(point: Offset): Offset = Offset((point.x - offsetX) / scale, (point.y - offsetY) / scale)

    /** Centro de lo que se ve, en píxeles de la hoja encajada. */
    fun visibleCenter(): Offset = toContent(Offset(viewWidth / 2f, viewHeight / 2f))

    private fun clamped(targetScale: Float, x: Float, y: Float): Offset {
        val width = contentWidth * targetScale
        val height = contentHeight * targetScale
        val clampedX = if (width <= viewWidth) (viewWidth - width) / 2f else x.coerceIn(viewWidth - width, 0f)
        val clampedY = if (height <= viewHeight) (viewHeight - height) / 2f else y.coerceIn(viewHeight - height, 0f)
        return Offset(clampedX, clampedY)
    }

    private fun set(targetScale: Float, x: Float, y: Float) {
        val safeScale = targetScale.coerceIn(0.85f, maxScale)
        val position = clamped(safeScale, x, y)
        scale = safeScale
        offsetX = position.x
        offsetY = position.y
    }

    /** Pellizco: agranda manteniendo quieto el punto entre los dedos. */
    fun zoomBy(factor: Float, centroid: Offset, pan: Offset) {
        val newScale = (scale * factor).coerceIn(0.85f, maxScale)
        val ratio = newScale / scale
        set(
            newScale,
            centroid.x - (centroid.x - offsetX) * ratio + pan.x,
            centroid.y - (centroid.y - offsetY) * ratio + pan.y
        )
    }

    fun panBy(pan: Offset) {
        set(scale, offsetX + pan.x, offsetY + pan.y)
    }

    /** Inercia al soltar el dedo, como en la galería. */
    suspend fun fling(velocity: Velocity) {
        val speed = hypot(velocity.x, velocity.y)
        if (speed < 60f) return
        val directionX = velocity.x / speed
        val directionY = velocity.y / speed
        var last = 0f
        animateDecay(0f, speed, FloatExponentialDecaySpec(frictionMultiplier = 1.6f)) { value, _ ->
            val delta = value - last
            last = value
            set(scale, offsetX + directionX * delta, offsetY + directionY * delta)
        }
    }

    private suspend fun animateTo(targetScale: Float, targetX: Float, targetY: Float) {
        val startScale = scale
        val startX = offsetX
        val startY = offsetY
        val endScale = targetScale.coerceIn(1f, maxScale)
        val end = clamped(endScale, targetX, targetY)
        animate(0f, 1f, animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing)) { progress, _ ->
            scale = startScale + (endScale - startScale) * progress
            offsetX = startX + (end.x - startX) * progress
            offsetY = startY + (end.y - startY) * progress
        }
        set(endScale, end.x, end.y)
    }

    /** Vuelve a ver la hoja completa. */
    suspend fun animateToFit() {
        animateTo(1f, 0f, 0f)
    }

    /** Doble toque: acerca donde se tocó o vuelve a la hoja completa. */
    suspend fun toggleAt(point: Offset) {
        if (scale > 1.2f) {
            animateToFit()
        } else {
            val target = 2.6f
            val content = toContent(point)
            animateTo(target, point.x - content.x * target, point.y - content.y * target)
        }
    }

    /**
     * Deja a la vista una parte de la hoja (en píxeles de la hoja encajada), por
     * ejemplo el renglón que se está editando cuando sale el teclado.
     */
    suspend fun reveal(area: Rect, readableWidthShare: Float = 0.85f) {
        if (viewWidth <= 0f || viewHeight <= 0f || area.width <= 0f) return
        // Si el renglón se ve muy chico, se acerca hasta que se lea bien (sin pasarse).
        val wanted = (viewWidth * readableWidthShare / area.width).coerceIn(1f, 2.8f)
        val targetScale = max(scale, min(wanted, maxScale))
        val screenLeft = area.left * scale + offsetX
        val screenTop = area.top * scale + offsetY
        val screenRight = area.right * scale + offsetX
        val screenBottom = area.bottom * scale + offsetY
        val margin = 24f
        val visible = targetScale == scale &&
            screenLeft >= -margin && screenRight <= viewWidth + margin &&
            screenTop >= margin && screenBottom <= viewHeight - margin
        if (visible) return
        animateTo(
            targetScale,
            viewWidth / 2f - area.center.x * targetScale,
            viewHeight * 0.4f - area.center.y * targetScale
        )
    }
}
