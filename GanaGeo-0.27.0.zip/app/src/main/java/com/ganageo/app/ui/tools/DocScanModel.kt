package com.ganageo.app.ui.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.InkLook
import com.ganageo.app.tools.OcrLine
import com.ganageo.app.tools.OcrTextRefiner
import com.ganageo.app.tools.ScanLook
import com.ganageo.app.tools.ToolFileUtils
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.pdmodel.graphics.state.RenderingMode
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Escáner de documentos (hecho desde cero).
//
// Idea: la hoja es SIEMPRE la foto original, idéntica. El texto que se lee
// con el lector de Google queda "debajo" como cajas invisibles. Solo cuando la
// persona cambia un renglón, ese renglón se tapa con el color del papel y se
// escribe el texto nuevo encima, con el color, tamaño y grosor del original.
// Todo lo que no se toca queda igual al original, punto por punto.
// ---------------------------------------------------------------------------

/** Lado más largo con que se trabaja cada página (lectura, vista y guardado). */
internal const val DOC_SCAN_PAGE_EDGE = 2200
internal const val DOC_SCAN_THUMB_EDGE = 256
internal const val DOC_SCAN_MAX_PAGES = 20
internal const val DOC_SCAN_DOCX_MIME =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

private const val DOC_SCAN_DESCENDERS = "gjpqyQ,;()[]{}|"

/** Una página del documento: la foto tal como llegó. */
internal data class DocScanPage(val id: Int, val uri: Uri)

/** Renglón leído: texto y caja (de 0 a 1 sobre la página) con su aspecto en la foto. */
internal data class DocScanLine(
    val id: Int,
    val text: String,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val background: Int,
    val ink: Int,
    val bold: Boolean,
    val centered: Boolean
)

/** Resultado de leer una página. */
internal class DocScanAnalysis(
    val width: Int,
    val height: Int,
    val lines: List<DocScanLine>,
    val failed: Boolean = false
)

/** Cambio hecho por la persona a un renglón leído. */
internal data class DocScanLineEdit(
    val text: String,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val scale: Float = 1f,
    val deleted: Boolean = false
)

/** Texto nuevo agregado en la hoja. x = borde izquierdo, y = línea base (de 0 a 1). */
internal data class DocScanAddedText(
    val id: Int,
    val x: Float,
    val y: Float,
    val text: String,
    /** Tamaño de la letra como fracción del alto de la página. */
    val size: Float,
    val color: Int,
    val bold: Boolean = false,
    val italic: Boolean = false
)

/** Firma o imagen pegada. x, y = esquina de arriba a la izquierda; width = fracción del ancho. */
internal class DocScanSign(
    val id: Int,
    val x: Float,
    val y: Float,
    val width: Float,
    val bitmap: Bitmap
) {
    fun movedBy(dx: Float, dy: Float) =
        DocScanSign(id, (x + dx).coerceIn(-0.2f, 0.98f), (y + dy).coerceIn(-0.2f, 0.98f), width, bitmap)

    fun resizedBy(factor: Float) = DocScanSign(id, x, y, (width * factor).coerceIn(0.05f, 1f), bitmap)
}

/** Todo lo que se cambió en una página. */
internal data class DocScanPageEdits(
    val lines: Map<Int, DocScanLineEdit> = emptyMap(),
    val texts: List<DocScanAddedText> = emptyList(),
    val signs: List<DocScanSign> = emptyList()
) {
    val isEmpty: Boolean get() = lines.isEmpty() && texts.isEmpty() && signs.isEmpty()
}

// ---------------------------------------------------------------------------
// Lectura
// ---------------------------------------------------------------------------

private suspend fun docScanRecognize(bitmap: Bitmap): Text = suspendCancellableCoroutine { continuation ->
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    val closed = java.util.concurrent.atomic.AtomicBoolean(false)
    fun closeRecognizer() {
        if (closed.compareAndSet(false, true)) recognizer.close()
    }
    val task = recognizer.process(InputImage.fromBitmap(bitmap, 0))
    task.addOnSuccessListener { result ->
        if (continuation.isActive) continuation.resume(result)
    }
    task.addOnFailureListener { error ->
        if (continuation.isActive) continuation.resumeWithException(error)
    }
    task.addOnCanceledListener {
        if (continuation.isActive) continuation.cancel()
    }
    task.addOnCompleteListener { closeRecognizer() }
    continuation.invokeOnCancellation { closeRecognizer() }
}

/** Lee el texto de la página y el aspecto de cada renglón. Todo en el celular. */
internal suspend fun docScanAnalyze(bitmap: Bitmap): DocScanAnalysis {
    val result = try {
        docScanRecognize(bitmap)
    } catch (cancelled: kotlinx.coroutines.CancellationException) {
        throw cancelled
    } catch (error: Throwable) {
        return DocScanAnalysis(bitmap.width, bitmap.height, emptyList(), failed = true)
    }
    return withContext(Dispatchers.Default) {
        val width = bitmap.width
        val height = bitmap.height
        val texts = ArrayList<String>()
        val boxes = ArrayList<android.graphics.Rect>()
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val raw = line.boundingBox ?: continue
                val text = OcrTextRefiner.fixLine(line.text)
                if (text.isBlank()) continue
                val box = android.graphics.Rect(raw)
                if (!box.intersect(0, 0, width, height) || box.width() < 2 || box.height() < 2) continue
                texts += text
                boxes += box
            }
        }
        val looks = ArrayList<InkLook>(boxes.size)
        for (box in boxes) {
            val pad = max(3, box.height() / 3)
            val left = max(0, box.left - pad)
            val top = max(0, box.top - pad)
            val right = min(width, box.right + pad)
            val bottom = min(height, box.bottom + pad)
            val zoneWidth = right - left
            val zoneHeight = bottom - top
            val look = runCatching {
                val pixels = IntArray(zoneWidth * zoneHeight)
                bitmap.getPixels(pixels, 0, zoneWidth, left, top, zoneWidth, zoneHeight)
                ScanLook.measure(
                    pixels,
                    zoneWidth,
                    zoneHeight,
                    box.left - left,
                    box.top - top,
                    box.right - left,
                    box.bottom - top
                )
            }.getOrElse { InkLook(android.graphics.Color.WHITE, android.graphics.Color.BLACK, 0f) }
            looks += look
        }
        val bold = ScanLook.boldFlags(
            FloatArray(boxes.size) { looks[it].stroke },
            FloatArray(boxes.size) { boxes[it].height().toFloat() }
        )
        val lines = boxes.mapIndexed { index, box ->
            val center = (box.left + box.right) / 2f / width
            DocScanLine(
                id = index,
                text = texts[index],
                left = box.left / width.toFloat(),
                top = box.top / height.toFloat(),
                right = box.right / width.toFloat(),
                bottom = box.bottom / height.toFloat(),
                background = looks[index].background,
                ink = looks[index].ink,
                bold = bold[index],
                centered = abs(center - 0.5f) < 0.025f && box.left > width * 0.12f
            )
        }
        DocScanAnalysis(width, height, lines)
    }
}

// ---------------------------------------------------------------------------
// Filtros de imagen (se aplican al dibujar: no se copia la foto)
// ---------------------------------------------------------------------------

/** Matriz de color del filtro (la misma que usa Imágenes a PDF), o null si es el original. */
internal fun docScanFilterMatrix(filter: DocumentImageFilter): FloatArray? {
    if (filter == DocumentImageFilter.ORIGINAL) return null
    val contrast = when (filter) {
        DocumentImageFilter.DOCUMENT -> 1.28f
        DocumentImageFilter.ENHANCE -> 1.08f
        else -> 1f
    }
    val saturation = when (filter) {
        DocumentImageFilter.GRAYSCALE, DocumentImageFilter.DOCUMENT -> 0f
        DocumentImageFilter.ENHANCE -> 1.18f
        else -> 1f
    }
    val matrix = ColorMatrix()
    matrix.setSaturation(saturation)
    val translate = (-0.5f * contrast + 0.5f) * 255f
    matrix.postConcat(
        ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )
    return matrix.array.copyOf()
}

// ---------------------------------------------------------------------------
// Dibujo de lo editado (sirve igual para la pantalla y para el archivo)
// ---------------------------------------------------------------------------

internal fun docScanTypeface(serif: Boolean, bold: Boolean, italic: Boolean): Typeface {
    val style = when {
        bold && italic -> Typeface.BOLD_ITALIC
        bold -> Typeface.BOLD
        italic -> Typeface.ITALIC
        else -> Typeface.NORMAL
    }
    return Typeface.create(if (serif) Typeface.SERIF else Typeface.SANS_SERIF, style)
}

/** Dónde y de qué tamaño queda el texto nuevo de un renglón, y qué parte se tapa. */
internal class DocScanPlaced(
    val x: Float,
    val baseline: Float,
    val size: Float,
    val scaleX: Float,
    val textWidth: Float,
    val cover: RectF
)

/**
 * Calcula el texto nuevo de un renglón: mismo tamaño de letra que el original
 * (se mide con el texto original), misma línea base y mismo borde izquierdo
 * (o mismo centro si el renglón estaba centrado). Si el texto nuevo es más
 * largo, ocupa el espacio libre de la derecha; si no alcanza, se angosta un poco.
 */
internal fun docScanPlace(
    line: DocScanLine,
    edit: DocScanLineEdit,
    all: List<DocScanLine>,
    width: Float,
    height: Float,
    serif: Boolean,
    paint: Paint
): DocScanPlaced {
    val left = line.left * width
    val top = line.top * height
    val right = line.right * width
    val bottom = line.bottom * height
    val boxHeight = (bottom - top).coerceAtLeast(1f)

    paint.textScaleX = 1f
    paint.typeface = docScanTypeface(serif, line.bold, false)
    paint.textSize = 100f
    val originalWidth = paint.measureText(line.text).coerceAtLeast(1f)
    var size = (100f * (right - left) / originalWidth).coerceIn(boxHeight * 0.55f, boxHeight * 1.4f)
    size *= edit.scale.coerceIn(0.4f, 3f)

    // Espacio libre a la derecha: hasta el siguiente renglón de la misma altura o el borde.
    var limit = width - width * 0.01f
    for (other in all) {
        if (other.id == line.id) continue
        val otherTop = other.top * height
        val otherBottom = other.bottom * height
        val overlap = min(bottom, otherBottom) - max(top, otherTop)
        val otherLeft = other.left * width
        if (overlap > boxHeight * 0.4f && otherLeft >= right - boxHeight * 0.2f) {
            limit = min(limit, otherLeft - boxHeight * 0.3f)
        }
    }

    paint.typeface = docScanTypeface(serif, edit.bold, edit.italic)
    paint.textSize = size
    var scaleX = 1f
    var textWidth = if (edit.deleted) 0f else paint.measureText(edit.text)
    var x = if (line.centered) (left + right) / 2f - textWidth / 2f else left
    if (textWidth > 0f) {
        val available = if (line.centered) {
            // Centrado: crece parejo a los dos lados.
            2f * min((left + right) / 2f - width * 0.01f, limit - (left + right) / 2f)
        } else {
            limit - left
        }.coerceAtLeast(right - left)
        if (textWidth > available) {
            // Primero se angosta la letra (hasta 82 %) y después se achica.
            scaleX = (available / textWidth).coerceAtLeast(0.82f)
            textWidth *= scaleX
            if (textWidth > available) {
                val shrink = available / textWidth
                size *= shrink
                textWidth *= shrink
            }
            x = if (line.centered) (left + right) / 2f - textWidth / 2f else left
        }
    }
    paint.textSize = size
    paint.textScaleX = scaleX
    val hasDescender = line.text.any { it in DOC_SCAN_DESCENDERS }
    val baseline = if (hasDescender) bottom - paint.descent() * 0.8f else bottom - boxHeight * 0.04f
    val pad = max(1.5f, boxHeight * 0.16f)
    val cover = RectF(
        min(left, x) - pad,
        min(top - pad, baseline + paint.ascent() * 0.92f),
        max(right, x + textWidth) + pad,
        max(bottom + pad, baseline + paint.descent())
    )
    paint.textScaleX = 1f
    return DocScanPlaced(x, baseline, size, scaleX, textWidth, cover)
}

/** Caja de un texto agregado. */
internal fun docScanAddedBounds(text: DocScanAddedText, width: Float, height: Float, serif: Boolean, paint: Paint): RectF {
    paint.textScaleX = 1f
    paint.typeface = docScanTypeface(serif, text.bold, text.italic)
    paint.textSize = (text.size * height).coerceAtLeast(2f)
    val textWidth = paint.measureText(text.text.ifEmpty { " " })
    val x = text.x * width
    val y = text.y * height
    return RectF(x, y + paint.ascent(), x + textWidth, y + paint.descent())
}

/** Caja de una firma. */
internal fun docScanSignRect(sign: DocScanSign, width: Float, height: Float): RectF {
    val signWidth = sign.width * width
    val ratio = sign.bitmap.height.toFloat() / sign.bitmap.width.coerceAtLeast(1)
    val left = sign.x * width
    val top = sign.y * height
    return RectF(left, top, left + signWidth, top + signWidth * ratio)
}

/**
 * Dibuja lo editado encima de la foto: tapa cada renglón cambiado con el color
 * de su papel y escribe el texto nuevo. Los colores pasan por el mismo filtro
 * que la foto, para que todo combine.
 */
internal fun docScanDrawEdits(
    canvas: Canvas,
    width: Float,
    height: Float,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    serif: Boolean,
    filter: FloatArray?
) {
    if (edits.isEmpty) return
    val colorFilter = filter?.let { ColorMatrixColorFilter(it) }
    val fill = Paint().apply {
        style = Paint.Style.FILL
        this.colorFilter = colorFilter
    }
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
        this.colorFilter = colorFilter
    }

    if (analysis != null && edits.lines.isNotEmpty()) {
        val placedLines = ArrayList<Pair<DocScanLineEdit, DocScanPlaced>>()
        for (line in analysis.lines) {
            val edit = edits.lines[line.id] ?: continue
            val placed = docScanPlace(line, edit, analysis.lines, width, height, serif, paint)
            fill.color = line.background
            canvas.drawRect(placed.cover, fill)
            placedLines += edit to placed
        }
        // Los textos van después de tapar todo: un renglón no borra al de al lado.
        for ((edit, placed) in placedLines) {
            if (edit.deleted || edit.text.isBlank()) continue
            paint.typeface = docScanTypeface(serif, edit.bold, edit.italic)
            paint.textSize = placed.size
            paint.textScaleX = placed.scaleX
            paint.color = edit.color
            canvas.drawText(edit.text, placed.x, placed.baseline, paint)
        }
        paint.textScaleX = 1f
    }

    for (text in edits.texts) {
        if (text.text.isBlank()) continue
        paint.typeface = docScanTypeface(serif, text.bold, text.italic)
        paint.textSize = (text.size * height).coerceAtLeast(2f)
        paint.color = text.color
        canvas.drawText(text.text, text.x * width, text.y * height, paint)
    }

    // La firma no pasa por el filtro: queda con su tinta.
    val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    for (sign in edits.signs) {
        if (!sign.bitmap.isRecycled) canvas.drawBitmap(sign.bitmap, null, docScanSignRect(sign, width, height), imagePaint)
    }
}

/** Foto + filtro + lo editado, en una imagen nueva. La foto de origen no se toca. */
internal fun docScanCompose(
    source: Bitmap,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    serif: Boolean,
    filter: FloatArray?
): Bitmap {
    val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    canvas.drawColor(android.graphics.Color.WHITE)
    val photoPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = filter?.let { ColorMatrixColorFilter(it) }
    }
    canvas.drawBitmap(source, 0f, 0f, photoPaint)
    docScanDrawEdits(canvas, source.width.toFloat(), source.height.toFloat(), analysis, edits, serif, filter)
    return output
}

// ---------------------------------------------------------------------------
// Texto de la hoja (para copiar, compartir y Word)
// ---------------------------------------------------------------------------

/** Texto de la página en orden de lectura, con los cambios de la persona. */
internal fun docScanPageText(analysis: DocScanAnalysis?, edits: DocScanPageEdits): String {
    if (analysis == null) return ""
    val width = analysis.width.toFloat()
    val height = analysis.height.toFloat()
    val located = ArrayList<OcrLine>()
    for (line in analysis.lines) {
        val edit = edits.lines[line.id]
        if (edit?.deleted == true) continue
        val text = edit?.text ?: line.text
        if (text.isBlank()) continue
        located += OcrLine(
            text,
            (line.left * width).roundToInt(),
            (line.top * height).roundToInt(),
            (line.right * width).roundToInt(),
            (line.bottom * height).roundToInt()
        )
    }
    for (added in edits.texts) {
        if (added.text.isBlank()) continue
        val letter = added.size * height
        val left = (added.x * width).roundToInt()
        val bottom = (added.y * height + letter * 0.25f).roundToInt()
        val top = (added.y * height - letter * 0.8f).roundToInt()
        val right = left + (letter * 0.55f * added.text.length).roundToInt().coerceAtLeast(4)
        located += OcrLine(added.text, left, top, right, max(bottom, top + 2))
    }
    if (located.isEmpty()) return ""
    return runCatching { OcrTextRefiner.buildText(located, analysis.width) }
        .getOrElse { located.joinToString("\n") { it.text } }
}

// ---------------------------------------------------------------------------
// Guardado
// ---------------------------------------------------------------------------

/** Una página lista para guardar: su foto con los cambios, y su lectura. */
private suspend fun docScanPreparePage(
    context: Context,
    page: DocScanPage,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    serif: Boolean,
    filter: FloatArray?
): Pair<Bitmap, DocScanAnalysis> {
    val source = ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
    try {
        val read = analysis ?: docScanAnalyze(source)
        val composed = withContext(Dispatchers.Default) { docScanCompose(source, read, edits, serif, filter) }
        return composed to read
    } finally {
        if (!source.isRecycled) source.recycle()
    }
}

/**
 * PDF: cada página es la foto (con los cambios) y encima, invisible, el texto
 * leído en su lugar. Se ve idéntico y el texto se puede buscar, seleccionar y copiar.
 */
internal suspend fun docScanWritePdf(
    context: Context,
    output: OutputStream,
    pages: List<DocScanPage>,
    analyses: Map<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    serif: Boolean,
    filter: FloatArray?
) = withContext(Dispatchers.IO) {
    PDFBoxResourceLoader.init(context.applicationContext)
    PDDocument().use { document ->
        val font = PDType1Font.HELVETICA
        val encodable = HashMap<Char, Boolean>()
        fun clean(text: String): String = buildString {
            for (char in text) {
                val ok = encodable.getOrPut(char) { runCatching { font.encode(char.toString()); true }.getOrDefault(false) }
                append(if (ok) char else ' ')
            }
        }.trim()

        for (page in pages) {
            val pageEdits = edits[page.id] ?: DocScanPageEdits()
            val (composed, analysis) = docScanPreparePage(context, page, analyses[page.id], pageEdits, serif, filter)
            val imageWidth = composed.width
            val imageHeight = composed.height
            val bytes = try {
                ByteArrayOutputStream().also { composed.compress(Bitmap.CompressFormat.JPEG, 88, it) }.toByteArray()
            } finally {
                composed.recycle()
            }
            val ratio = imageWidth.toFloat() / imageHeight.coerceAtLeast(1)
            val pageWidth = if (ratio >= 1f) 842f else 842f * ratio
            val pageHeight = if (ratio >= 1f) 842f / ratio else 842f
            val pdfPage = PDPage(PDRectangle(pageWidth, pageHeight))
            document.addPage(pdfPage)
            val image = PDImageXObject.createFromByteArray(document, bytes, "pagina")

            // Texto invisible: los renglones (con lo editado) y los textos agregados.
            val entries = ArrayList<Pair<String, RectF>>()
            for (line in analysis.lines) {
                val edit = pageEdits.lines[line.id]
                if (edit?.deleted == true) continue
                val text = edit?.text ?: line.text
                entries += text to RectF(line.left, line.top, line.right, line.bottom)
            }
            for (added in pageEdits.texts) {
                val letter = added.size
                val approxWidth = letter * 0.55f * added.text.length * pageHeight / pageWidth
                entries += added.text to RectF(added.x, added.y - letter * 0.8f, added.x + approxWidth, added.y + letter * 0.2f)
            }

            PDPageContentStream(document, pdfPage).use { stream ->
                stream.drawImage(image, 0f, 0f, pageWidth, pageHeight)
                for ((text, box) in entries) {
                    val cleaned = clean(text)
                    if (cleaned.isEmpty()) continue
                    val units = runCatching { font.getStringWidth(cleaned) }.getOrDefault(0f)
                    if (units <= 0f) continue
                    val boxWidth = (box.right - box.left) * pageWidth
                    val boxHeight = (box.bottom - box.top) * pageHeight
                    if (boxWidth <= 0f || boxHeight <= 0f) continue
                    val size = (boxWidth * 1000f / units).coerceIn(1f, max(2f, boxHeight * 2f))
                    runCatching {
                        stream.beginText()
                        stream.setFont(font, size)
                        stream.setRenderingMode(RenderingMode.NEITHER)
                        stream.newLineAtOffset(box.left * pageWidth, pageHeight - box.bottom * pageHeight + boxHeight * 0.15f)
                        stream.showText(cleaned)
                        stream.endText()
                    }
                }
            }
        }
        document.save(output)
    }
}

/** Imagen JPG de una página, idéntica a lo que se ve. */
internal suspend fun docScanWriteImage(
    context: Context,
    output: OutputStream,
    page: DocScanPage,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    serif: Boolean,
    filter: FloatArray?
) = withContext(Dispatchers.IO) {
    val (composed, _) = docScanPreparePage(context, page, analysis, edits, serif, filter)
    try {
        check(composed.compress(Bitmap.CompressFormat.JPEG, 92, output)) { "No se pudo guardar la imagen" }
    } finally {
        composed.recycle()
    }
}

/** Lee las páginas que falten (para Word y para copiar el texto de todas). */
internal suspend fun docScanEnsureAnalyses(
    context: Context,
    pages: List<DocScanPage>,
    known: Map<Int, DocScanAnalysis>
): Map<Int, DocScanAnalysis> {
    val result = HashMap(known)
    for (page in pages) {
        if (result[page.id] != null) continue
        val source = ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
        try {
            result[page.id] = docScanAnalyze(source)
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }
    return result
}

/** Texto de todas las páginas, separadas. */
internal fun docScanAllText(
    pages: List<DocScanPage>,
    analyses: Map<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>
): String {
    if (pages.size == 1) {
        val page = pages.first()
        return docScanPageText(analyses[page.id], edits[page.id] ?: DocScanPageEdits())
    }
    return pages.mapIndexed { index, page ->
        "— Página ${index + 1} —\n\n" + docScanPageText(analyses[page.id], edits[page.id] ?: DocScanPageEdits())
    }.joinToString("\n\n")
}

private fun docScanXml(value: String): String = value
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")
    .filter { it == '\t' || it == '\n' || it >= ' ' }

private fun docScanZip(zip: ZipOutputStream, name: String, text: String) {
    zip.putNextEntry(ZipEntry(name))
    zip.write(text.toByteArray(Charsets.UTF_8))
    zip.closeEntry()
}

/**
 * Word (.docx) armado a mano, sin librerías: el texto de cada página en orden,
 * en párrafos que se pueden editar. Cada página empieza en una hoja nueva.
 */
internal fun docScanWriteDocx(output: OutputStream, pageTexts: List<String>, serif: Boolean) {
    val font = if (serif) "Times New Roman" else "Arial"
    val runProperties = "<w:rPr><w:rFonts w:ascii=\"$font\" w:hAnsi=\"$font\" w:cs=\"$font\"/>" +
        "<w:sz w:val=\"22\"/><w:szCs w:val=\"22\"/></w:rPr>"
    val body = StringBuilder()
    pageTexts.forEachIndexed { pageIndex, pageText ->
        if (pageIndex > 0) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
        val paragraphs = pageText.split(Regex("\\n{2,}")).filter { it.isNotBlank() }
        if (paragraphs.isEmpty()) body.append("<w:p/>")
        for (paragraph in paragraphs) {
            body.append("<w:p><w:pPr><w:spacing w:after=\"160\"/></w:pPr>")
            paragraph.trim().split('\n').forEachIndexed { lineIndex, line ->
                if (lineIndex > 0) body.append("<w:r><w:br/></w:r>")
                body.append("<w:r>").append(runProperties)
                body.append("<w:t xml:space=\"preserve\">").append(docScanXml(line)).append("</w:t></w:r>")
            }
            body.append("</w:p>")
        }
    }
    val documentXml =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
            "<w:body>" + body +
            "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
            "<w:pgMar w:top=\"1418\" w:right=\"1418\" w:bottom=\"1418\" w:left=\"1418\" w:header=\"709\" w:footer=\"709\" w:gutter=\"0\"/>" +
            "</w:sectPr></w:body></w:document>"
    val types =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"
    val rootRels =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"
    ZipOutputStream(output).use { zip ->
        docScanZip(zip, "[Content_Types].xml", types)
        docScanZip(zip, "_rels/.rels", rootRels)
        docScanZip(zip, "word/document.xml", documentXml)
    }
}

/**
 * Copia las páginas del escáner de Google a la carpeta temporal de la app.
 * El escáner borra sus archivos en el siguiente escaneo; con la copia no se pierden.
 */
internal suspend fun docScanCopyToCache(context: Context, sources: List<Uri>): List<Uri> = withContext(Dispatchers.IO) {
    val directory = java.io.File(context.cacheDir, "camera").apply { mkdirs() }
    val stamp = System.currentTimeMillis()
    val copied = ArrayList<Uri>()
    sources.forEachIndexed { index, source ->
        val target = java.io.File(directory, "docscan_${stamp}_${index + 1}.jpg")
        val ok = runCatching {
            context.contentResolver.openInputStream(source)?.use { input ->
                target.outputStream().use { out -> input.copyTo(out) }
            } != null
        }.getOrDefault(false)
        if (ok && target.length() > 0L) {
            copied += androidx.core.content.FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                target
            )
        }
    }
    copied
}

/** Borra las copias de escaneos viejos (de otras sesiones). */
internal suspend fun docScanCleanCache(context: Context, keep: Set<String>) = withContext(Dispatchers.IO) {
    val directory = java.io.File(context.cacheDir, "camera")
    directory.listFiles()?.forEach { file ->
        if (file.name.startsWith("docscan_") && file.name !in keep) runCatching { file.delete() }
    }
}
