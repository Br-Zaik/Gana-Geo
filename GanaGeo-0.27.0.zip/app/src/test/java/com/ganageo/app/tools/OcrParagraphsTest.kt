package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Test

class OcrParagraphsTest {

    @Test
    fun juntaElTituloDeDosLineasEnUnParrafo() {
        val lines = listOf(
            OcrLine("1.- ¿QUE ES LA TOPOGRAFIA?", 50, 300, 400, 330),
            OcrLine("TOPOGRAFIA SUPERFICIAL", 400, 140, 600, 170),
            OcrLine("PRIMER EXAMEN DE LA UNIDAD DIDACTICA DE", 300, 100, 700, 130),
            OcrLine("NOMBRE Y APELLIDO:", 50, 220, 300, 250)
        )
        val groups = OcrTextRefiner.paragraphs(lines, 1000) { _, _ -> true }.map { it.toList() }
        assertEquals(listOf(listOf(2, 1), listOf(3), listOf(0)), groups)
    }

    @Test
    fun estiloDistintoSeparaLosRenglones() {
        val lines = listOf(
            OcrLine("PRIMER EXAMEN DE LA UNIDAD DIDACTICA DE", 300, 100, 700, 130),
            OcrLine("TOPOGRAFIA SUPERFICIAL", 400, 140, 600, 170)
        )
        val groups = OcrTextRefiner.paragraphs(lines, 1000) { _, _ -> false }.map { it.toList() }
        assertEquals(listOf(listOf(0), listOf(1)), groups)
    }

    @Test
    fun reconoceJustificadoYCentrado() {
        val justified = listOf(
            OcrLine("uno", 100, 100, 900, 130),
            OcrLine("dos", 100, 140, 900, 170),
            OcrLine("tres", 100, 180, 600, 210)
        )
        assertEquals(OcrTextRefiner.ALIGN_JUSTIFY, OcrTextRefiner.alignmentOf(justified, 1000))
        val centered = listOf(
            OcrLine("uno", 300, 100, 700, 130),
            OcrLine("dos", 400, 140, 600, 170)
        )
        assertEquals(OcrTextRefiner.ALIGN_CENTER, OcrTextRefiner.alignmentOf(centered, 1000))
    }
}
