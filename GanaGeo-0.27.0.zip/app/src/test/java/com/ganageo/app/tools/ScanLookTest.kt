package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanLookTest {
    private fun rgb(r: Int, g: Int, b: Int): Int = -0x1000000 or (r shl 16) or (g shl 8) or b

    @Test
    fun leePapelYLetraDeUnaHojaCrema() {
        val width = 60
        val height = 20
        val paper = rgb(245, 240, 230)
        val ink = rgb(40, 40, 48)
        val pixels = IntArray(width * height) { paper }
        for (y in 4 until 16) {
            var x = 5
            while (x + 2 <= 55) {
                pixels[y * width + x] = ink
                pixels[y * width + x + 1] = ink
                x += 6
            }
        }
        val look = ScanLook.measure(pixels, width, height, 5, 4, 55, 16)
        assertEquals(paper, look.background)
        assertEquals(ink, look.ink)
        assertEquals(2f, look.stroke, 0.01f)
    }

    @Test
    fun leeLetraBlancaSobreBarraAzul() {
        val width = 60
        val height = 20
        val blue = rgb(20, 60, 140)
        val white = rgb(255, 255, 255)
        val pixels = IntArray(width * height) { blue }
        for (y in 4 until 16) {
            var x = 5
            while (x + 3 <= 55) {
                for (k in 0 until 3) pixels[y * width + x + k] = white
                x += 7
            }
        }
        val look = ScanLook.measure(pixels, width, height, 5, 4, 55, 16)
        assertEquals(blue, look.background)
        assertEquals(white, look.ink)
    }

    @Test
    fun marcaNegritaSoloAlTrazoGrueso() {
        val bold = ScanLook.boldFlags(
            floatArrayOf(2f, 2f, 2.1f, 3.6f, 2f),
            floatArrayOf(20f, 20f, 20f, 20f, 20f)
        )
        assertFalse(bold[0])
        assertTrue(bold[3])
        assertFalse(bold[4])
    }
}
