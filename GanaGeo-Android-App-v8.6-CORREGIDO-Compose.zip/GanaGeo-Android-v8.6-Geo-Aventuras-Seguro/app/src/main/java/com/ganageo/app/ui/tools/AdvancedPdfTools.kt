package com.ganageo.app.ui.tools

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.AdvancedFileUtils
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.ImagesToPdfOptions
import com.ganageo.app.tools.PageSelectionParser
import com.ganageo.app.tools.PdfCompression
import com.ganageo.app.tools.PdfImageFit
import com.ganageo.app.tools.PdfImagePage
import com.ganageo.app.tools.PdfMargin
import com.ganageo.app.tools.PdfOrientation
import com.ganageo.app.tools.PdfPaperSize
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch

@Composable
fun DocumentScannerScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val pages = remember { mutableStateListOf<PdfImagePage>() }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var autoCrop by rememberSaveable { mutableStateOf(true) }
    var filterIndex by rememberSaveable { mutableIntStateOf(DocumentImageFilter.DOCUMENT.ordinal) }
    var brightness by rememberSaveable { mutableFloatStateOf(5f) }
    var contrast by rememberSaveable { mutableFloatStateOf(1.12f) }
    var paperIndex by rememberSaveable { mutableIntStateOf(PdfPaperSize.A4.ordinal) }
    var compressionIndex by rememberSaveable { mutableIntStateOf(PdfCompression.NORMAL.ordinal) }
    var passwordEnabled by rememberSaveable { mutableStateOf(false) }
    var password by rememberSaveable { mutableStateOf("") }
    var outputName by rememberSaveable { mutableStateOf("escaneo_gana_geo.pdf") }
    var processing by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected ->
        val remaining = (ToolFileUtils.MAX_IMAGES_PER_PDF - pages.size).coerceAtLeast(0)
        pages += selected.take(remaining).map(::PdfImagePage)
        if (selected.size > remaining) onMessage("Máximo ${ToolFileUtils.MAX_IMAGES_PER_PDF} páginas")
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingCameraUri?.let { pages += PdfImagePage(it) }
        pendingCameraUri = null
    }
    fun openCamera() {
        runCatching { ToolFileUtils.createCameraImageUri(context) }
            .onSuccess { pendingCameraUri = it; camera.launch(it) }
            .onFailure { onMessage(it.message ?: "No se pudo abrir la cámara") }
    }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openCamera() else onMessage("Se necesita permiso de cámara")
    }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        if (output == null || pages.isEmpty()) return@rememberLauncherForActivityResult
        processing = true
        progress = 0f
        scope.launch {
            val options = ImagesToPdfOptions(
                paperSize = PdfPaperSize.entries[paperIndex],
                orientation = PdfOrientation.AUTOMATIC,
                margin = PdfMargin.NORMAL,
                compression = PdfCompression.entries[compressionIndex],
                fit = PdfImageFit.CONTAIN,
                filter = DocumentImageFilter.entries[filterIndex],
                brightness = brightness.toInt(),
                contrast = contrast,
                password = password.takeIf { passwordEnabled }
            )
            runPaidTool(viewModel, tool) {
                AdvancedFileUtils.createScannedPdf(context, pages.toList(), output, options, autoCrop) { done, total ->
                    scope.launch { progress = done.toFloat() / total.coerceAtLeast(1) }
                }
            }.onSuccess { onMessage(successMessage("Escaneo PDF creado con ${pages.size} páginas", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo crear el escaneo") }
            processing = false
        }
    }

    AdvancedToolPage(tool, onBack) {
        AdvancedSection("1. Captura y organización") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f), enabled = !processing) {
                    Icon(Icons.Rounded.Folder, null); Text(" Galería")
                }
                OutlinedButton(onClick = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openCamera()
                    else cameraPermission.launch(Manifest.permission.CAMERA)
                }, modifier = Modifier.weight(1f), enabled = !processing) {
                    Icon(Icons.Rounded.AddAPhoto, null); Text(" Cámara")
                }
            }
            Text("${pages.size} páginas seleccionadas", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        itemsIndexed(pages, key = { index, page -> "$index-${page.uri}" }) { index, page ->
            Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Description, null, tint = NeonGreen)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Página ${index + 1}", fontWeight = FontWeight.Bold)
                        Text(ToolFileUtils.displayName(context, page.uri), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                    IconButton(onClick = { pages[index] = page.copy(rotationDegrees = (page.rotationDegrees + 90) % 360) }) { Icon(Icons.Rounded.RotateRight, "Girar") }
                    IconButton(onClick = {
                        if (index > 0) { val item = pages.removeAt(index); pages.add(index - 1, item) }
                    }, enabled = index > 0) { Icon(Icons.Rounded.ArrowUpward, "Subir") }
                    IconButton(onClick = {
                        if (index < pages.lastIndex) { val item = pages.removeAt(index); pages.add(index + 1, item) }
                    }, enabled = index < pages.lastIndex) { Icon(Icons.Rounded.ArrowDownward, "Bajar") }
                    IconButton(onClick = { pages.removeAt(index) }) { Icon(Icons.Rounded.Delete, "Eliminar") }
                }
            }
        }
        AdvancedSection("2. Mejora del documento") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Recorte automático de bordes", modifier = Modifier.weight(1f))
                Switch(checked = autoCrop, onCheckedChange = { autoCrop = it })
            }
            SimpleDropdown("Filtro", DocumentImageFilter.entries.map { it.label }, filterIndex) { filterIndex = it }
            Text("Brillo: ${brightness.toInt()}")
            Slider(brightness, { brightness = it }, valueRange = -40f..40f)
            Text("Contraste: ${"%.2f".format(contrast)}")
            Slider(contrast, { contrast = it }, valueRange = 0.7f..1.6f)
        }
        AdvancedSection("3. PDF y seguridad") {
            SimpleDropdown("Papel", PdfPaperSize.entries.map { it.label }, paperIndex) { paperIndex = it }
            SimpleDropdown("Compresión", PdfCompression.entries.map { "${it.label} · ${it.detail}" }, compressionIndex) { compressionIndex = it }
            OutlinedTextField(outputName, { outputName = it.replace(Regex("[\\/:*?\"<>|]"), "_").take(80) }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(passwordEnabled, { passwordEnabled = it }); Icon(Icons.Rounded.Lock, null, tint = Gold); Text(" Proteger con contraseña")
            }
            if (passwordEnabled) OutlinedTextField(password, { password = it.take(40) }, label = { Text("Contraseña") }, modifier = Modifier.fillMaxWidth())
        }
        if (processing) {
            item { AdvancedProgress("Procesando escaneo", progress) }
        }
        item {
            Button(
                onClick = {
                    if (passwordEnabled && password.length < 4) onMessage("La contraseña debe tener al menos 4 caracteres")
                    else launchPaidExport(viewModel, tool, onMessage) {
                        val clean = outputName.trim().ifBlank { "escaneo_gana_geo.pdf" }
                        save.launch(if (clean.endsWith(".pdf", true)) clean else "$clean.pdf")
                    }
                },
                enabled = pages.isNotEmpty() && !processing,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
            ) { Icon(Icons.Rounded.PictureAsPdf, null); Text(" Crear escaneo PDF · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold) }
        }
        item {
            Text("El recorte usa procesamiento tradicional en el teléfono; puedes desactivarlo cuando el fondo sea parecido al documento.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun TextToPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by rememberSaveable { mutableStateOf("") }
    var author by rememberSaveable { mutableStateOf("") }
    var body by rememberSaveable { mutableStateOf("") }
    var header by rememberSaveable { mutableStateOf("") }
    var paperIndex by rememberSaveable { mutableIntStateOf(PdfPaperSize.A4.ordinal) }
    var orientationIndex by rememberSaveable { mutableIntStateOf(PdfOrientation.PORTRAIT.ordinal) }
    var marginIndex by rememberSaveable { mutableIntStateOf(PdfMargin.NORMAL.ordinal) }
    var fontSize by rememberSaveable { mutableFloatStateOf(12f) }
    var pageNumbers by rememberSaveable { mutableStateOf(true) }
    var name by rememberSaveable { mutableStateOf("documento_texto.pdf") }
    var processing by remember { mutableStateOf(false) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        if (output == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                AdvancedFileUtils.createTextPdf(context, output, body, AdvancedFileUtils.TextPdfOptions(
                    title, author, fontSize, 1.35f, PdfPaperSize.entries[paperIndex], PdfOrientation.entries[orientationIndex], PdfMargin.entries[marginIndex], pageNumbers, header
                ))
            }.onSuccess { onMessage(successMessage("Documento PDF creado", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo crear el PDF") }
            processing = false
        }
    }
    AdvancedToolPage(tool, onBack) {
        AdvancedSection("Contenido") {
            OutlinedTextField(title, { title = it.take(180) }, label = { Text("Título (opcional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(author, { author = it.take(160) }, label = { Text("Autor (opcional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(header, { header = it.take(180) }, label = { Text("Encabezado (opcional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(body, { body = it.take(300_000) }, label = { Text("Texto") }, placeholder = { Text("Escribe o pega tu trabajo...") }, modifier = Modifier.fillMaxWidth().height(260.dp))
            Text("${body.length} caracteres", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        AdvancedSection("Formato") {
            SimpleDropdown("Papel", PdfPaperSize.entries.map { it.label }, paperIndex) { paperIndex = it }
            SimpleDropdown("Orientación", PdfOrientation.entries.map { it.label }, orientationIndex) { orientationIndex = it }
            SimpleDropdown("Márgenes", PdfMargin.entries.map { it.label }, marginIndex) { marginIndex = it }
            Text("Tamaño de letra: ${fontSize.toInt()} pt")
            Slider(fontSize, { fontSize = it }, valueRange = 9f..22f, steps = 12)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Numerar páginas", modifier = Modifier.weight(1f)); Switch(pageNumbers, { pageNumbers = it }) }
            OutlinedTextField(name, { name = it.replace(Regex("[\\/:*?\"<>|]"), "_").take(80) }, label = { Text("Nombre del archivo") }, modifier = Modifier.fillMaxWidth())
        }
        if (processing) {
            item { AdvancedProgress("Creando documento", null) }
        }
        item {
            Button(onClick = {
                if (body.isBlank()) onMessage("Escribe el contenido") else launchPaidExport(viewModel, tool, onMessage) {
                    val clean = name.trim().ifBlank { "documento_texto.pdf" }
                    save.launch(if (clean.endsWith(".pdf", true)) clean else "$clean.pdf")
                }
            }, enabled = body.isNotBlank() && !processing, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                Text("Crear PDF · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PdfWatermarkSecurityScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var modeIndex by rememberSaveable { mutableIntStateOf(0) }
    var watermark by rememberSaveable { mutableStateOf("GANA GEO") }
    var positionIndex by rememberSaveable { mutableIntStateOf(AdvancedFileUtils.WatermarkPosition.DIAGONAL.ordinal) }
    var opacity by rememberSaveable { mutableFloatStateOf(25f) }
    var fontSize by rememberSaveable { mutableFloatStateOf(42f) }
    var pagesText by rememberSaveable { mutableStateOf("") }
    var pageNumbers by rememberSaveable { mutableStateOf(false) }
    var firstPageNumber by rememberSaveable { mutableStateOf("1") }
    var currentPassword by rememberSaveable { mutableStateOf("") }
    var newPassword by rememberSaveable { mutableStateOf("") }
    var allowPrinting by rememberSaveable { mutableStateOf(true) }
    var allowCopy by rememberSaveable { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    val modes = listOf("Marca y numeración", "Agregar/cambiar contraseña", "Quitar contraseña")
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { input = it }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val source = input ?: return@rememberLauncherForActivityResult
        if (output == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                when (modeIndex) {
                    0 -> {
                        val count = ToolFileUtils.pdfPageCount(context, source)
                        val pages = PageSelectionParser.parse(pagesText, count).toSet()
                        AdvancedFileUtils.watermarkPdf(context, source, output, AdvancedFileUtils.PdfWatermarkOptions(
                            text = watermark,
                            opacityPercent = opacity.toInt(),
                            fontSize = fontSize,
                            position = AdvancedFileUtils.WatermarkPosition.entries[positionIndex],
                            addPageNumbers = pageNumbers,
                            firstPageNumber = firstPageNumber.toIntOrNull()?.coerceIn(1, 9999) ?: 1,
                            pages = pages
                        ), currentPassword)
                    }
                    1 -> AdvancedFileUtils.changePdfProtection(context, source, output, currentPassword, newPassword, allowPrinting, allowCopy)
                    else -> AdvancedFileUtils.changePdfProtection(context, source, output, currentPassword, null)
                }
            }.onSuccess { onMessage(successMessage("PDF guardado", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar el PDF") }
            processing = false
        }
    }
    AdvancedToolPage(tool, onBack) {
        AdvancedSection("Archivo") {
            OutlinedButton(onClick = { pick.launch(arrayOf("application/pdf")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Folder, null); Text(" Seleccionar PDF") }
            input?.let { Text(ToolFileUtils.displayName(context, it), color = NeonGreen) }
            SimpleDropdown("Operación", modes, modeIndex) { modeIndex = it }
        }
        if (modeIndex == 0) AdvancedSection("Marca de agua y páginas") {
            OutlinedTextField(watermark, { watermark = it.take(120) }, label = { Text("Texto de la marca") }, modifier = Modifier.fillMaxWidth())
            SimpleDropdown("Posición", AdvancedFileUtils.WatermarkPosition.entries.map { it.label }, positionIndex) { positionIndex = it }
            Text("Opacidad: ${opacity.toInt()} %"); Slider(opacity, { opacity = it }, valueRange = 5f..80f)
            Text("Tamaño: ${fontSize.toInt()} pt"); Slider(fontSize, { fontSize = it }, valueRange = 12f..90f)
            OutlinedTextField(pagesText, { pagesText = it.filter { c -> c.isDigit() || c in ", -" }.take(120) }, label = { Text("Páginas (vacío = todas)") }, placeholder = { Text("1-3, 5, 8") }, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Agregar número de página", modifier = Modifier.weight(1f)); Switch(pageNumbers, { pageNumbers = it }) }
            if (pageNumbers) OutlinedTextField(firstPageNumber, { firstPageNumber = it.filter(Char::isDigit).take(4) }, label = { Text("Comenzar numeración en") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(currentPassword, { currentPassword = it.take(60) }, label = { Text("Contraseña actual, si tiene") }, modifier = Modifier.fillMaxWidth())
        } else AdvancedSection("Contraseña y permisos") {
            OutlinedTextField(currentPassword, { currentPassword = it.take(60) }, label = { Text("Contraseña actual, si tiene") }, modifier = Modifier.fillMaxWidth())
            if (modeIndex == 1) {
                OutlinedTextField(newPassword, { newPassword = it.take(60) }, label = { Text("Nueva contraseña") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Permitir impresión", modifier = Modifier.weight(1f)); Switch(allowPrinting, { allowPrinting = it }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Permitir copiar contenido", modifier = Modifier.weight(1f)); Switch(allowCopy, { allowCopy = it }) }
            } else Text("Solo funciona cuando el usuario conoce la contraseña actual.", color = Gold)
        }
        if (processing) {
            item { AdvancedProgress("Procesando PDF", null) }
        }
        item {
            Button(onClick = {
                if (input == null) onMessage("Selecciona un PDF")
                else if (modeIndex == 1 && newPassword.length < 4) onMessage("La nueva contraseña debe tener al menos 4 caracteres")
                else launchPaidExport(viewModel, tool, onMessage) { save.launch("pdf_procesado_gana_geo.pdf") }
            }, enabled = input != null && !processing, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)) {
                Text("Guardar PDF · ${tool.creditCost} créditos", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AdvancedToolPage(tool: ToolId, onBack: () -> Unit, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, tool.subtitle, onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.AdvancedSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    item {
        Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                content()
            }
        }
    }
}

@Composable
private fun AdvancedProgress(title: String, progress: Float?) {
    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (progress == null) LinearProgressIndicator(Modifier.fillMaxWidth()) else LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        }
    }
}
