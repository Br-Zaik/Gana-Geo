package com.ganageo.app.data

import android.content.Context

/** Preferencias visuales del usuario en este celular (no se envían al servidor). */
class UiPrefsStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        "gana_geo_ui_prefs",
        Context.MODE_PRIVATE
    )

    var hideBalances: Boolean
        get() = runCatching { preferences.getBoolean(KEY_HIDE_BALANCES, false) }.getOrDefault(false)
        set(value) {
            runCatching { preferences.edit().putBoolean(KEY_HIDE_BALANCES, value).apply() }
        }

    /** 0 = normal, 1 = grande, 2 = muy grande. */
    var textSizeStep: Int
        get() = runCatching { preferences.getInt(KEY_TEXT_SIZE, 0) }.getOrDefault(0).coerceIn(0, 2)
        set(value) {
            runCatching { preferences.edit().putInt(KEY_TEXT_SIZE, value.coerceIn(0, 2)).apply() }
        }

    var toolOpenCount: Int
        get() = runCatching { preferences.getInt(KEY_TOOL_OPENS, 0) }.getOrDefault(0)
        set(value) {
            runCatching { preferences.edit().putInt(KEY_TOOL_OPENS, value).apply() }
        }

    var reviewAsked: Boolean
        get() = runCatching { preferences.getBoolean(KEY_REVIEW_ASKED, false) }.getOrDefault(false)
        set(value) {
            runCatching { preferences.edit().putBoolean(KEY_REVIEW_ASKED, value).apply() }
        }

    private companion object {
        const val KEY_HIDE_BALANCES = "hide_balances"
        const val KEY_TEXT_SIZE = "text_size_step"
        const val KEY_TOOL_OPENS = "tool_open_count"
        const val KEY_REVIEW_ASKED = "review_asked"
    }
}
