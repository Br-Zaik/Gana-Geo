package com.ganageo.app.ui.tools

import android.content.Context
import android.os.Parcel
import android.util.Base64
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.neverEqualPolicy
import androidx.compose.runtime.referentialEqualityPolicy
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.LocalSaveableStateRegistry
import androidx.compose.runtime.saveable.SaveableStateRegistry
import androidx.compose.runtime.snapshots.SnapshotMutableState
import androidx.compose.runtime.structuralEqualityPolicy
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

private const val TOOL_STATE_PREFS = "ganageo_tool_state_v1"
private const val TOOL_STATE_PREFIX = "tool_"
private const val STATE_MARKER = "__GANAGEO_MUTABLE_STATE_V1__"

/**
 * Persiste automáticamente los valores usados con rememberSaveable dentro de una herramienta.
 * Al volver a la herramienta o reabrir la app, Compose recibe el mismo estado guardado.
 */
@Composable
internal fun PersistentToolSaveableState(
    toolKey: String,
    content: @Composable () -> Unit
) {
    val appContext = LocalContext.current.applicationContext
    val preferences = remember(appContext) {
        appContext.getSharedPreferences(TOOL_STATE_PREFS, Context.MODE_PRIVATE)
    }
    val restoredValues = remember(toolKey) {
        decodeState(preferences.getString(TOOL_STATE_PREFIX + toolKey, null))
    }
    fun persistState(state: Map<String, List<Any?>>) {
        runCatching {
            preferences.edit()
                .putString(TOOL_STATE_PREFIX + toolKey, encodeState(state))
                .apply()
        }
    }

    val registry = remember(toolKey) {
        PersistingSaveableStateRegistry(
            restoredValues = restoredValues,
            onBeforeUnregister = ::persistState
        )
    }

    fun persist() = persistState(registry.performSave())

    // Guarda también mientras la pantalla sigue abierta para cubrir cierres de la aplicación.
    LaunchedEffect(toolKey, registry) {
        while (isActive) {
            delay(750)
            persist()
        }
    }

    // Al retroceder o cambiar de herramienta se guarda inmediatamente.
    DisposableEffect(toolKey, registry) {
        onDispose { persist() }
    }

    CompositionLocalProvider(LocalSaveableStateRegistry provides registry) {
        content()
    }
}

private class PersistingSaveableStateRegistry(
    restoredValues: Map<String, List<Any?>>?,
    private val onBeforeUnregister: (Map<String, List<Any?>>) -> Unit
) : SaveableStateRegistry {
    private val delegate = SaveableStateRegistry(
        restoredValues = restoredValues,
        canBeSaved = { true }
    )

    override fun canBeSaved(value: Any): Boolean = delegate.canBeSaved(value)

    override fun consumeRestored(key: String): Any? = delegate.consumeRestored(key)

    override fun performSave(): Map<String, List<Any?>> = delegate.performSave()

    override fun registerProvider(
        key: String,
        valueProvider: () -> Any?
    ): SaveableStateRegistry.Entry {
        val entry = delegate.registerProvider(key, valueProvider)
        return object : SaveableStateRegistry.Entry {
            override fun unregister() {
                // Guardar antes de que Compose retire el proveedor evita perder el último cambio
                // cuando el usuario pulsa Atrás inmediatamente después de escribir.
                runCatching { onBeforeUnregister(delegate.performSave()) }
                entry.unregister()
            }
        }
    }
}

private fun encodeState(state: Map<String, List<Any?>>): String {
    val parcel = Parcel.obtain()
    return try {
        val parcelSafe = HashMap<String, ArrayList<Any?>>(state.size)
        state.forEach { (key, values) ->
            parcelSafe[key] = ArrayList(values.map(::toParcelSafeValue))
        }
        parcel.writeMap(parcelSafe)
        Base64.encodeToString(parcel.marshall(), Base64.NO_WRAP)
    } finally {
        parcel.recycle()
    }
}

@Suppress("UNCHECKED_CAST")
private fun decodeState(encoded: String?): Map<String, List<Any?>>? {
    if (encoded.isNullOrBlank()) return null
    val parcel = Parcel.obtain()
    return try {
        val bytes = Base64.decode(encoded, Base64.NO_WRAP)
        parcel.unmarshall(bytes, 0, bytes.size)
        parcel.setDataPosition(0)
        val raw = parcel.readHashMap(ToolStatePersistenceMarker::class.java.classLoader)
            ?: return null
        raw.entries.associate { (key, value) ->
            val values = when (value) {
                is List<*> -> value.map(::fromParcelSafeValue)
                else -> listOf(fromParcelSafeValue(value))
            }
            key.toString() to values
        }
    } catch (_: Throwable) {
        null
    } finally {
        parcel.recycle()
    }
}

private fun toParcelSafeValue(value: Any?): Any? = when (value) {
    is SnapshotMutableState<*> -> arrayListOf(
        STATE_MARKER,
        policyName(value),
        toParcelSafeValue(value.value)
    )
    is List<*> -> ArrayList(value.map(::toParcelSafeValue))
    is Array<*> -> ArrayList(value.map(::toParcelSafeValue))
    is Map<*, *> -> HashMap<Any?, Any?>().apply {
        value.forEach { (key, item) -> put(toParcelSafeValue(key), toParcelSafeValue(item)) }
    }
    else -> value
}

private fun fromParcelSafeValue(value: Any?): Any? {
    if (value is List<*> && value.size >= 3 && value.firstOrNull() == STATE_MARKER) {
        val restoredValue = fromParcelSafeValue(value[2])
        val policy = when (value[1] as? String) {
            "never" -> neverEqualPolicy<Any?>()
            "referential" -> referentialEqualityPolicy<Any?>()
            else -> structuralEqualityPolicy<Any?>()
        }
        return mutableStateOf(restoredValue, policy)
    }
    return when (value) {
        is List<*> -> ArrayList(value.map(::fromParcelSafeValue))
        is Map<*, *> -> HashMap<Any?, Any?>().apply {
            value.forEach { (key, item) -> put(fromParcelSafeValue(key), fromParcelSafeValue(item)) }
        }
        else -> value
    }
}

private fun policyName(state: SnapshotMutableState<*>): String = when {
    state.policy === neverEqualPolicy<Any?>() -> "never"
    state.policy === referentialEqualityPolicy<Any?>() -> "referential"
    else -> "structural"
}

private object ToolStatePersistenceMarker
