package com.ganageo.app.tools

import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * Word (.docx) "igual a la hoja": cada página lleva sus formas (barras, líneas),
 * sus imágenes (logos, fotos, firmas) y sus cuadros de texto, todo en el mismo
 * lugar que en la hoja. El texto se puede editar en Word.
 * Escrito a mano (un .docx es un ZIP con XML), sin librerías. Sin Android.
 * Medidas en puntos (1/72 de pulgada), desde arriba a la izquierda de la hoja.
 */
object ScanDocx {

    class Shape(val x: Float, val y: Float, val width: Float, val height: Float, val color: Int, val radius: Float = 0f)

    /** Imagen ya codificada: PNG (con transparencia) o JPG. */
    class Image(val bytes: ByteArray, val png: Boolean, val x: Float, val y: Float, val width: Float, val height: Float)

    /** Cuadro de texto. [align]: "left", "center", "right" o "both" (justificado). */
    class TextBox(
        val x: Float,
        val y: Float,
        val width: Float,
        val height: Float,
        val paragraphs: List<String>,
        val font: String,
        val sizePt: Float,
        val bold: Boolean,
        val italic: Boolean,
        val color: Int,
        val align: String,
        /** Distancia entre renglones (exacta). */
        val lineSpacingPt: Float,
        /** Ancho de la letra en % (100 = normal). */
        val scalePercent: Int = 100,
        /** Un solo renglón: no se corta aunque la letra de Word sea un poco más ancha. */
        val singleLine: Boolean = false
    )

    class Page(
        val widthPt: Float,
        val heightPt: Float,
        val shapes: List<Shape>,
        val images: List<Image>,
        val boxes: List<TextBox>,
        val tables: List<Table> = emptyList()
    )

    /** Celda de una tabla de Word. [align]: "left", "center", "right". */
    class TableCell(
        val row: Int,
        val col: Int,
        val colSpan: Int,
        val text: String,
        val bold: Boolean,
        val italic: Boolean,
        val color: Int,
        val align: String,
        val fill: Int?
    )

    /** Tabla de Word de verdad (se edita como tabla). Medidas en puntos. */
    class Table(
        /** Esquina de arriba a la izquierda en la hoja (solo para la tabla flotante). */
        val x: Float,
        val y: Float,
        val colWidths: List<Float>,
        val rowHeights: List<Float>,
        val cells: List<TableCell>,
        val font: String,
        val sizePt: Float,
        val borderColor: Int,
        val borderPt: Float,
        /** [borde de fila][columna] y [borde de columna][fila]: hay raya. */
        val hRules: List<List<Boolean>>,
        val vRules: List<List<Boolean>>
    )

    /**
     * XML de una tabla. [floating]: queda fija en su lugar de la hoja (Word "igual a
     * la hoja"); si no, va en el texto corrido.
     */
    fun tableXml(table: Table, floating: Boolean): String {
        val out = StringBuilder()
        fun twips(pt: Float) = (pt * 20f).roundToInt().coerceAtLeast(0)
        val total = table.colWidths.sum()
        out.append("<w:tbl><w:tblPr>")
        if (floating) {
            out.append("<w:tblpPr w:leftFromText=\"0\" w:rightFromText=\"0\" w:topFromText=\"0\" w:bottomFromText=\"0\"")
                .append(" w:vertAnchor=\"page\" w:horzAnchor=\"page\" w:tblpX=\"").append(twips(table.x))
                .append("\" w:tblpY=\"").append(twips(table.y)).append("\"/>")
            out.append("<w:tblOverlap w:val=\"overlap\"/>")
        }
        out.append("<w:tblW w:w=\"").append(twips(total)).append("\" w:type=\"dxa\"/>")
        out.append("<w:tblLayout w:type=\"fixed\"/>")
        val side = twips(table.sizePt * 0.35f)
        out.append("<w:tblCellMar><w:top w:w=\"0\" w:type=\"dxa\"/><w:left w:w=\"").append(side)
            .append("\" w:type=\"dxa\"/><w:bottom w:w=\"0\" w:type=\"dxa\"/><w:right w:w=\"").append(side)
            .append("\" w:type=\"dxa\"/></w:tblCellMar>")
        out.append("<w:tblLook w:val=\"0000\"/></w:tblPr><w:tblGrid>")
        for (width in table.colWidths) out.append("<w:gridCol w:w=\"").append(twips(width)).append("\"/>")
        out.append("</w:tblGrid>")
        val halfPoints = (table.sizePt * 2f).roundToInt().coerceIn(2, 3276)
        val font = xml(table.font)
        val size = (table.borderPt * 8f).roundToInt().coerceIn(2, 96)
        val color = hex(table.borderColor)
        fun border(name: String, on: Boolean) {
            if (on) {
                out.append("<w:").append(name).append(" w:val=\"single\" w:sz=\"").append(size)
                    .append("\" w:space=\"0\" w:color=\"").append(color).append("\"/>")
            } else {
                out.append("<w:").append(name).append(" w:val=\"nil\"/>")
            }
        }
        for (row in table.rowHeights.indices) {
            out.append("<w:tr><w:trPr><w:trHeight w:val=\"").append(twips(table.rowHeights[row]))
                .append("\" w:hRule=\"atLeast\"/></w:trPr>")
            val cells = table.cells.filter { it.row == row }.sortedBy { it.col }
            var col = 0
            for (cell in cells) {
                // Columnas sin celda (no debería pasar): celda vacía.
                while (col < cell.col) {
                    out.append("<w:tc><w:tcPr><w:tcW w:w=\"").append(twips(table.colWidths.getOrElse(col) { 0f }))
                        .append("\" w:type=\"dxa\"/></w:tcPr><w:p/></w:tc>")
                    col++
                }
                val span = cell.colSpan.coerceIn(1, (table.colWidths.size - cell.col).coerceAtLeast(1))
                val width = (cell.col until cell.col + span).sumOf { table.colWidths.getOrElse(it) { 0f }.toDouble() }.toFloat()
                out.append("<w:tc><w:tcPr><w:tcW w:w=\"").append(twips(width)).append("\" w:type=\"dxa\"/>")
                if (span > 1) out.append("<w:gridSpan w:val=\"").append(span).append("\"/>")
                out.append("<w:tcBorders>")
                border("top", (cell.col until cell.col + span).any { table.hRules.getOrNull(row)?.getOrNull(it) == true })
                border("left", table.vRules.getOrNull(cell.col)?.getOrNull(row) == true)
                border("bottom", (cell.col until cell.col + span).any { table.hRules.getOrNull(row + 1)?.getOrNull(it) == true })
                border("right", table.vRules.getOrNull(cell.col + span)?.getOrNull(row) == true)
                out.append("</w:tcBorders>")
                cell.fill?.let { out.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(hex(it)).append("\"/>") }
                out.append("<w:vAlign w:val=\"center\"/></w:tcPr>")
                val runProperties = StringBuilder()
                runProperties.append("<w:rPr><w:rFonts w:ascii=\"").append(font).append("\" w:hAnsi=\"").append(font)
                    .append("\" w:cs=\"").append(font).append("\"/>")
                if (cell.bold) runProperties.append("<w:b/><w:bCs/>")
                if (cell.italic) runProperties.append("<w:i/><w:iCs/>")
                runProperties.append("<w:color w:val=\"").append(hex(cell.color)).append("\"/>")
                runProperties.append("<w:sz w:val=\"").append(halfPoints).append("\"/><w:szCs w:val=\"").append(halfPoints).append("\"/></w:rPr>")
                for (text in cell.text.split('\n')) {
                    out.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\"/><w:jc w:val=\"").append(cell.align).append("\"/>")
                        .append(runProperties).append("</w:pPr>")
                    if (text.isNotEmpty()) {
                        out.append("<w:r>").append(runProperties).append("<w:t xml:space=\"preserve\">").append(xml(text)).append("</w:t></w:r>")
                    }
                    out.append("</w:p>")
                }
                out.append("</w:tc>")
                col = cell.col + span
            }
            while (col < table.colWidths.size) {
                out.append("<w:tc><w:tcPr><w:tcW w:w=\"").append(twips(table.colWidths[col])).append("\" w:type=\"dxa\"/></w:tcPr><w:p/></w:tc>")
                col++
            }
            out.append("</w:tr>")
        }
        out.append("</w:tbl>")
        return out.toString()
    }

    private const val EMU_PER_PT = 12700L

    private fun emu(pt: Float): Long = (pt * EMU_PER_PT).roundToLong().coerceAtLeast(0L)

    private fun hex(color: Int): String = String.format(
        Locale.ROOT, "%02X%02X%02X", (color shr 16) and 0xFF, (color shr 8) and 0xFF, color and 0xFF
    )

    fun xml(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .filter { it == '\t' || it >= ' ' }

    private class Counter {
        var docPr = 1
        var image = 1
        var height = 10
    }

    private fun anchorStart(
        out: StringBuilder,
        counter: Counter,
        x: Float,
        y: Float,
        width: Float,
        height: Float,
        behind: Boolean,
        name: String
    ) {
        val id = counter.docPr++
        out.append("<w:r><w:drawing>")
        out.append("<wp:anchor distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"")
            .append(counter.height++).append("\" behindDoc=\"").append(if (behind) 1 else 0)
            .append("\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\">")
        out.append("<wp:simplePos x=\"0\" y=\"0\"/>")
        out.append("<wp:positionH relativeFrom=\"page\"><wp:posOffset>").append(emu(x)).append("</wp:posOffset></wp:positionH>")
        out.append("<wp:positionV relativeFrom=\"page\"><wp:posOffset>").append(emu(y)).append("</wp:posOffset></wp:positionV>")
        out.append("<wp:extent cx=\"").append(max(1L, emu(width))).append("\" cy=\"").append(max(1L, emu(height))).append("\"/>")
        out.append("<wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/>")
        out.append("<wp:wrapNone/>")
        out.append("<wp:docPr id=\"").append(id).append("\" name=\"").append(name).append(' ').append(id).append("\"/>")
        out.append("<wp:cNvGraphicFramePr/>")
    }

    private fun anchorEnd(out: StringBuilder) {
        out.append("</wp:anchor></w:drawing></w:r>")
    }

    private fun xfrm(out: StringBuilder, width: Float, height: Float) {
        out.append("<a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"").append(max(1L, emu(width)))
            .append("\" cy=\"").append(max(1L, emu(height))).append("\"/></a:xfrm>")
    }

    private fun shape(out: StringBuilder, counter: Counter, shape: Shape) {
        anchorStart(out, counter, shape.x, shape.y, shape.width, shape.height, behind = true, name = "Forma")
        out.append("<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">")
        out.append("<a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\">")
        out.append("<wps:wsp><wps:cNvSpPr/><wps:spPr>")
        xfrm(out, shape.width, shape.height)
        val shortSide = min(shape.width, shape.height)
        if (shape.radius > 0.3f && shortSide > 0f) {
            val adjust = (shape.radius / shortSide * 100000f).roundToInt().coerceIn(0, 50000)
            out.append("<a:prstGeom prst=\"roundRect\"><a:avLst><a:gd name=\"adj\" fmla=\"val ").append(adjust).append("\"/></a:avLst></a:prstGeom>")
        } else {
            out.append("<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom>")
        }
        out.append("<a:solidFill><a:srgbClr val=\"").append(hex(shape.color)).append("\"/></a:solidFill>")
        out.append("<a:ln><a:noFill/></a:ln>")
        out.append("</wps:spPr><wps:bodyPr/></wps:wsp>")
        out.append("</a:graphicData></a:graphic>")
        anchorEnd(out)
    }

    private fun image(out: StringBuilder, counter: Counter, image: Image, relId: String) {
        anchorStart(out, counter, image.x, image.y, image.width, image.height, behind = false, name = "Imagen")
        val id = counter.docPr - 1
        out.append("<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">")
        out.append("<a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">")
        out.append("<pic:pic><pic:nvPicPr><pic:cNvPr id=\"").append(id).append("\" name=\"Imagen ").append(id).append("\"/><pic:cNvPicPr/></pic:nvPicPr>")
        out.append("<pic:blipFill><a:blip r:embed=\"").append(relId).append("\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>")
        out.append("<pic:spPr>")
        xfrm(out, image.width, image.height)
        out.append("<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>")
        out.append("</a:graphicData></a:graphic>")
        anchorEnd(out)
    }

    private fun textBox(out: StringBuilder, counter: Counter, box: TextBox) {
        anchorStart(out, counter, box.x, box.y, box.width, box.height, behind = false, name = "Texto")
        out.append("<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">")
        out.append("<a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\">")
        out.append("<wps:wsp><wps:cNvSpPr txBox=\"1\"/><wps:spPr>")
        xfrm(out, box.width, box.height)
        out.append("<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></wps:spPr>")
        out.append("<wps:txbx><w:txbxContent>")
        val halfPoints = (box.sizePt * 2f).roundToInt().coerceIn(2, 3276)
        val line = (box.lineSpacingPt * 20f).roundToInt().coerceAtLeast(20)
        val font = xml(box.font)
        val runProperties = StringBuilder()
        runProperties.append("<w:rPr><w:rFonts w:ascii=\"").append(font).append("\" w:hAnsi=\"").append(font)
            .append("\" w:cs=\"").append(font).append("\"/>")
        if (box.bold) runProperties.append("<w:b/><w:bCs/>")
        if (box.italic) runProperties.append("<w:i/><w:iCs/>")
        runProperties.append("<w:color w:val=\"").append(hex(box.color)).append("\"/>")
        if (box.scalePercent != 100) runProperties.append("<w:w w:val=\"").append(box.scalePercent.coerceIn(1, 600)).append("\"/>")
        runProperties.append("<w:sz w:val=\"").append(halfPoints).append("\"/><w:szCs w:val=\"").append(halfPoints).append("\"/></w:rPr>")
        val paragraphs = box.paragraphs.ifEmpty { listOf("") }
        for (text in paragraphs) {
            out.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"").append(line)
                .append("\" w:lineRule=\"exact\"/>")
            // Viñetas y listas numeradas: los renglones de abajo van alineados al texto.
            val prefix = ScanRebuild.listPrefix(text)
            if (prefix > 0) {
                val hanging = (box.sizePt * 0.55f * prefix * 20f).roundToInt().coerceIn(100, 1400)
                out.append("<w:ind w:left=\"").append(hanging).append("\" w:hanging=\"").append(hanging).append("\"/>")
            }
            out.append("<w:jc w:val=\"").append(box.align).append("\"/>")
            out.append(runProperties)
            out.append("</w:pPr>")
            if (text.isNotEmpty()) {
                out.append("<w:r>").append(runProperties).append("<w:t xml:space=\"preserve\">").append(xml(text)).append("</w:t></w:r>")
            }
            out.append("</w:p>")
        }
        out.append("</w:txbxContent></wps:txbx>")
        out.append("<wps:bodyPr rot=\"0\" vert=\"horz\" wrap=\"").append(if (box.singleLine) "none" else "square").append("\" lIns=\"0\" tIns=\"0\" rIns=\"0\" bIns=\"0\" anchor=\"t\" anchorCtr=\"0\"><a:spAutoFit/></wps:bodyPr>")
        out.append("</wps:wsp></a:graphicData></a:graphic>")
        anchorEnd(out)
    }

    private fun section(page: Page): String {
        val width = (page.widthPt * 20f).roundToInt()
        val height = (page.heightPt * 20f).roundToInt()
        val orient = if (page.widthPt > page.heightPt) " w:orient=\"landscape\"" else ""
        return "<w:sectPr><w:pgSz w:w=\"$width\" w:h=\"$height\"$orient/>" +
            "<w:pgMar w:top=\"0\" w:right=\"0\" w:bottom=\"0\" w:left=\"0\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/>" +
            "</w:sectPr>"
    }

    fun write(output: OutputStream, pages: List<Page>) {
        val counter = Counter()
        val body = StringBuilder()
        val media = ArrayList<Pair<String, ByteArray>>()
        val rels = StringBuilder()
        pages.forEachIndexed { pageIndex, page ->
            // Tablas flotantes: fijas en su lugar de esta hoja (van antes de su párrafo).
            for (table in page.tables) body.append(tableXml(table, floating = true))
            body.append("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\"/>")
            if (pageIndex < pages.lastIndex) body.append(section(page))
            body.append("</w:pPr>")
            // Primero las formas (detrás), luego imágenes, luego el texto (encima).
            for (item in page.shapes) shape(body, counter, item)
            for (item in page.images) {
                val number = counter.image++
                val name = "image$number." + if (item.png) "png" else "jpeg"
                val relId = "rIdImg$number"
                media += name to item.bytes
                rels.append("<Relationship Id=\"").append(relId)
                    .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/")
                    .append(name).append("\"/>")
                image(body, counter, item, relId)
            }
            for (item in page.boxes) textBox(body, counter, item)
            body.append("</w:p>")
        }
        val last = pages.lastOrNull() ?: Page(595f, 842f, emptyList(), emptyList(), emptyList())
        val documentXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document" +
            " xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"" +
            " xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"" +
            " xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\"" +
            " xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\"" +
            " xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"" +
            " xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\">" +
            "<w:body>" + body + section(last) + "</w:body></w:document>"
        val types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Default Extension=\"png\" ContentType=\"image/png\"/>" +
            "<Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"
        val rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"
        val documentRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" + rels + "</Relationships>"
        ZipOutputStream(output).use { zip ->
            fun put(name: String, bytes: ByteArray) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(bytes)
                zip.closeEntry()
            }
            put("[Content_Types].xml", types.toByteArray(Charsets.UTF_8))
            put("_rels/.rels", rootRels.toByteArray(Charsets.UTF_8))
            put("word/document.xml", documentXml.toByteArray(Charsets.UTF_8))
            put("word/_rels/document.xml.rels", documentRels.toByteArray(Charsets.UTF_8))
            for ((name, bytes) in media) put("word/media/$name", bytes)
        }
    }
}
