package com.ganageo.app.tools

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Encuentra tablas en la foto de una hoja y arma sus celdas.
 *
 * Tres casos:
 * 1. Tabla con cuadrícula: líneas horizontales y verticales que se cruzan.
 *    Las filas y columnas salen de las líneas; una celda sin línea en medio se
 *    junta con la de al lado (celda combinada).
 * 2. Tabla con rayas solo horizontales (arriba, debajo del título, abajo).
 * 3. Tabla sin líneas: renglones cuyas palabras forman columnas alineadas.
 * En 2 y 3 cada renglón es una fila y las columnas salen de los espacios.
 *
 * Trabaja con colores ARGB y cajas de palabras (sin Android) para poder probarlo.
 */
object ScanTables {
    /** Palabra leída: caja [l, t, r, b) y el renglón al que pertenece. */
    class Word(val text: String, val l: Int, val t: Int, val r: Int, val b: Int, val line: Int) {
        val cx: Float get() = (l + r) / 2f
        val cy: Float get() = (t + b) / 2f
        val h: Int get() = b - t
    }

    /** Raya recta encontrada: caja [x0, y0, x1, y1) y su color. */
    class Segment(val x0: Int, val y0: Int, val x1: Int, val y1: Int, val color: Int, val fromBar: Boolean = false) {
        val thickness: Int get() = min(x1 - x0, y1 - y0)
        val cx: Float get() = (x0 + x1) / 2f
        val cy: Float get() = (y0 + y1) / 2f
    }

    class Rules(val horizontal: List<Segment>, val vertical: List<Segment>)

    const val ALIGN_LEFT = 0
    const val ALIGN_CENTER = 1
    const val ALIGN_RIGHT = 2

    class Cell(
        val row: Int,
        val col: Int,
        val colSpan: Int,
        /** Índices de las palabras (en el orden de lectura). */
        val words: List<Int>,
        val text: String,
        val align: Int
    )

    class Table(
        /** Bordes de las columnas (x), tamaño = columnas + 1. */
        val cols: IntArray,
        /** Bordes de las filas (y), tamaño = filas + 1. */
        val rows: IntArray,
        val cells: List<Cell>,
        /** [borde de fila][columna]: hay raya horizontal ahí. */
        val hRules: Array<BooleanArray>,
        /** [borde de columna][fila]: hay raya vertical ahí. */
        val vRules: Array<BooleanArray>,
        val ruleColor: Int,
        val ruleWidth: Float,
        /** true = salió de una cuadrícula dibujada. */
        val ruled: Boolean
    ) {
        val left: Int get() = cols.first()
        val right: Int get() = cols.last()
        val top: Int get() = rows.first()
        val bottom: Int get() = rows.last()
        val rowCount: Int get() = rows.size - 1
        val colCount: Int get() = cols.size - 1
        val wordIds: Set<Int> get() = cells.flatMapTo(HashSet()) { it.words }
    }

    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun dist(a: Int, b: Int) = abs(red(a) - red(b)) + abs(green(a) - green(b)) + abs(blue(a) - blue(b))
    private fun lum(c: Int) = (red(c) * 299 + green(c) * 587 + blue(c) * 114) / 1000

    // -----------------------------------------------------------------------
    // 1) Rayas
    // -----------------------------------------------------------------------

    /**
     * Rayas rectas largas de la hoja. [minHorizontal] y [minVertical]: largo mínimo en px
     * (las letras son más cortas). [maxThick]: más grueso que esto es una barra de color,
     * y de ella se toman sus bordes de arriba y abajo como rayas.
     */
    fun rules(
        pixels: IntArray,
        width: Int,
        height: Int,
        paper: Int,
        minHorizontal: Int,
        minVertical: Int,
        maxThick: Int
    ): Rules {
        if (width <= 0 || height <= 0 || pixels.size < width * height) return Rules(emptyList(), emptyList())
        // Fondo de cada zona (la foto puede tener sombra): lo más claro de cada cuadrito.
        val block = max(16, min(width, height) / 40)
        val bw = (width + block - 1) / block
        val bh = (height + block - 1) / block
        val local = IntArray(bw * bh)
        val lums = IntArray(64)
        for (by in 0 until bh) for (bx in 0 until bw) {
            var bestLum = -1
            var n = 0
            val x0 = bx * block
            val y0 = by * block
            val x1 = min(width, x0 + block)
            val y1 = min(height, y0 + block)
            val step = max(1, block / 8)
            var brightest = paper
            var y = y0
            while (y < y1) {
                var x = x0
                while (x < x1) {
                    val c = pixels[y * width + x]
                    val l = lum(c)
                    if (l > bestLum) { bestLum = l; brightest = c }
                    if (n < lums.size) lums[n++] = l
                    x += step
                }
                y += step
            }
            local[by * bw + bx] = brightest
        }
        // Un cuadrito tapado por una barra oscura toma el fondo claro de sus vecinos.
        val background = IntArray(bw * bh)
        for (by in 0 until bh) for (bx in 0 until bw) {
            var best = local[by * bw + bx]
            for (ny in max(0, by - 1)..min(bh - 1, by + 1)) for (nx in max(0, bx - 1)..min(bw - 1, bx + 1)) {
                val c = local[ny * bw + nx]
                if (lum(c) > lum(best)) best = c
            }
            background[by * bw + bx] = best
        }
        // Raya = más oscura que el fondo Y que lo que tiene a 3 px (arriba/abajo para las
        // horizontales, a los lados para las verticales). Así el relleno de una celda
        // (rosado, gris) no cuenta como raya, pero su borde sí.
        val lumMap = IntArray(width * height) { lum(pixels[it]) }
        val base = BooleanArray(width * height)
        for (y in 0 until height) {
            val row = (y / block) * bw
            for (x in 0 until width) {
                val i = y * width + x
                val bg = background[row + x / block]
                val d = dist(pixels[i], bg)
                base[i] = d > 70 && (lum(bg) - lumMap[i] > 22 || d > 160)
            }
        }
        val k = 3
        val darkH = BooleanArray(width * height)
        val darkV = BooleanArray(width * height)
        for (y in 0 until height) for (x in 0 until width) {
            val i = y * width + x
            if (!base[i]) continue
            val l = lumMap[i]
            val up = if (y >= k) lumMap[i - k * width] else 255
            val down = if (y + k < height) lumMap[i + k * width] else 255
            darkH[i] = up - l >= 28 || down - l >= 28
            val left = if (x >= k) lumMap[i - k] else 255
            val right = if (x + k < width) lumMap[i + k] else 255
            darkV[i] = left - l >= 28 || right - l >= 28
        }
        val dark = base
        val horizontal = mergeRuns(
            runs(width, height, minHorizontal) { x, y -> darkH[y * width + x] },
            transposed = false
        )
        val vertical = mergeRuns(
            runs(height, width, minVertical) { y, x -> darkV[y * width + x] },
            transposed = true
        )
        fun color(seg: IntArray): Int {
            var r = 0L; var g = 0L; var b = 0L; var n = 0
            val stepX = max(1, (seg[2] - seg[0]) / 40)
            val stepY = max(1, (seg[3] - seg[1]) / 40)
            var y = seg[1]
            while (y < seg[3]) {
                var x = seg[0]
                while (x < seg[2]) {
                    if (dark[y * width + x]) {
                        val c = pixels[y * width + x]
                        r += red(c); g += green(c); b += blue(c); n++
                    }
                    x += stepX
                }
                y += stepY
            }
            if (n == 0) return -0x1000000
            return -0x1000000 or ((r / n).toInt() shl 16) or ((g / n).toInt() shl 8) or (b / n).toInt()
        }
        // Una raya tiene papel arriba y abajo (o a los lados); un renglón de letras no.
        fun clearRow(y: Int, x0: Int, x1: Int): Boolean {
            if (y < 0 || y >= height) return true
            var on = 0
            for (x in x0 until x1) if (dark[y * width + x]) on++
            return on < (x1 - x0) * 0.35f
        }
        val hOut = ArrayList<Segment>()
        val vOut = ArrayList<Segment>()
        for (seg in horizontal) {
            val thick = seg[3] - seg[1]
            if (thick <= maxThick) {
                val above = clearRow(seg[1] - 2, seg[0], seg[2]) || clearRow(seg[1] - 3, seg[0], seg[2])
                val below = clearRow(seg[3] + 1, seg[0], seg[2]) || clearRow(seg[3] + 2, seg[0], seg[2])
                if (!above && !below) continue
                hOut += Segment(seg[0], seg[1], seg[2], seg[3], color(seg))
            } else {
                // Barra de color: sus bordes cuentan como rayas.
                val c = color(seg)
                hOut += Segment(seg[0], seg[1], seg[2], seg[1] + 1, c, fromBar = true)
                hOut += Segment(seg[0], seg[3] - 1, seg[2], seg[3], c, fromBar = true)
            }
        }
        for (seg in vertical) {
            if (seg[2] - seg[0] > maxThick) continue
            vOut += Segment(seg[0], seg[1], seg[2], seg[3], color(seg))
        }
        return Rules(hOut, vOut)
    }

    /** Tramos oscuros por fila ([outer] filas de largo [inner]); deja pasar huecos de 2 px. */
    private inline fun runs(inner: Int, outer: Int, minLength: Int, isDark: (Int, Int) -> Boolean): List<IntArray> {
        val found = ArrayList<IntArray>()
        for (o in 0 until outer) {
            var start = -1
            var lastDark = -10
            for (i in 0..inner) {
                val on = i < inner && isDark(i, o)
                if (on) {
                    if (start < 0 || i - lastDark > 3) {
                        if (start >= 0 && lastDark + 1 - start >= minLength) found += intArrayOf(o, start, lastDark + 1)
                        start = i
                    }
                    lastDark = i
                } else if (start >= 0 && (i == inner || i - lastDark > 3)) {
                    if (lastDark + 1 - start >= minLength) found += intArrayOf(o, start, lastDark + 1)
                    start = -1
                }
            }
        }
        return found
    }

    /**
     * Junta tramos de filas vecinas que se tapan casi entero en una raya con grosor.
     * Sale [x0, y0, x1, y1).
     */
    private fun mergeRuns(found: List<IntArray>, transposed: Boolean): List<IntArray> {
        // found: [fila, desde, hasta) ordenado por fila.
        class Open(var first: Int, var last: Int, var from: Int, var to: Int)
        val open = ArrayList<Open>()
        val closed = ArrayList<Open>()
        var index = 0
        while (index < found.size) {
            val row = found[index][0]
            var end = index
            while (end < found.size && found[end][0] == row) end++
            val used = BooleanArray(end - index)
            val keep = ArrayList<Open>()
            for (segment in open) {
                if (segment.last < row - 1) {
                    closed += segment
                    continue
                }
                var joined = false
                for (k in index until end) {
                    if (used[k - index]) continue
                    val run = found[k]
                    val overlap = min(run[2], segment.to) - max(run[1], segment.from)
                    // Mismo largo (casi): una raya; una barra al lado de una raya no se mezcla.
                    val longer = max(run[2] - run[1], segment.to - segment.from)
                    if (overlap >= longer * 0.8f) {
                        segment.last = row
                        segment.from = min(segment.from, run[1])
                        segment.to = max(segment.to, run[2])
                        used[k - index] = true
                        joined = true
                        break
                    }
                }
                if (joined || segment.last >= row - 1) keep += segment else closed += segment
            }
            for (k in index until end) {
                if (!used[k - index]) keep += Open(row, row, found[k][1], found[k][2])
            }
            open.clear()
            open += keep
            index = end
        }
        closed += open
        return closed.map { s ->
            if (transposed) intArrayOf(s.first, s.from, s.last + 1, s.to) else intArrayOf(s.from, s.first, s.to, s.last + 1)
        }
    }

    // -----------------------------------------------------------------------
    // 2) Tablas
    // -----------------------------------------------------------------------

    /**
     * Tablas de la hoja. [zones]: zonas que la IA marcó como tabla (pueden faltar).
     * Las palabras de una tabla no se repiten en otra.
     */
    fun find(width: Int, height: Int, rules: Rules, words: List<Word>, zones: List<IntArray> = emptyList()): List<Table> {
        if (words.isEmpty()) return emptyList()
        val tables = ArrayList<Table>()
        val taken = HashSet<Int>()
        val textHeight = median(words.map { it.h }).coerceAtLeast(4)
        for (grid in grids(rules, textHeight)) {
            val table = gridTable(grid, words, taken, textHeight) ?: continue
            if (table.cells.count { it.text.isNotBlank() } < 2) continue
            tables += table
            taken += table.wordIds
        }
        // Rayas solo horizontales que encierran columnas.
        for (band in horizontalBands(rules, textHeight, tables)) {
            val inside = words.indices.filter { it !in taken && words[it].cy > band[1] && words[it].cy < band[3] && words[it].cx > band[0] && words[it].cx < band[2] }
            val table = columnTable(words, inside, textHeight, relaxed = true, area = band, rules = rules, alignedColumns = true) ?: continue
            tables += table
            taken += table.wordIds
        }
        // Zonas de la IA.
        for (zone in zones) {
            val inside = words.indices.filter { it !in taken && words[it].cx >= zone[0] && words[it].cx <= zone[2] && words[it].cy >= zone[1] && words[it].cy <= zone[3] }
            val table = columnTable(words, inside, textHeight, relaxed = true, area = null, rules = rules) ?: continue
            tables += table
            taken += table.wordIds
        }
        // Sin líneas: renglones seguidos con columnas alineadas.
        for (run in alignedRuns(words, taken, textHeight)) {
            val table = columnTable(words, run, textHeight, relaxed = false, area = null, rules = rules) ?: continue
            tables += table
            taken += table.wordIds
        }
        return tables.sortedBy { it.top }
    }

    private fun median(values: List<Int>): Int = if (values.isEmpty()) 0 else values.sorted()[values.size / 2]

    /** Grupos de rayas horizontales y verticales que se cruzan (cada uno una cuadrícula). */
    private fun grids(rules: Rules, textHeight: Int): List<Pair<List<Segment>, List<Segment>>> {
        val hs = rules.horizontal
        val vs = rules.vertical
        if (hs.size < 2 || vs.size < 2) return emptyList()
        val n = hs.size + vs.size
        val parent = IntArray(n) { it }
        fun root(i: Int): Int {
            var x = i
            while (parent[x] != x) {
                parent[x] = parent[parent[x]]
                x = parent[x]
            }
            return x
        }
        val tol = max(4, textHeight / 4)
        for (i in hs.indices) for (j in vs.indices) {
            val h = hs[i]
            val v = vs[j]
            if (v.cx >= h.x0 - tol && v.cx <= h.x1 + tol && h.cy >= v.y0 - tol && h.cy <= v.y1 + tol) {
                val a = root(i)
                val b = root(hs.size + j)
                if (a != b) parent[a] = b
            }
        }
        val groups = HashMap<Int, Pair<MutableList<Segment>, MutableList<Segment>>>()
        for (i in hs.indices) groups.getOrPut(root(i)) { ArrayList<Segment>() to ArrayList() }.first += hs[i]
        for (j in vs.indices) groups.getOrPut(root(hs.size + j)) { ArrayList<Segment>() to ArrayList() }.second += vs[j]
        return groups.values.filter { it.first.size >= 2 && it.second.size >= 2 }.map { it.first to it.second }
    }

    /** Agrupa posiciones cercanas (dentro de [tol]) y deja el promedio de cada grupo. */
    private fun cluster(values: List<Float>, tol: Float): List<Float> {
        if (values.isEmpty()) return emptyList()
        val sorted = values.sorted()
        val out = ArrayList<Float>()
        var sum = sorted[0]
        var count = 1
        var last = sorted[0]
        for (k in 1 until sorted.size) {
            val v = sorted[k]
            if (v - last <= tol) {
                sum += v; count++
            } else {
                out += sum / count
                sum = v; count = 1
            }
            last = v
        }
        out += sum / count
        return out
    }

    private fun gridTable(
        grid: Pair<List<Segment>, List<Segment>>,
        words: List<Word>,
        taken: Set<Int>,
        textHeight: Int
    ): Table? {
        val (hs, vs) = grid
        val tol = max(3f, textHeight * 0.35f)
        val rowEdges = cluster(hs.map { it.cy }, tol).map { it.roundToInt() }.toMutableList()
        val colEdges = cluster(vs.map { it.cx }, tol).map { it.roundToInt() }.toMutableList()
        // Borde de afuera aunque falte su raya.
        val left = min(hs.minOf { it.x0 }, vs.minOf { it.x0 })
        val right = max(hs.maxOf { it.x1 }, vs.maxOf { it.x1 })
        val top = min(hs.minOf { it.y0 }, vs.minOf { it.y0 })
        val bottom = max(hs.maxOf { it.y1 }, vs.maxOf { it.y1 })
        if (colEdges.first() - left > tol * 2) colEdges.add(0, left)
        if (right - colEdges.last() > tol * 2) colEdges.add(right)
        if (rowEdges.first() - top > tol * 2) rowEdges.add(0, top)
        if (bottom - rowEdges.last() > tol * 2) rowEdges.add(bottom)
        // Filas o columnas demasiado finas (rayas dobles) se juntan.
        val minGap = max(4, textHeight / 2)
        fun thin(edges: MutableList<Int>) {
            var k = 1
            while (k < edges.size) {
                if (edges[k] - edges[k - 1] < minGap) edges.removeAt(k) else k++
            }
        }
        thin(rowEdges)
        thin(colEdges)
        // Bordes con poca raya (pedacitos sueltos, subrayados) no son filas ni columnas.
        fun hCover(y: Int): Float {
            var covered = 0
            for (c in 0 until colEdges.size - 1) {
                val mid = (colEdges[c] + colEdges[c + 1]) / 2f
                if (hs.any { abs(it.cy - y) <= tol && it.x0 <= mid && it.x1 >= mid }) covered++
            }
            return covered / (colEdges.size - 1).coerceAtLeast(1).toFloat()
        }
        fun vCover(x: Int): Float {
            var covered = 0
            for (r in 0 until rowEdges.size - 1) {
                val mid = (rowEdges[r] + rowEdges[r + 1]) / 2f
                if (vs.any { abs(it.cx - x) <= tol && it.y0 <= mid && it.y1 >= mid }) covered++
            }
            return covered / (rowEdges.size - 1).coerceAtLeast(1).toFloat()
        }
        repeat(2) {
            if (rowEdges.size > 3) rowEdges.removeAll { y -> rowEdges.size > 3 && y != rowEdges.first() && y != rowEdges.last() && hCover(y) < 0.5f }
            if (colEdges.size > 3) colEdges.removeAll { x -> colEdges.size > 3 && x != colEdges.first() && x != colEdges.last() && vCover(x) < 0.4f }
            while (rowEdges.size > 3 && hCover(rowEdges.last()) < 0.5f && vs.none { it.y1 >= rowEdges.last() - tol }) rowEdges.removeAt(rowEdges.lastIndex)
        }
        val rows = rowEdges.size - 1
        val cols = colEdges.size - 1
        if (rows < 2 || cols < 2) return null
        if (rows * cols < 4) return null
        val colsArr = colEdges.toIntArray()
        val rowsArr = rowEdges.toIntArray()

        val hRules = Array(rows + 1) { e ->
            BooleanArray(cols) { c ->
                val mid = (colsArr[c] + colsArr[c + 1]) / 2f
                hs.any { abs(it.cy - rowsArr[e]) <= tol && it.x0 <= mid && it.x1 >= mid }
            }
        }
        val vRules = Array(cols + 1) { e ->
            BooleanArray(rows) { r ->
                val mid = (rowsArr[r] + rowsArr[r + 1]) / 2f
                vs.any { abs(it.cx - colsArr[e]) <= tol && it.y0 <= mid && it.y1 >= mid }
            }
        }
        // Fila entera sin rayas verticales entre otras que sí tienen (una barra de color
        // tapa las rayas): se copian las de la fila vecina.
        for (r in 0 until rows) {
            if ((1 until cols).any { vRules[it][r] }) continue
            val near = listOf(r + 1, r - 1).firstOrNull { it in 0 until rows && (1 until cols).any { e -> vRules[e][it] } } ?: continue
            for (e in 0..cols) vRules[e][r] = vRules[e][near]
        }
        // Palabras dentro de la cuadrícula.
        val inside0 = words.indices.filter { i ->
            i !in taken && words[i].cx > colsArr.first() && words[i].cx < colsArr.last() &&
                words[i].cy > rowsArr.first() && words[i].cy < rowsArr.last()
        }
        if (inside0.isEmpty()) return null
        // Palabra leída encima de una raya ("11.3|OK"): se parte en la raya.
        val parts = ArrayList<Word>(words)
        val origin = ArrayList<Int>(words.size).apply { addAll(words.indices) }
        val inside = ArrayList<Int>()
        for (i in inside0) {
            val w = words[i]
            val wordWidth = (w.r - w.l).coerceAtLeast(1)
            val row = (0 until rows).firstOrNull { w.cy < rowsArr[it + 1] } ?: (rows - 1)
            val cuts = (1 until cols).filter { e ->
                colsArr[e] > w.l + wordWidth * 0.15f && colsArr[e] < w.r - wordWidth * 0.15f && vRules[e][row]
            }
            if (cuts.isEmpty() || w.text.length < 2) {
                inside += i
                continue
            }
            var start = 0
            var startX = w.l
            for (k in 0..cuts.size) {
                val endX = if (k < cuts.size) colsArr[cuts[k]] else w.r
                var end = if (k < cuts.size) ((w.text.length * (endX - w.l).toFloat() / wordWidth).roundToInt()).coerceIn(start, w.text.length) else w.text.length
                var piece = w.text.substring(start, end)
                // La raya leída como letra se quita.
                piece = piece.trim('|', '/', '!', ' ')
                if (k < cuts.size && end < w.text.length && w.text[end] in "|/!") end++
                if (piece.isNotEmpty()) {
                    parts += Word(piece, startX, w.t, endX, w.b, w.line)
                    origin += i
                    inside += parts.lastIndex
                }
                start = end
                startX = endX
            }
        }
        val cells = ArrayList<Cell>()
        for (r in 0 until rows) {
            var c = 0
            while (c < cols) {
                var span = 1
                // Sin raya vertical en medio de esta fila: celda combinada.
                while (c + span < cols && !vRules[c + span][r]) span++
                val y0 = rowsArr[r]
                val y1 = rowsArr[r + 1]
                if (span > 1) {
                    // Solo si el texto queda en una sola de las columnas (o no hay texto, no se junta).
                    val used = inside.filter { parts[it].cy > y0 && parts[it].cy < y1 && parts[it].cx > colsArr[c] && parts[it].cx < colsArr[c + span] }
                        .map { id -> (c until c + span).first { parts[id].cx < colsArr[it + 1] } }.toSet()
                    if (used.size != 1) span = 1
                }
                val x0 = colsArr[c]
                val x1 = colsArr[c + span]
                val ids = inside.filter { parts[it].cx > x0 && parts[it].cx < x1 && parts[it].cy > y0 && parts[it].cy < y1 }
                val made = makeCell(parts, r, c, span, ids, x0, x1)
                cells += Cell(made.row, made.col, made.colSpan, made.words.map { origin[it] }.distinct(), made.text, made.align)
                c += span
            }
        }
        // Una tabla de verdad tiene texto en 2 filas o más y en varias celdas.
        val textCells = cells.filter { it.text.isNotBlank() }
        if (textCells.size < 3 || textCells.map { it.row }.toSet().size < 2) return null
        val all = hs + vs
        val ruleWidth = all.map { it.thickness.toFloat() }.sorted()[all.size / 2].coerceIn(1f, 6f)
        val ruleColor = all.groupingBy { it.color and 0xF0F0F0 }.eachCount().maxByOrNull { it.value }?.key
            ?.let { key -> all.first { (it.color and 0xF0F0F0) == key }.color } ?: -0x1000000
        return Table(colsArr, rowsArr, cells, hRules, vRules, ruleColor, ruleWidth, ruled = true)
    }

    private fun makeCell(words: List<Word>, row: Int, col: Int, span: Int, ids: List<Int>, x0: Int, x1: Int): Cell {
        val ordered = readingOrder(words, ids)
        val text = ordered.joinToString(" ") { words[it].text }.trim().trim('|', ' ')
        var align = ALIGN_LEFT
        if (ordered.isNotEmpty()) {
            val l = ordered.minOf { words[it].l }
            val r = ordered.maxOf { words[it].r }
            val width = (x1 - x0).toFloat()
            val leftGap = l - x0
            val rightGap = x1 - r
            val h = words[ordered.first()].h.coerceAtLeast(1)
            align = when {
                abs(leftGap - rightGap) <= max(h * 0.6f, width * 0.08f) && leftGap > h * 0.8f -> ALIGN_CENTER
                rightGap < leftGap * 0.45f && leftGap > h * 1.2f -> ALIGN_RIGHT
                else -> ALIGN_LEFT
            }
        }
        return Cell(row, col, span, ordered, text, align)
    }

    /** Palabras en orden de lectura: por renglón (de arriba abajo) y de izquierda a derecha. */
    private fun readingOrder(words: List<Word>, ids: List<Int>): List<Int> {
        if (ids.size < 2) return ids
        val h = median(ids.map { words[it].h }).coerceAtLeast(1)
        val sorted = ids.sortedBy { words[it].cy }
        val lines = ArrayList<MutableList<Int>>()
        for (id in sorted) {
            val last = lines.lastOrNull()
            if (last != null && abs(words[id].cy - words[last.first()].cy) < h * 0.5f) last += id else lines += mutableListOf(id)
        }
        return lines.flatMap { line -> line.sortedBy { words[it].l } }
    }

    /** Zonas encerradas por 3 o más rayas horizontales parecidas (sin rayas verticales). */
    private fun horizontalBands(rules: Rules, textHeight: Int, done: List<Table>): List<IntArray> {
        val hs = rules.horizontal.filter { seg ->
            !seg.fromBar && seg.x1 - seg.x0 > textHeight * 8 &&
                done.none { seg.cy >= it.top - 4 && seg.cy <= it.bottom + 4 && seg.cx >= it.left && seg.cx <= it.right }
        }.sortedBy { it.cy }
        val bands = ArrayList<IntArray>()
        val used = BooleanArray(hs.size)
        for (i in hs.indices) {
            if (used[i]) continue
            val group = arrayListOf(i)
            for (j in i + 1 until hs.size) {
                if (used[j]) continue
                val a = hs[group.last()]
                val b = hs[j]
                val width = (a.x1 - a.x0).toFloat()
                val sameSpan = abs(a.x0 - b.x0) <= width * 0.06f && abs(a.x1 - b.x1) <= width * 0.06f
                if (sameSpan && b.cy - a.cy < textHeight * 14) group += j
            }
            if (group.size >= 2) {
                group.forEach { used[it] = true }
                val segs = group.map { hs[it] }
                // Con 2 rayas: la de arriba suele ser la del título; la tabla sigue debajo.
                val bottomExtra = if (group.size == 2) textHeight * 12 else textHeight
                bands += intArrayOf(
                    segs.minOf { it.x0 } - textHeight, segs.first().y0 - textHeight * 2,
                    segs.maxOf { it.x1 } + textHeight, segs.last().y1 + bottomExtra
                )
            }
        }
        return bands
    }

    /** Renglones seguidos (de varias palabras separadas) que pueden ser una tabla sin líneas. */
    private fun alignedRuns(words: List<Word>, taken: Set<Int>, textHeight: Int): List<List<Int>> {
        // Filas por altura (no por renglón leído: el lector a veces separa cada celda).
        val free = words.indices.filter { it !in taken }.sortedBy { words[it].cy }
        val rowsFound = ArrayList<MutableList<Int>>()
        for (id in free) {
            val w = words[id]
            val row = rowsFound.lastOrNull()
            if (row != null) {
                val cy = row.map { words[it].cy }.average().toFloat()
                val h = median(row.map { words[it].h }).coerceAtLeast(1)
                if (abs(w.cy - cy) < max(h, w.h) * 0.45f) {
                    row += id
                    continue
                }
            }
            rowsFound += mutableListOf(id)
        }
        val byLine = rowsFound.map { ids -> ids.sortedBy { words[it].l } }
        val out = ArrayList<List<Int>>()
        var current = ArrayList<List<Int>>()
        fun groupsOf(ids: List<Int>): Int {
            val h = median(ids.map { words[it].h }).coerceAtLeast(1)
            var groups = 1
            for (k in 1 until ids.size) if (words[ids[k]].l - words[ids[k - 1]].r > h * 0.55f) groups++
            return groups
        }
        fun flush() {
            if (current.size >= 3) out += current.flatten()
            current = ArrayList()
        }
        for (ids in byLine) {
            val top = ids.minOf { words[it].t }
            val h = median(ids.map { words[it].h }).coerceAtLeast(1)
            val previous = current.lastOrNull()
            if (previous != null) {
                val prevBottom = previous.maxOf { words[it].b }
                val prevH = median(previous.map { words[it].h }).coerceAtLeast(1)
                if (top - prevBottom > max(h, prevH) * 3f || abs(h - prevH) > max(h, prevH) * 0.4f) flush()
            }
            if (groupsOf(ids) >= 2) current += ids else flush()
        }
        flush()
        return out
    }

    /**
     * Tabla de filas = renglones y columnas = grupos de palabras alineados.
     * [relaxed]: ya se sabe que hay tabla (rayas o IA), se aceptan menos pruebas.
     */
    private fun columnTable(
        words: List<Word>,
        ids: List<Int>,
        textHeight: Int,
        relaxed: Boolean,
        area: IntArray?,
        rules: Rules?,
        alignedColumns: Boolean = !relaxed
    ): Table? {
        if (ids.size < 4) return null
        // Renglones.
        val sorted = ids.sortedBy { words[it].cy }
        val lines = ArrayList<MutableList<Int>>()
        for (id in sorted) {
            val last = lines.lastOrNull()
            if (last != null && abs(words[id].cy - last.map { words[it].cy }.average().toFloat()) < textHeight * 0.55f) last += id else lines += mutableListOf(id)
        }
        if (lines.size < (if (relaxed) 2 else 3)) return null
        lines.forEach { line -> line.sortBy { words[it].l } }
        // Grupos de palabras de cada renglón.
        class Group(val ids: List<Int>, val l: Int, val r: Int)
        val groupsPerLine = lines.map { line ->
            val h = median(line.map { words[it].h }).coerceAtLeast(1)
            val gap = h * (if (relaxed) 0.5f else 0.55f)
            val groups = ArrayList<Group>()
            var start = 0
            for (k in 1..line.size) {
                if (k == line.size || words[line[k]].l - words[line[k - 1]].r > gap) {
                    val part = line.subList(start, k).toList()
                    groups += Group(part, part.minOf { words[it].l }, part.maxOf { words[it].r })
                    start = k
                }
            }
            groups
        }
        // Columnas: huecos verticales que atraviesan todos los renglones.
        val left = groupsPerLine.minOf { g -> g.minOf { it.l } }
        val right = groupsPerLine.maxOf { g -> g.maxOf { it.r } }
        val span = right - left
        if (span <= 0) return null
        val covered = IntArray(span + 1)
        for (groups in groupsPerLine) for (g in groups) {
            for (x in (g.l - left).coerceAtLeast(0)..(g.r - left).coerceAtMost(span)) covered[x]++
        }
        val minGapWidth = max(3, (textHeight * 0.45f).roundToInt())
        val allowed = if (relaxed) 0 else 0
        val gaps = ArrayList<IntArray>()
        var x = 0
        while (x <= span) {
            if (covered[x] <= allowed) {
                val start = x
                while (x <= span && covered[x] <= allowed) x++
                if (x - start >= minGapWidth && start > 0 && x <= span) gaps += intArrayOf(start + left, x + left)
            } else {
                x++
            }
        }
        if (gaps.isEmpty()) return null
        val colEdges = ArrayList<Int>()
        val pad = max(2, textHeight / 3)
        colEdges += (area?.get(0)?.plus(textHeight) ?: left).coerceAtMost(left) - pad
        gaps.forEach { colEdges += (it[0] + it[1]) / 2 }
        colEdges += right + pad
        val cols = colEdges.size - 1
        if (cols < 2) return null
        // Cuántos renglones llenan 2 o más columnas: en una tabla, casi todos.
        fun colOf(w: Word): Int {
            for (c in 0 until cols) if (w.cx < colEdges[c + 1]) return c
            return cols - 1
        }
        val filled = lines.map { line -> line.map { colOf(words[it]) }.toSet().size }
        val multi = filled.count { it >= 2 }
        if (multi < (if (relaxed) 2 else 3) || multi < lines.size * (if (relaxed) 0.5f else 0.75f)) return null
        // Texto corrido no es tabla: celdas con muchas palabras (en alguna columna).
        val wordsPerCell = ids.size.toFloat() / filled.sum().coerceAtLeast(1)
        if (wordsPerCell > (if (relaxed) 7f else 4.5f)) return null
        if (alignedColumns) {
            for (c in 0 until cols) {
                val inColumn = lines.map { line -> line.filter { colOf(words[it]) == c } }.filter { it.isNotEmpty() }
                // Una columna de tabla tiene algo en casi todas las filas.
                if (inColumn.size < lines.size * 0.5f) return null
                if (inColumn.map { it.size }.average() > (if (relaxed) 7.0 else 5.0)) return null
                // En una tabla cada columna está alineada (a la izquierda, al centro o a la
                // derecha). Un texto justificado tiene huecos, pero no columnas alineadas.
                val tol = textHeight * 0.6f
                val lefts = inColumn.map { cell -> cell.minOf { words[it].l }.toFloat() }
                val rights = inColumn.map { cell -> cell.maxOf { words[it].r }.toFloat() }
                val centers = lefts.indices.map { (lefts[it] + rights[it]) / 2f }
                fun aligned(values: List<Float>): Int {
                    val mid = values.sorted()[values.size / 2]
                    return values.count { abs(it - mid) <= tol }
                }
                val best = maxOf(aligned(lefts), aligned(rights), aligned(centers))
                if (best < inColumn.size * 0.7f) return null
            }
        }
        if (!relaxed && cols > 8) return null
        // Filas.
        val rowEdges = ArrayList<Int>()
        val tops = lines.map { line -> line.minOf { words[it].t } }
        val bottoms = lines.map { line -> line.maxOf { words[it].b } }
        rowEdges += tops.first() - pad
        for (k in 1 until lines.size) rowEdges += (bottoms[k - 1] + tops[k]) / 2
        rowEdges += bottoms.last() + pad
        val rows = lines.size
        val colsArr = colEdges.toIntArray()
        val rowsArr = rowEdges.toIntArray()
        // Rayas horizontales que caen en los bordes de fila (o encima / debajo).
        val hRules = Array(rows + 1) { BooleanArray(cols) }
        var ruleColor = -0x1000000
        var ruleWidth = 1f
        if (rules != null) {
            val tableWidth = colsArr.last() - colsArr.first()
            for (seg in rules.horizontal) {
                if (seg.x1 - seg.x0 < tableWidth * 0.5f) continue
                if (seg.cx < colsArr.first() || seg.cx > colsArr.last()) continue
                // Borde de fila más cercano.
                var best = -1
                var bestDistance = Float.MAX_VALUE
                for (e in 0..rows) {
                    val d = abs(seg.cy - rowsArr[e])
                    if (d < bestDistance) { bestDistance = d; best = e }
                }
                if (best < 0 || bestDistance > textHeight * 1.6f) continue
                for (c in 0 until cols) {
                    val mid = (colsArr[c] + colsArr[c + 1]) / 2f
                    if (seg.x0 <= mid + textHeight && seg.x1 >= mid - textHeight) hRules[best][c] = true
                }
                ruleColor = seg.color
                ruleWidth = seg.thickness.toFloat().coerceIn(1f, 6f)
            }
        }
        val vRules = Array(cols + 1) { BooleanArray(rows) }
        val cells = ArrayList<Cell>()
        val perCell = Array(rows) { r -> Array(cols) { c -> lines[r].filter { colOf(words[it]) == c } } }
        for (c in 0 until cols) {
            // Alineación por columna: comparada con las otras filas, no con el borde.
            val filledRows = (0 until rows).filter { perCell[it][c].isNotEmpty() }
            val lefts = filledRows.map { r -> perCell[r][c].minOf { words[it].l } }
            val rights = filledRows.map { r -> perCell[r][c].maxOf { words[it].r } }
            val minL = lefts.minOrNull() ?: 0
            val maxR = rights.maxOrNull() ?: 0
            val columnCells = (0 until rows).map { r ->
                val inCell = perCell[r][c]
                val made = makeCell(words, r, c, 1, inCell, colsArr[c], colsArr[c + 1])
                if (inCell.isEmpty()) return@map made
                val l = inCell.minOf { words[it].l }
                val rr = inCell.maxOf { words[it].r }
                val tol = textHeight * 0.6f
                val alignAll = { a: Int -> Cell(r, c, 1, made.words, made.text, a) }
                when {
                    l - minL <= tol -> alignAll(ALIGN_LEFT)
                    maxR - rr <= tol -> alignAll(ALIGN_RIGHT)
                    else -> alignAll(ALIGN_CENTER)
                }
            }
            cells += columnCells
        }
        cells.sortWith(compareBy({ it.row }, { it.col }))
        return Table(colsArr, rowsArr, cells, hRules, vRules, ruleColor, ruleWidth, ruled = false)
    }

    /**
     * ¿Es creíble como tabla, viendo sus colores? Una "tabla sin líneas" donde una
     * columna entera está sobre un color y otra sobre el papel suele ser una hoja a
     * dos columnas (una barra lateral), no una tabla.
     */
    fun plausible(table: Table, fills: List<Int?>): Boolean {
        if (table.ruled || table.hRules.any { row -> row.any { it } }) return true
        val byColumn = (0 until table.colCount).map { c -> table.cells.indices.filter { table.cells[it].col == c }.map { fills.getOrNull(it) } }
        val allFilled = byColumn.any { column -> column.isNotEmpty() && column.all { it != null } }
        val allPaper = byColumn.any { column -> column.isNotEmpty() && column.all { it == null } }
        return !(allFilled && allPaper)
    }

    // -----------------------------------------------------------------------
    // 3) Colores de fondo de las celdas
    // -----------------------------------------------------------------------

    /**
     * Color de fondo de cada celda (en el orden de [Table.cells]); null = papel.
     * Se mira el centro de la celda sin las palabras ni las rayas.
     */
    fun fills(pixels: IntArray, width: Int, height: Int, table: Table, words: List<Word>, paper: Int): List<Int?> =
        table.cells.map { cell ->
            val inset = max(2, (table.ruleWidth * 2).roundToInt())
            val x0 = (table.cols[cell.col] + inset).coerceIn(0, width - 1)
            val x1 = (table.cols[cell.col + cell.colSpan] - inset).coerceIn(0, width)
            val y0 = (table.rows[cell.row] + inset).coerceIn(0, height - 1)
            val y1 = (table.rows[cell.row + 1] - inset).coerceIn(0, height)
            if (x1 - x0 < 2 || y1 - y0 < 2) return@map null
            val boxes = cell.words.map { words[it] }
            val counts = HashMap<Int, Int>()
            val sums = HashMap<Int, LongArray>()
            val stepX = max(1, (x1 - x0) / 30)
            val stepY = max(1, (y1 - y0) / 12)
            var y = y0
            var total = 0
            while (y < y1) {
                var x = x0
                while (x < x1) {
                    if (boxes.none { x >= it.l - 2 && x < it.r + 2 && y >= it.t - 2 && y < it.b + 2 }) {
                        val c = pixels[y * width + x]
                        val key = ((red(c) shr 4) shl 8) or ((green(c) shr 4) shl 4) or (blue(c) shr 4)
                        counts[key] = (counts[key] ?: 0) + 1
                        val sum = sums.getOrPut(key) { LongArray(3) }
                        sum[0] += red(c).toLong(); sum[1] += green(c).toLong(); sum[2] += blue(c).toLong()
                        total++
                    }
                    x += stepX
                }
                y += stepY
            }
            if (total < 4) return@map null
            val top = counts.maxByOrNull { it.value } ?: return@map null
            if (top.value < total * 0.4f) return@map null
            val sum = sums.getValue(top.key)
            val n = top.value
            val color = -0x1000000 or ((sum[0] / n).toInt() shl 16) or ((sum[1] / n).toInt() shl 8) or (sum[2] / n).toInt()
            if (dist(color, paper) < 60) null else color
        }
}
