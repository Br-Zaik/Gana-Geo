package com.ganageo.app.tools

import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.roundToInt

/**
 * Escribe un Excel (.xlsx) con las tablas del escáner: una hoja por tabla, con
 * celdas combinadas, negrita, colores, rellenos, bordes y ancho de columnas.
 * Los números quedan como números (se pueden sumar) con sus mismos decimales.
 * Sin librerías: un .xlsx es un ZIP con XML.
 */
object ScanXlsx {
    class Cell(
        val row: Int,
        val col: Int,
        val colSpan: Int,
        val text: String,
        val bold: Boolean = false,
        val italic: Boolean = false,
        val color: Int = -0x1000000,
        val fill: Int? = null,
        /** "left", "center", "right". */
        val align: String = "left",
        val top: Boolean = false,
        val bottom: Boolean = false,
        val left: Boolean = false,
        val right: Boolean = false
    )

    class Sheet(
        val name: String,
        /** Ancho de cada columna en puntos. */
        val colWidths: List<Float>,
        /** Alto de cada fila en puntos. */
        val rowHeights: List<Float>,
        val cells: List<Cell>,
        val font: String = "Arial",
        val sizePt: Float = 11f,
        val borderColor: Int = -0x1000000
    )

    /** Número de una celda y cuántos decimales tenía, o null si es texto. */
    fun number(text: String): Pair<Double, Int>? {
        val value = text.trim()
        if (value.isEmpty() || value.length > 18) return null
        Regex("^-?\\d+$").matchEntire(value)?.let {
            // "09" o "007" son códigos: se quedan como texto.
            val digits = value.removePrefix("-")
            if (digits.length > 1 && digits.startsWith("0")) return null
            return value.toDoubleOrNull()?.let { it to 0 }
        }
        Regex("^-?\\d+\\.(\\d+)$").matchEntire(value)?.let { match ->
            return value.toDoubleOrNull()?.let { it to match.groupValues[1].length }
        }
        Regex("^-?\\d{1,3}(,\\d{3})+(\\.(\\d+))?$").matchEntire(value)?.let { match ->
            // "1,425" solo es dudoso (¿mil o uno coma?): queda como texto.
            if (match.groupValues[3].isEmpty() && value.count { it == ',' } == 1) return null
            return value.replace(",", "").toDoubleOrNull()?.let { it to match.groupValues[3].length }
        }
        Regex("^-?\\d+,(\\d+)$").matchEntire(value)?.let { match ->
            // "12,5" es decimal; "1,425" puede ser mil cuatrocientos: queda como texto.
            if (match.groupValues[1].length == 3) return null
            return value.replace(',', '.').toDoubleOrNull()?.let { it to match.groupValues[1].length }
        }
        return null
    }

    /** "A", "B", … "Z", "AA"… */
    fun column(index: Int): String {
        var n = index + 1
        val out = StringBuilder()
        while (n > 0) {
            val r = (n - 1) % 26
            out.insert(0, ('A' + r))
            n = (n - 1) / 26
        }
        return out.toString()
    }

    private fun xml(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .filter { it == '\t' || it == '\n' || it >= ' ' }

    private fun argb(color: Int): String = String.format(
        Locale.ROOT, "FF%02X%02X%02X", (color shr 16) and 0xFF, (color shr 8) and 0xFF, color and 0xFF
    )

    /** Nombre válido y sin repetir para una hoja de Excel. */
    private fun sheetName(name: String, used: MutableSet<String>): String {
        var base = name.filter { it !in "[]:*?/\\" }.trim().ifEmpty { "Tabla" }.take(28)
        var candidate = base
        var n = 2
        while (candidate.lowercase(Locale.ROOT) in used) {
            candidate = "$base $n".take(31)
            n++
        }
        used += candidate.lowercase(Locale.ROOT)
        return candidate
    }

    private data class FontKey(val bold: Boolean, val italic: Boolean, val color: Int)
    private data class BorderKey(val top: Boolean, val bottom: Boolean, val left: Boolean, val right: Boolean)
    private data class StyleKey(val font: Int, val fill: Int, val border: Int, val numFmt: Int, val align: String)

    fun write(output: OutputStream, sheets: List<Sheet>) {
        val list = sheets.ifEmpty { listOf(Sheet("Tabla", listOf(60f), listOf(15f), emptyList())) }
        val first = list.first()
        val fonts = LinkedHashMap<FontKey, Int>()
        val fills = LinkedHashMap<Int, Int>() // color → índice (desde 2)
        val borders = LinkedHashMap<BorderKey, Int>()
        val numFmts = LinkedHashMap<Int, Int>() // decimales → id (desde 164)
        val styles = LinkedHashMap<StyleKey, Int>()
        fonts[FontKey(false, false, -0x1000000)] = 0
        borders[BorderKey(false, false, false, false)] = 0
        styles[StyleKey(0, 0, 0, 0, "general")] = 0

        fun style(cell: Cell, decimals: Int?): Int {
            val font = fonts.getOrPut(FontKey(cell.bold, cell.italic, cell.color or -0x1000000)) { fonts.size }
            val fill = cell.fill?.let { color -> fills.getOrPut(color or -0x1000000) { fills.size + 2 } } ?: 0
            val border = borders.getOrPut(BorderKey(cell.top, cell.bottom, cell.left, cell.right)) { borders.size }
            val numFmt = when {
                decimals == null -> 0
                decimals == 0 -> 1
                else -> numFmts.getOrPut(decimals) { 164 + numFmts.size }
            }
            return styles.getOrPut(StyleKey(font, fill, border, numFmt, cell.align)) { styles.size }
        }

        val usedNames = HashSet<String>()
        val sheetXml = list.map { sheet ->
            val out = StringBuilder()
            out.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
            out.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"")
                .append(" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">")
            out.append("<sheetFormatPr defaultRowHeight=\"15\"/>")
            if (sheet.colWidths.isNotEmpty()) {
                out.append("<cols>")
                sheet.colWidths.forEachIndexed { index, widthPt ->
                    // Ancho de Excel ≈ caracteres de la letra normal (unos 5,3 pt cada uno).
                    val chars = (widthPt / 5.3f).coerceIn(2f, 120f)
                    out.append("<col min=\"").append(index + 1).append("\" max=\"").append(index + 1)
                        .append("\" width=\"").append(String.format(Locale.ROOT, "%.2f", chars)).append("\" customWidth=\"1\"/>")
                }
                out.append("</cols>")
            }
            out.append("<sheetData>")
            val merges = ArrayList<String>()
            val rows = sheet.cells.groupBy { it.row }
            val rowCount = maxOf(sheet.rowHeights.size, (sheet.cells.maxOfOrNull { it.row } ?: -1) + 1)
            for (r in 0 until rowCount) {
                val height = sheet.rowHeights.getOrNull(r)
                out.append("<row r=\"").append(r + 1).append('"')
                if (height != null) {
                    out.append(" ht=\"").append(String.format(Locale.ROOT, "%.1f", height.coerceIn(8f, 400f))).append("\" customHeight=\"1\"")
                }
                out.append('>')
                for (cell in rows[r].orEmpty().sortedBy { it.col }) {
                    val ref = column(cell.col) + (r + 1)
                    val value = number(cell.text)
                    val s = style(cell, value?.second)
                    if (value != null) {
                        val shown = if (value.first == value.first.roundToInt().toDouble() && value.second == 0) {
                            value.first.roundToInt().toString()
                        } else {
                            value.first.toString()
                        }
                        out.append("<c r=\"").append(ref).append("\" s=\"").append(s).append("\"><v>").append(shown).append("</v></c>")
                    } else if (cell.text.isEmpty()) {
                        out.append("<c r=\"").append(ref).append("\" s=\"").append(s).append("\"/>")
                    } else {
                        out.append("<c r=\"").append(ref).append("\" s=\"").append(s).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
                            .append(xml(cell.text)).append("</t></is></c>")
                    }
                    if (cell.colSpan > 1) {
                        val end = cell.col + cell.colSpan - 1
                        // Las celdas tapadas llevan el mismo borde (si no, el borde se corta).
                        for (c in cell.col + 1..end) {
                            out.append("<c r=\"").append(column(c)).append(r + 1).append("\" s=\"").append(s).append("\"/>")
                        }
                        merges += "$ref:${column(end)}${r + 1}"
                    }
                }
                out.append("</row>")
            }
            out.append("</sheetData>")
            if (merges.isNotEmpty()) {
                out.append("<mergeCells count=\"").append(merges.size).append("\">")
                merges.forEach { out.append("<mergeCell ref=\"").append(it).append("\"/>") }
                out.append("</mergeCells>")
            }
            out.append("<pageMargins left=\"0.5\" right=\"0.5\" top=\"0.75\" bottom=\"0.75\" header=\"0.3\" footer=\"0.3\"/>")
            out.append("</worksheet>")
            sheetName(sheet.name, usedNames) to out.toString()
        }

        val fontName = xml(first.font)
        val size = String.format(Locale.ROOT, "%.1f", first.sizePt.coerceIn(6f, 72f))
        val border = argb(first.borderColor)
        val stylesXml = StringBuilder()
        stylesXml.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        stylesXml.append("<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
        if (numFmts.isNotEmpty()) {
            stylesXml.append("<numFmts count=\"").append(numFmts.size).append("\">")
            for ((decimals, id) in numFmts) {
                stylesXml.append("<numFmt numFmtId=\"").append(id).append("\" formatCode=\"0.").append("0".repeat(decimals.coerceIn(1, 10))).append("\"/>")
            }
            stylesXml.append("</numFmts>")
        }
        stylesXml.append("<fonts count=\"").append(fonts.size).append("\">")
        for (key in fonts.keys) {
            stylesXml.append("<font>")
            if (key.bold) stylesXml.append("<b/>")
            if (key.italic) stylesXml.append("<i/>")
            stylesXml.append("<sz val=\"").append(size).append("\"/><color rgb=\"").append(argb(key.color))
                .append("\"/><name val=\"").append(fontName).append("\"/></font>")
        }
        stylesXml.append("</fonts>")
        stylesXml.append("<fills count=\"").append(fills.size + 2).append("\">")
        stylesXml.append("<fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>")
        for (color in fills.keys) {
            stylesXml.append("<fill><patternFill patternType=\"solid\"><fgColor rgb=\"").append(argb(color))
                .append("\"/><bgColor indexed=\"64\"/></patternFill></fill>")
        }
        stylesXml.append("</fills>")
        stylesXml.append("<borders count=\"").append(borders.size).append("\">")
        for (key in borders.keys) {
            fun side(name: String, on: Boolean) {
                if (on) {
                    stylesXml.append("<").append(name).append(" style=\"thin\"><color rgb=\"").append(border).append("\"/></").append(name).append(">")
                } else {
                    stylesXml.append("<").append(name).append("/>")
                }
            }
            stylesXml.append("<border>")
            side("left", key.left)
            side("right", key.right)
            side("top", key.top)
            side("bottom", key.bottom)
            stylesXml.append("<diagonal/></border>")
        }
        stylesXml.append("</borders>")
        stylesXml.append("<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>")
        stylesXml.append("<cellXfs count=\"").append(styles.size).append("\">")
        for (key in styles.keys) {
            stylesXml.append("<xf numFmtId=\"").append(key.numFmt).append("\" fontId=\"").append(key.font)
                .append("\" fillId=\"").append(key.fill).append("\" borderId=\"").append(key.border).append("\" xfId=\"0\"")
            if (key.numFmt != 0) stylesXml.append(" applyNumberFormat=\"1\"")
            if (key.font != 0) stylesXml.append(" applyFont=\"1\"")
            if (key.fill != 0) stylesXml.append(" applyFill=\"1\"")
            if (key.border != 0) stylesXml.append(" applyBorder=\"1\"")
            if (key.align != "general") {
                stylesXml.append(" applyAlignment=\"1\"><alignment horizontal=\"").append(key.align)
                    .append("\" vertical=\"center\" wrapText=\"1\"/></xf>")
            } else {
                stylesXml.append("/>")
            }
        }
        stylesXml.append("</cellXfs>")
        stylesXml.append("<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>")
        stylesXml.append("</styleSheet>")

        val workbook = StringBuilder()
        workbook.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        workbook.append("<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"")
            .append(" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>")
        sheetXml.forEachIndexed { index, (name, _) ->
            workbook.append("<sheet name=\"").append(xml(name)).append("\" sheetId=\"").append(index + 1)
                .append("\" r:id=\"rId").append(index + 1).append("\"/>")
        }
        workbook.append("</sheets></workbook>")
        val workbookRels = StringBuilder()
        workbookRels.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        workbookRels.append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
        sheetXml.indices.forEach { index ->
            workbookRels.append("<Relationship Id=\"rId").append(index + 1)
                .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
                .append(index + 1).append(".xml\"/>")
        }
        workbookRels.append("<Relationship Id=\"rIdStyles\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>")
        workbookRels.append("</Relationships>")
        val types = StringBuilder()
        types.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        types.append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
        types.append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
        types.append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
        types.append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
        types.append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>")
        sheetXml.indices.forEach { index ->
            types.append("<Override PartName=\"/xl/worksheets/sheet").append(index + 1)
                .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
        }
        types.append("</Types>")
        val rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
            "</Relationships>"
        ZipOutputStream(output).use { zip ->
            fun put(name: String, text: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(text.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            put("[Content_Types].xml", types.toString())
            put("_rels/.rels", rootRels)
            put("xl/workbook.xml", workbook.toString())
            put("xl/_rels/workbook.xml.rels", workbookRels.toString())
            put("xl/styles.xml", stylesXml.toString())
            sheetXml.forEachIndexed { index, (_, text) -> put("xl/worksheets/sheet${index + 1}.xml", text) }
        }
    }
}
