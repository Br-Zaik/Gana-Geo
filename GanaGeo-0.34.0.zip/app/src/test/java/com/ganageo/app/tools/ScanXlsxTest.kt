package com.ganageo.app.tools

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanXlsxTest {
    @Test
    fun numerosQuedanComoNumeros() {
        assertEquals(1.425 to 3, ScanXlsx.number("1.425"))
        assertEquals(17.0 to 0, ScanXlsx.number("17"))
        assertEquals(12.5 to 1, ScanXlsx.number("12,5"))
        assertEquals(1234.5 to 1, ScanXlsx.number("1,234.5"))
        assertNull(ScanXlsx.number("09"))
        assertNull(ScanXlsx.number("1,425"))
        assertNull(ScanXlsx.number("T-101"))
    }

    @Test
    fun columnasComoEnExcel() {
        assertEquals("A", ScanXlsx.column(0))
        assertEquals("Z", ScanXlsx.column(25))
        assertEquals("AA", ScanXlsx.column(26))
    }

    @Test
    fun hojaConCeldasCombinadasYNombres() {
        val sheet = ScanXlsx.Sheet(
            "Tabla: 1", listOf(60f, 60f, 60f), listOf(18f, 18f),
            listOf(
                ScanXlsx.Cell(0, 0, 1, "Punto", bold = true, fill = 0xFF1F4E79.toInt()),
                ScanXlsx.Cell(0, 1, 1, "Cota & <m>"),
                ScanXlsx.Cell(0, 2, 1, "3850.000", align = "right"),
                ScanXlsx.Cell(1, 0, 2, "Total", top = true),
                ScanXlsx.Cell(1, 2, 1, "2.747")
            )
        )
        val out = ByteArrayOutputStream()
        ScanXlsx.write(out, listOf(sheet, sheet))
        val files = HashMap<String, String>()
        ZipInputStream(ByteArrayInputStream(out.toByteArray())).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                files[e.name] = String(zip.readBytes(), Charsets.UTF_8)
            }
        }
        val xml = files.getValue("xl/worksheets/sheet1.xml")
        assertTrue(xml.contains("<mergeCell ref=\"A2:B2\"/>"))
        assertTrue(xml.contains("<v>3850.0</v>"))
        assertTrue(xml.contains("Cota &amp; &lt;m&gt;"))
        val workbook = files.getValue("xl/workbook.xml")
        assertTrue(workbook.contains("name=\"Tabla 1\""))
        assertTrue(workbook.contains("name=\"Tabla 1 2\""))
        assertTrue(files.getValue("xl/styles.xml").contains("formatCode=\"0.000\""))
    }
}
