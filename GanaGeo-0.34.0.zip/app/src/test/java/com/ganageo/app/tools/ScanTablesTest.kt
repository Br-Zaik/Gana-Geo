package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanTablesTest {
    private val white = -0x1
    private val black = -0x1000000

    private fun page(width: Int, height: Int) = IntArray(width * height) { white }

    private fun hLine(px: IntArray, width: Int, y: Int, x0: Int, x1: Int, color: Int = black) {
        for (x in x0 until x1) px[y * width + x] = color
    }

    private fun vLine(px: IntArray, width: Int, x: Int, y0: Int, y1: Int, color: Int = black) {
        for (y in y0 until y1) px[y * width + x] = color
    }

    private fun fill(px: IntArray, width: Int, x0: Int, y0: Int, x1: Int, y1: Int, color: Int) {
        for (y in y0 until y1) for (x in x0 until x1) px[y * width + x] = color
    }

    /** Cuadrícula de 3 columnas x 3 filas: x = 20, 120, 220, 320; y = 20, 60, 100, 140. */
    private fun grid(px: IntArray, width: Int, skipLastRowMiddle: Boolean = false) {
        for (y in listOf(20, 60, 100, 140)) hLine(px, width, y, 20, 321)
        for (x in listOf(20, 120, 220, 320)) {
            if (skipLastRowMiddle && x == 120) {
                vLine(px, width, x, 20, 100)
            } else {
                vLine(px, width, x, 20, 141)
            }
        }
    }

    private fun word(text: String, l: Int, t: Int, line: Int) = ScanTables.Word(text, l, t, l + text.length * 8, t + 14, line)

    private fun find(px: IntArray, width: Int, height: Int, words: List<ScanTables.Word>): List<ScanTables.Table> {
        val rules = ScanTables.rules(px, width, height, white, 30, 25, 4)
        return ScanTables.find(width, height, rules, words)
    }

    @Test
    fun cuadriculaDaFilasYColumnas() {
        val w = 360; val h = 180
        val px = page(w, h)
        grid(px, w)
        val words = listOf(
            word("Punto", 30, 33, 0), word("Cota", 130, 33, 0), word("Nota", 230, 33, 0),
            word("A", 30, 73, 1), word("3850", 130, 73, 1), word("17", 230, 73, 1),
            word("B", 30, 113, 2), word("3849", 130, 113, 2), word("12", 230, 113, 2)
        )
        val tables = find(px, w, h, words)
        assertEquals(1, tables.size)
        val t = tables[0]
        assertTrue(t.ruled)
        assertEquals(3, t.rowCount)
        assertEquals(3, t.colCount)
        assertEquals(listOf("Punto", "Cota", "Nota", "A", "3850", "17", "B", "3849", "12"), t.cells.map { it.text })
        assertTrue(t.hRules.all { row -> row.all { it } })
    }

    @Test
    fun sinRayaEnMedioEsCeldaCombinada() {
        val w = 360; val h = 180
        val px = page(w, h)
        grid(px, w, skipLastRowMiddle = true)
        val words = listOf(
            word("Punto", 30, 33, 0), word("Cota", 130, 33, 0), word("Nota", 230, 33, 0),
            word("A", 30, 73, 1), word("3850", 130, 73, 1), word("17", 230, 73, 1),
            word("Total", 30, 113, 2), word("20", 230, 113, 2)
        )
        val t = find(px, w, h, words).single()
        val total = t.cells.first { it.row == 2 && it.col == 0 }
        assertEquals(2, total.colSpan)
        assertEquals("Total", total.text)
        assertEquals(8, t.cells.size)
    }

    @Test
    fun palabraEncimaDeLaRayaSeParte() {
        val w = 360; val h = 180
        val px = page(w, h)
        grid(px, w)
        val words = listOf(
            word("Punto", 30, 33, 0), word("Cota", 130, 33, 0), word("Nota", 230, 33, 0),
            ScanTables.Word("3850|17", 160, 73, 280, 87, 1),
            word("B", 30, 113, 2), word("3849", 130, 113, 2), word("12", 230, 113, 2)
        )
        val t = find(px, w, h, words).single()
        val row = t.cells.filter { it.row == 1 }.map { it.text }
        assertEquals(listOf("", "3850", "17"), row)
    }

    @Test
    fun tablaSinLineasPorColumnas() {
        val w = 500; val h = 300
        val px = page(w, h)
        val words = ArrayList<ScanTables.Word>()
        val rows = listOf(listOf("Alumno", "Nota", "Estado"), listOf("Pacco", "17", "Aprobado"), listOf("Quispe", "12", "Aprobado"), listOf("Ccama", "09", "Desaprobado"))
        rows.forEachIndexed { r, cells ->
            words += word(cells[0], 40, 40 + r * 30, r)
            words += word(cells[1], 200, 40 + r * 30, r)
            words += word(cells[2], 300, 40 + r * 30, r)
        }
        val t = find(px, w, h, words).single()
        assertEquals(4, t.rowCount)
        assertEquals(3, t.colCount)
        assertEquals("Desaprobado", t.cells.last().text)
    }

    @Test
    fun parrafoNoEsTabla() {
        val w = 600; val h = 300
        val px = page(w, h)
        val words = ArrayList<ScanTables.Word>()
        val text = listOf(
            "La topografía estudia el conjunto de procedimientos para",
            "determinar las posiciones de puntos sobre la superficie de la",
            "tierra por medio de medidas según los tres elementos del",
            "espacio y se representa en planos con su escala"
        )
        text.forEachIndexed { r, line ->
            var x = 30 + (r % 2) * 5
            for (part in line.split(' ')) {
                words += word(part, x, 30 + r * 24, r)
                x += part.length * 8 + 4 + (part.length % 3)
            }
        }
        assertTrue(find(px, w, h, words).isEmpty())
    }

    @Test
    fun rellenoDeCeldaNoEsRayaPeroSeVeSuColor() {
        val w = 360; val h = 180
        val px = page(w, h)
        val pink = -0x203a40
        fill(px, w, 21, 61, 320, 100, pink)
        grid(px, w)
        val words = listOf(
            word("Punto", 30, 33, 0), word("Cota", 130, 33, 0), word("Nota", 230, 33, 0),
            word("A", 30, 73, 1), word("3850", 130, 73, 1), word("17", 230, 73, 1),
            word("B", 30, 113, 2), word("3849", 130, 113, 2), word("12", 230, 113, 2)
        )
        val rules = ScanTables.rules(px, w, h, white, 30, 25, 4)
        val t = ScanTables.find(w, h, rules, words).single()
        assertEquals(3, t.rowCount)
        val fills = ScanTables.fills(px, w, h, t, words, white)
        assertNull(fills[0])
        assertNotNull(fills[3])
        assertEquals(pink and 0xF0F0F0, fills[3]!! and 0xF0F0F0)
    }
}
