# Gana Geo — Android

MVP Android de **Gana Geo**, preparado para subirse directamente a GitHub y compilarse con GitHub Actions.

## Qué incluye

- Nombre e icono definitivo de Gana Geo.
- Interfaz moderna en verde oscuro y verde neón.
- Inicio de sesión con Google mediante Supabase OAuth.
- Deep link de retorno: `ganageo://login-callback`.
- Lectura segura de perfil, Geo ID, puntos, saldo y movimientos.
- Billetera con saldo disponible, pendiente y bloqueado.
- Solicitudes de retiro por Yape, Plin o PayPal.
- Cancelación de retiros pendientes.
- Control de una instalación activa por cuenta y una cuenta activa por identificador de instalación.
- Secciones preparadas para encuestas, ofertas e incentivos por anuncios.
- Compilación automática del APK en GitHub Actions.

## Lo que NO está fingido

Esta versión no inventa ganancias. Las tarjetas de encuestas, ofertas y anuncios permanecen como **“Próximamente”** hasta conectar proveedores reales. Tampoco acredita puntos desde el APK, porque hacerlo del lado del cliente permitiría fraude.

Los retiros se registran en Supabase, pero el envío de dinero sigue siendo manual hasta integrar un proveedor de pagos autorizado.

## 1. Configurar Supabase

Tu proyecto ya usa:

```text
https://pnbpeehcbqkdhjueyldn.supabase.co
```

En Supabase abre **Connect / API Keys** y copia únicamente la clave pública **Publishable** o **anon**.

Nunca uses dentro de Android:

- `service_role`
- contraseña de PostgreSQL
- Client Secret de Google

Copia el archivo:

```text
local.properties.example
```

como:

```text
local.properties
```

Y completa:

```properties
SUPABASE_URL=https://pnbpeehcbqkdhjueyldn.supabase.co
SUPABASE_ANON_KEY=TU_CLAVE_PUBLICA
```

## 2. Agregar el retorno de la app en Supabase

En Supabase entra en:

```text
Authentication → URL Configuration → Redirect URLs
```

Agrega exactamente:

```text
ganageo://login-callback
```

Sin esta dirección, Google iniciará sesión en el navegador pero no podrá regresar a la app.

## 3. Ejecutar las funciones seguras

Como tus seis tablas ya existen, ejecuta únicamente:

```text
supabase/02_secure_app_functions.sql
```

En un proyecto Supabase nuevo, ejecuta primero `supabase/01_schema.sql` y después `supabase/02_secure_app_functions.sql`.

Ese archivo crea:

- `register_my_device`
- `request_withdrawal`
- `cancel_my_withdrawal`

Las funciones bloquean saldo de forma transaccional y no permiten que el APK escriba saldos arbitrarios.

## 4. Compilar en GitHub Actions

En tu repositorio de GitHub crea este secreto:

```text
Settings → Secrets and variables → Actions → New repository secret
```

Nombre:

```text
SUPABASE_ANON_KEY
```

Valor: tu clave pública Publishable/anon de Supabase.

Después entra en:

```text
Actions → Compilar Gana Geo → Run workflow
```

El flujo instala Android 36 y Gradle 8.13 automáticamente. Al terminar, descarga el artefacto `Gana-Geo-APK-...`.

## 5. Nombre del paquete

El paquete actual es:

```text
com.ganageo.app
```

No lo cambies después de publicar en Play Store. Si quieres otro paquete, cámbialo ahora en:

- `app/build.gradle.kts`
- carpetas Kotlin bajo `com/ganageo/app`

## 6. Cliente OAuth Android

El inicio actual usa OAuth en navegador y el cliente web que ya configuraste en Supabase.

Antes de publicar, crea además un cliente OAuth de tipo Android con:

```text
Paquete: com.ganageo.app
SHA-1: la huella de la clave con la que firmarás la versión final
```

No uses la firma debug para la versión publicada.

## Estructura

```text
app/                         Código Android
supabase/                    Esquema base y funciones SQL seguras
.github/workflows/           Compilación automática
logo-gana-geo.png            Logo original
local.properties.example     Plantilla sin secretos
```

## Reglas de seguridad aplicadas

- El usuario solo puede leer sus propios datos mediante RLS.
- El saldo se modifica únicamente en funciones del servidor.
- Las transacciones externas deben tener un ID único para evitar duplicados.
- La instalación se identifica mediante un UUID local, no mediante IMEI. Es un control básico: al reinstalar la app cambia el UUID y la cuenta deberá liberarse o revisarse desde administración.
- No se incluye devolución de dinero por compras propias ni sistemas de compra y reembolso entre amigos.

## Estado real del proyecto

La base visual, el login, la lectura de datos, la billetera, el retiro seguro y el control de dispositivo están implementados.

Para convertirlo en un negocio funcional faltan decisiones y contratos externos:

1. Proveedor de encuestas/ofertas con postback firmado.
2. Integración de anuncios recompensados autorizada.
3. Proceso administrativo de aprobación y pago de retiros.
4. Política de privacidad, términos, soporte y reglas antifraude.
5. Pruebas cerradas de Google Play y firma final de publicación.


## Compatibilidad de compilacion

Esta revision fija las bibliotecas AndroidX en versiones compatibles con Android Gradle Plugin 8.12.2 y compileSdk 36. Evita dependencias que exigen API 37 / AGP 9.x.

## Compilación en GitHub Actions

La versión 0.1.2 lee `SUPABASE_ANON_KEY` de dos lugares, en este orden:

1. `local.properties`
2. Variable de entorno `SUPABASE_ANON_KEY` enviada por GitHub Actions

Si la clave no existe, la compilación falla de forma intencional para evitar generar un APK que muestre “Falta conectar Supabase”.
