package com.ganageo.app.ui.tools

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import java.nio.FloatBuffer

/** Una parte de la hoja que reconoció la IA (en píxeles de la foto). */
internal class DocScanRegion(val kind: Int, val score: Float, val rect: RectF) {
    val label: String get() = DocScanLayoutAi.label(kind)
    val isFigure: Boolean get() = kind in DocScanLayoutAi.FIGURES
}

/**
 * IA local que reconoce las partes de una hoja: títulos, párrafos, imágenes,
 * tablas, encabezados, pies, sellos… Funciona en el celular, sin internet.
 *
 * Modelo: PP-DocLayout-S de PaddlePaddle (licencia Apache 2.0), convertido a
 * ONNX; corre con ONNX Runtime (licencia MIT). El archivo del modelo lo baja
 * GitHub al compilar (ver el flujo de compilación). Si no está, la app sigue
 * funcionando igual, sin IA.
 */
internal object DocScanLayoutAi {
    private const val ASSET = "models/pp_doclayout_s.onnx"
    private const val SIZE = 480
    private const val MIN_SCORE = 0.4f

    // Clases del modelo (23).
    const val PARAGRAPH_TITLE = 0
    const val IMAGE = 1
    const val TEXT = 2
    const val TABLE = 8
    const val DOC_TITLE = 11
    const val HEADER = 13
    const val FOOTER = 15
    const val SEAL = 16
    const val CHART = 18
    const val HEADER_IMAGE = 20
    const val FOOTER_IMAGE = 21

    /** Lo que es dibujo (foto, gráfico, sello): su texto se queda en la imagen. */
    val FIGURES = setOf(IMAGE, SEAL, CHART, HEADER_IMAGE, FOOTER_IMAGE)

    private val names = arrayOf(
        "Subtítulo", "Imagen", "Texto", "Número", "Resumen", "Índice", "Título de figura",
        "Fórmula", "Tabla", "Título de tabla", "Referencia", "Título", "Nota al pie", "Encabezado",
        "Algoritmo", "Pie de página", "Sello", "Título de gráfico", "Gráfico", "Número de fórmula",
        "Imagen de encabezado", "Imagen de pie", "Texto al margen"
    )

    fun label(kind: Int): String = names.getOrNull(kind) ?: "Parte"

    private val lock = Any()
    @Volatile private var session: OrtSession? = null
    @Volatile private var missing = false

    private fun session(context: Context): OrtSession? {
        session?.let { return it }
        if (missing) return null
        synchronized(lock) {
            session?.let { return it }
            if (missing) return null
            return try {
                val bytes = context.applicationContext.assets.open(ASSET).use { it.readBytes() }
                val options = OrtSession.SessionOptions()
                options.setIntraOpNumThreads(2)
                OrtEnvironment.getEnvironment().createSession(bytes, options).also { session = it }
            } catch (error: Throwable) {
                // Sin el archivo del modelo o sin el motor en este celular: se sigue sin IA.
                missing = true
                null
            }
        }
    }

    /** ¿La IA está lista en este celular? */
    fun available(context: Context): Boolean = session(context) != null

    /**
     * Partes de la hoja en [bitmap]. Nunca falla: si algo sale mal devuelve una
     * lista vacía y la hoja se arma como antes.
     */
    fun detect(context: Context, bitmap: Bitmap): List<DocScanRegion> {
        val model = session(context) ?: return emptyList()
        return try {
            run(model, bitmap)
        } catch (error: Throwable) {
            emptyList()
        }
    }

    private fun run(model: OrtSession, bitmap: Bitmap): List<DocScanRegion> {
        val width = bitmap.width
        val height = bitmap.height
        if (width < 10 || height < 10) return emptyList()
        val scaled = Bitmap.createScaledBitmap(bitmap, SIZE, SIZE, true)
        val pixels = IntArray(SIZE * SIZE)
        scaled.getPixels(pixels, 0, SIZE, 0, 0, SIZE, SIZE)
        if (scaled !== bitmap) scaled.recycle()
        // RGB, 0..1, normalizado como ImageNet, por canales (CHW).
        val plane = SIZE * SIZE
        val data = FloatArray(3 * plane)
        for (i in 0 until plane) {
            val c = pixels[i]
            data[i] = (((c shr 16) and 0xFF) / 255f - 0.485f) / 0.229f
            data[plane + i] = (((c shr 8) and 0xFF) / 255f - 0.456f) / 0.224f
            data[2 * plane + i] = ((c and 0xFF) / 255f - 0.406f) / 0.225f
        }
        val env = OrtEnvironment.getEnvironment()
        val image = OnnxTensor.createTensor(env, FloatBuffer.wrap(data), longArrayOf(1, 3, SIZE.toLong(), SIZE.toLong()))
        try {
            val scale = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(floatArrayOf(SIZE / height.toFloat(), SIZE / width.toFloat())), longArrayOf(1, 2)
            )
            try {
                val inputNames = model.inputNames.toList()
                val imageName = inputNames.firstOrNull { it.contains("image", ignoreCase = true) } ?: inputNames.first()
                val scaleName = inputNames.firstOrNull { it != imageName && it.contains("scale", ignoreCase = true) }
                    ?: inputNames.firstOrNull { it != imageName }
                val inputs = HashMap<String, OnnxTensor>()
                inputs[imageName] = image
                if (scaleName != null) inputs[scaleName] = scale
                val result = model.run(inputs)
                try {
                    var rows: Array<*>? = null
                    var count = -1
                    for (index in 0 until result.size()) {
                        when (val value = result.get(index).value) {
                            is Array<*> -> if (value.firstOrNull() is FloatArray) rows = value
                            is IntArray -> if (value.isNotEmpty()) count = value[0]
                            is LongArray -> if (value.isNotEmpty()) count = value[0].toInt()
                            is Int -> count = value
                            is Long -> count = value.toInt()
                        }
                    }
                    val found = rows ?: return emptyList()
                    val limit = if (count in 0..found.size) count else found.size
                    val regions = ArrayList<DocScanRegion>()
                    for (index in 0 until limit) {
                        val row = found[index] as? FloatArray ?: continue
                        if (row.size < 6) continue
                        val kind = row[0].toInt()
                        val score = row[1]
                        if (kind !in names.indices || score < MIN_SCORE) continue
                        val left = row[2].coerceIn(0f, width.toFloat())
                        val top = row[3].coerceIn(0f, height.toFloat())
                        val right = row[4].coerceIn(0f, width.toFloat())
                        val bottom = row[5].coerceIn(0f, height.toFloat())
                        if (right - left < 4f || bottom - top < 4f) continue
                        regions += DocScanRegion(kind, score, RectF(left, top, right, bottom))
                    }
                    return regions
                } finally {
                    result.close()
                }
            } finally {
                scale.close()
            }
        } finally {
            image.close()
        }
    }
}
