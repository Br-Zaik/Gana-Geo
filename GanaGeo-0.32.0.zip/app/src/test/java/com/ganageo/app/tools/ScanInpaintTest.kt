package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class ScanInpaintTest {
    private fun rgb(r: Int, g: Int, b: Int): Int = -0x1000000 or (r shl 16) or (g shl 8) or b
    private fun red(c: Int) = (c shr 16) and 0xFF
    private fun green(c: Int) = (c shr 8) and 0xFF
    private fun blue(c: Int) = c and 0xFF
    private fun close(a: Int, b: Int, tolerance: Int) =
        abs(red(a) - red(b)) <= tolerance && abs(green(a) - green(b)) <= tolerance && abs(blue(a) - blue(b)) <= tolerance

    @Test
    fun borraLetrasBlancasDeUnaBarraAzulSinTocarLaHoja() {
        val width = 100
        val height = 40
        val white = rgb(255, 255, 255)
        val blue = rgb(20, 60, 140)
        val pixels = IntArray(width * height) { index -> if (index / width in 10 until 30) blue else white }
        // Letras blancas (con sombra oscura) dentro de la barra.
        for (y in 14 until 26) for (x in 10 until 90 step 5) {
            pixels[y * width + x] = white
            pixels[y * width + x + 1] = rgb(5, 10, 30)
        }
        ScanInpaint.eraseInk(pixels, width, height, listOf(intArrayOf(8, 12, 92, 28)))
        for (y in 10 until 30) for (x in 0 until width) assertTrue(close(pixels[y * width + x], blue, 3))
        for (y in 0 until 10) for (x in 0 until width) assertEquals(white, pixels[y * width + x])
        for (y in 30 until 40) for (x in 0 until width) assertEquals(white, pixels[y * width + x])
    }

    @Test
    fun respetaUnFondoEnDegradado() {
        val width = 100
        val height = 30
        val pixels = IntArray(width * height) { index ->
            val x = index % width
            rgb(x * 2, 100, 255 - x * 2)
        }
        for (y in 10 until 20) for (x in 30 until 70 step 3) pixels[y * width + x] = rgb(0, 0, 0)
        ScanInpaint.eraseInk(pixels, width, height, listOf(intArrayOf(28, 8, 72, 22)))
        for (y in 10 until 20) for (x in 30 until 70) {
            assertTrue(close(pixels[y * width + x], rgb(x * 2, 100, 255 - x * 2), 8))
        }
    }

    @Test
    fun dejaIntactoLoQueNoEsLetra() {
        val width = 60
        val height = 20
        val paper = rgb(250, 248, 240)
        val pixels = IntArray(width * height) { paper }
        val copy = pixels.copyOf()
        ScanInpaint.eraseInk(pixels, width, height, listOf(intArrayOf(5, 5, 55, 15)))
        assertTrue(pixels.contentEquals(copy))
    }
}
