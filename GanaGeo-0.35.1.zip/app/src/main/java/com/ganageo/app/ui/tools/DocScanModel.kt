package com.ganageo.app.ui.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.InkLook
import com.ganageo.app.tools.OcrLine
import com.ganageo.app.tools.OcrTextRefiner
import com.ganageo.app.tools.ScanDictionary
import com.ganageo.app.tools.ScanDocx
import com.ganageo.app.tools.ScanFontMatch
import com.ganageo.app.tools.ScanGuides
import com.ganageo.app.tools.ScanIcons
import com.ganageo.app.tools.ScanInpaint
import com.ganageo.app.tools.ScanLook
import com.ganageo.app.tools.ScanObjects
import com.ganageo.app.tools.ScanPaper
import com.ganageo.app.tools.ScanRebuild
import com.ganageo.app.tools.ScanShapes
import com.ganageo.app.tools.ScanTables
import com.ganageo.app.tools.ScanBars
import com.ganageo.app.tools.ScanXlsx
import com.ganageo.app.tools.ToolFileUtils
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType0Font
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.util.Matrix
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Escáner de documentos: reconstrucción de la hoja (como "editar un escaneo"
// en Acrobat). Todo pasa en el celular.
//
// 1. Se lee el texto (lector de Google). Si la hoja está chueca o volteada, se
//    endereza y se vuelve a leer. Las partes dudosas o de letra chica se leen
//    otra vez de cerca (ampliadas).
// 2. Se juntan los pedazos de renglón y se quitan los repetidos.
// 3. Se mide cada renglón: color del fondo, de la letra y dónde está la tinta.
// 4. Se elige la letra más parecida (se dibuja cada palabra con cada letra
//    disponible y se compara con la foto) y el tamaño exacto (por el alto real
//    de la tinta). Un mismo estilo queda con un mismo tamaño en toda la hoja.
// 5. Se borran de la foto SOLO los puntos de las letras: fondos, barras de
//    color, fotos y líneas quedan iguales.
// 6. Encima se escribe el texto de verdad. Se edita por párrafo.
// ---------------------------------------------------------------------------

/** Lado más largo con que se trabaja cada página (lectura, vista y guardado). */
internal const val DOC_SCAN_PAGE_EDGE = 2200
internal const val DOC_SCAN_THUMB_EDGE = 256
internal const val DOC_SCAN_MAX_PAGES = 20
internal const val DOC_SCAN_DOCX_MIME =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

private const val DOC_SCAN_DESCENDERS = "gjpqyQ,;()[]{}|"

internal const val DOC_SCAN_ALIGN_LEFT = OcrTextRefiner.ALIGN_LEFT
internal const val DOC_SCAN_ALIGN_CENTER = OcrTextRefiner.ALIGN_CENTER
internal const val DOC_SCAN_ALIGN_RIGHT = OcrTextRefiner.ALIGN_RIGHT
internal const val DOC_SCAN_ALIGN_JUSTIFY = OcrTextRefiner.ALIGN_JUSTIFY

/** Letra automática (la que se parece a la foto). */
internal const val DOC_SCAN_FONT_AUTO = -1

/** Tamaño de hoja automático (el que se detecta en la foto). */
internal const val DOC_SCAN_PAPER_AUTO = -1

// ---------------------------------------------------------------------------
// Letras incluidas (gratis, de uso libre; ver assets/fonts/LICENCIAS.txt).
// Se usan las mismas en la pantalla y dentro del PDF: se ve igual en los dos.
// ---------------------------------------------------------------------------

internal object DocScanFonts {
    /** Nombre que se muestra. */
    val labels = listOf("Arial", "Times", "Calibri", "Cambria", "Angosta", "Moderna", "Máquina")

    /** Nombre de la letra en Word (las primeras tienen las mismas medidas). */
    val wordNames = listOf("Arial", "Times New Roman", "Calibri", "Cambria", "Arial Narrow", "Poppins", "Courier New")

    /** Archivos: normal, negrita, cursiva, negrita cursiva. */
    private val files = listOf(
        listOf("LiberationSans-Regular", "LiberationSans-Bold", "LiberationSans-Italic", "LiberationSans-BoldItalic"),
        listOf("LiberationSerif-Regular", "LiberationSerif-Bold", "LiberationSerif-Italic", "LiberationSerif-BoldItalic"),
        listOf("Carlito-Regular", "Carlito-Bold", "Carlito-Italic", "Carlito-BoldItalic"),
        listOf("Caladea-Regular", "Caladea-Bold", "Caladea-Italic", "Caladea-BoldItalic"),
        listOf("DejaVuSansCondensed", "DejaVuSansCondensed-Bold", "DejaVuSansCondensed-Oblique", "DejaVuSansCondensed-BoldOblique"),
        listOf("Poppins-Regular", "Poppins-Bold", "Poppins-Italic", "Poppins-BoldItalic"),
        // Letra de máquina de escribir (mismas medidas que Courier New).
        listOf("LiberationMono-Regular", "LiberationMono-Bold", "LiberationMono-Italic", "LiberationMono-BoldItalic")
    )

    val count: Int get() = files.size

    private val cache = arrayOfNulls<Typeface>(files.size * 4)

    @Volatile
    private var assets: android.content.res.AssetManager? = null

    fun init(context: Context) {
        if (assets == null) assets = context.applicationContext.assets
    }

    private fun style(bold: Boolean, italic: Boolean) = (if (bold) 1 else 0) + (if (italic) 2 else 0)

    fun file(family: Int, bold: Boolean, italic: Boolean): String =
        "fonts/" + files[family.coerceIn(0, files.lastIndex)][style(bold, italic)] + ".ttf"

    fun typeface(family: Int, bold: Boolean, italic: Boolean): Typeface {
        val safe = family.coerceIn(0, files.lastIndex)
        val index = safe * 4 + style(bold, italic)
        cache[index]?.let { return it }
        val loaded = runCatching { assets?.let { Typeface.createFromAsset(it, file(safe, bold, italic)) } }.getOrNull()
            ?: Typeface.create(
                if (safe == 1 || safe == 3) Typeface.SERIF else Typeface.SANS_SERIF,
                when {
                    bold && italic -> Typeface.BOLD_ITALIC
                    bold -> Typeface.BOLD
                    italic -> Typeface.ITALIC
                    else -> Typeface.NORMAL
                }
            )
        cache[index] = loaded
        return loaded
    }

    fun open(context: Context, family: Int, bold: Boolean, italic: Boolean): java.io.InputStream =
        context.assets.open(file(family, bold, italic))
}

/** Lista de palabras en español para corregir lo mal leído (se carga una vez). */
internal object DocScanWords {
    @Volatile
    private var loaded: ScanDictionary? = null

    fun get(context: Context): ScanDictionary? {
        loaded?.let { return it }
        return synchronized(this) {
            loaded ?: runCatching {
                context.applicationContext.assets.open("dict/es.txt.gz").use { raw ->
                    java.util.zip.GZIPInputStream(raw).bufferedReader(Charsets.UTF_8).use { it.readText() }
                }
            }.getOrNull()?.let { ScanDictionary(it) }?.also { loaded = it }
        }
    }
}

// ---------------------------------------------------------------------------
// Datos
// ---------------------------------------------------------------------------

/** Una página del documento: la foto tal como llegó. */
internal data class DocScanPage(val id: Int, val uri: Uri)

/** Palabra leída (en píxeles de la foto enderezada). */
internal class DocScanWord(val text: String, val box: Rect)

/** Renglón leído, en píxeles de la foto enderezada, con su aspecto. */
internal class DocScanLine(
    val id: Int,
    val text: String,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val background: Int,
    val ink: Int,
    val bold: Boolean,
    /** Borde real de la tinta (sin tildes sueltas); vacío si no se pudo medir. */
    val inkBox: RectF?
)

/** Párrafo: renglones seguidos del mismo estilo. Es lo que se toca y se edita. */
internal class DocScanBlock(
    val id: Int,
    val lines: List<DocScanLine>,
    val text: String,
    val align: Int,
    val ink: Int,
    val background: Int,
    val bold: Boolean,
    /** Letra más parecida (índice en [DocScanFonts]). */
    val family: Int,
    /** Tamaño de letra en píxeles de la foto. */
    val size: Float,
    /** Ancho de la letra respecto a la normal (1 = igual). */
    val scaleX: Float,
    /** Hasta dónde puede crecer a la derecha un título de un solo renglón. */
    val maxRight: Float,
    /** Hasta dónde puede crecer a la izquierda (lo que hay al lado en el mismo renglón). */
    val minLeft: Float = 0f,
    /** Letra inclinada (cursiva) en la foto. */
    val italic: Boolean = false
) {
    val left: Float = lines.minOf { it.left }
    val top: Float = lines.minOf { it.top }
    val right: Float = lines.maxOf { it.right }
    val bottom: Float = lines.maxOf { it.bottom }
}

/** Resultado de leer una página (medidas en píxeles de la foto enderezada). */
internal class DocScanAnalysis(
    val width: Int,
    val height: Int,
    val lines: List<DocScanLine>,
    val blocks: List<DocScanBlock>,
    /** Giro aplicado a la foto para enderezarla (grados). */
    val rotation: Float = 0f,
    /** Hoja detectada (índice en ScanRebuild.papers) o -1. */
    val paper: Int = -1,
    /** Letra principal de la hoja (para el texto que se agregue). */
    val mainFamily: Int = 0,
    /** Logos, fotos e íconos sobre el papel: [izq, arriba, der, abajo) en px. */
    val objects: List<IntArray> = emptyList(),
    val failed: Boolean = false,
    /** Partes de la hoja que reconoció la IA (vacío si no hay IA). */
    val regions: List<DocScanRegion> = emptyList(),
    /** Tablas encontradas (su texto no está en [blocks]). */
    val tables: List<DocScanTable> = emptyList(),
    /** Barras de color con texto encima (se dibujan limpias). */
    val bars: List<ScanBars.Bar> = emptyList()
) {
    val landscape: Boolean get() = width > height

    /** Zonas que la IA marcó como imagen (foto, gráfico, sello). */
    val figures: List<RectF> get() = regions.filter { it.isFigure }.map { it.rect }

    /** Márgenes reales del texto de la hoja (para centrar y alinear como en Word). */
    val margins: ScanGuides.Margins by lazy {
        ScanGuides.margins(lines.map { it.left }, lines.map { it.right }, width.toFloat())
    }
}

/** Lectura terminada: el análisis y la foto ya enderezada. */
internal class DocScanRead(val analysis: DocScanAnalysis, val bitmap: Bitmap)

/** Cambio hecho por la persona a un párrafo. */
internal data class DocScanBlockEdit(
    val text: String,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val align: Int,
    val scale: Float = 1f,
    val deleted: Boolean = false,
    /** Movido (en píxeles de la foto). */
    val dx: Float = 0f,
    val dy: Float = 0f,
    /** Ancho del cuadro de texto (píxeles de la foto); 0 = el de la hoja. */
    val width: Float = 0f
)

/** Cambio hecho a una forma (barra, recuadro o línea) de la hoja reconstruida. */
internal data class DocScanShapeEdit(
    val dx: Float = 0f,
    val dy: Float = 0f,
    /** Largo: 1 = como estaba. */
    val widthScale: Float = 1f,
    /** Color nuevo (null = el de la hoja). */
    val color: Int? = null,
    val deleted: Boolean = false
)

/** Cambio hecho a un logo o foto de la hoja. */
internal data class DocScanObjectEdit(
    val dx: Float = 0f,
    val dy: Float = 0f,
    val scale: Float = 1f,
    val deleted: Boolean = false
)

/** Logo, foto o ícono recortado de la hoja (con su forma: fuera de ella es transparente). */
internal class DocScanObject(val id: Int, val rect: Rect, val bitmap: Bitmap)

/**
 * Forma limpia de la hoja reconstruida (barra o línea), en píxeles de la foto analizada.
 * [color2]: degradado hasta este color (de izquierda a derecha, o de arriba abajo si
 * [vertical]). [insets]: cuánto entra cada esquina (arriba-izq, arriba-der, abajo-der,
 * abajo-izq) para una punta inclinada; null = rectángulo.
 */
internal class DocScanShape(
    val id: Int,
    val kind: Int,
    val rect: RectF,
    val color: Int,
    val radius: Float,
    val color2: Int? = null,
    val vertical: Boolean = false,
    val insets: FloatArray? = null
) {
    val slanted: Boolean get() = insets?.any { it > 0.5f } == true
}

/** Barras con texto encima: sus ids (para no chocar con las demás formas). */
internal const val DOC_SCAN_BAR_SHAPE = 500_000

/** Íconos recortados de las barras: sus ids. */
internal const val DOC_SCAN_BAR_ICON = 600_000

/** Contorno de una forma con punta inclinada (o null si es un rectángulo). */
internal fun docScanShapePath(shape: DocScanShape, rect: RectF): android.graphics.Path? {
    val insets = shape.insets ?: return null
    if (!shape.slanted) return null
    // Las puntas no pueden pasar del ancho (si se achicó la forma).
    val limit = rect.width() / 2f
    val path = android.graphics.Path()
    path.moveTo(rect.left + insets[0].coerceAtMost(limit), rect.top)
    path.lineTo(rect.right - insets[1].coerceAtMost(limit), rect.top)
    path.lineTo(rect.right - insets[2].coerceAtMost(limit), rect.bottom)
    path.lineTo(rect.left + insets[3].coerceAtMost(limit), rect.bottom)
    path.close()
    return path
}

/** Dónde queda una forma con su cambio (en píxeles de la foto analizada). */
internal fun docScanShapeRect(shape: DocScanShape, edit: DocScanShapeEdit?): RectF {
    val rect = RectF(shape.rect)
    if (edit == null) return rect
    rect.right = rect.left + rect.width() * edit.widthScale.coerceIn(0.1f, 6f)
    rect.offset(edit.dx, edit.dy)
    return rect
}

/**
 * Hoja lista para mostrar: el fondo (sin texto ni piezas) y las piezas.
 * [rebuilt]: hoja reconstruida (papel blanco + [shapes] + piezas); si no, es la foto limpia.
 */
internal class DocScanCleaned(
    val base: Bitmap,
    val objects: List<DocScanObject>,
    val shapes: List<DocScanShape> = emptyList(),
    val rebuilt: Boolean = false
) {
    fun recycle() {
        base.recycle()
        objects.forEach { it.bitmap.recycle() }
    }
}

/** Dónde queda una pieza con su cambio (en píxeles de la foto). */
internal fun docScanObjectRect(rect: Rect, edit: DocScanObjectEdit?): RectF {
    if (edit == null) return RectF(rect)
    val width = rect.width() * edit.scale
    val height = rect.height() * edit.scale
    val left = rect.left + edit.dx - (width - rect.width()) / 2f
    val top = rect.top + edit.dy - (height - rect.height()) / 2f
    return RectF(left, top, left + width, top + height)
}

internal fun DocScanBlock.originalEdit() = DocScanBlockEdit(text, bold, italic, ink, align)

/** Texto nuevo agregado en la hoja. x = borde izquierdo, y = línea base (de 0 a 1). */
internal data class DocScanAddedText(
    val id: Int,
    val x: Float,
    val y: Float,
    val text: String,
    /** Tamaño de la letra como fracción del alto de la página. */
    val size: Float,
    val color: Int,
    val bold: Boolean = false,
    val italic: Boolean = false
)

/** Firma o imagen pegada. x, y = esquina de arriba a la izquierda; width = fracción del ancho. */
internal class DocScanSign(
    val id: Int,
    val x: Float,
    val y: Float,
    val width: Float,
    val bitmap: Bitmap
) {
    fun movedBy(dx: Float, dy: Float) =
        DocScanSign(id, (x + dx).coerceIn(-0.2f, 0.98f), (y + dy).coerceIn(-0.2f, 0.98f), width, bitmap)

    fun resizedBy(factor: Float) = DocScanSign(id, x, y, (width * factor).coerceIn(0.05f, 1f), bitmap)
}

/** Todo lo que se cambió en una página. */
internal data class DocScanPageEdits(
    val blocks: Map<Int, DocScanBlockEdit> = emptyMap(),
    val objects: Map<Int, DocScanObjectEdit> = emptyMap(),
    val texts: List<DocScanAddedText> = emptyList(),
    val signs: List<DocScanSign> = emptyList(),
    val shapes: Map<Int, DocScanShapeEdit> = emptyMap(),
    val tables: Map<Int, DocScanTableEdit> = emptyMap()
) {
    val isEmpty: Boolean get() =
        blocks.isEmpty() && objects.isEmpty() && texts.isEmpty() && signs.isEmpty() && shapes.isEmpty() && tables.isEmpty()
}

// ---------------------------------------------------------------------------
// Tablas
// ---------------------------------------------------------------------------

/** Renglones de texto de una tabla: su blockId es este número menos el id de la tabla. */
internal const val DOC_SCAN_TABLE_RUN = -1000

/** Formas de las tablas (rellenos y rayas): ids desde aquí (no chocan con las de la hoja). */
internal const val DOC_SCAN_TABLE_SHAPE = 1_000_000

/** Celda de una tabla. [ink]: dónde estaba su texto en la foto (null = se acomoda solo). */
internal data class DocScanTableCell(
    val row: Int,
    val col: Int,
    val colSpan: Int = 1,
    val text: String,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val color: Int = android.graphics.Color.BLACK,
    val align: Int = DOC_SCAN_ALIGN_LEFT,
    val fill: Int? = null,
    val ink: RectF? = null
)

/** Cuadrícula de una tabla (en píxeles de la foto analizada). */
internal data class DocScanTableData(
    /** Bordes de las columnas (x). */
    val cols: List<Float>,
    /** Bordes de las filas (y). */
    val rows: List<Float>,
    val cells: List<DocScanTableCell>,
    /** [borde de fila][columna]. */
    val hRules: List<List<Boolean>>,
    /** [borde de columna][fila]. */
    val vRules: List<List<Boolean>>,
    /** false = sin rayas (como texto en columnas). */
    val borders: Boolean = true
) {
    val rowCount: Int get() = rows.size - 1
    val colCount: Int get() = cols.size - 1

    fun cellAt(row: Int, col: Int): DocScanTableCell? =
        cells.firstOrNull { it.row == row && col >= it.col && col < it.col + it.colSpan }
}

/** Tabla leída de la hoja. */
internal class DocScanTable(
    val id: Int,
    val data: DocScanTableData,
    /** Tamaño de letra (px de la foto). */
    val size: Float,
    val ruleColor: Int,
    val ruleWidth: Float,
    /** Cajas de las palabras (para borrarlas de la foto). */
    val wordBoxes: List<Rect>
) {
    val rect: RectF get() = RectF(data.cols.first(), data.rows.first(), data.cols.last(), data.rows.last())
}

/** Cambio hecho a una tabla: su cuadrícula nueva completa, y si se movió o borró. */
internal data class DocScanTableEdit(
    val data: DocScanTableData,
    val dx: Float = 0f,
    val dy: Float = 0f,
    val deleted: Boolean = false,
    /** Tamaño de la letra: 1 = como estaba. */
    val scale: Float = 1f
)

/** Tabla ya armada en la hoja (con filas que crecieron si el texto no entraba). */
internal class DocScanPlacedTable(
    val id: Int,
    val data: DocScanTableData,
    /** Bordes ya movidos. */
    val cols: FloatArray,
    val rows: FloatArray,
    val size: Float,
    val family: Int,
    val ruleColor: Int,
    val ruleWidth: Float,
    val deleted: Boolean
) {
    val rect: RectF get() = RectF(cols.first(), rows.first(), cols.last(), rows.last())

    fun cellRect(cell: DocScanTableCell): RectF =
        RectF(cols[cell.col], rows[cell.row], cols[(cell.col + cell.colSpan).coerceAtMost(cols.size - 1)], rows[cell.row + 1])

    /** Celda en el punto (x, y), o null. */
    fun cellAt(x: Float, y: Float): DocScanTableCell? {
        if (deleted) return null
        val row = (0 until rows.size - 1).firstOrNull { y >= rows[it] && y < rows[it + 1] } ?: return null
        val col = (0 until cols.size - 1).firstOrNull { x >= cols[it] && x < cols[it + 1] } ?: return null
        return data.cellAt(row, col)
    }
}

// ---- Cambios a una tabla (cada uno devuelve una tabla nueva) ----

internal fun DocScanTableData.withCell(row: Int, col: Int, change: (DocScanTableCell) -> DocScanTableCell): DocScanTableData {
    val target = cellAt(row, col) ?: return this
    return copy(cells = cells.map { if (it === target) change(it) else it })
}

/** Texto nuevo de una celda: ya no va en el lugar de la foto, se acomoda solo. */
internal fun DocScanTableData.withText(row: Int, col: Int, text: String): DocScanTableData =
    withCell(row, col) { if (it.text == text) it else it.copy(text = text, ink = null) }

/** Fila nueva debajo de [after], con el formato de esa fila y sin texto. La tabla crece hacia abajo. */
internal fun DocScanTableData.insertRow(after: Int): DocScanTableData {
    val r = after.coerceIn(0, rowCount - 1)
    val height = rows[r + 1] - rows[r]
    val newRows = rows.take(r + 2) + (rows.drop(r + 1).map { it + height })
    val moved = cells.map { cell ->
        if (cell.row > r) cell.copy(row = cell.row + 1, ink = cell.ink?.let { RectF(it.left, it.top + height, it.right, it.bottom + height) }) else cell
    }
    val added = cells.filter { it.row == r }.map { it.copy(row = r + 1, text = "", ink = null) }
    val newH = hRules.take(r + 2) + listOf(hRules.getOrElse(r + 1) { List(colCount) { borders } }) + hRules.drop(r + 2)
    val newV = vRules.map { col -> col.take(r + 1) + listOf(col.getOrElse(r) { borders }) + col.drop(r + 1) }
    return copy(rows = newRows, cells = (moved + added).sortedWith(compareBy({ it.row }, { it.col })), hRules = newH, vRules = newV)
}

/** Quita una fila; lo de abajo sube. */
internal fun DocScanTableData.deleteRow(row: Int): DocScanTableData {
    if (rowCount <= 1) return this
    val r = row.coerceIn(0, rowCount - 1)
    val height = rows[r + 1] - rows[r]
    val newRows = rows.take(r + 1) + rows.drop(r + 2).map { it - height }
    val kept = cells.filter { it.row != r }.map { cell ->
        if (cell.row > r) cell.copy(row = cell.row - 1, ink = cell.ink?.let { RectF(it.left, it.top - height, it.right, it.bottom - height) }) else cell
    }
    // El borde de arriba de la fila quitada se queda si había raya en alguno de los dos.
    val merged = (0 until colCount).map { c -> hRules.getOrNull(r)?.getOrNull(c) == true || hRules.getOrNull(r + 1)?.getOrNull(c) == true }
    val newH = hRules.take(r) + listOf(merged) + hRules.drop(r + 2)
    val newV = vRules.map { col -> col.take(r) + col.drop(r + 1) }
    return copy(rows = newRows, cells = kept, hRules = newH, vRules = newV)
}

/** Reparte las columnas en el mismo ancho total (el texto se acomoda solo). */
private fun docScanFitColumns(widths: List<Float>, left: Float, right: Float): List<Float> {
    val total = widths.sum().coerceAtLeast(1f)
    val out = ArrayList<Float>(widths.size + 1)
    var x = left
    out += x
    for (w in widths) {
        x += w * (right - left) / total
        out += x
    }
    return out
}

/** Columna nueva a la derecha de [after] (la tabla mantiene su ancho). */
internal fun DocScanTableData.insertColumn(after: Int): DocScanTableData {
    val c = after.coerceIn(0, colCount - 1)
    val widths = (0 until colCount).map { cols[it + 1] - cols[it] }.toMutableList()
    widths.add(c + 1, widths[c])
    val newCols = docScanFitColumns(widths, cols.first(), cols.last())
    val newCells = ArrayList<DocScanTableCell>()
    for (cell in cells) {
        newCells += when {
            cell.col > c -> cell.copy(col = cell.col + 1, ink = null)
            cell.col + cell.colSpan - 1 > c -> cell.copy(colSpan = cell.colSpan + 1, ink = null)
            else -> cell.copy(ink = null)
        }
    }
    for (r in 0 until rowCount) {
        val covered = newCells.any { it.row == r && c + 1 >= it.col && c + 1 < it.col + it.colSpan }
        if (!covered) {
            val left = cells.firstOrNull { it.row == r && c >= it.col && c < it.col + it.colSpan }
            newCells += DocScanTableCell(
                row = r, col = c + 1, text = "",
                bold = left?.bold ?: false, color = left?.color ?: android.graphics.Color.BLACK,
                align = left?.align ?: DOC_SCAN_ALIGN_LEFT, fill = left?.fill
            )
        }
    }
    val newH = hRules.map { edge -> edge.take(c + 1) + listOf(edge.getOrElse(c) { borders }) + edge.drop(c + 1) }
    val newV = vRules.take(c + 1) + listOf(vRules.getOrElse(c + 1) { List(rowCount) { borders } }) + vRules.drop(c + 1)
    return copy(cols = newCols, cells = newCells.sortedWith(compareBy({ it.row }, { it.col })), hRules = newH, vRules = newV)
}

/** Quita una columna (la tabla mantiene su ancho). */
internal fun DocScanTableData.deleteColumn(col: Int): DocScanTableData {
    if (colCount <= 1) return this
    val c = col.coerceIn(0, colCount - 1)
    val widths = (0 until colCount).map { cols[it + 1] - cols[it] }.toMutableList()
    widths.removeAt(c)
    val newCols = docScanFitColumns(widths, cols.first(), cols.last())
    val newCells = cells.mapNotNull { cell ->
        val end = cell.col + cell.colSpan - 1
        when {
            cell.col == c && cell.colSpan == 1 -> null
            cell.col > c -> cell.copy(col = cell.col - 1, ink = null)
            c in cell.col..end -> cell.copy(colSpan = cell.colSpan - 1, ink = null)
            else -> cell.copy(ink = null)
        }
    }
    val newH = hRules.map { edge -> edge.take(c) + edge.drop(c + 1) }
    // Se quita un borde: el de la derecha (o el de la izquierda si es la última columna).
    val removedEdge = if (c == colCount - 1) c else c + 1
    val newV = vRules.filterIndexed { index, _ -> index != removedEdge }
    return copy(cols = newCols, cells = newCells, hRules = newH, vRules = newV)
}

/** Prende o apaga las rayas. Al prenderlas en una tabla sin rayas, se ponen todas. */
internal fun DocScanTableData.toggleBorders(): DocScanTableData {
    if (borders && (hRules.any { it.any { b -> b } } || vRules.any { it.any { b -> b } })) return copy(borders = false)
    val anyRule = hRules.any { it.any { b -> b } } || vRules.any { it.any { b -> b } }
    if (anyRule) return copy(borders = true)
    val newV = vRules.mapIndexed { e, col ->
        col.mapIndexed { r, _ ->
            // Sin raya en medio de una celda combinada.
            e == 0 || e == colCount || cells.none { it.row == r && e > it.col && e < it.col + it.colSpan }
        }
    }
    return copy(borders = true, hRules = hRules.map { edge -> edge.map { true } }, vRules = newV)
}

/** Celda siguiente (o anterior) en orden de lectura. */
internal fun DocScanTableData.stepCell(row: Int, col: Int, forward: Boolean): Pair<Int, Int> {
    val ordered = cells.sortedWith(compareBy({ it.row }, { it.col }))
    val index = ordered.indexOfFirst { it.row == row && col >= it.col && col < it.col + it.colSpan }
    if (index < 0) return row to col
    val next = ordered.getOrNull(if (forward) index + 1 else index - 1) ?: return row to col
    return next.row to next.col
}

private fun docScanAlignFrom(tableAlign: Int): Int = when (tableAlign) {
    ScanTables.ALIGN_CENTER -> DOC_SCAN_ALIGN_CENTER
    ScanTables.ALIGN_RIGHT -> DOC_SCAN_ALIGN_RIGHT
    else -> DOC_SCAN_ALIGN_LEFT
}

/** "A4 vertical", "Carta horizontal"… o "" si no se reconoce. */
internal fun docScanPaperLabel(paper: Int, landscape: Boolean): String {
    val name = ScanRebuild.papers.getOrNull(paper)?.first ?: return ""
    return name + if (landscape) " horizontal" else " vertical"
}

// ---------------------------------------------------------------------------
// Lectura
// ---------------------------------------------------------------------------

private suspend fun docScanRecognize(recognizer: TextRecognizer, bitmap: Bitmap): Text =
    suspendCancellableCoroutine { continuation ->
        val task = recognizer.process(InputImage.fromBitmap(bitmap, 0))
        task.addOnSuccessListener { result -> if (continuation.isActive) continuation.resume(result) }
        task.addOnFailureListener { error -> if (continuation.isActive) continuation.resumeWithException(error) }
        task.addOnCanceledListener { if (continuation.isActive) continuation.cancel() }
    }

/** Renglón tal como lo entrega el lector (en píxeles de la foto enderezada). */
private class DocScanRawLine(val text: String, val box: Rect, val words: List<DocScanWord>)

private fun docScanMapRect(rect: Rect, scale: Float, offsetX: Int, offsetY: Int) = Rect(
    (rect.left / scale).roundToInt() + offsetX,
    (rect.top / scale).roundToInt() + offsetY,
    (rect.right / scale).roundToInt() + offsetX,
    (rect.bottom / scale).roundToInt() + offsetY
)

private fun docScanRawLines(block: Text.TextBlock, scale: Float = 1f, offsetX: Int = 0, offsetY: Int = 0): List<DocScanRawLine> {
    val result = ArrayList<DocScanRawLine>()
    for (line in block.lines) {
        val box = line.boundingBox ?: continue
        val words = line.elements.mapNotNull { element ->
            element.boundingBox?.let { DocScanWord(element.text, docScanMapRect(it, scale, offsetX, offsetY)) }
        }
        result += DocScanRawLine(line.text, docScanMapRect(box, scale, offsetX, offsetY), words)
    }
    return result
}

/** Ángulo de los renglones (grados): 0 = derecho, 90/180/-90 = hoja girada. */
private fun docScanSkew(result: Text): Float {
    val angles = ArrayList<Float>()
    for (block in result.textBlocks) for (line in block.lines) {
        if (line.text.length < 6) continue
        val points = line.cornerPoints ?: continue
        if (points.size < 2) continue
        val dx = (points[1].x - points[0].x).toDouble()
        val dy = (points[1].y - points[0].y).toDouble()
        if (dx == 0.0 && dy == 0.0) continue
        angles += Math.toDegrees(atan2(dy, dx)).toFloat()
    }
    if (angles.size < 3) return 0f
    fun quarterOf(angle: Float) = Math.floorMod((angle / 90f).roundToInt(), 4)
    val votes = IntArray(4)
    angles.forEach { votes[quarterOf(it)]++ }
    val quarter = votes.indices.maxByOrNull { votes[it] } ?: 0
    val residuals = angles.filter { quarterOf(it) == quarter }.map {
        var value = it - quarter * 90f
        while (value > 180f) value -= 360f
        while (value < -180f) value += 360f
        value
    }
    val residual = ScanRebuild.medianAngle(residuals)
    if (abs(residual) > 15f) return 0f
    val base = when (quarter) {
        1 -> 90f
        2 -> 180f
        3 -> -90f
        else -> 0f
    }
    return base + residual
}

/** Color del papel (mediana de los bordes de la foto), para rellenar al girar. */
private fun docScanPaperColor(bitmap: Bitmap): Int {
    val samples = ArrayList<Int>()
    val stepX = max(1, bitmap.width / 40)
    val stepY = max(1, bitmap.height / 40)
    for (x in 0 until bitmap.width step stepX) {
        samples += bitmap.getPixel(x, 2.coerceAtMost(bitmap.height - 1))
        samples += bitmap.getPixel(x, (bitmap.height - 3).coerceAtLeast(0))
    }
    for (y in 0 until bitmap.height step stepY) {
        samples += bitmap.getPixel(2.coerceAtMost(bitmap.width - 1), y)
        samples += bitmap.getPixel((bitmap.width - 3).coerceAtLeast(0), y)
    }
    if (samples.isEmpty()) return android.graphics.Color.WHITE
    fun channel(shift: Int) = samples.map { (it shr shift) and 0xFF }.sorted()[samples.size / 2]
    return android.graphics.Color.rgb(channel(16), channel(8), channel(0))
}

/** Gira la foto [rotation] grados (para enderezarla). Si no hace falta, devuelve la misma. */
internal fun docScanStraighten(source: Bitmap, rotation: Float): Bitmap {
    if (abs(rotation) < 0.05f) return source
    val quarter = (rotation / 90f).roundToInt()
    val swap = Math.floorMod(quarter, 2) == 1
    val outWidth = if (swap) source.height else source.width
    val outHeight = if (swap) source.width else source.height
    val output = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    canvas.drawColor(docScanPaperColor(source))
    val matrix = android.graphics.Matrix()
    matrix.postTranslate(-source.width / 2f, -source.height / 2f)
    matrix.postRotate(rotation)
    matrix.postTranslate(outWidth / 2f, outHeight / 2f)
    canvas.drawBitmap(source, matrix, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    return output
}

/** Quita íconos leídos como letras al principio o al final ("E PERFIL") y arregla viñetas. */
/** Color de la tinta de una palabra (lo que no es su fondo), o null. */
private fun docScanWordInk(bitmap: Bitmap, box: Rect): Int? {
    val left = box.left.coerceIn(0, bitmap.width - 1)
    val right = box.right.coerceIn(left + 1, bitmap.width)
    val top = box.top.coerceIn(0, bitmap.height - 1)
    val bottom = box.bottom.coerceIn(top + 1, bitmap.height)
    // Fondo: el borde de la caja.
    var br = 0L
    var bg = 0L
    var bb = 0L
    var bn = 0
    for (x in left until right step max(1, (right - left) / 10)) {
        for (y in intArrayOf(top, bottom - 1)) {
            val c = bitmap.getPixel(x, y)
            br += android.graphics.Color.red(c)
            bg += android.graphics.Color.green(c)
            bb += android.graphics.Color.blue(c)
            bn++
        }
    }
    if (bn == 0) return null
    val back = android.graphics.Color.rgb((br / bn).toInt(), (bg / bn).toInt(), (bb / bn).toInt())
    var r = 0L
    var g = 0L
    var b = 0L
    var n = 0
    val stepX = max(1, (right - left) / 14)
    val stepY = max(1, (bottom - top) / 10)
    for (y in top until bottom step stepY) for (x in left until right step stepX) {
        val c = bitmap.getPixel(x, y)
        val d = abs(android.graphics.Color.red(c) - android.graphics.Color.red(back)) +
            abs(android.graphics.Color.green(c) - android.graphics.Color.green(back)) +
            abs(android.graphics.Color.blue(c) - android.graphics.Color.blue(back))
        if (d > 70) {
            r += android.graphics.Color.red(c)
            g += android.graphics.Color.green(c)
            b += android.graphics.Color.blue(c)
            n++
        }
    }
    return if (n == 0) null else android.graphics.Color.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
}

private fun docScanTrimIcons(line: DocScanRawLine, bitmap: Bitmap? = null, dictionary: ScanDictionary? = null): DocScanRawLine {
    if (line.words.isEmpty()) return line
    var words = line.words.sortedBy { it.box.left }
    var iconsChanged = false
    // Ícono de otro color (o más alto) leído como letra: "8 PERFIL", "6 CONTACTO".
    if (bitmap != null && words.size >= 2) {
        val probe = words.take(3).map {
            ScanIcons.Word(it.text, it.box.left, it.box.top, it.box.right, it.box.bottom, runCatching { docScanWordInk(bitmap, it.box) }.getOrNull())
        }
        val drop = ScanIcons.leadingIcons(probe)
        if (drop > 0) {
            words = words.drop(drop)
            iconsChanged = true
        }
    }
    // Borde de un círculo pegado como "l": "lCONOCIMIENTOS" → "CONOCIMIENTOS".
    run {
        val first = words.first()
        val fixed = ScanIcons.stripGlued(first.text) { dictionary?.contains(it) == true }
        if (fixed != first.text) {
            val cut = first.box.width() * (first.text.length - fixed.length) / first.text.length.coerceAtLeast(1)
            words = listOf(DocScanWord(fixed, Rect(first.box.left + cut, first.box.top, first.box.right, first.box.bottom))) + words.drop(1)
            iconsChanged = true
        }
    }
    if (words.size < 2) {
        if (!iconsChanged) return line
        return DocScanRawLine(words.joinToString(" ") { it.text }, Rect(words.first().box), words)
    }
    val height = line.box.height().coerceAtLeast(1)
    fun junk(word: DocScanWord) =
        word.text.length <= 3 && word.text.count { it.isLetterOrDigit() } <= 1 && !word.text.all { it.isDigit() }
    var changed = iconsChanged
    while (words.size >= 2 && junk(words.first()) && words[1].box.left - words.first().box.right > height * 0.9f) {
        // Viñeta leída como letra: "e Ejercicios" → "• Ejercicios".
        val first = words.first()
        if (first.text in setOf("e", "o", "°", "*", "•", "·") && words[1].text.firstOrNull()?.isUpperCase() == true) break
        words = words.drop(1)
        changed = true
    }
    while (words.size >= 2 && junk(words.last()) && words.last().box.left - words[words.size - 2].box.right > height * 0.9f) {
        words = words.dropLast(1)
        changed = true
    }
    val first = words.first()
    if (words.size >= 2 && first.text in setOf("e", "o", "°", "*") &&
        words[1].text.firstOrNull()?.isUpperCase() == true &&
        words[1].box.left - first.box.right > height * 0.3f
    ) {
        words = listOf(DocScanWord("•", first.box)) + words.drop(1)
        changed = true
    }
    if (!changed) return line
    val box = Rect(words.first().box)
    words.forEach { box.union(it.box) }
    return DocScanRawLine(words.joinToString(" ") { it.text }, box, words)
}

/** Muestra de una palabra para comparar letras: forma de la tinta a tamaño chico. */
private class DocScanSample(val text: String, val map: FloatArray, val width: Int, val height: Int)

/** Dibuja palabras con cada letra y las compara con la foto. */
private class DocScanFontJudge {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bounds = Rect()
    private var bitmap: Bitmap? = null
    private var canvas: Canvas? = null
    private var pixels = IntArray(0)

    fun score(sample: DocScanSample, family: Int, bold: Boolean, italic: Boolean = false): Float? {
        val text = ScanFontMatch.withoutMarks(sample.text)
        paint.typeface = DocScanFonts.typeface(family, bold, italic)
        paint.textSize = 100f
        paint.textScaleX = 1f
        paint.getTextBounds(text, 0, text.length, bounds)
        if (bounds.width() <= 0 || bounds.height() <= 0) return null
        val width = sample.width
        val height = sample.height
        var target = bitmap
        if (target == null || target.width < width || target.height < height) {
            target?.recycle()
            target = Bitmap.createBitmap(max(width, 600), max(height, 40), Bitmap.Config.ARGB_8888)
            bitmap = target
            canvas = Canvas(target)
        }
        val drawCanvas = canvas ?: return null
        target.eraseColor(0)
        drawCanvas.save()
        drawCanvas.scale(width / bounds.width().toFloat(), height / bounds.height().toFloat())
        drawCanvas.drawText(text, -bounds.left.toFloat(), -bounds.top.toFloat(), paint)
        drawCanvas.restore()
        if (pixels.size < width * height) pixels = IntArray(width * height)
        target.getPixels(pixels, 0, width, 0, 0, width, height)
        val drawn = FloatArray(width * height) { ((pixels[it] ushr 24) and 0xFF) / 255f }
        val ratio = (bounds.width() * height / bounds.height().toFloat()) / width
        return ScanFontMatch.score(ScanFontMatch.similarity(sample.map, ScanFontMatch.sharpen(drawn)), ratio)
    }

    /** Tamaño (px) y ancho relativo de un renglón con esta letra, por el alto real de la tinta. */
    fun measure(text: String, inkBox: RectF, family: Int, bold: Boolean, italic: Boolean = false): Pair<Float, Float>? {
        val clean = ScanFontMatch.withoutMarks(text)
        paint.typeface = DocScanFonts.typeface(family, bold, italic)
        paint.textSize = 100f
        paint.textScaleX = 1f
        paint.getTextBounds(clean, 0, clean.length, bounds)
        if (bounds.width() <= 0 || bounds.height() <= 0 || inkBox.height() < 3f) return null
        val size = 100f * inkBox.height() / bounds.height()
        val scaleX = inkBox.width() / (bounds.width() * size / 100f)
        return size to scaleX
    }

    fun close() {
        bitmap?.recycle()
        bitmap = null
        canvas = null
    }
}

private fun docScanColorDistance(a: Int, b: Int): Int =
    abs(android.graphics.Color.red(a) - android.graphics.Color.red(b)) +
        abs(android.graphics.Color.green(a) - android.graphics.Color.green(b)) +
        abs(android.graphics.Color.blue(a) - android.graphics.Color.blue(b))

private fun docScanPixels(bitmap: Bitmap, rect: Rect): IntArray? {
    val left = rect.left.coerceIn(0, bitmap.width)
    val top = rect.top.coerceIn(0, bitmap.height)
    val right = rect.right.coerceIn(left, bitmap.width)
    val bottom = rect.bottom.coerceIn(top, bitmap.height)
    if (right - left < 1 || bottom - top < 1) return null
    rect.set(left, top, right, bottom)
    val pixels = IntArray(rect.width() * rect.height())
    bitmap.getPixels(pixels, 0, rect.width(), left, top, rect.width(), rect.height())
    return pixels
}

/**
 * Lee la página y la deja lista para reconstruir. Puede tardar unos segundos:
 * se lee dos veces lo dudoso y se compara cada letra. [onStep] avisa qué está haciendo.
 */
internal suspend fun docScanAnalyze(
    context: Context,
    source: Bitmap,
    onStep: (String) -> Unit = {}
): DocScanRead {
    DocScanFonts.init(context)
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    try {
        onStep("Leyendo el texto…")
        var bitmap = source
        var result = try {
            docScanRecognize(recognizer, bitmap)
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            return DocScanRead(DocScanAnalysis(source.width, source.height, emptyList(), emptyList(), failed = true), source)
        }

        // 1) Enderezar si está chueca o girada, y volver a leer.
        var rotation = 0f
        val skew = withContext(Dispatchers.Default) { docScanSkew(result) }
        if (abs(skew) >= 0.35f) {
            onStep("Enderezando la hoja…")
            rotation = -skew
            bitmap = withContext(Dispatchers.Default) { docScanStraighten(source, rotation) }
            result = runCatching { docScanRecognize(recognizer, bitmap) }.getOrElse {
                if (it is kotlinx.coroutines.CancellationException) throw it
                rotation = 0f
                if (bitmap !== source) bitmap.recycle()
                bitmap = source
                result
            }
        }

        // 2) Lo dudoso o de letra chica se vuelve a leer ampliado.
        onStep("Revisando de cerca…")
        val raw = ArrayList<DocScanRawLine>()
        for (block in result.textBlocks) {
            val first = docScanRawLines(block)
            if (first.isEmpty()) continue
            var chosen = first
            val heights = first.map { it.box.height() }.sorted()
            val lineHeight = heights[heights.size / 2]
            val text = first.joinToString(" ") { it.text }
            val quality = ScanRebuild.textScore(text)
            val area = Rect(block.boundingBox ?: first.first().box)
            first.forEach { area.union(it.box) }
            if (lineHeight >= 6 && (lineHeight < 30 || quality < 0.96f)) {
                val margin = (lineHeight * 0.6f).roundToInt()
                val crop = Rect(area.left - margin, area.top - margin, area.right + margin, area.bottom + margin)
                crop.intersect(0, 0, bitmap.width, bitmap.height)
                var factor = (44f / lineHeight).coerceIn(1.3f, 3f)
                val pixelsAfter = crop.width().toFloat() * crop.height() * factor * factor
                if (pixelsAfter > 9_000_000f) factor = sqrt(9_000_000f / (crop.width().toFloat() * crop.height()))
                if (factor >= 1.15f && crop.width() > 4 && crop.height() > 4) {
                    val again = runCatching {
                        val piece = Bitmap.createBitmap(bitmap, crop.left, crop.top, crop.width(), crop.height())
                        val scaled = Bitmap.createScaledBitmap(
                            piece, (crop.width() * factor).roundToInt(), (crop.height() * factor).roundToInt(), true
                        )
                        if (piece !== bitmap && piece !== scaled) piece.recycle()
                        try {
                            val read = docScanRecognize(recognizer, scaled)
                            read.textBlocks.flatMap { docScanRawLines(it, factor, crop.left, crop.top) }
                        } finally {
                            scaled.recycle()
                        }
                    }.getOrElse {
                        if (it is kotlinx.coroutines.CancellationException) throw it
                        emptyList()
                    }.filter { line ->
                        val centerX = line.box.exactCenterX()
                        val centerY = line.box.exactCenterY()
                        centerX >= area.left - margin / 2 && centerX <= area.right + margin / 2 &&
                            centerY >= area.top - margin / 2 && centerY <= area.bottom + margin / 2
                    }
                    if (again.isNotEmpty()) {
                        val againText = again.joinToString(" ") { it.text }
                        val ratio = againText.length / text.length.coerceAtLeast(1).toFloat()
                        val againQuality = ScanRebuild.textScore(againText)
                        if (ratio in 0.8f..1.3f && againQuality > quality + 0.015f) chosen = again
                    }
                }
            }
            raw += chosen
        }

        // 3) La IA reconoce las partes de la hoja (títulos, imágenes, tablas…).
        onStep("La IA reconoce las partes de la hoja…")
        val regions = withContext(Dispatchers.Default) { DocScanLayoutAi.detect(context, bitmap) }

        onStep("Corrigiendo palabras…")
        val dictionary = withContext(Dispatchers.IO) { DocScanWords.get(context) }
        onStep("Midiendo la letra y buscando logos y fotos…")
        val analysis = withContext(Dispatchers.Default) { docScanMeasure(bitmap, raw, rotation, dictionary, regions) }
        return DocScanRead(analysis, bitmap)
    } finally {
        runCatching { recognizer.close() }
    }
}

/**
 * Barras de color con texto encima (títulos, etiquetas). Se miden para dibujarlas
 * limpias, como en Word; el texto que está encima queda en su propio renglón y sin
 * las letras falsas que eran el ícono del inicio. Devuelve los renglones (partidos
 * donde cambia el fondo), las barras y a qué barra va cada renglón (-1 = papel).
 */
private fun docScanFindBars(bitmap: Bitmap, lines: List<DocScanRawLine>): Triple<List<DocScanRawLine>, List<ScanBars.Bar>, IntArray> {
    val none = Triple(lines, emptyList<ScanBars.Bar>(), IntArray(lines.size) { -1 })
    if (lines.isEmpty()) return none
    val width = bitmap.width
    val height = bitmap.height
    // Papel: lo más común de la hoja (en una copia chica).
    val small = Bitmap.createScaledBitmap(bitmap, max(1, width / 4), max(1, height / 4), true)
    val paper = try {
        val px = IntArray(small.width * small.height)
        small.getPixels(px, 0, small.width, 0, 0, small.width, small.height)
        ScanObjects.paperColor(px, small.width, small.height).takeIf { it != -1 } ?: android.graphics.Color.WHITE
    } finally {
        if (small !== bitmap) small.recycle()
    }
    fun inkOf(box: Rect): InkLook? {
        val pad = max(3, box.height() / 3)
        val zone = Rect(box.left - pad, box.top - pad, box.right + pad, box.bottom + pad)
        val pixels = docScanPixels(bitmap, zone) ?: return null
        return runCatching {
            ScanLook.measure(pixels, zone.width(), zone.height(), box.left - zone.left, box.top - zone.top, box.right - zone.left, box.bottom - zone.top)
        }.getOrNull()
    }
    val bars = ArrayList<ScanBars.Bar>()
    for (line in lines) {
        if (line.words.isEmpty()) continue
        val look = inkOf(line.box) ?: continue
        // Fondo de cada palabra: papel (null) o un color.
        val backgrounds = line.words.map { word ->
            val rect = Rect(word.box)
            val pixels = docScanPixels(bitmap, rect) ?: return@map null
            ScanBars.dominant(pixels, rect.width(), rect.height(), intArrayOf(0, 0, rect.width(), rect.height()), paper, look.ink)
        }
        if (backgrounds.all { it == null }) continue
        val boxes = line.words.map { intArrayOf(it.box.left, it.box.top, it.box.right, it.box.bottom) }
        for (segment in ScanBars.segments(backgrounds, boxes)) {
            if (backgrounds[segment.first()] == null) continue
            val box = Rect(line.words[segment.first()].box)
            segment.forEach { box.union(line.words[it].box) }
            if (bars.any { it.contains(box.exactCenterX(), box.exactCenterY()) }) continue
            val textHeight = box.height().coerceAtLeast(4)
            val ink = inkOf(box)?.ink ?: look.ink
            // Ventana: todo el ancho, unos renglones arriba y abajo.
            val top = (box.top - textHeight * 3).coerceAtLeast(0)
            val bottom = (box.bottom + textHeight * 3).coerceAtMost(height)
            if (bottom - top < 4) continue
            val window = IntArray(width * (bottom - top))
            bitmap.getPixels(window, 0, width, 0, top, width, bottom - top)
            val nearby = lines.filter { it.box.bottom > top && it.box.top < bottom }
            val bar = runCatching {
                ScanBars.find(
                    window, width, bottom - top, paper,
                    intArrayOf(box.left, box.top - top, box.right, box.bottom - top),
                    nearby.flatMap { it.words }.map { intArrayOf(it.box.left, it.box.top - top, it.box.right, it.box.bottom - top) },
                    ink,
                    nearby.map { intArrayOf(it.box.left, it.box.top - top, it.box.right, it.box.bottom - top) }
                )
            }.getOrNull() ?: continue
            bars += bar.shifted(0f, top.toFloat())
        }
    }
    if (bars.isEmpty()) return none
    // Cada renglón se parte donde entra o sale de una barra; sin las letras del ícono.
    val outLines = ArrayList<DocScanRawLine>()
    val outBars = ArrayList<Int>()
    for (line in lines) {
        val owner = line.words.map { word ->
            bars.indexOfFirst { it.contains(word.box.exactCenterX(), word.box.exactCenterY()) }
        }
        if (owner.all { it < 0 } || line.words.isEmpty()) {
            outLines += line
            outBars += -1
            continue
        }
        var start = 0
        for (k in 1..line.words.size) {
            if (k < line.words.size && owner[k] == owner[start]) continue
            val barIndex = owner[start]
            var words = line.words.subList(start, k).toList()
            if (barIndex >= 0) {
                val kept = ScanBars.trimWords(
                    words.map { it.text to intArrayOf(it.box.left, it.box.top, it.box.right, it.box.bottom) },
                    bars[barIndex].icons.map { intArrayOf(it[0], it[1], it[2], it[3]) }
                )
                words = kept.map { (text, b) -> DocScanWord(text, Rect(b[0], b[1], b[2], b[3])) }
            }
            if (words.isNotEmpty()) {
                val box = Rect(words.first().box)
                words.forEach { box.union(it.box) }
                outLines += DocScanRawLine(words.joinToString(" ") { it.text }, box, words)
                outBars += barIndex
            }
            start = k
        }
    }
    return Triple(outLines, bars, outBars.toIntArray())
}

/** Tabla encontrada, antes de medir su letra (en píxeles de la foto). */
private class DocScanFoundTable(
    val cols: FloatArray,
    val rows: FloatArray,
    val cells: List<ScanTables.Cell>,
    /** Caja del texto de cada celda (null si está vacía). */
    val cellBoxes: List<Rect?>,
    val fills: List<Int?>,
    val hRules: Array<BooleanArray>,
    val vRules: Array<BooleanArray>,
    val ruleColor: Int,
    val ruleWidth: Float,
    val wordBoxes: List<Rect>
)

/**
 * Busca tablas (con cuadrícula, con rayas o sin líneas) y saca sus palabras de los
 * renglones: el texto de una tabla va en sus celdas, no en párrafos.
 * Trabaja en una copia de hasta 2000 px (las rayas finas se siguen viendo).
 */
private fun docScanFindTables(
    bitmap: Bitmap,
    lines: List<DocScanRawLine>,
    regions: List<DocScanRegion>
): Pair<List<DocScanRawLine>, List<DocScanFoundTable>> {
    val allWords = ArrayList<Pair<Int, DocScanWord>>()
    lines.forEachIndexed { index, line -> line.words.forEach { allWords += index to it } }
    if (allWords.size < 4) return lines to emptyList()
    val longSide = max(bitmap.width, bitmap.height)
    val k = if (longSide > 2000) 2000f / longSide else 1f
    val work = if (k < 1f) {
        Bitmap.createScaledBitmap(bitmap, (bitmap.width * k).roundToInt().coerceAtLeast(1), (bitmap.height * k).roundToInt().coerceAtLeast(1), true)
    } else {
        bitmap
    }
    try {
        val width = work.width
        val height = work.height
        val pixels = IntArray(width * height)
        work.getPixels(pixels, 0, width, 0, 0, width, height)
        val words = allWords.map { (line, word) ->
            ScanTables.Word(
                word.text,
                (word.box.left * k).toInt(), (word.box.top * k).toInt(),
                (word.box.right * k).roundToInt(), (word.box.bottom * k).roundToInt(),
                line
            )
        }
        val textHeight = words.map { it.h }.sorted()[words.size / 2].coerceAtLeast(4)
        val paper = ScanObjects.paperColor(pixels, width, height).takeIf { it != -1 } ?: docScanPaperColor(work)
        val rules = ScanTables.rules(
            pixels, width, height, paper,
            minHorizontal = max(30, width / 25),
            minVertical = (textHeight * 1.8f).roundToInt(),
            maxThick = max(4, textHeight / 4)
        )
        val zones = regions.filter { it.kind == DocScanLayoutAi.TABLE }.map {
            intArrayOf((it.rect.left * k).toInt(), (it.rect.top * k).toInt(), (it.rect.right * k).roundToInt(), (it.rect.bottom * k).roundToInt())
        }
        val tables = ScanTables.find(width, height, rules, words, zones)
        if (tables.isEmpty()) return lines to emptyList()
        val used = HashSet<Int>()
        val found = tables.mapNotNull { table ->
            val fills = runCatching { ScanTables.fills(pixels, width, height, table, words, paper) }
                .getOrElse { List(table.cells.size) { null } }
            // Una hoja a dos columnas (barra lateral de color) no es tabla.
            if (!ScanTables.plausible(table, fills)) return@mapNotNull null
            used += table.wordIds
            val cellBoxes = table.cells.map { cell ->
                if (cell.words.isEmpty()) return@map null
                val box = Rect(allWords[cell.words.first()].second.box)
                cell.words.forEach { box.union(allWords[it].second.box) }
                // Una palabra partida en dos celdas: cada celda se queda con su parte.
                val cellRect = Rect(
                    (table.cols[cell.col] / k).toInt(), (table.rows[cell.row] / k).toInt(),
                    (table.cols[cell.col + cell.colSpan] / k).roundToInt(), (table.rows[cell.row + 1] / k).roundToInt()
                )
                if (!box.intersect(cellRect)) null else box
            }
            DocScanFoundTable(
                FloatArray(table.cols.size) { table.cols[it] / k },
                FloatArray(table.rows.size) { table.rows[it] / k },
                table.cells,
                cellBoxes,
                fills,
                table.hRules,
                table.vRules,
                table.ruleColor,
                (table.ruleWidth / k).coerceAtLeast(1f),
                table.wordIds.map { Rect(allWords[it].second.box) }
            )
        }
        // Los renglones se quedan sin las palabras de las tablas.
        val wordIndex = HashMap<DocScanWord, Int>()
        allWords.forEachIndexed { index, (_, word) -> wordIndex[word] = index }
        val remaining = lines.mapNotNull { line ->
            val kept = line.words.filter { (wordIndex[it] ?: -1) !in used }
            when {
                kept.size == line.words.size -> line
                kept.isEmpty() -> null
                else -> {
                    val box = Rect(kept.first().box)
                    kept.forEach { box.union(it.box) }
                    DocScanRawLine(kept.joinToString(" ") { it.text }, box, kept)
                }
            }
        }
        return remaining to found
    } finally {
        if (work !== bitmap) work.recycle()
    }
}

/** Mide la letra, negrita, color y alineación de cada celda y arma la tabla final. */
private fun docScanFinishTable(
    id: Int,
    found: DocScanFoundTable,
    bitmap: Bitmap,
    measure: (text: String, ink: RectF, bold: Boolean) -> Float?,
    strokeReference: Pair<FloatArray, FloatArray>,
    dictionary: ScanDictionary?
): DocScanTable {
    class CellLook(val look: InkLook, val ink: RectF?)
    val looks = found.cells.mapIndexed { index, _ ->
        val box = found.cellBoxes[index] ?: return@mapIndexed null
        val pad = max(3, box.height() / 3)
        val zone = Rect(box.left - pad, box.top - pad, box.right + pad, box.bottom + pad)
        val pixels = docScanPixels(bitmap, zone) ?: return@mapIndexed null
        val look = runCatching {
            ScanLook.measure(pixels, zone.width(), zone.height(), box.left - zone.left, box.top - zone.top, box.right - zone.left, box.bottom - zone.top)
        }.getOrNull() ?: return@mapIndexed null
        val inner = Rect(box.left - 1, box.top - 1, box.right + 1, box.bottom + 1)
        val ink = docScanPixels(bitmap, inner)?.let {
            val map = ScanFontMatch.inkMap(it, inner.width(), inner.height(), look.background, look.ink)
            ScanFontMatch.inkBounds(map, inner.width(), inner.height())?.let { b ->
                RectF((inner.left + b[0]).toFloat(), (inner.top + b[1]).toFloat(), (inner.left + b[2]).toFloat(), (inner.top + b[3]).toFloat())
            }
        }
        CellLook(look, ink)
    }
    // Negrita: se compara con el grosor de toda la hoja.
    val measured = found.cells.indices.filter { looks[it] != null && found.cellBoxes[it] != null }
    val strokes = strokeReference.first + FloatArray(measured.size) { looks[measured[it]]!!.look.stroke }
    val heights = strokeReference.second + FloatArray(measured.size) { found.cellBoxes[measured[it]]!!.height().toFloat() }
    val boldAll = ScanLook.boldFlags(strokes, heights)
    val bold = BooleanArray(found.cells.size)
    measured.forEachIndexed { k, index -> bold[index] = boldAll[strokeReference.first.size + k] }
    val wordHeights = found.cellBoxes.filterNotNull().map { it.height() }.sorted()
    val lineHeight = (wordHeights.getOrNull(wordHeights.size / 2) ?: 12).toFloat()
    val sizes = found.cells.indices.mapNotNull { index ->
        val ink = looks[index]?.ink ?: return@mapNotNull null
        val text = found.cells[index].text
        if (text.isBlank() || ink.height() > lineHeight * 1.6f) return@mapNotNull null
        measure(text, ink, bold[index])
    }.filter { it > 2f }
    val size = if (sizes.isEmpty()) lineHeight * 0.9f else ScanRebuild.quantile(sizes, 0.5f).coerceIn(lineHeight * 0.5f, lineHeight * 2f)
    val cells = found.cells.mapIndexed { index, cell ->
        val raw = cell.text
        val fixed = OcrTextRefiner.fixLine(raw).trim()
        val text = dictionary?.let { runCatching { it.fixText(fixed) }.getOrDefault(fixed) } ?: fixed
        val look = looks[index]
        // Texto de un solo renglón: se dibuja donde estaba. Si ocupaba varios renglones, se acomoda solo.
        val ink = look?.ink?.takeIf { it.height() <= lineHeight * 1.6f }
        DocScanTableCell(
            row = cell.row,
            col = cell.col,
            colSpan = cell.colSpan,
            text = text,
            bold = bold[index],
            color = look?.look?.ink ?: android.graphics.Color.BLACK,
            align = docScanAlignFrom(cell.align),
            fill = found.fills.getOrNull(index),
            ink = ink
        )
    }
    val data = DocScanTableData(
        cols = found.cols.toList(),
        rows = found.rows.toList(),
        cells = cells,
        hRules = found.hRules.map { it.toList() },
        vRules = found.vRules.map { it.toList() },
        borders = true
    )
    return DocScanTable(id, data, size, found.ruleColor, found.ruleWidth, found.wordBoxes)
}

/** Junta renglones, mide colores, arma párrafos y elige letra y tamaño. */
private fun docScanMeasure(
    bitmap: Bitmap,
    raw: List<DocScanRawLine>,
    rotation: Float,
    dictionary: ScanDictionary?,
    regions: List<DocScanRegion> = emptyList()
): DocScanAnalysis {
    val width = bitmap.width
    val height = bitmap.height

    // Pedazos del mismo renglón juntos; repetidos fuera; íconos fuera.
    val trimmedAll = raw.map { docScanTrimIcons(it, bitmap, dictionary) }
    // Tablas: su texto va en celdas (se sacan de los renglones).
    val (afterTables, foundTables) = runCatching { docScanFindTables(bitmap, trimmedAll, regions) }
        .getOrElse { trimmedAll to emptyList() }
    val tableRects = foundTables.map { RectF(it.cols.first(), it.rows.first(), it.cols.last(), it.rows.last()) }
    // Barras de color con texto encima: se dibujan limpias (y el texto sin el ícono).
    val (trimmed, bars, lineBar) = runCatching { docScanFindBars(bitmap, afterTables) }
        .getOrElse { Triple(afterTables, emptyList(), IntArray(afterTables.size) { -1 }) }
    val barRects = bars.map { bar ->
        val rect = RectF(bar.left, bar.top, bar.right, bar.bottom)
        bar.icons.forEach { rect.union(it[0].toFloat(), it[1].toFloat(), it[2].toFloat(), it[3].toFloat()) }
        rect
    }
    val groups = runCatching {
        ScanRebuild.mergeLines(trimmed.map { OcrLine(it.text, it.box.left, it.box.top, it.box.right, it.box.bottom) })
    }.getOrElse { trimmed.indices.map { intArrayOf(it) } }.flatMap { group ->
        // Un renglón sobre una barra no se junta con lo de al lado (otra barra o el papel).
        if (group.size == 1) listOf(group) else group.groupBy { lineBar.getOrElse(it) { -1 } }.values.map { it.toIntArray() }
    }
    val mergedAndObjects = groups.map { group ->
        if (group.size == 1) {
            trimmed[group[0]]
        } else {
            val parts = group.map { trimmed[it] }
            val box = Rect(parts.first().box)
            parts.forEach { box.union(it.box) }
            DocScanRawLine(parts.joinToString(" ") { it.text }, box, parts.flatMap { it.words })
        }
    }.mapNotNull { line ->
        val box = Rect(line.box)
        if (!box.intersect(0, 0, width, height) || box.width() < 2 || box.height() < 4) return@mapNotNull null
        val fixed = OcrTextRefiner.fixLine(line.text).trim()
        val text = dictionary?.let { runCatching { it.fixText(fixed) }.getOrDefault(fixed) } ?: fixed
        if (text.none { it.isLetterOrDigit() }) return@mapNotNull null
        DocScanRawLine(text, box, line.words)
    }.let { found -> docScanFindObjects(bitmap, found, regions.filter { it.isFigure }.map { it.rect }, tableRects + barRects) }
    val merged = mergedAndObjects.first
    val objects = mergedAndObjects.second

    // Aspecto de cada renglón y borde real de la tinta.
    val looks = ArrayList<InkLook>(merged.size)
    val inkBoxes = ArrayList<RectF?>(merged.size)
    for (line in merged) {
        val box = line.box
        val pad = max(3, box.height() / 3)
        val zone = Rect(box.left - pad, box.top - pad, box.right + pad, box.bottom + pad)
        val pixels = docScanPixels(bitmap, zone)
        val look = if (pixels == null) {
            InkLook(android.graphics.Color.WHITE, android.graphics.Color.BLACK, 0f)
        } else {
            runCatching {
                ScanLook.measure(
                    pixels, zone.width(), zone.height(),
                    box.left - zone.left, box.top - zone.top, box.right - zone.left, box.bottom - zone.top
                )
            }.getOrElse { InkLook(android.graphics.Color.WHITE, android.graphics.Color.BLACK, 0f) }
        }
        looks += look
        val inner = Rect(box.left - 1, box.top - 1, box.right + 1, box.bottom + 1)
        val innerPixels = docScanPixels(bitmap, inner)
        inkBoxes += innerPixels?.let {
            val map = ScanFontMatch.inkMap(it, inner.width(), inner.height(), look.background, look.ink)
            ScanFontMatch.inkBounds(map, inner.width(), inner.height())?.let { b ->
                RectF((inner.left + b[0]).toFloat(), (inner.top + b[1]).toFloat(), (inner.left + b[2]).toFloat(), (inner.top + b[3]).toFloat())
            }
        }
    }
    val bold = ScanLook.boldFlags(
        FloatArray(merged.size) { looks[it].stroke },
        FloatArray(merged.size) { merged[it].box.height().toFloat() }
    )
    val lines = merged.mapIndexed { index, line ->
        DocScanLine(
            id = index,
            text = line.text,
            left = line.box.left.toFloat(),
            top = line.box.top.toFloat(),
            right = line.box.right.toFloat(),
            bottom = line.box.bottom.toFloat(),
            background = looks[index].background,
            ink = looks[index].ink,
            bold = bold[index],
            inkBox = inkBoxes[index]
        )
    }
    fun finishTables(judge: DocScanFontJudge, family: Int): List<DocScanTable> = runCatching {
        val reference = FloatArray(merged.size) { looks[it].stroke } to FloatArray(merged.size) { merged[it].box.height().toFloat() }
        foundTables.mapIndexed { index, found ->
            docScanFinishTable(
                index, found, bitmap,
                { text, ink, isBold -> judge.measure(text, ink, family, isBold)?.first },
                reference, dictionary
            )
        }
    }.getOrElse { emptyList() }
    if (lines.isEmpty()) {
        val judge = DocScanFontJudge()
        val tables = try {
            finishTables(judge, 0)
        } finally {
            judge.close()
        }
        return DocScanAnalysis(
            width, height, emptyList(), emptyList(), rotation, ScanRebuild.paperOf(width, height),
            objects = objects, regions = regions, tables = tables, bars = bars
        )
    }

    // Párrafos.
    val located = lines.map {
        OcrLine(it.text, it.left.roundToInt(), it.top.roundToInt(), it.right.roundToInt(), it.bottom.roundToInt())
    }
    val paragraphGroups = runCatching {
        OcrTextRefiner.paragraphs(located, width) { a, b ->
            val first = lines[a]
            val second = lines[b]
            val firstHeight = first.bottom - first.top
            val secondHeight = second.bottom - second.top
            first.bold == second.bold &&
                abs(firstHeight - secondHeight) <= max(firstHeight, secondHeight) * 0.25f &&
                docScanColorDistance(first.ink, second.ink) < 120 &&
                docScanColorDistance(first.background, second.background) < 90
        }
    }.getOrElse { lines.indices.map { intArrayOf(it) } }.mapNotNull { group -> group.map { lines[it] }.takeIf { it.isNotEmpty() } }

    // Letra más parecida: se vota por tipo de texto (normal / negrita, chico / grande).
    val judge = DocScanFontJudge()
    try {
        val sortedHeights = lines.map { it.bottom - it.top }.sorted()
        val typicalHeight = sortedHeights[sortedHeights.size / 2]
        fun kind(line: DocScanLine, isBold: Boolean) = (if (isBold) 1 else 0) + (if (line.bottom - line.top > typicalHeight * 1.6f) 2 else 0)
        val totals = Array(4) { FloatArray(DocScanFonts.count) }
        // Cada párrafo también guarda su propio voto (un título puede tener otra letra).
        val paraTotals = Array(paragraphGroups.size) { FloatArray(DocScanFonts.count) }
        val paraLetters = IntArray(paragraphGroups.size)
        val paraSamples = Array(paragraphGroups.size) { ArrayList<DocScanSample>() }
        val wordRect = Rect()
        for ((groupIndex, members) in paragraphGroups.withIndex()) {
            val blockBold = members.count { it.bold } * 2 > members.size
            for (line in members) {
                val rawLine = merged[line.id]
                val words = rawLine.words.filter { word -> word.text.count { it.isLetter() } >= 3 }
                    .sortedByDescending { it.text.length }.take(5)
                for (word in words) {
                    wordRect.set(word.box.left - 2, word.box.top - 2, word.box.right + 2, word.box.bottom + 2)
                    val pixels = docScanPixels(bitmap, wordRect) ?: continue
                    val map = ScanFontMatch.inkMap(pixels, wordRect.width(), wordRect.height(), line.background, line.ink)
                    val b = ScanFontMatch.inkBounds(map, wordRect.width(), wordRect.height()) ?: continue
                    val inkWidth = b[2] - b[0]
                    val inkHeight = b[3] - b[1]
                    if (inkHeight < 8 || inkWidth < 4) continue
                    val sampleHeight = min(inkHeight, 40)
                    val sampleWidth = (inkWidth * sampleHeight / inkHeight.toFloat()).roundToInt().coerceIn(4, 600)
                    val sample = DocScanSample(
                        word.text,
                        ScanFontMatch.resample(map, wordRect.width(), b, sampleWidth, sampleHeight),
                        sampleWidth,
                        sampleHeight
                    )
                    val bucket = totals[kind(line, blockBold)]
                    val own = paraTotals[groupIndex]
                    for (family in 0 until DocScanFonts.count) {
                        val score = judge.score(sample, family, blockBold) ?: continue
                        bucket[family] += score * word.text.length
                        own[family] += score * word.text.length
                    }
                    paraLetters[groupIndex] += word.text.length
                    paraSamples[groupIndex] += sample
                }
            }
        }
        fun bestFamily(kind: Int): Int {
            val order = listOf(kind, kind xor 2, kind xor 1, 0)
            for (candidate in order) {
                val bucket = totals[candidate]
                if (bucket.any { it != 0f }) return bucket.indices.maxByOrNull { bucket[it] } ?: 0
            }
            return 0
        }

        // Párrafos con su letra, tamaño y ancho.
        class Draft(
            val members: List<DocScanLine>, val bold: Boolean, val family: Int, var size: Float, var scaleX: Float, val align: Int,
            val italic: Boolean
        )
        val drafts = paragraphGroups.mapIndexed { groupIndex, members ->
            val blockBold = members.count { it.bold } * 2 > members.size
            var family = bestFamily(kind(members.first(), blockBold))
            // Con bastantes letras y una letra claramente más parecida, el párrafo usa la suya.
            val own = paraTotals[groupIndex]
            if (paraLetters[groupIndex] >= 30) {
                val ownBest = own.indices.maxByOrNull { own[it] } ?: family
                if (ownBest != family && own[ownBest] > own[family] * 1.05f) family = ownBest
            }
            // Cursiva: la misma letra inclinada se parece claramente más a la foto.
            var italic = false
            if (paraLetters[groupIndex] >= 8 && own[family] > 0f) {
                var slanted = 0f
                for (sample in paraSamples[groupIndex]) {
                    slanted += (judge.score(sample, family, blockBold, italic = true) ?: 0f) * sample.text.length
                }
                italic = slanted > own[family] * 1.06f
            }
            val measured = members.mapNotNull { line -> line.inkBox?.let { judge.measure(line.text, it, family, blockBold, italic) } }
                .filter { (size, _) -> size > 2f }
            val boxHeights = members.map { it.bottom - it.top }.sorted()
            val fallbackSize = boxHeights[boxHeights.size / 2] * 0.9f
            val size = if (measured.isEmpty()) fallbackSize else ScanRebuild.quantile(measured.map { it.first }, 0.5f)
                .coerceIn(fallbackSize * 0.5f, fallbackSize * 2.4f)
            val align = if (members.size == 1) {
                val line = members.first()
                val center = (line.left + line.right) / 2f
                if (abs(center - width / 2f) < width * 0.025f && line.left > width * 0.12f) DOC_SCAN_ALIGN_CENTER else DOC_SCAN_ALIGN_LEFT
            } else {
                OcrTextRefiner.alignmentOf(members.map { located[it.id] }, width)
            }
            val widths = measured.map { it.second }
            val scaleX = when {
                widths.isEmpty() -> 1f
                align == DOC_SCAN_ALIGN_JUSTIFY -> ScanRebuild.quantile(widths, 0.25f)
                else -> ScanRebuild.quantile(widths, 0.5f)
            }.coerceIn(0.8f, 1.25f)
            Draft(members, blockBold, family, size, scaleX, align, italic)
        }

        // Mismo estilo = mismo tamaño en toda la hoja (así no queda una letra más grande).
        drafts.groupBy { it.family * 2 + if (it.bold) 1 else 0 }.values.forEach { same ->
            val sorted = same.sortedBy { it.size }
            var start = 0
            while (start < sorted.size) {
                var end = start + 1
                while (end < sorted.size && sorted[end].size <= sorted[start].size * 1.08f) end++
                val cluster = sorted.subList(start, end)
                val size = ScanRebuild.quantile(cluster.map { it.size }, 0.5f)
                val scaleX = ScanRebuild.quantile(cluster.map { it.scaleX }, 0.5f)
                cluster.forEach {
                    it.size = size
                    it.scaleX = scaleX
                }
                start = end
            }
        }

        val blocks = drafts.mapIndexed { index, draft ->
            val members = draft.members
            val left = members.minOf { it.left }
            val top = members.minOf { it.top }
            val right = members.maxOf { it.right }
            val bottom = members.maxOf { it.bottom }
            val lineHeight = bottom - top
            var limit = width * 0.98f
            var leftLimit = width * 0.02f
            if (members.size == 1) {
                for (other in drafts) {
                    if (other === draft) continue
                    val otherTop = other.members.minOf { it.top }
                    val otherBottom = other.members.maxOf { it.bottom }
                    val otherLeft = other.members.minOf { it.left }
                    val otherRight = other.members.maxOf { it.right }
                    val overlap = min(bottom, otherBottom) - max(top, otherTop)
                    if (overlap > lineHeight * 0.4f && otherLeft >= right - lineHeight * 0.2f) {
                        limit = min(limit, otherLeft - lineHeight * 0.3f)
                    }
                    if (overlap > lineHeight * 0.4f && otherRight <= left + lineHeight * 0.2f) {
                        leftLimit = max(leftLimit, otherRight + lineHeight * 0.3f)
                    }
                }
            }
            DocScanBlock(
                id = index,
                lines = members,
                text = ScanRebuild.joinLines(members.map { it.text }),
                align = draft.align,
                ink = members.first().ink,
                background = members.first().background,
                bold = draft.bold,
                family = draft.family,
                size = draft.size,
                scaleX = draft.scaleX,
                maxRight = max(right, limit),
                minLeft = min(left, leftLimit),
                italic = draft.italic
            )
        }
        val usage = IntArray(DocScanFonts.count)
        blocks.filter { !it.bold }.forEach { usage[it.family] += it.text.length }
        val mainFamily = usage.indices.maxByOrNull { usage[it] }?.takeIf { usage[it] > 0 } ?: blocks.first().family
        return DocScanAnalysis(
            width, height, lines, blocks, rotation, ScanRebuild.paperOf(width, height), mainFamily, objects,
            regions = regions, tables = finishTables(judge, mainFamily), bars = bars
        )
    } finally {
        judge.close()
    }
}

/** Cajas de borrado de cada renglón (con un pequeño margen). */
private fun docScanEraseBoxes(lines: List<Rect>, scaleX: Float = 1f, scaleY: Float = 1f): List<IntArray> = lines.map { box ->
    val lineHeight = box.height() * scaleY
    val padX = max(1f, lineHeight * 0.08f)
    val padY = max(1f, lineHeight * 0.06f)
    intArrayOf(
        (box.left * scaleX - padX).toInt(),
        (box.top * scaleY - padY).toInt(),
        (box.right * scaleX + padX).toInt() + 1,
        (box.bottom * scaleY + padY).toInt() + 1
    )
}

/**
 * Busca logos, fotos e íconos sobre el papel (en una copia sin texto).
 * El texto que está DENTRO de un logo (letras chicas del escudo) se deja como
 * parte del logo: no se borra ni se reescribe.
 */
private fun docScanFindObjects(
    bitmap: Bitmap,
    lines: List<DocScanRawLine>,
    figures: List<RectF> = emptyList(),
    tables: List<RectF> = emptyList()
): Pair<List<DocScanRawLine>, List<IntArray>> {
    val width = bitmap.width
    val height = bitmap.height
    val pageArea = width.toFloat() * height
    val byPixels = runCatching {
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        ScanInpaint.eraseInk(pixels, width, height, docScanEraseBoxes(lines.map { it.box }))
        ScanPaper.whiten(pixels, width, height)
        val paper = ScanObjects.paperColor(pixels, width, height)
        if (paper == -1) emptyList() else ScanObjects.find(pixels, width, height, paper)
    }.getOrElse { emptyList() }
    // Lo que la IA ve como imagen (foto, gráfico, sello) también es pieza, si no es casi toda la hoja.
    val found = ArrayList(byPixels)
    for (figure in figures) {
        if (figure.width() * figure.height() > pageArea * 0.45f) continue
        val box = intArrayOf(
            figure.left.toInt().coerceIn(0, width), figure.top.toInt().coerceIn(0, height),
            figure.right.roundToInt().coerceIn(0, width), figure.bottom.roundToInt().coerceIn(0, height)
        )
        if (box[2] - box[0] < 8 || box[3] - box[1] < 8) continue
        // Si ya hay una pieza casi igual, se queda la más grande.
        val same = found.indexOfFirst { other ->
            val overlapX = min(other[2], box[2]) - max(other[0], box[0])
            val overlapY = min(other[3], box[3]) - max(other[1], box[1])
            overlapX > 0 && overlapY > 0 &&
                overlapX.toFloat() * overlapY > 0.6f * min((other[2] - other[0]) * (other[3] - other[1]), (box[2] - box[0]) * (box[3] - box[1]))
        }
        if (same >= 0) {
            val other = found[same]
            found[same] = intArrayOf(min(other[0], box[0]), min(other[1], box[1]), max(other[2], box[2]), max(other[3], box[3]))
        } else {
            found += box
        }
    }
    // La cuadrícula de una tabla no es una pieza (la tabla se dibuja de nuevo).
    found.removeAll { box ->
        val area = ((box[2] - box[0]) * (box[3] - box[1])).toFloat().coerceAtLeast(1f)
        tables.any { table ->
            val overlapX = min(table.right, box[2].toFloat()) - max(table.left, box[0].toFloat())
            val overlapY = min(table.bottom, box[3].toFloat()) - max(table.top, box[1].toFloat())
            overlapX > 0f && overlapY > 0f && overlapX * overlapY > area * 0.5f
        }
    }
    if (found.isEmpty()) return lines to emptyList()
    val keep = BooleanArray(lines.size) { true }
    val objects = ArrayList<IntArray>()
    for (box in found) {
        val inside = lines.indices.filter { index ->
            val line = lines[index].box
            line.exactCenterX() >= box[0] && line.exactCenterX() <= box[2] &&
                line.exactCenterY() >= box[1] && line.exactCenterY() <= box[3]
        }
        // Con texto de verdad adentro (un párrafo, una tarjeta): no es una pieza.
        val small = inside.size <= 3 && inside.all { index ->
            lines[index].box.height() < height * 0.03f && lines[index].text.length <= 40
        }
        if (inside.isNotEmpty() && !small) continue
        inside.forEach { keep[it] = false }
        objects += box
    }
    // Íconos leídos como letras al lado de un título ("8 PERFIL"): esa palabra cae
    // dentro de una pieza, así que se quita del renglón (y no se borra del ícono).
    val result = lines.filterIndexed { index, _ -> keep[index] }.map { line ->
        docScanWithoutIconWords(line, objects)
    }
    return result to objects
}

/** Quita las palabras del principio o del final de un renglón que caen dentro de una pieza. */
private fun docScanWithoutIconWords(line: DocScanRawLine, objects: List<IntArray>): DocScanRawLine {
    if (line.words.size < 2 || objects.isEmpty()) return line
    fun insidePiece(word: DocScanWord): Boolean {
        val cx = word.box.exactCenterX()
        val cy = word.box.exactCenterY()
        return objects.any { cx >= it[0] && cx <= it[2] && cy >= it[1] && cy <= it[3] }
    }
    val words = line.words.sortedBy { it.box.left }
    var start = 0
    var end = words.size
    while (start < end - 1 && insidePiece(words[start])) start++
    while (end - 1 > start && insidePiece(words[end - 1])) end--
    if (start == 0 && end == words.size) return line
    val kept = words.subList(start, end)
    // El texto ya corregido se recorta por palabras (mismo orden).
    val tokens = line.text.split(' ').filter { it.isNotEmpty() }
    val text = if (tokens.size == words.size) {
        tokens.subList(start, end).joinToString(" ")
    } else {
        kept.joinToString(" ") { it.text }
    }
    val box = Rect(kept.first().box)
    kept.forEach { box.union(it.box) }
    return DocScanRawLine(text, box, kept)
}

/**
 * Hoja lista. Dos modos:
 * - [rebuild] = true (hoja reconstruida): papel blanco + formas limpias (barras,
 *   recuadros, líneas, dibujadas de nuevo) + piezas recortadas (logos, fotos,
 *   íconos, viñetas). Los restos de letras que no se borraron del todo no pasan.
 * - [rebuild] = false: la foto sin las letras leídas, con el papel blanco parejo si
 *   [cleanPaper], y los logos y fotos separados como piezas.
 * Devuelve imágenes nuevas.
 */
internal suspend fun docScanCleanPage(
    source: Bitmap,
    analysis: DocScanAnalysis,
    cleanPaper: Boolean,
    rebuild: Boolean = true
): DocScanCleaned =
    withContext(Dispatchers.Default) {
        val width = source.width
        val height = source.height
        val scaleX = width / analysis.width.coerceAtLeast(1).toFloat()
        val scaleY = height / analysis.height.coerceAtLeast(1).toFloat()
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)
        val lineBoxes = analysis.lines.map { Rect(it.left.toInt(), it.top.toInt(), it.right.roundToInt(), it.bottom.roundToInt()) }
        // Las tablas se dibujan de nuevo: su lugar queda como el papel de al lado.
        for (table in analysis.tables) {
            val margin = table.ruleWidth * 2f + 2f
            docScanBlankArea(
                pixels, width, height,
                ((table.data.cols.first() - margin) * scaleX).toInt(), ((table.data.rows.first() - margin) * scaleY).toInt(),
                ((table.data.cols.last() + margin) * scaleX).roundToInt(), ((table.data.rows.last() + margin) * scaleY).roundToInt()
            )
        }
        val boxes = docScanEraseBoxes(lineBoxes, scaleX, scaleY)
        ScanInpaint.eraseInk(pixels, width, height, boxes)
        if (cleanPaper || rebuild) ScanPaper.whiten(pixels, width, height)
        val paper = ScanObjects.paperColor(pixels, width, height).takeIf { it != -1 } ?: android.graphics.Color.WHITE

        // Recorta una pieza con su forma (lo que es [background] queda transparente) y deja el papel en su lugar.
        fun cut(id: Int, box: IntArray, background: Int): DocScanObject? {
            val boxWidth = box[2] - box[0]
            val boxHeight = box[3] - box[1]
            if (boxWidth < 2 || boxHeight < 2) return null
            val alpha = ScanObjects.alpha(pixels, width, box, background)
            val piece = IntArray(boxWidth * boxHeight)
            for (y in 0 until boxHeight) for (x in 0 until boxWidth) {
                val offset = (box[1] + y) * width + box[0] + x
                val on = alpha[y * boxWidth + x] != 0.toByte()
                piece[y * boxWidth + x] = if (on) pixels[offset] else 0
                if (on) pixels[offset] = background
            }
            val bitmap = Bitmap.createBitmap(piece, boxWidth, boxHeight, Bitmap.Config.ARGB_8888)
            // La pieza queda en píxeles de la foto analizada (para moverla con el texto).
            return DocScanObject(
                id,
                Rect(
                    (box[0] / scaleX).roundToInt(), (box[1] / scaleY).roundToInt(),
                    (box[2] / scaleX).roundToInt(), (box[3] / scaleY).roundToInt()
                ),
                bitmap
            )
        }

        // Piezas grandes (logos y fotos sobre el papel).
        val objects = ArrayList<DocScanObject>()
        analysis.objects.forEachIndexed { index, raw ->
            val box = intArrayOf(
                (raw[0] * scaleX).toInt().coerceIn(0, width),
                (raw[1] * scaleY).toInt().coerceIn(0, height),
                (raw[2] * scaleX).roundToInt().coerceIn(0, width),
                (raw[3] * scaleY).roundToInt().coerceIn(0, height)
            )
            cut(index, box, paper)?.let { objects += it }
        }

        if (!rebuild) {
            val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            output.setPixels(pixels, 0, width, 0, 0, width, height)
            return@withContext DocScanCleaned(output, objects)
        }

        // Hoja reconstruida: lo que queda se separa en formas limpias y piezas chicas.
        val textBoxes = lineBoxes.map {
            intArrayOf((it.left * scaleX).toInt(), (it.top * scaleY).toInt(), (it.right * scaleX).roundToInt(), (it.bottom * scaleY).roundToInt())
        }
        val figures = analysis.figures.map {
            intArrayOf((it.left * scaleX).toInt(), (it.top * scaleY).toInt(), (it.right * scaleX).roundToInt(), (it.bottom * scaleY).roundToInt())
        }
        // Barras con texto: se dibujan limpias (sin manchas). Sus íconos se recortan de la
        // foto original (antes de borrar la letra) con fondo transparente.
        val barShapes = ArrayList<DocScanShape>()
        analysis.bars.forEachIndexed { index, page ->
            // La barra en píxeles de esta foto (puede ser más grande que la analizada).
            val bar = ScanBars.Bar(
                page.left * scaleX, page.top * scaleY, page.right * scaleX, page.bottom * scaleY,
                FloatArray(4) { k -> page.insets[k] * scaleX }, page.radius * scaleX, page.color, page.color2, page.vertical,
                page.icons.map { b -> intArrayOf((b[0] * scaleX).toInt(), (b[1] * scaleY).toInt(), (b[2] * scaleX).roundToInt(), (b[3] * scaleY).roundToInt()) }
            )
            bar.icons.forEachIndexed { k, box ->
                val l = box[0].coerceIn(0, width)
                val t = box[1].coerceIn(0, height)
                val r = box[2].coerceIn(l, width)
                val b = box[3].coerceIn(t, height)
                if (r - l < 2 || b - t < 2) return@forEachIndexed
                val original = IntArray((r - l) * (b - t))
                source.getPixels(original, 0, r - l, l, t, r - l, b - t)
                for (y in t until b) for (x in l until r) {
                    val i = (y - t) * (r - l) + x - l
                    val c = original[i]
                    val inside = bar.contains(x + 0.5f, y + 0.5f)
                    val d = ScanBars.dist(c, if (inside) bar.colorAt(x.toFloat(), y.toFloat()) else paper)
                    val alpha = ((d - 30) * 255 / 50).coerceIn(0, 255)
                    original[i] = (alpha shl 24) or (c and 0xFFFFFF)
                    pixels[y * width + x] = paper
                }
                objects += DocScanObject(
                    DOC_SCAN_BAR_ICON + index * 16 + k,
                    Rect((l / scaleX).roundToInt(), (t / scaleY).roundToInt(), (r / scaleX).roundToInt(), (b / scaleY).roundToInt()),
                    Bitmap.createBitmap(original, r - l, b - t, Bitmap.Config.ARGB_8888)
                )
            }
            // Su lugar queda como papel (no se vuelve pieza ni forma otra vez).
            val y0 = (bar.top - 2).toInt().coerceAtLeast(0)
            val y1 = (bar.bottom + 2).roundToInt().coerceAtMost(height)
            val x0 = (bar.left - 2).toInt().coerceAtLeast(0)
            val x1 = (bar.right + 2).roundToInt().coerceAtMost(width)
            for (y in y0 until y1) for (x in x0 until x1) {
                val cx = x + 0.5f
                // Con 2 px de más alrededor (el borde suave de la barra en la foto).
                val cy = (y + 0.5f).coerceIn(bar.top, bar.bottom - 0.01f)
                if (bar.contains(cx, cy) || bar.contains(cx - 2f, cy) || bar.contains(cx + 2f, cy)) {
                    pixels[y * width + x] = paper
                }
            }
            barShapes += DocScanShape(
                DOC_SCAN_BAR_SHAPE + index,
                ScanShapes.RECT,
                RectF(page.left, page.top, page.right, page.bottom),
                page.color,
                page.radius,
                page.color2,
                page.vertical,
                page.insets.copyOf()
            )
        }
        val found = runCatching { ScanShapes.find(pixels, width, height, paper, textBoxes, figures) }
            .getOrElse { ScanShapes.Result(emptyList(), emptyList()) }
        var nextId = (objects.filter { it.id < DOC_SCAN_BAR_ICON }.maxOfOrNull { it.id } ?: -1) + 1
        for (piece in found.pieces) {
            cut(nextId, intArrayOf(piece.left, piece.top, piece.right, piece.bottom), piece.background)?.let {
                objects += it
                nextId++
            }
        }
        // Primero las barras (van debajo), después las demás formas.
        val shapes = barShapes + found.shapes.mapIndexed { index, shape ->
            DocScanShape(
                index,
                shape.kind,
                RectF(shape.left / scaleX, shape.top / scaleY, shape.right / scaleX, shape.bottom / scaleY),
                shape.color,
                shape.radius / scaleX
            )
        }
        // Papel blanco: las formas se dibujan aparte (se pueden mover, cambiar o quitar).
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        output.eraseColor(android.graphics.Color.WHITE)
        DocScanCleaned(output, objects, shapes, rebuilt = true)
    }

/**
 * Deja una zona como el papel que la rodea: en cada fila, un paso suave del color
 * de la izquierda al de la derecha (así se respeta la sombra de la foto).
 */
private fun docScanBlankArea(pixels: IntArray, width: Int, height: Int, left0: Int, top0: Int, right0: Int, bottom0: Int) {
    val left = left0.coerceIn(0, width)
    val right = right0.coerceIn(0, width)
    val top = top0.coerceIn(0, height)
    val bottom = bottom0.coerceIn(0, height)
    if (right - left < 2 || bottom - top < 2) return
    fun sideColor(y: Int, from: Int, step: Int): Int? {
        val reds = ArrayList<Int>(6)
        val greens = ArrayList<Int>(6)
        val blues = ArrayList<Int>(6)
        var x = from
        repeat(6) {
            if (x in 0 until width) {
                val c = pixels[y * width + x]
                reds += (c shr 16) and 0xFF
                greens += (c shr 8) and 0xFF
                blues += c and 0xFF
            }
            x += step
        }
        if (reds.isEmpty()) return null
        reds.sort(); greens.sort(); blues.sort()
        // Lo más claro (el papel, no una letra que esté al lado).
        val i = (reds.size * 3) / 4
        return -0x1000000 or (reds[i] shl 16) or (greens[i] shl 8) or blues[i]
    }
    for (y in top until bottom) {
        val l = sideColor(y, left - 2, -2)
        val r = sideColor(y, right + 1, 2)
        val a = l ?: r ?: android.graphics.Color.WHITE
        val b = r ?: a
        val span = (right - left).coerceAtLeast(1).toFloat()
        for (x in left until right) {
            val t = (x - left) / span
            val red = (((a shr 16) and 0xFF) * (1 - t) + ((b shr 16) and 0xFF) * t).roundToInt()
            val green = (((a shr 8) and 0xFF) * (1 - t) + ((b shr 8) and 0xFF) * t).roundToInt()
            val blue = ((a and 0xFF) * (1 - t) + (b and 0xFF) * t).roundToInt()
            pixels[y * width + x] = -0x1000000 or (red shl 16) or (green shl 8) or blue
        }
    }
}

/**
 * Pedazo de la hoja dibujado a la resolución de la pantalla (para el zoom): las
 * formas y el texto salen nítidos a cualquier acercamiento, como en un lector de PDF.
 * [region] en píxeles de la foto analizada; la imagen sale de [outWidth] × [outHeight].
 */
internal fun docScanRenderDetail(
    cleaned: DocScanCleaned,
    pageWidth: Int,
    pageHeight: Int,
    runs: List<DocScanRun>,
    objectEdits: Map<Int, DocScanObjectEdit>,
    hiddenObject: Int,
    region: RectF,
    outWidth: Int,
    outHeight: Int,
    shapeEdits: Map<Int, DocScanShapeEdit> = emptyMap(),
    hiddenShape: Int = -1,
    tableShapes: List<DocScanShape> = emptyList()
): Bitmap {
    val output = Bitmap.createBitmap(outWidth.coerceAtLeast(1), outHeight.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    canvas.drawColor(android.graphics.Color.WHITE)
    val scale = outWidth / region.width().coerceAtLeast(1f)
    canvas.scale(scale, outHeight / region.height().coerceAtLeast(1f))
    canvas.translate(-region.left, -region.top)
    val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    if (cleaned.rebuilt) {
        docScanDrawShapes(canvas, cleaned.shapes, Paint(Paint.ANTI_ALIAS_FLAG), shapeEdits, hiddenShape)
    } else {
        canvas.drawBitmap(cleaned.base, null, RectF(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat()), imagePaint)
    }
    docScanDrawShapes(canvas, tableShapes, Paint(Paint.ANTI_ALIAS_FLAG))
    val pieces = if (hiddenObject >= 0) cleaned.objects.filter { it.id != hiddenObject } else cleaned.objects
    docScanDrawObjects(canvas, pieces, objectEdits, imagePaint)
    docScanDrawRuns(canvas, runs, Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG))
    return output
}

/**
 * Dibuja las formas limpias con sus cambios (en píxeles de la foto analizada: el
 * lienzo ya viene escalado). [hidden] no se dibuja; [moving] se corre ([dx], [dy]).
 */
internal fun docScanDrawShapes(
    canvas: Canvas,
    shapes: List<DocScanShape>,
    paint: Paint,
    edits: Map<Int, DocScanShapeEdit> = emptyMap(),
    hidden: Int = -1,
    moving: Int = -1,
    dx: Float = 0f,
    dy: Float = 0f
) {
    paint.style = Paint.Style.FILL
    for (shape in shapes) {
        if (shape.id == hidden) continue
        val edit = edits[shape.id]
        if (edit?.deleted == true) continue
        val rect = docScanShapeRect(shape, edit)
        if (shape.id == moving) rect.offset(dx, dy)
        paint.color = edit?.color ?: shape.color
        val end = shape.color2
        // Degradado (si no se le puso un color nuevo).
        paint.shader = if (end != null && edit?.color == null) {
            if (shape.vertical) {
                android.graphics.LinearGradient(0f, rect.top, 0f, rect.bottom, shape.color, end, android.graphics.Shader.TileMode.CLAMP)
            } else {
                android.graphics.LinearGradient(rect.left, 0f, rect.right, 0f, shape.color, end, android.graphics.Shader.TileMode.CLAMP)
            }
        } else {
            null
        }
        val path = docScanShapePath(shape, rect)
        when {
            path != null -> canvas.drawPath(path, paint)
            shape.radius > 0.5f -> canvas.drawRoundRect(rect, shape.radius, shape.radius, paint)
            else -> canvas.drawRect(rect, paint)
        }
        paint.shader = null
    }
}

// ---------------------------------------------------------------------------
// Filtros de imagen (se aplican al dibujar: no se copia la foto)
// ---------------------------------------------------------------------------

internal fun docScanFilterMatrix(filter: DocumentImageFilter): FloatArray? {
    if (filter == DocumentImageFilter.ORIGINAL) return null
    val contrast = when (filter) {
        DocumentImageFilter.DOCUMENT -> 1.28f
        DocumentImageFilter.ENHANCE -> 1.08f
        else -> 1f
    }
    val saturation = when (filter) {
        DocumentImageFilter.GRAYSCALE, DocumentImageFilter.DOCUMENT -> 0f
        DocumentImageFilter.ENHANCE -> 1.18f
        else -> 1f
    }
    val matrix = ColorMatrix()
    matrix.setSaturation(saturation)
    val translate = (-0.5f * contrast + 0.5f) * 255f
    matrix.postConcat(
        ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )
    return matrix.array.copyOf()
}

/** Aplica la matriz del filtro a un color (para que el texto combine con la foto filtrada). */
internal fun docScanFilterColor(color: Int, matrix: FloatArray?): Int {
    if (matrix == null) return color
    val r = android.graphics.Color.red(color).toFloat()
    val g = android.graphics.Color.green(color).toFloat()
    val b = android.graphics.Color.blue(color).toFloat()
    fun channel(row: Int): Int =
        (matrix[row * 5] * r + matrix[row * 5 + 1] * g + matrix[row * 5 + 2] * b + matrix[row * 5 + 3] * 255f + matrix[row * 5 + 4])
            .roundToInt().coerceIn(0, 255)
    return android.graphics.Color.rgb(channel(0), channel(1), channel(2))
}

// ---------------------------------------------------------------------------
// Armado del texto de la hoja (sirve igual para la pantalla, el PDF y la imagen)
// ---------------------------------------------------------------------------

/** Un renglón de texto listo para dibujar. width = ancho final; justify = repartir palabras. */
internal data class DocScanRun(
    /** Párrafo al que pertenece (-1 = texto agregado). */
    val blockId: Int,
    val text: String,
    val x: Float,
    val baseline: Float,
    val size: Float,
    val scaleX: Float,
    val width: Float,
    val family: Int,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val justify: Boolean
)

/**
 * Párrafo ya armado: dónde quedó y con qué formato (para tocarlo, copiarlo y el Word).
 * También guarda su "caja de escritura" (ancho, primera línea base, interlineado) para
 * escribir directo encima de la hoja con la misma letra.
 */
internal class DocScanPlacedBlock(
    val id: Int,
    val rect: RectF,
    val text: String,
    val size: Float,
    val family: Int,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val align: Int,
    val background: Int,
    val deleted: Boolean,
    /** Ancho donde se acomoda el texto (ya movido). */
    val areaLeft: Float = rect.left,
    val areaRight: Float = rect.right,
    /** Línea base del primer renglón (ya movida). */
    val baseline: Float = rect.bottom,
    /** Distancia entre renglones. */
    val leading: Float = size * 1.22f,
    /** Ancho de la letra respecto a la normal. */
    val scaleX: Float = 1f
)

/** Hoja armada, en píxeles de la foto. */
internal class DocScanLayout(
    val width: Int,
    val height: Int,
    val runs: List<DocScanRun>,
    val blocks: List<DocScanPlacedBlock>,
    val tables: List<DocScanPlacedTable> = emptyList(),
    /** Rellenos y rayas de las tablas (se dibujan como las formas). */
    val tableShapes: List<DocScanShape> = emptyList()
) {
    private val byId = blocks.associateBy { it.id }
    fun block(id: Int): DocScanPlacedBlock? = byId[id]
    fun table(id: Int): DocScanPlacedTable? = tables.firstOrNull { it.id == id }
}

private val docScanBounds = ThreadLocal.withInitial { Rect() }

/** Dónde empieza y en qué línea base va un renglón leído, según su tinta real. */
private fun docScanPlaceLine(line: DocScanLine, paint: Paint, size: Float, scaleX: Float): Pair<Float, Float> {
    val ink = line.inkBox
    if (ink == null) {
        val lineHeight = (line.bottom - line.top).coerceAtLeast(1f)
        val hasDescender = line.text.any { it in DOC_SCAN_DESCENDERS }
        val baseline = if (hasDescender) line.bottom - paint.descent() * 0.8f else line.bottom - lineHeight * 0.04f
        return line.left to baseline
    }
    val bounds = docScanBounds.get() ?: Rect()
    val clean = ScanFontMatch.withoutMarks(line.text)
    val saved = paint.textSize
    paint.textSize = 100f
    paint.textScaleX = 1f
    paint.getTextBounds(clean, 0, clean.length, bounds)
    paint.textSize = saved
    paint.textScaleX = scaleX
    val k = size / 100f
    return (ink.left - bounds.left * k * scaleX) to (ink.top - bounds.top * k)
}

/**
 * Ancho donde se acomoda un párrafo con la alineación [align] (sin moverlo).
 * Un párrafo de varios renglones usa su columna. Un renglón solo:
 * - con su alineación de siempre crece hacia su lado hasta el margen;
 * - si se cambia la alineación, va entre los márgenes de la hoja (como en Word),
 *   sin pisar lo que haya al lado en el mismo renglón.
 */
private fun docScanArea(
    analysis: DocScanAnalysis,
    block: DocScanBlock,
    align: Int,
    startX: Float
): Pair<Float, Float> {
    val margins = analysis.margins
    if (block.lines.size > 1) {
        return startX to max(block.right, block.lines.maxOf { it.inkBox?.right ?: it.right })
    }
    val rowLeft = min(block.left, max(margins.left, block.minLeft))
    val rowRight = max(block.right, min(margins.right, block.maxRight))
    if (align != block.align) return rowLeft to rowRight
    return when (align) {
        DOC_SCAN_ALIGN_CENTER -> {
            val center = (block.left + block.right) / 2f
            val half = max((block.right - block.left) / 2f, min(center - rowLeft, rowRight - center))
            (center - half) to (center + half)
        }
        DOC_SCAN_ALIGN_RIGHT -> rowLeft to block.right
        else -> startX to max(block.right, rowRight)
    }
}

/**
 * Arma todo el texto de la hoja. Lo que no se cambió queda en el mismo lugar,
 * con la letra y el tamaño de la foto. Un párrafo cambiado se vuelve a cortar
 * en renglones dentro de su ancho, con su alineación.
 * [fontChoice]: DOC_SCAN_FONT_AUTO o una letra fija para toda la hoja.
 */
internal fun docScanLayout(
    analysis: DocScanAnalysis,
    edits: Map<Int, DocScanBlockEdit>,
    fontChoice: Int,
    paint: Paint = Paint(Paint.ANTI_ALIAS_FLAG),
    tableEdits: Map<Int, DocScanTableEdit> = emptyMap()
): DocScanLayout {
    val runs = ArrayList<DocScanRun>()
    val placed = ArrayList<DocScanPlacedBlock>(analysis.blocks.size)
    for (block in analysis.blocks) {
        val lines = block.lines
        val family = if (fontChoice >= 0) fontChoice else block.family
        val edit = edits[block.id]
        val baseSize = block.size
        val scaleX = block.scaleX
        paint.typeface = DocScanFonts.typeface(family, block.bold, block.italic)
        paint.textSize = baseSize
        paint.textScaleX = scaleX
        val positions = lines.map { docScanPlaceLine(it, paint, baseSize, scaleX) }
        val firstBaseline = positions.first().second
        val baseLeading = if (lines.size >= 2) {
            val gaps = (1 until lines.size).map { positions[it].second - positions[it - 1].second }.filter { it > 0f }
            if (gaps.isEmpty()) baseSize * 1.2f else ScanRebuild.quantile(gaps, 0.5f)
        } else {
            baseSize * 1.22f
        }
        val startX = positions.minOf { it.first }
        val dx = edit?.dx ?: 0f
        val dy = edit?.dy ?: 0f

        // Sin cambio de texto, tamaño ni alineación: los renglones quedan donde estaban
        // (si se movió, todos juntos), con el color, negrita o cursiva elegidos.
        val keepLines = edit == null ||
            (!edit.deleted && edit.text == block.text && edit.scale == 1f && edit.align == block.align && edit.width <= 0f)
        if (keepLines) {
            val runBold = edit?.bold ?: block.bold
            val runItalic = edit?.italic ?: block.italic
            val runColor = edit?.color ?: block.ink
            lines.forEachIndexed { index, line ->
                val (x0, baseline) = positions[index]
                paint.textScaleX = scaleX
                val advance = paint.measureText(line.text)
                val target = line.inkBox?.width() ?: (line.right - line.left)
                // Ancho de la tinta dibujada (sin el aire de los costados).
                val bounds = docScanBounds.get() ?: Rect()
                paint.textScaleX = 1f
                paint.getTextBounds(line.text, 0, line.text.length, bounds)
                paint.textScaleX = scaleX
                val drawnInk = (bounds.width() * scaleX).coerceAtLeast(1f)
                val lastLine = index == lines.lastIndex
                val justify = block.align == DOC_SCAN_ALIGN_JUSTIFY && !lastLine &&
                    line.text.contains(' ') && drawnInk < target * 0.985f
                val lineScale = if (justify) scaleX else (scaleX * target / drawnInk).coerceIn(scaleX * 0.9f, scaleX * 1.1f)
                val width = if (justify) advance + (target - drawnInk) else advance * lineScale / scaleX
                runs += DocScanRun(
                    block.id, line.text, x0 + dx, baseline + dy, baseSize, lineScale, width,
                    family, runBold, runItalic, runColor, justify
                )
            }
            val (areaLeft, areaRight) = docScanArea(analysis, block, block.align, startX)
            placed += DocScanPlacedBlock(
                block.id, RectF(block.left + dx, block.top + dy, block.right + dx, block.bottom + dy), block.text,
                baseSize, family, runBold, runItalic, runColor, block.align, block.background, deleted = false,
                areaLeft = areaLeft + dx, areaRight = max(areaRight, areaLeft + baseSize) + dx,
                baseline = firstBaseline + dy, leading = baseLeading, scaleX = scaleX
            )
            continue
        }
        edit!!

        if (edit.deleted || edit.text.isBlank()) {
            placed += DocScanPlacedBlock(
                block.id, RectF(block.left + dx, block.top + dy, block.right + dx, block.bottom + dy), "",
                baseSize, family, edit.bold, edit.italic, edit.color, edit.align, block.background,
                deleted = edit.deleted,
                areaLeft = startX + dx, areaRight = max(block.right, startX + baseSize) + dx,
                baseline = firstBaseline + dy, leading = baseLeading, scaleX = scaleX
            )
            continue
        }

        val size = baseSize * edit.scale.coerceIn(0.4f, 3f)
        val leading = baseLeading * size / baseSize
        val (areaLeft, autoRight) = docScanArea(analysis, block, edit.align, startX)
        // Cuadro de texto estirado a mano: su ancho manda.
        val areaRight = if (edit.width > 0f) areaLeft + edit.width else autoRight
        val areaWidth = (areaRight - areaLeft).coerceAtLeast(size)
        paint.typeface = DocScanFonts.typeface(family, edit.bold, edit.italic)
        paint.textSize = size
        paint.textScaleX = scaleX
        // Renglón, ¿cierra su párrafo?, sangría (viñetas: los renglones de abajo van alineados al texto).
        val wrapped = ArrayList<Triple<String, Boolean, Float>>()
        for (paragraph in edit.text.split('\n')) {
            val prefix = ScanRebuild.listPrefix(paragraph)
            val indent = if (prefix > 0) paint.measureText(paragraph, 0, prefix).coerceAtMost(areaWidth * 0.4f) else 0f
            val pieces = ScanRebuild.wrap(paragraph, areaWidth, areaWidth - indent) { paint.measureText(it) }
            pieces.forEachIndexed { index, piece ->
                wrapped += Triple(piece, index == pieces.lastIndex, if (index == 0) 0f else indent)
            }
        }
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        wrapped.forEachIndexed { index, (text, closes, indent) ->
            val natural = paint.measureText(text)
            val lineWidth = areaWidth - indent
            val justify = edit.align == DOC_SCAN_ALIGN_JUSTIFY && !closes && text.contains(' ')
            val width = if (justify) lineWidth else natural
            val x = dx + when (edit.align) {
                DOC_SCAN_ALIGN_CENTER -> areaLeft + indent + (lineWidth - width) / 2f
                DOC_SCAN_ALIGN_RIGHT -> areaLeft + areaWidth - width
                else -> areaLeft + indent
            }
            if (text.isNotEmpty()) {
                runs += DocScanRun(
                    block.id, text, x, firstBaseline + dy + index * leading, size, scaleX, width,
                    family, edit.bold, edit.italic, edit.color, justify
                )
            }
            minX = min(minX, x)
            maxX = max(maxX, x + width)
        }
        val ascent = paint.ascent()
        val descent = paint.descent()
        val rect = RectF(
            min(minX, areaLeft + dx),
            firstBaseline + ascent + dy,
            max(maxX, areaLeft + dx + size),
            firstBaseline + (wrapped.size - 1) * leading + descent + dy
        )
        placed += DocScanPlacedBlock(
            block.id, rect, edit.text, size, family, edit.bold, edit.italic, edit.color, edit.align, block.background,
            deleted = false,
            areaLeft = areaLeft + dx, areaRight = areaLeft + areaWidth + dx,
            baseline = firstBaseline + dy, leading = leading, scaleX = scaleX
        )
    }
    val tables = ArrayList<DocScanPlacedTable>(analysis.tables.size)
    val tableShapes = ArrayList<DocScanShape>()
    val tableFamily = if (fontChoice >= 0) fontChoice else analysis.mainFamily
    for (table in analysis.tables) {
        docScanLayoutTable(table, tableEdits[table.id], tableFamily, paint, runs, tableShapes)?.let { tables += it }
    }
    paint.textScaleX = 1f
    return DocScanLayout(analysis.width, analysis.height, runs, placed, tables, tableShapes)
}

/**
 * Arma una tabla: rellenos y rayas (como formas) y el texto de cada celda (como
 * renglones). Lo que no se cambió queda donde estaba; una celda cambiada acomoda
 * su texto en su ancho, y si no entra, la fila crece (como en Word).
 */
private fun docScanLayoutTable(
    table: DocScanTable,
    edit: DocScanTableEdit?,
    family: Int,
    paint: Paint,
    runs: MutableList<DocScanRun>,
    shapes: MutableList<DocScanShape>
): DocScanPlacedTable? {
    val data = edit?.data ?: table.data
    if (data.rowCount < 1 || data.colCount < 1) return null
    val dx = edit?.dx ?: 0f
    val dy = edit?.dy ?: 0f
    val size = table.size * (edit?.scale ?: 1f).coerceIn(0.4f, 3f)
    val leading = size * 1.22f
    val padX = max(size * 0.35f, table.ruleWidth * 2f)
    val padY = size * 0.25f
    val runId = DOC_SCAN_TABLE_RUN - table.id
    val cols = FloatArray(data.cols.size) { data.cols[it] + dx }
    val origRows = FloatArray(data.rows.size) { data.rows[it] }
    if (edit?.deleted == true) {
        return DocScanPlacedTable(table.id, data, cols, FloatArray(origRows.size) { origRows[it] + dy }, size, family, table.ruleColor, table.ruleWidth, deleted = true)
    }
    // Texto acomodado de cada celda que no queda en su lugar de la foto.
    val wrapped = HashMap<DocScanTableCell, List<String>>()
    val needed = FloatArray(data.rowCount)
    for (cell in data.cells) {
        if (cell.row !in 0 until data.rowCount || cell.col !in 0 until data.colCount) continue
        val endCol = (cell.col + cell.colSpan).coerceAtMost(data.colCount)
        val width = (cols[endCol] - cols[cell.col] - padX * 2f).coerceAtLeast(size)
        if (cell.ink != null && edit?.scale.let { it == null || it == 1f }) continue
        paint.typeface = DocScanFonts.typeface(family, cell.bold, cell.italic)
        paint.textSize = size
        paint.textScaleX = 1f
        val lines = if (cell.text.isEmpty()) emptyList() else cell.text.split('\n').flatMap { part ->
            ScanRebuild.wrap(part, width, width) { paint.measureText(it) }.ifEmpty { listOf("") }
        }
        wrapped[cell] = lines
        needed[cell.row] = max(needed[cell.row], lines.size * leading + padY * 2f)
    }
    // Filas: crecen si el texto no entra.
    val rows = FloatArray(origRows.size)
    rows[0] = origRows[0] + dy
    for (r in 0 until data.rowCount) {
        val height = max(origRows[r + 1] - origRows[r], needed[r])
        rows[r + 1] = rows[r] + height
    }
    val placed = DocScanPlacedTable(table.id, data, cols, rows, size, family, table.ruleColor, table.ruleWidth, deleted = false)

    // Rellenos.
    var shapeId = DOC_SCAN_TABLE_SHAPE + table.id * 10_000
    for (cell in data.cells) {
        val fill = cell.fill ?: continue
        shapes += DocScanShape(shapeId++, ScanShapes.RECT, placed.cellRect(cell), fill, 0f)
    }
    // Rayas (las seguidas van en una sola forma).
    if (data.borders) {
        val half = table.ruleWidth / 2f
        for (e in 0..data.rowCount) {
            val flags = data.hRules.getOrNull(e) ?: continue
            var c = 0
            while (c < data.colCount) {
                if (flags.getOrNull(c) != true) { c++; continue }
                val start = c
                while (c < data.colCount && flags.getOrNull(c) == true) c++
                shapes += DocScanShape(shapeId++, ScanShapes.LINE, RectF(cols[start] - half, rows[e] - half, cols[c] + half, rows[e] + half), table.ruleColor, 0f)
            }
        }
        for (e in 0..data.colCount) {
            val flags = data.vRules.getOrNull(e) ?: continue
            var r = 0
            while (r < data.rowCount) {
                if (flags.getOrNull(r) != true) { r++; continue }
                val start = r
                while (r < data.rowCount && flags.getOrNull(r) == true) r++
                shapes += DocScanShape(shapeId++, ScanShapes.LINE, RectF(cols[e] - half, rows[start] - half, cols[e] + half, rows[r] + half), table.ruleColor, 0f)
            }
        }
    }
    // Texto.
    val bounds = docScanBounds.get() ?: Rect()
    for (cell in data.cells) {
        if (cell.text.isBlank() || cell.row !in 0 until data.rowCount) continue
        val rect = placed.cellRect(cell)
        paint.typeface = DocScanFonts.typeface(family, cell.bold, cell.italic)
        paint.textSize = size
        paint.textScaleX = 1f
        val lines = wrapped[cell]
        val ink = cell.ink
        if (lines == null && ink != null) {
            // En su lugar de la foto (corrido si la fila de arriba creció o la tabla se movió).
            val shiftY = rows[cell.row] - origRows[cell.row]
            val clean = ScanFontMatch.withoutMarks(cell.text)
            paint.textSize = 100f
            paint.getTextBounds(clean, 0, clean.length, bounds)
            paint.textSize = size
            val k = size / 100f
            val drawnInk = (bounds.width() * k).coerceAtLeast(1f)
            val scaleX = (ink.width() / drawnInk).coerceIn(0.85f, 1.15f)
            paint.textScaleX = scaleX
            val x = ink.left + dx - bounds.left * k * scaleX
            val baseline = ink.top + shiftY - bounds.top * k
            runs += DocScanRun(runId, cell.text, x, baseline, size, scaleX, paint.measureText(cell.text), family, cell.bold, cell.italic, cell.color, false)
            paint.textScaleX = 1f
            continue
        }
        val parts = lines ?: continue
        val ascent = -paint.ascent()
        val descent = paint.descent()
        val blockHeight = parts.size * leading
        val top = rect.top + ((rect.height() - blockHeight) / 2f).coerceAtLeast(padY)
        parts.forEachIndexed { index, text ->
            if (text.isEmpty()) return@forEachIndexed
            val width = paint.measureText(text)
            val x = when (cell.align) {
                DOC_SCAN_ALIGN_CENTER -> rect.centerX() - width / 2f
                DOC_SCAN_ALIGN_RIGHT -> rect.right - padX - width
                else -> rect.left + padX
            }
            val baseline = top + (leading - ascent - descent) / 2f + ascent + index * leading
            runs += DocScanRun(runId, text, x, baseline, size, 1f, width, family, cell.bold, cell.italic, cell.color, false)
        }
    }
    return placed
}

/** Dibuja los renglones armados (en píxeles de la foto: el lienzo ya viene escalado). */
internal fun docScanDrawRuns(canvas: Canvas, runs: List<DocScanRun>, paint: Paint) {
    for (run in runs) {
        paint.typeface = DocScanFonts.typeface(run.family, run.bold, run.italic)
        paint.textSize = run.size
        paint.textScaleX = run.scaleX
        paint.color = run.color
        if (!run.justify) {
            canvas.drawText(run.text, run.x, run.baseline, paint)
            continue
        }
        val words = run.text.split(' ').filter { it.isNotEmpty() }
        if (words.size < 2) {
            canvas.drawText(run.text, run.x, run.baseline, paint)
            continue
        }
        val widths = FloatArray(words.size) { paint.measureText(words[it]) }
        val gap = (run.width - widths.sum()) / (words.size - 1)
        var x = run.x
        for (index in words.indices) {
            canvas.drawText(words[index], x, run.baseline, paint)
            x += widths[index] + gap
        }
    }
    paint.textScaleX = 1f
}

/**
 * Texto dibujado como trazos (la forma de cada letra), para lo que se mueve en
 * vivo sobre la pantalla. Con zoom grande la tarjeta gráfica a veces corta o
 * mezcla las letras de su memoria de letras; los trazos siempre salen bien.
 * Guarda las formas ya hechas para no rehacerlas en cada cuadro.
 */
internal class DocScanTextPaths(private val limit: Int = 400) {
    private val cache = object : LinkedHashMap<String, android.graphics.Path>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, android.graphics.Path>?): Boolean = size > limit
    }

    private fun piece(canvas: Canvas, key: String, text: String, x: Float, y: Float, paint: Paint) {
        val path = cache.getOrPut(key) {
            android.graphics.Path().also { paint.getTextPath(text, 0, text.length, 0f, 0f, it) }
        }
        canvas.save()
        canvas.translate(x, y)
        canvas.drawPath(path, paint)
        canvas.restore()
    }

    /** Un texto suelto con la letra que ya tiene [paint] ([style] = letra, tamaño y ancho). */
    fun drawText(canvas: Canvas, style: String, text: String, x: Float, y: Float, paint: Paint) {
        if (text.isEmpty()) return
        piece(canvas, "$style|$text", text, x, y, paint)
    }

    fun drawRuns(canvas: Canvas, runs: List<DocScanRun>, paint: Paint) {
        paint.style = Paint.Style.FILL
        for (run in runs) {
            paint.typeface = DocScanFonts.typeface(run.family, run.bold, run.italic)
            paint.textSize = run.size
            paint.textScaleX = run.scaleX
            paint.color = run.color
            val style = "${run.family}|${run.bold}|${run.italic}|${run.size}|${run.scaleX}"
            val words = if (run.justify) run.text.split(' ').filter { it.isNotEmpty() } else emptyList()
            if (words.size < 2) {
                drawText(canvas, style, run.text, run.x, run.baseline, paint)
                continue
            }
            val widths = FloatArray(words.size) { paint.measureText(words[it]) }
            val gap = (run.width - widths.sum()) / (words.size - 1)
            var x = run.x
            for (index in words.indices) {
                drawText(canvas, style, words[index], x, run.baseline, paint)
                x += widths[index] + gap
            }
        }
        paint.textScaleX = 1f
    }
}

// ---------------------------------------------------------------------------
// Cursor sobre la hoja (al escribir, se ven las letras de la hoja, fijas)
// ---------------------------------------------------------------------------

/**
 * Dónde empieza cada renglón dentro del texto del párrafo. null si un renglón no se
 * encuentra (entonces se usa el cuadro de texto normal).
 */
internal fun docScanRunStarts(text: String, runs: List<DocScanRun>): IntArray? {
    var pos = 0
    val starts = IntArray(runs.size)
    for (i in runs.indices) {
        val line = runs[i].text
        val at = if (line.isEmpty()) pos else text.indexOf(line, pos)
        if (at < 0) return null
        starts[i] = at
        pos = at + line.length
    }
    return starts
}

/** Renglón donde va el cursor [offset] (al inicio del siguiente si cae justo en el corte). */
internal fun docScanRunFor(offset: Int, runs: List<DocScanRun>, starts: IntArray): Int {
    if (runs.isEmpty()) return -1
    for (i in runs.indices.reversed()) {
        if (offset >= starts[i]) {
            // Pasó el final de este renglón (el espacio o salto del corte): sigue aquí al final.
            return i
        }
    }
    return 0
}

private fun docScanRunPaint(run: DocScanRun, paint: Paint) {
    paint.typeface = DocScanFonts.typeface(run.family, run.bold, run.italic)
    paint.textSize = run.size
    paint.textScaleX = run.scaleX
}

/** x del cursor antes de la letra [index] del renglón, igual que lo dibuja la hoja. */
internal fun docScanCaretX(run: DocScanRun, index: Int, paint: Paint): Float {
    docScanRunPaint(run, paint)
    val text = run.text
    val i = index.coerceIn(0, text.length)
    val words = if (run.justify) text.split(' ').filter { it.isNotEmpty() } else emptyList()
    if (words.size < 2) return run.x + paint.measureText(text, 0, i)
    // Justificado: los espacios se reparten como en la hoja.
    val widths = FloatArray(words.size) { paint.measureText(words[it]) }
    val gap = (run.width - widths.sum()) / (words.size - 1)
    var x = run.x
    var pos = 0
    for (k in words.indices) {
        val start = text.indexOf(words[k], pos)
        if (i <= start) return x
        if (i <= start + words[k].length) return x + paint.measureText(words[k], 0, i - start)
        x += widths[k] + gap
        pos = start + words[k].length
    }
    return run.x + run.width
}

/** Letra más cercana a [x] en el renglón (para poner el cursor donde se tocó). */
internal fun docScanCaretIndex(run: DocScanRun, x: Float, paint: Paint): Int {
    var best = 0
    var bestDistance = Float.MAX_VALUE
    for (i in 0..run.text.length) {
        val d = abs(docScanCaretX(run, i, paint) - x)
        if (d < bestDistance) {
            bestDistance = d
            best = i
        }
    }
    return best
}

/**
 * La hoja como se ve, en una imagen (fondo limpio + logos y fotos + texto), dibujada
 * por el procesador: las letras salen siempre completas y el zoom va fluido porque
 * es una sola imagen. Sin filtro de color (se aplica al mostrarla).
 * [hiddenObject] no se dibuja (se está moviendo y va aparte).
 */
internal fun docScanRenderSheet(
    cleaned: DocScanCleaned,
    pageWidth: Int,
    pageHeight: Int,
    runs: List<DocScanRun>,
    objectEdits: Map<Int, DocScanObjectEdit>,
    hiddenObject: Int,
    shapeEdits: Map<Int, DocScanShapeEdit> = emptyMap(),
    hiddenShape: Int = -1,
    tableShapes: List<DocScanShape> = emptyList()
): Bitmap {
    val base = cleaned.base
    val output = Bitmap.createBitmap(base.width, base.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    canvas.drawColor(android.graphics.Color.WHITE)
    val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    canvas.drawBitmap(base, 0f, 0f, imagePaint)
    canvas.save()
    canvas.scale(base.width / pageWidth.coerceAtLeast(1).toFloat(), base.height / pageHeight.coerceAtLeast(1).toFloat())
    docScanDrawShapes(canvas, cleaned.shapes, Paint(Paint.ANTI_ALIAS_FLAG), shapeEdits, hiddenShape)
    docScanDrawShapes(canvas, tableShapes, Paint(Paint.ANTI_ALIAS_FLAG))
    val pieces = if (hiddenObject >= 0) cleaned.objects.filter { it.id != hiddenObject } else cleaned.objects
    docScanDrawObjects(canvas, pieces, objectEdits, imagePaint)
    docScanDrawRuns(canvas, runs, Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG))
    canvas.restore()
    return output
}

/** Caja de un texto agregado. */
internal fun docScanAddedBounds(text: DocScanAddedText, width: Float, height: Float, family: Int, paint: Paint): RectF {
    paint.textScaleX = 1f
    paint.typeface = DocScanFonts.typeface(family, text.bold, text.italic)
    paint.textSize = (text.size * height).coerceAtLeast(2f)
    val textWidth = paint.measureText(text.text.ifEmpty { " " })
    val x = text.x * width
    val y = text.y * height
    return RectF(x, y + paint.ascent(), x + textWidth, y + paint.descent())
}

/** Caja de una firma. */
internal fun docScanSignRect(sign: DocScanSign, width: Float, height: Float): RectF {
    val signWidth = sign.width * width
    val ratio = sign.bitmap.height.toFloat() / sign.bitmap.width.coerceAtLeast(1)
    val left = sign.x * width
    val top = sign.y * height
    return RectF(left, top, left + signWidth, top + signWidth * ratio)
}

/** Textos agregados (con filtro de color) y firmas (sin filtro: quedan con su tinta). */
internal fun docScanDrawAdded(
    canvas: Canvas,
    width: Float,
    height: Float,
    edits: DocScanPageEdits,
    family: Int,
    paint: Paint,
    drawSigns: Boolean = true,
    /** En la pantalla: letras como trazos (ver [DocScanTextPaths]). */
    paths: DocScanTextPaths? = null,
    /** Texto agregado que no se dibuja (se está escribiendo encima). */
    hiddenText: Int = -1
) {
    paint.textScaleX = 1f
    for (text in edits.texts) {
        if (text.text.isBlank() || text.id == hiddenText) continue
        paint.typeface = DocScanFonts.typeface(family, text.bold, text.italic)
        paint.textSize = (text.size * height).coerceAtLeast(2f)
        paint.color = text.color
        if (paths != null) {
            paths.drawText(canvas, "$family|${text.bold}|${text.italic}|${paint.textSize}", text.text, text.x * width, text.y * height, paint)
        } else {
            canvas.drawText(text.text, text.x * width, text.y * height, paint)
        }
    }
    if (!drawSigns) return
    val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    for (sign in edits.signs) {
        if (!sign.bitmap.isRecycled) canvas.drawBitmap(sign.bitmap, null, docScanSignRect(sign, width, height), imagePaint)
    }
}

/** Letra de los textos agregados: la elegida o la principal de la hoja. */
internal fun docScanAddedFamily(analysis: DocScanAnalysis?, fontChoice: Int): Int =
    if (fontChoice >= 0) fontChoice else analysis?.mainFamily ?: 0

/** Dibuja los logos y fotos (en píxeles de la foto: el lienzo ya viene escalado). */
internal fun docScanDrawObjects(
    canvas: Canvas,
    objects: List<DocScanObject>,
    edits: Map<Int, DocScanObjectEdit>,
    paint: Paint,
    movingId: Int = -1,
    movingDx: Float = 0f,
    movingDy: Float = 0f
) {
    for (piece in objects) {
        if (piece.bitmap.isRecycled) continue
        val edit = edits[piece.id]
        if (edit?.deleted == true) continue
        val rect = docScanObjectRect(piece.rect, edit)
        if (piece.id == movingId) rect.offset(movingDx, movingDy)
        canvas.drawBitmap(piece.bitmap, null, rect, paint)
    }
}

/** Hoja completa en una imagen nueva: fondo limpio + piezas + filtro + texto + agregados. */
internal fun docScanRender(
    cleaned: DocScanCleaned,
    layout: DocScanLayout,
    edits: DocScanPageEdits,
    addedFamily: Int,
    filter: FloatArray?,
    withText: Boolean = true,
    withTables: Boolean = true
): Bitmap {
    val clean = cleaned.base
    val width = clean.width
    val height = clean.height
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    canvas.drawColor(android.graphics.Color.WHITE)
    val colorFilter = filter?.let { ColorMatrixColorFilter(it) }
    val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply { this.colorFilter = colorFilter }
    canvas.drawBitmap(clean, 0f, 0f, imagePaint)
    canvas.save()
    canvas.scale(width / layout.width.coerceAtLeast(1).toFloat(), height / layout.height.coerceAtLeast(1).toFloat())
    docScanDrawShapes(canvas, cleaned.shapes, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.colorFilter = colorFilter }, edits.shapes)
    if (withTables) docScanDrawShapes(canvas, layout.tableShapes, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.colorFilter = colorFilter })
    docScanDrawObjects(canvas, cleaned.objects, edits.objects, imagePaint)
    canvas.restore()
    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply { this.colorFilter = colorFilter }
    if (withText) {
        canvas.save()
        canvas.scale(width / layout.width.coerceAtLeast(1).toFloat(), height / layout.height.coerceAtLeast(1).toFloat())
        docScanDrawRuns(canvas, layout.runs, textPaint)
        canvas.restore()
        docScanDrawAdded(canvas, width.toFloat(), height.toFloat(), edits, addedFamily, textPaint)
    } else {
        // Para el PDF: solo las firmas e imágenes van en la foto; el texto va como texto real.
        docScanDrawAdded(canvas, width.toFloat(), height.toFloat(), edits.copy(texts = emptyList()), addedFamily, textPaint)
    }
    return output
}

// ---------------------------------------------------------------------------
// Texto de la hoja (para copiar, compartir y Word)
// ---------------------------------------------------------------------------

/** Un párrafo para copiar o para el Word, en orden de lectura. */
internal class DocScanParagraph(
    val text: String,
    /** Tamaño de letra como fracción del ancho de la página. */
    val size: Float,
    val family: Int,
    val bold: Boolean,
    val italic: Boolean,
    val color: Int,
    val align: Int,
    val background: Int,
    /** Si es una tabla: la tabla (el texto son sus filas separadas por tabulación). */
    val table: DocScanPlacedTable? = null,
    /** Ancho de la página (px de la foto), para pasar la tabla a puntos. */
    val pageWidth: Float = 0f
)

/** Texto de una tabla: filas en renglones, celdas separadas por tabulación (se pega bien en Excel). */
internal fun docScanTableText(data: DocScanTableData): String =
    (0 until data.rowCount).joinToString("\n") { row ->
        data.cells.filter { it.row == row }.sortedBy { it.col }.joinToString("\t") { it.text.replace('\n', ' ') }
    }

/** Párrafos de la página en orden de lectura, con los cambios y los textos agregados. */
internal fun docScanParagraphs(layout: DocScanLayout?, edits: DocScanPageEdits, addedFamily: Int): List<DocScanParagraph> {
    if (layout == null) return emptyList()
    val width = layout.width.coerceAtLeast(1).toFloat()
    val height = layout.height.toFloat()
    val result = ArrayList<Pair<Float, DocScanParagraph>>()
    for (block in layout.blocks) {
        if (block.deleted || block.text.isBlank()) continue
        result += block.rect.top to DocScanParagraph(
            block.text, block.size / width, block.family, block.bold, block.italic, block.color, block.align, block.background
        )
    }
    // Tablas en su lugar de lectura.
    for (table in layout.tables) {
        if (table.deleted) continue
        val paragraph = DocScanParagraph(
            docScanTableText(table.data), table.size / width, table.family, false, false,
            android.graphics.Color.BLACK, DOC_SCAN_ALIGN_LEFT, android.graphics.Color.WHITE,
            table = table, pageWidth = width
        )
        val at = result.indexOfFirst { it.first > table.rows.first() }
        if (at < 0) result += table.rows.first() to paragraph else result.add(at, table.rows.first() to paragraph)
    }
    // Los textos agregados van antes del primer párrafo que esté más abajo.
    for (added in edits.texts.sortedBy { it.y }) {
        if (added.text.isBlank()) continue
        val y = added.y * height
        val paragraph = DocScanParagraph(
            added.text, added.size * height / width, addedFamily, added.bold, added.italic, added.color,
            DOC_SCAN_ALIGN_LEFT, android.graphics.Color.WHITE
        )
        val at = result.indexOfFirst { it.first > y }
        if (at < 0) result += y to paragraph else result.add(at, y to paragraph)
    }
    return result.map { it.second }
}

internal fun docScanPageText(layout: DocScanLayout?, edits: DocScanPageEdits, addedFamily: Int): String =
    docScanParagraphs(layout, edits, addedFamily).joinToString("\n\n") { it.text }

/** Lee las páginas que falten (para Word y para copiar el texto de todas). */
internal suspend fun docScanEnsureAnalyses(
    context: Context,
    pages: List<DocScanPage>,
    known: Map<Int, DocScanAnalysis>,
    onStep: (String) -> Unit = {}
): Map<Int, DocScanAnalysis> {
    val result = HashMap(known)
    pages.forEachIndexed { index, page ->
        if (result[page.id] != null) return@forEachIndexed
        val source = ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
        try {
            val read = docScanAnalyze(context, source) { step -> onStep("Página ${index + 1}: $step") }
            result[page.id] = read.analysis
            if (read.bitmap !== source) read.bitmap.recycle()
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }
    return result
}

/** Texto de todas las páginas, separadas. */
internal fun docScanAllText(
    pages: List<DocScanPage>,
    analyses: Map<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    fontChoice: Int
): String {
    fun pageText(page: DocScanPage): String {
        val pageEdits = edits[page.id] ?: DocScanPageEdits()
        val analysis = analyses[page.id]
        val layout = analysis?.let { docScanLayout(it, pageEdits.blocks, fontChoice, tableEdits = pageEdits.tables) }
        return docScanPageText(layout, pageEdits, docScanAddedFamily(analysis, fontChoice))
    }
    if (pages.size == 1) return pageText(pages.first())
    return pages.mapIndexed { index, page -> "— Página ${index + 1} —\n\n" + pageText(page) }.joinToString("\n\n")
}

// ---------------------------------------------------------------------------
// Guardado
// ---------------------------------------------------------------------------

/** Una página lista para guardar: fondo limpio, lectura y armado. */
private class DocScanPrepared(val cleaned: DocScanCleaned, val analysis: DocScanAnalysis, val layout: DocScanLayout)

private suspend fun docScanPreparePage(
    context: Context,
    page: DocScanPage,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    fontChoice: Int,
    cleanPaper: Boolean,
    rebuild: Boolean = true
): DocScanPrepared {
    val source = ToolFileUtils.loadBitmap(context, page.uri, DOC_SCAN_PAGE_EDGE)
    var straight: Bitmap = source
    try {
        val read = if (analysis != null) {
            straight = withContext(Dispatchers.Default) { docScanStraighten(source, analysis.rotation) }
            analysis
        } else {
            val result = docScanAnalyze(context, source)
            straight = result.bitmap
            result.analysis
        }
        val cleaned = docScanCleanPage(straight, read, cleanPaper, rebuild)
        val layout = withContext(Dispatchers.Default) { docScanLayout(read, edits.blocks, fontChoice, tableEdits = edits.tables) }
        return DocScanPrepared(cleaned, read, layout)
    } finally {
        if (straight !== source && !straight.isRecycled) straight.recycle()
        if (!source.isRecycled) source.recycle()
    }
}

/** Medidas de la hoja en puntos de PDF (1/72 de pulgada). */
private fun docScanPageSize(analysis: DocScanAnalysis, paperChoice: Int): Pair<Float, Float> {
    val paper = if (paperChoice >= 0) paperChoice else analysis.paper
    val landscape = analysis.landscape
    val known = ScanRebuild.papers.getOrNull(paper)
    if (known != null) {
        val width = known.second * 72f / 25.4f
        val height = known.third * 72f / 25.4f
        return if (landscape) height to width else width to height
    }
    val ratio = analysis.width.toFloat() / analysis.height.coerceAtLeast(1)
    return if (ratio >= 1f) 842f to 842f / ratio else 595f to 595f / ratio
}

/**
 * PDF reconstruido: cada página es el fondo limpio (fotos, logos, barras) y
 * encima el texto REAL, visible, con la misma letra de la pantalla (va dentro
 * del PDF), en su lugar, tamaño, color y negrita. Se puede seleccionar, copiar,
 * buscar y editar en cualquier lector de PDF. La hoja sale en su tamaño (A4, Carta…).
 */
internal suspend fun docScanWritePdf(
    context: Context,
    output: OutputStream,
    pages: List<DocScanPage>,
    analyses: Map<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    fontChoice: Int,
    paperChoice: Int,
    cleanPaper: Boolean,
    filter: FloatArray?,
    rebuild: Boolean = true
) = withContext(Dispatchers.IO) {
    PDFBoxResourceLoader.init(context.applicationContext)
    DocScanFonts.init(context)
    val measure = Paint(Paint.ANTI_ALIAS_FLAG)
    PDDocument().use { document ->
        val fonts = HashMap<Int, PDFont>()
        fun pdfFont(family: Int, bold: Boolean, italic: Boolean): PDFont {
            val key = family * 4 + (if (bold) 1 else 0) + (if (italic) 2 else 0)
            return fonts.getOrPut(key) {
                runCatching {
                    DocScanFonts.open(context, family, bold, italic).use { PDType0Font.load(document, it) }
                }.getOrElse {
                    when {
                        bold && italic -> PDType1Font.HELVETICA_BOLD_OBLIQUE
                        bold -> PDType1Font.HELVETICA_BOLD
                        italic -> PDType1Font.HELVETICA_OBLIQUE
                        else -> PDType1Font.HELVETICA
                    }
                }
            }
        }
        val encodable = HashMap<Pair<PDFont, Char>, Boolean>()
        fun clean(font: PDFont, text: String): String = buildString {
            for (char in text) {
                val ok = encodable.getOrPut(font to char) { runCatching { font.encode(char.toString()); true }.getOrDefault(false) }
                append(if (ok) char else ' ')
            }
        }

        for (page in pages) {
            val pageEdits = edits[page.id] ?: DocScanPageEdits()
            val prepared = docScanPreparePage(context, page, analyses[page.id], pageEdits, fontChoice, cleanPaper, rebuild)
            val addedFamily = docScanAddedFamily(prepared.analysis, fontChoice)
            val (pageWidth, pageHeight) = docScanPageSize(prepared.analysis, paperChoice)
            val pdfPage = PDPage(PDRectangle(pageWidth, pageHeight))
            document.addPage(pdfPage)
            val layoutNow = prepared.layout
            // Píxeles de la foto → puntos del PDF (y desde abajo).
            val sx = pageWidth / layoutNow.width.coerceAtLeast(1)
            val sy = pageHeight / layoutNow.height.coerceAtLeast(1)

            // Hoja reconstruida: formas de verdad (vectores) y cada pieza como imagen aparte.
            // Si no, una sola imagen de fondo (la foto limpia).
            class Placed(val image: PDImageXObject, val rect: RectF)
            val placedImages = ArrayList<Placed>()
            var shapesToDraw: List<DocScanShape> = emptyList()
            var background: PDImageXObject? = null
            try {
                if (prepared.cleaned.rebuilt) {
                    shapesToDraw = prepared.cleaned.shapes + layoutNow.tableShapes
                    for (piece in prepared.cleaned.objects) {
                        val edit = pageEdits.objects[piece.id]
                        if (edit?.deleted == true || piece.bitmap.isRecycled) continue
                        val image = docScanPdfImage(document, piece.bitmap, filter) ?: continue
                        placedImages += Placed(image, docScanObjectRect(piece.rect, edit))
                    }
                    for (sign in pageEdits.signs) {
                        if (sign.bitmap.isRecycled) continue
                        val image = docScanPdfImage(document, sign.bitmap, filter) ?: continue
                        placedImages += Placed(image, docScanSignRect(sign, layoutNow.width.toFloat(), layoutNow.height.toFloat()))
                    }
                } else {
                    val rendered = withContext(Dispatchers.Default) {
                        docScanRender(prepared.cleaned, prepared.layout, pageEdits, addedFamily, filter, withText = false)
                    }
                    val bytes = try {
                        ByteArrayOutputStream().also { rendered.compress(Bitmap.CompressFormat.JPEG, 88, it) }.toByteArray()
                    } finally {
                        rendered.recycle()
                    }
                    background = PDImageXObject.createFromByteArray(document, bytes, "pagina")
                }
            } finally {
                prepared.cleaned.recycle()
            }

            // Todos los renglones (los leídos y los agregados) en píxeles de la foto.
            val layout = prepared.layout
            val runs = ArrayList(layout.runs)
            measure.textScaleX = 1f
            for (added in pageEdits.texts) {
                if (added.text.isBlank()) continue
                val size = added.size * layout.height
                measure.typeface = DocScanFonts.typeface(addedFamily, added.bold, added.italic)
                measure.textSize = size
                runs += DocScanRun(
                    -1, added.text, added.x * layout.width, added.y * layout.height, size, 1f,
                    measure.measureText(added.text), addedFamily, added.bold, added.italic, added.color, false
                )
            }
            // La foto ocupa toda la hoja: puede estirarse apenas para llenar A4/Carta exacto.
            val kx = sx
            val ky = sy

            PDPageContentStream(document, pdfPage).use { stream ->
                background?.let { stream.drawImage(it, 0f, 0f, pageWidth, pageHeight) }
                for (shape in shapesToDraw) {
                    val shapeEdit = pageEdits.shapes[shape.id]
                    if (shapeEdit?.deleted == true) continue
                    fun fillColor(value: Int) {
                        val color = docScanFilterColor(value, filter)
                        stream.setNonStrokingColor(
                            PDColor(
                                floatArrayOf(
                                    android.graphics.Color.red(color) / 255f,
                                    android.graphics.Color.green(color) / 255f,
                                    android.graphics.Color.blue(color) / 255f
                                ),
                                PDDeviceRGB.INSTANCE
                            )
                        )
                    }
                    val shapeRect = docScanShapeRect(shape, shapeEdit)
                    val left = shapeRect.left * sx
                    val right = shapeRect.right * sx
                    val top = pageHeight - shapeRect.top * sy
                    val bottom = pageHeight - shapeRect.bottom * sy
                    val radius = min(shape.radius * sx, min(right - left, top - bottom) / 2f)
                    val insets = shape.insets?.takeIf { shape.slanted }
                    fun outline() {
                        if (insets != null) {
                            // Punta inclinada.
                            val limit = (right - left) / 2f
                            stream.moveTo(left + (insets[0] * sx).coerceAtMost(limit), top)
                            stream.lineTo(right - (insets[1] * sx).coerceAtMost(limit), top)
                            stream.lineTo(right - (insets[2] * sx).coerceAtMost(limit), bottom)
                            stream.lineTo(left + (insets[3] * sx).coerceAtMost(limit), bottom)
                            stream.closePath()
                        } else if (radius > 0.3f) {
                            // Rectángulo con esquinas redondas (curvas de Bézier).
                            val k = radius * 0.5523f
                            stream.moveTo(left + radius, bottom)
                            stream.lineTo(right - radius, bottom)
                            stream.curveTo(right - radius + k, bottom, right, bottom + radius - k, right, bottom + radius)
                            stream.lineTo(right, top - radius)
                            stream.curveTo(right, top - radius + k, right - radius + k, top, right - radius, top)
                            stream.lineTo(left + radius, top)
                            stream.curveTo(left + radius - k, top, left, top - radius + k, left, top - radius)
                            stream.lineTo(left, bottom + radius)
                            stream.curveTo(left, bottom + radius - k, left + radius - k, bottom, left + radius, bottom)
                            stream.closePath()
                        } else {
                            stream.addRect(left, bottom, right - left, top - bottom)
                        }
                    }
                    val end = shape.color2?.takeIf { shapeEdit?.color == null }
                    if (end == null) {
                        fillColor(shapeEdit?.color ?: shape.color)
                        outline()
                        stream.fill()
                    } else {
                        // Degradado: franjas finas de color recortadas con la forma.
                        stream.saveGraphicsState()
                        outline()
                        stream.clip()
                        val strips = 48
                        for (k in 0 until strips) {
                            fillColor(ScanBars.mix(shape.color, end, (k + 0.5f) / strips))
                            if (shape.vertical) {
                                val h = (top - bottom) / strips
                                stream.addRect(left, top - (k + 1) * h - 0.3f, right - left, h + 0.6f)
                            } else {
                                val w = (right - left) / strips
                                stream.addRect(left + k * w - 0.3f, bottom, w + 0.6f, top - bottom)
                            }
                            stream.fill()
                        }
                        stream.restoreGraphicsState()
                    }
                }
                for (placed in placedImages) {
                    val rect = placed.rect
                    stream.drawImage(
                        placed.image,
                        rect.left * sx,
                        pageHeight - rect.bottom * sy,
                        rect.width() * sx,
                        rect.height() * sy
                    )
                }
                for (run in runs) {
                    val font = pdfFont(run.family, run.bold, run.italic)
                    val color = docScanFilterColor(run.color, filter)
                    measure.typeface = DocScanFonts.typeface(run.family, run.bold, run.italic)
                    measure.textSize = run.size
                    measure.textScaleX = run.scaleX
                    val words = run.text.split(' ').filter { it.isNotEmpty() }
                    val pieces = ArrayList<Pair<String, Float>>() // texto y su x (px de la foto)
                    val targets = ArrayList<Float>() // ancho que debe ocupar cada pedazo (px)
                    if (run.justify && words.size >= 2) {
                        val widths = words.map { measure.measureText(it) }
                        val gap = (run.width - widths.sum()) / (words.size - 1)
                        var x = run.x
                        for (index in words.indices) {
                            pieces += words[index] to x
                            targets += widths[index]
                            x += widths[index] + gap
                        }
                    } else {
                        pieces += run.text to run.x
                        targets += run.width
                    }
                    val sizePt = run.size * ky
                    if (sizePt < 0.5f) continue
                    pieces.forEachIndexed { index, (text, x) ->
                        val cleaned = clean(font, text)
                        if (cleaned.isBlank()) return@forEachIndexed
                        val units = runCatching { font.getStringWidth(cleaned) }.getOrDefault(0f)
                        if (units <= 0f) return@forEachIndexed
                        val pdfWidth = units / 1000f * sizePt
                        val stretch = (targets[index] * kx / pdfWidth).coerceIn(0.4f, 2.5f)
                        runCatching {
                            stream.beginText()
                            stream.setFont(font, sizePt)
                            stream.setNonStrokingColor(
                                PDColor(
                                    floatArrayOf(
                                        android.graphics.Color.red(color) / 255f,
                                        android.graphics.Color.green(color) / 255f,
                                        android.graphics.Color.blue(color) / 255f
                                    ),
                                    PDDeviceRGB.INSTANCE
                                )
                            )
                            stream.setTextMatrix(Matrix(stretch, 0f, 0f, 1f, x * kx, pageHeight - run.baseline * ky))
                            stream.showText(cleaned)
                            stream.endText()
                        }
                    }
                }
            }
        }
        document.save(output)
    }
}

internal const val DOC_SCAN_XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

/** Tabla de la hoja como hoja de Excel ([k] = puntos por píxel de la foto). */
internal fun docScanXlsxSheet(name: String, table: DocScanPlacedTable, k: Float): ScanXlsx.Sheet {
    val data = table.data
    val cells = data.cells.map { cell ->
        val span = cell.colSpan.coerceAtLeast(1)
        val on = data.borders
        ScanXlsx.Cell(
            cell.row, cell.col, span, cell.text, cell.bold, cell.italic, cell.color, cell.fill,
            docScanWordAlign(cell.align).let { if (it == "both") "left" else it },
            top = on && (cell.col until cell.col + span).any { data.hRules.getOrNull(cell.row)?.getOrNull(it) == true },
            bottom = on && (cell.col until cell.col + span).any { data.hRules.getOrNull(cell.row + 1)?.getOrNull(it) == true },
            left = on && data.vRules.getOrNull(cell.col)?.getOrNull(cell.row) == true,
            right = on && data.vRules.getOrNull(cell.col + span)?.getOrNull(cell.row) == true
        )
    }
    return ScanXlsx.Sheet(
        name,
        (0 until data.colCount).map { (table.cols[it + 1] - table.cols[it]) * k },
        (0 until data.rowCount).map { (table.rows[it + 1] - table.rows[it]) * k },
        cells,
        DocScanFonts.wordNames.getOrElse(table.family) { "Arial" },
        (table.size * k).coerceIn(6f, 36f),
        table.ruleColor
    )
}

/**
 * Excel con las tablas de las páginas (una hoja por tabla). Si no hay tablas,
 * una hoja con el texto (un párrafo por fila). Devuelve cuántas tablas se guardaron.
 */
internal suspend fun docScanWriteXlsx(
    output: OutputStream,
    pages: List<DocScanPage>,
    analyses: Map<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    fontChoice: Int,
    paperChoice: Int
): Int = withContext(Dispatchers.Default) {
    val sheets = ArrayList<ScanXlsx.Sheet>()
    val texts = ArrayList<String>()
    pages.forEachIndexed { pageIndex, page ->
        val analysis = analyses[page.id] ?: return@forEachIndexed
        val pageEdits = edits[page.id] ?: DocScanPageEdits()
        val layout = docScanLayout(analysis, pageEdits.blocks, fontChoice, tableEdits = pageEdits.tables)
        val (pageWidth, _) = docScanPageSize(analysis, paperChoice)
        val k = pageWidth / layout.width.coerceAtLeast(1)
        val tables = layout.tables.filter { !it.deleted }
        tables.forEachIndexed { index, table ->
            val name = if (pages.size == 1) "Tabla ${index + 1}" else "Pág ${pageIndex + 1} tabla ${index + 1}"
            sheets += docScanXlsxSheet(name, table, k)
        }
        docScanParagraphs(layout, pageEdits, docScanAddedFamily(analysis, fontChoice))
            .filter { it.table == null }
            .forEach { texts += it.text }
    }
    if (sheets.isEmpty()) {
        val rows = texts.filter { it.isNotBlank() }.flatMap { it.split('\n') }
        sheets += ScanXlsx.Sheet(
            "Texto", listOf(420f), rows.map { 15f },
            rows.mapIndexed { index, text -> ScanXlsx.Cell(index, 0, 1, text) }
        )
        withContext(Dispatchers.IO) { ScanXlsx.write(output, sheets) }
        return@withContext 0
    }
    withContext(Dispatchers.IO) { ScanXlsx.write(output, sheets) }
    sheets.size
}

/** Tabla de la hoja como tabla de Word ([k] = puntos por píxel de la foto). */
internal fun docScanDocxTable(table: DocScanPlacedTable, k: Float, filter: FloatArray?, maxWidth: Float = Float.MAX_VALUE): ScanDocx.Table {
    val data = table.data
    var colWidths = (0 until data.colCount).map { (table.cols[it + 1] - table.cols[it]) * k }
    val total = colWidths.sum()
    val fit = if (total > maxWidth && total > 0f) maxWidth / total else 1f
    colWidths = colWidths.map { it * fit }
    val rowHeights = (0 until data.rowCount).map { (table.rows[it + 1] - table.rows[it]) * k * fit }
    val cells = data.cells.map { cell ->
        ScanDocx.TableCell(
            cell.row, cell.col, cell.colSpan, cell.text, cell.bold, cell.italic,
            docScanFilterColor(cell.color, filter),
            docScanWordAlign(cell.align).let { if (it == "both") "left" else it },
            cell.fill?.let { docScanFilterColor(it, filter) }
        )
    }
    val hRules = if (data.borders) data.hRules else data.hRules.map { row -> row.map { false } }
    val vRules = if (data.borders) data.vRules else data.vRules.map { col -> col.map { false } }
    return ScanDocx.Table(
        table.cols.first() * k, table.rows.first() * k, colWidths, rowHeights, cells,
        DocScanFonts.wordNames.getOrElse(table.family) { "Arial" },
        table.size * k * fit,
        docScanFilterColor(table.ruleColor, filter),
        (table.ruleWidth * k).coerceIn(0.25f, 6f),
        hRules, vRules
    )
}

/**
 * Word "igual a la hoja": cada página con sus formas, imágenes y cuadros de texto
 * en el mismo lugar (se ve como la hoja y el texto se edita en Word).
 */
internal suspend fun docScanWriteDocxSheet(
    context: Context,
    output: OutputStream,
    pages: List<DocScanPage>,
    analyses: Map<Int, DocScanAnalysis>,
    edits: Map<Int, DocScanPageEdits>,
    fontChoice: Int,
    paperChoice: Int,
    cleanPaper: Boolean,
    filter: FloatArray?,
    rebuild: Boolean = true
) = withContext(Dispatchers.IO) {
    DocScanFonts.init(context)
    val measure = Paint(Paint.ANTI_ALIAS_FLAG)
    val docPages = ArrayList<ScanDocx.Page>()
    for (page in pages) {
        val pageEdits = edits[page.id] ?: DocScanPageEdits()
        val prepared = docScanPreparePage(context, page, analyses[page.id], pageEdits, fontChoice, cleanPaper, rebuild)
        try {
            val layout = prepared.layout
            val (pageWidth, pageHeight) = docScanPageSize(prepared.analysis, paperChoice)
            val sx = pageWidth / layout.width.coerceAtLeast(1)
            val sy = pageHeight / layout.height.coerceAtLeast(1)
            val shapes = ArrayList<ScanDocx.Shape>()
            val images = ArrayList<ScanDocx.Image>()
            if (prepared.cleaned.rebuilt) {
                for (shape in prepared.cleaned.shapes) {
                    val edit = pageEdits.shapes[shape.id]
                    if (edit?.deleted == true) continue
                    val rect = docScanShapeRect(shape, edit)
                    shapes += ScanDocx.Shape(
                        rect.left * sx, rect.top * sy, rect.width() * sx, rect.height() * sy,
                        docScanFilterColor(edit?.color ?: shape.color, filter), shape.radius * sx,
                        shape.color2?.takeIf { edit?.color == null }?.let { docScanFilterColor(it, filter) },
                        shape.vertical,
                        shape.insets?.takeIf { shape.slanted }?.let { insets -> FloatArray(4) { (insets[it] * sx).coerceAtMost(rect.width() * sx / 2f) } }
                    )
                }
                for (piece in prepared.cleaned.objects) {
                    val edit = pageEdits.objects[piece.id]
                    if (edit?.deleted == true || piece.bitmap.isRecycled) continue
                    val rect = docScanObjectRect(piece.rect, edit)
                    docScanDocxImage(piece.bitmap, filter, rect.left * sx, rect.top * sy, rect.width() * sx, rect.height() * sy)
                        ?.let { images += it }
                }
            } else {
                // Foto limpia: va de fondo, del tamaño de la hoja.
                val background = withContext(Dispatchers.Default) {
                    docScanRender(
                        prepared.cleaned, layout, pageEdits.copy(signs = emptyList()), docScanAddedFamily(prepared.analysis, fontChoice),
                        filter, withText = false, withTables = false
                    )
                }
                try {
                    val bytes = ByteArrayOutputStream().also { background.compress(Bitmap.CompressFormat.JPEG, 88, it) }.toByteArray()
                    images += ScanDocx.Image(bytes, false, 0f, 0f, pageWidth, pageHeight)
                } finally {
                    background.recycle()
                }
            }
            for (sign in pageEdits.signs) {
                if (sign.bitmap.isRecycled) continue
                val rect = docScanSignRect(sign, layout.width.toFloat(), layout.height.toFloat())
                docScanDocxImage(sign.bitmap, filter, rect.left * sx, rect.top * sy, rect.width() * sx, rect.height() * sy)
                    ?.let { images += it }
            }

            // Cuadros de texto: uno por párrafo, en su lugar.
            val boxes = ArrayList<ScanDocx.TextBox>()
            for (placed in layout.blocks) {
                if (placed.deleted || placed.text.isBlank()) continue
                val lineCount = layout.runs.count { it.blockId == placed.id }.coerceAtLeast(1)
                val single = lineCount == 1 && !placed.text.contains('\n')
                val sizePt = placed.size * sy
                val leadingPt = max(placed.leading * sy, sizePt)
                measure.typeface = DocScanFonts.typeface(placed.family, placed.bold, placed.italic)
                measure.textSize = placed.size
                measure.textScaleX = placed.scaleX
                val areaWidth = placed.areaRight - placed.areaLeft
                val natural = if (single) measure.measureText(placed.text) else areaWidth
                // Un poco más ancho que el texto: la letra de Word puede medir apenas distinto.
                val width = if (single) max(areaWidth, natural) * sx * 1.15f + 4f else areaWidth * sx * 1.03f + 2f
                val extra = width - areaWidth * sx
                var x = placed.areaLeft * sx
                when (placed.align) {
                    DOC_SCAN_ALIGN_CENTER -> x -= extra / 2f
                    DOC_SCAN_ALIGN_RIGHT -> x -= extra
                }
                // La línea base queda donde estaba (Word pone la letra al fondo del renglón exacto).
                val top = placed.baseline * sy - (leadingPt - sizePt * 0.21f)
                boxes += ScanDocx.TextBox(
                    x.coerceAtLeast(0f), top, width, leadingPt * lineCount,
                    placed.text.split('\n'),
                    DocScanFonts.wordNames.getOrElse(placed.family) { "Arial" },
                    sizePt, placed.bold, placed.italic,
                    docScanFilterColor(placed.color, filter),
                    docScanWordAlign(placed.align),
                    leadingPt,
                    (placed.scaleX * 100f).roundToInt(),
                    singleLine = single
                )
            }
            val addedFamily = docScanAddedFamily(prepared.analysis, fontChoice)
            for (added in pageEdits.texts) {
                if (added.text.isBlank()) continue
                val size = added.size * layout.height
                measure.typeface = DocScanFonts.typeface(addedFamily, added.bold, added.italic)
                measure.textSize = size
                measure.textScaleX = 1f
                val sizePt = size * sy
                val leadingPt = sizePt * 1.22f
                boxes += ScanDocx.TextBox(
                    added.x * layout.width * sx, added.y * layout.height * sy - (leadingPt - sizePt * 0.21f),
                    measure.measureText(added.text) * sx * 1.15f + 4f, leadingPt,
                    listOf(added.text),
                    DocScanFonts.wordNames.getOrElse(addedFamily) { "Arial" },
                    sizePt, added.bold, added.italic, docScanFilterColor(added.color, filter),
                    "left", leadingPt, singleLine = true
                )
            }
            val tables = layout.tables.filter { !it.deleted }.map { docScanDocxTable(it, sx, filter) }
            docPages += ScanDocx.Page(pageWidth, pageHeight, shapes, images, boxes, tables)
        } finally {
            prepared.cleaned.recycle()
        }
    }
    ScanDocx.write(output, docPages)
}

private fun docScanWordAlign(align: Int): String = when (align) {
    DOC_SCAN_ALIGN_CENTER -> "center"
    DOC_SCAN_ALIGN_RIGHT -> "right"
    DOC_SCAN_ALIGN_JUSTIFY -> "both"
    else -> "left"
}

/** Imagen para el Word: PNG si tiene transparencia, JPG si es foto. */
private fun docScanDocxImage(bitmap: Bitmap, filter: FloatArray?, x: Float, y: Float, width: Float, height: Float): ScanDocx.Image? =
    runCatching {
        val source = if (filter != null) docScanFiltered(bitmap, filter) else bitmap
        try {
            val png = docScanHasAlpha(source)
            val bytes = ByteArrayOutputStream().also {
                source.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 90, it)
            }.toByteArray()
            ScanDocx.Image(bytes, png, x, y, width, height)
        } finally {
            if (source !== bitmap) source.recycle()
        }
    }.getOrNull()

/** Imagen para el PDF: con transparencia (logos, íconos, firmas) sin pérdida; fotos en JPG. */
private fun docScanPdfImage(document: PDDocument, bitmap: Bitmap, filter: FloatArray?): PDImageXObject? = runCatching {
    val source = if (filter != null) docScanFiltered(bitmap, filter) else bitmap
    try {
        if (docScanHasAlpha(source)) {
            LosslessFactory.createFromImage(document, source)
        } else {
            JPEGFactory.createFromImage(document, source, 0.9f)
        }
    } finally {
        if (source !== bitmap) source.recycle()
    }
}.getOrNull()

/** ¿Tiene partes transparentes? (se revisa una muestra de puntos). */
private fun docScanHasAlpha(bitmap: Bitmap): Boolean {
    val width = bitmap.width
    val height = bitmap.height
    if (width <= 0 || height <= 0) return false
    val row = IntArray(width)
    val step = max(1, height / 60)
    var y = 0
    while (y < height) {
        bitmap.getPixels(row, 0, width, 0, y, width, 1)
        for (x in 0 until width step max(1, width / 60)) if ((row[x] ushr 24) < 250) return true
        y += step
    }
    return false
}

/** Copia de la imagen con el filtro de color aplicado. */
private fun docScanFiltered(bitmap: Bitmap, filter: FloatArray): Bitmap {
    val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
    Canvas(output).drawBitmap(bitmap, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(filter) })
    return output
}

/** Imagen JPG de una página, igual a lo que se ve. */
internal suspend fun docScanWriteImage(
    context: Context,
    output: OutputStream,
    page: DocScanPage,
    analysis: DocScanAnalysis?,
    edits: DocScanPageEdits,
    fontChoice: Int,
    cleanPaper: Boolean,
    filter: FloatArray?,
    rebuild: Boolean = true
) = withContext(Dispatchers.IO) {
    DocScanFonts.init(context)
    val prepared = docScanPreparePage(context, page, analysis, edits, fontChoice, cleanPaper, rebuild)
    val rendered = try {
        withContext(Dispatchers.Default) {
            docScanRender(prepared.cleaned, prepared.layout, edits, docScanAddedFamily(prepared.analysis, fontChoice), filter)
        }
    } finally {
        prepared.cleaned.recycle()
    }
    try {
        check(rendered.compress(Bitmap.CompressFormat.JPEG, 92, output)) { "No se pudo guardar la imagen" }
    } finally {
        rendered.recycle()
    }
}

private fun docScanXml(value: String): String = value
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")
    .filter { it == '\t' || it == '\n' || it >= ' ' }

private fun docScanZip(zip: ZipOutputStream, name: String, text: String) {
    zip.putNextEntry(ZipEntry(name))
    zip.write(text.toByteArray(Charsets.UTF_8))
    zip.closeEntry()
}

/** Una página para el Word: sus párrafos y el tamaño de hoja. */
internal class DocScanWordPage(val paragraphs: List<DocScanParagraph>, val paper: Int, val landscape: Boolean)

/**
 * Word (.docx) armado a mano, sin librerías: los párrafos de cada página en
 * orden, con su letra, tamaño, negrita, cursiva, color, alineación y fondo de
 * color (títulos en barras). Cada página en su hoja y en su tamaño (A4, Carta…).
 */
internal fun docScanWriteDocx(output: OutputStream, pages: List<DocScanWordPage>) {
    fun hex(color: Int): String = String.format(
        java.util.Locale.ROOT, "%02X%02X%02X",
        android.graphics.Color.red(color), android.graphics.Color.green(color), android.graphics.Color.blue(color)
    )
    fun light(color: Int): Boolean =
        android.graphics.Color.red(color) * 299 + android.graphics.Color.green(color) * 587 +
            android.graphics.Color.blue(color) * 114 > 160_000
    fun section(page: DocScanWordPage): String {
        val known = ScanRebuild.papers.getOrNull(page.paper) ?: ScanRebuild.papers[0]
        var width = (known.second / 25.4f * 1440f).roundToInt()
        var height = (known.third / 25.4f * 1440f).roundToInt()
        if (page.landscape) width = height.also { height = width }
        val orient = if (page.landscape) " w:orient=\"landscape\"" else ""
        return "<w:sectPr><w:pgSz w:w=\"$width\" w:h=\"$height\"$orient/>" +
            "<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"709\" w:footer=\"709\" w:gutter=\"0\"/>" +
            "</w:sectPr>"
    }

    val body = StringBuilder()
    pages.forEachIndexed { pageIndex, page ->
        val paragraphs = page.paragraphs
        val pageWidthPt = (ScanRebuild.papers.getOrNull(page.paper) ?: ScanRebuild.papers[0]).let {
            (if (page.landscape) it.third else it.second) * 72f / 25.4f
        }
        if (paragraphs.isEmpty()) body.append("<w:p/>")
        paragraphs.forEachIndexed { index, paragraph ->
            val table = paragraph.table
            if (table != null) {
                // Tabla de Word de verdad, del ancho que tenía en la hoja (sin pasar los márgenes).
                val k = pageWidthPt / paragraph.pageWidth.coerceAtLeast(1f)
                body.append(ScanDocx.tableXml(docScanDocxTable(table, k, null, maxWidth = pageWidthPt - 113.4f), floating = false))
                body.append("<w:p><w:pPr><w:spacing w:after=\"120\"/>")
                if (index == paragraphs.lastIndex && pageIndex < pages.lastIndex) body.append(section(page))
                body.append("</w:pPr></w:p>")
                return@forEachIndexed
            }
            val halfPoints = (paragraph.size * pageWidthPt * 2f).roundToInt().coerceIn(12, 120)
            val shaded = !light(paragraph.background)
            val textColor = if (!shaded && light(paragraph.color)) android.graphics.Color.BLACK else paragraph.color
            val justify = when (paragraph.align) {
                DOC_SCAN_ALIGN_CENTER -> "center"
                DOC_SCAN_ALIGN_RIGHT -> "right"
                DOC_SCAN_ALIGN_JUSTIFY -> "both"
                else -> "left"
            }
            val font = DocScanFonts.wordNames.getOrElse(paragraph.family) { "Arial" }
            body.append("<w:p><w:pPr>")
            if (shaded) body.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(hex(paragraph.background)).append("\"/>")
            body.append("<w:spacing w:after=\"120\"/>")
            // Viñetas y listas numeradas: los renglones de abajo van alineados al texto.
            if (ScanRebuild.listPrefix(paragraph.text) > 0) body.append("<w:ind w:left=\"360\" w:hanging=\"360\"/>")
            body.append("<w:jc w:val=\"").append(justify).append("\"/>")
            // Al terminar una página (menos la última) va su tamaño de hoja: empieza otra hoja.
            if (index == paragraphs.lastIndex && pageIndex < pages.lastIndex) body.append(section(page))
            body.append("</w:pPr>")
            val runProperties = StringBuilder("<w:rPr><w:rFonts w:ascii=\"$font\" w:hAnsi=\"$font\" w:cs=\"$font\"/>")
            if (paragraph.bold) runProperties.append("<w:b/>")
            if (paragraph.italic) runProperties.append("<w:i/>")
            runProperties.append("<w:color w:val=\"").append(hex(textColor)).append("\"/>")
            runProperties.append("<w:sz w:val=\"$halfPoints\"/><w:szCs w:val=\"$halfPoints\"/></w:rPr>")
            paragraph.text.split('\n').forEachIndexed { lineIndex, line ->
                if (lineIndex > 0) body.append("<w:r><w:br/></w:r>")
                body.append("<w:r>").append(runProperties)
                body.append("<w:t xml:space=\"preserve\">").append(docScanXml(line)).append("</w:t></w:r>")
            }
            body.append("</w:p>")
        }
        if (paragraphs.isEmpty() && pageIndex < pages.lastIndex) body.append("<w:p><w:pPr>").append(section(page)).append("</w:pPr></w:p>")
    }
    val last = pages.lastOrNull() ?: DocScanWordPage(emptyList(), 0, false)
    val documentXml =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
            "<w:body>" + body + section(last) + "</w:body></w:document>"
    val types =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"
    val rootRels =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"
    ZipOutputStream(output).use { zip ->
        docScanZip(zip, "[Content_Types].xml", types)
        docScanZip(zip, "_rels/.rels", rootRels)
        docScanZip(zip, "word/document.xml", documentXml)
    }
}

/**
 * Copia las páginas del escáner de Google a la carpeta temporal de la app.
 * El escáner borra sus archivos en el siguiente escaneo; con la copia no se pierden.
 */
internal suspend fun docScanCopyToCache(context: Context, sources: List<Uri>): List<Uri> = withContext(Dispatchers.IO) {
    val directory = java.io.File(context.cacheDir, "camera").apply { mkdirs() }
    val stamp = System.currentTimeMillis()
    val copied = ArrayList<Uri>()
    sources.forEachIndexed { index, source ->
        val target = java.io.File(directory, "docscan_${stamp}_${index + 1}.jpg")
        val ok = runCatching {
            context.contentResolver.openInputStream(source)?.use { input ->
                target.outputStream().use { out -> input.copyTo(out) }
            } != null
        }.getOrDefault(false)
        if (ok && target.length() > 0L) {
            copied += androidx.core.content.FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                target
            )
        }
    }
    copied
}

/** Borra las copias de escaneos viejos (de otras sesiones). */
internal suspend fun docScanCleanCache(context: Context, keep: Set<String>) = withContext(Dispatchers.IO) {
    val directory = java.io.File(context.cacheDir, "camera")
    directory.listFiles()?.forEach { file ->
        if (file.name.startsWith("docscan_") && file.name !in keep) runCatching { file.delete() }
    }
}
