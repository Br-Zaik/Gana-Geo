package com.ganageo.app.tools

import kotlin.math.abs

enum class PlatformKind { SOLID, FALLING, DISAPPEARING, PROXIMITY_DISAPPEARING, REVEALING, BOUNCE }
enum class HazardKind { SPIKES, HIDDEN_SPIKES, SAW, FIRE, CEILING_SPIKES }
enum class HazardOrientation { UP, DOWN, LEFT, RIGHT }
enum class CheckpointKind { SAFE, POPUP, DECOY }
enum class FallingObjectKind { ROCK, FRUIT, CRATE, SPIKE_BALL }
enum class FallingBehavior { DROP, EXPLODE, ROLL, CHASE, CHAIN }
enum class CrusherAxis { HORIZONTAL, VERTICAL }
enum class CrusherStyle { STONE_COLUMN, FALLING_WALL, LOG_PRESS, RUIN_BLOCK }
enum class GameEnemyKind { WALKER, JUMPER, FLYER, SHOOTER, GUARDIAN }
enum class GamePickupKind { ENERGY, SHIELD, POWER }
enum class AdventureBiome { FOREST_DAY, FOREST_SUNSET, UNDERGROUND, CAVE_NIGHT, DESERT_DAWN }
enum class LevelExitKind { TRAIL, ASCENT, DESCENT, CAVE, DOOR, LIFT, BRIDGE, TUNNEL, RUIN_GATE, SUMMIT }

data class GamePlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float = 34f,
    val kind: PlatformKind = PlatformKind.SOLID,
    val triggerX: Float = x - 90f,
    val delayMs: Long = 720L,
    val cycleMs: Long = 2_200L,
    val phaseMs: Long = 0L
)

data class GameHazard(
    val x: Float,
    val y: Float,
    val width: Float = 58f,
    val height: Float = 42f,
    val kind: HazardKind = HazardKind.SPIKES,
    val triggerX: Float = x - 105f,
    val cycleMs: Long = 0L,
    val phaseMs: Long = 0L,
    val orientation: HazardOrientation = HazardOrientation.UP,
    val camouflaged: Boolean = false
)

data class GameBarrier(
    val x: Float,
    val y: Float = 270f,
    val width: Float = 46f,
    val height: Float = 350f,
    val switchIndex: Int
)

data class GameEnemy(
    val x: Float,
    val y: Float,
    val range: Float = 120f,
    val detectionRange: Float = 480f,
    val health: Int = 2,
    val kind: GameEnemyKind = GameEnemyKind.WALKER,
    val speed: Float = 72f
)

data class GameCrystal(val x: Float, val y: Float)
data class GameCrate(val x: Float, val y: Float)
data class GameSwitch(val x: Float, val y: Float, val opensAtX: Float, val reversesFans: Boolean = false)
data class GamePickup(val x: Float, val y: Float, val kind: GamePickupKind)

data class GameKey(
    val x: Float,
    val y: Float,
    val revealTriggerX: Float = x - 220f,
    val hiddenUntilSwitch: Int? = null
)

data class GameMovingPlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val travel: Float,
    val vertical: Boolean,
    val periodSeconds: Float = 3.4f
)

data class GameCheckpoint(
    val x: Float,
    val y: Float = 535f,
    val kind: CheckpointKind = CheckpointKind.SAFE,
    val appearTriggerX: Float = x - 180f
)

data class GameFan(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val forceX: Float,
    val forceY: Float,
    val cycleMs: Long = 0L,
    val phaseMs: Long = 0L,
    val switchIndex: Int? = null
)

data class GameFallingObject(
    val x: Float,
    val startY: Float,
    val targetY: Float,
    val size: Float,
    val triggerX: Float,
    val kind: FallingObjectKind,
    val delayMs: Long = 180L,
    val behavior: FallingBehavior = FallingBehavior.DROP,
    val rollDirection: Float = 1f,
    val explosionRadius: Float = 110f,
    val chainCount: Int = 1,
    val chainSpacing: Float = 74f,
    val chaseDurationMs: Long = 5_500L,
    val chaseMaxTravel: Float = 850f,
    val treeFallsAfterTrap: Boolean = false,
    val explosionDelayMs: Long = 650L,
    val becomesPlatform: Boolean = false
)

data class GameChasingHole(
    val startX: Float,
    val y: Float = 592f,
    val width: Float = 145f,
    val height: Float = 48f,
    val triggerX: Float,
    val speed: Float = 170f,
    val maxTravel: Float = 720f,
    val direction: Float = 1f,
    val surfaceStartX: Float = startX,
    val surfaceEndX: Float = startX + maxTravel + width
)

data class GameCrusher(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val triggerX: Float,
    val axis: CrusherAxis,
    val travel: Float,
    val speed: Float = 330f,
    val delayMs: Long = 280L,
    val reverseAfterMs: Long = 1_350L,
    val style: CrusherStyle = CrusherStyle.STONE_COLUMN,
    val despawnAfterMs: Long = 0L
)

data class AdventureLevel(
    val number: Int,
    val worldName: String,
    val levelName: String,
    val objective: String,
    val difficultyLabel: String,
    val width: Float,
    val platforms: List<GamePlatform>,
    val movingPlatforms: List<GameMovingPlatform>,
    val hazards: List<GameHazard>,
    val barriers: List<GameBarrier>,
    val enemies: List<GameEnemy>,
    val crystals: List<GameCrystal>,
    val crates: List<GameCrate>,
    val switches: List<GameSwitch>,
    val checkpoints: List<GameCheckpoint>,
    val fans: List<GameFan>,
    val fallingObjects: List<GameFallingObject>,
    val chasingHoles: List<GameChasingHole>,
    val crushers: List<GameCrusher>,
    val requiredMechanisms: Int,
    val pickups: List<GamePickup>,
    val goalX: Float,
    val parSeconds: Int,
    val introStory: String? = null,
    val outroStory: String? = null,
    val companion: String? = null,
    val injured: Boolean = false,
    val weaponEnabled: Boolean = false,
    val acechantePresent: Boolean = false,
    val biome: AdventureBiome = AdventureBiome.FOREST_DAY,
    val entryKind: LevelExitKind = LevelExitKind.TRAIL,
    val exitKind: LevelExitKind = LevelExitKind.TRAIL,
    val entryConnection: String = "start",
    val exitConnection: String = "end",
    val spawnX: Float = 70f,
    val spawnY: Float = 520f,
    val goalY: Float = 485f,
    val keys: List<GameKey> = emptyList(),
    val requiresKey: Boolean = false,
    val requiredCrystals: Int = 0
)

object GeoAdventureLevelFactory {
    private class Draft(
        val number: Int,
        val worldName: String,
        val levelName: String,
        val objective: String,
        val difficultyLabel: String,
        val width: Float,
        val biome: AdventureBiome,
        val entryKind: LevelExitKind,
        val exitKind: LevelExitKind,
        val entryConnection: String,
        val exitConnection: String,
        val spawnPlatformY: Float,
        val goalPlatformY: Float,
        val requiredMechanisms: Int = 0,
        val requiresKey: Boolean = false,
        val parSeconds: Int = 240,
        val introStory: String? = null,
        val outroStory: String? = null,
        val companion: String? = null,
        val weaponEnabled: Boolean = false,
        val acechantePresent: Boolean = false
    ) {
        val platforms = mutableListOf<GamePlatform>()
        val movingPlatforms = mutableListOf<GameMovingPlatform>()
        val hazards = mutableListOf<GameHazard>()
        val barriers = mutableListOf<GameBarrier>()
        val enemies = mutableListOf<GameEnemy>()
        val crates = mutableListOf<GameCrate>()
        val switches = mutableListOf<GameSwitch>()
        val checkpoints = mutableListOf<GameCheckpoint>()
        val fans = mutableListOf<GameFan>()
        val fallingObjects = mutableListOf<GameFallingObject>()
        val chasingHoles = mutableListOf<GameChasingHole>()
        val crushers = mutableListOf<GameCrusher>()
        val pickups = mutableListOf<GamePickup>()
        val keys = mutableListOf<GameKey>()

        fun platform(x: Float, y: Float, width: Float, kind: PlatformKind = PlatformKind.SOLID, delayMs: Long = 720L) {
            platforms += GamePlatform(x, y, width, kind = kind, triggerX = x - 80f, delayMs = delayMs)
        }

        fun moving(x: Float, y: Float, width: Float, travel: Float, vertical: Boolean, period: Float = 3.4f) {
            movingPlatforms += GameMovingPlatform(x, y, width, travel, vertical, period)
        }

        fun floorSpikes(x: Float, platformY: Float, width: Float = 58f, hidden: Boolean = true, cycleMs: Long = 2_500L, phaseMs: Long = 0L) {
            hazards += GameHazard(
                x = x,
                y = platformY - 44f,
                width = width,
                height = 44f,
                kind = if (hidden) HazardKind.HIDDEN_SPIKES else HazardKind.SPIKES,
                triggerX = x - 92f,
                cycleMs = cycleMs,
                phaseMs = phaseMs,
                orientation = HazardOrientation.UP,
                camouflaged = hidden
            )
        }

        fun ceilingSpikes(x: Float, ceilingBottomY: Float, width: Float = 66f, height: Float = 54f, phaseMs: Long = 0L) {
            // Techo físico visible: los pinchos nunca quedan flotando sin soporte.
            if (platforms.none { it.x <= x && it.x + it.width >= x + width && kotlin.math.abs((it.y + it.height) - ceilingBottomY) <= 4f }) {
                platforms += GamePlatform(x - 18f, ceilingBottomY - 34f, width + 36f, height = 34f)
            }
            hazards += GameHazard(
                x = x,
                y = ceilingBottomY,
                width = width,
                height = height,
                kind = HazardKind.HIDDEN_SPIKES,
                triggerX = x - 90f,
                cycleMs = 2_700L,
                phaseMs = phaseMs,
                orientation = HazardOrientation.DOWN,
                camouflaged = true
            )
        }

        fun wallSpikes(x: Float, y: Float, height: Float, fromLeft: Boolean, phaseMs: Long = 0L) {
            hazards += GameHazard(
                x = x,
                y = y,
                width = 48f,
                height = height,
                kind = HazardKind.HIDDEN_SPIKES,
                triggerX = x - 95f,
                cycleMs = 2_850L,
                phaseMs = phaseMs,
                orientation = if (fromLeft) HazardOrientation.RIGHT else HazardOrientation.LEFT,
                camouflaged = true
            )
        }

        fun fire(x: Float, platformY: Float, width: Float = 72f, phaseMs: Long = 0L) {
            hazards += GameHazard(x, platformY - 46f, width, 46f, HazardKind.FIRE, x - 110f, 2_250L, phaseMs, HazardOrientation.UP, false)
        }

        fun enemy(x: Float, platformY: Float, kind: GameEnemyKind = GameEnemyKind.WALKER, range: Float = 105f, speed: Float = 92f) {
            enemies += GameEnemy(x, platformY - 55f, range, 430f, 2, kind, speed)
        }

        fun checkpoint(x: Float, platformY: Float, popup: Boolean = true) {
            if (platforms.none { x in it.x..(it.x + it.width) && abs(it.y - platformY) < 1f && it.kind == PlatformKind.SOLID }) {
                platform(x - 115f, platformY, 250f)
            }
            checkpoints += GameCheckpoint(x, platformY - 85f, if (popup) CheckpointKind.POPUP else CheckpointKind.SAFE, x - 165f)
        }

        fun decoy(x: Float, platformY: Float) {
            checkpoints += GameCheckpoint(x, platformY - 85f, CheckpointKind.DECOY, x - 155f)
        }

        fun fruit(
            x: Float,
            startY: Float,
            targetY: Float,
            behavior: FallingBehavior,
            triggerX: Float = x - 150f,
            rollDirection: Float = 1f,
            treeFalls: Boolean = false,
            explosionRadius: Float = 105f,
            explosionDelayMs: Long = 720L
        ) {
            fallingObjects += GameFallingObject(
                x = x,
                startY = startY,
                targetY = targetY,
                size = 68f,
                triggerX = triggerX,
                kind = FallingObjectKind.FRUIT,
                delayMs = 180L,
                behavior = behavior,
                rollDirection = rollDirection,
                explosionRadius = explosionRadius,
                chainCount = if (behavior == FallingBehavior.CHAIN) 4 else 1,
                chainSpacing = 58f,
                chaseDurationMs = 5_500L,
                chaseMaxTravel = 820f,
                treeFallsAfterTrap = treeFalls,
                explosionDelayMs = explosionDelayMs
            )
        }

        fun fallingRock(x: Float, startY: Float, targetY: Float, triggerX: Float = x - 130f, becomesPlatform: Boolean = false) {
            fallingObjects += GameFallingObject(
                x = x,
                startY = startY,
                targetY = targetY,
                size = if (becomesPlatform) 82f else 72f,
                triggerX = triggerX,
                kind = FallingObjectKind.ROCK,
                behavior = FallingBehavior.DROP,
                becomesPlatform = becomesPlatform
            )
        }

        fun fan(x: Float, y: Float, width: Float, height: Float, forceX: Float, forceY: Float, phaseMs: Long = 0L, switchIndex: Int? = null) {
            fans += GameFan(x, y, width, height, forceX, forceY, 2_850L, phaseMs, switchIndex)
        }

        fun crusher(
            x: Float,
            y: Float,
            width: Float,
            height: Float,
            triggerX: Float,
            axis: CrusherAxis,
            travel: Float,
            style: CrusherStyle,
            speed: Float = 300f,
            reverseAfterMs: Long = 1_450L,
            despawnAfterMs: Long = 0L
        ) {
            crushers += GameCrusher(x, y, width, height, triggerX, axis, travel, speed, 320L, reverseAfterMs, style, despawnAfterMs)
        }

        fun switch(x: Float, platformY: Float, opensAtX: Float, reversesFans: Boolean = false) {
            switches += GameSwitch(x, platformY - 54f, opensAtX, reversesFans)
        }

        fun barrier(x: Float, switchIndex: Int, y: Float = 280f, height: Float = 340f) {
            barriers += GameBarrier(x, y, 48f, height, switchIndex)
        }

        fun key(x: Float, platformY: Float, hiddenUntilSwitch: Int? = null, revealTriggerX: Float = x - 220f) {
            keys += GameKey(x, platformY - 72f, revealTriggerX, hiddenUntilSwitch)
        }

        fun pickup(x: Float, platformY: Float, kind: GamePickupKind) {
            pickups += GamePickup(x, platformY - 72f, kind)
        }

        fun hole(startX: Float, platformY: Float, surfaceStartX: Float, surfaceEndX: Float, direction: Float = 1f, speed: Float = 155f) {
            chasingHoles += GameChasingHole(
                startX = startX,
                y = platformY - 28f,
                width = 125f,
                triggerX = startX - 45f,
                speed = speed,
                maxTravel = (surfaceEndX - surfaceStartX - 125f).coerceAtLeast(100f),
                direction = direction,
                surfaceStartX = surfaceStartX,
                surfaceEndX = surfaceEndX
            )
        }

        fun build(): AdventureLevel {
            if (platforms.none { spawnX() in it.x..(it.x + it.width) && abs(it.y - spawnPlatformY) < 1f }) {
                platform(0f, spawnPlatformY, 430f)
            }
            val goalX = width - 145f
            if (platforms.none { goalX in it.x..(it.x + it.width) && abs(it.y - goalPlatformY) < 1f }) {
                platform(width - 430f, goalPlatformY, 430f)
            }

            val realCheckpoints = checkpoints.filter { it.kind != CheckpointKind.DECOY }
            val safeHazards = hazards.filterNot { h -> realCheckpoints.any { cp -> abs((h.x + h.width / 2f) - cp.x) < 120f } }
            val safeFalling = fallingObjects.filterNot { f -> realCheckpoints.any { cp -> abs((f.x + f.size / 2f) - cp.x) < 130f } }
            val safeCrushers = crushers.filterNot { c -> realCheckpoints.any { cp -> abs((c.x + c.width / 2f) - cp.x) < 150f } }

            return AdventureLevel(
                number = number,
                worldName = worldName,
                levelName = levelName,
                objective = objective,
                difficultyLabel = difficultyLabel,
                width = width,
                platforms = platforms.sortedBy { it.x },
                movingPlatforms = movingPlatforms,
                hazards = safeHazards,
                barriers = barriers,
                enemies = enemies,
                crystals = emptyList(),
                crates = crates,
                switches = switches,
                checkpoints = checkpoints,
                fans = fans,
                fallingObjects = safeFalling,
                chasingHoles = chasingHoles,
                crushers = safeCrushers,
                requiredMechanisms = requiredMechanisms,
                pickups = pickups,
                goalX = goalX,
                parSeconds = parSeconds,
                introStory = introStory,
                outroStory = outroStory,
                companion = companion,
                weaponEnabled = weaponEnabled,
                acechantePresent = acechantePresent,
                biome = biome,
                entryKind = entryKind,
                exitKind = exitKind,
                entryConnection = entryConnection,
                exitConnection = exitConnection,
                spawnX = spawnX(),
                spawnY = spawnPlatformY - 58f,
                goalY = goalPlatformY - 135f,
                keys = keys,
                requiresKey = requiresKey,
                requiredCrystals = 0
            )
        }

        private fun spawnX() = 70f
    }

    private fun level1(): AdventureLevel = Draft(
        1, "Bosque vivo", "El árbol que miente", "Cruza la primera loma y usa el árbol caído como puente.", "BRUTAL",
        6_900f, AdventureBiome.FOREST_DAY, LevelExitKind.TRAIL, LevelExitKind.ASCENT, "awakening", "forest-ridge",
        620f, 470f, parSeconds = 230,
        introStory = "GEO despierta en un bosque luminoso. El camino parece tranquilo, pero el escenario aprende cada paso.",
        outroStory = "La loma conduce a un sendero más alto. GEO continúa sin volver atrás."
    ).apply {
        platform(0f, 620f, 760f)
        platform(900f, 585f, 510f)
        platform(1_540f, 535f, 430f)
        platform(2_120f, 590f, 720f)
        platform(3_030f, 520f, 480f)
        platform(3_680f, 455f, 410f)
        platform(4_250f, 535f, 690f)
        platform(5_120f, 485f, 520f)
        platform(5_820f, 470f, 1_080f)
        fruit(580f, 235f, 620f, FallingBehavior.ROLL, rollDirection = 1f, treeFalls = true)
        floorSpikes(1_160f, 585f, cycleMs = 2_850L)
        floorSpikes(2_460f, 590f, phaseMs = 420L)
        ceilingSpikes(3_180f, 315f, phaseMs = 600L)
        floorSpikes(4_600f, 535f, phaseMs = 850L)
        enemy(1_720f, 535f, GameEnemyKind.JUMPER, speed = 88f)
        enemy(3_870f, 455f, GameEnemyKind.WALKER, speed = 95f)
        checkpoint(2_680f, 590f)
        checkpoint(5_340f, 485f)
        pickup(4_820f, 535f, GamePickupKind.SHIELD)
    }.build()

    private fun level2(): AdventureLevel = Draft(
        2, "Bosque vivo", "La pendiente se abre", "Desciende por terrazas y escapa del suelo que se abre.", "BRUTAL+",
        7_300f, AdventureBiome.FOREST_DAY, LevelExitKind.ASCENT, LevelExitKind.DESCENT, "forest-ridge", "root-descent",
        470f, 620f, parSeconds = 245
    ).apply {
        platform(0f, 470f, 540f)
        platform(660f, 520f, 480f)
        platform(1_260f, 570f, 520f)
        platform(1_920f, 620f, 920f)
        platform(3_020f, 565f, 470f)
        platform(3_660f, 620f, 1_020f)
        platform(4_860f, 550f, 520f)
        platform(5_550f, 610f, 700f)
        platform(6_390f, 620f, 910f)
        hole(2_080f, 620f, 1_920f, 2_840f, speed = 145f)
        floorSpikes(1_520f, 570f, cycleMs = 3_000L)
        floorSpikes(3_270f, 565f, phaseMs = 450L)
        wallSpikes(4_560f, 425f, 88f, fromLeft = false, phaseMs = 750L)
        floorSpikes(5_880f, 610f, phaseMs = 900L)
        fruit(3_960f, 235f, 620f, FallingBehavior.EXPLODE, explosionRadius = 92f, explosionDelayMs = 850L)
        enemy(2_600f, 620f, GameEnemyKind.WALKER, speed = 96f)
        enemy(5_070f, 550f, GameEnemyKind.JUMPER, speed = 102f)
        checkpoint(1_600f, 570f)
        checkpoint(4_310f, 620f)
        checkpoint(6_630f, 620f)
        crusher(5_310f, 395f, 56f, 165f, 5_030f, CrusherAxis.HORIZONTAL, -130f, CrusherStyle.STONE_COLUMN, speed = 245f, reverseAfterMs = 1_700L)
    }.build()

    private fun level3(): AdventureLevel = Draft(
        3, "Bosque vivo", "Viento entre las copas", "Sube por corrientes de aire y rebota sobre enemigos.", "EXTREMO",
        7_600f, AdventureBiome.FOREST_DAY, LevelExitKind.DESCENT, LevelExitKind.BRIDGE, "root-descent", "canopy-bridge",
        620f, 390f, parSeconds = 255
    ).apply {
        platform(0f, 620f, 610f)
        platform(780f, 545f, 300f)
        platform(1_220f, 455f, 330f)
        platform(1_700f, 365f, 350f)
        platform(2_240f, 510f, 540f)
        platform(2_940f, 420f, 390f)
        platform(3_500f, 335f, 430f)
        platform(4_100f, 500f, 650f)
        platform(4_930f, 430f, 410f)
        platform(5_520f, 350f, 470f)
        platform(6_170f, 430f, 520f)
        platform(6_850f, 390f, 750f)
        fan(620f, 360f, 230f, 240f, 0f, -330f)
        fan(4_760f, 280f, 190f, 260f, 0f, -350f, phaseMs = 620L)
        moving(2_020f, 430f, 150f, 85f, true, 3.1f)
        moving(3_960f, 420f, 155f, 110f, true, 3.0f)
        floorSpikes(2_520f, 510f, phaseMs = 400L)
        ceilingSpikes(3_620f, 205f, phaseMs = 780L)
        floorSpikes(6_420f, 430f, phaseMs = 960L)
        enemy(1_370f, 455f, GameEnemyKind.JUMPER, range = 85f, speed = 85f)
        enemy(3_700f, 335f, GameEnemyKind.JUMPER, range = 90f, speed = 90f)
        enemy(5_760f, 350f, GameEnemyKind.JUMPER, range = 95f, speed = 96f)
        checkpoint(2_520f, 510f)
        checkpoint(4_430f, 500f)
        checkpoint(6_420f, 430f)
        pickup(5_760f, 350f, GamePickupKind.ENERGY)
    }.build()

    private fun level4(): AdventureLevel = Draft(
        4, "Bosque vivo", "La puerta bajo las raíces", "Encuentra la llave oculta y abre la puerta de raíces.", "EXTREMO+",
        7_900f, AdventureBiome.FOREST_DAY, LevelExitKind.BRIDGE, LevelExitKind.DOOR, "canopy-bridge", "root-door",
        390f, 620f, requiredMechanisms = 1, requiresKey = true, parSeconds = 275,
        outroStory = "La puerta se abre hacia un sendero teñido por el atardecer."
    ).apply {
        platform(0f, 390f, 620f)
        platform(760f, 470f, 460f)
        platform(1_380f, 550f, 720f)
        platform(2_260f, 620f, 820f)
        platform(3_250f, 525f, 430f)
        platform(3_840f, 440f, 470f)
        platform(4_480f, 535f, 710f)
        platform(5_360f, 610f, 820f)
        platform(6_350f, 540f, 500f)
        platform(7_000f, 620f, 900f)
        switch(2_720f, 620f, 3_060f)
        barrier(3_080f, 0, y = 310f, height = 310f)
        key(4_060f, 440f, hiddenUntilSwitch = 0)
        floorSpikes(1_720f, 550f, phaseMs = 320L)
        ceilingSpikes(2_520f, 300f, phaseMs = 690L)
        floorSpikes(4_820f, 535f, phaseMs = 930L)
        wallSpikes(6_740f, 395f, 100f, fromLeft = true, phaseMs = 1_100L)
        fruit(5_700f, 230f, 610f, FallingBehavior.CHASE, treeFalls = false)
        enemy(1_920f, 550f, GameEnemyKind.WALKER, speed = 105f)
        enemy(4_140f, 440f, GameEnemyKind.FLYER, speed = 92f)
        enemy(6_520f, 540f, GameEnemyKind.JUMPER, speed = 108f)
        checkpoint(2_000f, 550f)
        decoy(3_500f, 525f)
        checkpoint(5_870f, 610f)
        checkpoint(7_260f, 620f)
    }.build()

    private fun level5(): AdventureLevel = Draft(
        5, "Bosque del atardecer", "El puente que recuerda", "Activa la palanca y convierte un tronco caído en el único puente.", "DEMENTE",
        8_200f, AdventureBiome.FOREST_SUNSET, LevelExitKind.DOOR, LevelExitKind.BRIDGE, "root-door", "sunset-bridge",
        620f, 520f, requiredMechanisms = 1, parSeconds = 285,
        introStory = "El sol desciende. Las sombras ocultan mecanismos viejos bajo las raíces.", companion = "Luma"
    ).apply {
        platform(0f, 620f, 760f)
        platform(940f, 560f, 560f)
        platform(1_680f, 620f, 720f)
        platform(2_620f, 515f, 520f, PlatformKind.PROXIMITY_DISAPPEARING, delayMs = 1_050L)
        platform(3_340f, 455f, 460f)
        platform(4_050f, 620f, 780f)
        platform(5_020f, 530f, 520f)
        platform(5_720f, 455f, 510f)
        platform(6_430f, 570f, 650f)
        platform(7_260f, 520f, 940f)
        switch(1_980f, 620f, 2_380f)
        barrier(2_420f, 0, y = 300f, height = 320f)
        fruit(3_570f, 210f, 455f, FallingBehavior.EXPLODE, treeFalls = true, explosionRadius = 100f)
        floorSpikes(1_180f, 560f, phaseMs = 250L)
        floorSpikes(4_420f, 620f, phaseMs = 650L)
        ceilingSpikes(5_860f, 250f, phaseMs = 900L)
        floorSpikes(6_820f, 570f, phaseMs = 1_150L)
        enemy(2_860f, 515f, GameEnemyKind.WALKER, speed = 108f)
        enemy(5_280f, 530f, GameEnemyKind.JUMPER, speed = 112f)
        checkpoint(2_060f, 620f)
        checkpoint(4_550f, 620f)
        checkpoint(6_720f, 570f)
        pickup(5_980f, 455f, GamePickupKind.SHIELD)
    }.build()

    private fun level6(): AdventureLevel = Draft(
        6, "Bosque del atardecer", "El barranco naranja", "Baja por el barranco antes de que las rocas cierren las terrazas.", "DEMENTE+",
        8_500f, AdventureBiome.FOREST_SUNSET, LevelExitKind.BRIDGE, LevelExitKind.DESCENT, "sunset-bridge", "orange-ravine",
        520f, 620f, parSeconds = 295
    ).apply {
        platform(0f, 520f, 560f)
        platform(720f, 570f, 470f)
        platform(1_340f, 620f, 650f)
        platform(2_160f, 545f, 460f)
        platform(2_780f, 620f, 820f)
        platform(3_780f, 565f, 510f)
        platform(4_450f, 620f, 730f)
        platform(5_360f, 540f, 520f)
        platform(6_060f, 600f, 620f)
        platform(6_850f, 530f, 470f)
        platform(7_480f, 620f, 1_020f)
        fallingRock(1_690f, 180f, 620f)
        fallingRock(3_180f, 160f, 620f, becomesPlatform = true)
        fallingRock(5_720f, 170f, 540f)
        floorSpikes(2_360f, 545f, phaseMs = 330L)
        wallSpikes(4_980f, 435f, 110f, fromLeft = false, phaseMs = 720L)
        floorSpikes(7_860f, 620f, phaseMs = 1_030L)
        crusher(6_580f, 245f, 150f, 82f, 6_300f, CrusherAxis.VERTICAL, 260f, CrusherStyle.RUIN_BLOCK, speed = 280f, despawnAfterMs = 3_000L)
        enemy(1_560f, 620f, GameEnemyKind.JUMPER, speed = 110f)
        enemy(4_720f, 620f, GameEnemyKind.WALKER, speed = 116f)
        enemy(7_050f, 530f, GameEnemyKind.JUMPER, speed = 118f)
        checkpoint(1_650f, 620f)
        checkpoint(4_770f, 620f)
        checkpoint(7_850f, 620f)
    }.build()

    private fun level7(): AdventureLevel = Draft(
        7, "Bosque del atardecer", "Muros de hojas", "Escapa de muros cortos que caen y desaparecen tras el impacto.", "INHUMANO",
        8_800f, AdventureBiome.FOREST_SUNSET, LevelExitKind.DESCENT, LevelExitKind.CAVE, "orange-ravine", "leaf-cave",
        620f, 500f, parSeconds = 305
    ).apply {
        platform(0f, 620f, 820f)
        platform(980f, 550f, 460f)
        platform(1_600f, 480f, 430f)
        platform(2_200f, 570f, 720f)
        platform(3_100f, 500f, 500f)
        platform(3_780f, 420f, 430f, PlatformKind.FALLING, delayMs = 820L)
        platform(4_380f, 540f, 760f)
        platform(5_320f, 470f, 490f)
        platform(5_980f, 590f, 710f)
        platform(6_870f, 510f, 520f)
        platform(7_560f, 500f, 1_240f)
        crusher(1_330f, 210f, 150f, 88f, 1_080f, CrusherAxis.VERTICAL, 270f, CrusherStyle.FALLING_WALL, speed = 290f, despawnAfterMs = 2_900L)
        crusher(3_450f, 150f, 165f, 92f, 3_190f, CrusherAxis.VERTICAL, 270f, CrusherStyle.FALLING_WALL, speed = 305f, despawnAfterMs = 3_000L)
        crusher(6_420f, 250f, 150f, 88f, 6_160f, CrusherAxis.VERTICAL, 270f, CrusherStyle.FALLING_WALL, speed = 315f, despawnAfterMs = 3_100L)
        floorSpikes(2_540f, 570f, phaseMs = 350L)
        ceilingSpikes(4_720f, 320f, phaseMs = 700L)
        floorSpikes(7_940f, 500f, phaseMs = 980L)
        fruit(5_520f, 205f, 470f, FallingBehavior.CHAIN)
        enemy(1_820f, 480f, GameEnemyKind.JUMPER, speed = 112f)
        enemy(4_680f, 540f, GameEnemyKind.WALKER, speed = 120f)
        enemy(7_140f, 510f, GameEnemyKind.FLYER, speed = 100f)
        checkpoint(2_620f, 570f)
        checkpoint(5_580f, 470f)
        checkpoint(7_980f, 500f)
    }.build()

    private fun level8(): AdventureLevel = Draft(
        8, "Bosque del atardecer", "La cueva de raíces", "Entra en la cueva alternando rutas altas y bajas.", "INHUMANO+",
        9_100f, AdventureBiome.FOREST_SUNSET, LevelExitKind.CAVE, LevelExitKind.TUNNEL, "leaf-cave", "deep-tunnel",
        500f, 580f, requiredMechanisms = 2, parSeconds = 320
    ).apply {
        platform(0f, 500f, 610f)
        platform(780f, 590f, 700f)
        platform(1_650f, 470f, 480f)
        platform(2_300f, 620f, 760f)
        platform(3_240f, 520f, 540f)
        platform(3_940f, 410f, 430f, PlatformKind.REVEALING, delayMs = 900L)
        platform(4_540f, 560f, 690f)
        platform(5_400f, 450f, 510f)
        platform(6_080f, 620f, 760f)
        platform(7_030f, 500f, 550f)
        platform(7_750f, 580f, 1_350f)
        switch(1_050f, 590f, 1_480f, reversesFans = true)
        switch(5_720f, 450f, 6_000f)
        barrier(6_000f, 1, y = 300f, height = 320f)
        fan(2_980f, 350f, 250f, 260f, 245f, 0f, switchIndex = 0)
        floorSpikes(2_600f, 620f, phaseMs = 250L)
        ceilingSpikes(4_020f, 225f, phaseMs = 580L)
        wallSpikes(5_820f, 330f, 100f, fromLeft = true, phaseMs = 820L)
        floorSpikes(8_180f, 580f, phaseMs = 1_050L)
        fruit(7_340f, 210f, 500f, FallingBehavior.CHASE)
        enemy(1_870f, 470f, GameEnemyKind.JUMPER, speed = 118f)
        enemy(4_820f, 560f, GameEnemyKind.WALKER, speed = 122f)
        enemy(7_320f, 500f, GameEnemyKind.SHOOTER, speed = 90f)
        checkpoint(2_720f, 620f)
        checkpoint(5_020f, 560f)
        checkpoint(8_380f, 580f)
    }.build()

    private fun level9(): AdventureLevel = Draft(
        9, "Descenso subterráneo", "La llave detrás de la luz", "Encuentra una llave escondida en una ruta superior y abre el túnel.", "PESADILLA",
        9_400f, AdventureBiome.UNDERGROUND, LevelExitKind.TUNNEL, LevelExitKind.DOOR, "deep-tunnel", "sealed-shaft",
        580f, 620f, requiredMechanisms = 1, requiresKey = true, parSeconds = 330,
        introStory = "La luz del atardecer desaparece. Las raíces dan paso a piedra húmeda y mecanismos antiguos.", companion = "Luma"
    ).apply {
        platform(0f, 580f, 760f)
        platform(920f, 500f, 480f)
        platform(1_570f, 410f, 460f)
        platform(2_200f, 540f, 680f)
        platform(3_050f, 620f, 850f)
        platform(4_080f, 510f, 520f)
        platform(4_770f, 420f, 490f)
        platform(5_440f, 560f, 710f)
        platform(6_330f, 470f, 510f)
        platform(7_010f, 620f, 800f)
        platform(7_990f, 540f, 560f)
        platform(8_720f, 620f, 680f)
        switch(3_520f, 620f, 3_900f)
        key(4_990f, 420f, hiddenUntilSwitch = 0)
        floorSpikes(1_180f, 500f, phaseMs = 300L)
        wallSpikes(2_720f, 405f, 100f, fromLeft = false, phaseMs = 550L)
        floorSpikes(3_380f, 620f, phaseMs = 800L)
        ceilingSpikes(5_600f, 300f, phaseMs = 980L)
        floorSpikes(7_420f, 620f, phaseMs = 1_180L)
        decoy(2_520f, 540f)
        fallingRock(6_570f, 180f, 470f)
        enemy(1_820f, 410f, GameEnemyKind.JUMPER, speed = 118f)
        enemy(4_360f, 510f, GameEnemyKind.SHOOTER, speed = 92f)
        enemy(7_300f, 620f, GameEnemyKind.WALKER, speed = 126f)
        checkpoint(3_540f, 620f)
        checkpoint(6_020f, 560f)
        checkpoint(8_980f, 620f)
    }.build()

    private fun level10(): AdventureLevel = Draft(
        10, "Descenso subterráneo", "El ascensor roto", "Repara el ascensor y baja hasta las profundidades.", "PESADILLA+",
        9_700f, AdventureBiome.UNDERGROUND, LevelExitKind.DOOR, LevelExitKind.LIFT, "sealed-shaft", "broken-lift",
        620f, 430f, requiredMechanisms = 2, parSeconds = 345
    ).apply {
        platform(0f, 620f, 720f)
        platform(880f, 540f, 500f)
        platform(1_540f, 460f, 470f)
        platform(2_180f, 570f, 760f)
        platform(3_120f, 480f, 510f)
        platform(3_800f, 390f, 440f)
        platform(4_420f, 540f, 700f)
        platform(5_300f, 450f, 520f)
        platform(6_000f, 590f, 760f)
        platform(6_950f, 500f, 520f)
        platform(7_650f, 410f, 520f)
        platform(8_350f, 500f, 520f)
        platform(9_030f, 430f, 670f)
        switch(2_520f, 570f, 2_930f)
        switch(6_380f, 590f, 6_760f)
        barrier(2_960f, 0, y = 280f, height = 340f)
        barrier(6_800f, 1, y = 280f, height = 340f)
        moving(4_220f, 450f, 150f, 100f, true, 3.0f)
        moving(8_050f, 460f, 155f, 110f, true, 2.8f)
        ceilingSpikes(1_740f, 285f, phaseMs = 310L)
        floorSpikes(4_750f, 540f, phaseMs = 620L)
        wallSpikes(7_450f, 300f, 100f, fromLeft = true, phaseMs = 860L)
        floorSpikes(8_700f, 500f, phaseMs = 1_100L)
        crusher(5_600f, 200f, 150f, 88f, 5_340f, CrusherAxis.VERTICAL, 250f, CrusherStyle.RUIN_BLOCK, speed = 300f, despawnAfterMs = 3_200L)
        enemy(1_760f, 460f, GameEnemyKind.JUMPER, speed = 120f)
        enemy(4_760f, 540f, GameEnemyKind.WALKER, speed = 126f)
        enemy(7_920f, 410f, GameEnemyKind.SHOOTER, speed = 95f)
        checkpoint(2_580f, 570f)
        checkpoint(5_560f, 450f)
        checkpoint(8_650f, 500f)
    }.build()

    private fun level11(): AdventureLevel = Draft(
        11, "Cavernas nocturnas", "Luciérnagas del abismo", "Sigue las luces por pozos verticales y plataformas móviles.", "ABISMO",
        10_000f, AdventureBiome.CAVE_NIGHT, LevelExitKind.LIFT, LevelExitKind.DESCENT, "broken-lift", "firefly-depth",
        430f, 620f, parSeconds = 355,
        introStory = "El ascensor se detiene en una caverna inmensa. Solo las luciérnagas marcan el camino seguro."
    ).apply {
        platform(0f, 430f, 560f)
        platform(720f, 520f, 460f)
        platform(1_340f, 620f, 740f)
        platform(2_260f, 500f, 520f)
        platform(2_950f, 390f, 460f)
        platform(3_590f, 540f, 720f)
        platform(4_480f, 440f, 520f)
        platform(5_180f, 330f, 450f, PlatformKind.BOUNCE)
        platform(5_810f, 500f, 650f)
        platform(6_650f, 610f, 730f)
        platform(7_550f, 470f, 520f)
        platform(8_250f, 360f, 480f)
        platform(8_900f, 520f, 500f)
        platform(9_550f, 620f, 450f)
        moving(560f, 470f, 150f, 105f, true, 3.1f)
        moving(3_360f, 430f, 150f, 100f, true, 2.9f)
        moving(6_420f, 500f, 160f, 115f, true, 2.8f)
        fan(7_300f, 300f, 190f, 300f, 0f, -330f, phaseMs = 480L)
        floorSpikes(1_620f, 620f, phaseMs = 260L)
        ceilingSpikes(3_060f, 205f, phaseMs = 530L)
        floorSpikes(6_980f, 610f, phaseMs = 820L)
        wallSpikes(8_760f, 365f, 110f, fromLeft = false, phaseMs = 1_050L)
        enemy(2_520f, 500f, GameEnemyKind.JUMPER, speed = 124f)
        enemy(5_360f, 330f, GameEnemyKind.FLYER, speed = 105f)
        enemy(8_450f, 360f, GameEnemyKind.JUMPER, speed = 128f)
        checkpoint(1_740f, 620f)
        checkpoint(4_760f, 440f)
        checkpoint(7_860f, 470f)
        checkpoint(9_760f, 620f)
    }.build()

    private fun level12(): AdventureLevel = Draft(
        12, "Cavernas nocturnas", "La cámara que respira", "Cruza una cámara que abre y cierra sus paredes con ritmo aprendible.", "ABISMO+",
        10_300f, AdventureBiome.CAVE_NIGHT, LevelExitKind.DESCENT, LevelExitKind.CAVE, "firefly-depth", "breathing-cave",
        620f, 500f, parSeconds = 365
    ).apply {
        platform(0f, 620f, 820f)
        platform(980f, 540f, 510f)
        platform(1_660f, 450f, 480f)
        platform(2_310f, 580f, 760f)
        platform(3_250f, 490f, 520f)
        platform(3_940f, 400f, 470f)
        platform(4_590f, 550f, 760f)
        platform(5_520f, 460f, 520f)
        platform(6_220f, 580f, 760f)
        platform(7_160f, 490f, 520f)
        platform(7_860f, 400f, 480f)
        platform(8_520f, 550f, 650f)
        platform(9_340f, 500f, 960f)
        crusher(1_440f, 360f, 54f, 160f, 1_180f, CrusherAxis.HORIZONTAL, -120f, CrusherStyle.STONE_COLUMN, speed = 245f, reverseAfterMs = 1_650L)
        crusher(4_180f, 250f, 54f, 150f, 3_900f, CrusherAxis.HORIZONTAL, -125f, CrusherStyle.STONE_COLUMN, speed = 255f, reverseAfterMs = 1_600L)
        crusher(7_630f, 250f, 54f, 150f, 7_350f, CrusherAxis.HORIZONTAL, -130f, CrusherStyle.STONE_COLUMN, speed = 265f, reverseAfterMs = 1_550L)
        floorSpikes(2_650f, 580f, phaseMs = 260L)
        ceilingSpikes(4_880f, 330f, phaseMs = 520L)
        floorSpikes(6_600f, 580f, phaseMs = 770L)
        wallSpikes(9_080f, 390f, 100f, fromLeft = true, phaseMs = 1_020L)
        enemy(1_900f, 450f, GameEnemyKind.WALKER, speed = 128f)
        enemy(5_760f, 460f, GameEnemyKind.SHOOTER, speed = 98f)
        enemy(8_760f, 550f, GameEnemyKind.JUMPER, speed = 132f)
        checkpoint(2_720f, 580f)
        checkpoint(5_920f, 460f)
        checkpoint(8_830f, 550f)
    }.build()

    private fun level13(): AdventureLevel = Draft(
        13, "Cavernas nocturnas", "Ríos de aire", "Usa corrientes horizontales sin dejar que te empujen al vacío.", "SIN PIEDAD",
        10_600f, AdventureBiome.CAVE_NIGHT, LevelExitKind.CAVE, LevelExitKind.ASCENT, "breathing-cave", "air-shaft",
        500f, 350f, requiredMechanisms = 1, parSeconds = 380, companion = "Taro"
    ).apply {
        platform(0f, 500f, 600f)
        platform(760f, 600f, 700f)
        platform(1_630f, 500f, 500f)
        platform(2_300f, 410f, 470f)
        platform(2_940f, 540f, 740f)
        platform(3_850f, 450f, 510f)
        platform(4_540f, 360f, 470f, PlatformKind.PROXIMITY_DISAPPEARING, delayMs = 980L)
        platform(5_180f, 520f, 720f)
        platform(6_080f, 430f, 510f)
        platform(6_770f, 340f, 470f)
        platform(7_420f, 500f, 720f)
        platform(8_320f, 410f, 520f)
        platform(9_020f, 320f, 500f)
        platform(9_700f, 350f, 900f)
        switch(1_100f, 600f, 1_460f, reversesFans = true)
        fan(1_450f, 330f, 650f, 250f, 245f, 0f, switchIndex = 0)
        fan(5_860f, 250f, 560f, 260f, -250f, 0f, phaseMs = 550L)
        fan(8_800f, 160f, 200f, 310f, 0f, -350f, phaseMs = 950L)
        floorSpikes(3_240f, 540f, phaseMs = 270L)
        ceilingSpikes(4_700f, 180f, phaseMs = 560L)
        floorSpikes(7_720f, 500f, phaseMs = 830L)
        wallSpikes(9_520f, 210f, 100f, fromLeft = false, phaseMs = 1_080L)
        enemy(2_520f, 410f, GameEnemyKind.JUMPER, speed = 126f)
        enemy(6_320f, 430f, GameEnemyKind.FLYER, speed = 108f)
        enemy(9_250f, 320f, GameEnemyKind.JUMPER, speed = 134f)
        checkpoint(3_320f, 540f)
        checkpoint(6_300f, 430f)
        checkpoint(9_880f, 350f)
    }.build()

    private fun level14(): AdventureLevel = Draft(
        14, "Cavernas nocturnas", "El descanso falso", "Reconoce el checkpoint falso y sube por paredes con pinchos retráctiles.", "SIN PIEDAD+",
        10_900f, AdventureBiome.CAVE_NIGHT, LevelExitKind.ASCENT, LevelExitKind.TUNNEL, "air-shaft", "false-rest",
        350f, 470f, parSeconds = 390
    ).apply {
        platform(0f, 350f, 620f)
        platform(780f, 440f, 500f)
        platform(1_450f, 530f, 720f)
        platform(2_340f, 430f, 500f)
        platform(3_010f, 340f, 470f)
        platform(3_650f, 500f, 740f)
        platform(4_560f, 410f, 520f)
        platform(5_260f, 320f, 470f)
        platform(5_900f, 480f, 760f)
        platform(6_840f, 390f, 520f)
        platform(7_540f, 540f, 740f)
        platform(8_450f, 450f, 520f)
        platform(9_150f, 360f, 500f)
        platform(9_830f, 470f, 1_070f)
        wallSpikes(1_230f, 300f, 100f, fromLeft = false, phaseMs = 250L)
        floorSpikes(1_780f, 530f, phaseMs = 480L)
        ceilingSpikes(3_150f, 155f, phaseMs = 690L)
        wallSpikes(5_080f, 220f, 100f, fromLeft = true, phaseMs = 900L)
        floorSpikes(6_180f, 480f, phaseMs = 1_120L)
        ceilingSpikes(8_650f, 265f, phaseMs = 1_330L)
        decoy(2_580f, 430f)
        fruit(7_820f, 205f, 540f, FallingBehavior.EXPLODE, explosionRadius = 100f)
        enemy(1_760f, 530f, GameEnemyKind.WALKER, speed = 130f)
        enemy(4_820f, 410f, GameEnemyKind.SHOOTER, speed = 100f)
        enemy(7_900f, 540f, GameEnemyKind.JUMPER, speed = 136f)
        checkpoint(3_900f, 500f)
        checkpoint(6_180f, 480f)
        checkpoint(9_980f, 470f)
    }.build()

    private fun level15(): AdventureLevel = Draft(
        15, "Cavernas nocturnas", "La llave de lava", "Encuentra la llave, activa la compuerta y comienza el ascenso.", "APOCALÍPTICO",
        11_200f, AdventureBiome.CAVE_NIGHT, LevelExitKind.TUNNEL, LevelExitKind.DOOR, "false-rest", "lava-door",
        470f, 300f, requiredMechanisms = 2, requiresKey = true, parSeconds = 410,
        outroStory = "La compuerta de lava se abre hacia una chimenea natural. Por primera vez, el camino vuelve a subir."
    ).apply {
        platform(0f, 470f, 650f)
        platform(820f, 580f, 720f)
        platform(1_710f, 470f, 520f)
        platform(2_400f, 360f, 500f)
        platform(3_070f, 520f, 760f)
        platform(4_010f, 410f, 520f)
        platform(4_710f, 300f, 490f)
        platform(5_380f, 500f, 760f)
        platform(6_320f, 390f, 520f)
        platform(7_020f, 280f, 480f)
        platform(7_680f, 480f, 760f)
        platform(8_620f, 370f, 520f)
        platform(9_320f, 520f, 720f)
        platform(10_210f, 410f, 500f)
        platform(10_880f, 300f, 320f)
        switch(1_160f, 580f, 1_550f)
        switch(5_780f, 500f, 6_140f)
        barrier(1_570f, 0, y = 280f, height = 340f)
        barrier(6_160f, 1, y = 260f, height = 360f)
        key(7_230f, 280f, hiddenUntilSwitch = 1)
        fire(3_420f, 520f, phaseMs = 260L)
        ceilingSpikes(4_860f, 115f, phaseMs = 520L)
        fire(5_720f, 500f, phaseMs = 760L)
        wallSpikes(8_430f, 245f, 100f, fromLeft = false, phaseMs = 1_010L)
        fire(9_680f, 520f, phaseMs = 1_250L)
        crusher(10_020f, 200f, 155f, 88f, 9_760f, CrusherAxis.VERTICAL, 230f, CrusherStyle.FALLING_WALL, speed = 320f, despawnAfterMs = 3_000L)
        enemy(2_000f, 470f, GameEnemyKind.JUMPER, speed = 132f)
        enemy(5_020f, 300f, GameEnemyKind.FLYER, speed = 112f)
        enemy(8_900f, 370f, GameEnemyKind.SHOOTER, speed = 102f)
        checkpoint(3_550f, 520f)
        checkpoint(6_620f, 390f)
        checkpoint(9_650f, 520f)
        checkpoint(10_980f, 300f)
        pickup(8_900f, 370f, GamePickupKind.SHIELD)
    }.build()

    private fun level16(): AdventureLevel = Draft(
        16, "Desierto del amanecer", "La salida de las profundidades", "Sube por la chimenea y emerge entre dunas.", "APOCALÍPTICO+",
        11_500f, AdventureBiome.DESERT_DAWN, LevelExitKind.DOOR, LevelExitKind.ASCENT, "lava-door", "dawn-rise",
        300f, 520f, parSeconds = 420,
        introStory = "Una luz dorada aparece sobre GEO. Las cavernas terminan y el viento del desierto entra por las grietas.", companion = "Taro"
    ).apply {
        platform(0f, 300f, 620f)
        platform(780f, 390f, 500f)
        platform(1_450f, 500f, 720f)
        platform(2_340f, 410f, 520f)
        platform(3_040f, 320f, 470f)
        platform(3_690f, 480f, 760f)
        platform(4_630f, 390f, 520f)
        platform(5_330f, 540f, 760f)
        platform(6_270f, 450f, 520f)
        platform(6_970f, 360f, 490f)
        platform(7_640f, 520f, 760f)
        platform(8_580f, 430f, 520f)
        platform(9_280f, 340f, 490f)
        platform(9_950f, 500f, 720f)
        platform(10_840f, 520f, 660f)
        fan(620f, 170f, 220f, 300f, 0f, -340f)
        fan(6_030f, 260f, 190f, 280f, 0f, -330f, phaseMs = 600L)
        moving(3_500f, 380f, 150f, 95f, true, 2.9f)
        moving(9_760f, 410f, 155f, 100f, true, 2.8f)
        floorSpikes(1_820f, 500f, phaseMs = 240L)
        ceilingSpikes(3_180f, 135f, phaseMs = 490L)
        floorSpikes(5_720f, 540f, phaseMs = 760L)
        wallSpikes(9_080f, 225f, 100f, fromLeft = true, phaseMs = 1_020L)
        enemy(2_580f, 410f, GameEnemyKind.JUMPER, speed = 134f)
        enemy(6_520f, 450f, GameEnemyKind.FLYER, speed = 114f)
        enemy(10_180f, 500f, GameEnemyKind.JUMPER, speed = 138f)
        checkpoint(1_850f, 500f)
        checkpoint(4_950f, 390f)
        checkpoint(8_850f, 430f)
        checkpoint(11_120f, 520f)
    }.build()

    private fun level17(): AdventureLevel = Draft(
        17, "Desierto del amanecer", "Ruinas que se derrumban", "Provoca derrumbes y usa los bloques caídos como escalones.", "IMPOSIBLE",
        11_800f, AdventureBiome.DESERT_DAWN, LevelExitKind.ASCENT, LevelExitKind.RUIN_GATE, "dawn-rise", "fallen-ruins",
        520f, 420f, parSeconds = 435
    ).apply {
        platform(0f, 520f, 700f)
        platform(870f, 430f, 520f)
        platform(1_570f, 550f, 760f)
        platform(2_510f, 460f, 520f)
        platform(3_210f, 370f, 480f)
        platform(3_870f, 530f, 760f)
        platform(4_810f, 440f, 520f)
        platform(5_510f, 350f, 490f)
        platform(6_180f, 510f, 760f)
        platform(7_120f, 420f, 520f)
        platform(7_820f, 330f, 490f, PlatformKind.FALLING, delayMs = 900L)
        platform(8_490f, 490f, 760f)
        platform(9_430f, 400f, 520f)
        platform(10_130f, 520f, 720f)
        platform(11_020f, 420f, 780f)
        fallingRock(1_180f, 150f, 430f, becomesPlatform = true)
        fallingRock(4_100f, 140f, 440f, becomesPlatform = true)
        fallingRock(8_720f, 140f, 490f, becomesPlatform = true)
        crusher(2_980f, 140f, 165f, 90f, 2_700f, CrusherAxis.VERTICAL, 230f, CrusherStyle.FALLING_WALL, speed = 325f, despawnAfterMs = 3_000L)
        crusher(7_550f, 110f, 165f, 90f, 7_280f, CrusherAxis.VERTICAL, 220f, CrusherStyle.FALLING_WALL, speed = 335f, despawnAfterMs = 3_100L)
        floorSpikes(1_950f, 550f, phaseMs = 250L)
        wallSpikes(5_300f, 235f, 100f, fromLeft = false, phaseMs = 620L)
        floorSpikes(10_500f, 520f, phaseMs = 1_020L)
        enemy(2_780f, 460f, GameEnemyKind.WALKER, speed = 138f)
        enemy(6_470f, 510f, GameEnemyKind.SHOOTER, speed = 104f)
        enemy(9_700f, 400f, GameEnemyKind.JUMPER, speed = 142f)
        checkpoint(2_030f, 550f)
        checkpoint(5_080f, 440f)
        checkpoint(8_850f, 490f)
        checkpoint(11_250f, 420f)
    }.build()

    private fun level18(): AdventureLevel = Draft(
        18, "Desierto del amanecer", "El templo de la llave", "Abre una ruta secreta, encuentra la llave y cruza la puerta del templo.", "IMPOSIBLE+",
        12_100f, AdventureBiome.DESERT_DAWN, LevelExitKind.RUIN_GATE, LevelExitKind.DOOR, "fallen-ruins", "temple-door",
        420f, 560f, requiredMechanisms = 2, requiresKey = true, parSeconds = 450, weaponEnabled = true
    ).apply {
        platform(0f, 420f, 680f)
        platform(840f, 520f, 720f)
        platform(1_730f, 430f, 520f)
        platform(2_430f, 340f, 490f)
        platform(3_100f, 500f, 760f)
        platform(4_040f, 410f, 520f)
        platform(4_740f, 320f, 490f)
        platform(5_410f, 480f, 760f)
        platform(6_350f, 390f, 520f)
        platform(7_050f, 550f, 760f)
        platform(7_990f, 460f, 520f)
        platform(8_690f, 370f, 490f)
        platform(9_360f, 530f, 760f)
        platform(10_300f, 440f, 520f)
        platform(11_000f, 560f, 1_100f)
        switch(1_140f, 520f, 1_560f)
        switch(6_760f, 390f, 7_020f)
        barrier(1_590f, 0, y = 280f, height = 340f)
        barrier(7_020f, 1, y = 260f, height = 360f)
        key(8_930f, 370f, hiddenUntilSwitch = 1)
        floorSpikes(2_050f, 430f, phaseMs = 240L)
        ceilingSpikes(4_900f, 135f, phaseMs = 520L)
        fire(5_720f, 480f, phaseMs = 760L)
        wallSpikes(9_180f, 260f, 100f, fromLeft = true, phaseMs = 980L)
        floorSpikes(11_420f, 560f, phaseMs = 1_240L)
        decoy(5_860f, 480f)
        enemy(2_650f, 340f, GameEnemyKind.SHOOTER, speed = 105f)
        enemy(5_980f, 480f, GameEnemyKind.GUARDIAN, speed = 110f)
        enemy(9_680f, 530f, GameEnemyKind.SHOOTER, speed = 108f)
        checkpoint(3_450f, 500f)
        checkpoint(6_650f, 390f)
        checkpoint(9_760f, 530f)
        checkpoint(11_520f, 560f)
        pickup(4_980f, 320f, GamePickupKind.POWER)
    }.build()

    private fun level19(): AdventureLevel = Draft(
        19, "Desierto del amanecer", "La escalera del Acechante", "Asciende sin detenerte mientras el Acechante cierra el camino.", "LEGENDARIO",
        12_400f, AdventureBiome.DESERT_DAWN, LevelExitKind.DOOR, LevelExitKind.SUMMIT, "temple-door", "summit-stairs",
        560f, 300f, parSeconds = 465, acechantePresent = true, weaponEnabled = true
    ).apply {
        platform(0f, 560f, 700f)
        platform(850f, 480f, 500f)
        platform(1_520f, 400f, 480f)
        platform(2_170f, 320f, 470f)
        platform(2_820f, 480f, 720f)
        platform(3_710f, 390f, 520f)
        platform(4_410f, 300f, 490f)
        platform(5_080f, 460f, 760f)
        platform(6_020f, 370f, 520f)
        platform(6_720f, 280f, 490f)
        platform(7_390f, 440f, 760f)
        platform(8_330f, 350f, 520f)
        platform(9_030f, 260f, 490f)
        platform(9_700f, 420f, 760f)
        platform(10_640f, 330f, 520f)
        platform(11_340f, 300f, 1_060f)
        moving(2_640f, 390f, 150f, 95f, true, 2.7f)
        moving(6_520f, 350f, 150f, 95f, true, 2.6f)
        moving(9_500f, 330f, 155f, 105f, true, 2.5f)
        floorSpikes(1_080f, 480f, phaseMs = 220L)
        ceilingSpikes(3_880f, 205f, phaseMs = 480L)
        floorSpikes(5_480f, 460f, phaseMs = 730L)
        wallSpikes(8_800f, 220f, 100f, fromLeft = false, phaseMs = 980L)
        floorSpikes(10_980f, 330f, phaseMs = 1_220L)
        fruit(7_760f, 160f, 440f, FallingBehavior.CHASE)
        enemy(2_360f, 320f, GameEnemyKind.JUMPER, speed = 140f)
        enemy(6_260f, 370f, GameEnemyKind.FLYER, speed = 118f)
        enemy(9_960f, 420f, GameEnemyKind.SHOOTER, speed = 110f)
        checkpoint(2_980f, 480f)
        checkpoint(6_250f, 370f)
        checkpoint(9_950f, 420f)
        checkpoint(11_760f, 300f)
    }.build()

    private fun level20(): AdventureLevel = Draft(
        20, "Desierto del amanecer", "La puerta de la nave", "Supera la ruta final, consigue la llave maestra y abre la nave.", "FINAL",
        12_800f, AdventureBiome.DESERT_DAWN, LevelExitKind.SUMMIT, LevelExitKind.DOOR, "summit-stairs", "adventure-end",
        300f, 500f, requiredMechanisms = 3, requiresKey = true, parSeconds = 490,
        introStory = "En la cima de las ruinas aparece una nave sellada. Todo el planeta parece preparar una última emboscada.",
        outroStory = "GEO abre la nave. Las luces interiores se encienden solas: algo llegó antes. Continuará…",
        companion = "Luma", weaponEnabled = true, acechantePresent = true
    ).apply {
        platform(0f, 300f, 700f)
        platform(860f, 420f, 520f)
        platform(1_560f, 540f, 760f)
        platform(2_500f, 450f, 520f)
        platform(3_200f, 360f, 490f)
        platform(3_870f, 520f, 760f)
        platform(4_810f, 430f, 520f)
        platform(5_510f, 340f, 490f)
        platform(6_180f, 500f, 760f)
        platform(7_120f, 410f, 520f)
        platform(7_820f, 320f, 490f)
        platform(8_490f, 480f, 760f)
        platform(9_430f, 390f, 520f)
        platform(10_130f, 550f, 760f)
        platform(11_070f, 460f, 520f)
        platform(11_770f, 500f, 1_030f)
        switch(1_900f, 540f, 2_320f)
        switch(6_580f, 500f, 6_960f)
        switch(10_520f, 550f, 10_900f)
        barrier(2_340f, 0, y = 280f, height = 340f)
        barrier(6_980f, 1, y = 260f, height = 360f)
        barrier(10_920f, 2, y = 270f, height = 350f)
        key(11_360f, 460f, hiddenUntilSwitch = 2)
        floorSpikes(1_050f, 420f, phaseMs = 180L)
        ceilingSpikes(3_360f, 175f, phaseMs = 390L)
        fire(4_220f, 520f, phaseMs = 610L)
        wallSpikes(5_280f, 225f, 100f, fromLeft = true, phaseMs = 820L)
        floorSpikes(7_500f, 410f, phaseMs = 1_020L)
        ceilingSpikes(8_700f, 295f, phaseMs = 1_200L)
        fire(10_420f, 550f, phaseMs = 1_400L)
        crusher(4_650f, 180f, 155f, 88f, 4_380f, CrusherAxis.VERTICAL, 245f, CrusherStyle.FALLING_WALL, speed = 330f, despawnAfterMs = 3_000L)
        crusher(9_140f, 250f, 55f, 155f, 8_850f, CrusherAxis.HORIZONTAL, -125f, CrusherStyle.STONE_COLUMN, speed = 270f, reverseAfterMs = 1_550L)
        fruit(7_980f, 150f, 480f, FallingBehavior.CHAIN)
        enemy(2_780f, 450f, GameEnemyKind.GUARDIAN, speed = 118f)
        enemy(6_420f, 500f, GameEnemyKind.SHOOTER, speed = 112f)
        enemy(9_720f, 390f, GameEnemyKind.FLYER, speed = 122f)
        enemy(11_220f, 460f, GameEnemyKind.GUARDIAN, speed = 120f)
        checkpoint(3_980f, 520f)
        checkpoint(6_500f, 500f)
        checkpoint(9_760f, 390f)
        checkpoint(11_980f, 500f)
        pickup(8_050f, 320f, GamePickupKind.SHIELD)
        pickup(10_660f, 550f, GamePickupKind.ENERGY)
    }.build()

    private fun AdventureLevel.enhancedTension(): AdventureLevel {
        val safeAnchors = buildList {
            add(spawnX)
            add(goalX)
            checkpoints.filter { it.kind != CheckpointKind.DECOY }.forEach { add(it.x) }
        }
        fun safeZone(x: Float, radius: Float = 210f) = safeAnchors.any { abs(it - x) <= radius }

        val tunedPlatforms = platforms.toMutableList()
        val tunedHazards = hazards.toMutableList()
        val tunedFalling = fallingObjects.toMutableList()
        val tunedEnemies = enemies.toMutableList()

        fun hazardNear(x: Float, radius: Float = 150f) = tunedHazards.any { abs((it.x + it.width / 2f) - x) <= radius }
        fun fallingNear(x: Float, radius: Float = 180f) = tunedFalling.any { abs((it.x + it.size / 2f) - x) <= radius }
        fun enemyNear(x: Float, radius: Float = 140f) = tunedEnemies.any { abs(it.x - x) <= radius }
        fun platformExists(x: Float, y: Float, width: Float, height: Float = 34f): Boolean = tunedPlatforms.any {
            abs(it.x - x) < 8f && abs(it.y - y) < 8f && abs(it.width - width) < 10f && abs(it.height - height) < 10f
        }
        fun spansPoint(x: Float, y: Float, margin: Float = 0f): Boolean = tunedPlatforms.any {
            x in (it.x - margin)..(it.x + it.width + margin) && abs(it.y - y) <= 6f
        }

        platforms.forEachIndexed { index, platform ->
            if (platform.kind != PlatformKind.SOLID || platform.width < 280f) return@forEachIndexed

            val front = platform.x + platform.width * 0.26f
            val mid = platform.x + platform.width * 0.54f
            val rear = platform.x + platform.width * 0.77f
            val corridorRoofY = (platform.y - (165f + (index % 2) * 22f)).coerceAtLeast(125f)
            val corridorRoofX = platform.x + platform.width * 0.14f
            val corridorRoofW = (platform.width * 0.46f).coerceIn(170f, 290f)
            val shouldAddRoof = !safeZone(mid, 250f) && platform.width >= 360f && platform.y >= 420f && (number + index) % 2 == 1

            if (shouldAddRoof && !platformExists(corridorRoofX, corridorRoofY, corridorRoofW)) {
                tunedPlatforms += GamePlatform(
                    x = corridorRoofX,
                    y = corridorRoofY,
                    width = corridorRoofW,
                    height = 34f,
                    kind = PlatformKind.SOLID
                )
                if ((number + index) % 3 != 0 && !hazardNear(corridorRoofX + corridorRoofW * 0.38f, 110f)) {
                    tunedHazards += GameHazard(
                        x = corridorRoofX + corridorRoofW * 0.30f,
                        y = corridorRoofY + 34f,
                        width = 68f,
                        height = 54f,
                        kind = HazardKind.HIDDEN_SPIKES,
                        triggerX = corridorRoofX - 36f,
                        cycleMs = 2_650L,
                        phaseMs = ((number * 140L) + index * 150L) % 1_650L,
                        orientation = HazardOrientation.DOWN,
                        camouflaged = true
                    )
                }
            }

            if ((number + index) % 2 == 0 && !safeZone(front) && !hazardNear(front)) {
                tunedHazards += GameHazard(
                    x = front,
                    y = platform.y - 44f,
                    width = 58f,
                    height = 44f,
                    kind = HazardKind.HIDDEN_SPIKES,
                    triggerX = front - 92f,
                    cycleMs = 2_450L + ((number + index) % 4) * 180L,
                    phaseMs = ((number * 90L) + index * 120L) % 1_400L,
                    orientation = HazardOrientation.UP,
                    camouflaged = true
                )
            }

            if (platform.width >= 430f && !safeZone(mid, 230f) && !fallingNear(mid) && (number + index) % 3 != 0) {
                when (biome) {
                    AdventureBiome.FOREST_DAY, AdventureBiome.FOREST_SUNSET -> {
                        val behavior = when ((number + index) % 4) {
                            0 -> FallingBehavior.ROLL
                            1 -> FallingBehavior.EXPLODE
                            2 -> FallingBehavior.CHAIN
                            else -> FallingBehavior.CHASE
                        }
                        tunedFalling += GameFallingObject(
                            x = mid,
                            startY = (platform.y - 280f).coerceAtLeast(155f),
                            targetY = platform.y,
                            size = 68f,
                            triggerX = mid - 165f,
                            kind = FallingObjectKind.FRUIT,
                            delayMs = 160L,
                            behavior = behavior,
                            rollDirection = if ((number + index) % 2 == 0) 1f else -1f,
                            explosionRadius = 100f,
                            chainCount = if (behavior == FallingBehavior.CHAIN) 4 else 1,
                            chainSpacing = 58f,
                            chaseDurationMs = 5_200L,
                            chaseMaxTravel = 760f,
                            treeFallsAfterTrap = (number + index) % 5 == 0,
                            explosionDelayMs = 760L
                        )
                    }
                    AdventureBiome.UNDERGROUND, AdventureBiome.CAVE_NIGHT, AdventureBiome.DESERT_DAWN -> {
                        tunedFalling += GameFallingObject(
                            x = mid,
                            startY = (platform.y - 235f).coerceAtLeast(145f),
                            targetY = platform.y,
                            size = 74f,
                            triggerX = mid - 150f,
                            kind = FallingObjectKind.ROCK,
                            delayMs = 170L,
                            behavior = FallingBehavior.DROP,
                            becomesPlatform = number >= 14 && (number + index) % 5 == 0
                        )
                    }
                }
            }

            if (platform.width >= 320f && !safeZone(rear) && !enemyNear(rear) && (number + index) % 3 == 1) {
                tunedEnemies += GameEnemy(
                    x = rear,
                    y = platform.y - 55f,
                    range = (85f + (index % 4) * 22f),
                    detectionRange = 460f,
                    health = if (number >= 12) 3 else 2,
                    kind = when {
                        number >= 16 && index % 4 == 0 -> GameEnemyKind.GUARDIAN
                        number >= 11 && index % 3 == 0 -> GameEnemyKind.SHOOTER
                        (number + index) % 4 == 0 -> GameEnemyKind.FLYER
                        (number + index) % 2 == 0 -> GameEnemyKind.JUMPER
                        else -> GameEnemyKind.WALKER
                    },
                    speed = 90f + number * 2f + (index % 3) * 6f
                )
            }

            if (number >= 5 && platform.width >= 340f && !safeZone(rear, 170f) && !hazardNear(rear, 150f) && (number + index) % 5 == 2) {
                val wallBaseY = platform.y - 92f
                if (!spansPoint(rear + 34f, wallBaseY + 34f, 8f)) {
                    tunedPlatforms += GamePlatform(
                        x = rear + 24f,
                        y = wallBaseY,
                        width = 42f,
                        height = 126f,
                        kind = PlatformKind.SOLID
                    )
                }
                tunedHazards += GameHazard(
                    x = rear + 6f,
                    y = platform.y - 96f,
                    width = 48f,
                    height = 92f,
                    kind = HazardKind.HIDDEN_SPIKES,
                    triggerX = rear - 84f,
                    cycleMs = 2_900L,
                    phaseMs = ((number * 95L) + index * 160L) % 1_500L,
                    orientation = HazardOrientation.LEFT,
                    camouflaged = true
                )
            }

            if (number >= 7 && platform.width >= 390f && platform.y > 300f && !safeZone(rear, 190f) && !hazardNear(rear, 170f) && (number + index) % 4 == 0) {
                if (!spansPoint(rear, platform.y - 84f, 20f)) {
                    tunedPlatforms += GamePlatform(
                        x = rear - 24f,
                        y = platform.y - 86f,
                        width = 114f,
                        height = 34f,
                        kind = PlatformKind.SOLID
                    )
                }
                tunedHazards += GameHazard(
                    x = rear,
                    y = platform.y - 52f,
                    width = 66f,
                    height = 54f,
                    kind = HazardKind.HIDDEN_SPIKES,
                    triggerX = rear - 90f,
                    cycleMs = 2_700L,
                    phaseMs = ((number * 110L) + index * 140L) % 1_600L,
                    orientation = HazardOrientation.DOWN,
                    camouflaged = true
                )
            }
        }

        return copy(
            platforms = tunedPlatforms.sortedBy { it.x },
            hazards = tunedHazards.sortedBy { it.x },
            enemies = tunedEnemies.sortedBy { it.x },
            fallingObjects = tunedFalling.sortedBy { it.x }
        )
    }

    fun build(number: Int): AdventureLevel = when (number.coerceIn(1, GeoGameRules.LEVEL_COUNT)) {
        1 -> level1()
        2 -> level2()
        3 -> level3()
        4 -> level4()
        5 -> level5()
        6 -> level6()
        7 -> level7()
        8 -> level8()
        9 -> level9()
        10 -> level10()
        11 -> level11()
        12 -> level12()
        13 -> level13()
        14 -> level14()
        15 -> level15()
        16 -> level16()
        17 -> level17()
        18 -> level18()
        19 -> level19()
        else -> level20()
    }.enhancedTension()
}
