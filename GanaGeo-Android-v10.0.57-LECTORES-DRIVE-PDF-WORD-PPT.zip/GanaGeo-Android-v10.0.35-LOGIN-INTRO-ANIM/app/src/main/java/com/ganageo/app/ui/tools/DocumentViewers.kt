package com.ganageo.app.ui.tools

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer as AndroidPdfRenderer
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.rendering.PDFRenderer as PdfBoxRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Xml
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.InvertColors
import androidx.compose.material.icons.rounded.NavigateBefore
import androidx.compose.material.icons.rounded.NavigateNext
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign

@Composable
fun PdfViewerScreen(
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val horizontalScrollState = rememberScrollState()
    var uriText by rememberSaveable { mutableStateOf<String?>(null) }
    val uri = uriText?.let(Uri::parse)
    var pageCount by rememberSaveable { mutableIntStateOf(0) }
    var loadingDocument by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var localPdfPath by remember { mutableStateOf<String?>(null) }
    var pdfEngine by remember { mutableStateOf<PdfRenderEngine?>(null) }
    var retryToken by remember { mutableIntStateOf(0) }
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    var showOverview by rememberSaveable { mutableStateOf(false) }
    var zoomInteracted by remember { mutableStateOf(false) }
    var zoomBadgeVisible by remember { mutableStateOf(false) }

    LaunchedEffect(zoom) {
        if (zoomInteracted) {
            zoomBadgeVisible = true
            kotlinx.coroutines.delay(700L)
            zoomBadgeVisible = false
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selected,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            localPdfPath?.let { runCatching { File(it).delete() } }
            localPdfPath = null
            pdfEngine = null
            loadingDocument = true
            uriText = selected.toString()
            pageCount = 0
            loadError = null
            zoom = 1f
            showOverview = false
        }
    }

    LaunchedEffect(uriText, retryToken) {
        val selected = uri ?: run {
            pageCount = 0
            loadError = null
            localPdfPath = null
            pdfEngine = null
            onImmersiveChanged(false)
            return@LaunchedEffect
        }
        onImmersiveChanged(true)
        horizontalScrollState.scrollTo(0)
        listState.scrollToItem(0)
        loadingDocument = true
        loadError = null
        pageCount = 0

        val previousPath = localPdfPath
        val result = runCatching {
            PDFBoxResourceLoader.init(context.applicationContext)

            // Primero intentamos abrir exactamente el URI que entrega Android. Algunos
            // proveedores permiten PdfRenderer pero no permiten copiar el archivo con un
            // InputStream normal. La versión anterior copiaba antes de probar el URI y por
            // eso podía rechazar un PDF que Drive abría sin problemas.
            val directCount = runCatching { ToolFileUtils.pdfPageCount(context, selected) }
                .getOrNull()
                ?.takeIf { it > 0 }

            if (directCount != null) {
                // La copia local es solo una optimización/fallback. Si el proveedor no deja
                // copiar, el visor sigue funcionando directamente desde content://.
                val optionalCopy = runCatching { copyPdfToViewerCache(context, selected) }.getOrNull()
                Triple(optionalCopy, directCount, PdfRenderEngine.ANDROID)
            } else {
                // Si PdfRenderer no entiende el URI, hacemos una copia local y probamos
                // Android PdfRenderer y después PDFBox como segundo motor.
                val copy = copyPdfToViewerCache(context, selected)
                val openInfo = detectLocalPdf(copy)
                require(openInfo.pageCount > 0) { "El PDF no contiene páginas." }
                Triple(copy, openInfo.pageCount, openInfo.engine)
            }
        }

        result.onSuccess { (copy, count, engine) ->
            previousPath?.takeIf { it != copy?.absolutePath }?.let { runCatching { File(it).delete() } }
            localPdfPath = copy?.absolutePath
            pdfEngine = engine
            pageCount = count
        }.onFailure { error ->
            localPdfPath = null
            pdfEngine = null
            pageCount = 0
            loadError = when {
                error.message?.contains("password", ignoreCase = true) == true ->
                    "Este PDF está protegido y Android no pudo abrirlo."
                else -> error.message ?: "No se pudo abrir este PDF."
            }
        }
        loadingDocument = false
    }


    DisposableEffect(Unit) {
        onDispose {
            onImmersiveChanged(false)
            localPdfPath?.let { path -> runCatching { File(path).delete() } }
        }
    }

    if (uri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Visor gratuito · el archivo no se modifica", onBack)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Ningún PDF seleccionado", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { launcher.launch(arrayOf("application/pdf")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                        Text(" Abrir PDF")
                    }
                }
            }
        }
        return
    }

    val fileName = remember(uriText) { ToolFileUtils.displayName(context, uri) }
    val currentPage by remember {
        derivedStateOf {
            if (pageCount <= 0) 0
            else (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding(),
            color = Color(0xFF202124),
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = Color.White)
                }
                Text(
                    fileName,
                    modifier = Modifier.weight(1f),
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = { shareDocumentFile(context, uri, "application/pdf") }) {
                    Icon(Icons.Rounded.Share, contentDescription = "Compartir PDF", tint = Color.White)
                }
                IconButton(onClick = { launcher.launch(arrayOf("application/pdf")) }) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = "Cambiar PDF", tint = Color.White)
                }
            }
        }

        if (loadingDocument) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = NeonGreen)
                    Spacer(Modifier.height(14.dp))
                    Text("Abriendo PDF…", color = Color.White.copy(alpha = 0.78f))
                }
            }
        } else if (loadError != null || pageCount <= 0 || pdfEngine == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF202124)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("No se pudo abrir el PDF", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(
                            loadError ?: "El archivo no contiene páginas compatibles.",
                            color = Color.White.copy(alpha = 0.72f)
                        )
                        OutlinedButton(onClick = { retryToken++ }, modifier = Modifier.fillMaxWidth()) {
                            Text("Reintentar")
                        }
                        OutlinedButton(
                            onClick = { launcher.launch(arrayOf("application/pdf")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                            Text(" Elegir otro PDF")
                        }
                    }
                }
            }
        } else {
            DrivePagedSurface(
                viewerKey = "pdf_${uriText.orEmpty()}",
                pageCount = pageCount,
                background = Color(0xFF121212),
                minZoom = 0.18f,
                maxZoom = 5f,
                onCurrentPageChanged = {},
                pageContent = { index, renderWidth, pageWidth ->
                    ContinuousPdfPage(
                        uri = uri,
                        localPdfPath = localPdfPath,
                        engine = pdfEngine!!,
                        pageIndex = index,
                        renderWidth = renderWidth,
                        modifier = Modifier.width(pageWidth),
                        onMessage = onMessage
                    )
                }
            )
        }
    }
}

@Composable
private fun PdfGridGlyph() {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(3) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                repeat(3) {
                    Box(
                        modifier = Modifier
                            .size(3.dp)
                            .background(Color(0xFF5F6368), RoundedCornerShape(1.dp))
                    )
                }
            }
        }
    }
}

@Composable
private fun ViewerSideCounter(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color.White.copy(alpha = 0.94f),
        contentColor = Color(0xFF303134),
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 3.dp
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun ViewerZoomBadge(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color(0xE6323440),
        contentColor = Color.White,
        shape = RoundedCornerShape(18.dp),
        shadowElevation = 3.dp
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelMedium
        )
    }
}


/**
 * Visor paginado inspirado en el comportamiento del lector de Drive.
 *
 * Las páginas se mantienen como superficies completas: el gesto de zoom cambia el ancho
 * de la superficie, no el tamaño individual del texto. El control derecho permite saltar
 * rápidamente por documentos largos sin renderizar todas las páginas a la vez.
 */
@Composable
private fun DrivePagedSurface(
    viewerKey: String,
    pageCount: Int,
    background: Color,
    resetViewToken: Int = 0,
    jumpToPage: Int? = null,
    jumpRequestKey: Any? = null,
    minZoom: Float = 0.20f,
    maxZoom: Float = 5f,
    onCurrentPageChanged: (Int) -> Unit = {},
    onTap: () -> Unit = {},
    pageContent: @Composable (pageIndex: Int, renderWidth: Int, pageWidth: androidx.compose.ui.unit.Dp) -> Unit
) {
    val listState = rememberLazyListState()
    val horizontalState = rememberScrollState()
    val scope = rememberCoroutineScope()
    var zoom by rememberSaveable(viewerKey) { mutableFloatStateOf(1f) }
    var zoomInteracted by remember { mutableStateOf(false) }
    var zoomBadgeVisible by remember { mutableStateOf(false) }
    var scrubbing by remember { mutableStateOf(false) }
    var scrubPage by remember { mutableIntStateOf(0) }

    val currentPageIndex by remember(pageCount) {
        derivedStateOf {
            if (pageCount <= 0) 0
            else listState.firstVisibleItemIndex.coerceIn(0, pageCount - 1)
        }
    }

    LaunchedEffect(currentPageIndex, pageCount) {
        if (pageCount > 0) onCurrentPageChanged(currentPageIndex)
    }

    LaunchedEffect(resetViewToken) {
        zoom = 1f
        horizontalState.scrollTo(0)
    }

    LaunchedEffect(jumpRequestKey, jumpToPage, pageCount) {
        val target = jumpToPage
        if (target != null && pageCount > 0) {
            listState.animateScrollToItem(target.coerceIn(0, pageCount - 1))
        }
    }

    LaunchedEffect(zoom) {
        if (zoomInteracted) {
            zoomBadgeVisible = true
            kotlinx.coroutines.delay(650L)
            zoomBadgeVisible = false
        }
    }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(background)
    ) {
        if (pageCount <= 0) return@BoxWithConstraints

        val basePageWidth = (maxWidth - 8.dp).coerceAtLeast(180.dp)
        val pageWidth = basePageWidth * zoom
        val contentWidth = if (pageWidth < maxWidth) maxWidth else pageWidth
        val renderWidth = when {
            zoom >= 3.2f -> 3000
            zoom >= 2.1f -> 2500
            zoom >= 1.35f -> 1900
            zoom >= 0.75f -> 1400
            zoom >= 0.40f -> 1000
            else -> 700
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(viewerKey) {
                    awaitEachGesture {
                        do {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.filter { it.pressed }
                            if (pressed.size >= 2) {
                                zoomInteracted = true
                                val oldZoom = zoom
                                val newZoom = (oldZoom * event.calculateZoom()).coerceIn(minZoom, maxZoom)
                                val pan = event.calculatePan()
                                zoom = newZoom

                                if (newZoom <= 1.01f) {
                                    horizontalState.dispatchRawDelta(-horizontalState.value.toFloat())
                                } else if (pan.x != 0f) {
                                    horizontalState.dispatchRawDelta(-pan.x)
                                }
                                if (pan.y != 0f) listState.dispatchRawDelta(-pan.y)
                                event.changes.forEach { it.consume() }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
                .pointerInput(viewerKey) {
                    detectTapGestures(
                        onTap = { onTap() },
                        onDoubleTap = {
                            zoomInteracted = true
                            zoom = if (zoom > 1.12f) 1f else 2f
                            scope.launch {
                                kotlinx.coroutines.yield()
                                if (zoom <= 1f) horizontalState.animateScrollTo(0)
                            }
                        }
                    )
                }
                .horizontalScroll(horizontalState)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.width(contentWidth).fillMaxHeight(),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                items(
                    count = pageCount,
                    key = { index -> "${viewerKey}_page_$index" },
                    contentType = { "drive_page" }
                ) { index ->
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        pageContent(index, renderWidth, pageWidth)
                    }
                }
            }
        }

        val shownPage = if (scrubbing) scrubPage else currentPageIndex
        val progress = if (pageCount <= 1) 0f else shownPage.toFloat() / (pageCount - 1).toFloat()

        BoxWithConstraints(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(82.dp)
                .padding(top = 8.dp, bottom = 10.dp)
        ) {
            val handleHeight = 44.dp
            val travel = (maxHeight - handleHeight).coerceAtLeast(0.dp)

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(pageCount) {
                        fun pageForY(y: Float): Int {
                            if (pageCount <= 1 || size.height <= 0) return 0
                            val fraction = (y / size.height.toFloat()).coerceIn(0f, 1f)
                            return (fraction * (pageCount - 1)).roundToInt().coerceIn(0, pageCount - 1)
                        }
                        fun jump(y: Float) {
                            val target = pageForY(y)
                            scrubPage = target
                            scope.launch { listState.scrollToItem(target) }
                        }
                        detectVerticalDragGestures(
                            onDragStart = { offset ->
                                scrubbing = true
                                jump(offset.y)
                            },
                            onVerticalDrag = { change, _ ->
                                change.consume()
                                jump(change.position.y)
                            },
                            onDragEnd = { scrubbing = false },
                            onDragCancel = { scrubbing = false }
                        )
                    }
            )

            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(y = travel * progress)
                    .height(handleHeight)
                    .padding(end = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    color = Color.White.copy(alpha = 0.96f),
                    contentColor = Color(0xFF303134),
                    shape = RoundedCornerShape(16.dp),
                    shadowElevation = 3.dp
                ) {
                    Text(
                        text = "${shownPage + 1}/$pageCount",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Surface(
                    modifier = Modifier.width(23.dp).height(handleHeight),
                    color = Color.White.copy(alpha = 0.96f),
                    shape = RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp),
                    shadowElevation = 3.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        repeat(3) {
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                repeat(2) {
                                    Box(
                                        Modifier.size(2.5.dp)
                                            .background(Color(0xFF5F6368), RoundedCornerShape(2.dp))
                                    )
                                }
                            }
                            if (it < 2) Spacer(Modifier.height(2.dp))
                        }
                    }
                }
            }
        }

        if (zoomBadgeVisible) {
            ViewerZoomBadge(
                text = "${(zoom * 100f).roundToInt()}%",
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
            )
        }
    }
}

@Composable
private fun PdfOverview(
    uri: Uri,
    localPdfPath: String?,
    engine: PdfRenderEngine,
    pageCount: Int,
    onSelectPage: (Int) -> Unit,
    onMessage: (String) -> Unit
) {
    val rowCount = (pageCount + 2) / 3
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF171717)),
        contentPadding = PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(count = rowCount, key = { "pdf_overview_row_$it" }) { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                repeat(3) { column ->
                    val pageIndex = row * 3 + column
                    if (pageIndex < pageCount) {
                        PdfThumbnail(
                            uri = uri,
                            localPdfPath = localPdfPath,
                            engine = engine,
                            pageIndex = pageIndex,
                            modifier = Modifier.weight(1f),
                            onClick = { onSelectPage(pageIndex) },
                            onMessage = onMessage
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfThumbnail(
    uri: Uri,
    localPdfPath: String?,
    engine: PdfRenderEngine,
    pageIndex: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var bitmap by remember(localPdfPath, pageIndex) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(localPdfPath, pageIndex) {
        runCatching {
            if (localPdfPath != null) {
                renderLocalPdfPage(File(localPdfPath), pageIndex, maxWidth = 360, engine = engine)
            } else {
                ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = 360)
            }
        }.recoverCatching {
            ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = 360)
        }.onSuccess { fresh ->
            val previous = bitmap
            bitmap = fresh
            previous?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure {
            onMessage(it.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
        }
    }

    DisposableEffect(localPdfPath, pageIndex) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    Column(
        modifier = modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            val current = bitmap
            if (current != null) {
                Image(
                    bitmap = current.asImageBitmap(),
                    contentDescription = "Página ${pageIndex + 1}",
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = NeonGreen,
                        strokeWidth = 2.dp
                    )
                }
            }
        }
        Text(
            "${pageIndex + 1}",
            color = Color.White.copy(alpha = 0.78f),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun ContinuousPdfPage(
    uri: Uri,
    localPdfPath: String?,
    engine: PdfRenderEngine,
    pageIndex: Int,
    renderWidth: Int,
    modifier: Modifier = Modifier,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var bitmap by remember(uri, localPdfPath, pageIndex) { mutableStateOf<Bitmap?>(null) }
    var loading by remember(uri, localPdfPath, pageIndex) { mutableStateOf(true) }

    LaunchedEffect(uri, localPdfPath, pageIndex, renderWidth) {
        loading = true
        runCatching {
            // Si existe una copia local se usa primero: evita abrir el proveedor de archivos
            // en cada página durante el scroll. Si no existe, se renderiza directamente desde
            // el URI original, que es importante para proveedores que no permiten copiar.
            if (localPdfPath != null) {
                renderLocalPdfPage(File(localPdfPath), pageIndex, maxWidth = renderWidth, engine = engine)
            } else {
                ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = renderWidth)
            }
        }.recoverCatching {
            ToolFileUtils.renderPdfPage(context, uri, pageIndex, maxWidth = renderWidth)
        }.onSuccess { fresh ->
            val previous = bitmap
            bitmap = fresh
            previous?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure {
            onMessage(it.message ?: "No se pudo mostrar la página ${pageIndex + 1}.")
        }
        loading = false
    }

    DisposableEffect(uri, localPdfPath, pageIndex) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    val current = bitmap
    val pageRatio = current?.let { image ->
        image.width.toFloat() / image.height.toFloat().coerceAtLeast(1f)
    } ?: 0.7071f
    Box(
        modifier = modifier
            .aspectRatio(pageRatio)
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = "Página ${pageIndex + 1}",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize().background(Color.White)
            )
        } else if (loading) {
            CircularProgressIndicator(color = NeonGreen)
        }
    }
}


private suspend fun copyPdfToViewerCache(context: android.content.Context, source: Uri): File =
    withContext(Dispatchers.IO) {
        val directory = File(context.cacheDir, "pdf_viewer").apply { mkdirs() }
        directory.listFiles()?.forEach { old ->
            if (System.currentTimeMillis() - old.lastModified() > 6 * 60 * 60 * 1000L) {
                runCatching { old.delete() }
            }
        }
        val file = File(directory, "viewer_${System.currentTimeMillis()}_${kotlin.random.Random.nextInt(1000, 9999)}.pdf")
        try {
            val copiedFromDescriptor = runCatching {
                context.contentResolver.openFileDescriptor(source, "r")?.use { descriptor ->
                    java.io.FileInputStream(descriptor.fileDescriptor).use { input ->
                        FileOutputStream(file).use { output -> input.copyTo(output, bufferSize = 256 * 1024) }
                    }
                    true
                } ?: false
            }.getOrDefault(false)

            if (!copiedFromDescriptor || file.length() <= 0L) {
                runCatching { file.delete() }
                context.contentResolver.openInputStream(source)?.use { input ->
                    FileOutputStream(file).use { output -> input.copyTo(output, bufferSize = 256 * 1024) }
                } ?: error("No se pudo leer el archivo seleccionado.")
            }
            require(file.length() > 0L) { "El archivo PDF está vacío." }
            file
        } catch (error: Throwable) {
            runCatching { file.delete() }
            throw error
        }
    }

private enum class PdfRenderEngine { ANDROID, PDFBOX }
private data class PdfOpenInfo(val engine: PdfRenderEngine, val pageCount: Int)

private suspend fun detectLocalPdf(file: File): PdfOpenInfo = withContext(Dispatchers.IO) {
    require(file.exists() && file.length() > 0L) { "El PDF no está disponible." }

    val androidResult = runCatching {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            AndroidPdfRenderer(descriptor).use { renderer ->
                require(renderer.pageCount > 0) { "El PDF no contiene páginas." }
                PdfOpenInfo(PdfRenderEngine.ANDROID, renderer.pageCount)
            }
        }
    }
    androidResult.getOrNull()?.let { return@withContext it }

    val pdfBoxResult = runCatching {
        PDDocument.load(file).use { document ->
            require(document.numberOfPages > 0) { "El PDF no contiene páginas." }
            PdfOpenInfo(PdfRenderEngine.PDFBOX, document.numberOfPages)
        }
    }
    pdfBoxResult.getOrElse { fallbackError ->
        val androidMessage = androidResult.exceptionOrNull()?.message.orEmpty()
        val fallbackMessage = fallbackError.message.orEmpty()
        error(
            listOf(androidMessage, fallbackMessage)
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString(" · ")
                .ifBlank { "Android no pudo interpretar este PDF." }
        )
    }
}

private suspend fun renderLocalPdfPage(
    file: File,
    pageIndex: Int,
    maxWidth: Int,
    engine: PdfRenderEngine
): Bitmap = withContext(Dispatchers.IO) {
    require(file.exists() && file.length() > 0L) { "El PDF no está disponible." }

    fun renderWithAndroid(): Bitmap {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            AndroidPdfRenderer(descriptor).use { renderer ->
                require(renderer.pageCount > 0) { "El PDF no contiene páginas." }
                require(pageIndex in 0 until renderer.pageCount) { "La página indicada no existe." }
                renderer.openPage(pageIndex).use { page ->
                    var width = min(maxWidth, page.width * 2).coerceAtLeast(240)
                    var height = (width.toFloat() / page.width.toFloat() * page.height.toFloat())
                        .roundToInt()
                        .coerceAtLeast(240)
                    val pixels = width.toLong() * height.toLong()
                    val maxPixels = 8_000_000L
                    if (pixels > maxPixels) {
                        val scale = sqrt(maxPixels.toDouble() / pixels.toDouble()).toFloat()
                        width = (width * scale).roundToInt().coerceAtLeast(1)
                        height = (height * scale).roundToInt().coerceAtLeast(1)
                    }
                    return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
                        eraseColor(AndroidColor.WHITE)
                        page.render(this, null, null, AndroidPdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    }
                }
            }
        }
    }

    fun renderWithPdfBox(): Bitmap {
        PDDocument.load(file).use { document ->
            require(pageIndex in 0 until document.numberOfPages) { "La página indicada no existe." }
            val page = document.getPage(pageIndex)
            val pageWidth = page.cropBox.width.coerceAtLeast(1f)
            val scale = (maxWidth.toFloat() / pageWidth).coerceIn(0.5f, 4f)
            val bitmap = PdfBoxRenderer(document).renderImage(pageIndex, scale)
            val pixels = bitmap.width.toLong() * bitmap.height.toLong()
            if (pixels <= 8_000_000L) return bitmap
            val reduce = sqrt(8_000_000.0 / pixels.toDouble()).toFloat()
            val targetWidth = (bitmap.width * reduce).roundToInt().coerceAtLeast(1)
            val targetHeight = (bitmap.height * reduce).roundToInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
            if (scaled !== bitmap && !bitmap.isRecycled) bitmap.recycle()
            return scaled
        }
    }

    when (engine) {
        PdfRenderEngine.ANDROID -> runCatching { renderWithAndroid() }.getOrElse { renderWithPdfBox() }
        PdfRenderEngine.PDFBOX -> renderWithPdfBox()
    }
}

enum class OfficeViewerType(val label: String, val extensions: String, val mimeTypes: Array<String>) {
    WORD("Word", "DOCX", arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")),
    EXCEL("Excel", "XLSX", arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")),
    POWERPOINT("PowerPoint", "PPTX", arrayOf("application/vnd.openxmlformats-officedocument.presentationml.presentation"))
}

private sealed interface OfficeDocumentModel

private data class WordDocumentModel(val pages: List<WordPageModel>) : OfficeDocumentModel
private data class WordPageModel(val blocks: List<WordBlockModel>)
private sealed interface WordBlockModel {
    data class Paragraph(val text: String) : WordBlockModel
    data class Picture(val entryName: String) : WordBlockModel
    data class Table(val rows: List<List<String>>) : WordBlockModel
}

private data class ExcelWorkbookModel(
    val sharedStrings: List<String>,
    val sheets: List<ExcelSheetRef>,
    val styles: List<ExcelCellStyleModel>
) : OfficeDocumentModel
private data class ExcelSheetRef(val name: String, val entryName: String)
private data class ExcelSheetData(
    val rows: Map<Int, ExcelRowData>,
    val maxColumns: Int,
    val maxRows: Int,
    val columnWidths: Map<Int, Float>,
    val totalRowsHint: Int = maxRows,
    val isComplete: Boolean = true
)
private data class ExcelRowData(
    val rowNumber: Int,
    val cells: Map<Int, ExcelCellData>,
    val heightPoints: Float? = null
)
private data class ExcelCellData(val value: String, val styleIndex: Int)
private data class ExcelCellStyleModel(
    val fillArgb: Int? = null,
    val textArgb: Int? = null,
    val bold: Boolean = false,
    val fontSizePt: Float? = null,
    val horizontal: String? = null,
    val numberFormatCode: String? = null
)

private data class PowerPointDeckModel(
    val widthEmu: Long,
    val heightEmu: Long,
    val slides: List<PowerPointSlideModel>
) : OfficeDocumentModel
private data class PowerPointSlideModel(
    val elements: List<PowerPointElementModel>,
    val transition: String?,
    val advanceAfterMs: Long?,
    val backgroundArgb: Int? = null
)
private sealed interface PowerPointElementModel {
    val x: Long
    val y: Long
    val width: Long
    val height: Long

    data class TextBox(
        val text: String,
        val textArgb: Int?,
        val fontSizePt: Float?,
        val bold: Boolean,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel

    data class Rectangle(
        val fillArgb: Int,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel

    data class Picture(
        val entryName: String,
        override val x: Long,
        override val y: Long,
        override val width: Long,
        override val height: Long
    ) : PowerPointElementModel
}

@Composable
fun OfficeViewerScreen(
    tool: ToolId,
    type: OfficeViewerType,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    var uriText by rememberSaveable { mutableStateOf<String?>(null) }
    val uri = uriText?.let(Uri::parse)
    var localPath by remember { mutableStateOf<String?>(null) }
    var model by remember { mutableStateOf<OfficeDocumentModel?>(null) }
    var loading by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var retryToken by remember { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var searchVisible by rememberSaveable { mutableStateOf(false) }
    var inverted by rememberSaveable { mutableStateOf(false) }
    var presenting by rememberSaveable { mutableStateOf(false) }
    var presentationStart by rememberSaveable { mutableIntStateOf(0) }
    var powerPointCurrentSlide by rememberSaveable { mutableIntStateOf(0) }
    var resetViewToken by remember { mutableIntStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { selected ->
        if (selected != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    selected,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            localPath?.let { runCatching { File(it).delete() } }
            localPath = null
            model = null
            loading = true
            loadError = null
            query = ""
            presenting = false
            powerPointCurrentSlide = 0
            uriText = selected.toString()
        }
    }

    LaunchedEffect(uriText, retryToken) {
        val selected = uri ?: run {
            onImmersiveChanged(false)
            return@LaunchedEffect
        }
        onImmersiveChanged(true)
        loading = true
        loadError = null
        model = null
        val previous = localPath
        val result = runCatching {
            val copy = copyOfficeToViewerCache(context, selected, type)
            val parsed = withContext(Dispatchers.IO) {
                when (type) {
                    OfficeViewerType.WORD -> parseDocxModel(copy)
                    OfficeViewerType.EXCEL -> parseXlsxWorkbook(copy)
                    OfficeViewerType.POWERPOINT -> parsePptxDeck(copy)
                }
            }
            copy to parsed
        }
        result.onSuccess { (copy, parsed) ->
            previous?.takeIf { it != copy.absolutePath }?.let { runCatching { File(it).delete() } }
            localPath = copy.absolutePath
            model = parsed
        }.onFailure { error ->
            localPath = null
            model = null
            loadError = error.message ?: "No se pudo abrir el archivo ${type.extensions}."
        }
        loading = false
    }

    DisposableEffect(Unit) {
        onDispose {
            onImmersiveChanged(false)
            localPath?.let { runCatching { File(it).delete() } }
        }
    }

    androidx.activity.compose.BackHandler(enabled = presenting) { presenting = false }

    if (uri == null) {
        Column(Modifier.fillMaxSize()) {
            ToolHeader(tool.title, "Visor gratuito ${type.extensions} · sin edición", onBack)
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Ningún archivo seleccionado", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { launcher.launch(type.mimeTypes) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                        Text(" Abrir ${type.label}")
                    }
                    Text(
                        when (type) {
                            OfficeViewerType.WORD -> "Vista por páginas, zoom, búsqueda e invertir colores."
                            OfficeViewerType.EXCEL -> "Hojas, cuadrícula, zoom, búsqueda e invertir colores."
                            OfficeViewerType.POWERPOINT -> "Diapositivas, zoom, búsqueda, invertir colores y modo Presentar."
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        return
    }

    val fileName = remember(uriText) { ToolFileUtils.displayName(context, uri) }
    val path = localPath
    val currentModel = model

    if (presenting && type == OfficeViewerType.POWERPOINT && path != null && currentModel is PowerPointDeckModel) {
        PowerPointPresentation(
            localPath = path,
            deck = currentModel,
            initialSlide = presentationStart,
            inverted = inverted,
            onExit = { presenting = false }
        )
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF121212))
    ) {
        OfficeViewerTopBar(
            fileName = fileName,
            type = type,
            onBack = onBack,
            onOpen = { launcher.launch(type.mimeTypes) }
        )

        if (searchVisible) {
            ViewerSearchBar(
                query = query,
                onQueryChange = { query = it.take(120) },
                onClose = { query = ""; searchVisible = false }
            )
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when {
                loading -> ViewerLoading("Abriendo ${type.label}…")
                loadError != null || path == null || currentModel == null -> ViewerLoadError(
                    message = loadError ?: "No se pudo leer el archivo.",
                    onRetry = { retryToken++ },
                    onChooseOther = { launcher.launch(type.mimeTypes) }
                )
                type == OfficeViewerType.WORD && currentModel is WordDocumentModel -> WordDocumentViewer(
                    localPath = path,
                    document = currentModel,
                    query = query,
                    inverted = inverted,
                    resetViewToken = resetViewToken,
                    onMessage = onMessage
                )
                type == OfficeViewerType.EXCEL && currentModel is ExcelWorkbookModel -> ExcelWorkbookViewer(
                    localPath = path,
                    workbook = currentModel,
                    query = query,
                    inverted = inverted,
                    onMessage = onMessage
                )
                type == OfficeViewerType.POWERPOINT && currentModel is PowerPointDeckModel -> PowerPointDeckViewer(
                    localPath = path,
                    deck = currentModel,
                    query = query,
                    inverted = inverted,
                    onMessage = onMessage,
                    onCurrentSlideChanged = { powerPointCurrentSlide = it }
                )
            }
        }

        OfficeViewerBottomBar(
            type = type,
            inverted = inverted,
            onOpen = { launcher.launch(type.mimeTypes) },
            onSearch = { searchVisible = !searchVisible },
            onInvert = { inverted = !inverted },
            onShare = { shareDocumentFile(context, uri, type.mimeTypes.first()) },
            onResetView = { resetViewToken++ },
            onPresent = if (type == OfficeViewerType.POWERPOINT && currentModel is PowerPointDeckModel) {
                { presentationStart = powerPointCurrentSlide; presenting = true }
            } else null
        )
    }
}

@Composable
private fun OfficeViewerTopBar(
    fileName: String,
    type: OfficeViewerType,
    onBack: () -> Unit,
    onOpen: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth().statusBarsPadding(),
        color = Color(0xFF202124),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(54.dp).padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Volver", tint = Color.White)
            }
            Text(
                fileName,
                modifier = Modifier.weight(1f),
                color = Color.White,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = onOpen) {
                Icon(Icons.Rounded.FolderOpen, contentDescription = "Cambiar ${type.label}", tint = Color.White)
            }
        }
    }
}

@Composable
private fun OfficeViewerBottomBar(
    type: OfficeViewerType,
    inverted: Boolean,
    onOpen: () -> Unit,
    onSearch: () -> Unit,
    onInvert: () -> Unit,
    onShare: () -> Unit,
    onResetView: () -> Unit,
    onPresent: (() -> Unit)?
) {
    Surface(
        modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
        color = Color(0xFF202124),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            when (type) {
                OfficeViewerType.WORD -> {
                    ViewerBottomAction(
                        icon = Icons.Rounded.ViewAgenda,
                        label = "Vertical",
                        selected = true,
                        onClick = onResetView
                    )
                }
                OfficeViewerType.EXCEL -> Unit
                OfficeViewerType.POWERPOINT -> if (onPresent != null) {
                    ViewerBottomAction(
                        icon = Icons.Rounded.Slideshow,
                        label = "Presentar",
                        selected = false,
                        onClick = onPresent
                    )
                }
            }
            ViewerBottomAction(Icons.Rounded.Search, "Buscar", false, onSearch)
            ViewerBottomAction(Icons.Rounded.InvertColors, "Invertir", inverted, onInvert)
            ViewerBottomAction(Icons.Rounded.Share, "Compartir", false, onShare)
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.ViewerBottomAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier.weight(1f).fillMaxHeight().clickable(onClick = onClick).padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (selected) NeonGreen else Color.White.copy(alpha = 0.88f),
            modifier = Modifier.size(20.dp)
        )
        Text(
            label,
            color = if (selected) NeonGreen else Color.White.copy(alpha = 0.82f),
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1
        )
    }
}

@Composable
private fun ViewerSearchBar(query: String, onQueryChange: (String) -> Unit, onClose: () -> Unit) {
    Surface(color = Color(0xFF292A2D), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Buscar en el archivo") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = "Cerrar búsqueda", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ViewerLoading(label: String) {
    Box(Modifier.fillMaxSize().background(Color(0xFF121212)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = NeonGreen)
            Spacer(Modifier.height(12.dp))
            Text(label, color = Color.White.copy(alpha = 0.78f))
        }
    }
}

@Composable
private fun ViewerLoadError(message: String, onRetry: () -> Unit, onChooseOther: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xFF121212)).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202124)), shape = RoundedCornerShape(20.dp)) {
            Column(
                Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("No se pudo abrir el archivo", color = Color.White, fontWeight = FontWeight.Bold)
                Text(message, color = Color.White.copy(alpha = 0.72f))
                OutlinedButton(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text("Reintentar") }
                OutlinedButton(onClick = onChooseOther, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                    Text(" Elegir otro archivo")
                }
            }
        }
    }
}

@Composable
private fun WordDocumentViewer(
    localPath: String,
    document: WordDocumentModel,
    query: String,
    inverted: Boolean,
    resetViewToken: Int,
    onMessage: (String) -> Unit
) {
    val matchingPages = remember(document, query) {
        if (query.isBlank()) emptySet()
        else document.pages.mapIndexedNotNull { index, page ->
            if (page.blocks.any { block -> wordBlockContains(block, query) }) index else null
        }.toSet()
    }
    val jumpTarget = matchingPages.minOrNull()

    DrivePagedSurface(
        viewerKey = "word_$localPath",
        pageCount = document.pages.size,
        background = if (inverted) Color.Black else Color(0xFF303030),
        resetViewToken = resetViewToken,
        jumpToPage = jumpTarget,
        jumpRequestKey = query,
        minZoom = 0.20f,
        maxZoom = 5f,
        pageContent = { index, renderWidth, pageWidth ->
            WordRenderedPage(
                localPath = localPath,
                page = document.pages[index],
                inverted = inverted,
                matched = index in matchingPages,
                renderWidth = renderWidth,
                modifier = Modifier.width(pageWidth),
                onMessage = onMessage
            )
        }
    )
}

@Composable
private fun WordPageCard(
    localPath: String,
    page: WordPageModel,
    inverted: Boolean,
    matched: Boolean,
    modifier: Modifier = Modifier,
    onMessage: (String) -> Unit
) {
    val pageColor = if (inverted) Color(0xFF111111) else Color.White
    val textColor = if (inverted) Color(0xFFF1F1F1) else Color(0xFF181818)
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(1.dp))
            .background(pageColor)
            .then(if (matched) Modifier.border(2.dp, NeonGreen) else Modifier)
            .padding(horizontal = 26.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        page.blocks.forEach { block ->
            when (block) {
                is WordBlockModel.Paragraph -> if (block.text.isNotBlank()) {
                    Text(
                        block.text,
                        color = textColor,
                        fontSize = 10.5.sp,
                        lineHeight = 14.2.sp
                    )
                }
                is WordBlockModel.Picture -> OfficeZipImage(
                    localPath = localPath,
                    entryName = block.entryName,
                    inverted = inverted,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 210.dp),
                    onMessage = onMessage
                )
                is WordBlockModel.Table -> WordTableBlock(block, inverted)
            }
        }
    }
}

@Composable
private fun WordTableBlock(table: WordBlockModel.Table, inverted: Boolean) {
    val fg = if (inverted) Color(0xFFF1F1F1) else Color(0xFF202124)
    val grid = if (inverted) Color(0xFF686868) else Color(0xFFB7B7B7)
    Column(Modifier.fillMaxWidth().border(0.7.dp, grid)) {
        table.rows.take(20).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                if (row.isEmpty()) {
                    Box(Modifier.weight(1f).height(24.dp).border(0.5.dp, grid))
                } else {
                    row.forEach { cell ->
                        Box(
                            Modifier.weight(1f)
                                .heightIn(min = 24.dp)
                                .border(0.5.dp, grid)
                                .padding(4.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                cell,
                                color = fg,
                                fontSize = 8.5.sp,
                                lineHeight = 11.sp,
                                maxLines = 4,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun wordBlockContains(block: WordBlockModel, query: String): Boolean = when (block) {
    is WordBlockModel.Paragraph -> block.text.contains(query, true)
    is WordBlockModel.Picture -> false
    is WordBlockModel.Table -> block.rows.any { row -> row.any { it.contains(query, true) } }
}


@Composable
private fun WordRenderedPage(
    localPath: String,
    page: WordPageModel,
    inverted: Boolean,
    matched: Boolean,
    renderWidth: Int,
    modifier: Modifier = Modifier,
    onMessage: (String) -> Unit
) {
    var bitmap by remember(localPath, page, inverted) { mutableStateOf<Bitmap?>(null) }
    var loading by remember(localPath, page, inverted) { mutableStateOf(true) }

    LaunchedEffect(localPath, page, inverted, renderWidth) {
        loading = true
        runCatching {
            withContext(Dispatchers.IO) {
                renderWordPageBitmap(File(localPath), page, renderWidth, inverted)
            }
        }.onSuccess { fresh ->
            val old = bitmap
            bitmap = fresh
            old?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure { error ->
            onMessage(error.message ?: "No se pudo renderizar una página de Word.")
        }
        loading = false
    }

    DisposableEffect(localPath, page, inverted) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    Box(
        modifier = modifier
            .aspectRatio(1f / 1.294f)
            .background(if (inverted) Color(0xFF111111) else Color.White)
            .then(if (matched) Modifier.border(2.dp, NeonGreen) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        val current = bitmap
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
        } else if (loading) {
            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = NeonGreen, strokeWidth = 2.dp)
        }
    }
}

private fun renderWordPageBitmap(
    file: File,
    page: WordPageModel,
    requestedWidth: Int,
    inverted: Boolean
): Bitmap {
    val width = requestedWidth.coerceIn(600, 3000)
    val height = (width * 1.294f).roundToInt().coerceAtLeast(1)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    val background = if (inverted) AndroidColor.rgb(18, 18, 18) else AndroidColor.WHITE
    val foreground = if (inverted) AndroidColor.rgb(238, 238, 238) else AndroidColor.rgb(28, 28, 28)
    val gridColor = if (inverted) AndroidColor.rgb(100, 100, 100) else AndroidColor.rgb(175, 175, 175)
    canvas.drawColor(background)

    val margin = width * 0.075f
    val contentWidth = (width - margin * 2f).roundToInt().coerceAtLeast(1)
    val bottom = height - margin
    var y = margin

    val paragraphPaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = foreground
        textSize = width * 0.0215f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.NORMAL)
    }
    val tablePaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = foreground
        textSize = width * 0.0155f
    }
    val linePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = gridColor
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = (width / 1000f).coerceAtLeast(1f)
    }
    val imagePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG).apply {
        if (inverted) colorFilter = android.graphics.ColorMatrixColorFilter(
            android.graphics.ColorMatrix(
                floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }

    java.util.zip.ZipFile(file).use { zip ->
        for (block in page.blocks) {
            if (y >= bottom) break
            when (block) {
                is WordBlockModel.Paragraph -> {
                    val text = block.text.trim()
                    if (text.isNotEmpty()) {
                        val layout = buildStaticLayout(text, paragraphPaint, contentWidth)
                        if (y + layout.height > bottom) break
                        canvas.save()
                        canvas.translate(margin, y)
                        layout.draw(canvas)
                        canvas.restore()
                        y += layout.height + width * 0.010f
                    }
                }
                is WordBlockModel.Picture -> {
                    val image = runCatching { decodeOfficeZipBitmap(zip, block.entryName) }.getOrNull()
                    if (image != null) {
                        val maxImageHeight = min(width * 0.40f, bottom - y)
                        val scale = min(contentWidth.toFloat() / image.width.coerceAtLeast(1), maxImageHeight / image.height.coerceAtLeast(1))
                        val drawW = image.width * scale
                        val drawH = image.height * scale
                        val left = margin + (contentWidth - drawW) / 2f
                        val dst = android.graphics.RectF(left, y, left + drawW, y + drawH)
                        canvas.drawBitmap(image, null, dst, imagePaint)
                        if (!image.isRecycled) image.recycle()
                        y += drawH + width * 0.012f
                    }
                }
                is WordBlockModel.Table -> {
                    val rows = block.rows.take(24)
                    if (rows.isNotEmpty()) {
                        val columns = rows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
                        val cellWidth = contentWidth.toFloat() / columns
                        val rowHeight = (width * 0.038f).coerceAtLeast(22f)
                        for (row in rows) {
                            if (y + rowHeight > bottom) break
                            for (column in 0 until columns) {
                                val left = margin + column * cellWidth
                                val rect = android.graphics.RectF(left, y, left + cellWidth, y + rowHeight)
                                canvas.drawRect(rect, linePaint)
                                val cellText = row.getOrNull(column).orEmpty()
                                if (cellText.isNotBlank()) {
                                    val available = (cellWidth - width * 0.010f).roundToInt().coerceAtLeast(1)
                                    val layout = buildStaticLayout(cellText, tablePaint, available, maxLines = 2)
                                    canvas.save()
                                    canvas.clipRect(rect)
                                    canvas.translate(left + width * 0.005f, y + width * 0.004f)
                                    layout.draw(canvas)
                                    canvas.restore()
                                }
                            }
                            y += rowHeight
                        }
                        y += width * 0.012f
                    }
                }
            }
        }
    }
    return bitmap
}

private fun buildStaticLayout(
    text: String,
    paint: android.text.TextPaint,
    width: Int,
    maxLines: Int = Int.MAX_VALUE
): android.text.StaticLayout {
    return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
        android.text.StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(1))
            .setAlignment(android.text.Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.08f)
            .setMaxLines(maxLines)
            .setEllipsize(if (maxLines == Int.MAX_VALUE) null else android.text.TextUtils.TruncateAt.END)
            .build()
    } else {
        @Suppress("DEPRECATION")
        android.text.StaticLayout(
            text,
            paint,
            width.coerceAtLeast(1),
            android.text.Layout.Alignment.ALIGN_NORMAL,
            1.08f,
            0f,
            false
        )
    }
}

@Composable
private fun ExcelWorkbookViewer(
    localPath: String,
    workbook: ExcelWorkbookModel,
    query: String,
    inverted: Boolean,
    onMessage: (String) -> Unit
) {
    var selectedSheet by rememberSaveable(localPath) { mutableIntStateOf(0) }
    var sheetData by remember(localPath, selectedSheet) { mutableStateOf<ExcelSheetData?>(null) }
    var loadingSheet by remember(localPath, selectedSheet) { mutableStateOf(true) }
    var loadingMore by remember(localPath, selectedSheet) { mutableStateOf(false) }
    var sheetError by remember(localPath, selectedSheet) { mutableStateOf<String?>(null) }
    var zoom by rememberSaveable(localPath) { mutableFloatStateOf(1f) }
    var zoomInteracted by remember { mutableStateOf(false) }
    var zoomBadgeVisible by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val horizontalState = rememberScrollState()
    var selectedCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    LaunchedEffect(localPath, selectedSheet) {
        loadingSheet = true
        loadingMore = false
        sheetError = null
        sheetData = null
        listState.scrollToItem(0)
        horizontalState.scrollTo(0)
        try {
            // Primera pasada limitada: evita que un XLSX grande deje al usuario viendo
            // "Cargando hoja" durante decenas de segundos. La hoja ya se puede usar
            // mientras se completa el resto en segundo plano.
            val initial = withContext(Dispatchers.IO) {
                parseXlsxSheet(
                    File(localPath),
                    workbook.sheets[selectedSheet],
                    workbook.sharedStrings,
                    workbook.styles,
                    rowLimit = 1500
                )
            }
            sheetData = initial
            loadingSheet = false
            if (!initial.isComplete) {
                loadingMore = true
                val full = withContext(Dispatchers.IO) {
                    parseXlsxSheet(
                        File(localPath),
                        workbook.sheets[selectedSheet],
                        workbook.sharedStrings,
                        workbook.styles,
                        rowLimit = null
                    )
                }
                sheetData = full
                loadingMore = false
            }
        } catch (error: Throwable) {
            loadingSheet = false
            loadingMore = false
            sheetError = error.message ?: "No se pudo leer esta hoja."
            onMessage(sheetError!!)
        }
    }

    LaunchedEffect(zoom) {
        if (zoomInteracted) {
            zoomBadgeVisible = true
            kotlinx.coroutines.delay(700L)
            zoomBadgeVisible = false
        }
    }

    val dataForSearch = sheetData
    LaunchedEffect(query, dataForSearch) {
        if (query.isNotBlank() && dataForSearch != null) {
            val firstMatch = dataForSearch.rows.entries.firstOrNull { (_, row) ->
                row.cells.values.any { it.value.contains(query, ignoreCase = true) }
            }?.key
            if (firstMatch != null && firstMatch > 0) {
                listState.animateScrollToItem((firstMatch - 1).coerceAtLeast(0))
            }
        }
    }

    Column(Modifier.fillMaxSize().background(if (inverted) Color.Black else Color.White)) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .background(if (inverted) Color(0xFF121212) else Color(0xFFF5F5F5))
                .padding(horizontal = 4.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            workbook.sheets.forEachIndexed { index, sheet ->
                val active = index == selectedSheet
                Surface(
                    modifier = Modifier.clickable {
                        selectedSheet = index
                        selectedCell = null
                    },
                    color = if (active) {
                        if (inverted) Color(0xFF0C5D32) else Color(0xFFDFF4E8)
                    } else Color.Transparent,
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text(
                        sheet.name,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        color = if (active) {
                            if (inverted) Color.White else Color(0xFF0B6B3A)
                        } else if (inverted) Color(0xFFD0D0D0) else Color(0xFF555555),
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
            }
        }

        if (loadingSheet) {
            ViewerLoading("Cargando hoja…")
            return@Column
        }
        val data = sheetData
        if (sheetError != null || data == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(sheetError ?: "Hoja no disponible", color = if (inverted) Color.White else Color.DarkGray)
            }
        } else {
            BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
                val baseRowHeaderWidth = 34.dp
                val baseHeaderHeight = 25.dp
                val baseColumnWidths = remember(data) {
                    List(data.maxColumns) { col ->
                        val chars = data.columnWidths[col] ?: 9.0f
                        ((chars * 7.1f).coerceIn(38f, 260f)).dp
                    }
                }
                val baseTotalWidth = baseColumnWidths.fold(baseRowHeaderWidth) { acc, width -> acc + width }
                val scaledTotalWidth = baseTotalWidth * zoom
                val contentWidth = if (scaledTotalWidth < maxWidth) maxWidth else scaledTotalWidth

                Box(
                    modifier = Modifier.fillMaxSize()
                        .pointerInput(localPath, selectedSheet) {
                            awaitEachGesture {
                                do {
                                    val event = awaitPointerEvent()
                                    if (event.changes.count { it.pressed } >= 2) {
                                        zoomInteracted = true
                                        zoom = (zoom * event.calculateZoom()).coerceIn(0.5f, 3f)
                                        val pan = event.calculatePan()
                                        if (pan.x != 0f) horizontalState.dispatchRawDelta(-pan.x)
                                        if (pan.y != 0f) listState.dispatchRawDelta(-pan.y)
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                        .horizontalScroll(horizontalState)
                ) {
                    Column(Modifier.width(contentWidth).fillMaxHeight()) {
                        Box(
                            modifier = Modifier.fillMaxWidth().height(baseHeaderHeight * zoom),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            ExcelColumnHeaders(
                                maxColumns = data.maxColumns,
                                rowHeaderWidth = baseRowHeaderWidth,
                                columnWidths = baseColumnWidths,
                                rowHeight = baseHeaderHeight,
                                inverted = inverted,
                                modifier = Modifier
                                    .width(baseTotalWidth)
                                    .height(baseHeaderHeight)
                                    .graphicsLayer {
                                        scaleX = zoom
                                        scaleY = zoom
                                        transformOrigin = TransformOrigin(0.5f, 0f)
                                    }
                            )
                        }
                        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth()) {
                            items(data.maxRows, key = { index -> "excel_row_${index + 1}" }) { index ->
                                val rowNumber = index + 1
                                val row = data.rows[rowNumber] ?: ExcelRowData(rowNumber, emptyMap())
                                val baseRowHeight = (((row.heightPoints ?: 18f) * 1.15f).coerceIn(20f, 120f)).dp
                                Box(
                                    modifier = Modifier.fillMaxWidth().height(baseRowHeight * zoom),
                                    contentAlignment = Alignment.TopCenter
                                ) {
                                    ExcelGridRow(
                                        row = row,
                                        maxColumns = data.maxColumns,
                                        rowHeaderWidth = baseRowHeaderWidth,
                                        columnWidths = baseColumnWidths,
                                        rowHeight = baseRowHeight,
                                        query = query,
                                        inverted = inverted,
                                        styles = workbook.styles,
                                        selectedCell = selectedCell,
                                        onCellSelected = { col -> selectedCell = row.rowNumber to col },
                                        modifier = Modifier
                                            .width(baseTotalWidth)
                                            .height(baseRowHeight)
                                            .graphicsLayer {
                                                scaleX = zoom
                                                scaleY = zoom
                                                transformOrigin = TransformOrigin(0.5f, 0f)
                                            }
                                    )
                                }
                            }
                        }
                    }
                }

                ViewerSideCounter(
                    text = "${selectedSheet + 1}/${workbook.sheets.size}",
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)
                )
                if (zoomBadgeVisible) {
                    ViewerZoomBadge(
                        text = "${(zoom * 100f).roundToInt()}%",
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                    )
                }
                if (loadingMore) {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
                        color = Color(0xD9202124),
                        contentColor = Color.White,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = NeonGreen)
                            Text("Cargando más filas…", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExcelColumnHeaders(
    maxColumns: Int,
    rowHeaderWidth: androidx.compose.ui.unit.Dp,
    columnWidths: List<androidx.compose.ui.unit.Dp>,
    rowHeight: androidx.compose.ui.unit.Dp,
    inverted: Boolean,
    modifier: Modifier = Modifier
) {
    val bg = if (inverted) Color(0xFF202020) else Color(0xFFEFEFEF)
    val fg = if (inverted) Color(0xFFEAEAEA) else Color(0xFF333333)
    val grid = if (inverted) Color(0xFF4A4A4A) else Color(0xFFC9C9C9)
    Row(modifier) {
        Box(Modifier.width(rowHeaderWidth).height(rowHeight).background(bg).border(0.5.dp, grid))
        repeat(maxColumns) { col ->
            Box(
                Modifier.width(columnWidths[col]).height(rowHeight).background(bg).border(0.5.dp, grid),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    excelColumnName(col),
                    color = fg,
                    fontWeight = FontWeight.Medium,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun ExcelGridRow(
    row: ExcelRowData,
    maxColumns: Int,
    rowHeaderWidth: androidx.compose.ui.unit.Dp,
    columnWidths: List<androidx.compose.ui.unit.Dp>,
    rowHeight: androidx.compose.ui.unit.Dp,
    query: String,
    inverted: Boolean,
    styles: List<ExcelCellStyleModel>,
    selectedCell: Pair<Int, Int>?,
    onCellSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (inverted) Color(0xFF0A0A0A) else Color.White
    val headerBg = if (inverted) Color(0xFF202020) else Color(0xFFEFEFEF)
    val fg = if (inverted) Color(0xFFF1F1F1) else Color(0xFF202124)
    val grid = if (inverted) Color(0xFF383838) else Color(0xFFD4D4D4)
    Row(modifier) {
        Box(
            Modifier.width(rowHeaderWidth).height(rowHeight).background(headerBg).border(0.5.dp, grid),
            contentAlignment = Alignment.Center
        ) {
            Text(row.rowNumber.toString(), color = fg, fontSize = 9.5.sp)
        }
        repeat(maxColumns) { col ->
            val cell = row.cells[col]
            val value = cell?.value.orEmpty()
            val style = styles.getOrNull(cell?.styleIndex ?: 0)
            val styledBg = style?.fillArgb?.let { Color(if (inverted) invertArgb(it) else it) } ?: bg
            val styledFg = style?.textArgb?.let { Color(if (inverted) invertArgb(it) else it) } ?: fg
            val isMatch = query.isNotBlank() && value.contains(query, ignoreCase = true)
            val isSelected = selectedCell == (row.rowNumber to col)
            val contentAlignment = when (style?.horizontal?.lowercase()) {
                "center" -> Alignment.Center
                "right" -> Alignment.CenterEnd
                else -> Alignment.CenterStart
            }
            Box(
                modifier = Modifier.width(columnWidths[col]).height(rowHeight).background(styledBg)
                    .border(
                        width = if (isSelected || isMatch) 1.8.dp else 0.5.dp,
                        color = if (isSelected || isMatch) Color(0xFF16A765) else grid
                    )
                    .clickable { onCellSelected(col) }
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                contentAlignment = contentAlignment
            ) {
                Text(
                    value,
                    color = styledFg,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = (style?.fontSizePt ?: 10f).sp,
                    lineHeight = ((style?.fontSizePt ?: 10f) * 1.15f).sp,
                    fontWeight = if (style?.bold == true) FontWeight.Bold else FontWeight.Normal,
                    textAlign = when (style?.horizontal?.lowercase()) {
                        "center" -> TextAlign.Center
                        "right" -> TextAlign.End
                        else -> TextAlign.Start
                    }
                )
            }
        }
    }
}

@Composable
private fun PowerPointDeckViewer(
    localPath: String,
    deck: PowerPointDeckModel,
    query: String,
    inverted: Boolean,
    onMessage: (String) -> Unit,
    onCurrentSlideChanged: (Int) -> Unit
) {
    val matchingSlides = remember(deck, query) {
        if (query.isBlank()) emptySet()
        else deck.slides.mapIndexedNotNull { index, slide ->
            val found = slide.elements.any { element ->
                element is PowerPointElementModel.TextBox && element.text.contains(query, true)
            }
            if (found) index else null
        }.toSet()
    }
    val jumpTarget = matchingSlides.minOrNull()

    DrivePagedSurface(
        viewerKey = "ppt_$localPath",
        pageCount = deck.slides.size,
        background = if (inverted) Color.Black else Color(0xFF252525),
        jumpToPage = jumpTarget,
        jumpRequestKey = query,
        minZoom = 0.20f,
        maxZoom = 5f,
        onCurrentPageChanged = onCurrentSlideChanged,
        pageContent = { index, renderWidth, pageWidth ->
            val ratio = deck.widthEmu.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f)
            PowerPointRenderedSlide(
                localPath = localPath,
                deck = deck,
                slide = deck.slides[index],
                inverted = inverted,
                renderWidth = renderWidth,
                matched = index in matchingSlides,
                modifier = Modifier.width(pageWidth).aspectRatio(ratio),
                onMessage = onMessage
            )
        }
    )
}

@Composable
private fun PowerPointPresentation(
    localPath: String,
    deck: PowerPointDeckModel,
    initialSlide: Int,
    inverted: Boolean,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    var current by rememberSaveable(localPath, initialSlide) {
        mutableIntStateOf(initialSlide.coerceIn(0, deck.slides.lastIndex))
    }
    var direction by remember { mutableIntStateOf(1) }
    var controlsVisible by remember { mutableStateOf(true) }
    var dragAmount by remember { mutableFloatStateOf(0f) }

    // Solo el modo Presentar fuerza paisaje. El visor normal permanece vertical.
    DisposableEffect(activity) {
        val previous = activity?.requestedOrientation
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose {
            if (previous != null) activity?.requestedOrientation = previous
        }
    }

    val goTo: (Int) -> Unit = { target ->
        val fixed = target.coerceIn(0, deck.slides.lastIndex)
        direction = if (fixed >= current) 1 else -1
        current = fixed
    }

    val autoMs = deck.slides[current].advanceAfterMs
    LaunchedEffect(current, autoMs) {
        if (autoMs != null && autoMs in 200L..120000L && current < deck.slides.lastIndex) {
            kotlinx.coroutines.delay(autoMs)
            goTo(current + 1)
        }
    }
    LaunchedEffect(controlsVisible, current) {
        if (controlsVisible) {
            kotlinx.coroutines.delay(1800L)
            controlsVisible = false
        }
    }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(current) {
                detectHorizontalDragGestures(
                    onDragStart = { dragAmount = 0f },
                    onHorizontalDrag = { change, amount ->
                        change.consume()
                        dragAmount += amount
                    },
                    onDragEnd = {
                        when {
                            dragAmount < -80f && current < deck.slides.lastIndex -> goTo(current + 1)
                            dragAmount > 80f && current > 0 -> goTo(current - 1)
                        }
                        dragAmount = 0f
                    }
                )
            }
            .pointerInput(current) { detectTapGestures(onTap = { controlsVisible = !controlsVisible }) },
        contentAlignment = Alignment.Center
    ) {
        val slideRatio = deck.widthEmu.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f)
        val availableRatio = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
        val fittedWidth: androidx.compose.ui.unit.Dp
        val fittedHeight: androidx.compose.ui.unit.Dp
        if (availableRatio > slideRatio) {
            fittedHeight = maxHeight
            fittedWidth = fittedHeight * slideRatio
        } else {
            fittedWidth = maxWidth
            fittedHeight = fittedWidth / slideRatio
        }

        androidx.compose.animation.AnimatedContent(
            targetState = current,
            transitionSpec = { powerPointTransition(deck.slides[targetState].transition, direction) },
            label = "ppt_transition",
            modifier = Modifier.fillMaxSize()
        ) { index ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                PowerPointRenderedSlide(
                    localPath = localPath,
                    deck = deck,
                    slide = deck.slides[index],
                    inverted = inverted,
                    renderWidth = 2600,
                    matched = false,
                    modifier = Modifier.width(fittedWidth).height(fittedHeight),
                    onMessage = {}
                )
            }
        }

        ViewerSideCounter(
            text = "${current + 1}/${deck.slides.size}",
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 10.dp)
        )

        if (controlsVisible) {
            Surface(
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding(),
                color = Color(0xCC111111)
            ) {
                Row(Modifier.height(48.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onExit) {
                        Icon(Icons.Rounded.Close, contentDescription = "Salir", tint = Color.White)
                    }
                    Text("Presentando", color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                }
            }
            Row(
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Surface(shape = RoundedCornerShape(24.dp), color = Color(0xCC202124)) {
                    IconButton(onClick = { if (current > 0) goTo(current - 1) }) {
                        Icon(Icons.Rounded.NavigateBefore, contentDescription = "Anterior", tint = Color.White)
                    }
                }
                Surface(shape = RoundedCornerShape(24.dp), color = Color(0xCC202124)) {
                    IconButton(onClick = { if (current < deck.slides.lastIndex) goTo(current + 1) }) {
                        Icon(Icons.Rounded.NavigateNext, contentDescription = "Siguiente", tint = Color.White)
                    }
                }
            }
        }
    }
}

private fun powerPointTransition(name: String?, direction: Int): androidx.compose.animation.ContentTransform {
    val normalized = name.orEmpty().lowercase()
    val enterOffset: (Int) -> Int = { width -> if (direction >= 0) width else -width }
    val exitOffset: (Int) -> Int = { width -> if (direction >= 0) -width else width }
    return when {
        normalized.contains("fade") || normalized.contains("dissolve") ->
            androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(280)) togetherWith
                androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(240))

        normalized.contains("zoom") || normalized.contains("newsflash") ||
            normalized.contains("wheel") || normalized.contains("wedge") ->
            (androidx.compose.animation.scaleIn(androidx.compose.animation.core.tween(320), initialScale = 0.88f) +
                androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(250))) togetherWith
                (androidx.compose.animation.scaleOut(androidx.compose.animation.core.tween(260), targetScale = 1.10f) +
                    androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(220)))

        normalized.contains("split") || normalized.contains("diamond") ||
            normalized.contains("circle") || normalized.contains("plus") ->
            (androidx.compose.animation.scaleIn(androidx.compose.animation.core.tween(280), initialScale = 0.96f) +
                androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220))) togetherWith
                (androidx.compose.animation.scaleOut(androidx.compose.animation.core.tween(240), targetScale = 0.96f) +
                    androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200)))

        normalized.contains("randombar") || normalized.contains("checker") || normalized.contains("blinds") ->
            androidx.compose.animation.slideInVertically(
                androidx.compose.animation.core.tween(300),
                initialOffsetY = { height -> if (direction >= 0) height / 3 else -height / 3 }
            ) togetherWith androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(240))

        normalized.contains("cut") || normalized.contains("none") ->
            androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(80)) togetherWith
                androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(80))

        else ->
            androidx.compose.animation.slideInHorizontally(
                androidx.compose.animation.core.tween(300),
                initialOffsetX = enterOffset
            ) togetherWith androidx.compose.animation.slideOutHorizontally(
                androidx.compose.animation.core.tween(300),
                targetOffsetX = exitOffset
            )
    }
}

@Composable
private fun PowerPointRenderedSlide(
    localPath: String,
    deck: PowerPointDeckModel,
    slide: PowerPointSlideModel,
    inverted: Boolean,
    renderWidth: Int,
    matched: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    var bitmap by remember(localPath, slide, inverted) { mutableStateOf<Bitmap?>(null) }
    var loading by remember(localPath, slide, inverted) { mutableStateOf(true) }

    LaunchedEffect(localPath, slide, inverted, renderWidth) {
        loading = true
        runCatching {
            withContext(Dispatchers.IO) {
                renderPowerPointSlideBitmap(File(localPath), deck, slide, renderWidth, inverted)
            }
        }.onSuccess { fresh ->
            val old = bitmap
            bitmap = fresh
            old?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure { error ->
            onMessage(error.message ?: "No se pudo renderizar una diapositiva.")
        }
        loading = false
    }

    DisposableEffect(localPath, slide, inverted) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    Box(
        modifier = modifier
            .background(if (inverted) Color.Black else Color.White)
            .then(if (matched) Modifier.border(2.dp, NeonGreen) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        val current = bitmap
        if (current != null) {
            Image(
                bitmap = current.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
        } else if (loading) {
            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = NeonGreen, strokeWidth = 2.dp)
        }
    }
}

private fun renderPowerPointSlideBitmap(
    file: File,
    deck: PowerPointDeckModel,
    slide: PowerPointSlideModel,
    requestedWidth: Int,
    inverted: Boolean
): Bitmap {
    val width = requestedWidth.coerceIn(700, 3200)
    val deckWidth = deck.widthEmu.coerceAtLeast(1L)
    val deckHeight = deck.heightEmu.coerceAtLeast(1L)
    val height = (width.toDouble() * deckHeight.toDouble() / deckWidth.toDouble())
        .roundToInt()
        .coerceAtLeast(1)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    val rawBackground = slide.backgroundArgb ?: 0xFFFFFFFF.toInt()
    val background = if (inverted) invertArgb(rawBackground) else rawBackground
    canvas.drawColor(background)

    val scaleX = width.toFloat() / deckWidth.toFloat()
    val scaleY = height.toFloat() / deckHeight.toFloat()
    val imagePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG).apply {
        if (inverted) colorFilter = android.graphics.ColorMatrixColorFilter(
            android.graphics.ColorMatrix(
                floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }

    java.util.zip.ZipFile(file).use { zip ->
        slide.elements.forEach { element ->
            val left = element.x * scaleX
            val top = element.y * scaleY
            val right = (element.x + element.width) * scaleX
            val bottom = (element.y + element.height) * scaleY
            val rect = android.graphics.RectF(left, top, right, bottom)
            if (rect.width() <= 0f || rect.height() <= 0f) return@forEach

            when (element) {
                is PowerPointElementModel.Rectangle -> {
                    val fill = if (inverted) invertArgb(element.fillArgb) else element.fillArgb
                    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = fill
                        style = android.graphics.Paint.Style.FILL
                    }
                    canvas.drawRect(rect, paint)
                }
                is PowerPointElementModel.Picture -> {
                    val image = runCatching { decodeOfficeZipBitmap(zip, element.entryName) }.getOrNull()
                    if (image != null) {
                        canvas.drawBitmap(image, null, rect, imagePaint)
                        if (!image.isRecycled) image.recycle()
                    }
                }
                is PowerPointElementModel.TextBox -> {
                    val baseColor = element.textArgb ?: if (pptIsDark(rawBackground)) 0xFFFFFFFF.toInt() else 0xFF171717.toInt()
                    val textColor = if (inverted) invertArgb(baseColor) else baseColor
                    val textPaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = textColor
                        val pointSize = element.fontSizePt ?: if (element.height > deckHeight / 7) 24f else 16f
                        textSize = (pointSize * 12700f * scaleY).coerceIn(width * 0.012f, width * 0.12f)
                        typeface = android.graphics.Typeface.create(
                            android.graphics.Typeface.SANS_SERIF,
                            if (element.bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL
                        )
                    }
                    val padding = (width * 0.004f).coerceAtLeast(2f)
                    val textWidth = (rect.width() - padding * 2f).roundToInt().coerceAtLeast(1)
                    val layout = buildStaticLayout(element.text, textPaint, textWidth, maxLines = 30)
                    canvas.save()
                    canvas.clipRect(rect)
                    canvas.translate(rect.left + padding, rect.top + padding)
                    layout.draw(canvas)
                    canvas.restore()
                }
            }
        }
    }
    return bitmap
}

@Composable
private fun PowerPointSlideCanvas(
    localPath: String,
    deck: PowerPointDeckModel,
    slide: PowerPointSlideModel,
    inverted: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    val rawBackground = slide.backgroundArgb ?: 0xFFFFFFFF.toInt()
    val background = Color(if (inverted) invertArgb(rawBackground) else rawBackground)
    val defaultForeground = if (pptIsDark(rawBackground) xor inverted) Color.White else Color(0xFF171717)
    BoxWithConstraints(
        modifier = modifier.clip(RoundedCornerShape(3.dp)).background(background)
    ) {
        val displayScale = (maxWidth.value / 360f).coerceIn(0.55f, 4f)
        slide.elements.forEach { element ->
            val left = maxWidth * (element.x.toFloat() / deck.widthEmu.toFloat().coerceAtLeast(1f))
            val top = maxHeight * (element.y.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f))
            val width = maxWidth * (element.width.toFloat() / deck.widthEmu.toFloat().coerceAtLeast(1f))
            val height = maxHeight * (element.height.toFloat() / deck.heightEmu.toFloat().coerceAtLeast(1f))
            when (element) {
                is PowerPointElementModel.TextBox -> {
                    val rawText = element.textArgb
                    val textColor = if (rawText != null) Color(if (inverted) invertArgb(rawText) else rawText) else defaultForeground
                    val baseFontSp = element.fontSizePt?.times(0.52f)
                        ?: if (element.height > deck.heightEmu / 7) 17f else 11.5f
                    val fontSp = (baseFontSp * displayScale).coerceIn(5.5f, 64f)
                    Text(
                        element.text,
                        color = textColor,
                        modifier = Modifier.offset(left, top).width(width).height(height).padding(1.dp * displayScale),
                        fontSize = fontSp.sp,
                        lineHeight = (fontSp * 1.08f).sp,
                        fontWeight = if (element.bold) FontWeight.Bold else FontWeight.Normal,
                        overflow = TextOverflow.Ellipsis,
                        maxLines = 24
                    )
                }
                is PowerPointElementModel.Rectangle -> {
                    val rawFill = element.fillArgb
                    Box(
                        Modifier.offset(left, top).width(width).height(height)
                            .background(Color(if (inverted) invertArgb(rawFill) else rawFill))
                    )
                }
                is PowerPointElementModel.Picture -> OfficeZipImage(
                    localPath = localPath,
                    entryName = element.entryName,
                    inverted = inverted,
                    modifier = Modifier.offset(left, top).width(width).height(height),
                    onMessage = onMessage
                )
            }
        }
    }
}

@Composable
private fun OfficeZipImage(
    localPath: String,
    entryName: String,
    inverted: Boolean,
    modifier: Modifier,
    onMessage: (String) -> Unit
) {
    var bitmap by remember(localPath, entryName) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(localPath, entryName) {
        runCatching {
            withContext(Dispatchers.IO) {
                java.util.zip.ZipFile(File(localPath)).use { zip ->
                    decodeOfficeZipBitmap(zip, entryName)
                }
            }
        }.onSuccess { fresh ->
            val old = bitmap
            bitmap = fresh
            old?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
        }.onFailure { onMessage(it.message ?: "No se pudo mostrar una imagen del documento.") }
    }
    DisposableEffect(localPath, entryName) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }
    val current = bitmap
    if (current != null) {
        Image(
            bitmap = current.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = modifier,
            colorFilter = if (inverted) officeInvertColorFilter() else null
        )
    } else {
        Box(modifier.background(if (inverted) Color(0xFF1E1E1E) else Color(0xFFF1F1F1)), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = NeonGreen, strokeWidth = 2.dp)
        }
    }
}


private fun decodeOfficeZipBitmap(zip: java.util.zip.ZipFile, entryName: String): Bitmap {
    val entry = zip.getEntry(entryName) ?: error("Imagen no encontrada")
    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    zip.getInputStream(entry).use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    val largest = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
    while (largest / sample > 2200) sample *= 2
    val options = android.graphics.BitmapFactory.Options().apply {
        inSampleSize = sample.coerceAtLeast(1)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return zip.getInputStream(entry).use { input ->
        android.graphics.BitmapFactory.decodeStream(input, null, options)
    } ?: error("Imagen no compatible")
}

private fun officeInvertColorFilter(): androidx.compose.ui.graphics.ColorFilter =
    androidx.compose.ui.graphics.ColorFilter.colorMatrix(
        androidx.compose.ui.graphics.ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

private fun shareDocumentFile(context: android.content.Context, uri: Uri, mime: String) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = mime
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { context.startActivity(android.content.Intent.createChooser(intent, "Compartir archivo")) }
}

private suspend fun copyOfficeToViewerCache(
    context: android.content.Context,
    source: Uri,
    type: OfficeViewerType
): File = withContext(Dispatchers.IO) {
    val directory = File(context.cacheDir, "office_viewer").apply { mkdirs() }
    directory.listFiles()?.forEach { old ->
        if (System.currentTimeMillis() - old.lastModified() > 6 * 60 * 60 * 1000L) runCatching { old.delete() }
    }
    val extension = type.extensions.lowercase()
    val file = File(directory, "viewer_${System.currentTimeMillis()}_${kotlin.random.Random.nextInt(1000, 9999)}.$extension")
    try {
        context.contentResolver.openInputStream(source)?.use { input ->
            FileOutputStream(file).use { output -> input.copyTo(output, 128 * 1024) }
        } ?: error("No se pudo leer el archivo seleccionado.")
        require(file.length() > 0) { "El archivo está vacío." }
        java.util.zip.ZipFile(file).use { require(it.entries().hasMoreElements()) { "El archivo no tiene contenido OOXML válido." } }
        file
    } catch (error: Throwable) {
        runCatching { file.delete() }
        throw error
    }
}

private fun parseDocxModel(file: File): WordDocumentModel {
    java.util.zip.ZipFile(file).use { zip ->
        val documentEntry = zip.getEntry("word/document.xml") ?: error("El DOCX no contiene document.xml.")
        val relationships = parseZipRelationships(zip, "word/_rels/document.xml.rels", "word/document.xml")
        val rawPages = mutableListOf<MutableList<WordBlockModel>>(mutableListOf())
        var paragraphText = StringBuilder()
        var paragraphImages = mutableListOf<String>()
        var inParagraph = false
        var pageBreak = false
        var explicitBreakSeen = false
        var tableDepth = -1
        var rowDepth = -1
        var cellDepth = -1
        var tableRows = mutableListOf<MutableList<String>>()
        var currentRow = mutableListOf<String>()
        var currentCell = StringBuilder()

        val parser = Xml.newPullParser()
        zip.getInputStream(documentEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "tbl" -> if (tableDepth < 0) {
                            tableDepth = parser.depth
                            tableRows = mutableListOf()
                        }
                        "tr" -> if (tableDepth > 0 && rowDepth < 0) {
                            rowDepth = parser.depth
                            currentRow = mutableListOf()
                        }
                        "tc" -> if (tableDepth > 0 && cellDepth < 0) {
                            cellDepth = parser.depth
                            currentCell = StringBuilder()
                        }
                        "p" -> {
                            inParagraph = true
                            paragraphText = StringBuilder()
                            paragraphImages = mutableListOf()
                            pageBreak = false
                        }
                        "t" -> if (inParagraph) paragraphText.append(parser.nextText())
                        "tab" -> if (inParagraph) paragraphText.append('\t')
                        "br" -> if (inParagraph) {
                            val type = attributeByLocalName(parser, "type")
                            if (type == "page") { pageBreak = true; explicitBreakSeen = true } else paragraphText.append('\n')
                        }
                        "lastRenderedPageBreak" -> if (inParagraph) { pageBreak = true; explicitBreakSeen = true }
                        "blip" -> if (inParagraph) {
                            val relId = attributeByLocalName(parser, "embed")
                            relId?.let { relationships[it] }?.let(paragraphImages::add)
                        }
                    }
                    XmlPullParser.END_TAG -> when {
                        parser.name == "p" && inParagraph -> {
                            val text = paragraphText.toString().trim()
                            if (tableDepth > 0 && cellDepth > 0) {
                                if (text.isNotBlank()) {
                                    if (currentCell.isNotEmpty()) currentCell.append('\n')
                                    currentCell.append(text)
                                }
                            } else {
                                if (text.isNotBlank()) rawPages.last().add(WordBlockModel.Paragraph(text))
                                paragraphImages.distinct().forEach { rawPages.last().add(WordBlockModel.Picture(it)) }
                                if (pageBreak && rawPages.last().isNotEmpty()) rawPages.add(mutableListOf())
                            }
                            inParagraph = false
                        }
                        parser.name == "tc" && cellDepth > 0 && parser.depth == cellDepth -> {
                            currentRow += currentCell.toString().trim()
                            currentCell = StringBuilder()
                            cellDepth = -1
                        }
                        parser.name == "tr" && rowDepth > 0 && parser.depth == rowDepth -> {
                            tableRows += currentRow
                            currentRow = mutableListOf()
                            rowDepth = -1
                        }
                        parser.name == "tbl" && tableDepth > 0 && parser.depth == tableDepth -> {
                            if (tableRows.isNotEmpty()) rawPages.last().add(WordBlockModel.Table(tableRows.map { it.toList() }))
                            tableRows = mutableListOf()
                            tableDepth = -1
                        }
                    }
                }
                event = parser.next()
            }
        }
        if (rawPages.lastOrNull()?.isEmpty() == true && rawPages.size > 1) rawPages.removeAt(rawPages.lastIndex)
        val pages = if (explicitBreakSeen) {
            rawPages.filter { it.isNotEmpty() }.map { WordPageModel(it.toList()) }
        } else repaginateWord(rawPages)
        require(pages.isNotEmpty()) { "El DOCX no contiene contenido visible." }
        return WordDocumentModel(pages)
    }
}

private fun repaginateWord(rawPages: List<List<WordBlockModel>>): List<WordPageModel> {
    val result = mutableListOf<WordPageModel>()
    rawPages.forEach { raw ->
        var current = mutableListOf<WordBlockModel>()
        var cost = 0
        fun flush() {
            if (current.isNotEmpty()) {
                result += WordPageModel(current)
                current = mutableListOf()
                cost = 0
            }
        }
        raw.forEach { block ->
            val blockCost = when (block) {
                is WordBlockModel.Paragraph -> 1 + block.text.length / 95
                is WordBlockModel.Picture -> 7
                is WordBlockModel.Table -> 3 + block.rows.size * 2
            }
            if (cost + blockCost > 28 && current.isNotEmpty()) flush()
            current += block
            cost += blockCost
        }
        flush()
    }
    return result
}

private fun parseXlsxWorkbook(file: File): ExcelWorkbookModel {
    java.util.zip.ZipFile(file).use { zip ->
        val shared = zip.getEntry("xl/sharedStrings.xml")?.let { entry ->
            zip.getInputStream(entry).use(::parseSharedStringsStream)
        }.orEmpty()
        val themeColors = zip.getEntry("xl/theme/theme1.xml")?.let { entry ->
            zip.getInputStream(entry).use(::parseOfficeThemeColorsStream)
        }.orEmpty()
        val styles = zip.getEntry("xl/styles.xml")?.let { entry ->
            zip.getInputStream(entry).use { parseExcelStylesStream(it, themeColors) }
        }.orEmpty().ifEmpty { listOf(ExcelCellStyleModel()) }
        val relationships = parseZipRelationships(zip, "xl/_rels/workbook.xml.rels", "xl/workbook.xml")
        val workbookEntry = zip.getEntry("xl/workbook.xml") ?: error("El XLSX no contiene workbook.xml.")
        val sheets = mutableListOf<ExcelSheetRef>()
        val parser = Xml.newPullParser()
        zip.getInputStream(workbookEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name == "sheet") {
                    val name = parser.getAttributeValue(null, "name").orEmpty().ifBlank { "Hoja ${sheets.size + 1}" }
                    val relId = relationshipIdAttribute(parser)
                    val target = relId?.let { relationships[it] }
                    if (!target.isNullOrBlank()) sheets += ExcelSheetRef(name, target)
                }
                event = parser.next()
            }
        }
        require(sheets.isNotEmpty()) { "El XLSX no contiene hojas legibles." }
        return ExcelWorkbookModel(shared, sheets, styles)
    }
}

private fun parseXlsxSheet(
    file: File,
    ref: ExcelSheetRef,
    shared: List<String>,
    styles: List<ExcelCellStyleModel>,
    rowLimit: Int? = null
): ExcelSheetData {
    java.util.zip.ZipFile(file).use { zip ->
        val entry = zip.getEntry(ref.entryName) ?: error("No se encontró la hoja ${ref.name}.")
        val rows = linkedMapOf<Int, ExcelRowData>()
        val columnWidths = mutableMapOf<Int, Float>()
        var rowNumber = 0
        var rowHeightPoints: Float? = null
        var cells = linkedMapOf<Int, ExcelCellData>()
        var cellRef = ""
        var cellType: String? = null
        var cellStyleIndex = 0
        var value = StringBuilder()
        var inline = StringBuilder()
        var formula = StringBuilder()
        var captureValue = false
        var captureInline = false
        var captureFormula = false
        var maxColumn = 0
        var maxRow = 1
        var declaredMaxColumn = 0
        var declaredMaxRow = 0
        var stoppedEarly = false
        val parser = Xml.newPullParser()
        zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "dimension" -> {
                            val range = parser.getAttributeValue(null, "ref").orEmpty()
                            val lastCell = range.substringAfterLast(':', range)
                            declaredMaxColumn = maxOf(declaredMaxColumn, excelColumnIndex(lastCell) + 1)
                            declaredMaxRow = maxOf(
                                declaredMaxRow,
                                lastCell.filter { it.isDigit() }.toIntOrNull() ?: 0
                            )
                        }
                        "col" -> {
                            val minCol = parser.getAttributeValue(null, "min")?.toIntOrNull()?.minus(1) ?: -1
                            val maxCol = parser.getAttributeValue(null, "max")?.toIntOrNull()?.minus(1) ?: minCol
                            val width = parser.getAttributeValue(null, "width")?.toFloatOrNull()
                            if (minCol >= 0 && maxCol >= minCol && width != null) {
                                for (col in minCol..maxCol.coerceAtMost(255)) columnWidths[col] = width
                                maxColumn = maxOf(maxColumn, maxCol + 1)
                            }
                        }
                        "row" -> {
                            val nextRow = parser.getAttributeValue(null, "r")?.toIntOrNull()
                                ?: (rowNumber + 1).coerceAtLeast(1)
                            if (rowLimit != null && nextRow > rowLimit) {
                                stoppedEarly = true
                            } else {
                                rowNumber = nextRow
                                rowHeightPoints = parser.getAttributeValue(null, "ht")?.toFloatOrNull()
                                cells = linkedMapOf()
                                maxRow = maxOf(maxRow, rowNumber)
                            }
                        }
                        "c" -> {
                            cellRef = parser.getAttributeValue(null, "r").orEmpty()
                            cellType = parser.getAttributeValue(null, "t")
                            cellStyleIndex = parser.getAttributeValue(null, "s")?.toIntOrNull() ?: 0
                            value = StringBuilder()
                            inline = StringBuilder()
                            formula = StringBuilder()
                        }
                        "v" -> captureValue = true
                        "t" -> captureInline = true
                        "f" -> captureFormula = true
                    }
                    XmlPullParser.TEXT -> {
                        if (captureValue) value.append(parser.text.orEmpty())
                        if (captureInline) inline.append(parser.text.orEmpty())
                        if (captureFormula) formula.append(parser.text.orEmpty())
                    }
                    XmlPullParser.END_TAG -> when (parser.name) {
                        "v" -> captureValue = false
                        "t" -> captureInline = false
                        "f" -> captureFormula = false
                        "c" -> {
                            val col = excelColumnIndex(cellRef)
                            if (col >= 0) {
                                val raw = value.toString()
                                val style = styles.getOrNull(cellStyleIndex)
                                val shown = when (cellType) {
                                    "s" -> shared.getOrNull(raw.toIntOrNull() ?: -1).orEmpty()
                                    "inlineStr", "str" -> inline.toString().ifBlank { raw }
                                    "b" -> if (raw == "1") "VERDADERO" else if (raw == "0") "FALSO" else raw
                                    else -> {
                                        val base = raw.ifBlank {
                                            formula.toString().takeIf { it.isNotBlank() }?.let { "=$it" }.orEmpty()
                                        }
                                        if (raw.isNotBlank()) formatExcelNumericValue(raw, style?.numberFormatCode) else base
                                    }
                                }
                                if (shown.isNotBlank() || cellStyleIndex != 0) {
                                    cells[col] = ExcelCellData(shown, cellStyleIndex)
                                }
                                maxColumn = maxOf(maxColumn, col + 1)
                            }
                        }
                        "row" -> if (rowNumber > 0) {
                            rows[rowNumber] = ExcelRowData(rowNumber, cells.toMap(), rowHeightPoints)
                        }
                    }
                }
                if (stoppedEarly) break
                event = parser.next()
            }
        }
        val totalHint = maxOf(declaredMaxRow, maxRow)
        val visibleRows = if (stoppedEarly && rowLimit != null) {
            maxOf(60, maxRow, minOf(totalHint.coerceAtLeast(rowLimit), rowLimit))
        } else {
            maxOf(60, totalHint, maxRow)
        }.coerceAtMost(200_000)
        return ExcelSheetData(
            rows = rows,
            maxColumns = maxOf(maxColumn, declaredMaxColumn).coerceAtLeast(1).coerceAtMost(256),
            maxRows = visibleRows,
            columnWidths = columnWidths.toMap(),
            totalRowsHint = totalHint.coerceAtLeast(visibleRows),
            isComplete = !stoppedEarly
        )
    }
}

private fun parseExcelStylesStream(
    input: java.io.InputStream,
    themeColors: Map<Int, Int>
): List<ExcelCellStyleModel> {
    data class FontStyle(val color: Int?, val bold: Boolean, val sizePt: Float?)
    val fonts = mutableListOf<FontStyle>()
    val fills = mutableListOf<Int?>()
    val styles = mutableListOf<ExcelCellStyleModel>()
    val customNumFormats = mutableMapOf<Int, String>()
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    var fontsDepth = -1
    var fillsDepth = -1
    var cellXfsDepth = -1
    var fontDepth = -1
    var fillDepth = -1
    var xfDepth = -1
    var fontColor: Int? = null
    var fontBold = false
    var fontSizePt: Float? = null
    var fillColor: Int? = null
    var fillPattern: String? = null
    var xfFontId = 0
    var xfFillId = 0
    var xfNumFmtId = 0
    var xfHorizontal: String? = null
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> when (parser.name) {
                "numFmt" -> {
                    val id = parser.getAttributeValue(null, "numFmtId")?.toIntOrNull()
                    val code = parser.getAttributeValue(null, "formatCode")
                    if (id != null && !code.isNullOrBlank()) customNumFormats[id] = code
                }
                "fonts" -> fontsDepth = parser.depth
                "fills" -> fillsDepth = parser.depth
                "cellXfs" -> cellXfsDepth = parser.depth
                "font" -> if (fontsDepth > 0 && parser.depth == fontsDepth + 1) {
                    fontDepth = parser.depth
                    fontColor = null
                    fontBold = false
                    fontSizePt = null
                }
                "b" -> if (fontDepth > 0) fontBold = true
                "sz" -> if (fontDepth > 0) {
                    fontSizePt = parser.getAttributeValue(null, "val")?.toFloatOrNull() ?: fontSizePt
                }
                "color" -> if (fontDepth > 0) {
                    fontColor = parseExcelStyleColor(parser, themeColors) ?: fontColor
                }
                "fill" -> if (fillsDepth > 0 && parser.depth == fillsDepth + 1) {
                    fillDepth = parser.depth
                    fillColor = null
                    fillPattern = null
                }
                "patternFill" -> if (fillDepth > 0) {
                    fillPattern = parser.getAttributeValue(null, "patternType")
                }
                "fgColor" -> if (fillDepth > 0) {
                    fillColor = parseExcelStyleColor(parser, themeColors) ?: fillColor
                }
                "xf" -> if (cellXfsDepth > 0 && parser.depth == cellXfsDepth + 1) {
                    xfDepth = parser.depth
                    xfFontId = parser.getAttributeValue(null, "fontId")?.toIntOrNull() ?: 0
                    xfFillId = parser.getAttributeValue(null, "fillId")?.toIntOrNull() ?: 0
                    xfNumFmtId = parser.getAttributeValue(null, "numFmtId")?.toIntOrNull() ?: 0
                    xfHorizontal = null
                }
                "alignment" -> if (xfDepth > 0) {
                    xfHorizontal = parser.getAttributeValue(null, "horizontal") ?: xfHorizontal
                }
            }
            XmlPullParser.END_TAG -> when {
                parser.name == "font" && parser.depth == fontDepth -> {
                    fonts += FontStyle(fontColor, fontBold, fontSizePt)
                    fontDepth = -1
                }
                parser.name == "fill" && parser.depth == fillDepth -> {
                    fills += fillColor.takeIf { fillPattern == "solid" }
                    fillDepth = -1
                }
                parser.name == "xf" && parser.depth == xfDepth -> {
                    val font = fonts.getOrNull(xfFontId)
                    styles += ExcelCellStyleModel(
                        fillArgb = fills.getOrNull(xfFillId),
                        textArgb = font?.color,
                        bold = font?.bold == true,
                        fontSizePt = font?.sizePt,
                        horizontal = xfHorizontal,
                        numberFormatCode = customNumFormats[xfNumFmtId] ?: builtInExcelNumberFormat(xfNumFmtId)
                    )
                    xfDepth = -1
                }
                parser.name == "fonts" && parser.depth == fontsDepth -> fontsDepth = -1
                parser.name == "fills" && parser.depth == fillsDepth -> fillsDepth = -1
                parser.name == "cellXfs" && parser.depth == cellXfsDepth -> cellXfsDepth = -1
            }
        }
        event = parser.next()
    }
    return styles.ifEmpty { listOf(ExcelCellStyleModel()) }
}

private fun parseOfficeThemeColorsStream(input: java.io.InputStream): Map<Int, Int> {
    // Orden de índices de tema definido por OOXML/Excel.
    val themeIndex = mapOf(
        "lt1" to 0, "dk1" to 1, "lt2" to 2, "dk2" to 3,
        "accent1" to 4, "accent2" to 5, "accent3" to 6,
        "accent4" to 7, "accent5" to 8, "accent6" to 9,
        "hlink" to 10, "folHlink" to 11
    )
    val colors = mutableMapOf<Int, Int>()
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    var currentIndex: Int? = null
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> {
                themeIndex[parser.name]?.let { currentIndex = it }
                if (parser.name == "srgbClr" || parser.name == "sysClr") {
                    val value = if (parser.name == "sysClr") {
                        parser.getAttributeValue(null, "lastClr") ?: parser.getAttributeValue(null, "val")
                    } else parser.getAttributeValue(null, "val")
                    val color = parseExcelArgb(value)
                    val index = currentIndex
                    if (color != null && index != null) colors[index] = color
                }
            }
            XmlPullParser.END_TAG -> if (themeIndex.containsKey(parser.name)) currentIndex = null
        }
        event = parser.next()
    }
    return colors
}

private fun parseExcelStyleColor(parser: XmlPullParser, themeColors: Map<Int, Int>): Int? {
    val direct = parseExcelArgb(parser.getAttributeValue(null, "rgb"))
    val themed = parser.getAttributeValue(null, "theme")?.toIntOrNull()?.let(themeColors::get)
    val indexed = parser.getAttributeValue(null, "indexed")?.toIntOrNull()?.let(::excelIndexedColor)
    val base = direct ?: themed ?: indexed ?: return null
    val tint = parser.getAttributeValue(null, "tint")?.toFloatOrNull() ?: 0f
    return applyExcelTint(base, tint)
}

private fun applyExcelTint(argb: Int, tint: Float): Int {
    if (tint == 0f) return argb
    fun tintChannel(value: Int): Int {
        val result = if (tint < 0f) value * (1f + tint) else value * (1f - tint) + 255f * tint
        return result.roundToInt().coerceIn(0, 255)
    }
    val a = (argb ushr 24) and 0xFF
    val r = tintChannel((argb ushr 16) and 0xFF)
    val g = tintChannel((argb ushr 8) and 0xFF)
    val b = tintChannel(argb and 0xFF)
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}

private fun excelIndexedColor(index: Int): Int? {
    val palette = intArrayOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt(), 0xFF00FF00.toInt(),
        0xFF0000FF.toInt(), 0xFFFFFF00.toInt(), 0xFFFF00FF.toInt(), 0xFF00FFFF.toInt(),
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF0000.toInt(), 0xFF00FF00.toInt(),
        0xFF0000FF.toInt(), 0xFFFFFF00.toInt(), 0xFFFF00FF.toInt(), 0xFF00FFFF.toInt(),
        0xFF800000.toInt(), 0xFF008000.toInt(), 0xFF000080.toInt(), 0xFF808000.toInt(),
        0xFF800080.toInt(), 0xFF008080.toInt(), 0xFFC0C0C0.toInt(), 0xFF808080.toInt(),
        0xFF9999FF.toInt(), 0xFF993366.toInt(), 0xFFFFFFCC.toInt(), 0xFFCCFFFF.toInt(),
        0xFF660066.toInt(), 0xFFFF8080.toInt(), 0xFF0066CC.toInt(), 0xFFCCCCFF.toInt(),
        0xFF000080.toInt(), 0xFFFF00FF.toInt(), 0xFFFFFF00.toInt(), 0xFF00FFFF.toInt(),
        0xFF800080.toInt(), 0xFF800000.toInt(), 0xFF008080.toInt(), 0xFF0000FF.toInt(),
        0xFF00CCFF.toInt(), 0xFFCCFFFF.toInt(), 0xFFCCFFCC.toInt(), 0xFFFFFF99.toInt(),
        0xFF99CCFF.toInt(), 0xFFFF99CC.toInt(), 0xFFCC99FF.toInt(), 0xFFFFCC99.toInt(),
        0xFF3366FF.toInt(), 0xFF33CCCC.toInt(), 0xFF99CC00.toInt(), 0xFFFFCC00.toInt(),
        0xFFFF9900.toInt(), 0xFFFF6600.toInt(), 0xFF666699.toInt(), 0xFF969696.toInt(),
        0xFF003366.toInt(), 0xFF339966.toInt(), 0xFF003300.toInt(), 0xFF333300.toInt(),
        0xFF993300.toInt(), 0xFF993366.toInt(), 0xFF333399.toInt(), 0xFF333333.toInt()
    )
    return palette.getOrNull(index)
}

private fun builtInExcelNumberFormat(id: Int): String? = when (id) {
    1 -> "0"
    2 -> "0.00"
    3 -> "#,##0"
    4 -> "#,##0.00"
    9 -> "0%"
    10 -> "0.00%"
    14 -> "mm-dd-yy"
    15 -> "d-mmm-yy"
    16 -> "d-mmm"
    17 -> "mmm-yy"
    18 -> "h:mm AM/PM"
    19 -> "h:mm:ss AM/PM"
    20 -> "h:mm"
    21 -> "h:mm:ss"
    22 -> "m/d/yy h:mm"
    else -> null
}

private fun formatExcelNumericValue(raw: String, formatCode: String?): String {
    val value = raw.toDoubleOrNull() ?: return raw
    val code = formatCode?.lowercase().orEmpty()
    if (code.isBlank()) return raw

    if ('%' in code) {
        val decimalPart = code.substringAfter('.', "").takeWhile { it == '0' || it == '#' }
        val decimals = decimalPart.count { it == '0' }.coerceIn(0, 6)
        return java.lang.String.format(java.util.Locale.US, "%.${decimals}f%%", value * 100.0)
    }

    if ((code.contains('y') || code.contains('d')) && (code.contains('m') || code.contains('y'))) {
        return runCatching {
            val wholeDays = kotlin.math.floor(value).toLong()
            val date = java.time.LocalDate.of(1899, 12, 30).plusDays(wholeDays)
            when {
                code.startsWith("yyyy-mm-dd") -> date.toString()
                code.contains("dd/mm/yyyy") -> "%02d/%02d/%04d".format(date.dayOfMonth, date.monthValue, date.year)
                else -> "%02d/%02d/%04d".format(date.dayOfMonth, date.monthValue, date.year)
            }
        }.getOrElse { raw }
    }

    val dot = code.indexOf('.')
    if (dot >= 0) {
        val decimals = code.substring(dot + 1).takeWhile { it == '0' || it == '#' }.count { it == '0' }.coerceIn(0, 8)
        if (decimals > 0) return java.lang.String.format(java.util.Locale.US, "%.${decimals}f", value)
    }
    if (code == "0" || code.contains("#,##0")) {
        return if (value % 1.0 == 0.0) value.toLong().toString() else raw
    }
    return raw
}

private fun parseExcelArgb(value: String?): Int? {
    val clean = value?.trim()?.removePrefix("#") ?: return null
    val raw = clean.toLongOrNull(16) ?: return null
    return when (clean.length) {
        6 -> (0xFF000000L or raw).toInt()
        8 -> {
            val argb = raw.toInt()
            // Excel/OpenPyXL suele escribir 00RRGGBB aunque el color sea opaco.
            if (((argb ushr 24) and 0xFF) == 0) (argb or 0xFF000000.toInt()) else argb
        }
        else -> null
    }
}

private fun parsePptxDeck(file: File): PowerPointDeckModel {
    java.util.zip.ZipFile(file).use { zip ->
        val presentationEntry = zip.getEntry("ppt/presentation.xml") ?: error("El PPTX no contiene presentation.xml.")
        var width = 12192000L
        var height = 6858000L
        val slideRelIds = mutableListOf<String>()
        val parser = Xml.newPullParser()
        zip.getInputStream(presentationEntry).use { parser.setInput(it, "UTF-8")
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    when (parser.name) {
                        "sldSz" -> {
                            width = parser.getAttributeValue(null, "cx")?.toLongOrNull() ?: width
                            height = parser.getAttributeValue(null, "cy")?.toLongOrNull() ?: height
                        }
                        "sldId" -> relationshipIdAttribute(parser)?.let(slideRelIds::add)
                    }
                }
                event = parser.next()
            }
        }
        val presentationRels = parseZipRelationships(zip, "ppt/_rels/presentation.xml.rels", "ppt/presentation.xml")
        val orderedSlides = slideRelIds.mapNotNull { presentationRels[it] }.ifEmpty {
            zip.entries().asSequence().map { it.name }
                .filter { it.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
                .sortedBy { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
                .toList()
        }
        val slides = orderedSlides.mapIndexed { index, slideEntry ->
            parsePowerPointSlide(zip, slideEntry, width, height, index)
        }
        require(slides.isNotEmpty()) { "El PPTX no contiene diapositivas legibles." }
        return PowerPointDeckModel(width, height, slides)
    }
}

private fun parsePowerPointSlide(
    zip: java.util.zip.ZipFile,
    slideEntry: String,
    deckWidth: Long,
    deckHeight: Long,
    slideIndex: Int
): PowerPointSlideModel {
    val entry = zip.getEntry(slideEntry) ?: error("Diapositiva no encontrada.")
    val fileName = slideEntry.substringAfterLast('/')
    val relEntry = slideEntry.substringBeforeLast('/') + "/_rels/$fileName.rels"
    val rels = parseZipRelationships(zip, relEntry, slideEntry)
    val elements = mutableListOf<PowerPointElementModel>()
    var shapeKind: String? = null
    var shapeDepth = -1
    var text = StringBuilder()
    var relId: String? = null
    var x = 0L; var y = 0L; var w = 0L; var h = 0L
    var shapeFillArgb: Int? = null
    var textArgb: Int? = null
    var textFontSizePt: Float? = null
    var textBold = false
    var spPrDepth = -1
    var rPrDepth = -1
    var solidFillDepth = -1
    var lineDepth = -1
    var transition: String? = null
    var advanceAfterMs: Long? = null
    var transitionDepth = -1
    var backgroundArgb: Int? = null
    var bgDepth = -1
    var bgSolidFillDepth = -1

    val parser = Xml.newPullParser()
    zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    if (parser.name == "bg" && shapeKind == null) bgDepth = parser.depth
                    if (bgDepth > 0 && parser.name == "solidFill") bgSolidFillDepth = parser.depth
                    if (bgSolidFillDepth > 0 && parser.name == "srgbClr" && backgroundArgb == null) {
                        backgroundArgb = parseRgbArgb(parser.getAttributeValue(null, "val"))
                    }

                    if ((parser.name == "sp" || parser.name == "pic") && shapeKind == null) {
                        shapeKind = parser.name
                        shapeDepth = parser.depth
                        text = StringBuilder(); relId = null; x = 0; y = 0; w = 0; h = 0
                        shapeFillArgb = null; textArgb = null; textFontSizePt = null; textBold = false
                        spPrDepth = -1; rPrDepth = -1; solidFillDepth = -1; lineDepth = -1
                    } else if (parser.name == "transition" && shapeKind == null) {
                        transitionDepth = parser.depth
                        advanceAfterMs = parser.getAttributeValue(null, "advTm")?.toLongOrNull()
                    } else if (transitionDepth > 0 && parser.depth == transitionDepth + 1 && transition == null) {
                        transition = parser.name
                    }

                    if (shapeKind != null) {
                        when (parser.name) {
                            "spPr" -> spPrDepth = parser.depth
                            "rPr", "defRPr", "endParaRPr" -> {
                                rPrDepth = parser.depth
                                parser.getAttributeValue(null, "sz")?.toFloatOrNull()?.let { size ->
                                    if (textFontSizePt == null) textFontSizePt = size / 100f
                                }
                                val boldValue = parser.getAttributeValue(null, "b")
                                if (boldValue == "1" || boldValue.equals("true", true)) textBold = true
                            }
                            "ln" -> if (spPrDepth > 0) lineDepth = parser.depth
                            "solidFill" -> solidFillDepth = parser.depth
                            "srgbClr" -> {
                                val color = parseRgbArgb(parser.getAttributeValue(null, "val"))
                                if (color != null) {
                                    if (rPrDepth > 0) textArgb = textArgb ?: color
                                    else if (spPrDepth > 0 && solidFillDepth > 0 && lineDepth < 0) shapeFillArgb = shapeFillArgb ?: color
                                }
                            }
                            "t" -> text.append(parser.nextText())
                            "p" -> if (text.isNotEmpty() && text.last() != '\n') text.append('\n')
                            "off" -> {
                                x = parser.getAttributeValue(null, "x")?.toLongOrNull() ?: x
                                y = parser.getAttributeValue(null, "y")?.toLongOrNull() ?: y
                            }
                            "ext" -> {
                                w = parser.getAttributeValue(null, "cx")?.toLongOrNull() ?: w
                                h = parser.getAttributeValue(null, "cy")?.toLongOrNull() ?: h
                            }
                            "blip" -> relId = attributeByLocalName(parser, "embed") ?: relId
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "solidFill" -> {
                            if (parser.depth == solidFillDepth) solidFillDepth = -1
                            if (parser.depth == bgSolidFillDepth) bgSolidFillDepth = -1
                        }
                        "spPr" -> if (parser.depth == spPrDepth) spPrDepth = -1
                        "ln" -> if (parser.depth == lineDepth) lineDepth = -1
                        "rPr", "defRPr", "endParaRPr" -> if (parser.depth == rPrDepth) rPrDepth = -1
                        "bg" -> if (parser.depth == bgDepth) bgDepth = -1
                    }
                    if (transitionDepth > 0 && parser.name == "transition" && parser.depth == transitionDepth) transitionDepth = -1
                    if (shapeKind != null && parser.depth == shapeDepth && parser.name == shapeKind) {
                        val fallbackIndex = elements.size
                        val finalX = if (w > 0) x else deckWidth / 12
                        val finalY = if (h > 0) y else deckHeight / 12 + fallbackIndex * (deckHeight / 7)
                        val finalW = if (w > 0) w else deckWidth * 5 / 6
                        val finalH = if (h > 0) h else deckHeight / 6
                        when (shapeKind) {
                            "sp" -> {
                                shapeFillArgb?.let { elements += PowerPointElementModel.Rectangle(it, finalX, finalY, finalW, finalH) }
                                text.toString().trim().takeIf { it.isNotBlank() }?.let {
                                    elements += PowerPointElementModel.TextBox(it, textArgb, textFontSizePt, textBold, finalX, finalY, finalW, finalH)
                                }
                            }
                            "pic" -> relId?.let { rels[it] }?.let {
                                elements += PowerPointElementModel.Picture(it, finalX, finalY, finalW, finalH)
                            }
                        }
                        shapeKind = null
                        shapeDepth = -1
                    }
                }
            }
            event = parser.next()
        }
    }
    if (elements.isEmpty()) {
        elements += PowerPointElementModel.TextBox(
            "Diapositiva ${slideIndex + 1}", null, 24f, true,
            deckWidth / 10, deckHeight / 3, deckWidth * 4 / 5, deckHeight / 4
        )
    }
    return PowerPointSlideModel(elements, transition, advanceAfterMs, backgroundArgb)
}

private fun parseRgbArgb(value: String?): Int? {
    val clean = value?.trim()?.removePrefix("#") ?: return null
    if (clean.length != 6) return null
    val rgb = clean.toLongOrNull(16) ?: return null
    return (0xFF000000L or rgb).toInt()
}

private fun invertArgb(argb: Int): Int {
    val a = (argb ushr 24) and 0xFF
    val r = 255 - ((argb ushr 16) and 0xFF)
    val g = 255 - ((argb ushr 8) and 0xFF)
    val b = 255 - (argb and 0xFF)
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}

private fun pptIsDark(argb: Int): Boolean {
    val r = (argb ushr 16) and 0xFF
    val g = (argb ushr 8) and 0xFF
    val b = argb and 0xFF
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) < 145.0
}

private fun parseZipRelationships(
    zip: java.util.zip.ZipFile,
    relEntryName: String,
    sourceEntryName: String
): Map<String, String> {
    val entry = zip.getEntry(relEntryName) ?: return emptyMap()
    val result = linkedMapOf<String, String>()
    val parser = Xml.newPullParser()
    zip.getInputStream(entry).use { parser.setInput(it, "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "Relationship") {
                val id = parser.getAttributeValue(null, "Id").orEmpty()
                val target = parser.getAttributeValue(null, "Target").orEmpty()
                val mode = parser.getAttributeValue(null, "TargetMode")
                if (id.isNotBlank() && target.isNotBlank() && !mode.equals("External", true)) {
                    result[id] = resolveZipTarget(sourceEntryName, target)
                }
            }
            event = parser.next()
        }
    }
    return result
}

private fun resolveZipTarget(sourceEntryName: String, target: String): String {
    if (target.startsWith('/')) return target.removePrefix("/")
    val base = sourceEntryName.substringBeforeLast('/', "")
    val combined = if (base.isBlank()) target else "$base/$target"
    val parts = mutableListOf<String>()
    combined.split('/').forEach { part ->
        when (part) {
            "", "." -> Unit
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
            else -> parts += part
        }
    }
    return parts.joinToString("/")
}

private fun attributeByLocalName(parser: XmlPullParser, localName: String): String? {
    for (index in 0 until parser.attributeCount) {
        if (parser.getAttributeName(index) == localName) return parser.getAttributeValue(index)
    }
    return null
}

private fun relationshipIdAttribute(parser: XmlPullParser): String? {
    // OOXML nodes such as p:sldId contain both a numeric `id` and an `r:id`.
    // Prefer the relationships namespace/prefix so slide/sheet ordering resolves correctly.
    for (index in 0 until parser.attributeCount) {
        val name = parser.getAttributeName(index)
        if (name != "id" && name != "r:id") continue
        val namespace = runCatching { parser.getAttributeNamespace(index) }.getOrNull().orEmpty()
        if (namespace.contains("relationships", ignoreCase = true) || name == "r:id") {
            return parser.getAttributeValue(index)
        }
    }
    // Most producers use rIdN. This fallback also works if namespace processing is disabled.
    for (index in 0 until parser.attributeCount) {
        val value = parser.getAttributeValue(index).orEmpty()
        if (value.startsWith("rId", ignoreCase = true)) return value
    }
    return null
}

private fun parseSharedStringsStream(input: java.io.InputStream): List<String> {
    val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
    val values = mutableListOf<String>()
    var insideSi = false
    var current = StringBuilder()
    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> if (parser.name == "si") { insideSi = true; current = StringBuilder() }
            XmlPullParser.TEXT -> if (insideSi) current.append(parser.text.orEmpty())
            XmlPullParser.END_TAG -> if (parser.name == "si") { values += current.toString(); insideSi = false }
        }
        event = parser.next()
    }
    return values
}

private fun excelColumnIndex(cellRef: String): Int {
    var result = 0
    var found = false
    for (char in cellRef) {
        if (!char.isLetter()) break
        found = true
        result = result * 26 + (char.uppercaseChar() - 'A' + 1)
    }
    return if (found) result - 1 else -1
}

private fun excelColumnName(index: Int): String {
    var value = index + 1
    val out = StringBuilder()
    while (value > 0) {
        val rem = (value - 1) % 26
        out.append(('A'.code + rem).toChar())
        value = (value - 1) / 26
    }
    return out.reverse().toString()
}


private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
