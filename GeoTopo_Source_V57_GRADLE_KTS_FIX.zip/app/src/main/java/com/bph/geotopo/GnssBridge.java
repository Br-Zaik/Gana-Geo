package com.bph.geotopo;

import android.location.LocationManager;

/** API-neutral bridge so Android 6 can load the GNSS quality screen safely. */
interface GnssBridge {
    void start(LocationManager manager) throws SecurityException;
    void stop(LocationManager manager);

    interface Sink {
        void onSatellites(int visible, int used, double averageCn0, String constellationSummary);
        void onNmea(String sentence);
    }
}
