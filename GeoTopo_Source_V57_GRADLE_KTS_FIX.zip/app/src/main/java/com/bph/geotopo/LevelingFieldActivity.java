package com.bph.geotopo;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LevelingFieldActivity extends BaseToolActivity {
    private static final int REQ_EXPORT = 9520;
    private EditText startElevation, expectedEnd;
    private LinearLayout rowsContainer;
    private final List<LevelRow> rows = new ArrayList<>();
    private TextView result;
    private String lastCsv;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        LinearLayout root = page("Nivelación de campo", "Método de altura de instrumento con control de cierre");
        LinearLayout content = vertical();
        LinearLayout box = card();
        box.addView(sectionTitle("Datos iniciales"));
        box.addView(small("En cada punto usa VA (vista atrás), VI (vista intermedia) o VD (vista adelante). En un punto de cambio puedes colocar VD y VA en la misma fila."));
        LinearLayout initial = horizontal();
        startElevation = numberInput("Cota BM"); expectedEnd = numberInput("Opcional");
        initial.addView(labeled("Cota inicial", startElevation), weight());
        initial.addView(labeled("Cota final conocida", expectedEnd), weight());
        box.addView(initial);

        rowsContainer = vertical(); box.addView(rowsContainer);
        for (int i = 0; i < 5; i++) addRow();

        LinearLayout actions = horizontal();
        Button add = secondaryButton("+ Punto"); add.setOnClickListener(v -> addRow()); actions.addView(add, weight());
        Button remove = secondaryButton("− Punto"); remove.setOnClickListener(v -> removeRow()); actions.addView(remove, weight());
        Button clear = secondaryButton("Limpiar"); clear.setOnClickListener(v -> clear()); actions.addView(clear, weight());
        box.addView(actions);
        Button calc = primaryButton("Calcular nivelación"); calc.setOnClickListener(v -> calculate()); box.addView(calc);
        Button export = secondaryButton("Exportar tabla CSV"); export.setOnClickListener(v -> export()); box.addView(export);
        result = resultBox("Cálculo pendiente."); box.addView(result);
        content.addView(box);
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private void addRow() {
        int i = rows.size() + 1;
        LinearLayout group = vertical();
        LinearLayout row1 = horizontal();
        TextView idx = text(String.valueOf(i), 13, true); idx.setGravity(Gravity.CENTER);
        row1.addView(idx, new LinearLayout.LayoutParams(dp(32), dp(52)));
        EditText point = textInput(i == 1 ? "BM-1" : "P" + (i - 1));
        EditText distance = numberInput("m");
        row1.addView(labeled("Punto", point), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f));
        row1.addView(labeled("Dist. acumulada", distance), weight());
        group.addView(row1);
        LinearLayout row2 = horizontal();
        EditText bs = numberInput("VA"); EditText is = numberInput("VI"); EditText fs = numberInput("VD");
        row2.addView(labeled("VA", bs), weight()); row2.addView(labeled("VI", is), weight()); row2.addView(labeled("VD", fs), weight());
        group.addView(row2);
        rows.add(new LevelRow(group, point, distance, bs, is, fs));
        rowsContainer.addView(group);
        rowsContainer.addView(divider());
    }

    private void removeRow() {
        if (rows.size() <= 2) { showToast("Conserva al menos dos puntos."); return; }
        int lastIndex = rowsContainer.getChildCount() - 1;
        if (lastIndex >= 0) rowsContainer.removeViewAt(lastIndex);
        LevelRow row = rows.remove(rows.size() - 1);
        rowsContainer.removeView(row.container);
    }

    private void clear() {
        for (LevelRow r : rows) {
            r.point.setText(""); r.distance.setText(""); r.bs.setText(""); r.is.setText(""); r.fs.setText("");
        }
        result.setText("Cálculo pendiente."); lastCsv = null;
    }

    private void calculate() {
        try {
            double start = parse(startElevation);
            double currentElevation = start;
            double hi = Double.NaN;
            double sumBS = 0, sumFS = 0;
            List<Computed> computed = new ArrayList<>();
            double lastDistance = 0;

            for (int i = 0; i < rows.size(); i++) {
                LevelRow r = rows.get(i);
                boolean hasBS = !blank(r.bs), hasIS = !blank(r.is), hasFS = !blank(r.fs);
                if (!hasBS && !hasIS && !hasFS) continue;
                if (hasIS && hasFS) throw new IllegalArgumentException();
                if (hasBS && hasIS) throw new IllegalArgumentException();
                String point = r.point.getText().toString().trim();
                if (point.isEmpty()) point = "P" + (i + 1);
                double distance = blank(r.distance) ? lastDistance : parse(r.distance);
                if (distance < lastDistance) throw new IllegalArgumentException();
                lastDistance = distance;

                Double bs = hasBS ? parse(r.bs) : null;
                Double is = hasIS ? parse(r.is) : null;
                Double fs = hasFS ? parse(r.fs) : null;

                // Read the point with the current instrument first.
                if (fs != null || is != null) {
                    if (Double.isNaN(hi)) throw new IllegalArgumentException();
                    double reading = fs != null ? fs : is;
                    currentElevation = hi - reading;
                    if (fs != null) sumFS += fs;
                }

                // First row or change point: establish a new instrument height from this point.
                if (bs != null) {
                    hi = currentElevation + bs;
                    sumBS += bs;
                }

                computed.add(new Computed(point, distance, bs, is, fs, hi, currentElevation));
            }
            if (computed.size() < 2 || Double.isNaN(hi)) throw new IllegalArgumentException();

            double finalElevation = computed.get(computed.size() - 1).elevation;
            double arithmetic = sumBS - sumFS;
            double observedDifference = finalElevation - start;
            boolean hasKnownEnd = !blank(expectedEnd);
            double closure = hasKnownEnd ? finalElevation - parse(expectedEnd) : 0;
            double totalDistance = computed.get(computed.size() - 1).distance;

            StringBuilder report = new StringBuilder();
            report.append("ΣVA: ").append(f3(sumBS)).append(" m · ΣVD: ").append(f3(sumFS)).append(" m\n");
            report.append("ΣVA − ΣVD: ").append(signed(arithmetic)).append(" m\n");
            report.append("Cota final − inicial: ").append(signed(observedDifference)).append(" m\n");
            report.append("Control aritmético: ").append(Math.abs(arithmetic - observedDifference) <= 0.001 ? "CORRECTO" : "REVISAR").append('\n');
            report.append("Cota final observada: ").append(f3(finalElevation)).append(" m");
            if (hasKnownEnd) report.append("\nError de cierre: ").append(signed(closure)).append(" m");

            StringBuilder csv = new StringBuilder("punto,distancia,VA,VI,VD,HI,cota_observada,correccion,cota_ajustada\n");
            report.append("\n\nPUNTOS:");
            int count = computed.size();
            for (int i = 0; i < count; i++) {
                Computed c = computed.get(i);
                double ratio;
                if (totalDistance > 0) ratio = c.distance / totalDistance;
                else ratio = count <= 1 ? 0 : (double) i / (count - 1);
                double correction = hasKnownEnd ? -closure * ratio : 0;
                double adjusted = c.elevation + correction;
                report.append("\n").append(c.point).append(": cota ").append(f3(c.elevation));
                if (hasKnownEnd) report.append(" → ajustada ").append(f3(adjusted));
                csv.append(csvCell(c.point)).append(',').append(f3(c.distance)).append(',')
                        .append(value(c.bs)).append(',').append(value(c.is)).append(',').append(value(c.fs)).append(',')
                        .append(Double.isNaN(c.hi) ? "" : f3(c.hi)).append(',').append(f3(c.elevation)).append(',')
                        .append(f3(correction)).append(',').append(f3(adjusted)).append('\n');
            }
            result.setText(report.toString()); lastCsv = csv.toString();
        } catch (Exception e) {
            result.setText("Revisa la libreta: inicia con una VA sobre la cota conocida; usa VI o VD para leer puntos y VA+VD en la misma fila para un punto de cambio.");
            lastCsv = null;
        }
    }

    private String value(Double d) { return d == null ? "" : f3(d); }
    private String csvCell(String v) { return '"' + v.replace("\"", "\"\"") + '"'; }

    private void export() {
        if (lastCsv == null) calculate(); if (lastCsv == null) return;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/csv");
        i.putExtra(Intent.EXTRA_TITLE, "GeoTopo_Nivelacion_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".csv");
        startActivityForResult(i, REQ_EXPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT && resultCode == RESULT_OK && data != null && data.getData() != null && lastCsv != null) {
            try {
                ContentResolver resolver = getContentResolver(); Uri uri = data.getData(); OutputStream out = resolver.openOutputStream(uri);
                if (out == null) throw new IllegalStateException(); out.write(lastCsv.getBytes(StandardCharsets.UTF_8)); out.close(); showToast("Nivelación exportada.");
            } catch (Exception e) { showToast("No se pudo exportar."); }
        }
    }

    private static class LevelRow {
        final LinearLayout container; final EditText point, distance, bs, is, fs;
        LevelRow(LinearLayout c, EditText p, EditText d, EditText b, EditText i, EditText f) { container=c; point=p; distance=d; bs=b; is=i; fs=f; }
    }
    private static class Computed {
        final String point; final double distance; final Double bs, is, fs; final double hi, elevation;
        Computed(String p, double d, Double b, Double i, Double f, double h, double e) { point=p; distance=d; bs=b; is=i; fs=f; hi=h; elevation=e; }
    }
}
