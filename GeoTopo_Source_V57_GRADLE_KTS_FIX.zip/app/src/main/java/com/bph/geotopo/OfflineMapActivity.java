package com.bph.geotopo;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class OfflineMapActivity extends BaseToolActivity {
    private static final int REQ_IMPORT = 9590;
    private static final int REQ_LOCATION = 9591;
    private static final String KEY_PATH = "offline_mbtiles_path";
    private static final String KEY_NAME = "offline_mbtiles_name";

    private MapView mapView;
    private MapLibreMap map;
    private TextView status;
    private final MbtilesServer server = new MbtilesServer();
    private Marker locationMarker;
    private LocationManager locationManager;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette(); MapLibre.getInstance(this); locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        LinearLayout root = page("Mapas sin internet", "Paquetes ráster MBTiles propios o autorizados");
        LinearLayout controls = card();
        controls.addView(small("Importa un archivo MBTiles ráster (PNG, JPG o WEBP). GeoTopo lo copia al almacenamiento privado y lo abre sin internet mediante un servidor local dentro del teléfono."));
        controls.addView(warning("GeoTopo no descarga masivamente desde OpenStreetMap u otros servidores públicos. Debes usar un paquete creado por ti o cuyo proveedor permita almacenamiento offline y conservar su atribución."));
        LinearLayout buttons = horizontal();
        Button importButton = primaryButton("Importar MBTiles"); importButton.setOnClickListener(v -> chooseFile()); buttons.addView(importButton, weight());
        Button location = secondaryButton("Mi ubicación"); location.setOnClickListener(v -> centerLocation()); buttons.addView(location, weight());
        Button delete = secondaryButton("Eliminar mapa"); delete.setOnClickListener(v -> deleteCurrent()); buttons.addView(delete, weight());
        controls.addView(buttons);
        status = resultBox("No hay mapa offline cargado."); controls.addView(status);
        root.addView(controls);

        mapView = new MapView(this);
        mapView.onCreate(savedInstanceState);
        root.addView(mapView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        mapView.getMapAsync(m -> {
            map = m;
            map.getUiSettings().setAttributionEnabled(false);
            map.getUiSettings().setLogoEnabled(false);
            loadRemembered();
        });
    }

    private void chooseFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK && data != null && data.getData() != null) importFile(data.getData());
    }

    private void importFile(Uri uri) {
        status.setText("Copiando y verificando paquete MBTiles...");
        new Thread(() -> {
            try {
                File dir = new File(getFilesDir(), "offline_maps");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("No se pudo crear la carpeta de mapas");

                String selectedName = displayName(uri);
                if (!selectedName.toLowerCase().endsWith(".mbtiles")) selectedName += ".mbtiles";
                final String originalName = selectedName;
                final File target = new File(dir, "current.mbtiles");

                try (InputStream in = getContentResolver().openInputStream(uri);
                     FileOutputStream out = new FileOutputStream(target)) {
                    if (in == null) throw new IllegalStateException("No se pudo abrir el archivo seleccionado");
                    byte[] buffer = new byte[1024 * 128];
                    int read;
                    while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                    out.flush();
                }

                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putString(KEY_PATH, target.getAbsolutePath())
                        .putString(KEY_NAME, originalName)
                        .apply();
                runOnUiThread(() -> openMap(target, originalName));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("No se pudo importar el archivo. Debe ser un MBTiles ráster válido: " + e.getMessage()));
            }
        }, "GeoTopo-MBTiles-Import").start();
    }

    private String displayName(Uri uri) {
        String name = null;
        Cursor c = getContentResolver().query(uri, null, null, null, null);
        if (c != null) {
            try { if (c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = c.getString(i); } }
            finally { c.close(); }
        }
        return name == null || name.trim().isEmpty() ? "mapa.mbtiles" : name;
    }

    private void loadRemembered() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        String path = sp.getString(KEY_PATH, ""); String name = sp.getString(KEY_NAME, "Mapa MBTiles");
        File file = path.isEmpty() ? null : new File(path);
        if (file != null && file.isFile()) openMap(file, name);
        else setEmptyStyle();
    }

    private void openMap(File file, String fileName) {
        if (map == null) return;
        try {
            server.start(file);
            String url = "http://127.0.0.1:" + server.getPort() + "/tiles/{z}/{x}/{y}." + server.getFormat();
            String style = "{\"version\":8,\"sources\":{\"offline\":{\"type\":\"raster\",\"tiles\":[\"" + url
                    + "\"],\"tileSize\":256,\"minzoom\":" + server.getMinZoom() + ",\"maxzoom\":" + server.getMaxZoom()
                    + "}},\"layers\":[{\"id\":\"background\",\"type\":\"background\",\"paint\":{\"background-color\":\"#e8edf1\"}},{\"id\":\"offline\",\"type\":\"raster\",\"source\":\"offline\",\"paint\":{\"raster-fade-duration\":0}}]}";
            map.setStyle(new Style.Builder().fromJson(style), s -> {
                centerMetadata();
                status.setText("Mapa cargado: " + fileName + "\nNombre interno: " + server.getName()
                        + " · formato " + server.getFormat().toUpperCase() + " · zoom " + server.getMinZoom() + "–" + server.getMaxZoom()
                        + "\nAtribución del paquete: " + server.getAttribution());
            });
        } catch (Exception e) {
            status.setText("El archivo no se pudo abrir: " + e.getMessage());
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_PATH).remove(KEY_NAME).apply();
            setEmptyStyle();
        }
    }

    private void centerMetadata() {
        try {
            String center = server.getCenter();
            if (center != null) {
                String[] c = center.split(","); double lon = Double.parseDouble(c[0]); double lat = Double.parseDouble(c[1]); double zoom = c.length > 2 ? Double.parseDouble(c[2]) : server.getMinZoom() + 2;
                zoom = Math.max(server.getMinZoom(), Math.min(server.getMaxZoom(), zoom));
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), zoom)); return;
            }
            String bounds = server.getBounds();
            if (bounds != null) {
                String[] b = bounds.split(","); double lon = (Double.parseDouble(b[0]) + Double.parseDouble(b[2])) / 2; double lat = (Double.parseDouble(b[1]) + Double.parseDouble(b[3])) / 2;
                double zoom = Math.max(server.getMinZoom(), Math.min(server.getMaxZoom(), 5));
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), zoom));
            }
        } catch (Exception ignored) {}
    }

    private void setEmptyStyle() {
        if (map == null) return;
        String style = "{\"version\":8,\"sources\":{},\"layers\":[{\"id\":\"background\",\"type\":\"background\",\"paint\":{\"background-color\":\"#dfe7ed\"}}]}";
        map.setStyle(new Style.Builder().fromJson(style));
    }

    private void centerLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION); return;
        }
        try {
            Location gps = locationManager == null ? null : locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = locationManager == null ? null : locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location loc = gps == null ? net : (net == null || gps.getTime() >= net.getTime() ? gps : net);
            if (loc == null) { showToast("Todavía no hay una posición reciente."); return; }
            if (locationMarker != null) map.removeMarker(locationMarker);
            locationMarker = map.addMarker(new MarkerOptions().position(new LatLng(loc.getLatitude(), loc.getLongitude())).title("Mi ubicación aproximada"));
            double zoom = Math.max(server.getMinZoom(), Math.min(server.getMaxZoom(), 15));
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(loc.getLatitude(), loc.getLongitude()), zoom));
        } catch (SecurityException e) { showToast("No se pudo leer la ubicación."); }
    }

    private void deleteCurrent() {
        server.stop();
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE); String path = sp.getString(KEY_PATH, "");
        if (!path.isEmpty()) { File f = new File(path); if (f.isFile()) f.delete(); }
        sp.edit().remove(KEY_PATH).remove(KEY_NAME).apply(); status.setText("Mapa offline eliminado."); setEmptyStyle();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) centerLocation();
        else if (requestCode == REQ_LOCATION) showToast("Sin permiso no se puede centrar en tu ubicación.");
    }

    @Override protected void onStart() { super.onStart(); mapView.onStart(); }
    @Override protected void onResume() { super.onResume(); mapView.onResume(); }
    @Override protected void onPause() { mapView.onPause(); super.onPause(); }
    @Override protected void onStop() { mapView.onStop(); super.onStop(); }
    @Override public void onLowMemory() { super.onLowMemory(); mapView.onLowMemory(); }
    @Override protected void onDestroy() { server.stop(); mapView.onDestroy(); super.onDestroy(); }
    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState); }
}
