package com.bph.geotopo;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AreaActivity extends BaseToolActivity {
    private static final int REQ_EXPORT = 9501;
    private final List<Row> rows = new ArrayList<>();
    private LinearLayout rowContainer;
    private TextView result;
    private String lastCsv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        LinearLayout root = page("Área y perímetro", "Cálculo por coordenadas planas ordenadas");
        LinearLayout content = vertical();
        LinearLayout box = card();
        box.addView(sectionTitle("Vértices del terreno"));
        box.addView(small("Ingresa los puntos en orden alrededor del perímetro. El último se une automáticamente con el primero."));
        rowContainer = vertical();
        box.addView(rowContainer);
        for (int i = 0; i < 4; i++) addRow();

        LinearLayout buttons = horizontal();
        Button add = secondaryButton("+ Punto"); add.setOnClickListener(v -> addRow()); buttons.addView(add, weight());
        Button remove = secondaryButton("− Punto"); remove.setOnClickListener(v -> removeRow()); buttons.addView(remove, weight());
        Button clear = secondaryButton("Limpiar"); clear.setOnClickListener(v -> clearRows()); buttons.addView(clear, weight());
        box.addView(buttons);

        Button calc = primaryButton("Calcular terreno"); calc.setOnClickListener(v -> calculate()); box.addView(calc);
        Button export = secondaryButton("Exportar resultado CSV"); export.setOnClickListener(v -> exportCsv()); box.addView(export);
        result = resultBox("Área: —\nPerímetro: —"); box.addView(result);
        content.addView(box);
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private void addRow() {
        int index = rows.size() + 1;
        LinearLayout row = horizontal();
        TextView label = text("P" + index, 14, true);
        label.setGravity(Gravity.CENTER);
        row.addView(label, new LinearLayout.LayoutParams(dp(42), dp(52)));
        EditText north = numberInput("Norte");
        EditText east = numberInput("Este");
        row.addView(labeled("N", north), weight());
        row.addView(labeled("E", east), weight());
        rows.add(new Row(row, north, east));
        rowContainer.addView(row);
    }

    private void removeRow() {
        if (rows.size() <= 3) { showToast("Se necesitan al menos tres puntos."); return; }
        Row r = rows.remove(rows.size() - 1);
        rowContainer.removeView(r.container);
    }

    private void clearRows() {
        for (Row r : rows) { r.north.setText(""); r.east.setText(""); }
        result.setText("Área: —\nPerímetro: —");
        lastCsv = null;
    }

    private List<double[]> readPoints() {
        List<double[]> points = new ArrayList<>();
        for (Row r : rows) {
            String n = r.north.getText().toString().trim();
            String e = r.east.getText().toString().trim();
            if (n.isEmpty() && e.isEmpty()) continue;
            if (n.isEmpty() || e.isEmpty()) throw new IllegalArgumentException();
            points.add(new double[]{parse(r.north), parse(r.east)});
        }
        return points;
    }

    private void calculate() {
        try {
            List<double[]> p = readPoints();
            if (p.size() < 3) throw new IllegalArgumentException();
            double twice = 0, perimeter = 0;
            StringBuilder sides = new StringBuilder();
            StringBuilder csv = new StringBuilder("punto,norte,este,lado_siguiente,distancia,azimut,rumbo\n");
            for (int i = 0; i < p.size(); i++) {
                double[] a = p.get(i), b = p.get((i + 1) % p.size());
                twice += a[1] * b[0] - b[1] * a[0];
                double dn = b[0] - a[0], de = b[1] - a[1];
                double distance = Math.hypot(dn, de);
                double az = normalizeBearing(Math.toDegrees(Math.atan2(de, dn)));
                perimeter += distance;
                sides.append("\nP").append(i + 1).append("→P").append((i + 1) % p.size() + 1)
                        .append(": ").append(f3(distance)).append(" m · ").append(f4(az)).append("° · ").append(bearingToQuadrant(az));
                csv.append("P").append(i + 1).append(',').append(f3(a[0])).append(',').append(f3(a[1])).append(',')
                        .append("P").append((i + 1) % p.size() + 1).append(',').append(f3(distance)).append(',')
                        .append(f4(az)).append(',').append('"').append(bearingToQuadrant(az)).append('"').append('\n');
            }
            double area = Math.abs(twice) / 2.0;
            result.setText("Vértices: " + p.size() + "\nÁrea: " + f3(area) + " m²\nÁrea: " + f4(area / 10000.0)
                    + " ha\nPerímetro: " + f3(perimeter) + " m\nLados:" + sides);
            lastCsv = csv.toString();
        } catch (Exception e) {
            result.setText("Revisa los puntos. Se requieren al menos tres filas completas con Norte y Este.");
            lastCsv = null;
        }
    }

    private void exportCsv() {
        if (lastCsv == null) calculate();
        if (lastCsv == null) return;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_Terreno_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".csv");
        startActivityForResult(intent, REQ_EXPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT && resultCode == RESULT_OK && data != null && data.getData() != null && lastCsv != null) {
            try {
                ContentResolver resolver = getContentResolver();
                Uri uri = data.getData();
                OutputStream out = resolver.openOutputStream(uri);
                if (out == null) throw new IllegalStateException();
                out.write(lastCsv.getBytes(StandardCharsets.UTF_8));
                out.close();
                showToast("Resultado exportado.");
            } catch (Exception e) { showToast("No se pudo exportar el CSV."); }
        }
    }

    private static class Row {
        final LinearLayout container;
        final EditText north;
        final EditText east;
        Row(LinearLayout container, EditText north, EditText east) { this.container = container; this.north = north; this.east = east; }
    }
}
