package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/** Native field tools launcher with photographic cards and direct navigation. */
public class FieldToolsActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.fieldToolsHeader(this, v -> finish()));

        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 16), NativeUi.dp(this, 8),
                NativeUi.dp(this, 16), NativeUi.dp(this, 30));

        content.addView(NativeUi.simpleSectionHeader(this, "CAPTURA Y UBICACIÓN", null, null));
        add(content, "stakeout", "Replanteo de punto",
                "Coordenadas, dirección, distancia y tolerancia", StakeoutActivity.class);
        add(content, "track", "Registro de recorridos GPS",
                "Trayectos, distancia, tiempo y puntos", TrackActivity.class);
        add(content, "quality", "Calidad GNSS",
                "Satélites, precisión, constelaciones y NMEA", GnssQualityActivity.class);
        add(content, "external", "GNSS externo Bluetooth",
                "Receptores NMEA emparejados", ExternalGnssActivity.class);

        content.addView(NativeUi.simpleSectionHeader(this, "CÁLCULOS DE CAMPO", null, null));
        add(content, "cogo", "COGO directo e inverso",
                "Directa, inversa, intersecciones y offsets", CogoActivity.class);
        add(content, "area", "Área y perímetro",
                "Cálculo por vértices, lados y rumbos", AreaActivity.class);
        add(content, "traverse", "Poligonales",
                "Abierta, cerrada, cierres y Bowditch", TraverseActivity.class);
        add(content, "leveling", "Nivelación de campo",
                "Vista atrás, intermedia, adelante y ajuste", LevelingFieldActivity.class);
        add(content, "profile", "Perfiles y secciones",
                "Progresivas, cotas y pendientes", ProfileActivity.class);

        content.addView(NativeUi.simpleSectionHeader(this, "MAPAS Y ARCHIVOS", null, null));
        add(content, "offline", "Mapas sin internet",
                "Paquetes MBTiles propios o autorizados", OfflineMapActivity.class);
        add(content, "notebook", "Libreta de campo",
                "Puntos, códigos, cotas y observaciones", NotebookActivity.class);
        add(content, "exchange", "Importar y exportar",
                "CSV, GeoJSON, KML y respaldo JSON", DataExchangeActivity.class);

        page.addView(NativeUi.scroll(this, content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private void add(LinearLayout content, String imageKey, String title,
                     String subtitle, Class<?> target) {
        View card = NativeUi.fieldToolImageCard(this, imageKey, title, subtitle,
                v -> startActivity(new Intent(this, target)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 124));
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 14));
        content.addView(card, lp);
    }
}
