package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/** Native list of all calculators, replacing the old accordion launcher. */
public class CalculatorsActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "Cálculos topográficos",
                "Herramientas directas, sin menús desplegables", v -> finish(), null, null));

        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 16), NativeUi.dp(this, 14),
                NativeUi.dp(this, 16), NativeUi.dp(this, 26));
        add(content, "swap", "Conversor de unidades", "Longitud, área, volumen y más", v -> open(ConverterActivity.class));
        add(content, "compass", "Orientación y brújula", "Brújula magnética y orientación GPS", v -> openTool("compass"));
        add(content, "angle", "Azimut y rumbo", "Conversión de azimut, rumbo y contraazimut", v -> openTool("azimuth"));
        add(content, "triangle", "Coordenadas parciales", "Incrementos Norte, Sur, Este y Oeste", v -> openTool("coordinates"));
        add(content, "slope", "Distancia y pendiente", "Distancias horizontal, inclinada y desnivel", v -> openTool("distance"));
        add(content, "hair", "Distancia por dos hilos", "Cálculo estadimétrico por hilo superior e inferior", v -> openTool("two_hair"));
        add(content, "polygon", "Poligonal cerrada", "Cierre y coordenadas parciales", v -> openTool("polygon"));
        add(content, "level", "Nivelación", "Libreta y cálculo de cotas", v -> openTool("level"));
        add(content, "staff", "Nivelación con tres hilos", "Lecturas inferior, medio y superior", v -> openTool("stadia"));

        page.addView(NativeUi.scroll(this, content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private void add(LinearLayout content, String icon, String title, String subtitle, android.view.View.OnClickListener click) {
        android.view.View card = NativeUi.menuCard(this, icon, title, subtitle, click, 88);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 11));
        content.addView(card, lp);
    }

    private void open(Class<?> target) { startActivity(new Intent(this, target)); }
    private void openTool(String key) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("single_tool", key);
        startActivity(intent);
    }
}
