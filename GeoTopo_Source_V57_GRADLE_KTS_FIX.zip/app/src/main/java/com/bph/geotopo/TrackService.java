package com.bph.geotopo;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONArray;
import org.json.JSONObject;

/** Foreground service that records a GPS track while the user explicitly enables it. */
public class TrackService extends Service implements LocationListener {
    public static final String ACTION_START = "com.bph.geotopo.track.START";
    public static final String ACTION_PAUSE = "com.bph.geotopo.track.PAUSE";
    public static final String ACTION_RESUME = "com.bph.geotopo.track.RESUME";
    public static final String ACTION_STOP = "com.bph.geotopo.track.STOP";
    public static final String ACTION_UPDATE = "com.bph.geotopo.track.UPDATE";
    public static final String PREFS_TRACK = "geo_topo_track";
    public static final String KEY_POINTS = "points";
    public static final String KEY_RUNNING = "running";
    public static final String KEY_PAUSED = "paused";
    public static final String KEY_START = "start_time";
    public static final String KEY_DISTANCE = "distance";
    public static final String KEY_PAUSED_AT = "paused_at";
    public static final String KEY_PAUSED_TOTAL = "paused_total";
    public static final String KEY_END = "end_time";

    private static final String CHANNEL = "geotopo_track_channel";
    private static final int NOTIFICATION_ID = 4432;

    private LocationManager locationManager;
    private JSONArray points = new JSONArray();
    private Location lastAccepted;
    private boolean paused;
    private long startTime;
    private double totalDistance;
    private long pausedAt;
    private long pausedTotal;

    @Override public void onCreate() {
        super.onCreate();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopRecording();
            return START_NOT_STICKY;
        }
        if (ACTION_PAUSE.equals(action)) {
            if (!paused) pausedAt = System.currentTimeMillis();
            paused = true;
            saveState(true, true);
            updateNotification();
            broadcastUpdate(null);
            return START_STICKY;
        }
        if (ACTION_RESUME.equals(action)) {
            if (paused && pausedAt > 0) pausedTotal += Math.max(0, System.currentTimeMillis() - pausedAt);
            pausedAt = 0;
            paused = false;
            lastAccepted = null;
            saveState(true, false);
            updateNotification();
            broadcastUpdate(null);
            return START_STICKY;
        }
        startRecording(intent != null && intent.getBooleanExtra("reset", true));
        return START_STICKY;
    }

    private void startRecording(boolean reset) {
        SharedPreferences sp = getSharedPreferences(PREFS_TRACK, MODE_PRIVATE);
        if (reset) {
            points = new JSONArray();
            totalDistance = 0;
            startTime = System.currentTimeMillis();
            lastAccepted = null;
            pausedAt = 0;
            pausedTotal = 0;
            paused = false;
        } else {
            try { points = new JSONArray(sp.getString(KEY_POINTS, "[]")); } catch (Exception e) { points = new JSONArray(); }
            totalDistance = Double.longBitsToDouble(sp.getLong(KEY_DISTANCE, Double.doubleToLongBits(0)));
            startTime = sp.getLong(KEY_START, System.currentTimeMillis());
            pausedAt = sp.getLong(KEY_PAUSED_AT, 0L);
            pausedTotal = sp.getLong(KEY_PAUSED_TOTAL, 0L);
            paused = sp.getBoolean(KEY_PAUSED, false);
        }
        startForeground(NOTIFICATION_ID, buildNotification());
        saveState(true, paused);
        requestUpdates();
        broadcastUpdate(null);
    }

    private void requestUpdates() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopRecording();
            return;
        }
        try {
            boolean gpsEnabled = locationManager != null && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if (gpsEnabled) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this);
            } else if (locationManager != null && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2500L, 0f, this);
            }
        } catch (SecurityException ignored) {
            stopRecording();
        }
    }

    @Override public void onLocationChanged(Location location) {
        if (paused || location == null) return;
        if (location.hasAccuracy() && location.getAccuracy() > 50f) {
            broadcastUpdate(location);
            return;
        }
        boolean accept = lastAccepted == null;
        float segmentDistance = 0f;
        if (!accept) {
            segmentDistance = lastAccepted.distanceTo(location);
            long dt = Math.max(1L, location.getTime() - lastAccepted.getTime());
            float currentAcc = location.hasAccuracy() ? location.getAccuracy() : 10f;
            float previousAcc = lastAccepted.hasAccuracy() ? lastAccepted.getAccuracy() : 10f;
            float movementThreshold = Math.max(1.5f, Math.max(currentAcc, previousAcc) * 0.55f);
            double derivedSpeed = segmentDistance / (dt / 1000.0);
            if (derivedSpeed > 80.0) return; // Reject an implausible GNSS jump.
            accept = segmentDistance >= movementThreshold;
        }
        if (!accept) return;

        if (lastAccepted != null) totalDistance += segmentDistance;
        lastAccepted = new Location(location);
        try {
            JSONObject o = new JSONObject();
            o.put("lat", location.getLatitude());
            o.put("lon", location.getLongitude());
            o.put("alt", location.hasAltitude() ? location.getAltitude() : JSONObject.NULL);
            o.put("acc", location.hasAccuracy() ? location.getAccuracy() : JSONObject.NULL);
            o.put("time", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis());
            points.put(o);
        } catch (Exception ignored) {}
        saveState(true, paused);
        updateNotification();
        broadcastUpdate(location);
    }

    private void saveState(boolean running, boolean isPaused) {
        getSharedPreferences(PREFS_TRACK, MODE_PRIVATE).edit()
                .putString(KEY_POINTS, points.toString())
                .putBoolean(KEY_RUNNING, running)
                .putBoolean(KEY_PAUSED, isPaused)
                .putLong(KEY_START, startTime)
                .putLong(KEY_DISTANCE, Double.doubleToLongBits(totalDistance))
                .putLong(KEY_PAUSED_AT, pausedAt)
                .putLong(KEY_PAUSED_TOTAL, pausedTotal)
                .putLong(KEY_END, running ? 0L : System.currentTimeMillis())
                .apply();
    }

    private void stopRecording() {
        if (paused && pausedAt > 0) pausedTotal += Math.max(0, System.currentTimeMillis() - pausedAt);
        pausedAt = 0;
        paused = false;
        if (locationManager != null) {
            try { locationManager.removeUpdates(this); } catch (SecurityException ignored) {}
        }
        saveState(false, false);
        broadcastUpdate(null);
        stopForeground(true);
        stopSelf();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Registro de recorrido GeoTopo", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Muestra que GeoTopo está registrando ubicación por decisión del usuario.");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, TrackActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Intent stop = new Intent(this, TrackService.class); stop.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setContentTitle(paused ? "GeoTopo: recorrido pausado" : "GeoTopo está registrando el recorrido")
                .setContentText(String.format(java.util.Locale.US, "%.1f m · %d puntos", totalDistance, points.length()))
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true)
                .setContentIntent(content)
                .addAction(android.R.drawable.ic_media_pause, "Detener", stopPending);
        return b.build();
    }

    private void updateNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification());
    }

    private void broadcastUpdate(Location location) {
        Intent update = new Intent(ACTION_UPDATE);
        update.setPackage(getPackageName());
        update.putExtra("distance", totalDistance);
        update.putExtra("points", points.length());
        update.putExtra("start", startTime);
        update.putExtra("paused", paused);
        if (location != null) {
            update.putExtra("lat", location.getLatitude());
            update.putExtra("lon", location.getLongitude());
            update.putExtra("accuracy", location.hasAccuracy() ? location.getAccuracy() : -1f);
        }
        sendBroadcast(update);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) { broadcastUpdate(null); }
}
