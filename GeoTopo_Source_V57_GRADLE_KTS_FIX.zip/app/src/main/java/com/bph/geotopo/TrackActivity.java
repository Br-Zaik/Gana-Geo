package com.bph.geotopo;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TrackActivity extends BaseToolActivity {
    private static final int REQ_LOCATION = 9540;
    private static final int REQ_NOTIFICATION = 9541;
    private static final int REQ_EXPORT_CSV = 9542;
    private static final int REQ_EXPORT_GPX = 9543;

    private TextView result;
    private Button startButton;
    private Button pauseButton;
    private String pendingExport;
    private boolean receiverRegistered;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { refresh(); }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        LinearLayout root = page("Registro de recorrido GPS", "Seguimiento iniciado por el usuario con notificación permanente");
        LinearLayout content = vertical();
        LinearLayout box = card();
        box.addView(sectionTitle("Recorrido"));
        box.addView(small("Inicia el recorrido antes de caminar. Mientras esté activo, Android mostrará una notificación y GeoTopo seguirá registrando aun con la pantalla apagada."));
        box.addView(warning("La app no activa seguimiento oculto ni permanente. El registro solo funciona después de pulsar Iniciar y se detiene al pulsar Detener."));

        LinearLayout a1 = horizontal();
        startButton = primaryButton("Iniciar nuevo recorrido"); startButton.setOnClickListener(v -> startTrack()); a1.addView(startButton, weight());
        pauseButton = secondaryButton("Pausar"); pauseButton.setOnClickListener(v -> togglePause()); a1.addView(pauseButton, weight());
        box.addView(a1);
        Button stop = secondaryButton("Detener recorrido"); stop.setOnClickListener(v -> stopTrack()); box.addView(stop);

        LinearLayout a2 = horizontal();
        Button csv = secondaryButton("Exportar CSV"); csv.setOnClickListener(v -> export(false)); a2.addView(csv, weight());
        Button gpx = secondaryButton("Exportar GPX"); gpx.setOnClickListener(v -> export(true)); a2.addView(gpx, weight());
        Button clear = secondaryButton("Borrar recorrido"); clear.setOnClickListener(v -> clearTrack()); a2.addView(clear, weight());
        box.addView(a2);
        result = resultBox("No hay recorrido activo."); box.addView(result);
        content.addView(box);
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        refresh();
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(TrackService.ACTION_UPDATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
        receiverRegistered = true;
        refresh();
    }

    @Override protected void onStop() {
        super.onStop();
        if (receiverRegistered) { unregisterReceiver(receiver); receiverRegistered = false; }
    }

    private void startTrack() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
            return;
        }
        Intent i = new Intent(this, TrackService.class); i.setAction(TrackService.ACTION_START); i.putExtra("reset", true);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        showToast("Recorrido iniciado.");
        refreshDelayed();
    }

    private void togglePause() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        if (!sp.getBoolean(TrackService.KEY_RUNNING, false)) { showToast("No hay recorrido activo."); return; }
        boolean paused = sp.getBoolean(TrackService.KEY_PAUSED, false);
        Intent i = new Intent(this, TrackService.class); i.setAction(paused ? TrackService.ACTION_RESUME : TrackService.ACTION_PAUSE);
        startService(i);
        refreshDelayed();
    }

    private void stopTrack() {
        Intent i = new Intent(this, TrackService.class); i.setAction(TrackService.ACTION_STOP); startService(i);
        refreshDelayed();
    }

    private void refreshDelayed() { result.postDelayed(this::refresh, 350L); }

    private void refresh() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        boolean running = sp.getBoolean(TrackService.KEY_RUNNING, false);
        boolean paused = sp.getBoolean(TrackService.KEY_PAUSED, false);
        long start = sp.getLong(TrackService.KEY_START, 0L);
        long pausedAt = sp.getLong(TrackService.KEY_PAUSED_AT, 0L);
        long pausedTotal = sp.getLong(TrackService.KEY_PAUSED_TOTAL, 0L);
        double distance = Double.longBitsToDouble(sp.getLong(TrackService.KEY_DISTANCE, Double.doubleToLongBits(0)));
        JSONArray points;
        try { points = new JSONArray(sp.getString(TrackService.KEY_POINTS, "[]")); } catch (Exception e) { points = new JSONArray(); }
        long now = running ? System.currentTimeMillis() : sp.getLong(TrackService.KEY_END, System.currentTimeMillis());
        long currentPause = paused && pausedAt > 0 ? Math.max(0, now - pausedAt) : 0;
        long duration = start > 0 ? Math.max(0, now - start - pausedTotal - currentPause) : 0;
        double hours = duration / 3600000.0;
        double avg = hours > 0 ? distance / 1000.0 / hours : 0;
        String last = "—";
        if (points.length() > 0) {
            JSONObject p = points.optJSONObject(points.length() - 1);
            if (p != null) last = f7(p.optDouble("lat")) + ", " + f7(p.optDouble("lon"));
        }
        result.setText("Estado: " + (running ? (paused ? "PAUSADO" : "REGISTRANDO") : "DETENIDO")
                + "\nPuntos: " + points.length()
                + "\nDistancia: " + f2(distance) + " m"
                + "\nTiempo transcurrido: " + formatDuration(duration)
                + "\nVelocidad media aproximada: " + f2(avg) + " km/h"
                + "\nÚltima posición: " + last);
        pauseButton.setText(paused ? "Reanudar" : "Pausar");
        startButton.setEnabled(!running);
    }

    private String formatDuration(long millis) {
        long seconds = millis / 1000; long h = seconds / 3600; long m = (seconds % 3600) / 60; long s = seconds % 60;
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s);
    }

    private void clearTrack() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        if (sp.getBoolean(TrackService.KEY_RUNNING, false)) { showToast("Detén el recorrido antes de borrarlo."); return; }
        sp.edit().clear().apply(); refresh();
    }

    private void export(boolean gpx) {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        JSONArray points;
        try { points = new JSONArray(sp.getString(TrackService.KEY_POINTS, "[]")); } catch (Exception e) { points = new JSONArray(); }
        if (points.length() == 0) { showToast("No hay puntos para exportar."); return; }
        pendingExport = gpx ? buildGpx(points) : buildCsv(points);
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(gpx ? "application/gpx+xml" : "text/csv");
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
        i.putExtra(Intent.EXTRA_TITLE, "GeoTopo_Recorrido_" + stamp + (gpx ? ".gpx" : ".csv"));
        startActivityForResult(i, gpx ? REQ_EXPORT_GPX : REQ_EXPORT_CSV);
    }

    private String buildCsv(JSONArray points) {
        StringBuilder sb = new StringBuilder("indice,latitud,longitud,altitud,precision,fecha_hora\n");
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i); if (p == null) continue;
            sb.append(i + 1).append(',').append(f7(p.optDouble("lat"))).append(',').append(f7(p.optDouble("lon"))).append(',')
                    .append(p.isNull("alt") ? "" : f3(p.optDouble("alt"))).append(',')
                    .append(p.isNull("acc") ? "" : f1(p.optDouble("acc"))).append(',')
                    .append('"').append(df.format(new Date(p.optLong("time")))).append('"').append('\n');
        }
        return sb.toString();
    }

    private String buildGpx(JSONArray points) {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"GeoTopo\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n<trk><name>GeoTopo recorrido</name><trkseg>\n");
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        iso.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i); if (p == null) continue;
            sb.append("<trkpt lat=\"").append(f7(p.optDouble("lat"))).append("\" lon=\"").append(f7(p.optDouble("lon"))).append("\">");
            if (!p.isNull("alt")) sb.append("<ele>").append(f3(p.optDouble("alt"))).append("</ele>");
            sb.append("<time>").append(iso.format(new Date(p.optLong("time")))).append("</time></trkpt>\n");
        }
        return sb.append("</trkseg></trk></gpx>\n").toString();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQ_EXPORT_CSV || requestCode == REQ_EXPORT_GPX) && resultCode == RESULT_OK
                && data != null && data.getData() != null && pendingExport != null) {
            try {
                ContentResolver resolver = getContentResolver(); Uri uri = data.getData(); OutputStream out = resolver.openOutputStream(uri);
                if (out == null) throw new IllegalStateException(); out.write(pendingExport.getBytes(StandardCharsets.UTF_8)); out.close(); showToast("Recorrido exportado.");
            } catch (Exception e) { showToast("No se pudo exportar."); }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if ((requestCode == REQ_LOCATION || requestCode == REQ_NOTIFICATION) && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startTrack();
        else if (requestCode == REQ_LOCATION || requestCode == REQ_NOTIFICATION) showToast("Se necesitan los permisos para registrar el recorrido con una notificación visible.");
    }
}
