package com.bph.geotopo;

import android.content.Context;

import java.lang.reflect.Method;

/**
 * Ajustes conservadores del motor de mapas.
 *
 * La caché ambiental de MapLibre se amplía en disco (no RAM) para que las zonas
 * ya visitadas reaparezcan con menos peticiones de red. Se usa reflexión para
 * mantener compatibilidad entre versiones del SDK sin acoplar el proyecto a
 * una firma concreta de OfflineManager.
 */
public final class MapEngineConfig {
    private static final long AMBIENT_CACHE_BYTES = 256L * 1024L * 1024L;
    private static boolean configured;

    private MapEngineConfig() { }

    public static synchronized void configure(Context context) {
        if (configured || context == null) return;
        configured = true;
        try {
            Class<?> managerClass = Class.forName("org.maplibre.android.offline.OfflineManager");
            Method getInstance = managerClass.getMethod("getInstance", Context.class);
            Object manager = getInstance.invoke(null, context.getApplicationContext());
            if (manager == null) return;

            for (Method method : managerClass.getMethods()) {
                if (!"setMaximumAmbientCacheSize".equals(method.getName())) continue;
                Class<?>[] params = method.getParameterTypes();
                if (params.length == 1 && params[0] == long.class) {
                    method.invoke(manager, AMBIENT_CACHE_BYTES);
                    return;
                }
                if (params.length == 2 && params[0] == long.class) {
                    method.invoke(manager, AMBIENT_CACHE_BYTES, null);
                    return;
                }
            }
        } catch (Throwable ignored) {
            // La caché mayor es una optimización; nunca debe impedir abrir el mapa.
        }
    }
}
