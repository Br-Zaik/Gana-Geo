package com.bph.geotopo;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Shared visual helpers for GeoTopo field tools. */
public abstract class BaseToolActivity extends Activity {
    protected static final String PREFS = "geo_topo_prefs";

    protected int themeMode;
    protected int accent;
    protected int bgColor;
    protected int barColor;
    protected int cardColor;
    protected int textColor;
    protected int subTextColor;
    protected int inputColor;
    protected int borderColor;

    protected void applyPalette() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", 1);
        int accentIndex = sp.getInt("accent", 0);
        int[] accents = {
                Color.rgb(41, 121, 255), Color.rgb(0, 188, 212), Color.rgb(0, 150, 136),
                Color.rgb(0, 184, 148), Color.rgb(118, 210, 34), Color.rgb(255, 214, 10),
                Color.rgb(255, 171, 0), Color.rgb(255, 112, 20), Color.rgb(244, 67, 54),
                Color.rgb(255, 64, 129), Color.rgb(142, 68, 173), Color.rgb(92, 92, 210)
        };
        int normalizedAccent = ((accentIndex % accents.length) + accents.length) % accents.length;
        accent = accents[normalizedAccent];
        borderColor = accent;

        if (themeMode == 0) {
            bgColor = Color.rgb(241, 244, 248);
            barColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(96, 104, 118);
            inputColor = Color.WHITE;
        } else if (themeMode == 2) {
            bgColor = Color.BLACK;
            barColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputColor = Color.rgb(14, 16, 22);
        } else {
            bgColor = Color.rgb(7, 22, 36);
            barColor = Color.rgb(3, 45, 73);
            cardColor = Color.rgb(17, 38, 58);
            textColor = Color.rgb(248, 250, 252);
            subTextColor = Color.rgb(199, 211, 222);
            inputColor = Color.rgb(10, 29, 45);
        }
    }

    protected LinearLayout page(String title, String subtitle) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(topBar(title, subtitle));
        return root;
    }

    protected ScrollView scrollWith(LinearLayout content) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content.setPadding(dp(14), dp(12), dp(14), dp(30));
        content.setBackgroundColor(bgColor);
        scroll.addView(content);
        return scroll;
    }

    protected LinearLayout vertical() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    protected LinearLayout topBar(String titleValue, String subtitleValue) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(12), dp(8));
        bar.setBackgroundColor(barColor);

        Button back = new Button(this);
        back.setText("‹");
        back.setTextSize(30);
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(50), dp(50)));

        LinearLayout titles = vertical();
        TextView title = text(titleValue, 20, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        if (subtitleValue != null && !subtitleValue.isEmpty()) {
            TextView sub = text(subtitleValue, 12, false);
            sub.setTextColor(Color.rgb(215, 228, 240));
            titles.addView(sub);
        }
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return bar;
    }

    protected LinearLayout card() {
        LinearLayout box = vertical();
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), withAlpha(borderColor, 120));
        box.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(11));
        box.setLayoutParams(lp);
        return box;
    }

    protected View collapsibleCard(LinearLayout body, String iconText, String titleText, boolean open) {
        LinearLayout wrapper = card();
        wrapper.setPadding(dp(12), dp(10), dp(12), dp(12));
        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = text(iconText, 19, true);
        icon.setTextColor(borderColor);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable ibg = new GradientDrawable();
        ibg.setColor(withAlpha(borderColor, themeMode == 0 ? 24 : 38));
        ibg.setCornerRadius(dp(12));
        icon.setBackground(ibg);
        header.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView title = text(titleText, 18, true);
        title.setPadding(dp(10), 0, 0, 0);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView arrow = text(open ? "⌄" : "›", 28, true);
        arrow.setTextColor(subTextColor);
        arrow.setGravity(Gravity.CENTER);
        header.addView(arrow, new LinearLayout.LayoutParams(dp(42), dp(42)));
        body.setVisibility(open ? View.VISIBLE : View.GONE);
        header.setOnClickListener(v -> {
            boolean show = body.getVisibility() != View.VISIBLE;
            body.setVisibility(show ? View.VISIBLE : View.GONE);
            arrow.setText(show ? "⌄" : "›");
        });
        wrapper.addView(header);
        wrapper.addView(body);
        return wrapper;
    }

    protected LinearLayout menuCard(String iconText, String titleText, String description, View.OnClickListener listener) {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(12), dp(12), dp(8), dp(12));

        TextView icon = text(iconText, 20, true);
        icon.setTextColor(borderColor);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable ibg = new GradientDrawable();
        ibg.setColor(withAlpha(borderColor, themeMode == 0 ? 24 : 38));
        ibg.setCornerRadius(dp(12));
        icon.setBackground(ibg);
        box.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout labels = vertical();
        labels.setPadding(dp(11), 0, dp(5), 0);
        labels.addView(text(titleText, 17, true));
        TextView d = text(description, 12, false);
        d.setTextColor(subTextColor);
        d.setLineSpacing(0, 1.08f);
        labels.addView(d);
        box.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView arrow = text("›", 28, true);
        arrow.setTextColor(subTextColor);
        arrow.setGravity(Gravity.CENTER);
        box.addView(arrow, new LinearLayout.LayoutParams(dp(38), dp(46)));
        box.setOnClickListener(listener);
        return box;
    }

    protected TextView sectionTitle(String value) {
        TextView view = text(value, 17, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(5), 0, dp(6));
        view.setLayoutParams(lp);
        return view;
    }

    protected TextView categoryTitle(String value) {
        TextView view = text(value, 14, true);
        view.setTextColor(borderColor);
        view.setAllCaps(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(10), 0, dp(8));
        view.setLayoutParams(lp);
        return view;
    }

    protected TextView small(String value) {
        TextView view = text(value, 13, false);
        view.setTextColor(subTextColor);
        view.setLineSpacing(0, 1.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        view.setLayoutParams(lp);
        return view;
    }

    protected TextView warning(String value) {
        TextView view = small(value);
        view.setPadding(dp(10), dp(9), dp(10), dp(9));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(255, 248, 225) : Color.rgb(60, 47, 14));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(255, 171, 0));
        view.setBackground(bg);
        return view;
    }

    protected TextView success(String value) {
        TextView view = small(value);
        view.setPadding(dp(10), dp(9), dp(10), dp(9));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(236, 249, 241) : Color.rgb(9, 50, 42));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(0, 184, 105));
        view.setBackground(bg);
        return view;
    }

    protected TextView divider() {
        TextView line = new TextView(this);
        line.setBackgroundColor(withAlpha(borderColor, 90));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(0, dp(13), 0, dp(9));
        line.setLayoutParams(lp);
        return line;
    }

    protected LinearLayout horizontal() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        row.setLayoutParams(lp);
        return row;
    }

    protected LinearLayout labeled(String label, View child) {
        LinearLayout box = vertical();
        TextView title = text(label, 12, true);
        title.setTextColor(subTextColor);
        box.addView(title);
        box.addView(child, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), 0, dp(3), 0);
        box.setLayoutParams(lp);
        return box;
    }

    protected EditText numberInput(String hint) {
        EditText input = textInput(hint);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        return input;
    }

    protected EditText integerInput(String hint) {
        EditText input = textInput(hint);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        return input;
    }

    protected EditText textInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setHintTextColor(subTextColor);
        input.setTextColor(textColor);
        input.setTextSize(14);
        input.setSingleLine(true);
        input.setPadding(dp(10), 0, dp(10), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputColor);
        bg.setCornerRadius(dp(9));
        bg.setStroke(dp(1), withAlpha(borderColor, 150));
        input.setBackground(bg);
        return input;
    }

    protected TextView resultBox(String value) {
        TextView view = text(value, 14, false);
        view.setPadding(dp(11), dp(10), dp(11), dp(10));
        view.setLineSpacing(0, 1.12f);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(245, 250, 255) : Color.rgb(10, 31, 46));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), withAlpha(borderColor, 160));
        view.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(4));
        view.setLayoutParams(lp);
        return view;
    }

    protected Button primaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accent);
        bg.setCornerRadius(dp(10));
        button.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        lp.setMargins(dp(3), dp(2), dp(3), dp(4));
        button.setLayoutParams(lp);
        return button;
    }

    protected Button secondaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setTextSize(13);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputColor);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), borderColor);
        button.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        lp.setMargins(dp(3), dp(2), dp(3), dp(4));
        button.setLayoutParams(lp);
        return button;
    }

    protected TextView text(String value, int size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(textColor);
        view.setTextSize(size);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return view;
    }

    protected LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    protected double parse(EditText input) {
        return Double.parseDouble(input.getText().toString().trim().replace(',', '.'));
    }

    protected boolean blank(EditText input) {
        return input == null || input.getText().toString().trim().isEmpty();
    }

    protected double normalizeBearing(double value) {
        double result = value % 360.0;
        return result < 0 ? result + 360.0 : result;
    }

    protected String bearingToQuadrant(double azimuth) {
        double az = normalizeBearing(azimuth);
        if (az <= 90.0) return "N " + f4(az) + "° E";
        if (az <= 180.0) return "S " + f4(180.0 - az) + "° E";
        if (az <= 270.0) return "S " + f4(az - 180.0) + "° O";
        return "N " + f4(360.0 - az) + "° O";
    }

    protected String f1(double value) { return String.format(Locale.US, "%.1f", value); }
    protected String f2(double value) { return String.format(Locale.US, "%.2f", value); }
    protected String f3(double value) { return String.format(Locale.US, "%.3f", value); }
    protected String f4(double value) { return String.format(Locale.US, "%.4f", value); }
    protected String f7(double value) { return String.format(Locale.US, "%.7f", value); }
    protected String signed(double value) { return String.format(Locale.US, "%+.3f", value); }

    protected int withAlpha(int color, int alpha) {
        return Color.argb(Math.max(0, Math.min(255, alpha)), Color.red(color), Color.green(color), Color.blue(color));
    }

    protected int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    protected void showToast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_LONG).show();
    }
}
