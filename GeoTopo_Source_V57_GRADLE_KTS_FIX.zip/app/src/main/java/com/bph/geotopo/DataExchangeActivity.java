package com.bph.geotopo;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataExchangeActivity extends BaseToolActivity {
    private static final int REQ_IMPORT = 9580;
    private static final int REQ_EXPORT = 9581;
    private TextView status;
    private String pendingContent;
    private String pendingMime;
    private String pendingExtension;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        LinearLayout root = page("Importar y exportar", "Intercambio local de puntos de la libreta de campo");
        LinearLayout content = vertical();

        LinearLayout importCard = card();
        importCard.addView(sectionTitle("Importar puntos"));
        importCard.addView(small("Admite CSV, GeoJSON, KML y copia JSON de GeoTopo. Los puntos se agregan a la libreta local; los registros existentes no se eliminan."));
        Button importButton = primaryButton("Seleccionar archivo"); importButton.setOnClickListener(v -> openImport()); importCard.addView(importButton);
        content.addView(importCard);

        LinearLayout exportCard = card();
        exportCard.addView(sectionTitle("Exportar libreta completa"));
        LinearLayout r1 = horizontal();
        Button csv = secondaryButton("CSV"); csv.setOnClickListener(v -> prepareExport("csv")); r1.addView(csv, weight());
        Button geojson = secondaryButton("GeoJSON"); geojson.setOnClickListener(v -> prepareExport("geojson")); r1.addView(geojson, weight());
        exportCard.addView(r1);
        LinearLayout r2 = horizontal();
        Button kml = secondaryButton("KML"); kml.setOnClickListener(v -> prepareExport("kml")); r2.addView(kml, weight());
        Button json = secondaryButton("Copia JSON"); json.setOnClickListener(v -> prepareExport("json")); r2.addView(json, weight());
        exportCard.addView(r2);
        content.addView(exportCard);

        LinearLayout info = card();
        info.addView(sectionTitle("Estado"));
        status = resultBox("Puntos actuales: " + NotebookStore.load(this).size()); info.addView(status);
        content.addView(info);

        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)); setContentView(root);
    }

    private void openImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/csv", "application/json", "application/geo+json", "application/vnd.google-earth.kml+xml", "text/xml", "application/xml"});
        startActivityForResult(i, REQ_IMPORT);
    }

    private void prepareExport(String type) {
        List<NotebookStore.Entry> entries = NotebookStore.load(this);
        if (entries.isEmpty()) { showToast("La libreta no tiene puntos."); return; }
        String base = "GeoTopo_Puntos_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
        if ("csv".equals(type)) { pendingContent = buildCsv(entries); pendingMime = "text/csv"; pendingExtension = ".csv"; }
        else if ("geojson".equals(type)) {
            List<NotebookStore.Entry> geographic = geographicEntries(entries);
            if (geographic.isEmpty()) { showToast("GeoJSON requiere coordenadas geográficas WGS84. Indica el sistema correcto en la libreta."); return; }
            pendingContent = buildGeoJson(geographic); pendingMime = "application/geo+json"; pendingExtension = ".geojson";
            status.setText("GeoJSON incluirá " + geographic.size() + " de " + entries.size() + " puntos geográficos WGS84.");
        }
        else if ("kml".equals(type)) {
            List<NotebookStore.Entry> geographic = geographicEntries(entries);
            if (geographic.isEmpty()) { showToast("KML requiere coordenadas geográficas WGS84. Indica el sistema correcto en la libreta."); return; }
            pendingContent = buildKml(geographic); pendingMime = "application/vnd.google-earth.kml+xml"; pendingExtension = ".kml";
            status.setText("KML incluirá " + geographic.size() + " de " + entries.size() + " puntos geográficos WGS84.");
        }
        else { pendingContent = buildJson(entries); pendingMime = "application/json"; pendingExtension = ".json"; }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(pendingMime);
        i.putExtra(Intent.EXTRA_TITLE, base + pendingExtension); startActivityForResult(i, REQ_EXPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        if (requestCode == REQ_IMPORT) importUri(data.getData());
        else if (requestCode == REQ_EXPORT && pendingContent != null) writeUri(data.getData(), pendingContent);
    }

    private void importUri(Uri uri) {
        try {
            String content = readAll(uri);
            String name = fileName(uri).toLowerCase(Locale.US);
            List<NotebookStore.Entry> imported;
            if (name.endsWith(".geojson") || content.trim().startsWith("{\"type\":\"FeatureCollection")) imported = parseGeoJson(content);
            else if (name.endsWith(".kml") || content.contains("<kml")) imported = parseKml(content);
            else if (name.endsWith(".json") || content.trim().startsWith("[") || content.trim().startsWith("{")) imported = parseJsonBackup(content);
            else imported = parseCsv(content);
            if (imported.isEmpty()) { status.setText("No se encontraron puntos válidos en " + fileName(uri) + "."); return; }
            List<NotebookStore.Entry> all = NotebookStore.load(this); all.addAll(imported); NotebookStore.save(this, all);
            status.setText("Importación completada: " + imported.size() + " puntos añadidos.\nTotal actual: " + all.size());
        } catch (Exception e) { status.setText("No se pudo importar el archivo. Revisa su formato y codificación UTF-8."); }
    }

    private String readAll(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri); if (in == null) throw new IllegalStateException();
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(); String line; while ((line = br.readLine()) != null) sb.append(line).append('\n'); br.close(); return sb.toString();
    }

    private String fileName(Uri uri) {
        String name = "archivo";
        Cursor c = getContentResolver().query(uri, null, null, null, null);
        if (c != null) { try { if (c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = c.getString(i); } } finally { c.close(); } }
        return name == null ? "archivo" : name;
    }

    private void writeUri(Uri uri, String content) {
        try {
            OutputStream out = getContentResolver().openOutputStream(uri); if (out == null) throw new IllegalStateException();
            out.write(content.getBytes(StandardCharsets.UTF_8)); out.close(); status.setText("Archivo exportado correctamente.\nPuntos: " + NotebookStore.load(this).size());
        } catch (Exception e) { status.setText("No se pudo escribir el archivo."); }
    }

    private List<NotebookStore.Entry> geographicEntries(List<NotebookStore.Entry> entries) {
        List<NotebookStore.Entry> out = new ArrayList<>();
        for (NotebookStore.Entry e : entries) {
            try {
                double lat = Double.parseDouble(e.north.replace(',', '.'));
                double lon = Double.parseDouble(e.east.replace(',', '.'));
                String crs = e.crs.toLowerCase(Locale.US);
                boolean namedGeographic = crs.contains("geograf") || crs.contains("lat") || crs.contains("epsg:4326") || (crs.contains("wgs84") || crs.contains("wgs 84")) && !crs.contains("utm");
                if (namedGeographic && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) out.add(e);
            } catch (Exception ignored) {}
        }
        return out;
    }

    private String buildCsv(List<NotebookStore.Entry> entries) {
        StringBuilder sb = new StringBuilder("proyecto,codigo,norte_o_latitud,este_o_longitud,cota,sistema_coordenadas,descripcion,precision,fuente,fecha_hora\n");
        for (NotebookStore.Entry e : entries) sb.append(csv(e.project)).append(',').append(csv(e.code)).append(',').append(csv(e.north)).append(',').append(csv(e.east)).append(',')
                .append(csv(e.elevation)).append(',').append(csv(e.crs)).append(',').append(csv(e.description)).append(',').append(csv(e.accuracy)).append(',').append(csv(e.source)).append(',').append(csv(e.time)).append('\n');
        return sb.toString();
    }

    private String buildGeoJson(List<NotebookStore.Entry> entries) {
        JSONObject root = new JSONObject(); JSONArray features = new JSONArray();
        try { root.put("type", "FeatureCollection"); } catch (Exception ignored) {}
        for (NotebookStore.Entry e : entries) {
            try {
                double y = Double.parseDouble(e.north.replace(',', '.')); double x = Double.parseDouble(e.east.replace(',', '.'));
                JSONObject f = new JSONObject(); f.put("type", "Feature");
                JSONObject geometry = new JSONObject(); geometry.put("type", "Point"); JSONArray coordinates = new JSONArray(); coordinates.put(x); coordinates.put(y);
                if (!e.elevation.isEmpty()) coordinates.put(Double.parseDouble(e.elevation.replace(',', '.')));
                geometry.put("coordinates", coordinates); f.put("geometry", geometry);
                JSONObject properties = new JSONObject(); properties.put("project", e.project); properties.put("code", e.code); properties.put("crs", e.crs);
                properties.put("description", e.description); properties.put("accuracy", e.accuracy); properties.put("source", e.source); properties.put("time", e.time);
                f.put("properties", properties); features.put(f);
            } catch (Exception ignored) {}
        }
        try { root.put("features", features); } catch (Exception ignored) {}
        try { return root.toString(2); } catch (Exception e) { return root.toString(); }
    }

    private String buildKml(List<NotebookStore.Entry> entries) {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>GeoTopo</name>\n");
        for (NotebookStore.Entry e : entries) {
            sb.append("<Placemark><name>").append(xml(e.code)).append("</name><description>").append(xml("[" + e.project + "] " + e.crs + " · " + e.description + " · " + e.accuracy)).append("</description><Point><coordinates>")
                    .append(e.east).append(',').append(e.north).append(',').append(e.elevation.isEmpty() ? "0" : e.elevation)
                    .append("</coordinates></Point></Placemark>\n");
        }
        return sb.append("</Document></kml>\n").toString();
    }

    private String buildJson(List<NotebookStore.Entry> entries) {
        JSONArray array = new JSONArray();
        try {
            for (NotebookStore.Entry e : entries) {
                JSONObject o = new JSONObject(); o.put("project", e.project); o.put("code", e.code); o.put("north", e.north); o.put("east", e.east); o.put("elevation", e.elevation); o.put("crs", e.crs);
                o.put("description", e.description); o.put("accuracy", e.accuracy); o.put("source", e.source); o.put("time", e.time); array.put(o);
            }
        } catch (Exception ignored) {}
        try { return array.toString(2); } catch (Exception e) { return array.toString(); }
    }

    private List<NotebookStore.Entry> parseJsonBackup(String content) throws Exception {
        JSONArray array;
        String t = content.trim();
        if (t.startsWith("[")) array = new JSONArray(t);
        else { JSONObject root = new JSONObject(t); array = root.optJSONArray("entries"); if (array == null && "FeatureCollection".equals(root.optString("type"))) return parseGeoJson(content); }
        List<NotebookStore.Entry> out = new ArrayList<>(); if (array == null) return out;
        for (int i = 0; i < array.length(); i++) {
            JSONObject o = array.optJSONObject(i); if (o == null) continue;
            String north = first(o, "north", "lat", "latitude"); String east = first(o, "east", "lon", "longitude");
            if (!number(north) || !number(east)) continue;
            out.add(new NotebookStore.Entry(o.optString("project", "Importado"), first(o, "code", "name", "id"), north, east,
                    first(o, "elevation", "alt", "z"), o.optString("crs", "No indicado"), o.optString("description"), o.optString("accuracy"), o.optString("source", "JSON importado"), o.optString("time", now())));
        }
        return out;
    }

    private List<NotebookStore.Entry> parseGeoJson(String content) throws Exception {
        JSONObject root = new JSONObject(content); JSONArray features = root.optJSONArray("features"); List<NotebookStore.Entry> out = new ArrayList<>(); if (features == null) return out;
        for (int i = 0; i < features.length(); i++) {
            JSONObject f = features.optJSONObject(i); if (f == null) continue; JSONObject g = f.optJSONObject("geometry");
            if (g == null || !"Point".equalsIgnoreCase(g.optString("type"))) continue; JSONArray c = g.optJSONArray("coordinates"); if (c == null || c.length() < 2) continue;
            JSONObject p = f.optJSONObject("properties"); if (p == null) p = new JSONObject();
            out.add(new NotebookStore.Entry(p.optString("project", "GeoJSON"), first(p, "code", "name", "id"), String.valueOf(c.optDouble(1)), String.valueOf(c.optDouble(0)),
                    c.length() > 2 ? String.valueOf(c.optDouble(2)) : "", "WGS84 geográficas", p.optString("description"), p.optString("accuracy"), "GeoJSON importado", p.optString("time", now())));
        }
        return out;
    }

    private List<NotebookStore.Entry> parseKml(String content) {
        List<NotebookStore.Entry> out = new ArrayList<>();
        Pattern placemark = Pattern.compile("<Placemark[\\s\\S]*?</Placemark>", Pattern.CASE_INSENSITIVE);
        Matcher m = placemark.matcher(content); int count = 1;
        while (m.find()) {
            String block = m.group();
            if (!block.toLowerCase(Locale.US).contains("<point")) continue;
            String coords = tag(block, "coordinates"); if (coords == null) continue;
            String[] xyz = coords.trim().split(","); if (xyz.length < 2 || !number(xyz[0]) || !number(xyz[1])) continue;
            String name = tag(block, "name"); if (name == null || name.trim().isEmpty()) name = "KML-" + count;
            String desc = tag(block, "description");
            out.add(new NotebookStore.Entry("KML", unescape(name), xyz[1].trim(), xyz[0].trim(), xyz.length > 2 ? xyz[2].trim() : "", "WGS84 geográficas", desc == null ? "" : unescape(desc), "", "KML importado", now())); count++;
        }
        return out;
    }

    private List<NotebookStore.Entry> parseCsv(String content) {
        List<String[]> lines = parseCsvLines(content); List<NotebookStore.Entry> out = new ArrayList<>(); if (lines.isEmpty()) return out;
        String[] header = lines.get(0); Map<String, Integer> columns = new HashMap<>();
        for (int i = 0; i < header.length; i++) columns.put(normalize(header[i]), i);
        int code = find(columns, "codigo", "code", "nombre", "name", "id");
        int north = find(columns, "norteolatitud", "norte", "north", "latitud", "latitude", "lat");
        int east = find(columns, "esteolongitud", "este", "east", "longitud", "longitude", "lon", "lng");
        int elevation = find(columns, "cota", "elevation", "altitud", "altitude", "z");
        int project = find(columns, "proyecto", "project"); int crs = find(columns, "sistemacoordenadas", "crs", "sistema", "datumzona"); int description = find(columns, "descripcion", "description", "observacion");
        int accuracy = find(columns, "precision", "accuracy"); int source = find(columns, "fuente", "source"); int time = find(columns, "fechahora", "time", "fecha");
        if (north < 0 || east < 0) return out;
        for (int r = 1; r < lines.size(); r++) {
            String[] row = lines.get(r); String n = cell(row, north), e = cell(row, east); if (!number(n) || !number(e)) continue;
            out.add(new NotebookStore.Entry(value(row, project, "CSV"), value(row, code, "P" + r), n, e, cell(row, elevation), value(row, crs, "No indicado"), cell(row, description), cell(row, accuracy), value(row, source, "CSV importado"), value(row, time, now())));
        }
        return out;
    }

    private List<String[]> parseCsvLines(String content) {
        List<String[]> rows = new ArrayList<>(); List<String> current = new ArrayList<>(); StringBuilder cell = new StringBuilder(); boolean quoted = false;
        for (int i = 0; i < content.length(); i++) {
            char ch = content.charAt(i);
            if (ch == '"') { if (quoted && i + 1 < content.length() && content.charAt(i + 1) == '"') { cell.append('"'); i++; } else quoted = !quoted; }
            else if (ch == ',' && !quoted) { current.add(cell.toString().trim()); cell.setLength(0); }
            else if ((ch == '\n' || ch == '\r') && !quoted) {
                if (ch == '\r' && i + 1 < content.length() && content.charAt(i + 1) == '\n') i++;
                current.add(cell.toString().trim()); cell.setLength(0); if (!(current.size() == 1 && current.get(0).isEmpty())) rows.add(current.toArray(new String[0])); current = new ArrayList<>();
            } else cell.append(ch);
        }
        if (cell.length() > 0 || !current.isEmpty()) { current.add(cell.toString().trim()); rows.add(current.toArray(new String[0])); }
        return rows;
    }

    private String normalize(String v) { if (v == null) return ""; String n = v.toLowerCase(Locale.US).replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u").replace("ñ","n"); return n.replaceAll("[^a-z0-9]", ""); }
    private int find(Map<String,Integer> m, String... names) { for (String n : names) if (m.containsKey(n)) return m.get(n); return -1; }
    private String cell(String[] row, int i) { return i >= 0 && i < row.length ? row[i].trim() : ""; }
    private String value(String[] row, int i, String fallback) { String v = cell(row, i); return v.isEmpty() ? fallback : v; }
    private boolean number(String v) { try { Double.parseDouble(v.trim().replace(',', '.')); return true; } catch (Exception e) { return false; } }
    private String first(JSONObject o, String... keys) { for (String k : keys) { String v = o.optString(k, ""); if (!v.isEmpty()) return v; } return ""; }
    private String tag(String block, String name) { Matcher m = Pattern.compile("<" + name + "[^>]*>([\\s\\S]*?)</" + name + ">", Pattern.CASE_INSENSITIVE).matcher(block); return m.find() ? m.group(1).trim() : null; }
    private String unescape(String v) { return v.replace("<![CDATA[", "").replace("]]>", "").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&"); }
    private String csv(String v) { return '"' + (v == null ? "" : v.replace("\"", "\"\"")) + '"'; }
    private String xml(String v) { return v == null ? "" : v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;"); }
    private String now() { return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()); }
}
