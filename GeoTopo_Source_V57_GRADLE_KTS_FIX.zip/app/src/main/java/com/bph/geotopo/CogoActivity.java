package com.bph.geotopo;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CogoActivity extends BaseToolActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        LinearLayout root = page("COGO completo", "Geometría de coordenadas para cálculo de campo");
        LinearLayout content = vertical();
        content.addView(collapsibleCard(directBlock(), "→", "Cálculo directo", false));
        content.addView(collapsibleCard(inverseBlock(), "↔", "Cálculo inverso", false));
        content.addView(collapsibleCard(azimuthIntersectionBlock(), "✕", "Intersección por dos azimuts", false));
        content.addView(collapsibleCard(distanceIntersectionBlock(), "◉", "Intersección por dos distancias", false));
        content.addView(collapsibleCard(projectionBlock(), "⊥", "Proyección y offset a una línea", false));
        content.addView(collapsibleCard(divisionBlock(), "÷", "Punto medio y división de línea", false));
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private LinearLayout directBlock() {
        LinearLayout box = vertical();
        box.addView(small("Coordenada final desde Norte/Este inicial, azimut medido desde el Norte en sentido horario y distancia horizontal."));
        EditText n0 = numberInput("N inicial");
        EditText e0 = numberInput("E inicial");
        EditText az = numberInput("Azimut °");
        EditText dist = numberInput("Distancia m");
        LinearLayout r1 = horizontal(); r1.addView(labeled("N inicial", n0), weight()); r1.addView(labeled("E inicial", e0), weight()); box.addView(r1);
        LinearLayout r2 = horizontal(); r2.addView(labeled("Azimut", az), weight()); r2.addView(labeled("Distancia", dist), weight()); box.addView(r2);
        TextView out = resultBox("Resultado: —");
        Button calc = primaryButton("Calcular directa");
        calc.setOnClickListener(v -> {
            try {
                double a = Math.toRadians(normalizeBearing(parse(az)));
                double d = parse(dist);
                if (d < 0) throw new IllegalArgumentException();
                double dn = d * Math.cos(a);
                double de = d * Math.sin(a);
                out.setText("ΔN: " + signed(dn) + " m · ΔE: " + signed(de) + " m\n"
                        + "N final: " + f3(parse(n0) + dn) + "\n"
                        + "E final: " + f3(parse(e0) + de));
            } catch (Exception ex) { out.setText("Revisa los datos. La distancia no puede ser negativa."); }
        });
        box.addView(calc); box.addView(out);
        return box;
    }

    private LinearLayout inverseBlock() {
        LinearLayout box = vertical();
        box.addView(small("Distancia, azimut, rumbo y diferencias entre dos coordenadas planas."));
        EditText n1 = numberInput("N1"), e1 = numberInput("E1"), n2 = numberInput("N2"), e2 = numberInput("E2");
        LinearLayout r1 = horizontal(); r1.addView(labeled("N1", n1), weight()); r1.addView(labeled("E1", e1), weight()); box.addView(r1);
        LinearLayout r2 = horizontal(); r2.addView(labeled("N2", n2), weight()); r2.addView(labeled("E2", e2), weight()); box.addView(r2);
        TextView out = resultBox("Resultado: —");
        Button calc = primaryButton("Calcular inversa");
        calc.setOnClickListener(v -> {
            try {
                double dn = parse(n2) - parse(n1);
                double de = parse(e2) - parse(e1);
                double d = Math.hypot(dn, de);
                if (d == 0) throw new IllegalArgumentException();
                double a = normalizeBearing(Math.toDegrees(Math.atan2(de, dn)));
                out.setText("ΔN: " + signed(dn) + " m · ΔE: " + signed(de) + " m\n"
                        + "Distancia: " + f3(d) + " m\n"
                        + "Azimut: " + f4(a) + "°\nRumbo: " + bearingToQuadrant(a));
            } catch (Exception ex) { out.setText("Revisa las coordenadas. Los puntos no deben ser iguales."); }
        });
        box.addView(calc); box.addView(out);
        return box;
    }

    private LinearLayout azimuthIntersectionBlock() {
        LinearLayout box = vertical();
        box.addView(small("Intersección de dos alineamientos definidos por un punto conocido y su azimut."));
        EditText n1 = numberInput("N1"), e1 = numberInput("E1"), a1 = numberInput("Az1");
        EditText n2 = numberInput("N2"), e2 = numberInput("E2"), a2 = numberInput("Az2");
        LinearLayout r1 = horizontal(); r1.addView(labeled("N1", n1), weight()); r1.addView(labeled("E1", e1), weight()); r1.addView(labeled("Az1", a1), weight()); box.addView(r1);
        LinearLayout r2 = horizontal(); r2.addView(labeled("N2", n2), weight()); r2.addView(labeled("E2", e2), weight()); r2.addView(labeled("Az2", a2), weight()); box.addView(r2);
        TextView out = resultBox("Intersección: —");
        Button calc = primaryButton("Calcular intersección");
        calc.setOnClickListener(v -> {
            try {
                double A1 = Math.toRadians(normalizeBearing(parse(a1)));
                double A2 = Math.toRadians(normalizeBearing(parse(a2)));
                double d1n = Math.cos(A1), d1e = Math.sin(A1);
                double d2n = Math.cos(A2), d2e = Math.sin(A2);
                double dn = parse(n2) - parse(n1), de = parse(e2) - parse(e1);
                double det = d1n * (-d2e) - d1e * (-d2n);
                if (Math.abs(det) < 1e-10) throw new IllegalArgumentException();
                double t1 = (dn * (-d2e) - de * (-d2n)) / det;
                double ni = parse(n1) + t1 * d1n;
                double ei = parse(e1) + t1 * d1e;
                double t2 = Math.hypot(ni - parse(n2), ei - parse(e2));
                out.setText("N intersección: " + f3(ni) + "\nE intersección: " + f3(ei)
                        + "\nDistancia desde P1: " + f3(Math.abs(t1)) + " m"
                        + "\nDistancia desde P2: " + f3(t2) + " m"
                        + (t1 < 0 ? "\nAdvertencia: la intersección está detrás del azimut 1." : ""));
            } catch (Exception ex) { out.setText("Las líneas son paralelas o faltan datos válidos."); }
        });
        box.addView(calc); box.addView(out);
        return box;
    }

    private LinearLayout distanceIntersectionBlock() {
        LinearLayout box = vertical();
        box.addView(small("Obtiene hasta dos puntos que están a una distancia conocida de P1 y P2."));
        EditText n1 = numberInput("N1"), e1 = numberInput("E1"), r1i = numberInput("Radio 1");
        EditText n2 = numberInput("N2"), e2 = numberInput("E2"), r2i = numberInput("Radio 2");
        LinearLayout r1 = horizontal(); r1.addView(labeled("N1", n1), weight()); r1.addView(labeled("E1", e1), weight()); r1.addView(labeled("Dist. 1", r1i), weight()); box.addView(r1);
        LinearLayout r2 = horizontal(); r2.addView(labeled("N2", n2), weight()); r2.addView(labeled("E2", e2), weight()); r2.addView(labeled("Dist. 2", r2i), weight()); box.addView(r2);
        TextView out = resultBox("Intersecciones: —");
        Button calc = primaryButton("Calcular intersecciones");
        calc.setOnClickListener(v -> {
            try {
                double N1 = parse(n1), E1 = parse(e1), N2 = parse(n2), E2 = parse(e2);
                double R1 = parse(r1i), R2 = parse(r2i);
                if (R1 <= 0 || R2 <= 0) throw new IllegalArgumentException();
                double dn = N2 - N1, de = E2 - E1, d = Math.hypot(dn, de);
                if (d == 0 || d > R1 + R2 || d < Math.abs(R1 - R2)) throw new IllegalArgumentException();
                double a = (R1 * R1 - R2 * R2 + d * d) / (2 * d);
                double h2 = R1 * R1 - a * a;
                if (h2 < -1e-8) throw new IllegalArgumentException();
                double h = Math.sqrt(Math.max(0, h2));
                double baseN = N1 + a * dn / d;
                double baseE = E1 + a * de / d;
                double offN = -de * h / d;
                double offE = dn * h / d;
                out.setText("Solución A: N " + f3(baseN + offN) + " · E " + f3(baseE + offE)
                        + "\nSolución B: N " + f3(baseN - offN) + " · E " + f3(baseE - offE)
                        + (h < 1e-7 ? "\nLos círculos son tangentes: ambas soluciones coinciden." : ""));
            } catch (Exception ex) { out.setText("No existe intersección real o los datos son inválidos."); }
        });
        box.addView(calc); box.addView(out);
        return box;
    }

    private LinearLayout projectionBlock() {
        LinearLayout box = vertical();
        box.addView(small("Proyecta un punto P sobre la línea A–B y calcula la progresiva desde A y el offset lateral con signo."));
        EditText an = numberInput("N A"), ae = numberInput("E A"), bn = numberInput("N B"), be = numberInput("E B"), pn = numberInput("N P"), pe = numberInput("E P");
        LinearLayout r1 = horizontal(); r1.addView(labeled("N A", an), weight()); r1.addView(labeled("E A", ae), weight()); box.addView(r1);
        LinearLayout r2 = horizontal(); r2.addView(labeled("N B", bn), weight()); r2.addView(labeled("E B", be), weight()); box.addView(r2);
        LinearLayout r3 = horizontal(); r3.addView(labeled("N P", pn), weight()); r3.addView(labeled("E P", pe), weight()); box.addView(r3);
        TextView out = resultBox("Proyección: —");
        Button calc = primaryButton("Calcular proyección");
        calc.setOnClickListener(v -> {
            try {
                double dN = parse(bn) - parse(an), dE = parse(be) - parse(ae);
                double len2 = dN * dN + dE * dE;
                if (len2 == 0) throw new IllegalArgumentException();
                double pN = parse(pn) - parse(an), pE = parse(pe) - parse(ae);
                double t = (pN * dN + pE * dE) / len2;
                double qN = parse(an) + t * dN, qE = parse(ae) + t * dE;
                double length = Math.sqrt(len2);
                double chainage = t * length;
                double cross = dN * pE - dE * pN;
                double offset = cross / length;
                out.setText("Punto proyectado: N " + f3(qN) + " · E " + f3(qE)
                        + "\nProgresiva desde A: " + f3(chainage) + " m"
                        + "\nOffset: " + signed(offset) + " m (positivo = izquierda mirando A→B)"
                        + "\nPosición: " + (t < 0 ? "antes de A" : (t > 1 ? "después de B" : "dentro del segmento")));
            } catch (Exception ex) { out.setText("Revisa los puntos; A y B no pueden coincidir."); }
        });
        box.addView(calc); box.addView(out);
        return box;
    }

    private LinearLayout divisionBlock() {
        LinearLayout box = vertical();
        box.addView(small("Calcula un punto sobre el segmento A–B. Usa 0.5 para punto medio, 0.25 para 25 %, o una distancia desde A."));
        EditText an = numberInput("N A"), ae = numberInput("E A"), bn = numberInput("N B"), be = numberInput("E B");
        EditText factor = numberInput("Fracción 0..1"), distance = numberInput("Distancia desde A");
        LinearLayout r1 = horizontal(); r1.addView(labeled("N A", an), weight()); r1.addView(labeled("E A", ae), weight()); box.addView(r1);
        LinearLayout r2 = horizontal(); r2.addView(labeled("N B", bn), weight()); r2.addView(labeled("E B", be), weight()); box.addView(r2);
        LinearLayout r3 = horizontal(); r3.addView(labeled("Fracción", factor), weight()); r3.addView(labeled("O distancia", distance), weight()); box.addView(r3);
        factor.setText("0.5");
        TextView out = resultBox("Punto calculado: —");
        Button calc = primaryButton("Calcular punto");
        calc.setOnClickListener(v -> {
            try {
                double dN = parse(bn) - parse(an), dE = parse(be) - parse(ae);
                double len = Math.hypot(dN, dE);
                if (len == 0) throw new IllegalArgumentException();
                double t;
                if (!blank(distance)) t = parse(distance) / len;
                else t = parse(factor);
                double n = parse(an) + t * dN, e = parse(ae) + t * dE;
                out.setText("N: " + f3(n) + "\nE: " + f3(e)
                        + "\nFracción: " + f4(t) + " · Distancia desde A: " + f3(t * len) + " m"
                        + (t < 0 || t > 1 ? "\nAdvertencia: el punto está fuera del segmento." : ""));
            } catch (Exception ex) { out.setText("Revisa las coordenadas y la fracción o distancia."); }
        });
        box.addView(calc); box.addView(out);
        return box;
    }
}
