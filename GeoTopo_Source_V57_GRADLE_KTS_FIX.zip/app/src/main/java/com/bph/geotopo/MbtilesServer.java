package com.bph.geotopo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Tiny localhost-only HTTP server for raster MBTiles imported by the user. */
public final class MbtilesServer {
    private SQLiteDatabase db;
    private ServerSocket serverSocket;
    private ExecutorService executor;
    private Thread acceptThread;
    private volatile boolean running;
    private final Map<String, String> metadata = new HashMap<>();
    private int minZoom;
    private int maxZoom;
    private String format = "png";

    public void start(File file) throws Exception {
        stop();
        db = SQLiteDatabase.openDatabase(file.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
        loadMetadata();
        byte[] sample = inspectTiles();
        String declared = metadata.containsKey("format") ? metadata.get("format").toLowerCase(Locale.US) : "";
        format = normalizeFormat(declared);
        if (format.isEmpty()) format = detectFormat(sample);
        if (!("png".equals(format) || "jpg".equals(format) || "webp".equals(format))) {
            stop();
            throw new IllegalArgumentException("Solo se admiten MBTiles ráster PNG/JPG/WEBP. Formato detectado: " + (format.isEmpty() ? "desconocido" : format));
        }

        serverSocket = new ServerSocket(0, 24, java.net.InetAddress.getByName("127.0.0.1"));
        executor = Executors.newFixedThreadPool(4);
        running = true;
        acceptThread = new Thread(() -> {
            while (running) {
                try {
                    Socket socket = serverSocket.accept();
                    executor.execute(() -> handle(socket));
                } catch (Exception e) {
                    if (running) {
                        // Continue until explicitly stopped.
                    }
                }
            }
        }, "GeoTopo-MBTiles-Accept");
        acceptThread.start();
    }

    private void loadMetadata() {
        metadata.clear();
        try {
            Cursor c = db.rawQuery("SELECT name, value FROM metadata", null);
            while (c.moveToNext()) metadata.put(c.getString(0).toLowerCase(Locale.US), c.getString(1));
            c.close();
        } catch (Exception ignored) {}
    }

    private byte[] inspectTiles() {
        Cursor zoom = null;
        Cursor tile = null;
        try {
            zoom = db.rawQuery("SELECT MIN(zoom_level), MAX(zoom_level) FROM tiles", null);
            if (!zoom.moveToFirst() || zoom.isNull(0) || zoom.isNull(1)) throw new IllegalArgumentException("El paquete MBTiles no contiene teselas.");
            minZoom = Math.max(0, Math.min(30, zoom.getInt(0)));
            maxZoom = Math.max(minZoom, Math.min(30, zoom.getInt(1)));
            tile = db.rawQuery("SELECT tile_data FROM tiles LIMIT 1", null);
            if (!tile.moveToFirst()) throw new IllegalArgumentException("El paquete MBTiles no contiene teselas.");
            return tile.getBlob(0);
        } finally {
            if (zoom != null) zoom.close();
            if (tile != null) tile.close();
        }
    }

    private String normalizeFormat(String value) {
        if (value == null) return "";
        String f = value.trim().toLowerCase(Locale.US);
        if ("jpeg".equals(f)) return "jpg";
        return f;
    }

    private String detectFormat(byte[] data) {
        if (data == null || data.length < 4) return "";
        if ((data[0] & 0xff) == 0x89 && data[1] == 0x50 && data[2] == 0x4e && data[3] == 0x47) return "png";
        if ((data[0] & 0xff) == 0xff && (data[1] & 0xff) == 0xd8) return "jpg";
        if (data.length >= 12 && data[0] == 'R' && data[1] == 'I' && data[2] == 'F' && data[3] == 'F'
                && data[8] == 'W' && data[9] == 'E' && data[10] == 'B' && data[11] == 'P') return "webp";
        return "";
    }

    private void handle(Socket socket) {
        try (Socket s = socket;
             BufferedInputStream in = new BufferedInputStream(s.getInputStream());
             BufferedOutputStream out = new BufferedOutputStream(s.getOutputStream())) {
            String request = readLine(in);
            if (request == null) return;
            String line;
            do { line = readLine(in); } while (line != null && !line.isEmpty());
            String[] parts = request.split(" ");
            if (parts.length < 2 || !"GET".equals(parts[0])) { respond(out, 400, "text/plain", "Bad request".getBytes(StandardCharsets.UTF_8)); return; }
            String path = parts[1].split("\\?")[0];
            String[] p = path.split("/");
            if (p.length < 5 || !"tiles".equals(p[1])) { respond(out, 404, "text/plain", new byte[0]); return; }
            int z = Integer.parseInt(p[2]);
            int x = Integer.parseInt(p[3]);
            if (z < minZoom || z > maxZoom || z < 0 || z > 30 || x < 0) { respond(out, 404, "text/plain", new byte[0]); return; }
            String yPart = p[4];
            // Style URL may produce /tiles/z/x/y.png, which splits to 5 entries. Handle both.
            if (p.length == 5) yPart = p[4];
            int dot = yPart.indexOf('.'); if (dot >= 0) yPart = yPart.substring(0, dot);
            int y = Integer.parseInt(yPart);
            byte[] tile = loadTile(z, x, y);
            if (tile == null) { respond(out, 404, "text/plain", new byte[0]); return; }
            respond(out, 200, mime(), tile);
        } catch (Exception ignored) {}
    }

    private byte[] loadTile(int z, int x, int xyzY) {
        if (db == null) return null;
        boolean xyz = "xyz".equalsIgnoreCase(metadata.get("scheme"));
        long storedY = xyz ? xyzY : ((1L << z) - 1L - xyzY);
        Cursor c = null;
        try {
            c = db.rawQuery("SELECT tile_data FROM tiles WHERE zoom_level=? AND tile_column=? AND tile_row=? LIMIT 1",
                    new String[]{String.valueOf(z), String.valueOf(x), String.valueOf(storedY)});
            return c.moveToFirst() ? c.getBlob(0) : null;
        } catch (Exception e) { return null; }
        finally { if (c != null) c.close(); }
    }

    private String readLine(BufferedInputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        int b;
        while ((b = in.read()) != -1) {
            if (b == '\n') break;
            if (b != '\r') sb.append((char) b);
            if (sb.length() > 8192) break;
        }
        if (b == -1 && sb.length() == 0) return null;
        return sb.toString();
    }

    private void respond(BufferedOutputStream out, int code, String mime, byte[] body) throws Exception {
        String status = code == 200 ? "OK" : (code == 404 ? "Not Found" : "Bad Request");
        String header = "HTTP/1.1 " + code + " " + status + "\r\n"
                + "Content-Type: " + mime + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Cache-Control: public, max-age=86400\r\n"
                + "Connection: close\r\n\r\n";
        out.write(header.getBytes(StandardCharsets.US_ASCII)); out.write(body); out.flush();
    }

    private String mime() {
        String f = getFormat();
        if ("jpg".equals(f) || "jpeg".equals(f)) return "image/jpeg";
        if ("webp".equals(f)) return "image/webp";
        return "image/png";
    }

    public int getPort() { return serverSocket == null ? -1 : serverSocket.getLocalPort(); }
    public int getMinZoom() { return minZoom; }
    public int getMaxZoom() { return maxZoom; }
    public String getFormat() { return format; }
    public String getName() { return metadata.containsKey("name") ? metadata.get("name") : "Mapa MBTiles"; }
    public String getAttribution() { return metadata.containsKey("attribution") ? metadata.get("attribution") : "Paquete MBTiles importado por el usuario"; }
    public String getBounds() { return metadata.get("bounds"); }
    public String getCenter() { return metadata.get("center"); }

    public synchronized void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        serverSocket = null;
        if (executor != null) executor.shutdownNow(); executor = null;
        try { if (db != null) db.close(); } catch (Exception ignored) {}
        db = null;
    }
}
