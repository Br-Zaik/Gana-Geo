package com.ganageo.app.ui.tools

import android.app.ActivityManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import com.ganageo.app.R

internal enum class GameSound {
    JUMP,
    DOUBLE_JUMP,
    SHOOT,
    ENEMY_SHOT,
    HIT,
    CRYSTAL,
    SWITCH,
    PICKUP,
    CHECKPOINT,
    TRAP,
    BUTTON,
    LAND,
    SPIKE,
    HOLE,
    CRUSHER,
    FRUIT_DROP,
    EXPLOSION,
    ENEMY_STOMP,
    DECOY,
    DEATH_RED,
    DEATH_GOLD,
    VICTORY,
    DEFEAT
}

/**
 * Lightweight game audio path.
 *
 * Music is prepared asynchronously so entering a level never blocks on decoder setup. SoundPool
 * effects are loaded on demand (only the most common ones are preloaded) and repetitive effects are
 * rate-limited. This keeps audio work away from the fixed-step physics loop and reduces decoder/GC
 * pressure on lower-end Android devices.
 */
internal class GameAudioController(context: Context, levelNumber: Int) {
    private val appContext = context.applicationContext
    private val activityManager = appContext.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    private val lowMemoryAudio = activityManager?.isLowRamDevice == true || (activityManager?.memoryClass ?: 256) <= 192
    private val lock = Any()
    @Volatile private var released = false

    private val soundPool = SoundPool.Builder()
        .setMaxStreams(if (lowMemoryAudio) 3 else 5)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val soundResources = mapOf(
        GameSound.JUMP to R.raw.geo_jump,
        GameSound.DOUBLE_JUMP to R.raw.geo_double_jump,
        GameSound.SHOOT to R.raw.geo_shoot,
        GameSound.ENEMY_SHOT to R.raw.geo_enemy_shot,
        GameSound.HIT to R.raw.geo_hit,
        GameSound.CRYSTAL to R.raw.geo_crystal,
        GameSound.SWITCH to R.raw.geo_switch,
        GameSound.PICKUP to R.raw.geo_pickup,
        GameSound.CHECKPOINT to R.raw.geo_checkpoint,
        GameSound.TRAP to R.raw.geo_trap,
        GameSound.BUTTON to R.raw.geo_button,
        GameSound.LAND to R.raw.geo_land,
        GameSound.SPIKE to R.raw.geo_spike,
        GameSound.HOLE to R.raw.geo_hole,
        GameSound.CRUSHER to R.raw.geo_crusher,
        GameSound.FRUIT_DROP to R.raw.geo_fruit_drop,
        GameSound.EXPLOSION to R.raw.geo_explosion,
        GameSound.ENEMY_STOMP to R.raw.geo_enemy_stomp,
        GameSound.DECOY to R.raw.geo_decoy,
        GameSound.DEATH_RED to R.raw.geo_death_red,
        GameSound.DEATH_GOLD to R.raw.geo_death_gold,
        GameSound.VICTORY to R.raw.geo_victory,
        GameSound.DEFEAT to R.raw.geo_defeat
    )

    private val sounds = GameSound.values()
    private val soundIds = IntArray(sounds.size)
    private val loaded = BooleanArray(sounds.size)
    private val pending = BooleanArray(sounds.size)
    private val pendingVolume = FloatArray(sounds.size) { 1f }
    private val pendingRate = FloatArray(sounds.size) { 1f }
    private val sampleToOrdinal = HashMap<Int, Int>(sounds.size)
    private val lastPlayNanos = LongArray(sounds.size)

    private val musicResource = when (levelNumber.coerceIn(1, 20)) {
        1 -> R.raw.geo_level_01
        2 -> R.raw.geo_level_02
        3 -> R.raw.geo_level_03
        4 -> R.raw.geo_level_04
        5 -> R.raw.geo_level_05
        6 -> R.raw.geo_level_06
        7 -> R.raw.geo_level_07
        8 -> R.raw.geo_level_08
        9 -> R.raw.geo_level_09
        10 -> R.raw.geo_level_10
        11 -> R.raw.geo_level_11
        12 -> R.raw.geo_level_12
        13 -> R.raw.geo_level_13
        14 -> R.raw.geo_level_14
        15 -> R.raw.geo_level_15
        16 -> R.raw.geo_level_16
        17 -> R.raw.geo_level_17
        18 -> R.raw.geo_level_18
        19 -> R.raw.geo_level_19
        else -> R.raw.geo_level_20
    }

    @Volatile private var musicPrepared = false
    @Volatile private var musicRequested = false
    private var musicPlayer: MediaPlayer? = null

    var musicEnabled: Boolean = true
        private set
    var effectsEnabled: Boolean = true
        private set

    init {
        soundPool.setOnLoadCompleteListener { _, sampleId, status ->
            val queued: Triple<Int, Float, Float>? = synchronized(lock) {
                if (released) {
                    null
                } else {
                    val ordinal = sampleToOrdinal[sampleId]
                    if (ordinal == null) {
                        null
                    } else if (status != 0) {
                        soundIds[ordinal] = 0
                        pending[ordinal] = false
                        null
                    } else {
                        loaded[ordinal] = true
                        if (pending[ordinal] && effectsEnabled) {
                            pending[ordinal] = false
                            Triple(sampleId, pendingVolume[ordinal], pendingRate[ordinal])
                        } else null
                    }
                }
            }
            queued?.let { (id, volume, rate) ->
                runCatching { soundPool.play(id, volume, volume, 1, 0, rate) }
            }
        }

        // Only the effects likely to occur in the first seconds are preloaded. Everything else is
        // decoded the first time it is requested, spreading I/O instead of doing 23 loads at once.
        val preload = if (lowMemoryAudio) {
            listOf(GameSound.JUMP, GameSound.DOUBLE_JUMP, GameSound.DEATH_RED, GameSound.DEATH_GOLD)
        } else {
            listOf(
                GameSound.JUMP,
                GameSound.DOUBLE_JUMP,
                GameSound.LAND,
                GameSound.TRAP,
                GameSound.ENEMY_STOMP,
                GameSound.DEATH_RED,
                GameSound.DEATH_GOLD
            )
        }
        preload.forEach { ensureLoaded(it) }

        prepareMusicAsync()
    }

    private fun ensureLoaded(sound: GameSound): Int {
        val ordinal = sound.ordinal
        synchronized(lock) {
            if (released) return 0
            soundIds[ordinal].takeIf { it != 0 }?.let { return it }
            val resource = soundResources[sound] ?: return 0
            val sampleId = soundPool.load(appContext, resource, 1)
            if (sampleId != 0) {
                soundIds[ordinal] = sampleId
                sampleToOrdinal[sampleId] = ordinal
            }
            return sampleId
        }
    }

    private fun prepareMusicAsync() {
        val descriptor = runCatching { appContext.resources.openRawResourceFd(musicResource) }.getOrNull() ?: return
        val player = MediaPlayer()
        val configured = runCatching {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.length)
            player.isLooping = true
            player.setVolume(MUSIC_VOLUME, MUSIC_VOLUME)
            player.setOnPreparedListener { preparedPlayer ->
                musicPrepared = true
                if (!released && musicEnabled && musicRequested) {
                    runCatching { preparedPlayer.start() }
                }
            }
            player.setOnErrorListener { _, _, _ ->
                musicPrepared = false
                false
            }
            musicPlayer = player
            player.prepareAsync()
        }.isSuccess
        runCatching { descriptor.close() }
        if (!configured) {
            runCatching { player.release() }
            musicPlayer = null
        }
    }

    fun startMusic() {
        if (released || !musicEnabled) return
        musicRequested = true
        val player = musicPlayer ?: return
        if (musicPrepared) runCatching { if (!player.isPlaying) player.start() }
    }

    fun pauseMusic() {
        musicRequested = false
        val player = musicPlayer ?: return
        if (musicPrepared) runCatching { if (player.isPlaying) player.pause() }
    }

    fun setMusicEnabled(enabled: Boolean) {
        musicEnabled = enabled
        if (enabled) startMusic() else pauseMusic()
    }

    fun setEffectsEnabled(enabled: Boolean) {
        effectsEnabled = enabled
        if (!enabled) synchronized(lock) { pending.fill(false) }
    }

    fun play(sound: GameSound, volume: Float = 1f, rate: Float = 1f) {
        if (released || !effectsEnabled) return
        val ordinal = sound.ordinal
        val now = System.nanoTime()
        val minIntervalNanos = minimumIntervalMs(sound) * 1_000_000L
        if (now - lastPlayNanos[ordinal] < minIntervalNanos) return
        lastPlayNanos[ordinal] = now

        val safeVolume = (volume * EFFECT_VOLUME_SCALE).coerceIn(0f, 1f)
        val safeRate = rate.coerceIn(0.5f, 2f)
        val id = ensureLoaded(sound)
        if (id == 0) return

        val canPlayNow = synchronized(lock) {
            if (released) return@synchronized false
            if (loaded[ordinal]) true else {
                pending[ordinal] = true
                pendingVolume[ordinal] = safeVolume
                pendingRate[ordinal] = safeRate
                false
            }
        }
        if (canPlayNow) runCatching { soundPool.play(id, safeVolume, safeVolume, 1, 0, safeRate) }
    }

    private fun minimumIntervalMs(sound: GameSound): Long = when (sound) {
        GameSound.LAND -> 105L
        GameSound.TRAP -> 85L
        GameSound.SPIKE -> 105L
        GameSound.HOLE -> 120L
        GameSound.CRUSHER -> 105L
        GameSound.FRUIT_DROP -> 95L
        GameSound.ENEMY_SHOT -> 70L
        GameSound.JUMP, GameSound.DOUBLE_JUMP -> 45L
        GameSound.EXPLOSION -> 85L
        else -> 28L
    }

    fun release() {
        if (released) return
        released = true
        musicRequested = false
        musicPrepared = false
        val player = musicPlayer
        musicPlayer = null
        runCatching {
            player?.setOnPreparedListener(null)
            player?.setOnErrorListener(null)
            player?.stop()
        }
        runCatching { player?.release() }
        runCatching { soundPool.setOnLoadCompleteListener(null) }
        runCatching { soundPool.release() }
    }

    private companion object {
        const val MUSIC_VOLUME = 0.085f
        const val EFFECT_VOLUME_SCALE = 0.86f
    }
}
