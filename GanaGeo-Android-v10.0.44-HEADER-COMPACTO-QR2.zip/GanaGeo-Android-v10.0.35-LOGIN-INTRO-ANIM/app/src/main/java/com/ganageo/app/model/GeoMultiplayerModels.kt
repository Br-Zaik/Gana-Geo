package com.ganageo.app.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
enum class GeoMultiplayerMode { SOLO, ONLINE, LOCAL }

@Serializable
enum class GeoSkin(val code: String, val displayName: String, val premium: Boolean = false) {
    GREEN("green", "Verde"),
    BLUE("blue", "Azul"),
    RED("red", "Rojo"),
    PURPLE("purple", "Morado"),
    CYAN("cyan", "Cian"),
    ORANGE("orange", "Naranja"),
    GOLD("gold", "Dorado", true),
    YELLOW_ELECTRIC("yellow_electric", "Amarillo eléctrico", true),
    GOLD_METALLIC("gold_metallic", "Oro metálico", true);

    companion object {
        fun fromCode(code: String?): GeoSkin = entries.firstOrNull { it.code == code?.lowercase() } ?: GREEN
        val free: List<GeoSkin> get() = entries.filterNot { it.premium }
    }
}

@Serializable
data class GeoMultiplayerPlayer(
    val playerId: String,
    val publicId: String,
    val displayName: String,
    val skinCode: String = "green",
    val isHost: Boolean = false,
    val isReady: Boolean = false,
    val lives: Int = 15,
    val isEliminated: Boolean = false,
    val isSpectator: Boolean = false,
    val x: Float = 0f,
    val y: Float = 0f,
    val velocityX: Float = 0f,
    val velocityY: Float = 0f,
    val checkpoint: Int = -1,
    val worldState: String = "",
    val seq: Long = 0L,
    val updatedAtMs: Long = 0L
) {
    val skin: GeoSkin get() = GeoSkin.fromCode(skinCode)
}

@Serializable
data class GeoMultiplayerRoom(
    val roomId: String,
    val roomCode: String = "",
    val hostId: String,
    val selectedLevel: Int = 1,
    val status: String = "lobby",
    val matchNo: Long = 0L,
    val winnerId: String? = null,
    val result: String? = null,
    val startedAtMs: Long = 0L,
    val updatedAtMs: Long = 0L
)

@Serializable
data class GeoMultiplayerLobbyState(
    val mode: GeoMultiplayerMode,
    val room: GeoMultiplayerRoom,
    val players: List<GeoMultiplayerPlayer>,
    val myPlayerId: String,
    val unlockedLevels: Set<Int> = setOf(1),
    val premiumSkins: Set<String> = emptySet(),
    val connected: Boolean = true,
    val message: String? = null
) {
    val me: GeoMultiplayerPlayer? get() = players.firstOrNull { it.playerId == myPlayerId }
    val isHost: Boolean get() = room.hostId == myPlayerId
}

@Serializable
data class GeoPlayerLookup(
    @SerialName("player_id") val playerId: String,
    @SerialName("public_id") val publicId: String,
    @SerialName("display_name") val displayName: String,
    @SerialName("skin_code") val skinCode: String = "green"
)

@Serializable
data class GeoMultiplayerInvite(
    @SerialName("invite_id") val inviteId: String,
    @SerialName("room_id") val roomId: String,
    @SerialName("from_public_id") val fromPublicId: String,
    @SerialName("from_name") val fromName: String,
    @SerialName("created_at_ms") val createdAtMs: Long = 0L
)

@Serializable
data class GeoOnlineRoomRow(
    @SerialName("room_id") val roomId: String,
    @SerialName("room_code") val roomCode: String,
    @SerialName("host_id") val hostId: String,
    @SerialName("selected_level") val selectedLevel: Int,
    val status: String,
    @SerialName("match_no") val matchNo: Long = 0,
    @SerialName("started_at_ms") val startedAtMs: Long = 0,
    @SerialName("updated_at_ms") val updatedAtMs: Long = 0
)

@Serializable
data class GeoOnlineRoomStateRow(
    @SerialName("room_id") val roomId: String,
    @SerialName("room_code") val roomCode: String,
    @SerialName("host_id") val hostId: String,
    @SerialName("selected_level") val selectedLevel: Int,
    val status: String,
    @SerialName("match_no") val matchNo: Long = 0,
    @SerialName("winner_id") val winnerId: String? = null,
    val result: String? = null,
    @SerialName("started_at_ms") val startedAtMs: Long = 0,
    @SerialName("room_updated_at_ms") val roomUpdatedAtMs: Long = 0,
    @SerialName("player_id") val playerId: String,
    @SerialName("public_id") val publicId: String,
    @SerialName("display_name") val displayName: String,
    @SerialName("skin_code") val skinCode: String,
    @SerialName("is_host") val isHost: Boolean,
    @SerialName("is_ready") val isReady: Boolean,
    val lives: Int = 15,
    @SerialName("is_eliminated") val isEliminated: Boolean = false,
    @SerialName("is_spectator") val isSpectator: Boolean = false,
    val x: Float = 0f,
    val y: Float = 0f,
    @SerialName("velocity_x") val velocityX: Float = 0f,
    @SerialName("velocity_y") val velocityY: Float = 0f,
    val checkpoint: Int = -1,
    @SerialName("world_state") val worldState: String = "",
    val seq: Long = 0,
    @SerialName("player_updated_at_ms") val playerUpdatedAtMs: Long = 0
)

@Serializable
data class GeoLevelUnlockRow(@SerialName("level_no") val levelNo: Int)

@Serializable
data class GeoCosmeticRow(@SerialName("skin_code") val skinCode: String)

@Serializable
data class GeoInviteIdRow(@SerialName("invite_id") val inviteId: String)

@Serializable
data class GeoRoomIdRow(@SerialName("room_id") val roomId: String)

@Serializable
data class GeoLocalRoomBeacon(
    val protocol: String,
    val roomId: String,
    val roomCode: String,
    val hostAddress: String,
    val hostName: String,
    val playerCount: Int,
    val selectedLevel: Int,
    val tcpPort: Int,
    val sentAt: Long = System.currentTimeMillis()
)

@Serializable
data class GeoMultiplayerWireMessage(
    val type: String,
    val protocol: String,
    val player: GeoMultiplayerPlayer? = null,
    val state: GeoMultiplayerLobbyState? = null,
    val name: String? = null,
    val skinCode: String? = null,
    val level: Int? = null,
    val ready: Boolean? = null,
    val playerId: String? = null,
    val winnerId: String? = null,
    val seq: Long = 0L
)
