package com.ganageo.app.data

import com.ganageo.app.model.GeoCosmeticRow
import com.ganageo.app.model.GeoInviteIdRow
import com.ganageo.app.model.GeoLevelUnlockRow
import com.ganageo.app.model.GeoMultiplayerInvite
import com.ganageo.app.model.GeoMultiplayerLobbyState
import com.ganageo.app.model.GeoMultiplayerMode
import com.ganageo.app.model.GeoMultiplayerPlayer
import com.ganageo.app.model.GeoMultiplayerRoom
import com.ganageo.app.model.GeoOnlineRoomRow
import com.ganageo.app.model.GeoOnlineRoomStateRow
import com.ganageo.app.model.GeoPlayerLookup
import com.ganageo.app.model.GeoRoomIdRow
import com.ganageo.app.model.GeoSkin
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class GeoOnlineMultiplayerService {
    private val client get() = SupabaseProvider.client ?: error("Supabase no está configurado.")
    private var cachedUnlocks: Set<Int> = setOf(1)
    private var cachedPremiumSkins: Set<String> = emptySet()

    fun isSignedIn(): Boolean = client.auth.currentSessionOrNull()?.user != null
    fun currentUserId(): String = client.auth.currentSessionOrNull()?.user?.id ?: error("Debes iniciar sesión para usar Online.")

    suspend fun registerProfile(skin: GeoSkin): GeoPlayerLookup = client.postgrest.rpc(
        "geo_mp_register_profile",
        buildJsonObject { put("p_skin_code", skin.code) }
    ).decodeList<GeoPlayerLookup>().single()

    suspend fun unlockedLevels(): Set<Int> = client.postgrest.rpc("geo_mp_my_unlocks")
        .decodeList<GeoLevelUnlockRow>().map { it.levelNo }.toSet().ifEmpty { setOf(1) }.also { cachedUnlocks = it }

    suspend fun premiumSkins(): Set<String> = client.postgrest.rpc("geo_mp_my_cosmetics")
        .decodeList<GeoCosmeticRow>().map { it.skinCode }.toSet().also { cachedPremiumSkins = it }

    suspend fun refreshAccountState(): Pair<Set<Int>, Set<String>> = unlockedLevels() to premiumSkins()

    suspend fun claimLocalUnlock(level: Int) {
        require(level in 1..20)
        client.postgrest.rpc("geo_mp_claim_local_unlock", buildJsonObject { put("p_level", level) })
    }

    suspend fun findPlayer(publicId: String): GeoPlayerLookup? = client.postgrest.rpc(
        "geo_mp_find_player",
        buildJsonObject { put("p_public_id", publicId.trim()) }
    ).decodeList<GeoPlayerLookup>().firstOrNull()

    suspend fun addFriend(publicId: String): GeoPlayerLookup = client.postgrest.rpc(
        "geo_mp_add_friend",
        buildJsonObject { put("p_public_id", publicId.trim()) }
    ).decodeList<GeoPlayerLookup>().single()

    suspend fun listFriends(): List<GeoPlayerLookup> = client.postgrest.rpc("geo_mp_list_friends").decodeList()

    suspend fun createRoom(level: Int, skin: GeoSkin): GeoMultiplayerLobbyState {
        val room = client.postgrest.rpc(
            "geo_mp_create_room",
            buildJsonObject { put("p_level", level); put("p_skin_code", skin.code) }
        ).decodeList<GeoOnlineRoomRow>().single()
        return roomState(room.roomId)
    }

    suspend fun invite(roomId: String, publicId: String): String = client.postgrest.rpc(
        "geo_mp_invite_player",
        buildJsonObject { put("p_room_id", roomId); put("p_public_id", publicId.trim()) }
    ).decodeList<GeoInviteIdRow>().single().inviteId

    suspend fun listInvites(): List<GeoMultiplayerInvite> = client.postgrest.rpc("geo_mp_list_invites").decodeList()

    suspend fun joinRoom(roomId: String, skin: GeoSkin): GeoMultiplayerLobbyState {
        client.postgrest.rpc(
            "geo_mp_join_room",
            buildJsonObject { put("p_room_id", roomId); put("p_skin_code", skin.code) }
        )
        return roomState(roomId)
    }

    suspend fun acceptInvite(inviteId: String, skin: GeoSkin): GeoMultiplayerLobbyState {
        val row = client.postgrest.rpc(
            "geo_mp_accept_invite",
            buildJsonObject { put("p_invite_id", inviteId); put("p_skin_code", skin.code) }
        ).decodeList<GeoRoomIdRow>().single()
        return roomState(row.roomId)
    }

    suspend fun roomState(roomId: String): GeoMultiplayerLobbyState {
        val rows = client.postgrest.rpc(
            "geo_mp_room_state",
            buildJsonObject { put("p_room_id", roomId) }
        ).decodeList<GeoOnlineRoomStateRow>()
        require(rows.isNotEmpty()) { "La sala ya no está disponible." }
        val first = rows.first()
        if (first.status == "finished" && first.result == "won") cachedUnlocks = cachedUnlocks + first.selectedLevel
        return GeoMultiplayerLobbyState(
            mode = GeoMultiplayerMode.ONLINE,
            room = GeoMultiplayerRoom(
                roomId = first.roomId,
                roomCode = first.roomCode,
                hostId = first.hostId,
                selectedLevel = first.selectedLevel,
                status = first.status,
                matchNo = first.matchNo,
                winnerId = first.winnerId,
                result = first.result,
                startedAtMs = first.startedAtMs,
                updatedAtMs = first.roomUpdatedAtMs
            ),
            players = rows.map { row ->
                GeoMultiplayerPlayer(
                    playerId = row.playerId,
                    publicId = row.publicId,
                    displayName = row.displayName,
                    skinCode = row.skinCode,
                    isHost = row.isHost,
                    isReady = row.isReady,
                    lives = row.lives,
                    isEliminated = row.isEliminated,
                    isSpectator = row.isSpectator,
                    x = row.x,
                    y = row.y,
                    velocityX = row.velocityX,
                    velocityY = row.velocityY,
                    checkpoint = row.checkpoint,
                    worldState = row.worldState,
                    seq = row.seq,
                    updatedAtMs = row.playerUpdatedAtMs
                )
            },
            myPlayerId = currentUserId(),
            unlockedLevels = cachedUnlocks,
            premiumSkins = cachedPremiumSkins
        )
    }

    suspend fun setReady(roomId: String, ready: Boolean, skin: GeoSkin) {
        client.postgrest.rpc("geo_mp_set_ready", buildJsonObject {
            put("p_room_id", roomId); put("p_ready", ready); put("p_skin_code", skin.code)
        })
    }

    suspend fun setLevel(roomId: String, level: Int) {
        client.postgrest.rpc("geo_mp_set_level", buildJsonObject { put("p_room_id", roomId); put("p_level", level) })
    }

    suspend fun startMatch(roomId: String) {
        client.postgrest.rpc("geo_mp_start_match", buildJsonObject { put("p_room_id", roomId) })
    }

    suspend fun updatePlayer(roomId: String, player: GeoMultiplayerPlayer) {
        client.postgrest.rpc("geo_mp_update_player", buildJsonObject {
            put("p_room_id", roomId)
            put("p_x", player.x); put("p_y", player.y)
            put("p_vx", player.velocityX); put("p_vy", player.velocityY)
            put("p_lives", player.lives); put("p_checkpoint", player.checkpoint)
            put("p_world_state", player.worldState.take(4096)); put("p_seq", player.seq)
        })
    }

    suspend fun finishMatch(roomId: String, won: Boolean, winnerId: String?) {
        client.postgrest.rpc("geo_mp_finish_match", buildJsonObject {
            put("p_room_id", roomId); put("p_result", if (won) "won" else "lost")
            put("p_winner_id", winnerId)
        })
    }

    suspend fun resetLobby(roomId: String) {
        client.postgrest.rpc("geo_mp_reset_lobby", buildJsonObject { put("p_room_id", roomId) })
    }

    suspend fun leaveRoom(roomId: String) {
        client.postgrest.rpc("geo_mp_leave_room", buildJsonObject { put("p_room_id", roomId) })
    }
}
