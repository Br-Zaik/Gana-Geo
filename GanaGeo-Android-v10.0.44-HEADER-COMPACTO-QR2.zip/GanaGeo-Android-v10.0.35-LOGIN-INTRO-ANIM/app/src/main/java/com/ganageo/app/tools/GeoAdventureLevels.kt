package com.ganageo.app.tools

import kotlin.math.abs

enum class PlatformKind { SOLID, FALLING, DISAPPEARING, PROXIMITY_DISAPPEARING, REVEALING, BOUNCE }
enum class PlatformRole { GROUND, LEDGE, ROOF, WALL }
enum class PlatformRevealMode { APPROACH, JUMP_NEAR, LAND_NEAR, BACKTRACK, SWITCH }
enum class HazardKind { SPIKES, HIDDEN_SPIKES, SAW, FIRE, CEILING_SPIKES }
enum class HazardOrientation { UP, DOWN, LEFT, RIGHT }
enum class CheckpointKind { SAFE, POPUP, DECOY }
enum class FallingObjectKind { ROCK, FRUIT, CRATE, SPIKE_BALL }
enum class FallingBehavior { DROP, EXPLODE, ROLL, CHASE, CHAIN }
enum class CrusherAxis { HORIZONTAL, VERTICAL }
enum class CrusherStyle { STONE_COLUMN, FALLING_WALL, LOG_PRESS, RUIN_BLOCK }
enum class GameEnemyKind { WALKER, JUMPER, FLYER, SHOOTER, GUARDIAN }
enum class GamePickupKind { ENERGY, SHIELD, POWER }
enum class AdventureBiome { FOREST_DAY, FOREST_SUNSET, UNDERGROUND, CAVE_NIGHT, DESERT_DAWN }
enum class LevelExitKind { TRAIL, ASCENT, DESCENT, CAVE, DOOR, LIFT, BRIDGE, TUNNEL, RUIN_GATE, SUMMIT }
enum class ConduitDirection { DOWN, UP, SIDE }
enum class HazardTriggerMode { APPROACH, JUMP_NEAR, LAND_NEAR, BACKTRACK }
enum class FallingTriggerMode { APPROACH, PASS_UNDER, JUMP_NEAR, LAND_NEAR, BACKTRACK, SWITCH }
enum class CratePayload { LIFE, SHIELD, POWER, EXPLOSION, SWITCH, EMPTY }
enum class LauncherDirection { LEFT, RIGHT, UP, DOWN }


data class GameConduit(
    val x: Float,
    val y: Float,
    val width: Float = 92f,
    val height: Float = 92f,
    val targetX: Float = x,
    val targetY: Float = y,
    val direction: ConduitDirection = ConduitDirection.DOWN,
    val endsLevel: Boolean = false,
    val arrivalOnly: Boolean = false,
    val autoEnter: Boolean = false
)

data class GamePlantTrap(
    val x: Float,
    val y: Float,
    val width: Float = 64f,
    val height: Float = 98f,
    val cycleMs: Long = 2_650L,
    val activeMs: Long = 1_250L,
    val phaseMs: Long = 0L,
    val detectionRange: Float = 210f,
    val proximityAggressive: Boolean = false
)

data class GameTree(
    val x: Float,
    val groundY: Float,
    val appleVisible: Boolean = false,
    val variant: Int = 0
)

data class GamePlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float = 34f,
    val kind: PlatformKind = PlatformKind.SOLID,
    val triggerX: Float = x - 90f,
    val delayMs: Long = 720L,
    val cycleMs: Long = 2_200L,
    val phaseMs: Long = 0L,
    val revealMode: PlatformRevealMode = PlatformRevealMode.APPROACH,
    val revealRadius: Float = 175f,
    val triggerSwitchIndex: Int? = null,
    val role: PlatformRole = PlatformRole.LEDGE
)

data class GameHazard(
    val x: Float,
    val y: Float,
    val width: Float = 58f,
    val height: Float = 42f,
    val kind: HazardKind = HazardKind.SPIKES,
    val triggerX: Float = x - 105f,
    val cycleMs: Long = 0L,
    val phaseMs: Long = 0L,
    val orientation: HazardOrientation = HazardOrientation.UP,
    val camouflaged: Boolean = false,
    val triggerMode: HazardTriggerMode = HazardTriggerMode.APPROACH,
    val retractable: Boolean = false
)

data class GameBarrier(
    val x: Float,
    val y: Float = 270f,
    val width: Float = 46f,
    val height: Float = 350f,
    val switchIndex: Int
)

data class GameEnemy(
    val x: Float,
    val y: Float,
    val range: Float = 120f,
    val detectionRange: Float = 480f,
    val health: Int = 2,
    val kind: GameEnemyKind = GameEnemyKind.WALKER,
    val speed: Float = 72f,
    val onDefeatSwitchIndex: Int? = null,
    val activationTriggerX: Float? = null,
    val hiddenUntilActivated: Boolean = false
)

data class GameCrystal(val x: Float, val y: Float)
data class GameCrate(
    val x: Float,
    val y: Float,
    val payload: CratePayload = CratePayload.SHIELD,
    val switchIndex: Int? = null
)

data class GameLauncher(
    val x: Float,
    val y: Float,
    val direction: LauncherDirection,
    val triggerX: Float,
    val triggerRadius: Float = 230f,
    val delayMs: Long = 240L,
    val projectileSpeed: Float = 470f,
    val hiddenUntilTriggered: Boolean = false
)
data class GameSwitch(val x: Float, val y: Float, val opensAtX: Float, val reversesFans: Boolean = false)
data class GamePickup(val x: Float, val y: Float, val kind: GamePickupKind)

data class GameKey(
    val x: Float,
    val y: Float,
    val revealTriggerX: Float = x - 220f,
    val hiddenUntilSwitch: Int? = null
)

data class GameMovingPlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val travel: Float,
    val vertical: Boolean,
    val periodSeconds: Float = 3.4f
)

data class GameCheckpoint(
    val x: Float,
    val y: Float = 535f,
    val kind: CheckpointKind = CheckpointKind.SAFE,
    val appearTriggerX: Float = x - 180f
)

data class GameFan(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val forceX: Float,
    val forceY: Float,
    val cycleMs: Long = 0L,
    val phaseMs: Long = 0L,
    val switchIndex: Int? = null
)

data class GameFallingObject(
    val x: Float,
    val startY: Float,
    val targetY: Float,
    val size: Float,
    val triggerX: Float,
    val kind: FallingObjectKind,
    val delayMs: Long = 180L,
    val behavior: FallingBehavior = FallingBehavior.DROP,
    val rollDirection: Float = 1f,
    val explosionRadius: Float = 110f,
    val chainCount: Int = 1,
    val chainSpacing: Float = 74f,
    val chaseDurationMs: Long = 5_500L,
    val chaseMaxTravel: Float = 850f,
    val treeFallsAfterTrap: Boolean = false,
    val explosionDelayMs: Long = 230L,
    val becomesPlatform: Boolean = false,
    val triggerMode: FallingTriggerMode = FallingTriggerMode.APPROACH,
    val triggerRadius: Float = 190f,
    val triggerSwitchIndex: Int? = null
)

data class GameChasingHole(
    val startX: Float,
    val y: Float = 592f,
    val width: Float = 145f,
    val height: Float = 48f,
    val triggerX: Float,
    val speed: Float = 170f,
    val maxTravel: Float = 720f,
    val direction: Float = 1f,
    val surfaceStartX: Float = startX,
    val surfaceEndX: Float = startX + maxTravel + width
)

data class GameCrusher(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val triggerX: Float,
    val axis: CrusherAxis,
    val travel: Float,
    val speed: Float = 330f,
    val delayMs: Long = 280L,
    val reverseAfterMs: Long = 1_350L,
    val style: CrusherStyle = CrusherStyle.STONE_COLUMN,
    val despawnAfterMs: Long = 0L
)

data class AdventureLevel(
    val number: Int,
    val worldName: String,
    val levelName: String,
    val objective: String,
    val difficultyLabel: String,
    val width: Float,
    val platforms: List<GamePlatform>,
    val movingPlatforms: List<GameMovingPlatform>,
    val hazards: List<GameHazard>,
    val barriers: List<GameBarrier>,
    val enemies: List<GameEnemy>,
    val crystals: List<GameCrystal>,
    val crates: List<GameCrate>,
    val switches: List<GameSwitch>,
    val checkpoints: List<GameCheckpoint>,
    val fans: List<GameFan>,
    val fallingObjects: List<GameFallingObject>,
    val chasingHoles: List<GameChasingHole>,
    val crushers: List<GameCrusher>,
    val requiredMechanisms: Int,
    val pickups: List<GamePickup>,
    val goalX: Float,
    val parSeconds: Int,
    val introStory: String? = null,
    val outroStory: String? = null,
    val companion: String? = null,
    val injured: Boolean = false,
    val weaponEnabled: Boolean = false,
    val acechantePresent: Boolean = false,
    val biome: AdventureBiome = AdventureBiome.FOREST_DAY,
    val entryKind: LevelExitKind = LevelExitKind.TRAIL,
    val exitKind: LevelExitKind = LevelExitKind.TRAIL,
    val entryConnection: String = "start",
    val exitConnection: String = "end",
    val spawnX: Float = 70f,
    val spawnY: Float = 520f,
    val goalY: Float = 485f,
    val keys: List<GameKey> = emptyList(),
    val requiresKey: Boolean = false,
    val requiredCrystals: Int = 0,
    val conduits: List<GameConduit> = emptyList(),
    val plantTraps: List<GamePlantTrap> = emptyList(),
    val trees: List<GameTree> = emptyList(),
    val launchers: List<GameLauncher> = emptyList()
)

object GeoAdventureLevelFactory {
    private enum class Beat {
        CLIMB_GATE,
        DESCEND_GATE,
        LOW_TUNNEL,
        HIGH_BRIDGE,
        SHAFT_UP,
        SHAFT_DOWN,
        SPLIT_ROUTE,
        FLOOR_DROP,
        CRUSHER_ROOM,
        FRUIT_AMBUSH,
        ROCK_RUN,
        FAN_SHAFT,
        KEY_DETOUR,
        FALSE_SAFE,
        ENEMY_NEST,
        WALL_MAZE,
        MOVING_GAP,
        COLLAPSING_BRIDGE,
        BOUNCE_CHAMBER,
        SWITCH_GATE,
        TRAP_LIFT,
        CHAIN_COLLAPSE,
        BAIT_DOOR,
        BACKTRACK_ROOM,
        FALSE_PIT,
        SINKING_FLOOR,
        ROCK_BRIDGE,
        SWING_LOG,
        PLANT_CONDUIT,
        LANDING_TRAP,
        SURPRISE_CORRIDOR,
        GIANT_SPIKE_ROOM,
        DECEPTIVE_GROVE,
        FALLING_WALL_BRIDGE,
        SWITCH_COUNTERTRAP,
        FALSE_EXIT_LOOP,
        VERTICAL_CONDUIT,
        ROLLING_ESCAPE,
        TRICK_ASCENT,
        BREAKAWAY_FLOOR,
        SILENT_ROOM,
        ENEMY_REBOUND,
        INVISIBLE_BLOCK_TRAP,
        DORMANT_AMBUSH,
        PROJECTILE_ALLEY,
        BAIT_CRATES,
        CHAIN_BLOCK_FALL
    }

    private data class Plan(
        val number: Int,
        val world: String,
        val name: String,
        val objective: String,
        val difficulty: String,
        val biome: AdventureBiome,
        val entry: LevelExitKind,
        val exit: LevelExitKind,
        val entryConnection: String,
        val exitConnection: String,
        val startY: Float,
        val beats: List<Beat>,
        val requiresKey: Boolean = false,
        val companion: String? = null,
        val weaponEnabled: Boolean = false,
        val acechantePresent: Boolean = false,
        val intro: String? = null,
        val outro: String? = null
    )

    private class MazeBuilder(private val plan: Plan) {
        private val platforms = mutableListOf<GamePlatform>()
        private val movingPlatforms = mutableListOf<GameMovingPlatform>()
        private val hazards = mutableListOf<GameHazard>()
        private val barriers = mutableListOf<GameBarrier>()
        private val enemies = mutableListOf<GameEnemy>()
        private val crates = mutableListOf<GameCrate>()
        private val switches = mutableListOf<GameSwitch>()
        private val checkpoints = mutableListOf<GameCheckpoint>()
        private val fans = mutableListOf<GameFan>()
        private val fallingObjects = mutableListOf<GameFallingObject>()
        private val chasingHoles = mutableListOf<GameChasingHole>()
        private val crushers = mutableListOf<GameCrusher>()
        private val pickups = mutableListOf<GamePickup>()
        private val keys = mutableListOf<GameKey>()
        private val conduits = mutableListOf<GameConduit>()
        private val plantTraps = mutableListOf<GamePlantTrap>()
        private val trees = mutableListOf<GameTree>()
        private val launchers = mutableListOf<GameLauncher>()

        private var x = 0f
        private var floorY = plan.startY
        private var requiredMechanisms = 0
        private var decoyCount = 0

        private fun structure(
            x: Float,
            y: Float,
            width: Float,
            height: Float = 34f,
            kind: PlatformKind = PlatformKind.SOLID,
            delayMs: Long = 720L,
            revealMode: PlatformRevealMode = PlatformRevealMode.APPROACH,
            revealRadius: Float = 175f,
            triggerSwitchIndex: Int? = null,
            role: PlatformRole = PlatformRole.LEDGE
        ) {
            val candidate = GamePlatform(
                x = x,
                y = y,
                width = width,
                height = height,
                kind = kind,
                triggerX = x - 75f,
                delayMs = delayMs,
                revealMode = revealMode,
                revealRadius = revealRadius,
                triggerSwitchIndex = triggerSwitchIndex,
                role = role
            )
            val duplicate = platforms.any { existing ->
                val exact = existing.role == candidate.role && existing.kind == candidate.kind &&
                    kotlin.math.abs(existing.x - candidate.x) < 1f && kotlin.math.abs(existing.y - candidate.y) < 1f &&
                    kotlin.math.abs(existing.width - candidate.width) < 1f && kotlin.math.abs(existing.height - candidate.height) < 1f
                val containedStructural = candidate.role in setOf(PlatformRole.WALL, PlatformRole.ROOF) &&
                    existing.role == candidate.role && existing.kind == PlatformKind.SOLID && candidate.kind == PlatformKind.SOLID &&
                    candidate.x >= existing.x - 2f && candidate.x + candidate.width <= existing.x + existing.width + 2f &&
                    candidate.y >= existing.y - 2f && candidate.y + candidate.height <= existing.y + existing.height + 2f
                exact || containedStructural
            }
            if (duplicate) return
            platforms += candidate
        }

        private fun ground(x: Float, y: Float, width: Float, kind: PlatformKind = PlatformKind.SOLID, delayMs: Long = 720L) {
            structure(x, y, width, (760f - y).coerceAtLeast(70f), kind, delayMs, role = PlatformRole.GROUND)
        }

        private fun ledge(
            x: Float,
            y: Float,
            width: Float,
            kind: PlatformKind = PlatformKind.SOLID,
            delayMs: Long = 720L,
            revealMode: PlatformRevealMode = PlatformRevealMode.APPROACH,
            revealRadius: Float = 175f,
            triggerSwitchIndex: Int? = null
        ) {
            // Mandatory touch landings must not become frame-perfect on a phone. Surprise/reveal
            // blocks keep their authored size because many of them are head-bump traps, not landings.
            val touchSafeWidth = if (kind == PlatformKind.REVEALING) width else width.coerceAtLeast(120f)
            structure(x, y, touchSafeWidth, 34f, kind, delayMs, revealMode, revealRadius, triggerSwitchIndex, PlatformRole.LEDGE)
        }

        private fun roof(x: Float, bottomY: Float, width: Float) {
            structure(x, 0f, width, bottomY.coerceAtLeast(45f), role = PlatformRole.ROOF)
        }

        private fun wall(x: Float, topY: Float, width: Float, bottomY: Float = 760f) {
            structure(x, topY, width, (bottomY - topY).coerceAtLeast(45f), role = PlatformRole.WALL)
        }

        private fun floorSpikes(
            x: Float,
            y: Float,
            width: Float = 58f,
            phase: Long = 0L,
            hidden: Boolean = true,
            triggerMode: HazardTriggerMode = HazardTriggerMode.APPROACH,
            height: Float = 44f
        ) {
            hazards += GameHazard(
                x = x,
                y = y - height,
                width = width,
                height = height,
                kind = if (hidden) HazardKind.HIDDEN_SPIKES else HazardKind.SPIKES,
                triggerX = x - 88f,
                cycleMs = 0L,
                phaseMs = phase,
                orientation = HazardOrientation.UP,
                camouflaged = hidden,
                triggerMode = triggerMode,
                retractable = false
            )
        }

        private fun timedFloorSpikes(x: Float, y: Float, width: Float = 58f, cycleMs: Long = 2_700L, phase: Long = 0L) {
            hazards += GameHazard(
                x = x,
                y = y - 44f,
                width = width,
                height = 44f,
                kind = HazardKind.SPIKES,
                triggerX = x - 90f,
                cycleMs = cycleMs,
                phaseMs = phase,
                orientation = HazardOrientation.UP,
                camouflaged = false,
                retractable = true
            )
        }

        private fun ceilingSpikes(x: Float, bottomY: Float, width: Float = 68f, height: Float = 46f, phase: Long = 0L) {
            val safeBottomY = bottomY.coerceAtLeast(45f)
            val support = platforms.any {
                it.x <= x && it.x + it.width >= x + width && kotlin.math.abs((it.y + it.height) - safeBottomY) <= 4f
            }
            if (!support) roof(x - 24f, safeBottomY, width + 48f)
            hazards += GameHazard(
                x = x,
                y = safeBottomY,
                width = width,
                height = height,
                kind = HazardKind.HIDDEN_SPIKES,
                triggerX = x - 92f,
                cycleMs = 0L,
                phaseMs = phase,
                orientation = HazardOrientation.DOWN,
                camouflaged = true,
                triggerMode = if ((plan.number + phase.toInt()) % 3 == 0) HazardTriggerMode.JUMP_NEAR else HazardTriggerMode.APPROACH,
                retractable = false
            )
        }

        private fun spikesFromLeftWall(wallX: Float, y: Float, height: Float = 92f, phase: Long = 0L) {
            wall(wallX, y - 18f, 38f, y + height + 18f)
            hazards += GameHazard(
                x = wallX + 30f,
                y = y,
                width = 46f,
                height = height,
                kind = HazardKind.HIDDEN_SPIKES,
                triggerX = wallX - 90f,
                cycleMs = 0L,
                phaseMs = phase,
                orientation = HazardOrientation.RIGHT,
                camouflaged = true,
                triggerMode = HazardTriggerMode.APPROACH,
                retractable = false
            )
        }

        private fun spikesFromRightWall(wallX: Float, y: Float, height: Float = 92f, phase: Long = 0L) {
            wall(wallX, y - 18f, 38f, y + height + 18f)
            hazards += GameHazard(
                x = wallX - 38f,
                y = y,
                width = 46f,
                height = height,
                kind = HazardKind.HIDDEN_SPIKES,
                triggerX = wallX - 140f,
                cycleMs = 0L,
                phaseMs = phase,
                orientation = HazardOrientation.LEFT,
                camouflaged = true,
                triggerMode = HazardTriggerMode.APPROACH,
                retractable = false
            )
        }

        private fun surpriseWallSpikesFromLeft(wallX: Float, y: Float, height: Float = 86f, triggerMode: HazardTriggerMode = HazardTriggerMode.APPROACH) {
            wall(wallX, y - 18f, 38f, y + height + 18f)
            hazards += GameHazard(
                x = wallX + 30f,
                y = y,
                width = 46f,
                height = height,
                kind = HazardKind.HIDDEN_SPIKES,
                triggerX = wallX - 115f,
                cycleMs = 0L,
                orientation = HazardOrientation.RIGHT,
                camouflaged = true,
                triggerMode = triggerMode,
                retractable = false
            )
        }

        private fun surpriseWallSpikesFromRight(wallX: Float, y: Float, height: Float = 86f, triggerMode: HazardTriggerMode = HazardTriggerMode.APPROACH) {
            wall(wallX, y - 18f, 38f, y + height + 18f)
            hazards += GameHazard(
                x = wallX - 38f,
                y = y,
                width = 46f,
                height = height,
                kind = HazardKind.HIDDEN_SPIKES,
                triggerX = wallX - 155f,
                cycleMs = 0L,
                orientation = HazardOrientation.LEFT,
                camouflaged = true,
                triggerMode = triggerMode,
                retractable = false
            )
        }

        private fun fire(x: Float, y: Float, width: Float = 70f, phase: Long = 0L) {
            hazards += GameHazard(
                x = x,
                y = y - 46f,
                width = width,
                height = 46f,
                kind = HazardKind.FIRE,
                triggerX = x - 100f,
                cycleMs = 2_250L,
                phaseMs = phase,
                orientation = HazardOrientation.UP
            )
        }

        private fun enemy(
            x: Float,
            y: Float,
            kind: GameEnemyKind,
            speedBoost: Float = 0f,
            onDefeatSwitchIndex: Int? = null,
            activationTriggerX: Float? = null,
            hiddenUntilActivated: Boolean = false
        ) {
            enemies += GameEnemy(
                x = x,
                y = y - 55f,
                range = 95f + (plan.number % 4) * 14f,
                detectionRange = 450f,
                health = if (plan.number >= 12) 3 else 2,
                kind = kind,
                speed = 88f + plan.number * 2.1f + speedBoost,
                onDefeatSwitchIndex = onDefeatSwitchIndex,
                activationTriggerX = activationTriggerX,
                hiddenUntilActivated = hiddenUntilActivated
            )
        }

        private fun fruit(
            x: Float,
            targetY: Float,
            behavior: FallingBehavior,
            treeFalls: Boolean = false,
            direction: Float = 1f,
            triggerMode: FallingTriggerMode = FallingTriggerMode.APPROACH,
            triggerRadius: Float = 190f
        ) {
            fallingObjects += GameFallingObject(
                x = x,
                startY = (targetY - 285f).coerceAtLeast(130f),
                targetY = targetY,
                size = 68f,
                triggerX = x - 150f,
                kind = FallingObjectKind.FRUIT,
                delayMs = 145L,
                behavior = behavior,
                rollDirection = direction,
                explosionRadius = 102f,
                chainCount = if (behavior == FallingBehavior.CHAIN) 2 else 1,
                chainSpacing = 58f,
                chaseDurationMs = 4_600L,
                chaseMaxTravel = 720f,
                treeFallsAfterTrap = treeFalls,
                explosionDelayMs = if (behavior == FallingBehavior.EXPLODE) 210L else 280L,
                triggerMode = triggerMode,
                triggerRadius = triggerRadius
            )
        }

        private fun normalTree(x: Float, groundY: Float, appleVisible: Boolean = false, variant: Int = 0) {
            trees += GameTree(x = x, groundY = groundY, appleVisible = appleVisible, variant = variant)
        }

        private fun rock(x: Float, targetY: Float, becomesPlatform: Boolean = false) {
            fallingObjects += GameFallingObject(
                x = x,
                startY = (targetY - 260f).coerceAtLeast(115f),
                targetY = targetY,
                size = if (becomesPlatform) 84f else 74f,
                triggerX = x - 145f,
                kind = FallingObjectKind.ROCK,
                delayMs = 190L,
                behavior = FallingBehavior.DROP,
                becomesPlatform = becomesPlatform
            )
        }

        private fun chasingRock(x: Float, targetY: Float, direction: Float = 1f) {
            fallingObjects += GameFallingObject(
                x = x,
                startY = (targetY - 245f).coerceAtLeast(115f),
                targetY = targetY,
                size = 78f,
                triggerX = x - 155f,
                kind = FallingObjectKind.ROCK,
                delayMs = 210L,
                behavior = FallingBehavior.CHASE,
                rollDirection = direction,
                chaseDurationMs = 4_300L,
                chaseMaxTravel = 690f
            )
        }

        private fun checkpoint(x: Float, y: Float) {
            val support = platforms.any { x in it.x..(it.x + it.width) && kotlin.math.abs(it.y - y) < 2f }
            if (!support) ground(x - 180f, y, 360f)
            checkpoints += GameCheckpoint(x, y - 85f, CheckpointKind.POPUP, x - 165f)
        }

        private fun decoy(x: Float, y: Float) {
            if (decoyCount >= 1) return
            checkpoints += GameCheckpoint(x, y - 85f, CheckpointKind.DECOY, x - 160f)
            decoyCount++
        }

        private fun addTrollEcho(roomStart: Float, roomEnd: Float, index: Int) {
            if (roomEnd - roomStart < 420f) return
            val candidates = platforms.filter { platform ->
                platform.kind == PlatformKind.SOLID &&
                    platform.role in setOf(PlatformRole.GROUND, PlatformRole.LEDGE) &&
                    platform.width >= 185f &&
                    platform.x + platform.width > roomStart + 180f &&
                    platform.x < roomEnd - 90f &&
                    platform.y in 300f..655f
            }
            if (candidates.isEmpty()) return

            val support = candidates[(plan.number * 7 + index * 3) % candidates.size]
            val left = maxOf(support.x + 24f, roomStart + 150f)
            val right = minOf(support.x + support.width - 24f, roomEnd - 100f)
            if (right - left < 95f) return
            val center = (left + right) * 0.5f
            val variant = (plan.number * 11 + index * 5) % 6

            when (variant) {
                0 -> {
                    val spikeWidth = minOf(46f, (right - left) * 0.28f)
                    val spikeX = if ((plan.number + index) % 2 == 0) left + 18f else right - spikeWidth - 18f
                    floorSpikes(
                        spikeX,
                        support.y,
                        width = spikeWidth,
                        hidden = true,
                        triggerMode = if ((plan.number + index) % 3 == 0) HazardTriggerMode.LAND_NEAR else HazardTriggerMode.APPROACH,
                        height = 36f
                    )
                }
                1 -> {
                    val spawnX = if ((plan.number + index) % 2 == 0) left + 24f else right - 78f
                    enemy(
                        spawnX,
                        support.y,
                        if ((plan.number + index) % 3 == 0) GameEnemyKind.JUMPER else GameEnemyKind.WALKER,
                        speedBoost = 12f + plan.number * 0.7f,
                        activationTriggerX = (center - 40f).coerceAtLeast(roomStart + 120f),
                        hiddenUntilActivated = true
                    )
                }
                2 -> {
                    val fromRight = (plan.number + index) % 2 == 0
                    launchers += GameLauncher(
                        x = if (fromRight) minOf(roomEnd - 55f, support.x + support.width + 72f) else maxOf(roomStart + 70f, support.x - 65f),
                        y = support.y - 132f,
                        direction = if (fromRight) LauncherDirection.LEFT else LauncherDirection.RIGHT,
                        triggerX = (center - 125f).coerceAtLeast(roomStart + 90f),
                        triggerRadius = 350f,
                        delayMs = 245L + ((plan.number + index) % 3) * 35L,
                        projectileSpeed = 455f + plan.number * 4.5f,
                        hiddenUntilTriggered = true
                    )
                }
                3 -> {
                    val trapX = (center - 36f).coerceIn(left, right - 72f)
                    fallingObjects += GameFallingObject(
                        x = trapX,
                        startY = (support.y - 315f).coerceAtLeast(68f),
                        targetY = support.y,
                        size = if ((plan.number + index) % 4 == 0) 78f else 70f,
                        triggerX = (center - 150f).coerceAtLeast(roomStart + 80f),
                        kind = if ((plan.number + index) % 4 == 0) FallingObjectKind.SPIKE_BALL else FallingObjectKind.ROCK,
                        delayMs = 275L,
                        behavior = FallingBehavior.DROP,
                        triggerMode = if ((plan.number + index) % 2 == 0) FallingTriggerMode.JUMP_NEAR else FallingTriggerMode.APPROACH,
                        triggerRadius = 190f
                    )
                }
                4 -> {
                    if (support.role == PlatformRole.GROUND && support.width >= 330f) {
                        val holeWidth = minOf(102f, support.width * 0.26f)
                        val holeStart = (center - holeWidth / 2f).coerceIn(support.x + 42f, support.x + support.width - holeWidth - 42f)
                        chasingHoles += GameChasingHole(
                            startX = holeStart,
                            y = support.y - 28f,
                            width = holeWidth,
                            height = 48f,
                            triggerX = holeStart - 68f,
                            speed = 118f + plan.number * 1.9f,
                            maxTravel = minOf(105f, support.width - holeWidth - 110f),
                            direction = if ((plan.number + index) % 2 == 0) 1f else -1f,
                            surfaceStartX = support.x + 24f,
                            surfaceEndX = support.x + support.width - 24f
                        )
                    } else {
                        floorSpikes(center - 20f, support.y, width = 40f, hidden = true, triggerMode = HazardTriggerMode.BACKTRACK, height = 34f)
                    }
                }
                else -> {
                    // A harmless-looking landing becomes a head-bump rule change only after the jump begins.
                    if (right - left >= 118f) {
                        val revealX = (center - 54f).coerceIn(left, right - 108f)
                        ledge(
                            revealX,
                            (support.y - 150f).coerceAtLeast(145f),
                            108f,
                            PlatformKind.REVEALING,
                            720L,
                            PlatformRevealMode.JUMP_NEAR,
                            165f
                        )
                    } else {
                        floorSpikes(center - 18f, support.y, width = 36f, hidden = true, triggerMode = HazardTriggerMode.JUMP_NEAR, height = 32f)
                    }
                }
            }

            // Every second room carries a second hidden consequence, including level 1.
            if (index % 2 == 1) {
                val secondaryX = if ((plan.number + index) % 2 == 0) left + 35f else right - 55f
                if (support.role == PlatformRole.GROUND && support.width >= 250f) {
                    floorSpikes(
                        secondaryX.coerceIn(support.x + 22f, support.x + support.width - 58f),
                        support.y,
                        width = 38f,
                        hidden = true,
                        triggerMode = if ((plan.number + index) % 4 == 0) HazardTriggerMode.BACKTRACK else HazardTriggerMode.LAND_NEAR,
                        height = 32f
                    )
                } else {
                    launchers += GameLauncher(
                        x = minOf(roomEnd - 45f, support.x + support.width + 50f),
                        y = support.y - 112f,
                        direction = LauncherDirection.LEFT,
                        triggerX = (center - 70f).coerceAtLeast(roomStart + 90f),
                        triggerRadius = 300f,
                        delayMs = 310L,
                        projectileSpeed = 430f + plan.number * 3.5f,
                        hiddenUntilTriggered = true
                    )
                }
            }

            // Late acts add a third consequence after GEO has already reacted to the first two.
            // It comes from behind so it does not telegraph the route from the camera ahead.
            if (plan.number >= 12 && index % 3 == 0) {
                launchers += GameLauncher(
                    x = maxOf(roomStart + 55f, support.x - 72f),
                    y = support.y - 122f,
                    direction = LauncherDirection.RIGHT,
                    triggerX = (center - 15f).coerceAtLeast(roomStart + 110f),
                    triggerRadius = 330f,
                    delayMs = 285L,
                    projectileSpeed = 470f + plan.number * 4.2f,
                    hiddenUntilTriggered = true
                )
            }
        }

        private fun addBeat(beat: Beat, index: Int) {
            when (beat) {
                Beat.CLIMB_GATE -> climbGate(index)
                Beat.DESCEND_GATE -> descendGate(index)
                Beat.LOW_TUNNEL -> lowTunnel(index)
                Beat.HIGH_BRIDGE -> highBridge(index)
                Beat.SHAFT_UP -> shaftUp(index)
                Beat.SHAFT_DOWN -> shaftDown(index)
                Beat.SPLIT_ROUTE -> splitRoute(index)
                Beat.FLOOR_DROP -> floorDrop(index)
                Beat.CRUSHER_ROOM -> crusherRoom(index)
                Beat.FRUIT_AMBUSH -> fruitAmbush(index)
                Beat.ROCK_RUN -> rockRun(index)
                Beat.FAN_SHAFT -> fanShaft(index)
                Beat.KEY_DETOUR -> keyDetour(index)
                Beat.FALSE_SAFE -> falseSafe(index)
                Beat.ENEMY_NEST -> enemyNest(index)
                Beat.WALL_MAZE -> wallMaze(index)
                Beat.MOVING_GAP -> movingGap(index)
                Beat.COLLAPSING_BRIDGE -> collapsingBridge(index)
                Beat.BOUNCE_CHAMBER -> bounceChamber(index)
                Beat.SWITCH_GATE -> switchGate(index)
                Beat.TRAP_LIFT -> trapLift(index)
                Beat.CHAIN_COLLAPSE -> chainCollapse(index)
                Beat.BAIT_DOOR -> baitDoor(index)
                Beat.BACKTRACK_ROOM -> backtrackRoom(index)
                Beat.FALSE_PIT -> falsePit(index)
                Beat.SINKING_FLOOR -> sinkingFloor(index)
                Beat.ROCK_BRIDGE -> rockBridge(index)
                Beat.SWING_LOG -> swingLog(index)
                Beat.PLANT_CONDUIT -> plantConduit(index)
                Beat.LANDING_TRAP -> landingTrap(index)
                Beat.SURPRISE_CORRIDOR -> surpriseCorridor(index)
                Beat.GIANT_SPIKE_ROOM -> giantSpikeRoom(index)
                Beat.DECEPTIVE_GROVE -> deceptiveGrove(index)
                Beat.FALLING_WALL_BRIDGE -> fallingWallBridge(index)
                Beat.SWITCH_COUNTERTRAP -> switchCountertrap(index)
                Beat.FALSE_EXIT_LOOP -> falseExitLoop(index)
                Beat.VERTICAL_CONDUIT -> verticalConduit(index)
                Beat.ROLLING_ESCAPE -> rollingEscape(index)
                Beat.TRICK_ASCENT -> trickAscent(index)
                Beat.BREAKAWAY_FLOOR -> breakawayFloor(index)
                Beat.SILENT_ROOM -> silentRoom(index)
                Beat.ENEMY_REBOUND -> enemyRebound(index)
                Beat.INVISIBLE_BLOCK_TRAP -> invisibleBlockTrap(index)
                Beat.DORMANT_AMBUSH -> dormantAmbush(index)
                Beat.PROJECTILE_ALLEY -> projectileAlley(index)
                Beat.BAIT_CRATES -> baitCrates(index)
                Beat.CHAIN_BLOCK_FALL -> chainBlockFall(index)
            }
        }

        private fun climbGate(i: Int) {
            val start = x
            val target = (floorY - if (i % 2 == 0) 185f else 150f).coerceAtLeast(315f)
            ground(start, floorY, 210f)
            ledge(start + 260f, floorY - 92f, 145f)
            ledge(start + 455f, target, 170f)
            wall(start + 650f, target + 34f, 86f)
            ground(start + 735f, target, 250f)
            floorSpikes(start + 85f, floorY, phase = 180L * i)
            spikesFromRightWall(start + 650f, target + 88f, 82f, 110L * i)
            enemy(start + 820f, target, GameEnemyKind.JUMPER)
            floorY = target
            x += 965f
        }

        private fun descendGate(i: Int) {
            val start = x
            val target = (floorY + if (i % 2 == 0) 165f else 130f).coerceAtMost(625f)
            ground(start, floorY, 200f)
            ledge(start + 250f, floorY + 80f, 150f)
            ledge(start + 455f, target, 170f)
            roof(start + 620f, target - 132f, 160f)
            ground(start + 620f, target, 360f)
            ceilingSpikes(start + 670f, target - 132f, 72f, 42f, 170L * i)
            floorSpikes(start + 830f, target, phase = 240L * i)
            enemy(start + 900f, target, GameEnemyKind.WALKER)
            floorY = target
            x += 960f
        }

        private fun lowTunnel(i: Int) {
            val start = x
            val tunnelY = floorY.coerceAtLeast(565f)
            if (tunnelY != floorY) {
                ledge(start + 40f, floorY + 80f, 150f)
                floorY = tunnelY
            }
            ground(start, floorY, 900f)
            roof(start + 110f, floorY - 172f, 680f)
            ceilingSpikes(start + 220f, floorY - 172f, 68f, 38f, 190L * i)
            // Nothing lethal is advertised in advance: the floor looks normal until GEO commits.
            floorSpikes(
                start + 420f,
                floorY,
                phase = 270L * i,
                hidden = true,
                triggerMode = if ((plan.number + i) % 2 == 0) HazardTriggerMode.LAND_NEAR else HazardTriggerMode.APPROACH,
                height = 40f
            )
            chasingHoles += GameChasingHole(
                startX = start + 470f,
                y = floorY - 28f,
                width = 115f,
                height = 48f,
                triggerX = start + 390f,
                speed = 135f,
                maxTravel = 180f,
                direction = 1f,
                surfaceStartX = start + 350f,
                surfaceEndX = start + 680f
            )
            ceilingSpikes(start + 610f, floorY - 172f, 68f, 38f, 340L * i)
            spikesFromRightWall(start + 792f, floorY - 155f, 76f, 110L * i)
            enemy(start + 735f, floorY, if (i % 2 == 0) GameEnemyKind.WALKER else GameEnemyKind.JUMPER)
            x += 900f
        }

        private fun highBridge(i: Int) {
            val start = x
            val bridgeY = (floorY - 165f).coerceAtLeast(320f)
            ground(start, floorY, 180f)
            ledge(start + 245f, bridgeY + 65f, 130f)
            ledge(start + 430f, bridgeY, 150f)
            ledge(start + 635f, bridgeY + 35f, 145f)
            wall(start + 390f, bridgeY + 34f, 65f)
            wall(start + 760f, bridgeY + 69f, 65f)
            ground(start + 825f, bridgeY + 35f, 230f)
            floorSpikes(start + 455f, bridgeY, phase = 160L * i)
            rock(start + 650f, bridgeY + 35f, becomesPlatform = i % 3 == 0)
            enemy(start + 900f, bridgeY + 35f, GameEnemyKind.FLYER)
            floorY = bridgeY + 35f
            x += 1_040f
        }

        private fun shaftUp(i: Int) {
            val start = x
            val target = (floorY - 205f).coerceAtLeast(300f)

            // This room used to have a 15 px choke between a hanging roof and the first ledge.
            // GEO is 44 px wide, so the geometry could be mathematically close yet physically sealed.
            // Every transition below keeps a real body-width corridor plus reaction margin.
            ground(start, floorY, 230f)
            roof(start + 260f, floorY - 170f, 70f)
            ceilingSpikes(start + 272f, floorY - 170f, 46f, 30f, 160L * i)
            ledge(start + 390f, floorY - 90f, 145f)
            ledge(start + 610f, floorY - 165f, 145f)
            ledge(start + 830f, target, 155f)
            // Low pillar under the route: visual structure without closing the playable corridor.
            wall(start + 1_025f, target + 34f, 70f)
            ground(start + 1_095f, target, 260f)
            floorSpikes(start + 635f, floorY - 165f, phase = 220L * i)
            enemy(start + 865f, target, GameEnemyKind.JUMPER)
            floorY = target
            x += 1_335f
        }

        private fun shaftDown(i: Int) {
            val start = x
            val target = (floorY + 205f).coerceAtMost(625f)
            ground(start, floorY, 190f)
            roof(start + 230f, floorY - 138f, 140f)
            ledge(start + 305f, floorY + 80f, 140f)
            ledge(start + 495f, floorY + 150f, 140f)
            ground(start + 690f, target, 450f)
            ceilingSpikes(start + 265f, floorY - 138f, 64f, 38f, 170L * i)
            floorSpikes(start + 735f, target, phase = 280L * i)
            rock(start + 940f, target, becomesPlatform = i % 4 == 0)
            floorY = target
            x += 1_120f
        }

        private fun splitRoute(i: Int) {
            val start = x
            ground(start, floorY, 860f)
            roof(start + 240f, floorY - 220f, 270f)
            wall(start + 505f, floorY - 220f, 74f, floorY - 118f)
            if ((plan.number + i) % 2 == 0) {
                ledge(start + 250f, floorY - 125f, 190f, PlatformKind.REVEALING, 720L, PlatformRevealMode.JUMP_NEAR, 190f)
            } else {
                ledge(start + 250f, floorY - 125f, 190f)
            }
            ledge(start + 590f, floorY - 170f, 160f)
            floorSpikes(start + 150f, floorY, phase = 150L * i)
            ceilingSpikes(start + 315f, floorY - 220f, 70f, 45f, 260L * i)
            floorSpikes(start + 640f, floorY - 170f, phase = 390L * i)
            enemy(start + 760f, floorY, GameEnemyKind.SHOOTER)
            x += 860f
        }

        private fun floorDrop(i: Int) {
            val start = x
            val lower = (floorY + 130f).coerceAtMost(650f)
            ground(start, floorY, 210f)
            ledge(start + 245f, floorY, 230f, PlatformKind.PROXIMITY_DISAPPEARING, 1_000L + (i % 3) * 120L)
            ground(start + 245f, lower, 500f)
            ledge(start + 540f, lower - 75f, 135f)
            ledge(start + 725f, floorY, 145f)
            ground(start + 920f, floorY, 220f)
            floorSpikes(start + 390f, lower, phase = 230L * i)
            chasingHoles += GameChasingHole(
                startX = start + 505f,
                y = lower - 28f,
                width = 120f,
                height = 48f,
                triggerX = start + 450f,
                speed = 150f,
                maxTravel = 165f,
                direction = 1f,
                surfaceStartX = start + 430f,
                surfaceEndX = start + 720f
            )
            enemy(start + 620f, lower - 75f, GameEnemyKind.JUMPER)
            spikesFromLeftWall(start + 905f, floorY - 92f, 82f, 130L * i)
            x += 1_120f
        }

        private fun crusherRoom(i: Int) {
            val start = x
            ground(start, floorY, 900f)
            roof(start + 130f, floorY - 205f, 640f)
            crushers += GameCrusher(
                x = start + 310f,
                y = floorY - 190f,
                width = 94f,
                height = 150f,
                triggerX = start + 165f,
                axis = CrusherAxis.VERTICAL,
                travel = 145f,
                speed = 280f,
                delayMs = 360L,
                reverseAfterMs = 1_550L,
                style = if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) CrusherStyle.LOG_PRESS else CrusherStyle.STONE_COLUMN
            )
            crushers += GameCrusher(
                x = start + 620f,
                y = floorY - 165f,
                width = 72f,
                height = 125f,
                triggerX = start + 500f,
                axis = CrusherAxis.HORIZONTAL,
                travel = -120f,
                speed = 255f,
                delayMs = 370L,
                reverseAfterMs = 1_650L,
                style = CrusherStyle.STONE_COLUMN
            )
            floorSpikes(start + 485f, floorY, phase = 210L * i)
            enemy(start + 790f, floorY, GameEnemyKind.WALKER)
            x += 900f
        }

        private fun fruitAmbush(i: Int) {
            val start = x
            ground(start, floorY, 940f)
            // Three visually similar trees, but only ONE is the fruit trap.
            // This keeps the sequence surprising without turning every tree into danger.
            val trapSlot = (plan.number + i) % 3
            val treeXs = listOf(start + 205f, start + 490f, start + 760f)
            treeXs.forEachIndexed { slot, treeX ->
                if (slot == trapSlot) {
                    val behavior = when ((plan.number + i) % 4) {
                        0 -> FallingBehavior.EXPLODE
                        1 -> FallingBehavior.ROLL
                        2 -> FallingBehavior.CHASE
                        else -> FallingBehavior.DROP
                    }
                    val trigger = when ((plan.number + i) % 5) {
                        0 -> FallingTriggerMode.PASS_UNDER
                        1 -> FallingTriggerMode.JUMP_NEAR
                        2 -> FallingTriggerMode.LAND_NEAR
                        3 -> FallingTriggerMode.BACKTRACK
                        else -> FallingTriggerMode.APPROACH
                    }
                    fruit(treeX, floorY, behavior, treeFalls = (plan.number + i) % 3 == 0, triggerMode = trigger, triggerRadius = 170f)
                } else {
                    normalTree(treeX + 34f, floorY, appleVisible = (slot + plan.number + i) % 2 == 0, variant = slot + i)
                }
            }
            // The second surprise comes from the scenery, not another obvious apple tree.
            if ((plan.number + i) % 2 == 0) {
                floorSpikes(start + 630f, floorY, width = 60f, hidden = true, triggerMode = HazardTriggerMode.LAND_NEAR)
            } else {
                rock(start + 640f, floorY, becomesPlatform = (plan.number + i) % 4 == 1)
            }
            enemy(start + 850f, floorY, GameEnemyKind.JUMPER)
            x += 940f
        }

        private fun rockRun(i: Int) {
            val start = x
            ground(start, floorY, 940f)
            roof(start + 120f, floorY - 230f, 690f)
            rock(start + 260f, floorY)
            rock(start + 500f, floorY, becomesPlatform = (plan.number + i) % 4 == 0)
            if ((plan.number + i) % 2 == 0) chasingRock(start + 735f, floorY, direction = -1f) else rock(start + 735f, floorY)
            floorSpikes(start + 390f, floorY, phase = 180L * i)
            ceilingSpikes(start + 620f, floorY - 230f, 78f, 50f, 260L * i)
            x += 940f
        }

        private fun fanShaft(i: Int) {
            val start = x
            val target = (floorY - 155f).coerceAtLeast(320f)
            ground(start, floorY, 220f)
            wall(start + 250f, 250f, 56f, floorY - 50f)
            wall(start + 620f, target + 35f, 70f)
            ledge(start + 340f, floorY - 95f, 120f)
            ledge(start + 500f, target, 125f)
            ground(start + 690f, target, 270f)
            fans += GameFan(start + 300f, target - 15f, 300f, floorY - target + 20f, 0f, -315f, 2_900L, 230L * i)
            floorSpikes(start + 545f, target, phase = 170L * i)
            spikesFromRightWall(start + 620f, target + 58f, 82f, 260L * i)
            floorY = target
            x += 940f
        }

        private fun keyDetour(i: Int) {
            val start = x
            val keyY = (floorY - 175f).coerceAtLeast(310f)
            ground(start, floorY, 1_000f)
            ledge(start + 220f, floorY - 85f, 135f)
            ledge(start + 410f, keyY, 190f)
            ledge(start + 655f, floorY - 95f, 140f)
            keys += GameKey(start + 500f, keyY - 72f, start + 240f)
            floorSpikes(start + 300f, floorY - 85f, phase = 150L * i)
            ceilingSpikes(start + 460f, keyY - 110f, 74f, 42f, 300L * i)
            enemy(start + 720f, floorY - 95f, GameEnemyKind.GUARDIAN)
            fruit(start + 850f, floorY, FallingBehavior.EXPLODE)
            x += 1_000f
        }

        private fun falseSafe(i: Int) {
            val start = x
            ground(start, floorY, 820f)
            if ((plan.number + i) % 2 == 0) decoy(start + 315f, floorY)
            floorSpikes(start + 180f, floorY, phase = 190L * i)
            floorSpikes(start + 470f, floorY, phase = 420L * i)
            if ((plan.number + i) % 2 == 1) {
                chasingHoles += GameChasingHole(
                    startX = start + 235f,
                    y = floorY - 28f,
                    width = 125f,
                    height = 48f,
                    triggerX = start + 175f,
                    speed = 145f,
                    maxTravel = 330f,
                    direction = 1f,
                    surfaceStartX = start + 120f,
                    surfaceEndX = start + 710f
                )
            }
            if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) {
                fruit(start + 610f, floorY, FallingBehavior.CHASE, triggerMode = FallingTriggerMode.PASS_UNDER, triggerRadius = 175f)
            } else {
                rock(start + 610f, floorY)
            }
            enemy(start + 735f, floorY, GameEnemyKind.FLYER)
            x += 820f
        }

        private fun enemyNest(i: Int) {
            val start = x
            ground(start, floorY, 940f)
            ledge(start + 250f, floorY - 115f, 150f)
            ledge(start + 520f, floorY - 175f, 160f)
            val defeatGate = (plan.number + i) % 3 == 0
            val defeatSwitchIndex = if (defeatGate) {
                switches += GameSwitch(start + 610f, -420f, start + 760f)
                requiredMechanisms++
                barriers += GameBarrier(start + 760f, floorY - 285f, 56f, 285f, switches.lastIndex)
                switches.lastIndex
            } else null
            enemy(start + 150f, floorY, GameEnemyKind.WALKER)
            enemy(start + 315f, floorY - 115f, GameEnemyKind.JUMPER)
            enemy(start + 585f, floorY - 175f, if (plan.number >= 10) GameEnemyKind.SHOOTER else GameEnemyKind.FLYER, onDefeatSwitchIndex = defeatSwitchIndex)
            enemy(start + 800f, floorY, if (plan.number >= 15) GameEnemyKind.GUARDIAN else GameEnemyKind.JUMPER)
            floorSpikes(start + 420f, floorY, phase = 220L * i)
            ceilingSpikes(start + 700f, floorY - 210f, 70f, 46f, 340L * i)
            crushers += GameCrusher(
                x = start + 820f,
                y = floorY - 210f,
                width = 96f,
                height = 150f,
                triggerX = start + 690f,
                axis = CrusherAxis.VERTICAL,
                travel = 145f,
                speed = 265f,
                delayMs = 320L,
                reverseAfterMs = 1_450L,
                style = CrusherStyle.RUIN_BLOCK,
                despawnAfterMs = 2_600L
            )
            x += 940f
        }

        private fun wallMaze(i: Int) {
            val start = x
            ground(start, floorY, 1_060f)
            val hangingBottom = floorY - 125f
            roof(start + 240f, hangingBottom, 105f)
            wall(start + 475f, floorY - 175f, 85f)
            roof(start + 690f, floorY - 165f, 105f)
            wall(start + 895f, floorY - 155f, 80f)
            ceilingSpikes(start + 255f, hangingBottom, 70f, 42f, 150L * i)
            spikesFromLeftWall(start + 475f, floorY - 150f, 84f, 260L * i)
            floorSpikes(start + 610f, floorY, phase = 340L * i)
            ceilingSpikes(start + 710f, floorY - 165f, 66f, 38f, 410L * i)
            if ((plan.number + i) % 3 == 0) {
                crushers += GameCrusher(
                    x = start + 820f,
                    y = floorY - 230f,
                    width = 132f,
                    height = 170f,
                    triggerX = start + 690f,
                    axis = CrusherAxis.VERTICAL,
                    travel = 175f,
                    speed = 275f,
                    delayMs = 360L,
                    reverseAfterMs = 1_650L,
                    style = CrusherStyle.FALLING_WALL,
                    despawnAfterMs = 3_000L
                )
            }
            enemy(start + 995f, floorY, GameEnemyKind.JUMPER)
            x += 1_060f
        }

        private fun movingGap(i: Int) {
            val start = x
            ground(start, floorY, 190f)
            // Three real moving platforms, but each transfer has a reachable worst-case window.
            // GEO is carried by platform delta in runtime, so these now behave like actual lifts.
            movingPlatforms += GameMovingPlatform(start + 300f, floorY - 58f, 150f, 54f, true, 3.25f)
            ledge(start + 480f, floorY - 108f, 105f)
            movingPlatforms += GameMovingPlatform(start + 650f, floorY - 138f, 150f, 62f, false, 3.55f)
            ledge(start + 850f, floorY - 92f, 105f)
            movingPlatforms += GameMovingPlatform(start + 1_020f, floorY - 55f, 150f, 48f, true, 3.15f)
            ground(start + 1_235f, floorY - 20f, 270f)

            fallingObjects += GameFallingObject(
                x = start + 715f,
                startY = (floorY - 355f).coerceAtLeast(60f),
                targetY = floorY - 138f,
                size = 72f,
                triggerX = start + 585f,
                kind = FallingObjectKind.ROCK,
                delayMs = 150L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.APPROACH,
                triggerRadius = 205f
            )
            crushers += GameCrusher(start + 1_130f, floorY - 220f, 78f, 145f, start + 1_000f, CrusherAxis.VERTICAL, 118f, 235f, 420L, 1_700L, CrusherStyle.FALLING_WALL, 2_850L)
            floorY -= 20f
            x += 1_495f
        }

        private fun collapsingBridge(i: Int) {
            val start = x
            ground(start, floorY, 160f)
            ledge(start + 220f, floorY - 30f, 180f, PlatformKind.FALLING, 900L)
            ledge(start + 450f, floorY - 70f, 180f, PlatformKind.PROXIMITY_DISAPPEARING, 1_050L)
            ledge(start + 680f, floorY - 20f, 180f, PlatformKind.FALLING, 980L)
            ground(start + 920f, floorY, 240f)
            floorSpikes(start + 500f, floorY - 70f, phase = 210L * i)
            rock(start + 735f, floorY - 20f, becomesPlatform = true)
            enemy(start + 1_015f, floorY, GameEnemyKind.WALKER)
            x += 1_140f
        }

        private fun bounceChamber(i: Int) {
            val start = x
            ground(start, floorY, 230f)
            // Keep the bounce route open. The old 600 px roof sat directly over the required
            // trajectory and could turn the intended jump into a closed chamber.
            ledge(start + 300f, floorY - 15f, 125f, PlatformKind.BOUNCE)
            ledge(start + 490f, floorY - 155f, 145f)
            ledge(start + 700f, floorY - 92f, 135f)
            // A short hanging shelf keeps the ceiling-trap idea without covering the whole room.
            ledge(start + 555f, floorY - 285f, 210f)
            ground(start + 900f, floorY, 250f)
            ceilingSpikes(start + 620f, floorY - 251f, 62f, 40f, 160L * i)
            floorSpikes(start + 540f, floorY - 155f, width = 46f, phase = 280L * i, height = 38f)
            surpriseWallSpikesFromRight(start + 850f, floorY - 145f, 72f, HazardTriggerMode.APPROACH)
            enemy(start + 995f, floorY, GameEnemyKind.FLYER)
            x += 1_135f
        }

        private fun switchGate(i: Int) {
            val start = x
            ground(start, floorY, 960f)
            ledge(start + 210f, floorY - 120f, 150f)
            switches += GameSwitch(start + 285f, floorY - 174f, start + 710f)
            val switchIndex = switches.lastIndex
            requiredMechanisms++
            barriers += GameBarrier(start + 710f, floorY - 300f, 58f, 300f, switchIndex)
            roof(start + 480f, floorY - 210f, 180f)
            floorSpikes(start + 410f, floorY, phase = 190L * i)
            ceilingSpikes(start + 525f, floorY - 210f, 76f, 45f, 330L * i)
            enemy(start + 830f, floorY, GameEnemyKind.GUARDIAN)
            x += 960f
        }


        private fun trapLift(i: Int) {
            val start = x
            val upper = (floorY - 165f).coerceAtLeast(315f)
            ground(start, floorY, 235f)
            // Open lift shaft: no giant roof directly across the mandatory trajectory.
            ledge(start + 280f, floorY - 72f, 105f)
            movingPlatforms += GameMovingPlatform(start + 415f, floorY - 48f, 155f, 88f, true, 3.25f)
            ledge(start + 600f, upper + 58f, 115f)
            movingPlatforms += GameMovingPlatform(start + 745f, upper + 40f, 150f, 58f, true, 2.95f)
            ground(start + 955f, upper, 300f)
            // Short overhead shelf supplies the troll without sealing the shaft.
            roof(start + 560f, upper - 88f, 125f)
            ceilingSpikes(start + 592f, upper - 88f, 58f, 36f, 130L * i)
            floorSpikes(start + 1_050f, upper, width = 50f, phase = 180L * i, hidden = true)
            enemy(start + 1_155f, upper, GameEnemyKind.JUMPER, speedBoost = -10f)
            floorY = upper
            x += 1_245f
        }

        private fun chainCollapse(i: Int) {
            val start = x
            ground(start, floorY, 180f)
            ledge(start + 320f, floorY - 25f, 125f, PlatformKind.FALLING, 920L)
            ledge(start + 585f, floorY - 70f, 115f, PlatformKind.PROXIMITY_DISAPPEARING, 930L)
            ledge(start + 835f, floorY - 20f, 120f, PlatformKind.FALLING, 860L)
            ground(start + 1_100f, floorY - 35f, 250f)

            // Sequential ceiling objects: each is invisible before its trigger and attacks the landing zone.
            listOf(370f, 635f, 885f).forEachIndexed { idx, off ->
                fallingObjects += GameFallingObject(
                    x = start + off,
                    startY = (floorY - 330f - idx * 12f).coerceAtLeast(70f),
                    targetY = when (idx) { 0 -> floorY - 25f; 1 -> floorY - 70f; else -> floorY - 20f },
                    size = 72f + idx * 3f,
                    triggerX = start + off - 145f,
                    kind = FallingObjectKind.ROCK,
                    delayMs = 170L + idx * 20L,
                    behavior = FallingBehavior.DROP,
                    triggerMode = if (idx == 1) FallingTriggerMode.JUMP_NEAR else FallingTriggerMode.LAND_NEAR,
                    triggerRadius = 165f
                )
            }
            crushers += GameCrusher(start + 980f, floorY - 225f, 92f, 160f, start + 865f, CrusherAxis.VERTICAL, 140f, 258f, 360L, 1_550L, CrusherStyle.FALLING_WALL, 2_750L)
            floorY -= 35f
            x += 1_340f
        }

        private fun baitDoor(i: Int) {
            val start = x
            ground(start, floorY, 250f)
            ledge(start + 415f, floorY - 120f, 135f)
            ledge(start + 680f, floorY - 55f, 125f)
            ground(start + 980f, floorY, 250f)

            switches += GameSwitch(start + 480f, floorY - 174f, start + 875f)
            val switchIndex = switches.lastIndex
            requiredMechanisms++
            barriers += GameBarrier(start + 875f, floorY - 300f, 58f, 300f, switchIndex)
            // The obvious door is correct, but opening it starts a second trap from above.
            fallingObjects += GameFallingObject(
                x = start + 730f,
                startY = (floorY - 330f).coerceAtLeast(70f),
                targetY = floorY - 55f,
                size = 80f,
                triggerX = start + 610f,
                kind = FallingObjectKind.ROCK,
                delayMs = 175L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.SWITCH,
                triggerSwitchIndex = switchIndex
            )
            crushers += GameCrusher(start + 920f, floorY - 225f, 100f, 160f, start + 845f, CrusherAxis.VERTICAL, 145f, 265f, 350L, 1_550L, if (plan.biome == AdventureBiome.DESERT_DAWN) CrusherStyle.RUIN_BLOCK else CrusherStyle.FALLING_WALL, 2_750L)
            if ((plan.number + i) % 2 == 0) {
                conduits += GameConduit(start + 110f, floorY - 92f, targetX = start + 40f, targetY = floorY - 58f, direction = ConduitDirection.SIDE, endsLevel = false, autoEnter = false)
            }
            enemy(start + 1_090f, floorY, GameEnemyKind.JUMPER, speedBoost = -10f)
            x += 1_220f
        }

        private fun backtrackRoom(i: Int) {
            val start = x
            val upper = (floorY - 95f).coerceAtLeast(325f)
            ground(start, floorY, 250f)
            ledge(start + 420f, upper, 135f)
            ground(start + 1_020f, floorY, 250f)

            switches += GameSwitch(start + 145f, floorY - 54f, start + 710f)
            val revealSwitchIndex = switches.lastIndex
            ledge(start + 710f, floorY - 25f, 130f, PlatformKind.REVEALING, 720L, PlatformRevealMode.SWITCH, 175f, revealSwitchIndex)
            requiredMechanisms++
            // The spike is not visible until the player has gone past it and decides to retreat.
            floorSpikes(start + 465f, upper, width = 48f, hidden = true, triggerMode = HazardTriggerMode.BACKTRACK, height = 38f)
            fruit(start + 770f, floorY - 25f, FallingBehavior.CHASE, direction = -1f, triggerMode = FallingTriggerMode.BACKTRACK, triggerRadius = 170f)
            fallingObjects += GameFallingObject(
                x = start + 925f,
                startY = (floorY - 315f).coerceAtLeast(80f),
                targetY = floorY,
                size = 78f,
                triggerX = start + 820f,
                kind = FallingObjectKind.ROCK,
                delayMs = 175L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.BACKTRACK,
                triggerRadius = 190f
            )
            enemy(start + 1_125f, floorY, GameEnemyKind.WALKER, speedBoost = -10f)
            x += 1_270f
        }

        private fun falsePit(i: Int) {
            val start = x
            ground(start, floorY, 210f)
            val lower = (floorY + 135f).coerceAtMost(650f)
            ledge(start + 245f, lower, 185f)
            ledge(start + 485f, lower - 65f, 150f)
            ground(start + 685f, floorY, 300f)
            floorSpikes(start + 275f, lower, phase = 140L * i)
            enemy(start + 520f, lower - 65f, GameEnemyKind.JUMPER)
            fallingObjects += GameFallingObject(
                x = start + 760f,
                startY = (floorY - 245f).coerceAtLeast(120f),
                targetY = floorY,
                size = 82f,
                triggerX = start + 650f,
                kind = FallingObjectKind.ROCK,
                delayMs = 220L,
                behavior = FallingBehavior.DROP,
                becomesPlatform = true
            )
            x += 970f
        }

        private fun sinkingFloor(i: Int) {
            val start = x
            ground(start, floorY, 165f)
            ledge(start + 300f, floorY, 120f, PlatformKind.PROXIMITY_DISAPPEARING, 1_090L)
            ledge(start + 535f, floorY + 12f, 115f, PlatformKind.PROXIMITY_DISAPPEARING, 960L)
            ledge(start + 760f, floorY - 28f, 115f, PlatformKind.PROXIMITY_DISAPPEARING, 900L)
            ledge(start + 985f, floorY + 16f, 110f, PlatformKind.FALLING, 820L)
            ground(start + 1_230f, floorY - 18f, 250f)

            roof(start + 470f, floorY - 185f, 430f)
            // One surprise from the roof, not a carpet of spikes.
            ceilingSpikes(start + 690f, floorY - 185f, 58f, 40f, 260L * i)
            enemy(start + 1_345f, floorY - 18f, GameEnemyKind.WALKER, speedBoost = -12f)
            floorY -= 18f
            x += 1_470f
        }

        private fun rockBridge(i: Int) {
            val start = x
            val lower = (floorY + 45f).coerceAtMost(640f)
            ground(start, floorY, 185f)
            // The boulder is still the obvious stepping stone, but two narrow permanent
            // footholds keep the room solvable even if its timing is missed. They are intentionally
            // small so the safer-looking boulder remains the tempting route.
            ledge(start + 335f, lower - 10f, 60f)
            ledge(start + 520f, lower - 25f, 75f)
            fallingObjects += GameFallingObject(
                x = start + 405f,
                startY = (floorY - 345f).coerceAtLeast(65f),
                targetY = lower + 10f,
                size = 100f,
                triggerX = start + 245f,
                kind = FallingObjectKind.ROCK,
                delayMs = 190L,
                behavior = FallingBehavior.DROP,
                becomesPlatform = true,
                triggerMode = FallingTriggerMode.APPROACH,
                triggerRadius = 185f
            )
            ledge(start + 650f, lower - 35f, 125f)
            ledge(start + 885f, floorY - 75f, 120f)
            ground(start + 1_145f, floorY, 245f)
            fallingObjects += GameFallingObject(
                x = start + 925f,
                startY = (floorY - 340f).coerceAtLeast(70f),
                targetY = floorY - 75f,
                size = 74f,
                triggerX = start + 805f,
                kind = FallingObjectKind.ROCK,
                delayMs = 170L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.JUMP_NEAR,
                triggerRadius = 160f
            )
            enemy(start + 1_245f, floorY, GameEnemyKind.JUMPER, speedBoost = -12f)
            x += 1_380f
        }

        private fun swingLog(i: Int) {
            val start = x
            ground(start, floorY, 900f)
            roof(start + 160f, floorY - 235f, 580f)
            crushers += GameCrusher(
                x = start + 330f,
                y = floorY - 205f,
                width = 72f,
                height = 155f,
                triggerX = start + 190f,
                axis = CrusherAxis.HORIZONTAL,
                travel = 150f,
                speed = 235f,
                delayMs = 300L,
                reverseAfterMs = 1_500L,
                style = CrusherStyle.LOG_PRESS
            )
            crushers += GameCrusher(
                x = start + 625f,
                y = floorY - 205f,
                width = 72f,
                height = 155f,
                triggerX = start + 480f,
                axis = CrusherAxis.HORIZONTAL,
                travel = -145f,
                speed = 245f,
                delayMs = 360L,
                reverseAfterMs = 1_520L,
                style = CrusherStyle.LOG_PRESS
            )
            floorSpikes(start + 500f, floorY, phase = 190L * i)
            enemy(start + 820f, floorY, GameEnemyKind.JUMPER)
            x += 900f
        }

        private fun plantConduit(i: Int) {
            val start = x
            val descend = (plan.number + i) % 2 == 0
            val target = if (descend) (floorY + 145f).coerceAtMost(625f) else (floorY - 155f).coerceAtLeast(310f)
            ground(start, floorY, 245f)
            val entryX = start + 130f
            conduits += GameConduit(
                x = entryX,
                y = floorY - 92f,
                width = 92f,
                height = 92f,
                targetX = start + 735f,
                targetY = target - 58f,
                direction = if (descend) ConduitDirection.DOWN else ConduitDirection.UP,
                autoEnter = false
            )
            plantTraps += GamePlantTrap(
                x = entryX + 14f,
                y = floorY - 148f,
                width = 64f,
                height = 98f,
                cycleMs = 2_650L + (i % 3) * 180L,
                activeMs = 1_100L,
                phaseMs = 170L * i,
                detectionRange = 220f,
                proximityAggressive = true
            )
            // No tiny helper platforms across this chasm: the plant/conduit is the route.
            ground(start + 700f, target, 250f)
            ledge(start + 1_065f, target - 75f, 125f)
            ground(start + 1_310f, target - 15f, 225f)
            fruit(start + 1_110f, target - 75f, FallingBehavior.EXPLODE, triggerMode = FallingTriggerMode.LAND_NEAR, triggerRadius = 150f)
            enemy(start + 1_390f, target - 15f, GameEnemyKind.JUMPER, speedBoost = -12f)
            floorY = target - 15f
            x += 1_525f
        }

        private fun landingTrap(i: Int) {
            val start = x
            val high = (floorY - 125f).coerceAtLeast(330f)
            ground(start, floorY, 190f)
            ledge(start + 250f, high, 145f)
            floorSpikes(start + 300f, high, width = 58f, phase = 160L * i)
            ledge(start + 455f, floorY - 55f, 150f, PlatformKind.FALLING, 960L)
            roof(start + 620f, floorY - 180f, 180f)
            ceilingSpikes(start + 670f, floorY - 180f, 72f, 44f, 280L * i)
            ground(start + 820f, floorY, 250f)
            fruit(start + 900f, floorY, FallingBehavior.EXPLODE, triggerMode = FallingTriggerMode.LAND_NEAR, triggerRadius = 175f)
            x += 1_050f
        }

        private fun surpriseCorridor(i: Int) {
            val start = x
            ground(start, floorY, 285f)
            // Wider headroom and staggered supports: still troll, but no single pixel-perfect route.
            roof(start + 120f, floorY - 235f, 220f)
            ledge(start + 395f, floorY - 88f, 155f)
            ledge(start + 650f, floorY - 138f, 165f)
            ledge(start + 895f, floorY - 72f, 150f)
            ground(start + 1_115f, floorY - 20f, 285f)

            if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) {
                normalTree(start + 165f, floorY, appleVisible = false, variant = i + plan.number)
            }
            floorSpikes(start + 495f, floorY - 88f, width = 40f, hidden = true, triggerMode = HazardTriggerMode.LAND_NEAR, height = 34f)
            floorSpikes(start + 745f, floorY - 138f, width = 40f, hidden = true, triggerMode = HazardTriggerMode.APPROACH, height = 34f)
            fallingObjects += GameFallingObject(
                x = start + 930f,
                startY = (floorY - 360f).coerceAtLeast(60f),
                targetY = floorY - 72f,
                size = 72f,
                triggerX = start + 795f,
                kind = FallingObjectKind.ROCK,
                delayMs = 145L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.APPROACH,
                triggerRadius = 205f
            )
            chasingHoles += GameChasingHole(start + 1_170f, floorY - 48f, 88f, 48f, start + 1_085f, 108f, 72f, 1f, start + 1_145f, start + 1_315f)
            floorY -= 20f
            x += 1_390f
        }

        private fun giantSpikeRoom(i: Int) {
            val start = x
            ground(start, floorY, 1_040f)
            ledge(start + 245f, floorY - 120f, 160f)
            ledge(start + 500f, floorY - 185f, 160f)
            roof(start + 690f, floorY - 245f, 185f)
            // A large surprise spike like the reference rhythm, but with a real upper escape route.
            floorSpikes(start + 405f, floorY, width = 76f, hidden = true, triggerMode = HazardTriggerMode.APPROACH, height = 112f)
            floorSpikes(start + 555f, floorY - 185f, width = 58f, hidden = true, triggerMode = HazardTriggerMode.LAND_NEAR)
            ceilingSpikes(start + 745f, floorY - 245f, 68f, 54f, 150L * i)
            crushers += GameCrusher(
                x = start + 875f,
                y = floorY - 205f,
                width = 88f,
                height = 150f,
                triggerX = start + 755f,
                axis = CrusherAxis.VERTICAL,
                travel = 145f,
                speed = 270f,
                delayMs = 330L,
                reverseAfterMs = 1_450L,
                style = if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) CrusherStyle.LOG_PRESS else CrusherStyle.FALLING_WALL,
                despawnAfterMs = 2_900L
            )
            x += 1_040f
        }

        private fun deceptiveGrove(i: Int) {
            val start = x
            val baseY = floorY
            val upperY = (baseY - 54f).coerceAtLeast(330f)
            val lowerY = (baseY + 52f).coerceAtMost(645f)
            val exitY = (baseY - 28f).coerceAtLeast(330f)

            // Real chasms between the tree islands. Missing a measured jump means falling to the void.
            ground(start, baseY, 205f)
            ground(start + 365f, upperY, 185f)
            ground(start + 730f, lowerY, 175f)
            ground(start + 1_080f, exitY, 225f)

            val treeSlots = listOf(
                Triple(start + 120f, baseY, 0),
                Triple(start + 455f, upperY, 1),
                Triple(start + 810f, lowerY, 2),
                Triple(start + 1_175f, exitY, 3)
            )
            val trapSlot = (plan.number * 3 + i) % treeSlots.size
            treeSlots.forEachIndexed { slot, data ->
                val (tx, gy, variant) = data
                if (slot == trapSlot) {
                    val behavior = when ((plan.number + i) % 4) {
                        0 -> FallingBehavior.EXPLODE
                        1 -> FallingBehavior.ROLL
                        2 -> FallingBehavior.CHASE
                        else -> FallingBehavior.DROP
                    }
                    val trigger = when ((plan.number + i) % 5) {
                        0 -> FallingTriggerMode.PASS_UNDER
                        1 -> FallingTriggerMode.JUMP_NEAR
                        2 -> FallingTriggerMode.BACKTRACK
                        3 -> FallingTriggerMode.LAND_NEAR
                        else -> FallingTriggerMode.APPROACH
                    }
                    fruit(tx, gy, behavior, treeFalls = (i + plan.number) % 3 == 0, triggerMode = trigger, triggerRadius = 155f)
                } else {
                    normalTree(tx + 22f, gy, appleVisible = (slot + i + plan.number) % 4 == 0, variant = plan.number + variant * 3)
                }
            }

            // A second, unrelated surprise makes the tree pattern impossible to read from decoration alone.
            if ((i + plan.number) % 2 == 0) {
                fallingObjects += GameFallingObject(
                    x = start + 925f,
                    startY = (lowerY - 260f).coerceAtLeast(95f),
                    targetY = lowerY,
                    size = 78f,
                    triggerX = start + 790f,
                    kind = FallingObjectKind.ROCK,
                    delayMs = 185L,
                    behavior = FallingBehavior.DROP,
                    triggerMode = FallingTriggerMode.LAND_NEAR,
                    triggerRadius = 165f
                )
            } else {
                chasingHoles += GameChasingHole(
                    startX = start + 755f,
                    y = lowerY - 28f,
                    width = 94f,
                    height = 48f,
                    triggerX = start + 690f,
                    speed = 122f,
                    maxTravel = 92f,
                    direction = 1f,
                    surfaceStartX = start + 742f,
                    surfaceEndX = start + 886f
                )
            }
            enemy(start + 1_190f, exitY, GameEnemyKind.JUMPER, speedBoost = -8f)
            floorY = exitY
            x += 1_300f
        }

        private fun fallingWallBridge(i: Int) {
            val start = x
            val lower = (floorY + 72f).coerceAtMost(645f)
            ground(start, floorY, 185f)
            ledge(start + 365f, lower, 125f)

            // The falling rock is not decoration: surviving it creates the middle step of the bridge.
            fallingObjects += GameFallingObject(
                x = start + 620f,
                startY = (floorY - 325f).coerceAtLeast(75f),
                targetY = lower + 15f,
                size = 96f,
                triggerX = start + 470f,
                kind = FallingObjectKind.ROCK,
                delayMs = 190L,
                behavior = FallingBehavior.DROP,
                becomesPlatform = true,
                triggerMode = FallingTriggerMode.APPROACH,
                triggerRadius = 185f
            )
            ledge(start + 825f, floorY - 28f, 120f)
            ground(start + 1_095f, floorY, 255f)
            crushers += GameCrusher(
                x = start + 970f,
                y = floorY - 230f,
                width = 118f,
                height = 170f,
                triggerX = start + 845f,
                axis = CrusherAxis.VERTICAL,
                travel = 150f,
                speed = 258f,
                delayMs = 380L,
                reverseAfterMs = 1_650L,
                style = CrusherStyle.FALLING_WALL,
                despawnAfterMs = 2_850L
            )
            enemy(start + 1_220f, floorY, GameEnemyKind.WALKER, speedBoost = -10f)
            x += 1_340f
        }

        private fun switchCountertrap(i: Int) {
            val start = x
            ground(start, floorY, 270f)
            ledge(start + 435f, floorY - 105f, 135f)
            ground(start + 985f, floorY - 20f, 250f)

            switches += GameSwitch(start + 150f, floorY - 54f, start + 900f)
            val switchIndex = switches.lastIndex
            ledge(start + 700f, floorY - 155f, 125f, PlatformKind.REVEALING, 720L, PlatformRevealMode.SWITCH, 175f, switchIndex)
            requiredMechanisms++
            barriers += GameBarrier(start + 900f, floorY - 300f, 54f, 300f, switchIndex)
            // The useful switch also triggers a hidden rock above the intended landing.
            fallingObjects += GameFallingObject(
                x = start + 735f,
                startY = (floorY - 335f).coerceAtLeast(70f),
                targetY = floorY - 155f,
                size = 80f,
                triggerX = start + 600f,
                kind = FallingObjectKind.ROCK,
                delayMs = 175L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.SWITCH,
                triggerSwitchIndex = switchIndex
            )
            crushers += GameCrusher(start + 845f, floorY - 220f, 80f, 145f, start + 770f, CrusherAxis.VERTICAL, 128f, 245f, 390L, 1_600L, CrusherStyle.STONE_COLUMN, 2_800L)
            enemy(start + 1_095f, floorY - 20f, GameEnemyKind.JUMPER, speedBoost = -10f)
            floorY -= 20f
            x += 1_225f
        }

        private fun falseExitLoop(i: Int) {
            val start = x
            ground(start, floorY, 225f)
            // Tempting side entrance loops back. The real route crosses the chasm above.
            conduits += GameConduit(
                x = start + 105f,
                y = floorY - 92f,
                targetX = start + 35f,
                targetY = floorY - 58f,
                direction = ConduitDirection.SIDE,
                autoEnter = false
            )
            ledge(start + 400f, floorY - 110f, 125f)
            ledge(start + 675f, floorY - 185f, 125f)
            movingPlatforms += GameMovingPlatform(start + 930f, floorY - 115f, 125f, 70f, true, 3.1f)
            ground(start + 1_170f, floorY - 25f, 240f)
            rock(start + 500f, floorY - 110f, becomesPlatform = false)
            if ((plan.number + i) % 2 == 0) {
                surpriseWallSpikesFromRight(start + 1_150f, floorY - 155f, 70f, HazardTriggerMode.BACKTRACK)
            } else {
                crushers += GameCrusher(start + 1_040f, floorY - 225f, 82f, 145f, start + 915f, CrusherAxis.VERTICAL, 125f, 245f, 390L, 1_600L, CrusherStyle.FALLING_WALL, 2_700L)
            }
            enemy(start + 1_275f, floorY - 25f, GameEnemyKind.FLYER, speedBoost = -10f)
            floorY -= 25f
            x += 1_400f
        }

        private fun verticalConduit(i: Int) {
            val start = x
            val down = (plan.number + i) % 2 == 0
            val target = if (down) (floorY + 150f).coerceAtMost(640f) else (floorY - 170f).coerceAtLeast(305f)
            ground(start, floorY, 255f)
            val entryX = start + 135f
            conduits += GameConduit(
                x = entryX,
                y = floorY - 92f,
                width = 92f,
                height = 92f,
                targetX = start + 720f,
                targetY = target - 58f,
                direction = if (down) ConduitDirection.DOWN else ConduitDirection.UP,
                endsLevel = false,
                arrivalOnly = false,
                autoEnter = false
            )
            if ((plan.number + i) % 3 != 1) {
                plantTraps += GamePlantTrap(entryX + 14f, floorY - 148f, 64f, 98f, 2_750L, 1_020L, i * 140L, 205f, (plan.number + i) % 4 == 0)
            }
            // The gap is intentionally too wide to ignore the conduit.
            ground(start + 680f, target, 245f)
            ledge(start + 1_035f, target - 82f, 125f)
            ground(start + 1_285f, target - 18f, 230f)
            fallingObjects += GameFallingObject(
                x = start + 1_075f,
                startY = (target - 325f).coerceAtLeast(75f),
                targetY = target - 82f,
                size = 74f,
                triggerX = start + 965f,
                kind = FallingObjectKind.ROCK,
                delayMs = 175L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.JUMP_NEAR,
                triggerRadius = 170f
            )
            enemy(start + 1_370f, target - 18f, GameEnemyKind.JUMPER, speedBoost = -10f)
            floorY = target - 18f
            x += 1_500f
        }

        private fun rollingEscape(i: Int) {
            val start = x
            val exitY = (floorY - 45f).coerceAtLeast(325f)
            ground(start, floorY, 195f)
            ledge(start + 355f, floorY - 35f, 125f)
            ledge(start + 625f, floorY - 105f, 115f, PlatformKind.PROXIMITY_DISAPPEARING, 1_020L)
            ledge(start + 875f, floorY - 42f, 120f)
            ground(start + 1_145f, exitY, 250f)

            chasingRock(start + 135f, floorY, direction = 1f)
            crushers += GameCrusher(
                x = start + 1_020f,
                y = floorY - 220f,
                width = 86f,
                height = 155f,
                triggerX = start + 895f,
                axis = CrusherAxis.VERTICAL,
                travel = 135f,
                speed = 252f,
                delayMs = 340L,
                reverseAfterMs = 1_560L,
                style = CrusherStyle.FALLING_WALL,
                despawnAfterMs = 2_700L
            )
            enemy(start + 1_245f, exitY, GameEnemyKind.WALKER, speedBoost = -12f)
            floorY = exitY
            x += 1_390f
        }

        private fun trickAscent(i: Int) {
            val start = x
            val upper = (floorY - 175f).coerceAtLeast(310f)

            // Keep the lift timing as a troll mechanic, but never make it the only route.
            // Earlier versions could strand GEO if a vertical platform moved out of the jump window.
            ground(start, floorY, 250f)
            ledge(start + 305f, floorY - 58f, 90f)
            movingPlatforms += GameMovingPlatform(start + 435f, floorY - 95f, 130f, 70f, true, 3.35f)
            ledge(
                start + 585f,
                floorY - 118f,
                135f,
                if ((plan.number + i) % 3 == 0) PlatformKind.BOUNCE else PlatformKind.SOLID
            )
            movingPlatforms += GameMovingPlatform(start + 760f, upper + 70f, 130f, 62f, true, 3.2f)
            // Narrow permanent foothold: difficult, but it guarantees a reproducible fallback.
            ledge(start + 905f, upper + 52f, 90f)
            crushers += GameCrusher(
                start + 655f,
                upper - 128f,
                72f,
                112f,
                start + 545f,
                CrusherAxis.VERTICAL,
                92f,
                205f,
                430L,
                1_820L,
                CrusherStyle.LOG_PRESS,
                0L
            )
            ground(start + 1_040f, upper, 300f)
            enemy(start + 1_210f, upper, GameEnemyKind.JUMPER)
            floorY = upper
            x += 1_325f
        }

        private fun breakawayFloor(i: Int) {
            val start = x
            val midY = (floorY - 18f).coerceAtLeast(330f)
            ground(start, floorY, 165f)
            ledge(start + 325f, floorY - 10f, 125f, PlatformKind.PROXIMITY_DISAPPEARING, 960L)
            ledge(start + 630f, floorY - 66f, 115f, PlatformKind.FALLING, 880L)
            ledge(start + 865f, midY - 80f, 120f)
            ground(start + 1_130f, midY, 245f)

            // Surprise from above is invisible until the jump has already committed.
            fallingObjects += GameFallingObject(
                x = start + 705f,
                startY = (floorY - 330f).coerceAtLeast(85f),
                targetY = floorY - 66f,
                size = 76f,
                triggerX = start + 540f,
                kind = FallingObjectKind.ROCK,
                delayMs = 175L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.JUMP_NEAR,
                triggerRadius = 180f
            )
            if ((plan.number + i) % 3 == 0) {
                floorSpikes(start + 903f, midY - 80f, 46f, hidden = true, triggerMode = HazardTriggerMode.LAND_NEAR, height = 38f)
            }
            floorY = midY
            x += 1_360f
        }

        private fun silentRoom(i: Int) {
            val start = x
            val upper = (floorY - 88f).coerceAtLeast(330f)
            ground(start, floorY, 220f)
            ground(start + 395f, floorY, 205f)
            ledge(start + 770f, upper, 130f)
            ground(start + 1_080f, floorY - 25f, 235f)

            if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) {
                normalTree(start + 115f, floorY, appleVisible = false, variant = 1 + i)
                normalTree(start + 495f, floorY, appleVisible = (plan.number + i) % 4 == 0, variant = 3 + i)
            }

            // The room appears calm. The trap is armed only after the player commits to the third island.
            fallingObjects += GameFallingObject(
                x = start + 820f,
                startY = (upper - 285f).coerceAtLeast(80f),
                targetY = upper,
                size = 82f,
                triggerX = start + 700f,
                kind = FallingObjectKind.ROCK,
                delayMs = 185L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.LAND_NEAR,
                triggerRadius = 155f
            )
            chasingHoles += GameChasingHole(
                startX = start + 455f,
                y = floorY - 28f,
                width = 96f,
                height = 48f,
                triggerX = start + 395f,
                speed = 118f,
                maxTravel = 88f,
                direction = 1f,
                surfaceStartX = start + 410f,
                surfaceEndX = start + 575f
            )
            enemy(start + 1_170f, floorY - 25f, GameEnemyKind.WALKER, speedBoost = -12f)
            floorY -= 25f
            x += 1_310f
        }

        private fun enemyRebound(i: Int) {
            val start = x
            val high = (floorY - 155f).coerceAtLeast(320f)
            ground(start, floorY, 190f)
            // The first gap is deliberately large: stomping the enemy gives the safest route upward.
            enemy(start + 118f, floorY, GameEnemyKind.JUMPER, speedBoost = -14f)
            ledge(start + 390f, high + 55f, 125f)
            ledge(start + 650f, high, 130f)

            val opensRoute = (plan.number + i) % 3 == 0
            val defeatSwitchIndex = if (opensRoute) {
                switches += GameSwitch(start + 720f, -420f, start + 965f)
                requiredMechanisms++
                barriers += GameBarrier(start + 965f, high - 235f, 54f, 255f, switches.lastIndex)
                switches.lastIndex
            } else null
            enemy(start + 690f, high, if (plan.number >= 10) GameEnemyKind.SHOOTER else GameEnemyKind.WALKER, onDefeatSwitchIndex = defeatSwitchIndex)
            movingPlatforms += GameMovingPlatform(start + 865f, high + 75f, 125f, 55f, true, 3.1f)
            ground(start + 1_105f, high + 20f, 250f)

            fallingObjects += GameFallingObject(
                x = start + 1_155f,
                startY = (high - 285f).coerceAtLeast(85f),
                targetY = high + 20f,
                size = 76f,
                triggerX = start + 1_015f,
                kind = FallingObjectKind.ROCK,
                delayMs = 180L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.LAND_NEAR,
                triggerRadius = 165f
            )
            floorY = high + 20f
            x += 1_345f
        }

        private fun invisibleBlockTrap(i: Int) {
            val start = x
            val landingY = (floorY - 42f).coerceAtLeast(335f)
            ground(start, floorY, 225f)
            // Cat-Mario style rule change: this block is genuinely absent until GEO commits to the jump.
            ledge(
                start + 300f,
                floorY - 150f,
                112f,
                PlatformKind.REVEALING,
                720L,
                PlatformRevealMode.JUMP_NEAR,
                185f
            )
            ledge(start + 505f, floorY - 72f, 128f)
            ground(start + 765f, landingY, 250f)
            fallingObjects += GameFallingObject(
                x = start + 820f,
                startY = (landingY - 315f).coerceAtLeast(72f),
                targetY = landingY,
                size = 76f,
                triggerX = start + 690f,
                kind = FallingObjectKind.ROCK,
                delayMs = 205L,
                behavior = FallingBehavior.DROP,
                triggerMode = FallingTriggerMode.LAND_NEAR,
                triggerRadius = 165f
            )
            if ((plan.number + i) % 2 == 0) {
                ledge(start + 575f, floorY - 205f, 92f, PlatformKind.REVEALING, 720L, PlatformRevealMode.BACKTRACK, 160f)
            }
            floorY = landingY
            x += 1_005f
        }

        private fun dormantAmbush(i: Int) {
            val start = x
            val upper = (floorY - 88f).coerceAtLeast(330f)
            ground(start, floorY, 260f)
            ledge(start + 390f, upper, 150f)
            ledge(start + 660f, floorY - 20f, 132f)
            ground(start + 970f, floorY, 260f)
            // The first enemy is behind GEO and does not exist visually until the trigger is crossed.
            enemy(
                start + 105f,
                floorY,
                if ((plan.number + i) % 3 == 0) GameEnemyKind.JUMPER else GameEnemyKind.WALKER,
                speedBoost = 18f,
                activationTriggerX = start + 515f,
                hiddenUntilActivated = true
            )
            enemy(
                start + 1_080f,
                floorY,
                if (plan.number >= 8) GameEnemyKind.SHOOTER else GameEnemyKind.JUMPER,
                speedBoost = -8f,
                activationTriggerX = start + 800f,
                hiddenUntilActivated = true
            )
            if ((plan.number + i) % 2 == 1) {
                chasingHoles += GameChasingHole(start + 700f, floorY - 48f, 88f, 48f, start + 625f, 112f, 78f, 1f, start + 675f, start + 805f)
            }
            x += 1_225f
        }

        private fun projectileAlley(i: Int) {
            val start = x
            val mid = (floorY - 60f).coerceAtLeast(330f)
            ground(start, floorY, 240f)
            ledge(start + 390f, mid, 145f)
            ledge(start + 665f, floorY - 110f, 130f)
            ground(start + 985f, floorY - 25f, 265f)
            launchers += GameLauncher(
                x = start + 810f,
                y = floorY - 145f,
                direction = LauncherDirection.LEFT,
                triggerX = start + 470f,
                triggerRadius = 390f,
                delayMs = 220L + (i % 2) * 60L,
                projectileSpeed = 480f + plan.number * 4f,
                hiddenUntilTriggered = true
            )
            if (plan.number >= 6 || i % 2 == 0) {
                launchers += GameLauncher(
                    x = start + 360f,
                    y = floorY - 205f,
                    direction = LauncherDirection.RIGHT,
                    triggerX = start + 690f,
                    triggerRadius = 350f,
                    delayMs = 330L,
                    projectileSpeed = 430f + plan.number * 3f,
                    hiddenUntilTriggered = true
                )
            }
            enemy(start + 1_105f, floorY - 25f, GameEnemyKind.WALKER, speedBoost = -12f)
            floorY -= 25f
            x += 1_245f
        }

        private fun baitCrates(i: Int) {
            val start = x
            ground(start, floorY, 1_160f)
            val needsGate = (plan.number + i) % 3 == 0
            val switchIndex = if (needsGate) {
                switches += GameSwitch(start + 80f, -420f, start + 930f)
                requiredMechanisms++
                barriers += GameBarrier(start + 930f, floorY - 285f, 52f, 285f, switches.lastIndex)
                switches.lastIndex
            } else null
            // They look identical. Memorising the art is useless; the payload is what matters.
            val payloads = if (needsGate) {
                listOf(CratePayload.EXPLOSION, CratePayload.SWITCH, CratePayload.SHIELD)
            } else if ((plan.number + i) % 2 == 0) {
                listOf(CratePayload.EMPTY, CratePayload.EXPLOSION, CratePayload.POWER)
            } else {
                listOf(CratePayload.SHIELD, CratePayload.EXPLOSION, CratePayload.LIFE)
            }
            crates += GameCrate(start + 270f, floorY - 54f, payloads[0], switchIndex)
            crates += GameCrate(start + 500f, floorY - 54f, payloads[1], switchIndex)
            crates += GameCrate(start + 730f, floorY - 54f, payloads[2], switchIndex)
            if ((plan.number + i) % 2 == 0) {
                fallingObjects += GameFallingObject(
                    start + 820f,
                    (floorY - 320f).coerceAtLeast(70f),
                    floorY,
                    76f,
                    start + 680f,
                    FallingObjectKind.ROCK,
                    210L,
                    FallingBehavior.DROP,
                    triggerMode = FallingTriggerMode.BACKTRACK,
                    triggerRadius = 180f
                )
            }
            enemy(start + 1_050f, floorY, GameEnemyKind.JUMPER, speedBoost = -10f)
            x += 1_150f
        }

        private fun chainBlockFall(i: Int) {
            val start = x
            val lower = (floorY + 45f).coerceAtMost(640f)
            ground(start, floorY, 245f)
            val firstY = floorY - 42f
            val secondY = lower - 92f
            val thirdY = lower - 28f
            ledge(start + 350f, firstY, 165f)
            ledge(start + 625f, secondY, 165f)
            ledge(start + 875f, thirdY, 160f)
            ground(start + 1_105f, lower, 275f)

            // The three blocks are visible only after the corridor trigger, then fall in a learned
            // sequence. Each one lands on the edge of a real support and leaves >70 px clear, so the
            // reaction is dodge/reposition rather than "stand still until the route reopens".
            val blockSpecs = listOf(
                Triple(start + 360f, firstY, 205L),
                Triple(start + 705f, secondY, 350L + (i % 2) * 25L),
                Triple(start + 885f, thirdY, 500L + (i % 2) * 30L)
            )
            blockSpecs.forEach { (cx, target, delay) ->
                fallingObjects += GameFallingObject(
                    x = cx,
                    startY = (target - 300f).coerceAtLeast(70f),
                    targetY = target,
                    size = 68f,
                    triggerX = start + 285f,
                    kind = FallingObjectKind.CRATE,
                    delayMs = delay,
                    behavior = FallingBehavior.DROP,
                    triggerMode = FallingTriggerMode.APPROACH,
                    triggerRadius = 610f
                )
            }
            if (plan.number >= 10) {
                launchers += GameLauncher(start + 1_010f, lower - 165f, LauncherDirection.LEFT, start + 790f, 300f, 320L, 450f + plan.number * 2f, true)
            }
            floorY = lower
            x += 1_365f
        }

        fun build(): AdventureLevel {
            // Every level begins differently and the first threat is environmental, not a row of visible spikes.
            ground(0f, floorY, 300f)
            if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) {
                normalTree(120f, floorY, appleVisible = plan.number % 4 == 0, variant = plan.number)
            }
            when (plan.number % 5) {
                0 -> fallingObjects += GameFallingObject(235f, (floorY - 320f).coerceAtLeast(70f), floorY, 76f, 125f, FallingObjectKind.ROCK, 175L, FallingBehavior.DROP, triggerMode = FallingTriggerMode.PASS_UNDER, triggerRadius = 150f)
                1 -> if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) {
                    fruit(235f, floorY, FallingBehavior.DROP, treeFalls = false, triggerMode = FallingTriggerMode.PASS_UNDER, triggerRadius = 145f)
                } else chasingRock(235f, floorY, direction = 1f)
                2 -> enemy(225f, floorY, if (plan.number >= 10) GameEnemyKind.SHOOTER else GameEnemyKind.JUMPER, speedBoost = -12f)
                3 -> chasingHoles += GameChasingHole(185f, floorY - 28f, 94f, 48f, 125f, 118f, 78f, 1f, 160f, 285f)
                else -> crushers += GameCrusher(205f, floorY - 215f, 82f, 150f, 105f, CrusherAxis.VERTICAL, 132f, 245f, 350L, 1_650L, if (plan.biome == AdventureBiome.DESERT_DAWN) CrusherStyle.RUIN_BLOCK else CrusherStyle.FALLING_WALL, 2_650L)
            }
            x = 300f
            plan.beats.forEachIndexed { index, beat ->
                val roomStart = x
                addBeat(beat, index)
                val roomEnd = x
                addTrollEcho(roomStart, roomEnd, index)
                if (index == 2 || index == 5 || (index == 8 && plan.beats.size >= 11)) {
                    checkpoint(x - 135f, floorY)
                }
            }

            if (plan.requiresKey && keys.isEmpty()) {
                keyDetour(plan.beats.size + 1)
            }

            ground(x, floorY, 390f)
            when (plan.number % 4) {
                0 -> rock(x + 150f, floorY, becomesPlatform = false)
                1 -> if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) {
                    fruit(x + 150f, floorY, FallingBehavior.EXPLODE, triggerMode = FallingTriggerMode.LAND_NEAR, triggerRadius = 160f)
                } else chasingRock(x + 150f, floorY, direction = -1f)
                2 -> enemy(x + 165f, floorY, if (plan.number >= 12) GameEnemyKind.GUARDIAN else GameEnemyKind.JUMPER)
                else -> crushers += GameCrusher(x + 145f, floorY - 190f, 82f, 140f, x + 30f, CrusherAxis.VERTICAL, 125f, 245f, 420L, 1_650L, if (plan.biome == AdventureBiome.DESERT_DAWN) CrusherStyle.RUIN_BLOCK else CrusherStyle.FALLING_WALL, 2_850L)
            }
            val width = x + 500f
            val goalX = width - 175f
            val conduitExitKinds = setOf(LevelExitKind.DESCENT, LevelExitKind.CAVE, LevelExitKind.TUNNEL, LevelExitKind.LIFT)
            if (plan.entry in conduitExitKinds) {
                conduits += GameConduit(88f, plan.startY - 92f, targetX = 88f, targetY = plan.startY - 58f, direction = if (plan.entry == LevelExitKind.LIFT) ConduitDirection.UP else ConduitDirection.DOWN, arrivalOnly = true)
            }
            if (plan.exit in conduitExitKinds) {
                conduits += GameConduit(
                    x = goalX - 54f,
                    y = floorY - 92f,
                    targetX = goalX - 30f,
                    targetY = if (plan.exit == LevelExitKind.LIFT) floorY - 205f else floorY + 105f,
                    direction = if (plan.exit == LevelExitKind.LIFT) ConduitDirection.UP else ConduitDirection.DOWN,
                    endsLevel = true,
                    autoEnter = true
                )
                if (plan.number % 3 == 0) {
                    plantTraps += GamePlantTrap(goalX - 40f, floorY - 148f, phaseMs = plan.number * 170L, proximityAggressive = true)
                }
            }
            // Normalize checkpoints after all terrain is generated. This prevents a checkpoint from
            // ending up buried inside an overlapping floor/ledge created by a later room.
            val normalizedCheckpoints = checkpoints.map { cp ->
                if (cp.kind == CheckpointKind.DECOY) cp else {
                    val expectedSurface = cp.y + 82f
                    val support = platforms
                        .filter { cp.x in (it.x + 18f)..(it.x + it.width - 18f) && it.kind == PlatformKind.SOLID }
                        .minByOrNull { kotlin.math.abs(it.y - expectedSurface) }
                    if (support != null) cp.copy(y = support.y - 82f) else cp
                }
            }
            val realCheckpoints = normalizedCheckpoints.filter { it.kind != CheckpointKind.DECOY }
            val safetyAnchors = buildList {
                add(80f)
                add(goalX)
                realCheckpoints.forEach { add(it.x) }
            }
            fun closeToSafety(centerX: Float, radius: Float) = safetyAnchors.any { kotlin.math.abs(it - centerX) < radius }

            // Fill unusually long quiet stretches with a hidden off-camera shot. A checkpoint is
            // still treated as a deliberate breathing point, but normal rooms must not allow GEO to
            // walk for several seconds without another learned surprise.
            fun currentTrollAnchors(): List<Float> = buildList {
                add(80f)
                add(goalX)
                normalizedCheckpoints.filter { it.kind != CheckpointKind.DECOY }.forEach { add(it.x) }
                hazards.forEach { add(it.triggerX) }
                enemies.mapNotNullTo(this) { it.activationTriggerX }
                fallingObjects.forEach { add(it.triggerX) }
                chasingHoles.forEach { add(it.triggerX) }
                crushers.forEach { add(it.triggerX) }
                launchers.forEach { add(it.triggerX) }
                plantTraps.forEach { add(it.x - minOf(it.detectionRange, 190f)) }
                platforms.filter { it.kind in setOf(PlatformKind.FALLING, PlatformKind.PROXIMITY_DISAPPEARING, PlatformKind.REVEALING) }
                    .forEach { add(it.triggerX) }
            }.filter { it in 0f..goalX }.sorted()

            repeat(6) { pass ->
                val anchors = currentTrollAnchors()
                val gap = anchors.zipWithNext().maxByOrNull { (a, b) -> b - a } ?: return@repeat
                val gapSize = gap.second - gap.first
                if (gapSize <= 1_050f) return@repeat
                var trigger = gap.first + gapSize * 0.54f
                val nearestSafety = safetyAnchors.minByOrNull { kotlin.math.abs(it - trigger) }
                if (nearestSafety != null && kotlin.math.abs(nearestSafety - trigger) < 205f) {
                    trigger = if (trigger <= nearestSafety) nearestSafety - 215f else nearestSafety + 215f
                }
                trigger = trigger.coerceIn(gap.first + 175f, gap.second - 175f)
                if (closeToSafety(trigger, 165f)) return@repeat

                val support = platforms
                    .filter { it.kind == PlatformKind.SOLID && it.role in setOf(PlatformRole.GROUND, PlatformRole.LEDGE) }
                    .minByOrNull { platform -> kotlin.math.abs((platform.x + platform.width / 2f) - trigger) }
                    ?: return@repeat
                val fromRight = (plan.number + pass + launchers.size) % 2 == 0
                var launcherX = if (fromRight) trigger + 250f else trigger - 250f
                launcherX = launcherX.coerceIn(gap.first + 70f, gap.second - 70f)
                if (closeToSafety(launcherX, 165f)) launcherX = trigger
                launchers += GameLauncher(
                    x = launcherX,
                    y = (support.y - 125f).coerceAtLeast(105f),
                    direction = if (fromRight) LauncherDirection.LEFT else LauncherDirection.RIGHT,
                    triggerX = trigger,
                    triggerRadius = 390f,
                    delayMs = 275L + (pass * 25L),
                    projectileSpeed = 455f + plan.number * 4.0f,
                    hiddenUntilTriggered = true
                )
            }

            fun supported(h: GameHazard): Boolean {
                val left = h.x
                val right = h.x + h.width
                val top = h.y
                val bottom = h.y + h.height
                return when (h.orientation) {
                    HazardOrientation.UP -> platforms.any { p ->
                        left >= p.x - 8f && right <= p.x + p.width + 8f && kotlin.math.abs(p.y - bottom) <= 9f
                    }
                    HazardOrientation.DOWN -> platforms.any { p ->
                        left >= p.x - 8f && right <= p.x + p.width + 8f && kotlin.math.abs((p.y + p.height) - top) <= 9f
                    }
                    HazardOrientation.RIGHT -> platforms.any { p ->
                        kotlin.math.abs((p.x + p.width) - h.x) <= 14f && top < p.y + p.height && bottom > p.y
                    }
                    HazardOrientation.LEFT -> platforms.any { p ->
                        kotlin.math.abs(p.x - (h.x + h.width)) <= 14f && top < p.y + p.height && bottom > p.y
                    }
                }
            }
            fun buriedInsideTerrain(h: GameHazard): Boolean {
                val cx = h.x + h.width / 2f
                val cy = h.y + h.height / 2f
                return platforms.any { p ->
                    cx > p.x + 10f && cx < p.x + p.width - 10f &&
                        cy > p.y + 12f && cy < p.y + p.height - 12f
                }
            }

            val safetyFiltered = hazards
                .filterNot { closeToSafety(it.x + it.width / 2f, 175f) }
                .map { hazard ->
                    when (hazard.kind) {
                        HazardKind.SPIKES, HazardKind.CEILING_SPIKES, HazardKind.FIRE -> hazard.copy(
                            kind = HazardKind.HIDDEN_SPIKES,
                            cycleMs = 0L,
                            camouflaged = true,
                            retractable = false,
                            triggerMode = if (hazard.triggerMode == HazardTriggerMode.BACKTRACK) HazardTriggerMode.BACKTRACK else HazardTriggerMode.APPROACH
                        )
                        else -> hazard
                    }
                }
            val supportedHazards = safetyFiltered.filter { supported(it) && !buriedInsideTerrain(it) }
            // Prevent a floor/ceiling spike pair from leaving a corridor narrower than GEO.
            val safeHazards = mutableListOf<GameHazard>()
            supportedHazards.forEach { candidate ->
                val impossiblePair = safeHazards.any { kept ->
                    val xOverlap = candidate.x < kept.x + kept.width && candidate.x + candidate.width > kept.x
                    val opposite = (candidate.orientation == HazardOrientation.UP && kept.orientation == HazardOrientation.DOWN) ||
                        (candidate.orientation == HazardOrientation.DOWN && kept.orientation == HazardOrientation.UP)
                    if (!xOverlap || !opposite) false else {
                        val floorSpike = if (candidate.orientation == HazardOrientation.UP) candidate else kept
                        val ceilingSpike = if (candidate.orientation == HazardOrientation.DOWN) candidate else kept
                        val gap = floorSpike.y - (ceilingSpike.y + ceilingSpike.height)
                        gap < 86f
                    }
                }
                if (!impossiblePair) safeHazards += candidate
            }
            val safeFalling = fallingObjects.filterNot { closeToSafety(it.x + it.size / 2f, 165f) }.toMutableList()
            val sanitizedFalling = safeFalling.map { falling ->
                if (falling.triggerMode == FallingTriggerMode.SWITCH) falling else when (falling.kind) {
                    FallingObjectKind.ROCK, FallingObjectKind.SPIKE_BALL -> falling.copy(delayMs = falling.delayMs.coerceIn(260L, 320L))
                    FallingObjectKind.CRATE -> falling.copy(delayMs = falling.delayMs.coerceAtLeast(190L))
                    FallingObjectKind.FRUIT -> falling.copy(delayMs = falling.delayMs.coerceAtLeast(145L))
                }
            }
            val safeCrushers = crushers.filterNot { closeToSafety(it.x + it.width / 2f, 185f) }.toMutableList()
            val authoredSafeEnemies = enemies.filterNot { closeToSafety(it.x, 110f) }.map { enemy ->
                if (enemy.hiddenUntilActivated && enemy.activationTriggerX != null) enemy else {
                    enemy.copy(
                        activationTriggerX = (enemy.x - minOf(285f, enemy.detectionRange * 0.62f)).coerceAtLeast(95f),
                        hiddenUntilActivated = true
                    )
                }
            }
            // Two enemies occupying almost the same head space made a correct stomp on one enemy
            // immediately register as a side hit against its neighbour. Keep dense encounters, but
            // guarantee enough horizontal separation for a clean 44 px GEO landing/rebound.
            val safeEnemies = mutableListOf<GameEnemy>()
            authoredSafeEnemies.forEach { enemy ->
                val conflict = safeEnemies.lastOrNull { kept ->
                    kotlin.math.abs(kept.y - enemy.y) < 62f && kotlin.math.abs(kept.x - enemy.x) < 72f
                }
                if (conflict == null) {
                    safeEnemies += enemy
                } else {
                    val footY = enemy.y + 58f
                    val support = platforms
                        .filter { p ->
                            p.kind == PlatformKind.SOLID &&
                                p.role in setOf(PlatformRole.GROUND, PlatformRole.LEDGE) &&
                                enemy.x + 25f in p.x..(p.x + p.width) &&
                                kotlin.math.abs(p.y - footY) <= 18f
                        }
                        .minByOrNull { kotlin.math.abs((it.x + it.width / 2f) - (enemy.x + 25f)) }
                    val candidates = if (support != null) {
                        listOf(conflict.x + 82f, conflict.x - 82f, enemy.x + 86f, enemy.x - 86f)
                            .map { it.coerceIn(support.x + 6f, support.x + support.width - 56f) }
                            .distinct()
                            .filter { x -> safeEnemies.none { kept -> kotlin.math.abs(kept.y - enemy.y) < 62f && kotlin.math.abs(kept.x - x) < 72f } }
                    } else emptyList()
                    val shiftedX = candidates.minByOrNull { kotlin.math.abs(it - enemy.x) }
                    if (shiftedX != null) {
                        safeEnemies += enemy.copy(
                            x = shiftedX,
                            activationTriggerX = (shiftedX - minOf(285f, enemy.detectionRange * 0.62f)).coerceAtLeast(95f)
                        )
                    }
                    // If the authored support is too short for two enemies, keep only the first.
                    // The final hidden-launcher density pass below fills any resulting quiet gap.
                }
            }
            val safeHoles = chasingHoles.filterNot { closeToSafety(it.startX + it.width / 2f, 180f) }.toMutableList()
            val safePlants = plantTraps.filterNot { closeToSafety(it.x + it.width / 2f, 155f) }.toMutableList()

            // Final structural cleanup: remove exact duplicates and nested support walls/roofs.
            val sanitizedPlatforms = platforms.fold(mutableListOf<GamePlatform>()) { acc, candidate ->
                val redundant = acc.any { existing ->
                    val exact = existing.role == candidate.role && existing.kind == candidate.kind &&
                        kotlin.math.abs(existing.x - candidate.x) < 1f && kotlin.math.abs(existing.y - candidate.y) < 1f &&
                        kotlin.math.abs(existing.width - candidate.width) < 1f && kotlin.math.abs(existing.height - candidate.height) < 1f
                    val nested = candidate.role in setOf(PlatformRole.WALL, PlatformRole.ROOF) &&
                        existing.role == candidate.role && existing.kind == PlatformKind.SOLID && candidate.kind == PlatformKind.SOLID &&
                        candidate.x >= existing.x - 2f && candidate.x + candidate.width <= existing.x + existing.width + 2f &&
                        candidate.y >= existing.y - 2f && candidate.y + candidate.height <= existing.y + existing.height + 2f
                    exact || nested
                }
                if (!redundant) acc += candidate
                acc
            }

            // Narrow ledges must retain an actual landing zone after a surprise spike appears.
            // GEO is 44 px wide; leaving only ~42-50 px on either side made some "possible" landings
            // effectively frame-perfect. Preserve the troll, but leave at least one real foothold.
            val sanitizedHazards = safeHazards.mapIndexed { index, hazard ->
                if (hazard.kind != HazardKind.HIDDEN_SPIKES || hazard.orientation != HazardOrientation.UP) {
                    hazard
                } else {
                    val support = sanitizedPlatforms.firstOrNull { p ->
                        hazard.x >= p.x - 8f && hazard.x + hazard.width <= p.x + p.width + 8f &&
                            kotlin.math.abs(p.y - (hazard.y + hazard.height)) <= 9f
                    }
                    if (support == null || support.width >= 180f) {
                        hazard
                    } else {
                        val leftClear = (hazard.x - support.x).coerceAtLeast(0f)
                        val rightClear = (support.x + support.width - (hazard.x + hazard.width)).coerceAtLeast(0f)
                        if (maxOf(leftClear, rightClear) >= 62f) {
                            hazard
                        } else {
                            val newWidth = minOf(hazard.width, 38f)
                            val placeOnRight = (plan.number + index) % 2 == 0
                            val newX = if (placeOnRight) {
                                support.x + support.width - newWidth - 10f
                            } else {
                                support.x + 10f
                            }
                            hazard.copy(
                                x = newX,
                                width = newWidth,
                                triggerX = minOf(hazard.triggerX, newX - 85f)
                            )
                        }
                    }
                }
            }

            // Keep difficulty varied: if a room composition produced too many spike hazards,
            // replace the excess with hidden projectiles at the same learned trigger area. The
            // player still dies often, but not because every answer is "another spike".
            val finalLaunchers = launchers.filterNot { launcher ->
                normalizedCheckpoints.any { cp -> cp.kind != CheckpointKind.DECOY && kotlin.math.abs(cp.x - launcher.x) < 165f }
            }.toMutableList()
            val nonSpikeThreats = safeEnemies.size + sanitizedFalling.size + safeCrushers.size + safeHoles.size +
                fans.size + safePlants.size + finalLaunchers.size + crates.count { it.payload == CratePayload.EXPLOSION }
            val maxSpikeHazards = maxOf(4, kotlin.math.floor(nonSpikeThreats * (0.30f / 0.70f)).toInt())
            val balancedHazards: List<GameHazard>
            if (sanitizedHazards.size <= maxSpikeHazards) {
                balancedHazards = sanitizedHazards
            } else {
                val ordered = sanitizedHazards.sortedBy { it.triggerX }
                val keepIndices = (0 until maxSpikeHazards).map { slot ->
                    if (maxSpikeHazards <= 1) 0 else kotlin.math.round(slot * (ordered.lastIndex.toFloat() / (maxSpikeHazards - 1))).toInt()
                }.toSet()
                balancedHazards = ordered.filterIndexed { index, _ -> index in keepIndices }
                ordered.filterIndexed { index, _ -> index !in keepIndices }.forEachIndexed { replacementIndex, hazard ->
                    val hx = hazard.x + hazard.width / 2f
                    val fromRight = (plan.number + replacementIndex) % 2 == 0
                    finalLaunchers += GameLauncher(
                        x = hx,
                        y = (hazard.y - 82f).coerceAtLeast(105f),
                        direction = if (fromRight) LauncherDirection.LEFT else LauncherDirection.RIGHT,
                        triggerX = hazard.triggerX,
                        triggerRadius = 320f,
                        delayMs = 275L + (replacementIndex % 3) * 25L,
                        projectileSpeed = 450f + plan.number * 4f,
                        hiddenUntilTriggered = true
                    )
                }
            }

            // Final density pass runs AFTER safety filtering. Earlier versions could lose an
            // entire room's threats when checkpoint safety removed them, leaving several seconds of
            // empty walking. Only hidden launchers are inserted here; they do not change geometry.
            fun finalTrollAnchors(): List<Float> = buildList {
                add(80f)
                add(goalX)
                normalizedCheckpoints.filter { it.kind != CheckpointKind.DECOY }.forEach { add(it.x) }
                balancedHazards.forEach { add(it.triggerX) }
                safeEnemies.mapNotNullTo(this) { it.activationTriggerX }
                sanitizedFalling.forEach { add(it.triggerX) }
                safeHoles.forEach { add(it.triggerX) }
                safeCrushers.forEach { add(it.triggerX) }
                finalLaunchers.forEach { add(it.triggerX) }
                safePlants.forEach { add(it.x - minOf(it.detectionRange, 190f)) }
                sanitizedPlatforms.filter { it.kind in setOf(PlatformKind.FALLING, PlatformKind.PROXIMITY_DISAPPEARING, PlatformKind.REVEALING) }
                    .forEach { add(it.triggerX) }
            }.filter { it in 0f..goalX }.sorted()

            repeat(5) { pass ->
                val anchors = finalTrollAnchors()
                val gap = anchors.zipWithNext().maxByOrNull { (a, b) -> b - a } ?: return@repeat
                if (gap.second - gap.first <= 1_060f) return@repeat
                var trigger = (gap.first + gap.second) * 0.5f
                val nearestCheckpoint = normalizedCheckpoints
                    .filter { it.kind != CheckpointKind.DECOY }
                    .minByOrNull { kotlin.math.abs(it.x - trigger) }
                if (nearestCheckpoint != null && kotlin.math.abs(nearestCheckpoint.x - trigger) < 180f) {
                    trigger = if (trigger < nearestCheckpoint.x) nearestCheckpoint.x - 190f else nearestCheckpoint.x + 190f
                }
                trigger = trigger.coerceIn(gap.first + 160f, gap.second - 160f)
                if (normalizedCheckpoints.any { it.kind != CheckpointKind.DECOY && kotlin.math.abs(it.x - trigger) < 165f }) return@repeat

                val support = sanitizedPlatforms
                    .filter { it.kind == PlatformKind.SOLID && it.role in setOf(PlatformRole.GROUND, PlatformRole.LEDGE) }
                    .minByOrNull { platform -> kotlin.math.abs((platform.x + platform.width / 2f) - trigger) }
                    ?: return@repeat
                val fromRight = (plan.number + pass + finalLaunchers.size) % 2 == 0
                var launcherX = (trigger + if (fromRight) 235f else -235f).coerceIn(gap.first + 55f, gap.second - 55f)
                if (normalizedCheckpoints.any { it.kind != CheckpointKind.DECOY && kotlin.math.abs(it.x - launcherX) < 160f }) {
                    launcherX = trigger
                }
                finalLaunchers += GameLauncher(
                    x = launcherX,
                    y = (support.y - 125f).coerceAtLeast(105f),
                    direction = if (fromRight) LauncherDirection.LEFT else LauncherDirection.RIGHT,
                    triggerX = trigger,
                    triggerRadius = 385f,
                    delayMs = 290L + pass * 20L,
                    projectileSpeed = 460f + plan.number * 4f,
                    hiddenUntilTriggered = true
                )
            }

            return AdventureLevel(
                number = plan.number,
                worldName = plan.world,
                levelName = plan.name,
                objective = plan.objective,
                difficultyLabel = plan.difficulty,
                width = width,
                platforms = sanitizedPlatforms.sortedWith(compareBy<GamePlatform> { it.x }.thenBy { it.y }),
                movingPlatforms = movingPlatforms,
                hazards = balancedHazards,
                barriers = barriers,
                enemies = safeEnemies,
                crystals = emptyList(),
                crates = crates,
                switches = switches,
                checkpoints = normalizedCheckpoints,
                fans = fans,
                fallingObjects = sanitizedFalling,
                chasingHoles = safeHoles,
                crushers = safeCrushers,
                requiredMechanisms = requiredMechanisms,
                pickups = pickups,
                goalX = goalX,
                parSeconds = 250 + plan.number * 13,
                introStory = plan.intro,
                outroStory = plan.outro,
                companion = plan.companion,
                weaponEnabled = plan.weaponEnabled,
                acechantePresent = plan.acechantePresent,
                biome = plan.biome,
                entryKind = plan.entry,
                exitKind = plan.exit,
                entryConnection = plan.entryConnection,
                exitConnection = plan.exitConnection,
                spawnX = 70f,
                spawnY = plan.startY - 58f,
                goalY = floorY - 135f,
                keys = keys,
                requiresKey = plan.requiresKey,
                requiredCrystals = 0,
                conduits = conduits,
                plantTraps = safePlants,
                trees = trees,
                launchers = finalLaunchers
            )
        }
    }

    private val plans = listOf(
        Plan(1, "Bosque tramposo", "El sendero que escucha", "Avanza con miedo: el bosque reacciona a saltos, pasos y retrocesos.", "BRUTAL", AdventureBiome.FOREST_DAY, LevelExitKind.TRAIL, LevelExitKind.ASCENT, "awakening", "ridge-gate", 620f,
            listOf(Beat.INVISIBLE_BLOCK_TRAP, Beat.DECEPTIVE_GROVE, Beat.DORMANT_AMBUSH, Beat.BREAKAWAY_FLOOR, Beat.PROJECTILE_ALLEY, Beat.ENEMY_REBOUND, Beat.FRUIT_AMBUSH, Beat.BOUNCE_CHAMBER, Beat.CHAIN_BLOCK_FALL),
            intro = "GEO despierta bajo un cielo limpio. Nada parece peligroso todavía.", outro = "La salida sube hacia una cresta más cerrada."),
        Plan(2, "Bosque tramposo", "La cresta cerrada", "Baja, vuelve, cambia de ruta y no confíes en la primera salida.", "BRUTAL+", AdventureBiome.FOREST_DAY, LevelExitKind.ASCENT, LevelExitKind.DESCENT, "ridge-gate", "root-descent", 430f,
            listOf(Beat.TRICK_ASCENT, Beat.INVISIBLE_BLOCK_TRAP, Beat.FALSE_EXIT_LOOP, Beat.PROJECTILE_ALLEY, Beat.SWITCH_COUNTERTRAP, Beat.DORMANT_AMBUSH, Beat.SINKING_FLOOR, Beat.COLLAPSING_BRIDGE, Beat.SURPRISE_CORRIDOR, Beat.PLANT_CONDUIT, Beat.BAIT_CRATES, Beat.BACKTRACK_ROOM)),
        Plan(3, "Bosque tramposo", "Las copas falsas", "Usa enemigos, corrientes y estructuras cambiantes para encontrar la ruta real.", "EXTREMO", AdventureBiome.FOREST_DAY, LevelExitKind.DESCENT, LevelExitKind.BRIDGE, "root-descent", "canopy-crossing", 620f,
            listOf(Beat.ENEMY_REBOUND, Beat.DORMANT_AMBUSH, Beat.TRICK_ASCENT, Beat.INVISIBLE_BLOCK_TRAP, Beat.SWING_LOG, Beat.PROJECTILE_ALLEY, Beat.FALSE_EXIT_LOOP, Beat.ROCK_BRIDGE, Beat.FRUIT_AMBUSH, Beat.BAIT_CRATES, Beat.CHAIN_BLOCK_FALL, Beat.BACKTRACK_ROOM, Beat.FALSE_SAFE, Beat.LANDING_TRAP)),
        Plan(4, "Bosque tramposo", "La puerta de raíces", "Encuentra la llave sin caer en las rutas cebo.", "EXTREMO+", AdventureBiome.FOREST_DAY, LevelExitKind.BRIDGE, LevelExitKind.DOOR, "canopy-crossing", "sunset-door", 500f,
            listOf(Beat.DECEPTIVE_GROVE, Beat.BAIT_CRATES, Beat.KEY_DETOUR, Beat.INVISIBLE_BLOCK_TRAP, Beat.SWITCH_COUNTERTRAP, Beat.PROJECTILE_ALLEY, Beat.BACKTRACK_ROOM, Beat.DORMANT_AMBUSH, Beat.CHAIN_BLOCK_FALL, Beat.FRUIT_AMBUSH), requiresKey = true,
            outro = "La puerta desemboca en un bosque teñido por el atardecer."),
        Plan(5, "Bosque del atardecer", "Puentes de sombra", "Cruza rutas que se rompen y se reconstruyen delante de GEO.", "DEMENTE", AdventureBiome.FOREST_SUNSET, LevelExitKind.DOOR, LevelExitKind.BRIDGE, "sunset-door", "broken-bridge", 610f,
            listOf(Beat.FALLING_WALL_BRIDGE, Beat.CHAIN_BLOCK_FALL, Beat.SILENT_ROOM, Beat.PROJECTILE_ALLEY, Beat.DECEPTIVE_GROVE, Beat.INVISIBLE_BLOCK_TRAP, Beat.TRICK_ASCENT, Beat.DORMANT_AMBUSH, Beat.VERTICAL_CONDUIT, Beat.PLANT_CONDUIT, Beat.ROLLING_ESCAPE, Beat.BAIT_CRATES), companion = "Luma"),
        Plan(6, "Bosque del atardecer", "El barranco naranja", "Desciende por cámaras, conductos y pisos que ceden bajo tus decisiones.", "DEMENTE+", AdventureBiome.FOREST_SUNSET, LevelExitKind.BRIDGE, LevelExitKind.DESCENT, "broken-bridge", "ravine-depth", 460f,
            listOf(Beat.VERTICAL_CONDUIT, Beat.INVISIBLE_BLOCK_TRAP, Beat.COLLAPSING_BRIDGE, Beat.SWITCH_GATE, Beat.PROJECTILE_ALLEY, Beat.ROLLING_ESCAPE, Beat.BAIT_CRATES, Beat.TRAP_LIFT, Beat.DORMANT_AMBUSH, Beat.FAN_SHAFT)),
        Plan(7, "Bosque del atardecer", "Raíces con dientes", "Aprende qué raíces son inocentes y cuáles cambian el camino.", "IMPOSIBLE JUSTO", AdventureBiome.FOREST_SUNSET, LevelExitKind.DESCENT, LevelExitKind.TUNNEL, "ravine-depth", "root-tunnel", 620f,
            listOf(Beat.DECEPTIVE_GROVE, Beat.PROJECTILE_ALLEY, Beat.FALSE_EXIT_LOOP, Beat.INVISIBLE_BLOCK_TRAP, Beat.BACKTRACK_ROOM, Beat.BAIT_CRATES, Beat.ENEMY_REBOUND, Beat.CHAIN_BLOCK_FALL, Beat.VERTICAL_CONDUIT, Beat.DORMANT_AMBUSH)),
        Plan(8, "Bosque del atardecer", "La boca de la tierra", "El bosque termina en un descenso que se transforma mientras huyes.", "IMPOSIBLE+", AdventureBiome.FOREST_SUNSET, LevelExitKind.TUNNEL, LevelExitKind.CAVE, "root-tunnel", "earth-mouth", 590f,
            listOf(Beat.ROLLING_ESCAPE, Beat.PROJECTILE_ALLEY, Beat.DECEPTIVE_GROVE, Beat.TRICK_ASCENT, Beat.CHAIN_BLOCK_FALL, Beat.SWITCH_COUNTERTRAP, Beat.DORMANT_AMBUSH, Beat.SINKING_FLOOR, Beat.INVISIBLE_BLOCK_TRAP, Beat.PLANT_CONDUIT)),
        Plan(9, "Subsuelo", "La mina sin mapa", "Usa llaves, roca y rutas falsas para atravesar la mina.", "PESADILLA", AdventureBiome.UNDERGROUND, LevelExitKind.CAVE, LevelExitKind.DOOR, "earth-mouth", "locked-mine", 610f,
            listOf(Beat.SILENT_ROOM, Beat.INVISIBLE_BLOCK_TRAP, Beat.KEY_DETOUR, Beat.BAIT_CRATES, Beat.FALLING_WALL_BRIDGE, Beat.PROJECTILE_ALLEY, Beat.CHAIN_BLOCK_FALL, Beat.TRAP_LIFT, Beat.DORMANT_AMBUSH, Beat.WALL_MAZE), requiresKey = true),
        Plan(10, "Subsuelo", "El elevador roto", "Sube y baja por un pozo mecánico que nunca hace exactamente lo esperado.", "PESADILLA+", AdventureBiome.UNDERGROUND, LevelExitKind.DOOR, LevelExitKind.LIFT, "locked-mine", "abyss-elevator", 610f,
            listOf(Beat.TRAP_LIFT, Beat.VERTICAL_CONDUIT, Beat.PROJECTILE_ALLEY, Beat.ROLLING_ESCAPE, Beat.INVISIBLE_BLOCK_TRAP, Beat.CHAIN_BLOCK_FALL, Beat.DORMANT_AMBUSH, Beat.FALSE_EXIT_LOOP, Beat.BAIT_CRATES, Beat.SHAFT_UP)),
        Plan(11, "Cavernas nocturnas", "Cristales que observan", "Cruza cámaras donde la roca, los enemigos y el suelo reaccionan juntos.", "TERROR", AdventureBiome.CAVE_NIGHT, LevelExitKind.LIFT, LevelExitKind.CAVE, "abyss-elevator", "crystal-hollows", 470f,
            listOf(Beat.SILENT_ROOM, Beat.PROJECTILE_ALLEY, Beat.ENEMY_REBOUND, Beat.VERTICAL_CONDUIT, Beat.DORMANT_AMBUSH, Beat.CHAIN_BLOCK_FALL, Beat.SWITCH_COUNTERTRAP, Beat.INVISIBLE_BLOCK_TRAP, Beat.BAIT_CRATES, Beat.LOW_TUNNEL), companion = "Luma"),
        Plan(12, "Cavernas nocturnas", "La vena ardiente", "Deja que el escenario te enseñe cuándo avanzar y cuándo retroceder.", "TERROR+", AdventureBiome.CAVE_NIGHT, LevelExitKind.CAVE, LevelExitKind.TUNNEL, "crystal-hollows", "fire-vein", 430f,
            listOf(Beat.BACKTRACK_ROOM, Beat.INVISIBLE_BLOCK_TRAP, Beat.ROLLING_ESCAPE, Beat.PROJECTILE_ALLEY, Beat.FALLING_WALL_BRIDGE, Beat.BAIT_CRATES, Beat.VERTICAL_CONDUIT, Beat.CHAIN_BLOCK_FALL, Beat.DORMANT_AMBUSH, Beat.CRUSHER_ROOM), weaponEnabled = true),
        Plan(13, "Cavernas nocturnas", "El pozo de ecos", "Escala y desciende por una ruta vertical que castiga las reacciones automáticas.", "ABISMO", AdventureBiome.CAVE_NIGHT, LevelExitKind.TUNNEL, LevelExitKind.ASCENT, "fire-vein", "night-shaft", 620f,
            listOf(Beat.TRICK_ASCENT, Beat.VERTICAL_CONDUIT, Beat.DORMANT_AMBUSH, Beat.INVISIBLE_BLOCK_TRAP, Beat.FALSE_EXIT_LOOP, Beat.PROJECTILE_ALLEY, Beat.TRAP_LIFT, Beat.CHAIN_BLOCK_FALL, Beat.BAIT_CRATES, Beat.SHAFT_DOWN), acechantePresent = true),
        Plan(14, "Cavernas nocturnas", "Muros que respiran", "Haz que las paredes, rocas y mecanismos trabajen a tu favor.", "ABISMO+", AdventureBiome.CAVE_NIGHT, LevelExitKind.ASCENT, LevelExitKind.RUIN_GATE, "night-shaft", "buried-door", 350f,
            listOf(Beat.FALLING_WALL_BRIDGE, Beat.SWITCH_COUNTERTRAP, Beat.CHAIN_BLOCK_FALL, Beat.PROJECTILE_ALLEY, Beat.BAIT_CRATES, Beat.ROLLING_ESCAPE, Beat.INVISIBLE_BLOCK_TRAP, Beat.DORMANT_AMBUSH, Beat.TRICK_ASCENT, Beat.WALL_MAZE), weaponEnabled = true),
        Plan(15, "Cavernas nocturnas", "La puerta enterrada", "Encuentra la llave final de las profundidades sin confiar en la salida más obvia.", "INHUMANO", AdventureBiome.CAVE_NIGHT, LevelExitKind.RUIN_GATE, LevelExitKind.DOOR, "buried-door", "dawn-lift", 520f,
            listOf(Beat.FALSE_EXIT_LOOP, Beat.KEY_DETOUR, Beat.BAIT_CRATES, Beat.PROJECTILE_ALLEY, Beat.INVISIBLE_BLOCK_TRAP, Beat.ROLLING_ESCAPE, Beat.TRAP_LIFT, Beat.CHAIN_BLOCK_FALL, Beat.DORMANT_AMBUSH, Beat.LOW_TUNNEL), requiresKey = true, weaponEnabled = true,
            outro = "La puerta deja entrar una luz cálida. GEO comienza el ascenso."),
        Plan(16, "Desierto del amanecer", "La escalera de arena", "Sube por ruinas que se hunden, caen y vuelven a convertirse en camino.", "INHUMANO+", AdventureBiome.DESERT_DAWN, LevelExitKind.DOOR, LevelExitKind.ASCENT, "dawn-lift", "dune-maze", 620f,
            listOf(Beat.TRICK_ASCENT, Beat.SINKING_FLOOR, Beat.PROJECTILE_ALLEY, Beat.ROCK_BRIDGE, Beat.BAIT_CRATES, Beat.INVISIBLE_BLOCK_TRAP, Beat.CHAIN_BLOCK_FALL, Beat.VERTICAL_CONDUIT, Beat.DORMANT_AMBUSH, Beat.COLLAPSING_BRIDGE), companion = "Nox", weaponEnabled = true),
        Plan(17, "Desierto del amanecer", "El laberinto de dunas", "Elige rutas altas y bajas mientras las ruinas cambian detrás de ti.", "LEYENDA", AdventureBiome.DESERT_DAWN, LevelExitKind.ASCENT, LevelExitKind.RUIN_GATE, "dune-maze", "ruin-courtyard", 360f,
            listOf(Beat.FALSE_EXIT_LOOP, Beat.DORMANT_AMBUSH, Beat.SWITCH_COUNTERTRAP, Beat.ROLLING_ESCAPE, Beat.PROJECTILE_ALLEY, Beat.TRAP_LIFT, Beat.INVISIBLE_BLOCK_TRAP, Beat.CHAIN_BLOCK_FALL, Beat.BAIT_CRATES, Beat.SPLIT_ROUTE), weaponEnabled = true),
        Plan(18, "Desierto del amanecer", "El patio de las llaves", "Abre la puerta solar sin dejar que el patio decida tu ruta por ti.", "LEYENDA+", AdventureBiome.DESERT_DAWN, LevelExitKind.RUIN_GATE, LevelExitKind.DOOR, "ruin-courtyard", "sun-key-gate", 520f,
            listOf(Beat.SWITCH_COUNTERTRAP, Beat.KEY_DETOUR, Beat.BAIT_CRATES, Beat.PROJECTILE_ALLEY, Beat.ENEMY_REBOUND, Beat.INVISIBLE_BLOCK_TRAP, Beat.TRAP_LIFT, Beat.CHAIN_BLOCK_FALL, Beat.DORMANT_AMBUSH, Beat.HIGH_BRIDGE), requiresKey = true, weaponEnabled = true),
        Plan(19, "Desierto del amanecer", "Las ruinas imposibles", "Combina todo lo aprendido: esperar, retroceder, usar enemigos y transformar el escenario.", "MITO", AdventureBiome.DESERT_DAWN, LevelExitKind.DOOR, LevelExitKind.SUMMIT, "sun-key-gate", "summit-approach", 430f,
            listOf(Beat.ROLLING_ESCAPE, Beat.PROJECTILE_ALLEY, Beat.FALLING_WALL_BRIDGE, Beat.FALSE_EXIT_LOOP, Beat.INVISIBLE_BLOCK_TRAP, Beat.ENEMY_REBOUND, Beat.BAIT_CRATES, Beat.CHAIN_BLOCK_FALL, Beat.DORMANT_AMBUSH, Beat.MOVING_GAP, Beat.SURPRISE_CORRIDOR, Beat.SWITCH_COUNTERTRAP), weaponEnabled = true, acechantePresent = true),
        Plan(20, "Cumbre del amanecer", "La última mentira", "Supera la última ruta usando todo lo que el mundo te enseñó.", "FINAL ABSOLUTO", AdventureBiome.DESERT_DAWN, LevelExitKind.SUMMIT, LevelExitKind.DOOR, "summit-approach", "adventure-end", 380f,
            listOf(Beat.FALSE_EXIT_LOOP, Beat.KEY_DETOUR, Beat.SWITCH_COUNTERTRAP, Beat.PROJECTILE_ALLEY, Beat.CHAIN_BLOCK_FALL, Beat.ROLLING_ESCAPE, Beat.DORMANT_AMBUSH, Beat.INVISIBLE_BLOCK_TRAP, Beat.BAIT_CRATES, Beat.ENEMY_REBOUND, Beat.BOUNCE_CHAMBER), requiresKey = true, weaponEnabled = true, acechantePresent = true,
            intro = "La salida está cerca. El mundo ya sabe cómo reacciona GEO.", outro = "GEO alcanza la salida. La aventura termina, pero el mundo sigue desconfiando de él.")
    )

    private val levelCache = arrayOfNulls<AdventureLevel>(GeoGameRules.LEVEL_COUNT)
    private val cacheLock = Any()

    private fun planFor(number: Int): Plan = plans[number.coerceIn(1, GeoGameRules.LEVEL_COUNT) - 1]

    /** Lightweight metadata for menus. These methods never build the full authored level. */
    fun difficultyLabel(number: Int): String = planFor(number).difficulty
    fun levelName(number: Int): String = planFor(number).name
    fun introStory(number: Int): String? = planFor(number).intro

    /**
     * Levels are immutable authored data, so generating the same maze repeatedly wastes CPU and
     * allocations. Cache each level once. The synchronized fill also makes background prewarming
     * safe when a player taps a level while Compose is rendering the menu.
     */
    fun build(number: Int): AdventureLevel {
        val index = number.coerceIn(1, GeoGameRules.LEVEL_COUNT) - 1
        levelCache[index]?.let { return it }
        return synchronized(cacheLock) {
            levelCache[index] ?: MazeBuilder(plans[index]).build().also { levelCache[index] = it }
        }
    }
}
