package com.ganageo.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ganageo.app.model.GeoSkin
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.geoMultiplayerDataStore by preferencesDataStore(name = "geo_multiplayer")

class GeoMultiplayerLocalProgressStore(private val context: Context) {
    private object Keys {
        val SelectedSkin = stringPreferencesKey("selected_skin")
        val PendingRoom = stringPreferencesKey("pending_room")
    }

    private fun safeScope(scopeId: String?): String = scopeId
        ?.lowercase()
        ?.replace(Regex("[^a-z0-9]"), "")
        ?.take(40)
        ?.ifBlank { "guest" }
        ?: "guest"

    private fun sparseLevelsKey(scopeId: String?) = stringPreferencesKey("sparse_levels_${safeScope(scopeId)}")
    private fun premiumSkinsKey(scopeId: String?) = stringPreferencesKey("premium_skins_${safeScope(scopeId)}")

    suspend fun unlockedLevels(baseUnlocked: Int, scopeId: String? = null): Set<Int> {
        return (1..baseUnlocked.coerceIn(1, 20)).toSet() + sparseLevels(scopeId)
    }

    suspend fun sparseLevels(scopeId: String? = null): Set<Int> {
        val key = sparseLevelsKey(scopeId)
        return context.geoMultiplayerDataStore.data.map { it[key].orEmpty() }.first()
            .split(',').mapNotNull { it.toIntOrNull() }.filter { it in 1..20 }.toSet()
    }

    suspend fun unlock(level: Int, scopeId: String? = null) {
        if (level !in 1..20) return
        val key = sparseLevelsKey(scopeId)
        context.geoMultiplayerDataStore.edit { prefs ->
            val set = prefs[key].orEmpty().split(',').mapNotNull { it.toIntOrNull() }.toMutableSet()
            set += level
            prefs[key] = set.sorted().joinToString(",")
        }
    }

    suspend fun selectedSkin(): GeoSkin = context.geoMultiplayerDataStore.data.map {
        GeoSkin.fromCode(it[Keys.SelectedSkin])
    }.first()

    suspend fun setSelectedSkin(skin: GeoSkin) {
        context.geoMultiplayerDataStore.edit { it[Keys.SelectedSkin] = skin.code }
    }

    suspend fun premiumSkins(scopeId: String? = null): Set<String> {
        val key = premiumSkinsKey(scopeId)
        return context.geoMultiplayerDataStore.data.map { prefs ->
            prefs[key].orEmpty().split(',').filter { it.isNotBlank() }.toSet()
        }.first()
    }

    suspend fun setPremiumSkins(skins: Set<String>, scopeId: String? = null) {
        val key = premiumSkinsKey(scopeId)
        context.geoMultiplayerDataStore.edit { it[key] = skins.sorted().joinToString(",") }
    }

    suspend fun savePendingRoom(roomId: String) {
        context.geoMultiplayerDataStore.edit { it[Keys.PendingRoom] = roomId }
    }

    suspend fun consumePendingRoom(): String? {
        var value: String? = null
        context.geoMultiplayerDataStore.edit { prefs ->
            value = prefs[Keys.PendingRoom]?.takeIf { it.isNotBlank() }
            prefs.remove(Keys.PendingRoom)
        }
        return value
    }
}
