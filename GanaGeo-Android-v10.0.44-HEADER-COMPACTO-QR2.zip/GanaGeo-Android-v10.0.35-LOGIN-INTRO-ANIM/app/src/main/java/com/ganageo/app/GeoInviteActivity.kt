package com.ganageo.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.ganageo.app.data.GeoMultiplayerLocalProgressStore
import kotlinx.coroutines.launch

/**
 * Entrada aislada para invitaciones multijugador. No modifica autenticacion ni sesion.
 * Guarda la sala pendiente y abre la Activity principal existente.
 */
class GeoInviteActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val roomId = intent?.data?.pathSegments?.firstOrNull()?.trim().orEmpty()
        if (roomId.isBlank()) {
            openMain()
            return
        }
        lifecycleScope.launch {
            runCatching { GeoMultiplayerLocalProgressStore(applicationContext).savePendingRoom(roomId) }
            openMain()
        }
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }
}
