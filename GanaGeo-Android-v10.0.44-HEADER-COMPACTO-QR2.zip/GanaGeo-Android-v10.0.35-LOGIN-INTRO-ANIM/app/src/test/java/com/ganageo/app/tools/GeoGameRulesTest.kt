package com.ganageo.app.tools

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class GeoGameRulesTest {
    @Test
    fun freeLivesUseFiveSlotsAndRecoverEveryThirtyMinutes() {
        assertEquals(5, GeoGameRules.MAX_FREE_LIVES)
        assertEquals(30, GeoGameRules.FREE_LIFE_RECOVERY_MINUTES)
    }

    @Test
    fun everyLevelUsesFifteenGameLivesWithOneDeathPerLife() {
        assertEquals(15, GeoGameRules.GAME_LIVES_PER_RUN)
        (1..GeoGameRules.LEVEL_COUNT).forEach { level ->
            assertEquals(15, GeoGameRules.attemptsForLevel(level))
        }
    }


    @Test
    fun deathTimingKeepsTrapsVisibleButVoidRestartsImmediately() {
        assertEquals(1_000L, GeoGameRules.DEATH_REVEAL_MS)
        assertEquals(80L, GeoGameRules.VOID_RESPAWN_DELAY_MS)
        assertEquals(900L, GeoGameRules.HOLE_SINK_MS)
    }

    @Test
    fun lifePackagesKeepTwoCreditsPerPremiumLife() {
        GeoGameRules.lifePackages.forEach { pack ->
            assertEquals(pack.lives * GeoGameRules.PREMIUM_LIFE_CREDIT_COST, pack.creditCost)
        }
        assertNull(GeoGameRules.packageByCode("unknown"))
    }

    @Test
    fun premiumRewardsStillActivateAfterTwentySeconds() {
        assertEquals(20, GeoGameRules.PREMIUM_ACTIVATION_SECONDS)
    }

    @Test
    fun starsNeverDependOnRewardsOrLifeType() {
        assertEquals(0, GeoGameRules.calculateStars(false, 3, 10, 60))
        assertEquals(1, GeoGameRules.calculateStars(true, 0, 80, 60))
        assertEquals(2, GeoGameRules.calculateStars(true, 3, 80, 60))
        assertEquals(3, GeoGameRules.calculateStars(true, 3, 50, 60))
    }

    @Test
    fun twentyLevelsAreSplitIntoFourWorlds() {
        assertEquals("Bosque del despertar", GeoGameRules.worldName(1))
        assertEquals("Descenso del atardecer", GeoGameRules.worldName(6))
        assertEquals("Cavernas nocturnas", GeoGameRules.worldName(11))
        assertEquals("Desierto del amanecer", GeoGameRules.worldName(20))
    }
}
