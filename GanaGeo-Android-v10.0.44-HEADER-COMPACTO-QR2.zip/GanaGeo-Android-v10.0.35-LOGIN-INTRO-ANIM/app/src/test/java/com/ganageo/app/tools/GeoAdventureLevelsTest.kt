package com.ganageo.app.tools

import java.util.ArrayDeque
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class GeoAdventureLevelsTest {
    private val levels get() = (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build)

    @Test
    fun createsTwentyConnectedAdventureLevelsWithoutMandatoryCollectibles() {
        assertEquals(20, levels.size)
        levels.forEachIndexed { index, level ->
            assertEquals(index + 1, level.number)
            assertTrue("Nivel ${level.number}: demasiado corto", level.width >= 6_800f)
            assertEquals("Nivel ${level.number}: no debe exigir cristales", 0, level.requiredCrystals)
            assertTrue("Nivel ${level.number}: quedaron cristales obligatorios", level.crystals.isEmpty())
            assertTrue("Nivel ${level.number}: faltan enemigos", level.enemies.isNotEmpty())
            val threatCount = level.hazards.size + level.enemies.size + level.fallingObjects.size +
                level.crushers.size + level.chasingHoles.size + level.fans.size + level.plantTraps.size +
                level.launchers.size + level.crates.count { it.payload == CratePayload.EXPLOSION }
            assertTrue("Nivel ${level.number}: no alcanza la densidad full-troll", threatCount >= 30)
            assertTrue("Nivel ${level.number}: par inválido", level.parSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS)
        }
    }

    @Test
    fun everyExitContinuesIntoTheNextLevelEntry() {
        levels.zipWithNext().forEach { (current, next) ->
            assertEquals(
                "La salida del nivel ${current.number} no conecta con la entrada del ${next.number}",
                current.exitConnection,
                next.entryConnection
            )
        }
        assertEquals("awakening", levels.first().entryConnection)
        assertEquals("adventure-end", levels.last().exitConnection)
    }

    @Test
    fun actsProgressFromDayToDepthsNightAndDesertDawn() {
        assertTrue(levels.slice(0..3).all { it.biome == AdventureBiome.FOREST_DAY })
        assertTrue(levels.slice(4..7).all { it.biome == AdventureBiome.FOREST_SUNSET })
        assertTrue(levels.slice(8..9).all { it.biome == AdventureBiome.UNDERGROUND })
        assertTrue(levels.slice(10..14).all { it.biome == AdventureBiome.CAVE_NIGHT })
        assertTrue(levels.slice(15..19).all { it.biome == AdventureBiome.DESERT_DAWN })
    }

    @Test
    fun terrainIsARealMazeWithFloorsCeilingsAndSideStructures() {
        levels.forEach { level ->
            val distinctHeights = level.platforms.map { it.y }.distinct()
            val verticalRange = distinctHeights.maxOrNull()!! - distinctHeights.minOrNull()!!
            val tallStructures = level.platforms.count { it.height >= 90f }
            val roofStructures = level.platforms.count { it.role == PlatformRole.ROOF && it.height >= 90f }
            val wallStructures = level.platforms.count { it.role == PlatformRole.WALL && it.height >= 90f }
            assertTrue("Nivel ${level.number}: muy pocas alturas", distinctHeights.size >= 6)
            assertTrue("Nivel ${level.number}: todavía se siente plano", verticalRange >= 180f)
            assertTrue("Nivel ${level.number}: faltan muros y bloques laterales", tallStructures >= 5)
            assertTrue("Nivel ${level.number}: falta estructura de laberinto superior/vertical", roofStructures >= 1 || wallStructures >= 1 || level.conduits.size >= 2 || level.movingPlatforms.count { it.vertical } >= 2)
        }
    }

    @Test
    fun adjacentLevelsDoNotRepeatTheSameOpening() {
        fun openingSignature(level: AdventureLevel): String {
            val firstTerrain = level.platforms.sortedBy { it.x }.take(3)
                .joinToString("|") { "${it.y.toInt()}:${it.kind}" }
            return "${level.biome}:${level.entryKind}:${level.spawnY.toInt()}:$firstTerrain"
        }
        levels.zipWithNext().forEach { (current, next) ->
            assertTrue(
                "Los niveles ${current.number} y ${next.number} repiten el mismo inicio",
                openingSignature(current) != openingSignature(next)
            )
        }
        assertTrue("No debe repetirse pinchos + checkpoint falso al inicio", levels.all { level ->
            level.checkpoints.none { it.kind == CheckpointKind.DECOY && it.x < 600f }
        })
    }

    @Test
    fun spikesAreAttachedToRealFloorOrCeilingStructures() {
        levels.forEach { level ->
            level.hazards.forEach { hazard ->
                when (hazard.orientation) {
                    HazardOrientation.UP -> assertTrue("Nivel ${level.number}: pinchos de piso flotantes", level.platforms.any { platform ->
                        platform.x <= hazard.x + 3f && platform.x + platform.width >= hazard.x + hazard.width - 3f &&
                            abs(platform.y - (hazard.y + hazard.height)) <= 5f
                    })
                    HazardOrientation.DOWN -> assertTrue("Nivel ${level.number}: pinchos de techo sin techo", level.platforms.any { platform ->
                        platform.x <= hazard.x && platform.x + platform.width >= hazard.x + hazard.width &&
                            abs((platform.y + platform.height) - hazard.y) <= 5f
                    })
                    HazardOrientation.LEFT -> assertTrue("Nivel ${level.number}: pincho lateral izquierdo sin pared", level.platforms.any { platform ->
                        abs(platform.x - (hazard.x + hazard.width)) <= 8f &&
                            platform.y <= hazard.y + 3f && platform.y + platform.height >= hazard.y + hazard.height - 3f
                    })
                    HazardOrientation.RIGHT -> assertTrue("Nivel ${level.number}: pincho lateral derecho sin pared", level.platforms.any { platform ->
                        abs((platform.x + platform.width) - hazard.x) <= 8f &&
                            platform.y <= hazard.y + 3f && platform.y + platform.height >= hazard.y + hazard.height - 3f
                    })
                }
            }
        }
    }

    @Test
    fun keysOpenOnlyPurposefulLockedDoors() {
        val keyLevels = levels.filter { it.requiresKey }
        assertEquals(setOf(4, 9, 15, 18, 20), keyLevels.map { it.number }.toSet())
        keyLevels.forEach { level ->
            assertTrue("Nivel ${level.number}: puerta con llave sin llave", level.keys.isNotEmpty())
            assertEquals("Nivel ${level.number}: la llave debe abrir una puerta", LevelExitKind.DOOR, level.exitKind)
            level.keys.forEach { key ->
                assertTrue("Nivel ${level.number}: llave fuera del terreno", level.platforms.any { platform ->
                    key.x in platform.x..(platform.x + platform.width) && abs(key.y - (platform.y - 72f)) <= 1f
                })
            }
        }
    }

    @Test
    fun realCheckpointsStayPermanentAndSafe() {
        levels.forEach { level ->
            val real = level.checkpoints.filter { it.kind != CheckpointKind.DECOY }
            assertTrue("Nivel ${level.number}: faltan checkpoints reales", real.size >= 2)
            real.forEach { checkpoint ->
                assertTrue("Nivel ${level.number}: checkpoint sin plataforma sólida", level.platforms.any { platform ->
                    platform.kind == PlatformKind.SOLID &&
                        checkpoint.x in platform.x..(platform.x + platform.width) &&
                        abs(platform.y - (checkpoint.y + 82f)) < 0.1f
                })
                assertTrue("Nivel ${level.number}: checkpoint junto a peligro", level.hazards.none { hazard ->
                    abs((hazard.x + hazard.width / 2f) - checkpoint.x) < 85f
                })
                assertTrue("Nivel ${level.number}: checkpoint bajo objeto que cae", level.fallingObjects.none { falling ->
                    abs((falling.x + falling.size / 2f) - checkpoint.x) < 100f
                })
                assertTrue("Nivel ${level.number}: checkpoint junto a suelo que se abre", level.chasingHoles.none { hole ->
                    abs((hole.startX + hole.width / 2f) - checkpoint.x) < 150f
                })
                assertTrue("Nivel ${level.number}: checkpoint junto a planta trampa", level.plantTraps.none { plant ->
                    abs((plant.x + plant.width / 2f) - checkpoint.x) < 130f
                })
                assertTrue("Nivel ${level.number}: checkpoint junto a lanzador oculto", level.launchers.none { launcher ->
                    abs(launcher.x - checkpoint.x) < 150f
                })
                assertTrue("Nivel ${level.number}: checkpoint junto a caja explosiva", level.crates.none { crate ->
                    crate.payload == CratePayload.EXPLOSION && abs((crate.x + 27f) - checkpoint.x) < 140f
                })
                assertTrue("Nivel ${level.number}: checkpoint junto a enemigo dormido", level.enemies.none { enemy ->
                    enemy.hiddenUntilActivated && abs(enemy.x - checkpoint.x) < 120f
                })
            }
        }
        assertTrue("Los checkpoints falsos deben usarse con moderación", levels.sumOf { level ->
            level.checkpoints.count { it.kind == CheckpointKind.DECOY }
        } <= 5)
    }

    @Test
    fun applesAreUnexpectedFastAndStillLearnable() {
        val falling = levels.flatMap { it.fallingObjects }
        val fruit = falling.filter { it.kind == FallingObjectKind.FRUIT }
        assertTrue(fruit.any { it.behavior == FallingBehavior.EXPLODE })
        assertTrue(fruit.any { it.behavior == FallingBehavior.CHASE })
        assertTrue(fruit.any { it.behavior == FallingBehavior.ROLL })
        assertTrue(fruit.any { it.treeFallsAfterTrap })
        assertTrue(fruit.filter { it.behavior == FallingBehavior.CHASE }.all {
            it.chaseDurationMs <= 4_800L && it.chaseMaxTravel <= 750f
        })
        assertTrue("Las manzanas explosivas deben reaccionar rápido", fruit.filter { it.behavior == FallingBehavior.EXPLODE }.all {
            it.explosionDelayMs in 180L..350L
        })
        val triggerModes = fruit.map { it.triggerMode }.toSet()
        assertTrue("Las trampas de árbol deben activarse de varias maneras", triggerModes.size >= 4)
        assertTrue("Debe haber árboles normales mezclados con árboles trampa", levels.filter {
            it.biome == AdventureBiome.FOREST_DAY || it.biome == AdventureBiome.FOREST_SUNSET
        }.all { it.trees.isNotEmpty() })
        assertTrue("Debe haber rocas que se convierten en camino", falling.any { it.becomesPlatform })
    }

    @Test
    fun surpriseSpikesUseTriggeredRuntimeLifecycleInsteadOfAuthoredTimerLoops() {
        val hidden = levels.flatMap { it.hazards }.filter { it.kind == HazardKind.HIDDEN_SPIKES }
        assertTrue("Deben existir pinchos sorpresa", hidden.isNotEmpty())
        assertTrue("El ciclo de rearmado debe vivir en runtime, no en un temporizador fijo del nivel", hidden.all {
            it.cycleMs == 0L && !it.retractable
        })
        assertTrue("Debe haber distintos disparadores de pinchos sorpresa", hidden.map { it.triggerMode }.toSet().size >= 2)
    }

    @Test
    fun fallingWallsAreSmallerWarnedAndAestheticallyTemporary() {
        val crushers = levels.flatMap { it.crushers }
        val fallingWalls = crushers.filter { it.style == CrusherStyle.FALLING_WALL }
        assertTrue(fallingWalls.isNotEmpty())
        fallingWalls.forEach { wall ->
            assertTrue("Muro demasiado ancho", wall.width <= 170f)
            assertTrue("Muro sin aviso", wall.delayMs >= 300L)
            assertTrue("Muro permanente tras caer", wall.despawnAfterMs in 2_500L..3_500L)
        }
        crushers.filter { it.axis == CrusherAxis.HORIZONTAL }.forEach { wall ->
            assertTrue("Prensa horizontal demasiado larga", abs(wall.travel) <= 150f)
            assertTrue("Prensa horizontal demasiado rápida", wall.speed <= 300f)
            assertTrue("Prensa horizontal sin ventana", wall.reverseAfterMs >= 1_450L)
        }
    }

    @Test
    fun reactivePlatformFamiliesExistWithoutTimerOnlyFloors() {
        val allPlatforms = levels.flatMap { it.platforms }
        assertTrue(allPlatforms.any { it.kind == PlatformKind.FALLING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.PROXIMITY_DISAPPEARING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.REVEALING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.BOUNCE })
        assertTrue("No debe haber pisos que desaparezcan solo por reloj", allPlatforms.none {
            it.kind == PlatformKind.DISAPPEARING
        })
        assertTrue(allPlatforms.filter { it.kind == PlatformKind.PROXIMITY_DISAPPEARING }.all {
            it.delayMs >= 900L
        })
    }

    @Test
    fun everyLevelHasAPhysicsBasedReachableRouteFromSpawnToExit() {
        levels.forEach { level ->
            // Model the same jump constants used by GeoAdventureGame instead of a loose distance graph.
            // Dynamic route surfaces are included at their usable positions; the jump simulation also
            // checks ceiling collisions so a low roof cannot be silently accepted as passable.
            val platforms = buildList {
                addAll(level.platforms)
                level.movingPlatforms.forEach { moving ->
                    // A moving platform is never a continuous bridge. GEO can wait for it, so the
                    // conservative structural solver uses the authored center position at real size.
                    add(GamePlatform(moving.x, moving.y, moving.width, 26f))
                }
                level.fallingObjects.filter { it.becomesPlatform }.forEach { falling ->
                    add(GamePlatform(falling.x, falling.targetY - falling.size, falling.size, 24f))
                }
                level.switches.forEach { sw ->
                    add(GamePlatform(sw.opensAtX, 520f, 235f, 26f))
                }
                level.fallingObjects.forEachIndexed { index, falling ->
                    if (falling.treeFallsAfterTrap && falling.kind == FallingObjectKind.FRUIT) {
                        val trunkLength = (falling.targetY - (falling.startY - 28f)).coerceAtLeast(180f)
                        val direction = if ((index + level.number) % 2 == 0) 1f else -1f
                        val base = falling.x + falling.size / 2f
                        val tip = base + direction * trunkLength
                        add(
                            GamePlatform(
                                minOf(base, tip) + 24f,
                                falling.targetY - 11f,
                                (abs(tip - base) - 48f).coerceAtLeast(120f),
                                22f
                            )
                        )
                    }
                }
            }

            val playerWidth = 44f
            val playerHeight = 58f
            val horizontalSpeed = 278f + level.number * 3.4f
            val gravity = 1_470f
            val dt = 1f / 120f
            val secondJumpTimes = listOf<Float?>(null, 0.20f, 0.35f, 0.50f, 0.65f, 0.80f, 0.95f)

            fun overlapsX(playerX: Float, platform: GamePlatform): Boolean =
                playerX + playerWidth > platform.x + 2f && playerX < platform.x + platform.width - 2f

            fun jumpLanding(fromIndex: Int, direction: Int, secondJumpAt: Float?): Int? {
                val from = platforms[fromIndex]
                var px = if (direction > 0) from.x + from.width - playerWidth - 2f else from.x + 2f
                var py = from.y - playerHeight
                var velocityY = if (from.kind == PlatformKind.BOUNCE) -810f else -655f
                var elapsed = 0f
                var doubleJumpUsed = false

                repeat(360) {
                    if (secondJumpAt != null && !doubleJumpUsed && elapsed >= secondJumpAt) {
                        velocityY = -535f
                        doubleJumpUsed = true
                    }
                    val previousTop = py
                    val previousBottom = py + playerHeight
                    px += direction * horizontalSpeed * dt
                    if (px < 0f || px > level.width - playerWidth) return null

                    velocityY += gravity * dt
                    var nextY = py + velocityY * dt
                    if (velocityY < 0f) {
                        platforms.forEachIndexed { index, platform ->
                            if (index == fromIndex) return@forEachIndexed
                            val underside = platform.y + platform.height
                            if (overlapsX(px, platform) && previousTop >= underside - 10f && nextY <= underside) {
                                nextY = underside
                                velocityY = 0f
                            }
                        }
                    }

                    val nextBottom = nextY + playerHeight
                    if (velocityY >= 0f) {
                        val landing = platforms.indices
                            .filter { index ->
                                index != fromIndex && overlapsX(px, platforms[index]) &&
                                    previousBottom <= platforms[index].y + 12f && nextBottom >= platforms[index].y
                            }
                            .minByOrNull { platforms[it].y }
                        if (landing != null) return landing
                    }
                    py = nextY
                    elapsed += dt
                    if (py > 720f) return null
                }
                return null
            }

            fun platformsNear(x: Float, feetY: Float): List<Int> = platforms.indices.filter { index ->
                val platform = platforms[index]
                x + playerWidth >= platform.x - 12f && x <= platform.x + platform.width + 12f &&
                    abs(platform.y - feetY) <= 28f
            }

            val startIndices = platformsNear(level.spawnX, level.spawnY + playerHeight)
            assertTrue("Nivel ${level.number}: el inicio no está sobre terreno real", startIndices.isNotEmpty())

            val reachable = startIndices.toMutableSet()
            val pending = ArrayDeque<Int>()
            startIndices.forEach(pending::add)
            while (pending.isNotEmpty()) {
                val currentIndex = pending.removeFirst()
                for (direction in listOf(-1, 1)) {
                    secondJumpTimes.forEach { secondJumpAt ->
                        val landing = jumpLanding(currentIndex, direction, secondJumpAt) ?: return@forEach
                        if (landing !in reachable) {
                            reachable += landing
                            pending.add(landing)
                        }
                    }
                }

                val current = platforms[currentIndex]
                level.conduits.filter { !it.arrivalOnly && !it.endsLevel }.forEach { conduit ->
                    val entranceNearCurrent = conduit.x + conduit.width >= current.x - 45f &&
                        conduit.x <= current.x + current.width + 45f &&
                        abs((conduit.y + conduit.height) - current.y) < 170f
                    if (!entranceNearCurrent) return@forEach
                    platformsNear(conduit.targetX, conduit.targetY + playerHeight).forEach { candidate ->
                        if (candidate !in reachable) {
                            reachable += candidate
                            pending.add(candidate)
                        }
                    }
                }
            }

            val goalHasRoute = platforms.indices.any { index ->
                val platform = platforms[index]
                index in reachable && platform.x + platform.width >= level.goalX - 155f &&
                    abs(platform.y - (level.goalY + 135f)) < 300f
            }
            val conduitExitHasRoute = level.conduits.any { exit ->
                exit.endsLevel && platforms.indices.any { index ->
                    val platform = platforms[index]
                    index in reachable && exit.x + exit.width >= platform.x - 45f &&
                        exit.x <= platform.x + platform.width + 45f &&
                        abs((exit.y + exit.height) - platform.y) < 180f
                }
            }
            assertTrue(
                "Nivel ${level.number}: no existe ruta reproducible con las físicas reales de GEO",
                goalHasRoute || conduitExitHasRoute
            )
        }
    }

    @Test
    fun wallsAndRoofsDoNotContainDuplicateNestedSupportGeometry() {
        levels.forEach { level ->
            val structural = level.platforms.filter { it.role == PlatformRole.WALL || it.role == PlatformRole.ROOF }
            structural.forEachIndexed { i, a ->
                structural.drop(i + 1).forEach { b ->
                    if (a.role != b.role || a.kind != b.kind) return@forEach
                    fun contains(outer: GamePlatform, inner: GamePlatform): Boolean =
                        inner.x >= outer.x - 2f && inner.x + inner.width <= outer.x + outer.width + 2f &&
                            inner.y >= outer.y - 2f && inner.y + inner.height <= outer.y + outer.height + 2f
                    assertTrue(
                        "Nivel ${level.number}: muro/techo duplicado o anidado",
                        !contains(a, b) && !contains(b, a)
                    )
                }
            }
        }
    }

    @Test
    fun movingPlatformsKeepTheirRealSizeInAuthoredLevels() {
        levels.forEach { level ->
            level.movingPlatforms.forEach { moving ->
                assertTrue("Nivel ${level.number}: plataforma móvil demasiado pequeña", moving.width >= 110f)
                assertTrue("Nivel ${level.number}: recorrido móvil excesivo", moving.travel <= 105f)
                assertTrue("Nivel ${level.number}: periodo móvil demasiado rápido", moving.periodSeconds >= 2.7f)
            }
        }
    }

    @Test
    fun everyLevelHasAPermanentFallbackRouteWithRealBodyWidthCollisions() {
        levels.forEach { level ->
            // This safety route intentionally ignores moving/switch/falling-object platforms.
            // Troll mechanics may make the faster path dynamic, but a timing miss must not hard-lock a level.
            val platforms = level.platforms
            val playerWidth = 44f
            val playerHeight = 58f
            val horizontalSpeed = 278f + level.number * 3.4f
            val gravity = 1_470f
            val dt = 1f / 120f
            val secondJumpTimes = listOf<Float?>(null, 0.20f, 0.35f, 0.50f, 0.65f, 0.80f, 0.95f)

            fun overlapsX(playerX: Float, platform: GamePlatform): Boolean =
                playerX + playerWidth > platform.x + 2f && playerX < platform.x + platform.width - 2f

            fun jumpLanding(fromIndex: Int, direction: Int, secondJumpAt: Float?): Int? {
                val from = platforms[fromIndex]
                var px = if (direction > 0) from.x + from.width - playerWidth - 2f else from.x + 2f
                var py = from.y - playerHeight
                var velocityY = if (from.kind == PlatformKind.BOUNCE) -810f else -655f
                var elapsed = 0f
                var doubleJumpUsed = false

                repeat(420) {
                    if (secondJumpAt != null && !doubleJumpUsed && elapsed >= secondJumpAt) {
                        velocityY = -535f
                        doubleJumpUsed = true
                    }
                    val previousTop = py
                    val previousBottom = py + playerHeight
                    val candidateX = px + direction * horizontalSpeed * dt
                    if (candidateX < 0f || candidateX > level.width - playerWidth) return null

                    // Mirror runtime horizontal collision. This catches narrow roof/wall chokes that a
                    // simple distance graph can incorrectly treat as passable.
                    val blockedHorizontally = platforms.indices.any { index ->
                        if (index == fromIndex) false else {
                            val platform = platforms[index]
                            candidateX + playerWidth > platform.x && candidateX < platform.x + platform.width &&
                                py + playerHeight > platform.y && py < platform.y + platform.height
                        }
                    }
                    if (!blockedHorizontally) px = candidateX

                    velocityY += gravity * dt
                    var nextY = py + velocityY * dt
                    if (velocityY < 0f) {
                        platforms.forEachIndexed { index, platform ->
                            if (index == fromIndex) return@forEachIndexed
                            val underside = platform.y + platform.height
                            if (overlapsX(px, platform) && previousTop >= underside - 10f && nextY <= underside) {
                                nextY = underside
                                velocityY = 0f
                            }
                        }
                    }

                    val nextBottom = nextY + playerHeight
                    if (velocityY >= 0f) {
                        val landing = platforms.indices
                            .filter { index ->
                                index != fromIndex && overlapsX(px, platforms[index]) &&
                                    previousBottom <= platforms[index].y + 12f && nextBottom >= platforms[index].y
                            }
                            .minByOrNull { platforms[it].y }
                        if (landing != null) return landing
                    }
                    py = nextY
                    elapsed += dt
                    if (py > 720f) return null
                }
                return null
            }

            fun platformsNear(x: Float, feetY: Float): List<Int> = platforms.indices.filter { index ->
                val platform = platforms[index]
                x + playerWidth >= platform.x - 12f && x <= platform.x + platform.width + 12f &&
                    abs(platform.y - feetY) <= 28f
            }

            val startIndices = platformsNear(level.spawnX, level.spawnY + playerHeight)
            assertTrue("Nivel ${level.number}: spawn sin superficie permanente", startIndices.isNotEmpty())
            val reachable = startIndices.toMutableSet()
            val pending = ArrayDeque<Int>()
            startIndices.forEach(pending::add)

            while (pending.isNotEmpty()) {
                val currentIndex = pending.removeFirst()
                val current = platforms[currentIndex]

                // Overlapping/adjacent floor chunks are walkable without forcing a jump.
                platforms.indices.forEach { index ->
                    if (index == currentIndex) return@forEach
                    val other = platforms[index]
                    val horizontalGap = when {
                        current.x + current.width < other.x -> other.x - (current.x + current.width)
                        other.x + other.width < current.x -> current.x - (other.x + other.width)
                        else -> 0f
                    }
                    if (horizontalGap <= 8f && abs(current.y - other.y) <= 12f && index !in reachable) {
                        reachable += index
                        pending.add(index)
                    }
                }

                for (direction in listOf(-1, 1)) {
                    secondJumpTimes.forEach { secondJumpAt ->
                        val landing = jumpLanding(currentIndex, direction, secondJumpAt) ?: return@forEach
                        if (landing !in reachable) {
                            reachable += landing
                            pending.add(landing)
                        }
                    }
                }

                level.conduits.filter { !it.arrivalOnly && !it.endsLevel }.forEach { conduit ->
                    val entranceNearCurrent = conduit.x + conduit.width >= current.x - 45f &&
                        conduit.x <= current.x + current.width + 45f &&
                        abs((conduit.y + conduit.height) - current.y) < 170f
                    if (!entranceNearCurrent) return@forEach
                    platformsNear(conduit.targetX, conduit.targetY + playerHeight).forEach { candidate ->
                        if (candidate !in reachable) {
                            reachable += candidate
                            pending.add(candidate)
                        }
                    }
                }
            }

            val goalHasRoute = platforms.indices.any { index ->
                val platform = platforms[index]
                index in reachable && platform.x + platform.width >= level.goalX - 155f &&
                    abs(platform.y - (level.goalY + 135f)) < 300f
            }
            val conduitExitHasRoute = level.conduits.any { exit ->
                exit.endsLevel && platforms.indices.any { index ->
                    val platform = platforms[index]
                    index in reachable && exit.x + exit.width >= platform.x - 45f &&
                        exit.x <= platform.x + platform.width + 45f &&
                        abs((exit.y + exit.height) - platform.y) < 180f
                }
            }
            assertTrue(
                "Nivel ${level.number}: la ruta permanente queda bloqueada por geometría/hitbox",
                goalHasRoute || conduitExitHasRoute
            )
        }
    }

    @Test
    fun groundEnemiesAlwaysSpawnOnPermanentSupport() {
        levels.forEach { level ->
            level.enemies.forEachIndexed { index, enemy ->
                if (enemy.kind == GameEnemyKind.FLYER) return@forEachIndexed
                val supported = level.platforms.any { platform ->
                    platform.role != PlatformRole.WALL && platform.role != PlatformRole.ROOF &&
                        enemy.x + 46f > platform.x && enemy.x + 4f < platform.x + platform.width &&
                        abs(platform.y - (enemy.y + 55f)) <= 16f
                }
                assertTrue("Nivel ${level.number}: enemigo terrestre $index nace sin piso permanente", supported)
            }
        }
    }

    @Test
    fun groundEnemiesLeaveAStompLandingWindowInsteadOfOverlapping() {
        levels.forEach { level ->
            for (index in level.enemies.indices) {
                val enemy = level.enemies[index]
                if (enemy.kind == GameEnemyKind.FLYER) continue
                for (otherIndex in index + 1 until level.enemies.size) {
                    val other = level.enemies[otherIndex]
                    if (other.kind == GameEnemyKind.FLYER || abs(enemy.y - other.y) >= 65f) continue
                    assertTrue(
                        "Nivel ${level.number}: enemigos terrestres $index/$otherIndex demasiado juntos para un pisoton limpio",
                        abs(enemy.x - other.x) >= 72f
                    )
                }
            }
        }
    }

    @Test
    fun narrowHiddenSpikeLedgesKeepARealLandingZone() {
        levels.forEach { level ->
            level.hazards.forEachIndexed { index, hazard ->
                if (hazard.kind != HazardKind.HIDDEN_SPIKES || hazard.orientation != HazardOrientation.UP) return@forEachIndexed
                val support = level.platforms.firstOrNull { platform ->
                    hazard.x >= platform.x - 8f && hazard.x + hazard.width <= platform.x + platform.width + 8f &&
                        abs(platform.y - (hazard.y + hazard.height)) <= 9f
                } ?: return@forEachIndexed
                if (support.width >= 180f) return@forEachIndexed
                val leftClear = (hazard.x - support.x).coerceAtLeast(0f)
                val rightClear = (support.x + support.width - (hazard.x + hazard.width)).coerceAtLeast(0f)
                assertTrue(
                    "Nivel ${level.number}: pincho oculto $index deja una plataforma casi imposible",
                    maxOf(leftClear, rightClear) >= 62f
                )
            }
        }
    }

    @Test
    fun rocksAndSpikeBallsHaveAConsistentVisibleWarningWindow() {
        levels.forEach { level ->
            level.fallingObjects.forEachIndexed { index, falling ->
                if (falling.kind !in setOf(FallingObjectKind.ROCK, FallingObjectKind.SPIKE_BALL)) return@forEachIndexed
                if (falling.triggerMode == FallingTriggerMode.SWITCH) return@forEachIndexed
                assertTrue(
                    "Nivel ${level.number}: roca/bola $index no deja una advertencia breve y consistente (${falling.delayMs} ms)",
                    falling.delayMs in 260L..320L
                )
            }
        }
    }

    @Test
    fun normalLedgesKeepTouchFriendlyLandingWidth() {
        levels.forEach { level ->
            level.platforms.forEachIndexed { index, platform ->
                if (platform.role != PlatformRole.LEDGE || platform.kind == PlatformKind.REVEALING) return@forEachIndexed
                assertTrue(
                    "Nivel ${level.number}: repisa $index demasiado estrecha para controles táctiles (${platform.width})",
                    platform.width >= 120f
                )
            }
        }
    }

    @Test
    fun fallingCratesLandOnRealAuthoredSupport() {
        levels.forEach { level ->
            level.fallingObjects.forEachIndexed { index, falling ->
                if (falling.kind != FallingObjectKind.CRATE || falling.behavior !in setOf(FallingBehavior.DROP, FallingBehavior.CHAIN)) return@forEachIndexed
                val supports = level.platforms.filter { platform ->
                    platform.role !in setOf(PlatformRole.WALL, PlatformRole.ROOF) &&
                        falling.x + falling.size > platform.x && falling.x < platform.x + platform.width &&
                        abs(platform.y - falling.targetY) <= 12f
                }
                assertTrue(
                    "Nivel ${level.number}: caja que cae $index termina suspendida o sin soporte real",
                    supports.isNotEmpty()
                )
                val bestClearSide = supports.maxOfOrNull { platform ->
                    maxOf(
                        (falling.x - platform.x).coerceAtLeast(0f),
                        (platform.x + platform.width - (falling.x + falling.size)).coerceAtLeast(0f)
                    )
                } ?: 0f
                assertTrue(
                    "Nivel ${level.number}: caja que cae $index tapa casi toda la zona de aterrizaje ($bestClearSide px libres)",
                    bestClearSide >= 70f
                )
            }
        }
    }

    @Test
    fun exitTypesStayVariedAcrossTheAdventure() {
        val exitTypes = levels.map { it.exitKind }.toSet()
        assertTrue(exitTypes.contains(LevelExitKind.ASCENT))
        assertTrue(exitTypes.contains(LevelExitKind.DESCENT))
        assertTrue(exitTypes.contains(LevelExitKind.DOOR))
        assertTrue(exitTypes.contains(LevelExitKind.CAVE))
        assertTrue(exitTypes.contains(LevelExitKind.TUNNEL))
        assertTrue(exitTypes.contains(LevelExitKind.BRIDGE))
        assertTrue(exitTypes.contains(LevelExitKind.LIFT))
        assertTrue(exitTypes.contains(LevelExitKind.RUIN_GATE))
        assertTrue(exitTypes.contains(LevelExitKind.SUMMIT))
    }


    @Test
    fun everyLevelContainsRealFallRiskInsteadOfTinyProtectedGaps() {
        levels.forEach { level ->
            val groundLike = level.platforms
                .filter { it.kind == PlatformKind.SOLID && it.role == PlatformRole.GROUND && it.height >= 60f && it.y >= 250f }
                .sortedBy { it.x }
            val realGaps = groundLike.zipWithNext().map { (a, b) -> b.x - (a.x + a.width) }
                .filter { it >= 135f }
            assertTrue("Nivel ${level.number}: no hay huecos reales con riesgo de caída", realGaps.isNotEmpty())
        }
    }

    @Test
    fun difficultyDoesNotDependMostlyOnSpikes() {
        levels.forEach { level ->
            val totalThreats = level.hazards.size + level.enemies.size + level.fallingObjects.size +
                level.crushers.size + level.chasingHoles.size + level.fans.size + level.plantTraps.size +
                level.launchers.size + level.crates.count { it.payload == CratePayload.EXPLOSION }
            val spikes = level.hazards.count {
                it.kind == HazardKind.SPIKES || it.kind == HazardKind.HIDDEN_SPIKES || it.kind == HazardKind.CEILING_SPIKES
            }
            assertTrue("Nivel ${level.number}: demasiada dependencia de pinchos", totalThreats == 0 || spikes.toFloat() / totalThreats <= 0.30f)
        }
    }

    @Test
    fun everyLevelKeepsTensionAcrossTheWholeRoute() {
        levels.forEach { level ->
            val threatPositions = buildList {
                level.hazards.forEach { add(it.x + it.width / 2f) }
                level.enemies.forEach { add(it.x) }
                level.fallingObjects.forEach { add(it.x + it.size / 2f) }
                level.crushers.forEach { add(it.x + it.width / 2f) }
                level.chasingHoles.forEach { add(it.startX + it.width / 2f) }
                level.fans.forEach { add(it.x + it.width / 2f) }
                level.plantTraps.forEach { add(it.x + it.width / 2f) }
                level.launchers.forEach { add(it.x) }
                level.crates.filter { it.payload == CratePayload.EXPLOSION }.forEach { add(it.x + 27f) }
            }.sorted()
            assertTrue("Nivel ${level.number}: faltan amenazas", threatPositions.size >= 30)
            val structureCount = level.platforms.count { it.height >= 90f }
            assertTrue("Nivel ${level.number}: el recorrido sigue demasiado abierto", structureCount >= 5)
        }
    }


    @Test
    fun conduitsPlantsAndNewTrollFamiliesAreActuallyPresent() {
        val allConduits = levels.flatMap { it.conduits }
        val allPlants = levels.flatMap { it.plantTraps }
        val allFalling = levels.flatMap { it.fallingObjects }
        val allPlatforms = levels.flatMap { it.platforms }
        val allCrushers = levels.flatMap { it.crushers }

        assertTrue("Deben existir conductos internos entre zonas", allConduits.any { !it.arrivalOnly && !it.endsLevel })
        assertTrue("Deben existir conductos que conecten niveles", allConduits.any { it.endsLevel })
        assertTrue("Deben existir plantas trampa retráctiles", allPlants.isNotEmpty())
        assertTrue("Debe existir al menos una planta agresiva por proximidad", allPlants.any { it.proximityAggressive })
        assertTrue("Deben existir rocas perseguidoras limitadas", allFalling.any { it.kind == FallingObjectKind.ROCK && it.behavior == FallingBehavior.CHASE })
        assertTrue("Deben existir pisos que se hunden por proximidad", allPlatforms.any { it.kind == PlatformKind.PROXIMITY_DISAPPEARING })
        assertTrue("Deben existir puentes o plataformas que caen", allPlatforms.any { it.kind == PlatformKind.FALLING })
        assertTrue("Deben existir caminos que se revelan tras mecanismos", allPlatforms.any { it.kind == PlatformKind.REVEALING })
        assertTrue("Deben existir plataformas de rebote", allPlatforms.any { it.kind == PlatformKind.BOUNCE })
        assertTrue("Deben existir troncos/prensas integradas", allCrushers.any { it.style == CrusherStyle.LOG_PRESS })
        assertTrue("Deben existir muros o bloques de ruina temporales", allCrushers.any { it.style == CrusherStyle.FALLING_WALL || it.style == CrusherStyle.RUIN_BLOCK })
        assertTrue("Algunos enemigos deben activar mecanismos al ser derrotados", levels.flatMap { it.enemies }.any { it.onDefeatSwitchIndex != null })
    }

    @Test
    fun lethalThreatsDoNotAdvertiseThemselvesBeforeGeoCommits() {
        levels.forEach { level ->
            assertTrue("Nivel ${level.number}: quedó un peligro de pinchos/fuego visible desde lejos", level.hazards.all {
                it.kind == HazardKind.HIDDEN_SPIKES && it.camouflaged
            })
            assertTrue("Nivel ${level.number}: quedó un enemigo visible antes del trigger", level.enemies.all {
                it.hiddenUntilActivated && it.activationTriggerX != null
            })
            assertTrue("Nivel ${level.number}: quedó un lanzador visible antes del trigger", level.launchers.all {
                it.hiddenUntilTriggered
            })
        }
    }

    @Test
    fun noLevelHasALongQuietStretchBetweenTrollEvents() {
        levels.forEach { level ->
            val anchors = buildList {
                add(80f)
                add(level.goalX)
                level.checkpoints.filter { it.kind != CheckpointKind.DECOY }.forEach { add(it.x) }
                level.hazards.forEach { add(it.triggerX) }
                level.enemies.mapNotNullTo(this) { it.activationTriggerX }
                level.fallingObjects.forEach { add(it.triggerX) }
                level.chasingHoles.forEach { add(it.triggerX) }
                level.crushers.forEach { add(it.triggerX) }
                level.launchers.forEach { add(it.triggerX) }
                level.plantTraps.forEach { add(it.x - minOf(it.detectionRange, 190f)) }
                level.platforms.filter {
                    it.kind == PlatformKind.FALLING || it.kind == PlatformKind.PROXIMITY_DISAPPEARING || it.kind == PlatformKind.REVEALING
                }.forEach { add(it.triggerX) }
            }.filter { it in 0f..level.goalX }.sorted()
            val maxGap = anchors.zipWithNext().maxOfOrNull { (a, b) -> b - a } ?: 0f
            assertTrue("Nivel ${level.number}: tramo demasiado tranquilo de $maxGap px", maxGap <= 1_060f)
        }
    }

    @Test
    fun catMarioReferenceMechanicsAreRealAndDistributedAcrossAllLevels() {
        levels.forEach { level ->
            assertTrue("Nivel ${level.number}: falta un bloque sorpresa activado por salto", level.platforms.any {
                it.kind == PlatformKind.REVEALING && it.revealMode == PlatformRevealMode.JUMP_NEAR
            })
            assertTrue("Nivel ${level.number}: falta una emboscada por trigger", level.enemies.any {
                it.hiddenUntilActivated && it.activationTriggerX != null
            })
            assertTrue("Nivel ${level.number}: faltan proyectiles por proximidad", level.launchers.isNotEmpty())
        }

        val payloads = levels.flatMap { it.crates }.map { it.payload }.toSet()
        assertEquals(
            setOf(CratePayload.LIFE, CratePayload.SHIELD, CratePayload.POWER, CratePayload.EXPLOSION, CratePayload.SWITCH, CratePayload.EMPTY),
            payloads
        )
        assertTrue("Los lanzadores deben atacar desde ambos lados", levels.flatMap { it.launchers }.map { it.direction }.toSet().containsAll(
            setOf(LauncherDirection.LEFT, LauncherDirection.RIGHT)
        ))
        assertTrue("Las plataformas reveladas deben depender de varias reacciones del jugador", levels.flatMap { it.platforms }
            .filter { it.kind == PlatformKind.REVEALING }.map { it.revealMode }.toSet().size >= 3)
        assertTrue("Toda plataforma revelada por interruptor debe apuntar al interruptor correcto", levels.flatMap { it.platforms }.all {
            it.kind != PlatformKind.REVEALING || it.revealMode != PlatformRevealMode.SWITCH || it.triggerSwitchIndex != null
        })
    }

    @Test
    fun everyLevelStillUsesExactlyFifteenInternalLives() {
        levels.forEach { level ->
            assertEquals(15, GeoGameRules.attemptsForLevel(level.number))
        }
    }
}
