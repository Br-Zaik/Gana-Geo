-- Gana Geo v0.10.28
-- Geo Aventuras multiplayer ONLINE. Esta migracion es aditiva y NO reemplaza
-- Google OAuth, sesiones, creditos, Rewards, referidos ni retiros.
-- Ejecutar despues de las migraciones 01..07 existentes.

begin;

create table if not exists public.geo_mp_profiles (
    user_id uuid primary key references auth.users(id) on delete cascade,
    public_id text not null unique,
    display_name text not null default 'GEO',
    skin_code text not null default 'green',
    updated_at timestamptz not null default now()
);

create table if not exists public.geo_mp_cosmetics (
    user_id uuid not null references auth.users(id) on delete cascade,
    skin_code text not null,
    granted_at timestamptz not null default now(),
    primary key (user_id, skin_code)
);

create table if not exists public.geo_mp_level_unlocks (
    user_id uuid not null references auth.users(id) on delete cascade,
    level_no integer not null check (level_no between 1 and 20),
    unlocked_at timestamptz not null default now(),
    source text not null default 'multiplayer',
    primary key (user_id, level_no)
);

create table if not exists public.geo_mp_rooms (
    id uuid primary key default gen_random_uuid(),
    room_code text not null unique,
    host_id uuid not null references auth.users(id) on delete cascade,
    selected_level integer not null default 1 check (selected_level between 1 and 20),
    status text not null default 'lobby' check (status in ('lobby','playing','finished')),
    match_no bigint not null default 0,
    winner_id uuid references auth.users(id) on delete set null,
    result text check (result is null or result in ('won','lost')),
    started_at timestamptz,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists public.geo_mp_room_members (
    room_id uuid not null references public.geo_mp_rooms(id) on delete cascade,
    user_id uuid not null references auth.users(id) on delete cascade,
    skin_code text not null default 'green',
    is_ready boolean not null default false,
    lives integer not null default 15 check (lives between 0 and 15),
    is_eliminated boolean not null default false,
    is_spectator boolean not null default false,
    x real not null default 0,
    y real not null default 0,
    velocity_x real not null default 0,
    velocity_y real not null default 0,
    checkpoint integer not null default -1,
    world_state text not null default '',
    seq bigint not null default 0,
    joined_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    primary key (room_id, user_id)
);

create table if not exists public.geo_mp_friends (
    user_id uuid not null references auth.users(id) on delete cascade,
    friend_id uuid not null references auth.users(id) on delete cascade,
    created_at timestamptz not null default now(),
    primary key (user_id, friend_id),
    check (user_id <> friend_id)
);

create table if not exists public.geo_mp_invites (
    id uuid primary key default gen_random_uuid(),
    room_id uuid not null references public.geo_mp_rooms(id) on delete cascade,
    from_user_id uuid not null references auth.users(id) on delete cascade,
    to_user_id uuid not null references auth.users(id) on delete cascade,
    status text not null default 'pending' check (status in ('pending','accepted','declined','expired')),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

alter table public.geo_mp_room_members add column if not exists world_state text not null default '';
create index if not exists geo_mp_invites_target_idx on public.geo_mp_invites(to_user_id, status, created_at desc);
create index if not exists geo_mp_members_room_idx on public.geo_mp_room_members(room_id, updated_at desc);

alter table public.geo_mp_profiles enable row level security;
alter table public.geo_mp_cosmetics enable row level security;
alter table public.geo_mp_level_unlocks enable row level security;
alter table public.geo_mp_rooms enable row level security;
alter table public.geo_mp_room_members enable row level security;
alter table public.geo_mp_invites enable row level security;
alter table public.geo_mp_friends enable row level security;

-- Todo el acceso pasa por RPC security-definer. No se expone acceso directo a tablas.
revoke all on public.geo_mp_profiles from anon, authenticated;
revoke all on public.geo_mp_cosmetics from anon, authenticated;
revoke all on public.geo_mp_level_unlocks from anon, authenticated;
revoke all on public.geo_mp_rooms from anon, authenticated;
revoke all on public.geo_mp_room_members from anon, authenticated;
revoke all on public.geo_mp_invites from anon, authenticated;
revoke all on public.geo_mp_friends from anon, authenticated;

create or replace function public.geo_mp_skin_allowed(p_user_id uuid, p_skin text)
returns boolean
language sql security definer set search_path = ''
as $$
    select lower(coalesce(p_skin,'')) in ('green','blue','red','purple','cyan','orange')
        or exists (
            select 1 from public.geo_mp_cosmetics c
             where c.user_id=p_user_id and c.skin_code=lower(p_skin)
        );
$$;

create or replace function public.geo_mp_level_allowed(p_user_id uuid, p_level integer)
returns boolean
language sql security definer set search_path = ''
as $$
    select p_level between 1 and 20 and (
        p_level <= coalesce((select a.unlocked_level from public.geo_game_accounts a where a.user_id=p_user_id),1)
        or exists(select 1 from public.geo_mp_level_unlocks u where u.user_id=p_user_id and u.level_no=p_level)
    );
$$;

create or replace function public.geo_mp_register_profile(p_skin_code text default 'green')
returns table(player_id uuid, public_id text, display_name text, skin_code text)
language plpgsql security definer set search_path = ''
as $$
declare
    v_uid uuid:=auth.uid();
    v_name text;
    v_public text;
    v_skin text:=lower(coalesce(p_skin_code,'green'));
begin
    if v_uid is null then raise exception 'Authentication required'; end if;
    if not public.geo_mp_skin_allowed(v_uid,v_skin) then v_skin:='green'; end if;
    -- Reutiliza el Geo ID permanente que Gana Geo ya asigna a cada cuenta.
    -- No crea un segundo identificador ni modifica el sistema de login.
    select pr.geo_id::text,
           coalesce(
               nullif(trim(pr.display_name),''),
               nullif(trim(u.raw_user_meta_data ->> 'full_name'),''),
               nullif(trim(u.raw_user_meta_data ->> 'name'),''),
               nullif(split_part(u.email,'@',1),''),
               'GEO'
           )
      into v_public,v_name
      from public.profiles pr
      join auth.users u on u.id=pr.user_id
     where pr.user_id=v_uid;
    if v_public is null then raise exception 'Gana Geo profile not available'; end if;
    insert into public.geo_mp_profiles(user_id,public_id,display_name,skin_code,updated_at)
    values(v_uid,v_public,left(v_name,24),v_skin,now())
    on conflict(user_id) do update set public_id=excluded.public_id,display_name=excluded.display_name,skin_code=excluded.skin_code,updated_at=now();
    return query select p.user_id,p.public_id,p.display_name,p.skin_code from public.geo_mp_profiles p where p.user_id=v_uid;
end;
$$;

create or replace function public.geo_mp_my_unlocks()
returns table(level_no integer)
language sql security definer set search_path = ''
as $$
    with me as (select auth.uid() uid),
    base as (
        select generate_series(1,greatest(1,least(20,coalesce(a.unlocked_level,1))))::integer level_no
          from me left join public.geo_game_accounts a on a.user_id=me.uid
    ), sparse as (
        select u.level_no from public.geo_mp_level_unlocks u,me where u.user_id=me.uid
    )
    select distinct x.level_no from (select * from base union all select * from sparse) x order by x.level_no;
$$;

create or replace function public.geo_mp_my_cosmetics()
returns table(skin_code text)
language sql security definer set search_path = ''
as $$
    select c.skin_code from public.geo_mp_cosmetics c where c.user_id=auth.uid() order by c.skin_code;
$$;

-- El modo LAN funciona sin Internet. Cuando una cuenta vuelve a tener conexion,
-- el cliente sincroniza aqui los niveles exactos que completo localmente.
-- Este desbloqueo solo afecta progreso de Geo Aventuras; no otorga creditos ni Rewards.
create or replace function public.geo_mp_claim_local_unlock(p_level integer)
returns void
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid();
begin
    if v_uid is null then raise exception 'Authentication required'; end if;
    if p_level not between 1 and 20 then raise exception 'Invalid level'; end if;
    insert into public.geo_mp_level_unlocks(user_id,level_no,source)
    values(v_uid,p_level,'local_multiplayer')
    on conflict(user_id,level_no) do nothing;
end;
$$;

create or replace function public.geo_mp_find_player(p_public_id text)
returns table(player_id uuid, public_id text, display_name text, skin_code text)
language sql security definer set search_path = ''
as $$
    select pr.user_id,
           pr.geo_id::text,
           coalesce(
               nullif(trim(pr.display_name),''),
               nullif(trim(u.raw_user_meta_data ->> 'full_name'),''),
               nullif(trim(u.raw_user_meta_data ->> 'name'),''),
               nullif(split_part(u.email,'@',1),''),
               'GEO'
           ),
           coalesce(mp.skin_code,'green')
      from public.profiles pr
      join auth.users u on u.id=pr.user_id
      left join public.geo_mp_profiles mp on mp.user_id=pr.user_id
     where pr.geo_id::text=trim(p_public_id) and pr.user_id<>auth.uid()
     limit 1;
$$;

create or replace function public.geo_mp_add_friend(p_public_id text)
returns table(player_id uuid, public_id text, display_name text, skin_code text)
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid(); v_friend uuid;
begin
    if v_uid is null then raise exception 'Authentication required'; end if;
    select p.user_id into v_friend from public.profiles p where p.geo_id::text=trim(p_public_id);
    if v_friend is null or v_friend=v_uid then raise exception 'Player not found'; end if;
    insert into public.geo_mp_profiles(user_id,public_id,display_name,skin_code,updated_at)
    select pr.user_id,pr.geo_id::text,
           left(coalesce(nullif(trim(pr.display_name),''),nullif(split_part(u.email,'@',1),''),'GEO'),24),
           'green',now()
      from public.profiles pr join auth.users u on u.id=pr.user_id where pr.user_id=v_friend
    on conflict(user_id) do nothing;
    insert into public.geo_mp_friends(user_id,friend_id) values(v_uid,v_friend) on conflict do nothing;
    return query select p.user_id,p.public_id,p.display_name,p.skin_code from public.geo_mp_profiles p where p.user_id=v_friend;
end;
$$;

create or replace function public.geo_mp_list_friends()
returns table(player_id uuid, public_id text, display_name text, skin_code text)
language sql security definer set search_path = ''
as $$
    select p.user_id,p.public_id,p.display_name,p.skin_code
      from public.geo_mp_friends f join public.geo_mp_profiles p on p.user_id=f.friend_id
     where f.user_id=auth.uid() order by p.display_name,p.public_id limit 100;
$$;

create or replace function public.geo_mp_create_room(p_level integer,p_skin_code text)
returns table(room_id uuid, room_code text, host_id uuid, selected_level integer, status text, match_no bigint, started_at_ms bigint, updated_at_ms bigint)
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid(); v_room uuid:=gen_random_uuid(); v_code text; v_skin text:=lower(coalesce(p_skin_code,'green'));
begin
    if v_uid is null then raise exception 'Authentication required'; end if;
    perform public.geo_mp_register_profile(v_skin);
    if not public.geo_mp_level_allowed(v_uid,p_level) then raise exception 'Level is locked for host'; end if;
    if not public.geo_mp_skin_allowed(v_uid,v_skin) then raise exception 'Skin is locked'; end if;
    delete from public.geo_mp_rooms where host_id=v_uid;
    delete from public.geo_mp_room_members where user_id=v_uid;
    v_code:=upper(substr(replace(v_room::text,'-',''),1,6));
    insert into public.geo_mp_rooms(id,room_code,host_id,selected_level) values(v_room,v_code,v_uid,p_level);
    insert into public.geo_mp_room_members(room_id,user_id,skin_code,is_ready) values(v_room,v_uid,v_skin,true);
    return query select r.id,r.room_code,r.host_id,r.selected_level,r.status,r.match_no,
        coalesce((extract(epoch from r.started_at)*1000)::bigint,0),(extract(epoch from r.updated_at)*1000)::bigint
      from public.geo_mp_rooms r where r.id=v_room;
end;
$$;

create or replace function public.geo_mp_invite_player(p_room_id uuid,p_public_id text)
returns table(invite_id uuid)
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid(); v_target uuid; v_inv uuid;
begin
    if not exists(select 1 from public.geo_mp_rooms r where r.id=p_room_id and r.host_id=v_uid and r.status='lobby') then raise exception 'Only host can invite'; end if;
    select p.user_id into v_target from public.profiles p where p.geo_id::text=trim(p_public_id);
    if v_target is null or v_target=v_uid then raise exception 'Player not found'; end if;
    insert into public.geo_mp_profiles(user_id,public_id,display_name,skin_code,updated_at)
    select pr.user_id,pr.geo_id::text,
           left(coalesce(nullif(trim(pr.display_name),''),nullif(split_part(u.email,'@',1),''),'GEO'),24),
           'green',now()
      from public.profiles pr join auth.users u on u.id=pr.user_id where pr.user_id=v_target
    on conflict(user_id) do nothing;
    if exists(select 1 from public.geo_mp_room_members m where m.room_id=p_room_id and m.user_id=v_target) then raise exception 'Player already in room'; end if;
    update public.geo_mp_invites set status='expired',updated_at=now() where to_user_id=v_target and status='pending' and room_id=p_room_id;
    insert into public.geo_mp_invites(room_id,from_user_id,to_user_id) values(p_room_id,v_uid,v_target) returning id into v_inv;
    return query select v_inv;
end;
$$;

create or replace function public.geo_mp_list_invites()
returns table(invite_id uuid, room_id uuid, from_public_id text, from_name text, created_at_ms bigint)
language sql security definer set search_path = ''
as $$
    select i.id,i.room_id,p.public_id,p.display_name,(extract(epoch from i.created_at)*1000)::bigint
      from public.geo_mp_invites i
      join public.geo_mp_profiles p on p.user_id=i.from_user_id
      join public.geo_mp_rooms r on r.id=i.room_id
     where i.to_user_id=auth.uid() and i.status='pending' and r.status='lobby'
       and i.created_at>now()-interval '30 minutes'
     order by i.created_at desc limit 10;
$$;

create or replace function public.geo_mp_join_room(p_room_id uuid,p_skin_code text)
returns void
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid(); v_skin text:=lower(coalesce(p_skin_code,'green')); v_count integer;
begin
    if v_uid is null then raise exception 'Authentication required'; end if;
    perform public.geo_mp_register_profile(v_skin);
    if not public.geo_mp_skin_allowed(v_uid,v_skin) then raise exception 'Skin is locked'; end if;
    if not exists(select 1 from public.geo_mp_rooms r where r.id=p_room_id and r.status='lobby') then raise exception 'Room is not available'; end if;
    select count(*) into v_count from public.geo_mp_room_members where room_id=p_room_id;
    if v_count>=3 and not exists(select 1 from public.geo_mp_room_members where room_id=p_room_id and user_id=v_uid) then raise exception 'Room is full'; end if;
    delete from public.geo_mp_rooms where host_id=v_uid and id<>p_room_id;
    delete from public.geo_mp_room_members where user_id=v_uid and room_id<>p_room_id;
    insert into public.geo_mp_room_members(room_id,user_id,skin_code,is_ready) values(p_room_id,v_uid,v_skin,false)
    on conflict(room_id,user_id) do update set skin_code=excluded.skin_code,updated_at=now();
    update public.geo_mp_invites set status='accepted',updated_at=now() where to_user_id=v_uid and room_id=p_room_id and status='pending';
end;
$$;

create or replace function public.geo_mp_accept_invite(p_invite_id uuid,p_skin_code text)
returns table(room_id uuid)
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid(); v_room uuid;
begin
    select i.room_id into v_room from public.geo_mp_invites i where i.id=p_invite_id and i.to_user_id=v_uid and i.status='pending';
    if v_room is null then raise exception 'Invitation not available'; end if;
    perform public.geo_mp_join_room(v_room,p_skin_code);
    return query select v_room;
end;
$$;

create or replace function public.geo_mp_room_state(p_room_id uuid)
returns table(
    room_id uuid, room_code text, host_id uuid, selected_level integer, status text, match_no bigint,
    winner_id uuid, result text, started_at_ms bigint, room_updated_at_ms bigint,
    player_id uuid, public_id text, display_name text, skin_code text, is_host boolean, is_ready boolean,
    lives integer, is_eliminated boolean, is_spectator boolean, x real, y real, velocity_x real, velocity_y real,
    checkpoint integer, world_state text, seq bigint, player_updated_at_ms bigint
)
language plpgsql security definer set search_path = ''
as $$
begin
    if not exists(select 1 from public.geo_mp_room_members m where m.room_id=p_room_id and m.user_id=auth.uid()) then raise exception 'Not a room member'; end if;

    update public.geo_mp_room_members set updated_at=now() where room_id=p_room_id and user_id=auth.uid();

    -- Si un telefono desaparece durante partida, no deja atrapados a los demas.
    update public.geo_mp_room_members m
       set lives=0,is_eliminated=true,is_spectator=true,updated_at=now()
     where m.room_id=p_room_id and m.user_id<>auth.uid()
       and m.updated_at<now()-interval '12 seconds'
       and exists(select 1 from public.geo_mp_rooms r where r.id=p_room_id and r.status='playing');

    delete from public.geo_mp_room_members m
     where m.room_id=p_room_id and m.user_id<>auth.uid()
       and m.user_id<>(select r.host_id from public.geo_mp_rooms r where r.id=p_room_id)
       and m.updated_at<now()-interval '90 seconds'
       and exists(select 1 from public.geo_mp_rooms r where r.id=p_room_id and r.status='lobby');

    -- Si desaparece el host, migra el host a un miembro activo. Subconsulta correlacionada
    -- para evitar referencias laterales invalidas al target de UPDATE.
    update public.geo_mp_rooms r
       set host_id=(
           select m.user_id from public.geo_mp_room_members m
            where m.room_id=r.id and m.user_id<>r.host_id and m.updated_at>=now()-interval '12 seconds'
            order by m.joined_at limit 1
       ), updated_at=now()
     where r.id=p_room_id
       and exists(select 1 from public.geo_mp_room_members old_host where old_host.room_id=r.id and old_host.user_id=r.host_id and old_host.updated_at<now()-interval '12 seconds')
       and exists(select 1 from public.geo_mp_room_members candidate where candidate.room_id=r.id and candidate.user_id<>r.host_id and candidate.updated_at>=now()-interval '12 seconds');

    return query
    select r.id,r.room_code,r.host_id,r.selected_level,r.status,r.match_no,r.winner_id,r.result,
           coalesce((extract(epoch from r.started_at)*1000)::bigint,0),(extract(epoch from r.updated_at)*1000)::bigint,
           m.user_id,p.public_id,p.display_name,m.skin_code,(m.user_id=r.host_id),m.is_ready,m.lives,m.is_eliminated,m.is_spectator,
           m.x,m.y,m.velocity_x,m.velocity_y,m.checkpoint,m.world_state,m.seq,(extract(epoch from m.updated_at)*1000)::bigint
      from public.geo_mp_rooms r
      join public.geo_mp_room_members m on m.room_id=r.id
      join public.geo_mp_profiles p on p.user_id=m.user_id
     where r.id=p_room_id order by (m.user_id=r.host_id) desc,m.joined_at;
end;
$$;

create or replace function public.geo_mp_set_ready(p_room_id uuid,p_ready boolean,p_skin_code text)
returns void
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid(); v_skin text:=lower(coalesce(p_skin_code,'green'));
begin
    if not public.geo_mp_skin_allowed(v_uid,v_skin) then raise exception 'Skin is locked'; end if;
    update public.geo_mp_room_members set is_ready=p_ready,skin_code=v_skin,updated_at=now() where room_id=p_room_id and user_id=v_uid;
    if not found then raise exception 'Not a room member'; end if;
end;
$$;

create or replace function public.geo_mp_set_level(p_room_id uuid,p_level integer)
returns void
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid();
begin
    if not public.geo_mp_level_allowed(v_uid,p_level) then raise exception 'Level is locked for host'; end if;
    update public.geo_mp_rooms set selected_level=p_level,updated_at=now() where id=p_room_id and host_id=v_uid and status='lobby';
    if not found then raise exception 'Only host can select the level'; end if;
end;
$$;

create or replace function public.geo_mp_start_match(p_room_id uuid)
returns void
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid(); v_count integer; v_unready integer;
begin
    if not exists(select 1 from public.geo_mp_rooms r where r.id=p_room_id and r.host_id=v_uid and r.status='lobby') then raise exception 'Only host can start'; end if;
    select count(*) into v_count from public.geo_mp_room_members where room_id=p_room_id;
    if v_count<2 or v_count>3 then raise exception 'Between 2 and 3 players are required'; end if;
    select count(*) into v_unready from public.geo_mp_room_members where room_id=p_room_id and user_id<>v_uid and not is_ready;
    if v_unready>0 then raise exception 'All invited players must be ready'; end if;
    update public.geo_mp_rooms set status='playing',match_no=match_no+1,winner_id=null,result=null,started_at=now(),updated_at=now() where id=p_room_id;
    update public.geo_mp_room_members set lives=15,is_eliminated=false,is_spectator=false,x=0,y=0,velocity_x=0,velocity_y=0,checkpoint=-1,world_state='',seq=0,updated_at=now() where room_id=p_room_id;
end;
$$;

create or replace function public.geo_mp_update_player(
    p_room_id uuid,p_x real,p_y real,p_vx real,p_vy real,p_lives integer,p_checkpoint integer,p_world_state text,p_seq bigint
)
returns void
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid(); v_lives integer:=greatest(0,least(15,coalesce(p_lives,0)));
begin
    if not exists(select 1 from public.geo_mp_rooms r where r.id=p_room_id and r.status='playing') then return; end if;
    update public.geo_mp_room_members
       set x=p_x,y=p_y,velocity_x=p_vx,velocity_y=p_vy,lives=v_lives,checkpoint=p_checkpoint,
           world_state=left(coalesce(p_world_state,''),4096),seq=greatest(seq,p_seq),
           is_eliminated=(v_lives<=0),is_spectator=(v_lives<=0),updated_at=now()
     where room_id=p_room_id and user_id=v_uid and p_seq>=seq;
end;
$$;

create or replace function public.geo_mp_finish_match(p_room_id uuid,p_result text,p_winner_id uuid default null)
returns void
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid(); v_level integer; v_host uuid;
begin
    if p_result not in ('won','lost') then raise exception 'Invalid result'; end if;
    select selected_level,host_id into v_level,v_host from public.geo_mp_rooms where id=p_room_id and status='playing' for update;
    if v_level is null then return; end if;
    if not exists(select 1 from public.geo_mp_room_members where room_id=p_room_id and user_id=v_uid) then raise exception 'Not a member'; end if;
    if p_result='won' then
        -- El dispositivo que llega a la salida solo puede declararse ganador a si mismo.
        if p_winner_id is null or p_winner_id<>v_uid then raise exception 'Invalid winner'; end if;
        insert into public.geo_mp_level_unlocks(user_id,level_no,source)
        select m.user_id,v_level,'multiplayer' from public.geo_mp_room_members m where m.room_id=p_room_id
        on conflict(user_id,level_no) do nothing;
    else
        if v_uid<>v_host then raise exception 'Only host can finalize a loss'; end if;
        if exists(select 1 from public.geo_mp_room_members m where m.room_id=p_room_id and m.lives>0 and not m.is_eliminated) then
            raise exception 'There are still active players';
        end if;
    end if;
    update public.geo_mp_rooms set status='finished',winner_id=p_winner_id,result=p_result,updated_at=now() where id=p_room_id;
end;
$$;

create or replace function public.geo_mp_reset_lobby(p_room_id uuid)
returns void
language plpgsql security definer set search_path = ''
as $$
begin
    update public.geo_mp_rooms set status='lobby',winner_id=null,result=null,started_at=null,updated_at=now()
     where id=p_room_id and host_id=auth.uid() and status='finished';
    if found then
        update public.geo_mp_room_members set is_ready=(user_id=auth.uid()),lives=15,is_eliminated=false,is_spectator=false,x=0,y=0,velocity_x=0,velocity_y=0,checkpoint=-1,world_state='',seq=0,updated_at=now()
         where room_id=p_room_id;
    end if;
end;
$$;

create or replace function public.geo_mp_leave_room(p_room_id uuid)
returns void
language plpgsql security definer set search_path = ''
as $$
declare v_uid uuid:=auth.uid(); v_was_host boolean; v_new_host uuid;
begin
    select exists(select 1 from public.geo_mp_rooms where id=p_room_id and host_id=v_uid) into v_was_host;
    delete from public.geo_mp_room_members where room_id=p_room_id and user_id=v_uid;
    if v_was_host then
        select user_id into v_new_host from public.geo_mp_room_members where room_id=p_room_id order by joined_at limit 1;
        if v_new_host is null then
            delete from public.geo_mp_rooms where id=p_room_id;
        else
            update public.geo_mp_rooms set host_id=v_new_host,status='lobby',updated_at=now() where id=p_room_id;
            update public.geo_mp_room_members set is_ready=(user_id=v_new_host) where room_id=p_room_id;
        end if;
    end if;
end;
$$;

revoke execute on function public.geo_mp_skin_allowed(uuid,text) from public,anon;
revoke execute on function public.geo_mp_level_allowed(uuid,integer) from public,anon;
revoke execute on function public.geo_mp_register_profile(text) from public,anon;
revoke execute on function public.geo_mp_my_unlocks() from public,anon;
revoke execute on function public.geo_mp_my_cosmetics() from public,anon;
revoke execute on function public.geo_mp_claim_local_unlock(integer) from public,anon;
revoke execute on function public.geo_mp_find_player(text) from public,anon;
revoke execute on function public.geo_mp_add_friend(text) from public,anon;
revoke execute on function public.geo_mp_list_friends() from public,anon;
revoke execute on function public.geo_mp_create_room(integer,text) from public,anon;
revoke execute on function public.geo_mp_invite_player(uuid,text) from public,anon;
revoke execute on function public.geo_mp_list_invites() from public,anon;
revoke execute on function public.geo_mp_join_room(uuid,text) from public,anon;
revoke execute on function public.geo_mp_accept_invite(uuid,text) from public,anon;
revoke execute on function public.geo_mp_room_state(uuid) from public,anon;
revoke execute on function public.geo_mp_set_ready(uuid,boolean,text) from public,anon;
revoke execute on function public.geo_mp_set_level(uuid,integer) from public,anon;
revoke execute on function public.geo_mp_start_match(uuid) from public,anon;
revoke execute on function public.geo_mp_update_player(uuid,real,real,real,real,integer,integer,text,bigint) from public,anon;
revoke execute on function public.geo_mp_finish_match(uuid,text,uuid) from public,anon;
revoke execute on function public.geo_mp_reset_lobby(uuid) from public,anon;
revoke execute on function public.geo_mp_leave_room(uuid) from public,anon;

grant execute on function public.geo_mp_skin_allowed(uuid,text) to authenticated;
grant execute on function public.geo_mp_level_allowed(uuid,integer) to authenticated;
grant execute on function public.geo_mp_register_profile(text) to authenticated;
grant execute on function public.geo_mp_my_unlocks() to authenticated;
grant execute on function public.geo_mp_my_cosmetics() to authenticated;
grant execute on function public.geo_mp_claim_local_unlock(integer) to authenticated;
grant execute on function public.geo_mp_find_player(text) to authenticated;
grant execute on function public.geo_mp_add_friend(text) to authenticated;
grant execute on function public.geo_mp_list_friends() to authenticated;
grant execute on function public.geo_mp_create_room(integer,text) to authenticated;
grant execute on function public.geo_mp_invite_player(uuid,text) to authenticated;
grant execute on function public.geo_mp_list_invites() to authenticated;
grant execute on function public.geo_mp_join_room(uuid,text) to authenticated;
grant execute on function public.geo_mp_accept_invite(uuid,text) to authenticated;
grant execute on function public.geo_mp_room_state(uuid) to authenticated;
grant execute on function public.geo_mp_set_ready(uuid,boolean,text) to authenticated;
grant execute on function public.geo_mp_set_level(uuid,integer) to authenticated;
grant execute on function public.geo_mp_start_match(uuid) to authenticated;
grant execute on function public.geo_mp_update_player(uuid,real,real,real,real,integer,integer,text,bigint) to authenticated;
grant execute on function public.geo_mp_finish_match(uuid,text,uuid) to authenticated;
grant execute on function public.geo_mp_reset_lobby(uuid) to authenticated;
grant execute on function public.geo_mp_leave_room(uuid) to authenticated;

commit;
