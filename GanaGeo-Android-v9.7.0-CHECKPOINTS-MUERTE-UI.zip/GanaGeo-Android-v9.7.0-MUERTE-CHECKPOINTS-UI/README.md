# Gana Geo Android v9.7 — Checkpoints seguros, muerte visible y UI de invitado corregida

Versión basada en v0.9.6. Mantiene intactos el acceso con Google, Supabase, créditos, Geo Rewards, referidos, retiros y el resto de herramientas.

## Cambios principales

- La primera apertura continúa entrando directamente como invitado.
- El encabezado de invitado respeta la barra de estado, la cámara y el notch del teléfono.
- Barra de estado y navegación con fondo verde oscuro coherente con la app.
- Herramientas gratuitas mostradas primero; herramientas de pago después, visibles con candado.
- Se eliminó la repetición de “Inicia sesión” dentro de cada tarjeta bloqueada.
- El contador de próxima vida roja se actualiza cada segundo y usa el tiempo persistente guardado.
- Cada partida mantiene 15 vidas internas.
- Al morir, la escena permanece visible 1.25 segundos, sin mensajes que expliquen la causa.
- Los checkpoints reales reciben plataforma sólida permanente y una zona de seguridad.
- Los checkpoints falsos conservan el comportamiento de troleo.
- Los niveles 1–4 conservan dificultad extrema, pero se reservan zonas reales de aterrizaje y rutas estáticas sin huecos imposibles.
- Al reaparecer, GEO queda correctamente apoyado sobre la plataforma del último checkpoint real.

## Compilación

GitHub Actions ejecuta pruebas unitarias y genera `app-debug.apk`. Deben existir los secretos `SUPABASE_ANON_KEY` y `GOOGLE_WEB_CLIENT_ID`.
