package com.ganageo.app.tools

import kotlin.math.abs

enum class PlatformKind { SOLID, FALLING, DISAPPEARING, PROXIMITY_DISAPPEARING, REVEALING, BOUNCE }
enum class HazardKind { SPIKES, HIDDEN_SPIKES, SAW, FIRE, CEILING_SPIKES }
enum class HazardOrientation { UP, DOWN, LEFT, RIGHT }
enum class CheckpointKind { SAFE, POPUP, DECOY }
enum class FallingObjectKind { ROCK, FRUIT, CRATE, SPIKE_BALL }
enum class FallingBehavior { DROP, EXPLODE, ROLL, CHASE, CHAIN }
enum class CrusherAxis { HORIZONTAL, VERTICAL }
enum class CrusherStyle { STONE_COLUMN, FALLING_WALL, LOG_PRESS, RUIN_BLOCK }
enum class GameEnemyKind { WALKER, JUMPER, FLYER, SHOOTER, GUARDIAN }
enum class GamePickupKind { ENERGY, SHIELD, POWER }
enum class AdventureBiome { FOREST_DAY, FOREST_SUNSET, UNDERGROUND, CAVE_NIGHT, DESERT_DAWN }
enum class LevelExitKind { TRAIL, ASCENT, DESCENT, CAVE, DOOR, LIFT, BRIDGE, TUNNEL, RUIN_GATE, SUMMIT }

data class GamePlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float = 34f,
    val kind: PlatformKind = PlatformKind.SOLID,
    val triggerX: Float = x - 90f,
    val delayMs: Long = 720L,
    val cycleMs: Long = 2_200L,
    val phaseMs: Long = 0L
)

data class GameHazard(
    val x: Float,
    val y: Float,
    val width: Float = 58f,
    val height: Float = 42f,
    val kind: HazardKind = HazardKind.SPIKES,
    val triggerX: Float = x - 105f,
    val cycleMs: Long = 0L,
    val phaseMs: Long = 0L,
    val orientation: HazardOrientation = HazardOrientation.UP,
    val camouflaged: Boolean = false
)

data class GameBarrier(
    val x: Float,
    val y: Float = 270f,
    val width: Float = 46f,
    val height: Float = 350f,
    val switchIndex: Int
)

data class GameEnemy(
    val x: Float,
    val y: Float,
    val range: Float = 120f,
    val detectionRange: Float = 480f,
    val health: Int = 2,
    val kind: GameEnemyKind = GameEnemyKind.WALKER,
    val speed: Float = 72f
)

data class GameCrystal(val x: Float, val y: Float)
data class GameCrate(val x: Float, val y: Float)
data class GameSwitch(val x: Float, val y: Float, val opensAtX: Float, val reversesFans: Boolean = false)
data class GamePickup(val x: Float, val y: Float, val kind: GamePickupKind)

data class GameKey(
    val x: Float,
    val y: Float,
    val revealTriggerX: Float = x - 220f,
    val hiddenUntilSwitch: Int? = null
)

data class GameMovingPlatform(
    val x: Float,
    val y: Float,
    val width: Float,
    val travel: Float,
    val vertical: Boolean,
    val periodSeconds: Float = 3.4f
)

data class GameCheckpoint(
    val x: Float,
    val y: Float = 535f,
    val kind: CheckpointKind = CheckpointKind.SAFE,
    val appearTriggerX: Float = x - 180f
)

data class GameFan(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val forceX: Float,
    val forceY: Float,
    val cycleMs: Long = 0L,
    val phaseMs: Long = 0L,
    val switchIndex: Int? = null
)

data class GameFallingObject(
    val x: Float,
    val startY: Float,
    val targetY: Float,
    val size: Float,
    val triggerX: Float,
    val kind: FallingObjectKind,
    val delayMs: Long = 180L,
    val behavior: FallingBehavior = FallingBehavior.DROP,
    val rollDirection: Float = 1f,
    val explosionRadius: Float = 110f,
    val chainCount: Int = 1,
    val chainSpacing: Float = 74f,
    val chaseDurationMs: Long = 5_500L,
    val chaseMaxTravel: Float = 850f,
    val treeFallsAfterTrap: Boolean = false,
    val explosionDelayMs: Long = 650L,
    val becomesPlatform: Boolean = false
)

data class GameChasingHole(
    val startX: Float,
    val y: Float = 592f,
    val width: Float = 145f,
    val height: Float = 48f,
    val triggerX: Float,
    val speed: Float = 170f,
    val maxTravel: Float = 720f,
    val direction: Float = 1f,
    val surfaceStartX: Float = startX,
    val surfaceEndX: Float = startX + maxTravel + width
)

data class GameCrusher(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val triggerX: Float,
    val axis: CrusherAxis,
    val travel: Float,
    val speed: Float = 330f,
    val delayMs: Long = 280L,
    val reverseAfterMs: Long = 1_350L,
    val style: CrusherStyle = CrusherStyle.STONE_COLUMN,
    val despawnAfterMs: Long = 0L
)

data class AdventureLevel(
    val number: Int,
    val worldName: String,
    val levelName: String,
    val objective: String,
    val difficultyLabel: String,
    val width: Float,
    val platforms: List<GamePlatform>,
    val movingPlatforms: List<GameMovingPlatform>,
    val hazards: List<GameHazard>,
    val barriers: List<GameBarrier>,
    val enemies: List<GameEnemy>,
    val crystals: List<GameCrystal>,
    val crates: List<GameCrate>,
    val switches: List<GameSwitch>,
    val checkpoints: List<GameCheckpoint>,
    val fans: List<GameFan>,
    val fallingObjects: List<GameFallingObject>,
    val chasingHoles: List<GameChasingHole>,
    val crushers: List<GameCrusher>,
    val requiredMechanisms: Int,
    val pickups: List<GamePickup>,
    val goalX: Float,
    val parSeconds: Int,
    val introStory: String? = null,
    val outroStory: String? = null,
    val companion: String? = null,
    val injured: Boolean = false,
    val weaponEnabled: Boolean = false,
    val acechantePresent: Boolean = false,
    val biome: AdventureBiome = AdventureBiome.FOREST_DAY,
    val entryKind: LevelExitKind = LevelExitKind.TRAIL,
    val exitKind: LevelExitKind = LevelExitKind.TRAIL,
    val entryConnection: String = "start",
    val exitConnection: String = "end",
    val spawnX: Float = 70f,
    val spawnY: Float = 520f,
    val goalY: Float = 485f,
    val keys: List<GameKey> = emptyList(),
    val requiresKey: Boolean = false,
    val requiredCrystals: Int = 0
)

object GeoAdventureLevelFactory {
    private enum class Beat {
        CLIMB_GATE,
        DESCEND_GATE,
        LOW_TUNNEL,
        HIGH_BRIDGE,
        SHAFT_UP,
        SHAFT_DOWN,
        SPLIT_ROUTE,
        FLOOR_DROP,
        CRUSHER_ROOM,
        FRUIT_AMBUSH,
        ROCK_RUN,
        FAN_SHAFT,
        KEY_DETOUR,
        FALSE_SAFE,
        ENEMY_NEST,
        WALL_MAZE,
        MOVING_GAP,
        COLLAPSING_BRIDGE,
        BOUNCE_CHAMBER,
        SWITCH_GATE
    }

    private data class Plan(
        val number: Int,
        val world: String,
        val name: String,
        val objective: String,
        val difficulty: String,
        val biome: AdventureBiome,
        val entry: LevelExitKind,
        val exit: LevelExitKind,
        val entryConnection: String,
        val exitConnection: String,
        val startY: Float,
        val beats: List<Beat>,
        val requiresKey: Boolean = false,
        val companion: String? = null,
        val weaponEnabled: Boolean = false,
        val acechantePresent: Boolean = false,
        val intro: String? = null,
        val outro: String? = null
    )

    private class MazeBuilder(private val plan: Plan) {
        private val platforms = mutableListOf<GamePlatform>()
        private val movingPlatforms = mutableListOf<GameMovingPlatform>()
        private val hazards = mutableListOf<GameHazard>()
        private val barriers = mutableListOf<GameBarrier>()
        private val enemies = mutableListOf<GameEnemy>()
        private val crates = mutableListOf<GameCrate>()
        private val switches = mutableListOf<GameSwitch>()
        private val checkpoints = mutableListOf<GameCheckpoint>()
        private val fans = mutableListOf<GameFan>()
        private val fallingObjects = mutableListOf<GameFallingObject>()
        private val chasingHoles = mutableListOf<GameChasingHole>()
        private val crushers = mutableListOf<GameCrusher>()
        private val pickups = mutableListOf<GamePickup>()
        private val keys = mutableListOf<GameKey>()

        private var x = 0f
        private var floorY = plan.startY
        private var requiredMechanisms = 0
        private var decoyCount = 0

        private fun structure(
            x: Float,
            y: Float,
            width: Float,
            height: Float = 34f,
            kind: PlatformKind = PlatformKind.SOLID,
            delayMs: Long = 720L
        ) {
            platforms += GamePlatform(
                x = x,
                y = y,
                width = width,
                height = height,
                kind = kind,
                triggerX = x - 75f,
                delayMs = delayMs
            )
        }

        private fun ground(x: Float, y: Float, width: Float, kind: PlatformKind = PlatformKind.SOLID, delayMs: Long = 720L) {
            structure(x, y, width, (760f - y).coerceAtLeast(70f), kind, delayMs)
        }

        private fun ledge(x: Float, y: Float, width: Float, kind: PlatformKind = PlatformKind.SOLID, delayMs: Long = 720L) {
            structure(x, y, width, 34f, kind, delayMs)
        }

        private fun roof(x: Float, bottomY: Float, width: Float) {
            structure(x, 0f, width, bottomY.coerceAtLeast(45f))
        }

        private fun wall(x: Float, topY: Float, width: Float, bottomY: Float = 760f) {
            structure(x, topY, width, (bottomY - topY).coerceAtLeast(45f))
        }

        private fun floorSpikes(x: Float, y: Float, width: Float = 58f, phase: Long = 0L, hidden: Boolean = true) {
            hazards += GameHazard(
                x = x,
                y = y - 44f,
                width = width,
                height = 44f,
                kind = if (hidden) HazardKind.HIDDEN_SPIKES else HazardKind.SPIKES,
                triggerX = x - 88f,
                cycleMs = 2_450L + (plan.number % 4) * 160L,
                phaseMs = phase,
                orientation = HazardOrientation.UP,
                camouflaged = hidden
            )
        }

        private fun ceilingSpikes(x: Float, bottomY: Float, width: Float = 68f, height: Float = 46f, phase: Long = 0L) {
            val support = platforms.any {
                it.x <= x && it.x + it.width >= x + width && kotlin.math.abs((it.y + it.height) - bottomY) <= 4f
            }
            if (!support) roof(x - 24f, bottomY, width + 48f)
            hazards += GameHazard(
                x = x,
                y = bottomY,
                width = width,
                height = height,
                kind = HazardKind.HIDDEN_SPIKES,
                triggerX = x - 92f,
                cycleMs = 2_650L + (plan.number % 3) * 180L,
                phaseMs = phase,
                orientation = HazardOrientation.DOWN,
                camouflaged = true
            )
        }

        private fun spikesFromLeftWall(wallX: Float, y: Float, height: Float = 92f, phase: Long = 0L) {
            wall(wallX, y - 18f, 38f, y + height + 18f)
            hazards += GameHazard(
                x = wallX + 30f,
                y = y,
                width = 46f,
                height = height,
                kind = HazardKind.HIDDEN_SPIKES,
                triggerX = wallX - 90f,
                cycleMs = 2_850L,
                phaseMs = phase,
                orientation = HazardOrientation.RIGHT,
                camouflaged = true
            )
        }

        private fun spikesFromRightWall(wallX: Float, y: Float, height: Float = 92f, phase: Long = 0L) {
            wall(wallX, y - 18f, 38f, y + height + 18f)
            hazards += GameHazard(
                x = wallX - 38f,
                y = y,
                width = 46f,
                height = height,
                kind = HazardKind.HIDDEN_SPIKES,
                triggerX = wallX - 140f,
                cycleMs = 2_850L,
                phaseMs = phase,
                orientation = HazardOrientation.LEFT,
                camouflaged = true
            )
        }

        private fun fire(x: Float, y: Float, width: Float = 70f, phase: Long = 0L) {
            hazards += GameHazard(
                x = x,
                y = y - 46f,
                width = width,
                height = 46f,
                kind = HazardKind.FIRE,
                triggerX = x - 100f,
                cycleMs = 2_250L,
                phaseMs = phase,
                orientation = HazardOrientation.UP
            )
        }

        private fun enemy(x: Float, y: Float, kind: GameEnemyKind, speedBoost: Float = 0f) {
            enemies += GameEnemy(
                x = x,
                y = y - 55f,
                range = 95f + (plan.number % 4) * 14f,
                detectionRange = 450f,
                health = if (plan.number >= 12) 3 else 2,
                kind = kind,
                speed = 88f + plan.number * 2.1f + speedBoost
            )
        }

        private fun fruit(
            x: Float,
            targetY: Float,
            behavior: FallingBehavior,
            treeFalls: Boolean = false,
            direction: Float = 1f
        ) {
            fallingObjects += GameFallingObject(
                x = x,
                startY = (targetY - 285f).coerceAtLeast(130f),
                targetY = targetY,
                size = 68f,
                triggerX = x - 150f,
                kind = FallingObjectKind.FRUIT,
                delayMs = 170L,
                behavior = behavior,
                rollDirection = direction,
                explosionRadius = 102f,
                chainCount = if (behavior == FallingBehavior.CHAIN) 4 else 1,
                chainSpacing = 58f,
                chaseDurationMs = 5_200L,
                chaseMaxTravel = 790f,
                treeFallsAfterTrap = treeFalls,
                explosionDelayMs = 760L
            )
        }

        private fun rock(x: Float, targetY: Float, becomesPlatform: Boolean = false) {
            fallingObjects += GameFallingObject(
                x = x,
                startY = (targetY - 260f).coerceAtLeast(115f),
                targetY = targetY,
                size = if (becomesPlatform) 84f else 74f,
                triggerX = x - 145f,
                kind = FallingObjectKind.ROCK,
                delayMs = 190L,
                behavior = FallingBehavior.DROP,
                becomesPlatform = becomesPlatform
            )
        }

        private fun checkpoint(x: Float, y: Float) {
            val support = platforms.any { x in it.x..(it.x + it.width) && kotlin.math.abs(it.y - y) < 2f }
            if (!support) ground(x - 125f, y, 270f)
            checkpoints += GameCheckpoint(x, y - 85f, CheckpointKind.POPUP, x - 165f)
        }

        private fun decoy(x: Float, y: Float) {
            if (decoyCount >= 1) return
            checkpoints += GameCheckpoint(x, y - 85f, CheckpointKind.DECOY, x - 160f)
            decoyCount++
        }

        private fun addBeat(beat: Beat, index: Int) {
            when (beat) {
                Beat.CLIMB_GATE -> climbGate(index)
                Beat.DESCEND_GATE -> descendGate(index)
                Beat.LOW_TUNNEL -> lowTunnel(index)
                Beat.HIGH_BRIDGE -> highBridge(index)
                Beat.SHAFT_UP -> shaftUp(index)
                Beat.SHAFT_DOWN -> shaftDown(index)
                Beat.SPLIT_ROUTE -> splitRoute(index)
                Beat.FLOOR_DROP -> floorDrop(index)
                Beat.CRUSHER_ROOM -> crusherRoom(index)
                Beat.FRUIT_AMBUSH -> fruitAmbush(index)
                Beat.ROCK_RUN -> rockRun(index)
                Beat.FAN_SHAFT -> fanShaft(index)
                Beat.KEY_DETOUR -> keyDetour(index)
                Beat.FALSE_SAFE -> falseSafe(index)
                Beat.ENEMY_NEST -> enemyNest(index)
                Beat.WALL_MAZE -> wallMaze(index)
                Beat.MOVING_GAP -> movingGap(index)
                Beat.COLLAPSING_BRIDGE -> collapsingBridge(index)
                Beat.BOUNCE_CHAMBER -> bounceChamber(index)
                Beat.SWITCH_GATE -> switchGate(index)
            }
        }

        private fun climbGate(i: Int) {
            val start = x
            val target = (floorY - if (i % 2 == 0) 185f else 150f).coerceAtLeast(315f)
            ground(start, floorY, 210f)
            ledge(start + 260f, floorY - 92f, 145f)
            ledge(start + 455f, target, 170f)
            wall(start + 650f, target + 34f, 86f)
            ground(start + 735f, target, 250f)
            floorSpikes(start + 85f, floorY, phase = 180L * i)
            spikesFromRightWall(start + 650f, target + 88f, 82f, 110L * i)
            enemy(start + 820f, target, GameEnemyKind.JUMPER)
            floorY = target
            x += 965f
        }

        private fun descendGate(i: Int) {
            val start = x
            val target = (floorY + if (i % 2 == 0) 165f else 130f).coerceAtMost(625f)
            ground(start, floorY, 200f)
            ledge(start + 250f, floorY + 80f, 150f)
            ledge(start + 455f, target, 170f)
            roof(start + 620f, target - 132f, 160f)
            ground(start + 620f, target, 360f)
            ceilingSpikes(start + 670f, target - 132f, 72f, 42f, 170L * i)
            floorSpikes(start + 830f, target, phase = 240L * i)
            enemy(start + 900f, target, GameEnemyKind.WALKER)
            floorY = target
            x += 960f
        }

        private fun lowTunnel(i: Int) {
            val start = x
            val tunnelY = floorY.coerceAtLeast(565f)
            if (tunnelY != floorY) {
                ledge(start + 40f, floorY + 80f, 150f)
                floorY = tunnelY
            }
            ground(start, floorY, 900f)
            roof(start + 110f, floorY - 135f, 680f)
            ceilingSpikes(start + 220f, floorY - 135f, 72f, 42f, 190L * i)
            if (plan.biome == AdventureBiome.CAVE_NIGHT || plan.biome == AdventureBiome.DESERT_DAWN) {
                fire(start + 420f, floorY, phase = 270L * i)
            } else {
                floorSpikes(start + 420f, floorY, phase = 270L * i)
            }
            ceilingSpikes(start + 610f, floorY - 135f, 72f, 42f, 340L * i)
            enemy(start + 735f, floorY, if (i % 2 == 0) GameEnemyKind.WALKER else GameEnemyKind.JUMPER)
            x += 900f
        }

        private fun highBridge(i: Int) {
            val start = x
            val bridgeY = (floorY - 165f).coerceAtLeast(320f)
            ground(start, floorY, 180f)
            ledge(start + 245f, bridgeY + 65f, 130f)
            ledge(start + 430f, bridgeY, 150f)
            ledge(start + 635f, bridgeY + 35f, 145f)
            wall(start + 390f, bridgeY + 34f, 65f)
            wall(start + 760f, bridgeY + 69f, 65f)
            ground(start + 825f, bridgeY + 35f, 230f)
            floorSpikes(start + 455f, bridgeY, phase = 160L * i)
            rock(start + 650f, bridgeY + 35f, becomesPlatform = i % 3 == 0)
            enemy(start + 900f, bridgeY + 35f, GameEnemyKind.FLYER)
            floorY = bridgeY + 35f
            x += 1_040f
        }

        private fun shaftUp(i: Int) {
            val start = x
            val target = (floorY - 205f).coerceAtLeast(300f)
            ground(start, floorY, 190f)
            roof(start + 215f, floorY - 105f, 80f)
            ledge(start + 310f, floorY - 90f, 145f)
            ledge(start + 500f, floorY - 165f, 145f)
            ledge(start + 690f, target, 155f)
            wall(start + 860f, target + 34f, 80f)
            ground(start + 940f, target, 230f)
            spikesFromLeftWall(start + 215f, floorY - 100f, 84f, 160L * i)
            floorSpikes(start + 525f, floorY - 165f, phase = 220L * i)
            enemy(start + 725f, target, GameEnemyKind.JUMPER)
            floorY = target
            x += 1_150f
        }

        private fun shaftDown(i: Int) {
            val start = x
            val target = (floorY + 205f).coerceAtMost(625f)
            ground(start, floorY, 190f)
            roof(start + 230f, floorY - 90f, 140f)
            ledge(start + 305f, floorY + 80f, 140f)
            ledge(start + 495f, floorY + 150f, 140f)
            ground(start + 690f, target, 450f)
            ceilingSpikes(start + 265f, floorY - 90f, 68f, 42f, 170L * i)
            floorSpikes(start + 735f, target, phase = 280L * i)
            rock(start + 940f, target, becomesPlatform = i % 4 == 0)
            floorY = target
            x += 1_120f
        }

        private fun splitRoute(i: Int) {
            val start = x
            ground(start, floorY, 860f)
            roof(start + 240f, floorY - 220f, 270f)
            wall(start + 505f, floorY - 220f, 74f, floorY - 70f)
            ledge(start + 250f, floorY - 125f, 190f, if ((plan.number + i) % 2 == 0) PlatformKind.REVEALING else PlatformKind.SOLID)
            ledge(start + 590f, floorY - 170f, 160f)
            floorSpikes(start + 150f, floorY, phase = 150L * i)
            ceilingSpikes(start + 315f, floorY - 220f, 70f, 45f, 260L * i)
            floorSpikes(start + 640f, floorY - 170f, phase = 390L * i)
            enemy(start + 760f, floorY, GameEnemyKind.SHOOTER)
            x += 860f
        }

        private fun floorDrop(i: Int) {
            val start = x
            val lower = (floorY + 130f).coerceAtMost(650f)
            ground(start, floorY, 210f)
            ledge(start + 245f, floorY, 230f, PlatformKind.PROXIMITY_DISAPPEARING, 1_000L + (i % 3) * 120L)
            ground(start + 245f, lower, 500f)
            ledge(start + 540f, lower - 75f, 135f)
            ledge(start + 725f, floorY, 145f)
            ground(start + 920f, floorY, 220f)
            floorSpikes(start + 390f, lower, phase = 230L * i)
            enemy(start + 620f, lower - 75f, GameEnemyKind.JUMPER)
            spikesFromLeftWall(start + 905f, floorY - 92f, 82f, 130L * i)
            x += 1_120f
        }

        private fun crusherRoom(i: Int) {
            val start = x
            ground(start, floorY, 900f)
            roof(start + 130f, floorY - 205f, 640f)
            crushers += GameCrusher(
                x = start + 310f,
                y = floorY - 190f,
                width = 94f,
                height = 150f,
                triggerX = start + 165f,
                axis = CrusherAxis.VERTICAL,
                travel = 145f,
                speed = 280f,
                delayMs = 360L,
                reverseAfterMs = 1_550L,
                style = if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) CrusherStyle.LOG_PRESS else CrusherStyle.STONE_COLUMN
            )
            crushers += GameCrusher(
                x = start + 620f,
                y = floorY - 165f,
                width = 72f,
                height = 125f,
                triggerX = start + 500f,
                axis = CrusherAxis.HORIZONTAL,
                travel = -120f,
                speed = 255f,
                delayMs = 370L,
                reverseAfterMs = 1_650L,
                style = CrusherStyle.STONE_COLUMN
            )
            floorSpikes(start + 485f, floorY, phase = 210L * i)
            enemy(start + 790f, floorY, GameEnemyKind.WALKER)
            x += 900f
        }

        private fun fruitAmbush(i: Int) {
            val start = x
            ground(start, floorY, 900f)
            val behaviors = listOf(FallingBehavior.ROLL, FallingBehavior.EXPLODE, FallingBehavior.CHASE, FallingBehavior.CHAIN)
            fruit(start + 220f, floorY, behaviors[(plan.number + i) % behaviors.size], treeFalls = (plan.number + i) % 3 == 0)
            fruit(start + 520f, floorY, behaviors[(plan.number + i + 2) % behaviors.size], treeFalls = (plan.number + i) % 4 == 0, direction = -1f)
            floorSpikes(start + 365f, floorY, phase = 170L * i)
            enemy(start + 735f, floorY, GameEnemyKind.JUMPER)
            x += 900f
        }

        private fun rockRun(i: Int) {
            val start = x
            ground(start, floorY, 940f)
            roof(start + 120f, floorY - 230f, 690f)
            rock(start + 260f, floorY)
            rock(start + 500f, floorY, becomesPlatform = (plan.number + i) % 4 == 0)
            rock(start + 735f, floorY)
            floorSpikes(start + 390f, floorY, phase = 180L * i)
            ceilingSpikes(start + 620f, floorY - 230f, 78f, 50f, 260L * i)
            x += 940f
        }

        private fun fanShaft(i: Int) {
            val start = x
            val target = (floorY - 155f).coerceAtLeast(320f)
            ground(start, floorY, 220f)
            wall(start + 250f, 250f, 56f, floorY - 50f)
            wall(start + 620f, target + 35f, 70f)
            ledge(start + 340f, floorY - 95f, 120f)
            ledge(start + 500f, target, 125f)
            ground(start + 690f, target, 270f)
            fans += GameFan(start + 300f, target - 15f, 300f, floorY - target + 20f, 0f, -315f, 2_900L, 230L * i)
            floorSpikes(start + 545f, target, phase = 170L * i)
            spikesFromRightWall(start + 620f, target + 58f, 82f, 260L * i)
            floorY = target
            x += 940f
        }

        private fun keyDetour(i: Int) {
            val start = x
            val keyY = (floorY - 175f).coerceAtLeast(310f)
            ground(start, floorY, 1_000f)
            ledge(start + 220f, floorY - 85f, 135f)
            ledge(start + 410f, keyY, 190f)
            ledge(start + 655f, floorY - 95f, 140f)
            keys += GameKey(start + 500f, keyY - 72f, start + 240f)
            floorSpikes(start + 300f, floorY - 85f, phase = 150L * i)
            ceilingSpikes(start + 460f, keyY - 110f, 74f, 42f, 300L * i)
            enemy(start + 720f, floorY - 95f, GameEnemyKind.GUARDIAN)
            fruit(start + 850f, floorY, FallingBehavior.EXPLODE)
            x += 1_000f
        }

        private fun falseSafe(i: Int) {
            val start = x
            ground(start, floorY, 820f)
            if ((plan.number + i) % 2 == 0) decoy(start + 315f, floorY)
            floorSpikes(start + 180f, floorY, phase = 190L * i)
            floorSpikes(start + 470f, floorY, phase = 420L * i)
            if ((plan.number + i) % 2 == 1) {
                chasingHoles += GameChasingHole(
                    startX = start + 235f,
                    y = floorY - 28f,
                    width = 125f,
                    height = 48f,
                    triggerX = start + 175f,
                    speed = 145f,
                    maxTravel = 330f,
                    direction = 1f,
                    surfaceStartX = start + 120f,
                    surfaceEndX = start + 710f
                )
            }
            if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) {
                fruit(start + 610f, floorY, FallingBehavior.CHASE)
            } else {
                rock(start + 610f, floorY)
            }
            enemy(start + 735f, floorY, GameEnemyKind.FLYER)
            x += 820f
        }

        private fun enemyNest(i: Int) {
            val start = x
            ground(start, floorY, 940f)
            ledge(start + 250f, floorY - 115f, 150f)
            ledge(start + 520f, floorY - 175f, 160f)
            enemy(start + 150f, floorY, GameEnemyKind.WALKER)
            enemy(start + 315f, floorY - 115f, GameEnemyKind.JUMPER)
            enemy(start + 585f, floorY - 175f, if (plan.number >= 10) GameEnemyKind.SHOOTER else GameEnemyKind.FLYER)
            enemy(start + 800f, floorY, if (plan.number >= 15) GameEnemyKind.GUARDIAN else GameEnemyKind.JUMPER)
            floorSpikes(start + 420f, floorY, phase = 220L * i)
            ceilingSpikes(start + 700f, floorY - 210f, 70f, 46f, 340L * i)
            x += 940f
        }

        private fun wallMaze(i: Int) {
            val start = x
            ground(start, floorY, 1_060f)
            val hangingBottom = floorY - 125f
            roof(start + 240f, hangingBottom, 105f)
            wall(start + 475f, floorY - 175f, 85f)
            roof(start + 690f, floorY - 145f, 105f)
            wall(start + 895f, floorY - 155f, 80f)
            ceilingSpikes(start + 255f, hangingBottom, 70f, 42f, 150L * i)
            spikesFromLeftWall(start + 475f, floorY - 150f, 84f, 260L * i)
            floorSpikes(start + 610f, floorY, phase = 340L * i)
            ceilingSpikes(start + 710f, floorY - 145f, 70f, 42f, 410L * i)
            if ((plan.number + i) % 3 == 0) {
                crushers += GameCrusher(
                    x = start + 820f,
                    y = floorY - 230f,
                    width = 132f,
                    height = 170f,
                    triggerX = start + 690f,
                    axis = CrusherAxis.VERTICAL,
                    travel = 175f,
                    speed = 275f,
                    delayMs = 360L,
                    reverseAfterMs = 1_650L,
                    style = CrusherStyle.FALLING_WALL,
                    despawnAfterMs = 3_000L
                )
            }
            enemy(start + 995f, floorY, GameEnemyKind.JUMPER)
            x += 1_060f
        }

        private fun movingGap(i: Int) {
            val start = x
            ground(start, floorY, 180f)
            movingPlatforms += GameMovingPlatform(start + 255f, floorY - 90f, 140f, 70f, true, 3.1f)
            movingPlatforms += GameMovingPlatform(start + 470f, floorY - 150f, 145f, 90f, false, 3.4f)
            movingPlatforms += GameMovingPlatform(start + 690f, floorY - 80f, 140f, 65f, true, 2.9f)
            ground(start + 890f, floorY, 220f)
            wall(start + 405f, floorY - 50f, 55f)
            wall(start + 820f, floorY - 40f, 55f)
            spikesFromLeftWall(start + 405f, floorY - 145f, 80f, 180L * i)
            spikesFromRightWall(start + 875f, floorY - 145f, 80f, 320L * i)
            rock(start + 720f, floorY)
            x += 1_090f
        }

        private fun collapsingBridge(i: Int) {
            val start = x
            ground(start, floorY, 160f)
            ledge(start + 220f, floorY - 30f, 180f, PlatformKind.FALLING, 900L)
            ledge(start + 450f, floorY - 70f, 180f, PlatformKind.PROXIMITY_DISAPPEARING, 1_050L)
            ledge(start + 680f, floorY - 20f, 180f, PlatformKind.FALLING, 980L)
            ground(start + 920f, floorY, 240f)
            floorSpikes(start + 500f, floorY - 70f, phase = 210L * i)
            rock(start + 735f, floorY - 20f, becomesPlatform = true)
            enemy(start + 1_015f, floorY, GameEnemyKind.WALKER)
            x += 1_140f
        }

        private fun bounceChamber(i: Int) {
            val start = x
            ground(start, floorY, 230f)
            roof(start + 240f, floorY - 250f, 600f)
            ledge(start + 300f, floorY - 15f, 115f, PlatformKind.BOUNCE)
            ledge(start + 495f, floorY - 165f, 135f)
            ledge(start + 690f, floorY - 90f, 130f)
            ground(start + 880f, floorY, 250f)
            ceilingSpikes(start + 350f, floorY - 250f, 75f, 46f, 160L * i)
            floorSpikes(start + 540f, floorY - 165f, phase = 280L * i)
            spikesFromRightWall(start + 835f, floorY - 160f, 88f, 410L * i)
            enemy(start + 970f, floorY, GameEnemyKind.FLYER)
            x += 1_110f
        }

        private fun switchGate(i: Int) {
            val start = x
            ground(start, floorY, 960f)
            ledge(start + 210f, floorY - 120f, 150f)
            switches += GameSwitch(start + 285f, floorY - 174f, start + 710f)
            val switchIndex = switches.lastIndex
            requiredMechanisms++
            barriers += GameBarrier(start + 710f, floorY - 300f, 58f, 300f, switchIndex)
            roof(start + 480f, floorY - 210f, 180f)
            floorSpikes(start + 410f, floorY, phase = 190L * i)
            ceilingSpikes(start + 525f, floorY - 210f, 76f, 45f, 330L * i)
            enemy(start + 830f, floorY, GameEnemyKind.GUARDIAN)
            x += 960f
        }

        fun build(): AdventureLevel {
            ground(0f, floorY, 520f)
            when (plan.number % 5) {
                0 -> floorSpikes(330f, floorY, phase = 240L)
                1 -> if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) {
                    fruit(350f, floorY, FallingBehavior.ROLL, treeFalls = plan.number > 5)
                } else {
                    rock(350f, floorY)
                }
                2 -> {
                    roof(250f, floorY - 138f, 190f)
                    ceilingSpikes(305f, floorY - 138f, 72f, 42f, 310L)
                }
                3 -> enemy(365f, floorY, if (plan.number >= 10) GameEnemyKind.SHOOTER else GameEnemyKind.JUMPER)
                else -> {
                    floorSpikes(285f, floorY, phase = 160L)
                    enemy(425f, floorY, GameEnemyKind.WALKER)
                }
            }
            x = 480f
            plan.beats.forEachIndexed { index, beat ->
                addBeat(beat, index)
                if (index == 2 || index == 6 || (index == 9 && plan.beats.size > 11)) {
                    checkpoint(x - 120f, floorY)
                }
            }

            if (plan.requiresKey && keys.isEmpty()) {
                keyDetour(plan.beats.size + 1)
            }

            ground(x, floorY, 520f)
            when (plan.number % 4) {
                0 -> floorSpikes(x + 130f, floorY, phase = 520L)
                1 -> if (plan.biome == AdventureBiome.FOREST_DAY || plan.biome == AdventureBiome.FOREST_SUNSET) {
                    fruit(x + 135f, floorY, FallingBehavior.EXPLODE)
                } else {
                    rock(x + 135f, floorY)
                }
                2 -> enemy(x + 150f, floorY, if (plan.number >= 12) GameEnemyKind.GUARDIAN else GameEnemyKind.JUMPER)
                else -> fire(x + 135f, floorY, phase = 380L)
            }
            val width = x + 500f
            val goalX = width - 175f
            val realCheckpoints = checkpoints.filter { it.kind != CheckpointKind.DECOY }
            val safetyAnchors = buildList {
                add(80f)
                add(goalX)
                realCheckpoints.forEach { add(it.x) }
            }
            fun closeToSafety(centerX: Float, radius: Float) = safetyAnchors.any { kotlin.math.abs(it - centerX) < radius }

            val safeHazards = hazards.filterNot { closeToSafety(it.x + it.width / 2f, 105f) }
            val safeFalling = fallingObjects.filterNot { closeToSafety(it.x + it.size / 2f, 125f) }
            val safeCrushers = crushers.filterNot { closeToSafety(it.x + it.width / 2f, 145f) }
            val safeEnemies = enemies.filterNot { closeToSafety(it.x, 85f) }

            return AdventureLevel(
                number = plan.number,
                worldName = plan.world,
                levelName = plan.name,
                objective = plan.objective,
                difficultyLabel = plan.difficulty,
                width = width,
                platforms = platforms.sortedWith(compareBy<GamePlatform> { it.x }.thenBy { it.y }),
                movingPlatforms = movingPlatforms,
                hazards = safeHazards,
                barriers = barriers,
                enemies = safeEnemies,
                crystals = emptyList(),
                crates = crates,
                switches = switches,
                checkpoints = checkpoints,
                fans = fans,
                fallingObjects = safeFalling,
                chasingHoles = chasingHoles,
                crushers = safeCrushers,
                requiredMechanisms = requiredMechanisms,
                pickups = pickups,
                goalX = goalX,
                parSeconds = 250 + plan.number * 13,
                introStory = plan.intro,
                outroStory = plan.outro,
                companion = plan.companion,
                weaponEnabled = plan.weaponEnabled,
                acechantePresent = plan.acechantePresent,
                biome = plan.biome,
                entryKind = plan.entry,
                exitKind = plan.exit,
                entryConnection = plan.entryConnection,
                exitConnection = plan.exitConnection,
                spawnX = 70f,
                spawnY = plan.startY - 58f,
                goalY = floorY - 135f,
                keys = keys,
                requiresKey = plan.requiresKey,
                requiredCrystals = 0
            )
        }
    }

    private val plans = listOf(
        Plan(1, "Bosque tramposo", "El sendero que cambia", "Aprende a desconfiar del suelo, los árboles y los techos.", "BRUTAL", AdventureBiome.FOREST_DAY, LevelExitKind.TRAIL, LevelExitKind.ASCENT, "awakening", "ridge-gate", 620f,
            listOf(Beat.FRUIT_AMBUSH, Beat.CLIMB_GATE, Beat.WALL_MAZE, Beat.LOW_TUNNEL, Beat.FLOOR_DROP, Beat.ENEMY_NEST, Beat.DESCEND_GATE, Beat.HIGH_BRIDGE, Beat.FALSE_SAFE, Beat.SHAFT_UP),
            intro = "GEO despierta bajo un cielo limpio. El primer paso ya es una mentira.", outro = "La salida sube hacia una cresta más cerrada."),
        Plan(2, "Bosque tramposo", "La cresta cerrada", "Desciende, atraviesa muros y encuentra la única ruta real.", "BRUTAL+", AdventureBiome.FOREST_DAY, LevelExitKind.ASCENT, LevelExitKind.DESCENT, "ridge-gate", "root-descent", 430f,
            listOf(Beat.DESCEND_GATE, Beat.LOW_TUNNEL, Beat.WALL_MAZE, Beat.COLLAPSING_BRIDGE, Beat.SPLIT_ROUTE, Beat.CRUSHER_ROOM, Beat.SHAFT_UP, Beat.FLOOR_DROP, Beat.ENEMY_NEST, Beat.DESCEND_GATE)),
        Plan(3, "Bosque tramposo", "Las copas falsas", "Usa corrientes y rebotes sin confiar en ninguna plataforma.", "EXTREMO", AdventureBiome.FOREST_DAY, LevelExitKind.DESCENT, LevelExitKind.BRIDGE, "root-descent", "canopy-crossing", 620f,
            listOf(Beat.FAN_SHAFT, Beat.SHAFT_UP, Beat.MOVING_GAP, Beat.ENEMY_NEST, Beat.HIGH_BRIDGE, Beat.BOUNCE_CHAMBER, Beat.DESCEND_GATE, Beat.WALL_MAZE, Beat.FALSE_SAFE, Beat.COLLAPSING_BRIDGE)),
        Plan(4, "Bosque tramposo", "La puerta de raíces", "Busca la llave oculta en el laberinto y abre la salida.", "EXTREMO+", AdventureBiome.FOREST_DAY, LevelExitKind.BRIDGE, LevelExitKind.DOOR, "canopy-crossing", "sunset-door", 500f,
            listOf(Beat.COLLAPSING_BRIDGE, Beat.WALL_MAZE, Beat.KEY_DETOUR, Beat.LOW_TUNNEL, Beat.SWITCH_GATE, Beat.FRUIT_AMBUSH, Beat.SHAFT_DOWN, Beat.CRUSHER_ROOM, Beat.ENEMY_NEST, Beat.CLIMB_GATE), requiresKey = true,
            outro = "La puerta desemboca en un bosque teñido por el atardecer."),
        Plan(5, "Bosque del atardecer", "Puentes de sombra", "Cruza estructuras que caen antes de que el camino se cierre.", "DEMENTE", AdventureBiome.FOREST_SUNSET, LevelExitKind.DOOR, LevelExitKind.BRIDGE, "sunset-door", "broken-bridge", 610f,
            listOf(Beat.HIGH_BRIDGE, Beat.COLLAPSING_BRIDGE, Beat.FALSE_SAFE, Beat.WALL_MAZE, Beat.FRUIT_AMBUSH, Beat.SHAFT_UP, Beat.SPLIT_ROUTE, Beat.CRUSHER_ROOM, Beat.FLOOR_DROP, Beat.HIGH_BRIDGE), companion = "Luma"),
        Plan(6, "Bosque del atardecer", "El barranco naranja", "Baja por cámaras de tierra mientras el techo intenta cerrarte el paso.", "DEMENTE+", AdventureBiome.FOREST_SUNSET, LevelExitKind.BRIDGE, LevelExitKind.DESCENT, "broken-bridge", "ravine-depth", 460f,
            listOf(Beat.SHAFT_DOWN, Beat.DESCEND_GATE, Beat.LOW_TUNNEL, Beat.ROCK_RUN, Beat.WALL_MAZE, Beat.FLOOR_DROP, Beat.ENEMY_NEST, Beat.CRUSHER_ROOM, Beat.SPLIT_ROUTE, Beat.DESCEND_GATE)),
        Plan(7, "Bosque del atardecer", "Raíces con dientes", "Encuentra la ruta entre raíces, falsos descansos y paredes vivas.", "IMPOSIBLE JUSTO", AdventureBiome.FOREST_SUNSET, LevelExitKind.DESCENT, LevelExitKind.TUNNEL, "ravine-depth", "root-tunnel", 620f,
            listOf(Beat.FALSE_SAFE, Beat.LOW_TUNNEL, Beat.FRUIT_AMBUSH, Beat.WALL_MAZE, Beat.SHAFT_UP, Beat.ENEMY_NEST, Beat.SWITCH_GATE, Beat.FLOOR_DROP, Beat.CRUSHER_ROOM, Beat.LOW_TUNNEL)),
        Plan(8, "Bosque del atardecer", "La boca de la tierra", "Escapa del último bosque y entra al subsuelo.", "IMPOSIBLE+", AdventureBiome.FOREST_SUNSET, LevelExitKind.TUNNEL, LevelExitKind.CAVE, "root-tunnel", "earth-mouth", 590f,
            listOf(Beat.ROCK_RUN, Beat.SHAFT_UP, Beat.HIGH_BRIDGE, Beat.WALL_MAZE, Beat.COLLAPSING_BRIDGE, Beat.FRUIT_AMBUSH, Beat.DESCEND_GATE, Beat.CRUSHER_ROOM, Beat.MOVING_GAP, Beat.SHAFT_DOWN)),
        Plan(9, "Subsuelo", "La mina sin mapa", "Recorre galerías cerradas, encuentra la llave y abre la puerta minera.", "PESADILLA", AdventureBiome.UNDERGROUND, LevelExitKind.CAVE, LevelExitKind.DOOR, "earth-mouth", "locked-mine", 610f,
            listOf(Beat.LOW_TUNNEL, Beat.ROCK_RUN, Beat.WALL_MAZE, Beat.KEY_DETOUR, Beat.SHAFT_UP, Beat.CRUSHER_ROOM, Beat.SPLIT_ROUTE, Beat.FLOOR_DROP, Beat.ENEMY_NEST, Beat.DESCEND_GATE), requiresKey = true),
        Plan(10, "Subsuelo", "El elevador roto", "Sube y baja por un pozo mecánico hasta alcanzar las profundidades.", "PESADILLA+", AdventureBiome.UNDERGROUND, LevelExitKind.DOOR, LevelExitKind.LIFT, "locked-mine", "abyss-elevator", 610f,
            listOf(Beat.SHAFT_UP, Beat.MOVING_GAP, Beat.SHAFT_DOWN, Beat.CRUSHER_ROOM, Beat.BOUNCE_CHAMBER, Beat.WALL_MAZE, Beat.ROCK_RUN, Beat.SWITCH_GATE, Beat.FLOOR_DROP, Beat.FAN_SHAFT)),
        Plan(11, "Cavernas nocturnas", "Cristales que observan", "Cruza cámaras nocturnas donde el suelo y el techo atacan juntos.", "TERROR", AdventureBiome.CAVE_NIGHT, LevelExitKind.LIFT, LevelExitKind.CAVE, "abyss-elevator", "crystal-hollows", 470f,
            listOf(Beat.SPLIT_ROUTE, Beat.SHAFT_DOWN, Beat.ROCK_RUN, Beat.LOW_TUNNEL, Beat.ENEMY_NEST, Beat.WALL_MAZE, Beat.MOVING_GAP, Beat.CRUSHER_ROOM, Beat.FALSE_SAFE, Beat.CLIMB_GATE), companion = "Luma"),
        Plan(12, "Cavernas nocturnas", "La vena ardiente", "Avanza entre fuego, roca y caminos que desaparecen.", "TERROR+", AdventureBiome.CAVE_NIGHT, LevelExitKind.CAVE, LevelExitKind.TUNNEL, "crystal-hollows", "fire-vein", 430f,
            listOf(Beat.CRUSHER_ROOM, Beat.DESCEND_GATE, Beat.LOW_TUNNEL, Beat.FLOOR_DROP, Beat.ROCK_RUN, Beat.BOUNCE_CHAMBER, Beat.SHAFT_UP, Beat.ENEMY_NEST, Beat.WALL_MAZE, Beat.COLLAPSING_BRIDGE), weaponEnabled = true),
        Plan(13, "Cavernas nocturnas", "El pozo de ecos", "Escala un laberinto vertical sin caer en las rutas falsas.", "ABISMO", AdventureBiome.CAVE_NIGHT, LevelExitKind.TUNNEL, LevelExitKind.ASCENT, "fire-vein", "night-shaft", 620f,
            listOf(Beat.SHAFT_UP, Beat.FAN_SHAFT, Beat.MOVING_GAP, Beat.HIGH_BRIDGE, Beat.FALSE_SAFE, Beat.SHAFT_DOWN, Beat.SPLIT_ROUTE, Beat.CRUSHER_ROOM, Beat.BOUNCE_CHAMBER, Beat.SHAFT_UP), acechantePresent = true),
        Plan(14, "Cavernas nocturnas", "Muros que respiran", "Supera paredes, prensas y derrumbes que reaccionan a cada paso.", "ABISMO+", AdventureBiome.CAVE_NIGHT, LevelExitKind.ASCENT, LevelExitKind.RUIN_GATE, "night-shaft", "buried-door", 350f,
            listOf(Beat.WALL_MAZE, Beat.CRUSHER_ROOM, Beat.ROCK_RUN, Beat.DESCEND_GATE, Beat.LOW_TUNNEL, Beat.FLOOR_DROP, Beat.ENEMY_NEST, Beat.SWITCH_GATE, Beat.SPLIT_ROUTE, Beat.CLIMB_GATE), weaponEnabled = true),
        Plan(15, "Cavernas nocturnas", "La puerta enterrada", "Busca la última llave de las profundidades y abre el camino al amanecer.", "INHUMANO", AdventureBiome.CAVE_NIGHT, LevelExitKind.RUIN_GATE, LevelExitKind.DOOR, "buried-door", "dawn-lift", 520f,
            listOf(Beat.ENEMY_NEST, Beat.WALL_MAZE, Beat.KEY_DETOUR, Beat.ROCK_RUN, Beat.SHAFT_DOWN, Beat.CRUSHER_ROOM, Beat.FLOOR_DROP, Beat.MOVING_GAP, Beat.SHAFT_UP, Beat.FALSE_SAFE), requiresKey = true, weaponEnabled = true,
            outro = "La puerta deja entrar una luz cálida. GEO comienza el ascenso."),
        Plan(16, "Desierto del amanecer", "La escalera de arena", "Sube desde las cavernas por ruinas enterradas y pisos inestables.", "INHUMANO+", AdventureBiome.DESERT_DAWN, LevelExitKind.DOOR, LevelExitKind.ASCENT, "dawn-lift", "dune-maze", 620f,
            listOf(Beat.CLIMB_GATE, Beat.SHAFT_UP, Beat.COLLAPSING_BRIDGE, Beat.ROCK_RUN, Beat.WALL_MAZE, Beat.FAN_SHAFT, Beat.ENEMY_NEST, Beat.CRUSHER_ROOM, Beat.SPLIT_ROUTE, Beat.CLIMB_GATE), companion = "Nox", weaponEnabled = true),
        Plan(17, "Desierto del amanecer", "El laberinto de dunas", "Elige entre rutas altas y bajas mientras las ruinas se derrumban.", "LEYENDA", AdventureBiome.DESERT_DAWN, LevelExitKind.ASCENT, LevelExitKind.RUIN_GATE, "dune-maze", "ruin-courtyard", 360f,
            listOf(Beat.SPLIT_ROUTE, Beat.DESCEND_GATE, Beat.WALL_MAZE, Beat.FALSE_SAFE, Beat.FLOOR_DROP, Beat.ROCK_RUN, Beat.SHAFT_UP, Beat.MOVING_GAP, Beat.CRUSHER_ROOM, Beat.HIGH_BRIDGE), weaponEnabled = true),
        Plan(18, "Desierto del amanecer", "El patio de las llaves", "Encuentra la llave escondida entre columnas y abre la puerta solar.", "LEYENDA+", AdventureBiome.DESERT_DAWN, LevelExitKind.RUIN_GATE, LevelExitKind.DOOR, "ruin-courtyard", "sun-key-gate", 520f,
            listOf(Beat.SWITCH_GATE, Beat.KEY_DETOUR, Beat.WALL_MAZE, Beat.ENEMY_NEST, Beat.COLLAPSING_BRIDGE, Beat.CRUSHER_ROOM, Beat.SHAFT_DOWN, Beat.BOUNCE_CHAMBER, Beat.ROCK_RUN, Beat.CLIMB_GATE), requiresKey = true, weaponEnabled = true),
        Plan(19, "Desierto del amanecer", "Las ruinas imposibles", "Cruza la prueba final de mecanismos, trampas y rutas quebradas.", "MITO", AdventureBiome.DESERT_DAWN, LevelExitKind.DOOR, LevelExitKind.SUMMIT, "sun-key-gate", "summit-approach", 430f,
            listOf(Beat.CRUSHER_ROOM, Beat.WALL_MAZE, Beat.SHAFT_DOWN, Beat.LOW_TUNNEL, Beat.ENEMY_NEST, Beat.MOVING_GAP, Beat.FLOOR_DROP, Beat.SWITCH_GATE, Beat.HIGH_BRIDGE, Beat.SHAFT_UP), weaponEnabled = true, acechantePresent = true),
        Plan(20, "Cumbre del amanecer", "La última mentira", "Consigue la llave final y sobrevive al laberinto completo.", "FINAL ABSOLUTO", AdventureBiome.DESERT_DAWN, LevelExitKind.SUMMIT, LevelExitKind.DOOR, "summit-approach", "adventure-end", 380f,
            listOf(Beat.BOUNCE_CHAMBER, Beat.WALL_MAZE, Beat.KEY_DETOUR, Beat.CRUSHER_ROOM, Beat.SHAFT_DOWN, Beat.LOW_TUNNEL, Beat.ROCK_RUN, Beat.SWITCH_GATE, Beat.MOVING_GAP, Beat.ENEMY_NEST, Beat.FLOOR_DROP, Beat.SHAFT_UP), requiresKey = true, weaponEnabled = true, acechantePresent = true,
            intro = "La salida está cerca. Todas las reglas anteriores regresan juntas.", outro = "GEO alcanza la salida. La aventura termina, pero el mundo sigue desconfiando de él.")
    )

    fun build(number: Int): AdventureLevel {
        val plan = plans[(number.coerceIn(1, GeoGameRules.LEVEL_COUNT) - 1)]
        return MazeBuilder(plan).build()
    }
}
