package com.ganageo.app.ui.tools

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.GeoGameRunStart
import com.ganageo.app.model.GeoGameStatus
import com.ganageo.app.tools.AdventureBiome
import com.ganageo.app.tools.AdventureLevel
import com.ganageo.app.tools.CheckpointKind
import com.ganageo.app.tools.CrusherAxis
import com.ganageo.app.tools.CrusherStyle
import com.ganageo.app.tools.FallingBehavior
import com.ganageo.app.tools.FallingObjectKind
import com.ganageo.app.tools.GameEnemyKind
import com.ganageo.app.tools.GameHazard
import com.ganageo.app.tools.GamePickupKind
import com.ganageo.app.tools.GamePlatform
import com.ganageo.app.tools.GeoAdventureLevelFactory
import com.ganageo.app.tools.GeoGameRules
import com.ganageo.app.tools.GeoLifePackage
import com.ganageo.app.tools.HazardKind
import com.ganageo.app.tools.HazardOrientation
import com.ganageo.app.tools.LevelExitKind
import com.ganageo.app.tools.PlatformKind
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun GeoAdventuresScreen(
    viewModel: GanaGeoViewModel,
    onBack: () -> Unit,
    onMessage: (String) -> Unit,
    onImmersiveChanged: (Boolean) -> Unit = {},
    guestMode: Boolean = false
) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<GeoGameStatus?>(null) }
    var loading by remember { mutableStateOf(true) }
    var localMode by remember { mutableStateOf(guestMode) }
    var activeRun by remember { mutableStateOf<GeoGameRunStart?>(null) }
    var activeLevel by rememberSaveable { mutableIntStateOf(1) }
    var pendingPurchase by remember { mutableStateOf<GeoLifePackage?>(null) }
    var selectedLifeType by rememberSaveable { mutableStateOf("free") }
    var storyBeforeStart by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var pendingLifeType by remember { mutableStateOf("free") }
    var shownStories by remember { mutableStateOf(setOf<Int>()) }
    var countdownNowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var nextLifeDeadlineMs by remember { mutableLongStateOf(0L) }

    fun reload(preferLocal: Boolean = localMode) {
        scope.launch {
            loading = true
            viewModel.loadGeoGameStatus(preferLocal)
                .onSuccess {
                    status = it
                    localMode = it.isLocalTest
                    activeLevel = activeLevel.coerceAtMost(it.unlockedLevel.coerceAtLeast(1))
                }
                .onFailure { onMessage(it.message ?: "No se pudo cargar Geo Aventuras.") }
            loading = false
        }
    }

    fun startLevel(level: Int, lifeType: String, skipStory: Boolean = false) {
        val levelData = GeoAdventureLevelFactory.build(level)
        if (!skipStory && levelData.introStory != null && level !in shownStories) {
            pendingLifeType = lifeType
            storyBeforeStart = level to levelData.introStory
            shownStories = shownStories + level
            return
        }
        scope.launch {
            loading = true
            viewModel.startGeoGameRun(level, lifeType, localMode)
                .onSuccess {
                    activeLevel = level
                    activeRun = it
                }
                .onFailure { onMessage(it.message ?: "No se pudo iniciar el nivel.") }
            loading = false
        }
    }

    fun advanceLevel(level: Int, lifeType: String) {
        if (level > GeoGameRules.LEVEL_COUNT) {
            activeRun = null
            onImmersiveChanged(false)
            reload(if (guestMode) true else localMode)
            return
        }
        scope.launch {
            loading = true
            viewModel.startGeoGameRun(level, lifeType, localMode)
                .onSuccess {
                    activeLevel = level
                    activeRun = it
                }
                .onFailure {
                    onMessage(it.message ?: "No quedan vidas disponibles para continuar la aventura.")
                    activeRun = null
                    onImmersiveChanged(false)
                    reload(if (guestMode) true else localMode)
                }
            loading = false
        }
    }

    fun chooseLevel(level: Int) {
        val current = status ?: return
        if (level > current.unlockedLevel || loading) return
        val canUsePremium = !guestMode &&
            current.premiumLives > 0 &&
            current.premiumUsedToday < current.premiumDailyLimit
        val lifeType = if (selectedLifeType == "premium" && canUsePremium) "premium" else "free"
        if (lifeType == "free" && current.freeLives <= 0) {
            onMessage("No tienes vidas rojas disponibles. Espera la recuperación o inicia sesión para revisar tus opciones.")
            return
        }
        if (selectedLifeType == "premium" && !canUsePremium) selectedLifeType = "free"
        startLevel(level, lifeType)
    }

    fun buyPackage(packageInfo: GeoLifePackage) {
        scope.launch {
            loading = true
            viewModel.buyGeoGameLives(packageInfo.code)
                .onSuccess { purchase ->
                    localMode = purchase.isLocalTest
                    onMessage("Recibiste ${purchase.livesAdded} vida(s) dorada(s). Los Rewards se liberan tras 20 segundos activos.")
                    status = viewModel.loadGeoGameStatus(localMode).getOrNull() ?: status
                }
                .onFailure { onMessage(it.message ?: "No se pudieron comprar vidas.") }
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload(guestMode) }
    LaunchedEffect(status?.freeLives, status?.nextFreeLifeInSeconds) {
        val remainingSeconds = status?.nextFreeLifeInSeconds ?: 0L
        countdownNowMs = System.currentTimeMillis()
        nextLifeDeadlineMs = if (remainingSeconds > 0L) {
            countdownNowMs + remainingSeconds * 1_000L
        } else {
            0L
        }
        while (nextLifeDeadlineMs > 0L) {
            countdownNowMs = System.currentTimeMillis()
            if (countdownNowMs >= nextLifeDeadlineMs) {
                nextLifeDeadlineMs = 0L
                reload(localMode)
                break
            }
            delay(1_000L)
        }
    }

    DisposableEffect(activeRun) {
        onImmersiveChanged(activeRun != null)
        onDispose { if (activeRun != null) onImmersiveChanged(false) }
    }

    storyBeforeStart?.let { (level, story) ->
        StoryDialog(
            title = "${when (level) {
                in 1..4 -> "Acto 1 · Bosque de día"
                in 5..8 -> "Acto 2 · Descenso al atardecer"
                in 9..10 -> "Acto 3 · Subsuelo"
                in 11..15 -> "Acto 4 · Cavernas nocturnas"
                else -> "Acto 5 · Desierto del amanecer"
            }} · ${GeoAdventureLevelFactory.build(level).levelName}",
            story = story,
            onDismiss = { storyBeforeStart = null },
            onContinue = {
                storyBeforeStart = null
                startLevel(level, pendingLifeType)
            }
        )
    }


    pendingPurchase?.let { pack ->
        AlertDialog(
            onDismissRequest = { if (!loading) pendingPurchase = null },
            title = { Text("Confirmar compra de vidas") },
            text = { Text("Comprarás ${pack.lives} vida(s) dorada(s) por ${pack.creditCost} créditos.") },
            confirmButton = {
                Button(onClick = { pendingPurchase = null; buyPackage(pack) }, enabled = !loading) { Text("Comprar") }
            },
            dismissButton = { TextButton(onClick = { pendingPurchase = null }, enabled = !loading) { Text("Cancelar") } }
        )
    }

    activeRun?.let { run ->
        key(activeLevel, run.runId) {
            GeoAdventureGame(
                level = GeoAdventureLevelFactory.build(activeLevel),
                run = run,
                viewModel = viewModel,
                onMessage = onMessage,
                onExit = {
                    activeRun = null
                    onImmersiveChanged(false)
                    reload(if (guestMode) true else localMode)
                },
                onQuit = {
                    activeRun = null
                    onImmersiveChanged(false)
                    onBack()
                },
                onAdvance = { nextLevel, lifeType -> advanceLevel(nextLevel, lifeType) },
                guestMode = guestMode
            )
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader("Geo Aventuras", "20 laberintos troll · tensión constante", onBack)
        if (loading && status == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = NeonGreen) }
            return@Column
        }
        val current = status ?: GeoGameStatus(isLocalTest = true)
        val displayedNextLifeSeconds = when {
            current.freeLives >= GeoGameRules.MAX_FREE_LIVES -> 0L
            nextLifeDeadlineMs > 0L -> ((nextLifeDeadlineMs - countdownNowMs).coerceAtLeast(0L) + 999L) / 1_000L
            else -> current.nextFreeLifeInSeconds
        }
        val nextLifeText = if (current.freeLives >= GeoGameRules.MAX_FREE_LIVES || displayedNextLifeSeconds <= 0L) {
            "Vidas rojas completas"
        } else {
            val min = displayedNextLifeSeconds / 60
            val sec = displayedNextLifeSeconds % 60
            "Próxima vida en %02d:%02d".format(min, sec)
        }
        val premiumAvailable = !guestMode && current.premiumLives > 0 && current.premiumUsedToday < current.premiumDailyLimit
        LaunchedEffect(premiumAvailable) {
            if (!premiumAvailable && selectedLifeType == "premium") selectedLifeType = "free"
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF102E45)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("GEO contra un planeta tramposo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(
                            "Una aventura continua de 20 niveles: bosque, atardecer, profundidades, cavernas nocturnas y ruinas del desierto. Cada salida conecta con el siguiente nivel.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (guestMode) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                LifeInfo("❤️", current.freeLives.toString(), "Vidas rojas", Modifier.weight(1f))
                                LifeInfo("🏆", current.bestScore.toString(), "Mejor puntaje", Modifier.weight(1f))
                            }
                            Text("Modo invitado: juego básico sin compras ni vidas doradas.", color = NeonGreen, fontWeight = FontWeight.Bold)
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                LifeInfo("❤️", current.freeLives.toString(), "Rojas", Modifier.weight(1f))
                                LifeInfo("💛", current.premiumLives.toString(), "Doradas", Modifier.weight(1f))
                                LifeInfo("🏆", current.bestScore.toString(), "Mejor puntaje", Modifier.weight(1f))
                            }
                            Text("Vida para el próximo nivel", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = { selectedLifeType = "free" },
                                    enabled = current.freeLives > 0,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selectedLifeType == "free") Color(0xFFE53935) else Color(0xFF263A45)
                                    )
                                ) { Text("❤️ Roja") }
                                OutlinedButton(
                                    onClick = { selectedLifeType = "premium" },
                                    enabled = premiumAvailable,
                                    modifier = Modifier.weight(1f)
                                ) { Text("💛 Dorada") }
                            }
                            Text("Comprar vidas doradas", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                LifePackCard("1 vida", "2 créditos", "life_1", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                                LifePackCard("5 vidas", "10 créditos", "life_5", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                                LifePackCard("15 vidas", "30 créditos", "life_15", !loading, Modifier.weight(1f)) { pendingPurchase = GeoGameRules.packageByCode(it) }
                            }
                        }
                        Text(nextLifeText, color = NeonGreen, fontWeight = FontWeight.Bold)
                        Text("Cada partida comienza con ${GeoGameRules.GAME_LIVES_PER_RUN} vidas internas. Cada muerte consume exactamente 1.", color = Gold, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Mapa de los 20 niveles", style = MaterialTheme.typography.titleLarge)
                        Text("Desbloqueado: ${current.unlockedLevel}/20", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { reload(if (guestMode) true else localMode) }) { Icon(Icons.Rounded.Refresh, contentDescription = "Actualizar", tint = NeonGreen) }
                }
            }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxWidth().height(500.dp),
                    userScrollEnabled = false,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items((1..20).toList()) { level ->
                        val data = GeoAdventureLevelFactory.build(level)
                        LevelButton(
                            level = level,
                            unlocked = level <= current.unlockedLevel,
                            importantStory = level in setOf(1, 5, 9, 11, 16, 20),
                            difficultyLabel = data.difficultyLabel,
                            onClick = { chooseLevel(level) }
                        )
                    }
                }
            }
        }

    }
}

@Composable
private fun StoryDialog(title: String, story: String, onDismiss: () -> Unit, onContinue: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(story, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        confirmButton = { Button(onClick = onContinue) { Text("Continuar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Volver") } }
    )
}

@Composable
private fun LifeInfo(symbol: String, value: String, label: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(14.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(symbol)
        Spacer(Modifier.width(6.dp))
        Column { Text(value, fontWeight = FontWeight.Bold); Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun LifePackCard(title: String, cost: String, code: String, enabled: Boolean, modifier: Modifier, onBuy: (String) -> Unit) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = Gold)
            Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(cost, color = NeonGreen, textAlign = TextAlign.Center)
            FilledTonalButton(onClick = { onBuy(code) }, enabled = enabled, contentPadding = PaddingValues(horizontal = 9.dp)) { Text("Comprar") }
        }
    }
}

@Composable
private fun LevelButton(
    level: Int,
    unlocked: Boolean,
    importantStory: Boolean,
    difficultyLabel: String,
    onClick: () -> Unit
) {
    val color = when (level) {
        in 1..5 -> Color(0xFF8EE38A)
        in 6..10 -> Color(0xFFFF9F43)
        in 11..15 -> Color(0xFF8D8BFF)
        else -> Color(0xFFFFC857)
    }
    FilledTonalButton(onClick = onClick, enabled = unlocked, modifier = Modifier.height(78.dp), contentPadding = PaddingValues(4.dp)) {
        if (unlocked) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(level.toString(), fontWeight = FontWeight.Bold)
                Text(difficultyLabel, style = MaterialTheme.typography.labelSmall, color = color, maxLines = 1)
                if (importantStory) Text("• historia", style = MaterialTheme.typography.labelSmall, color = Gold)
            }
        } else Icon(Icons.Rounded.Lock, contentDescription = "Bloqueado", modifier = Modifier.size(18.dp))
    }
}

private enum class GameOutcome { WON, LOST }
private enum class DeathCause { HAZARD, VOID }
private enum class ExitTarget { LEVELS, GEO_ADVENTURES }
private data class Bullet(val x: Float, val y: Float, val direction: Float)
private data class EnemyBullet(val x: Float, val y: Float, val velocityX: Float, val velocityY: Float)
private data class EnemyRuntime(
    val x: Float,
    val y: Float,
    val direction: Float,
    val health: Int,
    val lastActionAt: Long = 0L,
    val velocityY: Float = 0f
)
private data class FallingRuntime(
    val x: Float,
    val y: Float,
    val velocityX: Float = 0f,
    val velocityY: Float = 0f,
    val triggeredAt: Long? = null,
    val landedAt: Long? = null,
    val explodedAt: Long? = null,
    val chaseStartedAt: Long? = null,
    val travelled: Float = 0f,
    val disabled: Boolean = false
)
private data class ChasingHoleRuntime(
    val x: Float,
    val active: Boolean = false,
    val travelled: Float = 0f,
    val closed: Boolean = false
)
private data class CrusherRuntime(val triggeredAt: Long? = null)
private data class TreeRuntime(
    val fallStartedAt: Long? = null
)

@Composable
private fun GeoAdventureGame(
    level: AdventureLevel,
    run: GeoGameRunStart,
    viewModel: GanaGeoViewModel,
    onMessage: (String) -> Unit,
    onExit: () -> Unit,
    onQuit: () -> Unit,
    onAdvance: (Int, String) -> Unit,
    guestMode: Boolean = false
) {
    ImmersiveLandscapeEffect()
    val context = LocalContext.current
    val worldIndex = (level.number - 1) / 5
    val audio = remember(level.number) { GameAudioController(context, worldIndex) }
    val vibrator = remember { context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator }
    var musicEnabled by rememberSaveable { mutableStateOf(true) }
    var effectsEnabled by rememberSaveable { mutableStateOf(true) }
    var vibrationEnabled by rememberSaveable { mutableStateOf(true) }

    fun vibrate(duration: Long, amplitude: Int = 130) {
        if (!vibrationEnabled || vibrator == null) return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(duration, amplitude.coerceIn(1, 255)))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(duration)
            }
        }
    }

    DisposableEffect(audio) {
        audio.setMusicEnabled(musicEnabled)
        audio.setEffectsEnabled(effectsEnabled)
        audio.startMusic()
        onDispose { audio.release() }
    }
    LaunchedEffect(musicEnabled, effectsEnabled) {
        audio.setMusicEnabled(musicEnabled)
        audio.setEffectsEnabled(effectsEnabled)
    }

    val playerWidth = 44f
    val playerHeight = 58f
    val appleRadius = 12f
    val appleDiameter = appleRadius * 2f
    val maxLives = GeoGameRules.attemptsForLevel(level.number)
    var playerX by remember(level.number) { mutableFloatStateOf(level.spawnX) }
    var playerY by remember(level.number) { mutableFloatStateOf(level.spawnY) }
    var velocityY by remember(level.number) { mutableFloatStateOf(0f) }
    var moveDirection by remember { mutableFloatStateOf(0f) }
    var facing by remember { mutableFloatStateOf(1f) }
    var jumpQueued by remember { mutableStateOf(false) }
    var shootQueued by remember { mutableStateOf(false) }
    var interactQueued by remember { mutableStateOf(false) }
    var onGround by remember { mutableStateOf(false) }
    var jumpsRemaining by remember(level.number) { mutableIntStateOf(2) }
    var jumpBufferUntil by remember { mutableLongStateOf(0L) }
    var lastGroundedAt by remember { mutableLongStateOf(0L) }
    var lastPlayerShotAt by remember { mutableLongStateOf(0L) }
    var lastFanSoundAt by remember { mutableLongStateOf(-1_000L) }
    var elapsedMs by remember { mutableLongStateOf(0L) }
    val treeWarningMs = 280L
    val treeFallDurationMs = 820f
    fun treeFallProgress(startedAt: Long?): Float {
        val started = startedAt ?: return 0f
        return ((elapsedMs - started - treeWarningMs) / treeFallDurationMs).coerceIn(0f, 1f)
    }
    fun treeWarningActive(startedAt: Long?): Boolean {
        val started = startedAt ?: return false
        return elapsedMs - started in 0L until treeWarningMs
    }
    var livesRemaining by remember(level.number) { mutableIntStateOf(maxLives) }
    var deathCount by remember(level.number) { mutableIntStateOf(0) }
    var deathPending by remember(level.number) { mutableStateOf(false) }
    var deathCause by remember(level.number) { mutableStateOf(DeathCause.HAZARD) }
    var pendingExitTarget by remember(level.number) { mutableStateOf<ExitTarget?>(null) }
    var respawnX by remember(level.number) { mutableFloatStateOf(level.spawnX) }
    var respawnY by remember(level.number) { mutableFloatStateOf(level.spawnY) }
    var activeCheckpoint by remember(level.number) { mutableIntStateOf(-1) }
    var collected by remember(level.number) { mutableStateOf(setOf<Int>()) }
    var collectedKeys by remember(level.number) { mutableStateOf(setOf<Int>()) }
    var activeSwitches by remember(level.number) { mutableStateOf(setOf<Int>()) }
    var destroyedCrates by remember { mutableStateOf(setOf<Int>()) }
    var collectedPickups by remember { mutableStateOf(setOf<Int>()) }
    var activatedCheckpoints by remember { mutableStateOf(setOf<Int>()) }
    var revealedCheckpoints by remember { mutableStateOf(setOf<Int>()) }
    var brokenDecoys by remember { mutableStateOf(setOf<Int>()) }
    val platformTriggeredAt = remember(level.number) { mutableStateMapOf<Int, Long>() }
    val hazardTriggeredAt = remember(level.number) { mutableStateMapOf<Int, Long>() }
    val fallingRuntime = remember(level.number) {
        mutableStateListOf<FallingRuntime>().apply { addAll(level.fallingObjects.map { FallingRuntime(it.x, it.startY) }) }
    }
    val treeRuntime = remember(level.number) {
        mutableStateListOf<TreeRuntime>().apply { addAll(level.fallingObjects.map { TreeRuntime() }) }
    }
    val chasingHoleRuntime = remember(level.number) {
        mutableStateListOf<ChasingHoleRuntime>().apply { addAll(level.chasingHoles.map { ChasingHoleRuntime(it.startX) }) }
    }
    val crusherRuntime = remember(level.number) {
        mutableStateListOf<CrusherRuntime>().apply { addAll(level.crushers.map { CrusherRuntime() }) }
    }

    // A floor trap is represented by removing a rectangular piece of the real platform.
    // It is not drawn as an oval, cone or independent black object.
    fun splitPlatformByOpenFloor(platform: GamePlatform): List<GamePlatform> {
        var pieces = listOf(platform)
        level.chasingHoles.forEachIndexed { index, trap ->
            val runtime = chasingHoleRuntime.getOrNull(index) ?: return@forEachIndexed
            if (!runtime.active || runtime.closed) return@forEachIndexed
            val surfaceY = trap.y + 28f
            if (abs(platform.y - surfaceY) > 14f) return@forEachIndexed

            val openingStart = runtime.x.coerceIn(
                minOf(trap.surfaceStartX, trap.surfaceEndX),
                maxOf(trap.surfaceStartX, trap.surfaceEndX)
            )
            val openingEnd = (runtime.x + trap.width).coerceIn(
                minOf(trap.surfaceStartX, trap.surfaceEndX),
                maxOf(trap.surfaceStartX, trap.surfaceEndX)
            )
            if (openingEnd <= openingStart) return@forEachIndexed

            pieces = pieces.flatMap { piece ->
                val pieceEnd = piece.x + piece.width
                if (openingEnd <= piece.x || openingStart >= pieceEnd) {
                    listOf(piece)
                } else {
                    buildList {
                        val leftWidth = (openingStart - piece.x).coerceAtLeast(0f)
                        if (leftWidth > 5f) add(piece.copy(width = leftWidth))
                        val rightX = maxOf(openingEnd, piece.x)
                        val rightWidth = (pieceEnd - rightX).coerceAtLeast(0f)
                        if (rightWidth > 5f) add(piece.copy(x = rightX, width = rightWidth))
                    }
                }
            }
        }
        return pieces
    }
    var outcome by remember { mutableStateOf<GameOutcome?>(null) }
    var paused by remember { mutableStateOf(false) }
    var activated by remember(run.runId) { mutableStateOf(!run.needsActivation) }
    var activating by remember { mutableStateOf(false) }
    var activationRewards by remember { mutableLongStateOf(0L) }
    var reportingResult by remember { mutableStateOf(false) }
    var resultSaved by remember { mutableStateOf(false) }
    var resultError by remember { mutableStateOf<String?>(null) }
    var reportAttempt by remember { mutableIntStateOf(0) }
    var autoTransitionStarted by remember(level.number, run.runId) { mutableStateOf(false) }
    var shieldHits by remember { mutableIntStateOf(0) }
    var weaponPowerUntil by remember { mutableLongStateOf(0L) }
    var invulnerableUntil by remember { mutableLongStateOf(900L) }
    var acechanteX by remember(level.number) { mutableFloatStateOf(-750f) }
    var objectiveHint by remember(level.number) { mutableStateOf<String?>(level.objective) }
    var objectiveHintUntil by remember(level.number) { mutableLongStateOf(6_000L) }
    val bullets = remember(level.number) { mutableStateListOf<Bullet>() }
    val enemyBullets = remember(level.number) { mutableStateListOf<EnemyBullet>() }
    val enemies = remember(level.number) {
        mutableStateListOf<EnemyRuntime>().apply {
            addAll(level.enemies.mapIndexed { index, enemy -> EnemyRuntime(enemy.x, enemy.y, if (index % 2 == 0) 1f else -1f, enemy.health) })
        }
    }

    fun endGame(result: GameOutcome) {
        if (outcome != null) return
        outcome = result
        audio.play(if (result == GameOutcome.WON) GameSound.VICTORY else GameSound.DEFEAT, 0.9f)
        audio.pauseMusic()
    }

    fun resetTransientTraps() {
        platformTriggeredAt.clear()
        hazardTriggeredAt.clear()
        level.fallingObjects.forEachIndexed { index, trap ->
            if (index < fallingRuntime.size) fallingRuntime[index] = FallingRuntime(trap.x, trap.startY)
            if (index < treeRuntime.size) treeRuntime[index] = TreeRuntime()
        }
        level.chasingHoles.forEachIndexed { index, trap ->
            if (index < chasingHoleRuntime.size) chasingHoleRuntime[index] = ChasingHoleRuntime(trap.startX)
        }
        level.crushers.forEachIndexed { index, _ ->
            if (index < crusherRuntime.size) crusherRuntime[index] = CrusherRuntime()
        }
        bullets.clear()
        enemyBullets.clear()
        enemies.clear()
        enemies.addAll(level.enemies.mapIndexed { index, enemy ->
            EnemyRuntime(enemy.x, enemy.y, if (index % 2 == 0) 1f else -1f, enemy.health)
        })
    }

    fun respawn() {
        playerX = respawnX
        playerY = respawnY
        velocityY = 0f
        moveDirection = 0f
        jumpQueued = false
        shootQueued = false
        interactQueued = false
        jumpsRemaining = 2
        onGround = false
        invulnerableUntil = elapsedMs + 1_100L
        resetTransientTraps()
    }

    fun insideRealCheckpointSafeZone(): Boolean {
        val centerX = playerX + playerWidth / 2f
        val centerY = playerY + playerHeight / 2f
        return level.checkpoints.any { checkpoint ->
            checkpoint.kind != CheckpointKind.DECOY &&
                centerX in (checkpoint.x - 125f)..(checkpoint.x + 165f) &&
                centerY in (checkpoint.y - 95f)..(checkpoint.y + 125f)
        }
    }

    fun loseLife(
        @Suppress("UNUSED_PARAMETER") reason: String,
        cause: DeathCause = DeathCause.HAZARD
    ) {
        if (outcome != null || deathPending || elapsedMs < invulnerableUntil || insideRealCheckpointSafeZone()) return
        if (shieldHits > 0) {
            shieldHits--
            invulnerableUntil = elapsedMs + 900L
            audio.play(GameSound.HIT, 0.75f)
            vibrate(80, 90)
            return
        }
        livesRemaining--
        deathCount++
        deathPending = true
        deathCause = cause
        moveDirection = 0f
        jumpQueued = false
        shootQueued = false
        interactQueued = false
        velocityY = 0f
        objectiveHint = null
        objectiveHintUntil = 0L
        audio.play(if (run.lifeType == "premium") GameSound.DEATH_GOLD else GameSound.DEATH_RED, 0.92f, 0.96f + (deathCount % 4) * 0.03f)
        vibrate(if (cause == DeathCause.VOID) 70 else 180, if (cause == DeathCause.VOID) 90 else 190)
    }

    LaunchedEffect(deathPending, livesRemaining, deathCause) {
        if (!deathPending) return@LaunchedEffect
        when (deathCause) {
            DeathCause.VOID -> delay(GeoGameRules.VOID_RESPAWN_DELAY_MS)
            DeathCause.HAZARD -> delay(GeoGameRules.DEATH_REVEAL_MS)
        }
        if (livesRemaining <= 0) {
            endGame(GameOutcome.LOST)
        } else {
            respawn()
        }
        deathPending = false
    }

    BackHandler {
        if (outcome == null) paused = !paused else onExit()
    }

    LaunchedEffect(paused, outcome, musicEnabled) {
        if (paused || outcome != null || !musicEnabled) audio.pauseMusic() else audio.startMusic()
    }
    LaunchedEffect(paused, outcome, deathPending) {
        delay(80L)
        context.findActivity()?.window?.let { window ->
            val appBackground = android.graphics.Color.rgb(6, 29, 18)
            window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(appBackground))
            window.decorView.setBackgroundColor(appBackground)
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
            window.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN or
                    android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
            WindowCompat.setDecorFitsSystemWindows(window, false)
            ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { _, _ ->
                WindowInsetsCompat.CONSUMED
            }
            ViewCompat.requestApplyInsets(window.decorView)
            WindowInsetsControllerCompat(window, window.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    LaunchedEffect(level.number, outcome, paused, deathPending) {
        if (outcome != null || paused || deathPending) return@LaunchedEffect
        var previousNanos = withFrameNanos { it }
        while (outcome == null && !paused && !deathPending) {
            val now = withFrameNanos { it }
            val dt = ((now - previousNanos) / 1_000_000_000f).coerceIn(0f, 0.035f)
            previousNanos = now
            elapsedMs += (dt * 1000).toLong()

            level.checkpoints.forEachIndexed { index, cp ->
                if (cp.kind == CheckpointKind.SAFE || (level.number <= 4 && cp.kind == CheckpointKind.DECOY) || playerX >= cp.appearTriggerX) revealedCheckpoints = revealedCheckpoints + index
            }
            val playerCenterX = playerX + playerWidth / 2f
            level.platforms.forEachIndexed { index, platform ->
                val closeEnough = playerCenterX >= platform.x - 38f && playerCenterX <= platform.x + platform.width + 18f
                val verticallyNear = playerY + playerHeight >= platform.y - 120f && playerY <= platform.y + platform.height + 45f
                val reactiveFloor = platform.kind == PlatformKind.PROXIMITY_DISAPPEARING || platform.kind == PlatformKind.DISAPPEARING
                if (reactiveFloor && closeEnough && verticallyNear && index !in platformTriggeredAt) {
                    platformTriggeredAt[index] = elapsedMs
                    audio.play(GameSound.HOLE, 0.62f, 1.12f)
                }
            }
            level.hazards.forEachIndexed { index, hazard ->
                val hazardCenterX = hazard.x + hazard.width / 2f
                val closeEnough = playerX >= hazard.triggerX && abs(playerCenterX - hazardCenterX) <= max(175f, hazard.width + 110f)
                if (hazard.kind == HazardKind.HIDDEN_SPIKES && closeEnough && index !in hazardTriggeredAt) {
                    hazardTriggeredAt[index] = elapsedMs
                    audio.play(GameSound.SPIKE, 0.58f, 1.18f + (index % 3) * 0.08f)
                }
            }
            level.fallingObjects.forEachIndexed { index, trap ->
                val runtime = fallingRuntime[index]
                if (runtime.triggeredAt == null && playerX >= trap.triggerX && playerX < trap.x + 300f) {
                    fallingRuntime[index] = runtime.copy(triggeredAt = elapsedMs)
                    audio.play(GameSound.FRUIT_DROP, 0.58f, 0.90f + (index % 4) * 0.05f)
                }
            }

            val movingPlatforms = level.movingPlatforms.mapIndexed { index, moving ->
                val phase = elapsedMs / 1000f / moving.periodSeconds * (Math.PI * 2.0) + index * 0.68
                val offset = sin(phase).toFloat() * moving.travel
                GamePlatform(
                    x = if (moving.vertical) moving.x else moving.x + offset,
                    y = if (moving.vertical) moving.y + offset else moving.y,
                    width = moving.width,
                    height = 26f
                )
            }

            fun platformVisible(index: Int, p: GamePlatform): Boolean = when (p.kind) {
                PlatformKind.SOLID, PlatformKind.BOUNCE -> true
                PlatformKind.REVEALING -> playerX >= p.triggerX || activeSwitches.isNotEmpty()
                PlatformKind.DISAPPEARING, PlatformKind.PROXIMITY_DISAPPEARING -> {
                    val delay = if (p.kind == PlatformKind.DISAPPEARING) maxOf(p.delayMs, 700L) else p.delayMs
                    platformTriggeredAt[index]?.let { elapsedMs - it <= delay } ?: true
                }
                PlatformKind.FALLING -> {
                    val triggered = platformTriggeredAt[index]
                    triggered == null || elapsedMs - triggered <= p.delayMs
                }
            }

            val visibleBasePlatforms = level.platforms.mapIndexedNotNull { index, p ->
                if (!platformVisible(index, p)) return@mapIndexedNotNull null
                if (p.kind == PlatformKind.FALLING) {
                    val triggered = platformTriggeredAt[index]
                    if (triggered != null) {
                        val fallOffset = ((elapsedMs - triggered).coerceAtLeast(0L) / 4f).coerceAtMost(120f)
                        p.copy(y = p.y + fallOffset)
                    } else p
                } else p
            }
            val collisionPlatforms = buildList {
                addAll(visibleBasePlatforms.flatMap(::splitPlatformByOpenFloor))
                addAll(movingPlatforms)
                activeSwitches.forEach { index ->
                    level.switches.getOrNull(index)?.let { add(GamePlatform(it.opensAtX, 520f, 235f, 26f)) }
                }
                level.fallingObjects.forEachIndexed { index, trap ->
                    val runtime = fallingRuntime.getOrNull(index)
                    if (trap.becomesPlatform && runtime?.landedAt != null && !runtime.disabled) {
                        add(
                            GamePlatform(
                                x = runtime.x,
                                y = runtime.y,
                                width = trap.size,
                                height = 18f,
                                kind = PlatformKind.SOLID
                            )
                        )
                    }
                    if (!trap.treeFallsAfterTrap || trap.kind != FallingObjectKind.FRUIT) return@forEachIndexed
                    val progress = treeFallProgress(treeRuntime.getOrNull(index)?.fallStartedAt)
                    if (progress < 0.98f) return@forEachIndexed
                    val trunkLength = (trap.targetY - (trap.startY - 28f)).coerceAtLeast(180f)
                    val baseX = trap.x + trap.size / 2f
                    val direction = if ((index + level.number) % 2 == 0) 1f else -1f
                    val tipX = baseX + direction * trunkLength
                    val platformStart = minOf(baseX, tipX) + 24f
                    val platformWidth = (kotlin.math.abs(tipX - baseX) - 48f).coerceAtLeast(120f)
                    add(
                        GamePlatform(
                            x = platformStart,
                            y = trap.targetY - 11f,
                            width = platformWidth,
                            height = 22f,
                            kind = PlatformKind.SOLID
                        )
                    )
                }
            }
            val blockingBarriers = level.barriers.filter { it.switchIndex !in activeSwitches }

            val wasOnGround = onGround
            if (wasOnGround) lastGroundedAt = elapsedMs
            val previousBottom = playerY + playerHeight
            if (moveDirection != 0f) facing = moveDirection.sign
            var horizontalForce = moveDirection * (278f + level.number * 3.4f)
            val currentRectForFan = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)
            level.fans.forEachIndexed { index, fan ->
                val cyclingOn = fan.cycleMs <= 0 || ((elapsedMs + fan.phaseMs) % fan.cycleMs) < fan.cycleMs * 0.66f
                if (!cyclingOn) return@forEachIndexed
                val reversed = fan.switchIndex?.let { it in activeSwitches } == true
                val fanRect = Rect(fan.x, fan.y, fan.x + fan.width, fan.y + fan.height)
                if (currentRectForFan.overlaps(fanRect)) {
                    horizontalForce += if (reversed) -fan.forceX else fan.forceX
                    velocityY += (if (reversed) -fan.forceY else fan.forceY) * dt
                    if (elapsedMs - lastFanSoundAt >= 700L) {
                        audio.play(GameSound.FAN, 0.14f)
                        lastFanSoundAt = elapsedMs
                    }
                }
            }
            val candidateX = (playerX + horizontalForce * dt).coerceIn(0f, level.width - playerWidth)
            val candidateRect = Rect(candidateX, playerY, candidateX + playerWidth, playerY + playerHeight)
            val blockedByBarrier = blockingBarriers.any {
                candidateRect.overlaps(Rect(it.x, it.y, it.x + it.width, it.y + it.height))
            }
            val blockedByTerrain = collisionPlatforms.any { platform ->
                candidateRect.overlaps(Rect(platform.x, platform.y, platform.x + platform.width, platform.y + platform.height))
            }
            if (!blockedByBarrier && !blockedByTerrain) {
                playerX = candidateX
            }

            if (jumpQueued) {
                jumpBufferUntil = elapsedMs + 180L
                jumpQueued = false
            }
            val canGroundJump = wasOnGround || elapsedMs - lastGroundedAt <= 125L
            if (jumpBufferUntil >= elapsedMs && (canGroundJump || jumpsRemaining > 0)) {
                val double = !canGroundJump
                velocityY = if (double) -535f else -655f
                jumpsRemaining = if (double) (jumpsRemaining - 1).coerceAtLeast(0) else 1
                onGround = false
                jumpBufferUntil = 0L
                audio.play(if (double) GameSound.DOUBLE_JUMP else GameSound.JUMP, 0.8f)
            }

            velocityY += 1_470f * dt
            var nextY = playerY + velocityY * dt
            onGround = false
            val previousTop = playerY

            // Los techos y bloques del laberinto son sólidos: GEO ya no atraviesa
            // estructuras de tierra al saltar desde abajo.
            if (velocityY < 0f) {
                collisionPlatforms.forEach { p ->
                    val overlapsX = playerX + playerWidth > p.x + 3f && playerX < p.x + p.width - 3f
                    val underside = p.y + p.height
                    if (overlapsX && previousTop >= underside - 10f && nextY <= underside) {
                        nextY = underside
                        velocityY = 0f
                    }
                }
            }

            val nextBottom = nextY + playerHeight
            collisionPlatforms.forEach { p ->
                val overlapsX = playerX + playerWidth > p.x + 2f && playerX < p.x + p.width - 2f
                if (overlapsX && velocityY >= 0f && previousBottom <= p.y + 12f && nextBottom >= p.y) {
                    nextY = p.y - playerHeight
                    velocityY = if (p.kind == PlatformKind.BOUNCE) -810f else 0f
                    onGround = p.kind != PlatformKind.BOUNCE
                    jumpsRemaining = if (p.kind == PlatformKind.BOUNCE) 1 else 2
                    lastGroundedAt = elapsedMs
                    if (!wasOnGround && velocityY == 0f) audio.play(GameSound.LAND, 0.18f, 0.92f + (level.number % 3) * 0.05f)
                    val baseIndex = level.platforms.indexOf(p)
                    if (baseIndex >= 0 && p.kind == PlatformKind.FALLING && platformTriggeredAt[baseIndex] == null) {
                        platformTriggeredAt[baseIndex] = elapsedMs
                        audio.play(GameSound.TRAP, 0.35f, 1.15f)
                    }
                }
            }
            playerY = nextY
            var playerRect = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)

            level.checkpoints.forEachIndexed { index, cp ->
                if (index !in revealedCheckpoints || index in brokenDecoys) return@forEachIndexed
                val cpRect = Rect(cp.x - 25f, cp.y - 30f, cp.x + 30f, cp.y + 65f)
                if (playerRect.overlaps(cpRect) && index !in activatedCheckpoints) {
                    if (cp.kind == CheckpointKind.DECOY) {
                        brokenDecoys = brokenDecoys + index
                        audio.play(GameSound.DECOY, 0.9f)
                        loseLife("El checkpoint falso explotó")
                        playerRect = Rect(playerX, playerY, playerX + playerWidth, playerY + playerHeight)
                    } else {
                        activatedCheckpoints = activatedCheckpoints + index
                        activeCheckpoint = index
                        respawnX = (cp.x + 18f).coerceIn(0f, level.width - playerWidth)
                        respawnY = (cp.y + 85f - playerHeight).coerceAtLeast(50f)
                        audio.play(GameSound.CHECKPOINT, 0.85f)
                        vibrate(70, 75)
                        objectiveHint = "Checkpoint ${activatedCheckpoints.count { level.checkpoints[it].kind != CheckpointKind.DECOY }} activado"
                        objectiveHintUntil = elapsedMs + 1_900L
                    }
                }
            }

            level.crystals.forEachIndexed { index, crystal ->
                if (index !in collected && playerRect.overlaps(Rect(crystal.x - 24f, crystal.y - 24f, crystal.x + 24f, crystal.y + 24f))) {
                    collected = collected + index
                    audio.play(GameSound.CRYSTAL, 0.75f, 1f + index * 0.08f)
                }
            }
            level.keys.forEachIndexed { index, key ->
                val visible = playerX >= key.revealTriggerX && (key.hiddenUntilSwitch == null || key.hiddenUntilSwitch in activeSwitches)
                if (visible && index !in collectedKeys && playerRect.overlaps(Rect(key.x - 28f, key.y - 28f, key.x + 28f, key.y + 28f))) {
                    collectedKeys = collectedKeys + index
                    audio.play(GameSound.PICKUP, 0.92f, 1.18f)
                    vibrate(80, 90)
                    objectiveHint = "Llave encontrada: la salida ya puede abrirse"
                    objectiveHintUntil = elapsedMs + 2_300L
                }
            }
            level.pickups.forEachIndexed { index, pickup ->
                if (index !in collectedPickups && playerRect.overlaps(Rect(pickup.x - 25f, pickup.y - 25f, pickup.x + 25f, pickup.y + 25f))) {
                    collectedPickups = collectedPickups + index
                    when (pickup.kind) {
                        GamePickupKind.ENERGY -> livesRemaining = (livesRemaining + 1).coerceAtMost(maxLives)
                        GamePickupKind.SHIELD -> shieldHits = (shieldHits + 1).coerceAtMost(2)
                        GamePickupKind.POWER -> weaponPowerUntil = elapsedMs + 25_000L
                    }
                    audio.play(GameSound.PICKUP, 0.8f)
                }
            }

            if (interactQueued) {
                var didInteract = false
                level.switches.forEachIndexed { index, sw ->
                    if (index !in activeSwitches && abs(playerX - sw.x) < 115f && abs(playerY - sw.y) < 130f) {
                        activeSwitches = activeSwitches + index
                        didInteract = true
                        audio.play(GameSound.BUTTON, 0.8f)
                        vibrate(55, 70)
                        objectiveHint = if (sw.reversesFans) "Interruptor activado: algunas corrientes cambiaron de dirección" else "Interruptor activado: una barrera se abrió"
                        objectiveHintUntil = elapsedMs + 2_100L
                    }
                }
                val crateIndex = level.crates.indices.firstOrNull { idx -> idx !in destroyedCrates && abs(playerX - level.crates[idx].x) < 95f }
                if (crateIndex != null) {
                    destroyedCrates = destroyedCrates + crateIndex
                    didInteract = true
                    if ((crateIndex + level.number) % 2 == 0) shieldHits = (shieldHits + 1).coerceAtMost(2)
                    else livesRemaining = (livesRemaining + 1).coerceAtMost(maxLives)
                    audio.play(GameSound.PICKUP, 0.7f)
                }
                if (!didInteract) {
                    objectiveHint = "No hay un botón u objeto cerca"
                    objectiveHintUntil = elapsedMs + 1_100L
                }
                interactQueued = false
            }

            if (shootQueued && elapsedMs - lastPlayerShotAt >= 330L && (level.weaponEnabled || weaponPowerUntil > elapsedMs)) {
                bullets += Bullet(playerX + playerWidth / 2f, playerY + 25f, facing)
                lastPlayerShotAt = elapsedMs
                audio.play(GameSound.SHOOT, 0.55f)
            }
            shootQueued = false

            for (i in bullets.indices.reversed()) {
                val b = bullets[i]
                val moved = b.copy(x = b.x + b.direction * 620f * dt)
                var hit = false
                enemies.indices.forEach { enemyIndex ->
                    val e = enemies[enemyIndex]
                    if (!hit && e.health > 0 && Rect(moved.x - 8f, moved.y - 8f, moved.x + 8f, moved.y + 8f)
                            .overlaps(Rect(e.x, e.y, e.x + 52f, e.y + 58f))) {
                        enemies[enemyIndex] = e.copy(health = (e.health - 1).coerceAtLeast(0))
                        hit = true
                    }
                }
                if (hit || moved.x < 0f || moved.x > level.width) bullets.removeAt(i) else bullets[i] = moved
            }

            for (i in enemies.indices) {
                val runtime = enemies[i]
                if (runtime.health <= 0) continue
                val model = level.enemies[i]
                var ex = runtime.x
                var ey = runtime.y
                var dir = runtime.direction
                var evy = runtime.velocityY
                var lastAction = runtime.lastActionAt
                val distance = playerX - ex
                val chasing = abs(distance) < model.detectionRange
                if (model.kind == GameEnemyKind.FLYER) {
                    ex += (if (chasing) distance.sign else dir) * model.speed * dt
                    ey = model.y + sin(elapsedMs / 360.0 + i).toFloat() * 75f
                } else {
                    if (chasing) dir = distance.sign.takeIf { it != 0f } ?: dir
                    val left = model.x - model.range
                    val right = model.x + model.range
                    if (!chasing && (ex < left || ex > right)) dir *= -1f
                    ex = (ex + dir * model.speed * (if (chasing) 1.35f else 0.72f) * dt).coerceIn(0f, level.width - 55f)
                    if (model.kind == GameEnemyKind.JUMPER && chasing && abs(distance) < 220f && evy == 0f && elapsedMs - lastAction > 800L) {
                        evy = -520f
                        lastAction = elapsedMs
                    }
                    if (model.kind == GameEnemyKind.SHOOTER && chasing && abs(distance) < 520f && elapsedMs - lastAction > 1_150L) {
                        val dx = playerX - ex
                        val dy = playerY - ey
                        val len = sqrt((dx * dx + dy * dy).toDouble()).toFloat().coerceAtLeast(1f)
                        enemyBullets += EnemyBullet(ex + 25f, ey + 22f, dx / len * 365f, dy / len * 365f)
                        lastAction = elapsedMs
                        audio.play(GameSound.ENEMY_SHOT, 0.38f)
                    }
                    val prevBottom = ey + 55f
                    evy += 1_420f * dt
                    var nextEnemyY = ey + evy * dt
                    val nextEnemyBottom = nextEnemyY + 55f
                    collisionPlatforms.forEach { p ->
                        if (ex + 50f > p.x && ex < p.x + p.width && evy >= 0f && prevBottom <= p.y + 15f && nextEnemyBottom >= p.y) {
                            nextEnemyY = p.y - 55f
                            evy = 0f
                        }
                    }
                    ey = nextEnemyY
                }
                val enemyRect = Rect(ex, ey, ex + 50f, ey + 58f)
                if (playerRect.overlaps(enemyRect)) {
                    val stomping = velocityY > 140f && playerY + playerHeight - velocityY * dt <= ey + 15f
                    if (stomping) {
                        enemies[i] = runtime.copy(x = ex, y = ey, direction = dir, health = (runtime.health - 2).coerceAtLeast(0), lastActionAt = lastAction, velocityY = evy)
                        velocityY = if (level.number <= 4) -820f else -460f
                        audio.play(GameSound.ENEMY_STOMP, 0.72f, 0.94f + (i % 3) * 0.07f)
                        continue
                    } else loseLife("Un enemigo te alcanzó")
                }
                enemies[i] = runtime.copy(x = ex, y = ey, direction = dir, lastActionAt = lastAction, velocityY = evy)
            }

            for (i in enemyBullets.indices.reversed()) {
                val b = enemyBullets[i]
                val moved = b.copy(x = b.x + b.velocityX * dt, y = b.y + b.velocityY * dt)
                if (playerRect.overlaps(Rect(moved.x - 7f, moved.y - 7f, moved.x + 7f, moved.y + 7f))) {
                    enemyBullets.removeAt(i)
                    loseLife("Un proyectil te alcanzó")
                } else if (moved.x !in 0f..level.width || moved.y !in 0f..780f) enemyBullets.removeAt(i)
                else enemyBullets[i] = moved
            }

            level.fallingObjects.forEachIndexed { index, trap ->
                var runtime = fallingRuntime[index]
                val triggeredAt = runtime.triggeredAt ?: return@forEachIndexed
                if (runtime.disabled || elapsedMs - triggeredAt < trap.delayMs) return@forEachIndexed
                var x = runtime.x
                var y = runtime.y
                var vx = runtime.velocityX
                var vy = runtime.velocityY
                var landedAt = runtime.landedAt
                var explodedAt = runtime.explodedAt
                var chaseStartedAt = runtime.chaseStartedAt
                var travelled = runtime.travelled
                var disabled = runtime.disabled

                if (landedAt == null) {
                    vy += 1_650f * dt
                    y += vy * dt
                    if (y + trap.size >= trap.targetY) {
                        y = trap.targetY - trap.size
                        vy = 0f
                        landedAt = elapsedMs
                        when (trap.behavior) {
                            FallingBehavior.EXPLODE -> audio.play(GameSound.EXPLOSION, 0.82f, 0.90f + index % 3 * 0.06f)
                            FallingBehavior.ROLL, FallingBehavior.CHASE -> audio.play(GameSound.FRUIT_DROP, 0.5f, 0.72f)
                            else -> audio.play(GameSound.CRUSHER, 0.42f, 0.76f)
                        }
                    }
                } else {
                    when (trap.behavior) {
                        FallingBehavior.ROLL -> {
                            vx = trap.rollDirection * (225f + level.number * 12f)
                            x += vx * dt
                            travelled += abs(vx * dt)
                        }
                        FallingBehavior.CHASE -> {
                            if (chaseStartedAt == null) chaseStartedAt = elapsedMs
                            val chaseAge = elapsedMs - (chaseStartedAt ?: elapsedMs)
                            if (chaseAge >= trap.chaseDurationMs || travelled >= trap.chaseMaxTravel) {
                                disabled = true
                            } else {
                                val targetX = playerX + playerWidth / 2f - trap.size / 2f
                                val targetY = playerY + playerHeight / 2f - trap.size / 2f
                                val dx = targetX - x
                                val dy = targetY - y
                                val distance = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (distance > 4f) {
                                    val speed = (145f + level.number * 2.2f).coerceAtMost(188f)
                                    val desiredX = dx / distance * speed
                                    val desiredY = dy / distance * speed
                                    val turn = (dt * 2.4f).coerceIn(0f, 1f)
                                    vx += (desiredX - vx) * turn
                                    vy += (desiredY - vy) * turn
                                    val stepX = vx * dt
                                    val stepY = vy * dt
                                    x += stepX
                                    y += stepY
                                    travelled += sqrt((stepX * stepX + stepY * stepY).toDouble()).toFloat()
                                    val fruitRect = Rect(x, y, x + trap.size, y + trap.size)
                                    val hitBarrier = blockingBarriers.any { barrier ->
                                        fruitRect.overlaps(Rect(barrier.x, barrier.y, barrier.x + barrier.width, barrier.y + barrier.height))
                                    }
                                    if (hitBarrier || x <= 0f || x + trap.size >= level.width || y < 20f || y > 690f) {
                                        disabled = true
                                    }
                                }
                            }
                        }
                        FallingBehavior.EXPLODE -> if (explodedAt == null && elapsedMs - landedAt >= trap.explosionDelayMs) explodedAt = elapsedMs
                        else -> Unit
                    }
                    if (!trap.becomesPlatform) {
                        val landedAge = elapsedMs - landedAt
                        disabled = disabled || when (trap.behavior) {
                            FallingBehavior.DROP, FallingBehavior.CHAIN -> landedAge >= 1_800L
                            FallingBehavior.ROLL -> travelled >= 760f || landedAge >= 4_200L
                            FallingBehavior.EXPLODE -> explodedAt?.let { elapsedMs - it >= 420L } == true
                            FallingBehavior.CHASE -> false
                        }
                    }
                }
                runtime = runtime.copy(
                    x = x,
                    y = y,
                    velocityX = vx,
                    velocityY = vy,
                    landedAt = landedAt,
                    explodedAt = explodedAt,
                    chaseStartedAt = chaseStartedAt,
                    travelled = travelled,
                    disabled = disabled
                )
                fallingRuntime[index] = runtime

                if (trap.treeFallsAfterTrap && index < treeRuntime.size) {
                    var tree = treeRuntime[index]
                    val readyToFall = when (trap.behavior) {
                        FallingBehavior.CHASE -> chaseStartedAt?.let { elapsedMs - it >= 2_200L } == true
                        FallingBehavior.EXPLODE -> explodedAt != null
                        else -> landedAt?.let { elapsedMs - it >= 900L } == true
                    }
                    if (tree.fallStartedAt == null && readyToFall) {
                        tree = tree.copy(fallStartedAt = elapsedMs)
                        treeRuntime[index] = tree
                        audio.play(GameSound.CRUSHER, 0.55f, 0.82f + index % 3 * 0.08f)
                    }
                    tree.fallStartedAt?.let { started ->
                        val progress = treeFallProgress(started)
                        // El árbol solo mata mientras está cayendo. Una vez horizontal,
                        // el tronco queda como plataforma segura para continuar el nivel.
                        if (progress in 0.08f..0.96f) {
                            val trunkHeight = (trap.targetY - (trap.startY - 28f)).coerceAtLeast(180f)
                            val baseX = trap.x + trap.size / 2f
                            val baseY = trap.targetY
                            val direction = if ((index + level.number) % 2 == 0) 1f else -1f
                            val tipX = baseX + direction * trunkHeight * progress
                            val tipY = baseY - trunkHeight * (1f - progress)
                            val treeRect = Rect(
                                minOf(baseX, tipX) - 24f,
                                minOf(baseY, tipY) - 34f,
                                maxOf(baseX, tipX) + 24f,
                                maxOf(baseY, tipY) + 12f
                            )
                            if (playerRect.overlaps(treeRect)) loseLife("El árbol cayó sobre GEO")
                        }
                    }
                }

                if (!disabled) {
                    val copies = if (trap.behavior == FallingBehavior.CHAIN) trap.chainCount else 1
                    repeat(copies) { copyIndex ->
                        val copyX = x + (copyIndex - (copies - 1) / 2f) * trap.chainSpacing
                        val hitSize = if (trap.kind == FallingObjectKind.FRUIT) appleDiameter else trap.size
                        val offset = (trap.size - hitSize) / 2f
                        if (playerRect.overlaps(Rect(copyX + offset, y + offset, copyX + offset + hitSize, y + offset + hitSize))) loseLife("Una fruta trampa aplastó a GEO")
                    }
                }
                if (explodedAt != null && elapsedMs - explodedAt < 360L) {
                    val centerX = x + trap.size / 2f
                    val centerY = y + trap.size / 2f
                    val dx = playerX + playerWidth / 2f - centerX
                    val dy = playerY + playerHeight / 2f - centerY
                    if (sqrt((dx * dx + dy * dy).toDouble()).toFloat() <= trap.explosionRadius) loseLife("La fruta explotó al acercarte")
                }
            }

            level.chasingHoles.forEachIndexed { index, trap ->
                var runtime = chasingHoleRuntime[index]
                val holePlayerCenter = playerX + playerWidth / 2f
                val closeToOpening = holePlayerCenter >= trap.startX - 38f && holePlayerCenter <= trap.startX + trap.width + 48f
                if (!runtime.active && !runtime.closed && closeToOpening) {
                    runtime = runtime.copy(active = true)
                    audio.play(GameSound.HOLE, 0.76f, 0.84f + index % 3 * 0.08f)
                }
                if (runtime.active && !runtime.closed) {
                    val minX = minOf(trap.surfaceStartX, trap.surfaceEndX)
                    val maxX = (maxOf(trap.surfaceStartX, trap.surfaceEndX) - trap.width).coerceAtLeast(minX)
                    val forward = if (trap.direction >= 0f) 1f else -1f
                    val playerCenter = playerX + playerWidth / 2f
                    val targetX = (playerCenter - trap.width * 0.45f).coerceIn(minX, maxX)
                    val shouldAdvance = if (forward > 0f) targetX > runtime.x else targetX < runtime.x
                    if (shouldAdvance && runtime.travelled < trap.maxTravel) {
                        val rawStep = forward * trap.speed * dt
                        val nextX = (runtime.x + rawStep).coerceIn(minX, maxX)
                        val travelledNow = runtime.travelled + abs(nextX - runtime.x)
                        runtime = runtime.copy(x = nextX, travelled = travelledNow)
                    }
                    val reachedSurfaceEdge = if (forward > 0f) runtime.x >= maxX - 0.5f else runtime.x <= minX + 0.5f
                    val exceededTravel = runtime.travelled >= trap.maxTravel
                    val playerLeftSurface = if (forward > 0f) playerX > trap.surfaceEndX + 45f else playerX + playerWidth < trap.surfaceStartX - 45f
                    if (reachedSurfaceEdge || exceededTravel || playerLeftSurface) {
                        runtime = runtime.copy(active = false, closed = true)
                    }
                }
                chasingHoleRuntime[index] = runtime
            }

            level.crushers.forEachIndexed { index, trap ->
                var runtime = crusherRuntime[index]
                if (runtime.triggeredAt == null && playerX >= trap.triggerX) {
                    runtime = runtime.copy(triggeredAt = elapsedMs)
                    audio.play(GameSound.CRUSHER, 0.7f, 0.86f + index % 3 * 0.08f)
                    crusherRuntime[index] = runtime
                }
                val triggeredAt = runtime.triggeredAt ?: return@forEachIndexed
                if (trap.despawnAfterMs > 0L && elapsedMs - triggeredAt >= trap.despawnAfterMs) return@forEachIndexed
                val activeMs = (elapsedMs - triggeredAt - trap.delayMs).coerceAtLeast(0L)
                val maxDistance = abs(trap.travel)
                val forward = (activeMs / 1000f * trap.speed).coerceAtMost(maxDistance)
                val reverseStart = trap.delayMs + trap.reverseAfterMs
                val distance = if (elapsedMs - triggeredAt <= reverseStart) forward else {
                    val reversed = ((elapsedMs - triggeredAt - reverseStart) / 1000f * trap.speed).coerceAtMost(maxDistance)
                    (maxDistance - reversed).coerceAtLeast(0f)
                }
                val signedOffset = trap.travel.sign * distance
                val cx = trap.x + if (trap.axis == CrusherAxis.HORIZONTAL) signedOffset else 0f
                val cy = trap.y + if (trap.axis == CrusherAxis.VERTICAL) signedOffset else 0f
                if (playerRect.overlaps(Rect(cx, cy, cx + trap.width, cy + trap.height))) loseLife(if (trap.style == CrusherStyle.FALLING_WALL) "El muro cayó sobre GEO" else "La trampa de piedra aplastó a GEO")
            }

            fun hazardIsActive(index: Int, h: GameHazard): Boolean {
                if (h.kind != HazardKind.HIDDEN_SPIKES) {
                    return h.cycleMs <= 0L || ((elapsedMs + h.phaseMs) % h.cycleMs) < h.cycleMs * 0.62f
                }
                val trigger = hazardTriggeredAt[index] ?: return false
                val age = elapsedMs - trigger
                if (age <= 150L) return false
                if (h.cycleMs <= 0L) return true
                val cycleAge = (age - 150L + h.phaseMs).coerceAtLeast(0L) % h.cycleMs
                return cycleAge < h.cycleMs * 0.56f
            }
            level.hazards.forEachIndexed { index, h ->
                if (hazardIsActive(index, h) && playerRect.overlaps(Rect(h.x, h.y, h.x + h.width, h.y + h.height))) {
                    audio.play(if (h.kind == HazardKind.FIRE) GameSound.EXPLOSION else GameSound.SPIKE, 0.58f, 0.94f + index % 4 * 0.05f)
                    loseLife(when (h.kind) {
                        HazardKind.HIDDEN_SPIKES -> "Los pinchos estaban ocultos"
                        HazardKind.SAW -> "La sierra te alcanzó"
                        HazardKind.FIRE -> "La llamarada se activó"
                        HazardKind.CEILING_SPIKES -> "El techo era una trampa"
                        else -> "Caíste en los pinchos"
                    })
                }
            }

            if (level.acechantePresent) {
                val target = playerX - 155f
                val speed = 132f + level.number * 6f
                acechanteX += (target - acechanteX).sign * speed * dt
                if (abs(playerX - acechanteX) < 60f) loseLife("El Acechante te encontró")
            }

            if (playerY > 705f) loseLife("Caíste al vacío", DeathCause.VOID)
            if (elapsedMs > 900_000L) endGame(GameOutcome.LOST)

            val nearExitHeight = playerY + playerHeight >= level.goalY - 85f && playerY <= level.goalY + 150f
            if (playerX + playerWidth >= level.goalX && nearExitHeight) {
                when {
                    level.requiresKey && collectedKeys.size < level.keys.size -> {
                        objectiveHint = "La puerta está cerrada: encuentra la llave oculta"
                        objectiveHintUntil = elapsedMs + 2_200L
                    }
                    activeSwitches.size < level.requiredMechanisms -> {
                        objectiveHint = "La salida está cerrada: faltan ${level.requiredMechanisms - activeSwitches.size} interruptores"
                        objectiveHintUntil = elapsedMs + 2_200L
                    }
                    else -> endGame(GameOutcome.WON)
                }
            } else if (objectiveHint != null && objectiveHintUntil > 0 && elapsedMs > objectiveHintUntil) {
                objectiveHint = null
                objectiveHintUntil = 0L
            }
        }
    }

    val elapsedSeconds = (elapsedMs / 1000L).toInt()
    LaunchedEffect(run.runId, elapsedSeconds, activated, outcome) {
        if (run.needsActivation && !activated && !activating && outcome == null && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            activating = true
            viewModel.activateGeoGameRun(run)
                .onSuccess {
                    activated = true
                    activationRewards = it.awardedPoints
                }
                .onFailure { if (!it.message.orEmpty().contains("not ready", true)) onMessage(it.message ?: "No se pudo activar la vida dorada.") }
            activating = false
        }
    }

    LaunchedEffect(outcome, reportAttempt) {
        val finalOutcome = outcome ?: return@LaunchedEffect
        if (resultSaved || reportingResult) return@LaunchedEffect
        reportingResult = true
        resultError = null
        var canFinish = activated
        if (run.needsActivation && !canFinish && elapsedSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS) {
            viewModel.activateGeoGameRun(run)
                .onSuccess { canFinish = true; activated = true; activationRewards = it.awardedPoints }
                .onFailure { resultError = it.message ?: "No se pudo confirmar la vida dorada." }
        }
        if (run.needsActivation && !canFinish) {
            runCatching { viewModel.cancelGeoGameRun(run) }
                .onSuccess { onMessage("La partida terminó antes de 20 segundos activos; la vida dorada fue devuelta."); resultSaved = true }
                .onFailure { resultError = it.message ?: "No se pudo devolver la vida todavía." }
            reportingResult = false
            return@LaunchedEffect
        }
        val won = finalOutcome == GameOutcome.WON
        val stars = GeoGameRules.calculateStars(won, if (won) 3 else 0, elapsedSeconds, level.parSeconds)
        val score = playerX.toLong() + collectedKeys.size * 900L + activeSwitches.size * 350L + activatedCheckpoints.size * 250L + livesRemaining * 160L + if (won) 3_000L else 0L
        viewModel.finishGeoGameRun(run, won, stars, score, elapsedMs)
            .onSuccess { resultSaved = true }
            .onFailure { resultError = it.message ?: "No se pudo guardar el resultado." }
        reportingResult = false
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF040D13))) {
        Canvas(Modifier.fillMaxSize()) {
            val viewportWidth = size.width
            val viewportHeight = size.height
            val gameTop = 2f
            val gameBottom = viewportHeight - 76f
            val scaleY = (gameBottom - gameTop) / 720f
            val cameraX = (playerX - viewportWidth * 0.30f).coerceIn(0f, max(level.width - viewportWidth, 0f))
            fun sy(value: Float) = gameTop + value * scaleY
            fun drawApple(center: Offset, radius: Float = appleRadius, exploding: Boolean = false) {
                val darkRed = if (exploding) Color(0xFF9C1322) else Color(0xFFB71C2A)
                val appleRed = if (exploding) Color(0xFFFF334D) else Color(0xFFE72F3E)
                drawOval(
                    color = darkRed,
                    topLeft = Offset(center.x - radius * 0.78f, center.y - radius * 0.52f),
                    size = Size(radius * 1.56f, radius * 1.46f)
                )
                drawCircle(appleRed, radius * 0.61f, Offset(center.x - radius * 0.30f, center.y - radius * 0.18f))
                drawCircle(appleRed, radius * 0.61f, Offset(center.x + radius * 0.30f, center.y - radius * 0.18f))
                drawOval(
                    color = appleRed,
                    topLeft = Offset(center.x - radius * 0.58f, center.y - radius * 0.02f),
                    size = Size(radius * 1.16f, radius * 0.92f)
                )
                drawLine(
                    Color(0xFF5D3A20),
                    Offset(center.x, center.y - radius * 0.72f),
                    Offset(center.x + radius * 0.12f, center.y - radius * 1.08f),
                    radius * 0.13f
                )
                val leaf = Path().apply {
                    moveTo(center.x + radius * 0.10f, center.y - radius * 0.88f)
                    quadraticBezierTo(
                        center.x + radius * 0.55f,
                        center.y - radius * 1.14f,
                        center.x + radius * 0.68f,
                        center.y - radius * 0.72f
                    )
                    quadraticBezierTo(
                        center.x + radius * 0.38f,
                        center.y - radius * 0.58f,
                        center.x + radius * 0.10f,
                        center.y - radius * 0.88f
                    )
                    close()
                }
                drawPath(leaf, Color(0xFF70C84D))
                drawCircle(Color.White.copy(alpha = 0.62f), radius * 0.12f, Offset(center.x - radius * 0.30f, center.y - radius * 0.34f))
            }

            when (level.biome) {
                AdventureBiome.FOREST_DAY -> {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFF45BDF2), Color(0xFF9DE4FF), Color(0xFFE9FAFF))), size = size)
                    val sunPulse = 1f + sin(elapsedMs / 1_900.0).toFloat() * 0.035f
                    drawCircle(Color(0xFFFFF1A6).copy(alpha = 0.34f), 62f * sunPulse, Offset(viewportWidth - 112f, 82f))
                    drawCircle(Color(0xFFFFE26F), 41f, Offset(viewportWidth - 112f, 82f))
                    repeat(7) { i ->
                        val drift = (elapsedMs / (34f + i * 4f)) % (viewportWidth + 280f)
                        val cx = ((i * 230f + drift - cameraX * 0.035f) % (viewportWidth + 280f)) - 140f
                        val cy = 68f + (i % 3) * 62f
                        drawOval(Color.White.copy(alpha = 0.63f), Offset(cx, cy), Size(145f, 36f))
                        drawCircle(Color.White.copy(alpha = 0.67f), 27f, Offset(cx + 40f, cy + 5f))
                        drawCircle(Color.White.copy(alpha = 0.67f), 32f, Offset(cx + 83f, cy + 3f))
                    }
                    repeat(24) { i ->
                        val leafX = ((i * 137f - cameraX * 0.62f + elapsedMs / (24f + i % 4 * 5f)) % (viewportWidth + 240f)) - 90f
                        val leafY = 95f + ((i * 73f + elapsedMs / 33f) % (viewportHeight - 165f))
                        drawOval(Color(0xFF9FE36C).copy(alpha = 0.32f), Offset(leafX, leafY), Size(14f, 6f))
                    }
                }
                AdventureBiome.FOREST_SUNSET -> {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFF4A286E), Color(0xFFFF7B54), Color(0xFFFFC971), Color(0xFF314B3B))), size = size)
                    val sunY = 122f + sin(elapsedMs / 2_600.0).toFloat() * 5f
                    drawCircle(Color(0xFFFFD166).copy(alpha = 0.28f), 78f, Offset(viewportWidth * 0.76f, sunY))
                    drawCircle(Color(0xFFFFC857), 48f, Offset(viewportWidth * 0.76f, sunY))
                    repeat(6) { i ->
                        val drift = (elapsedMs / (50f + i * 7f)) % (viewportWidth + 320f)
                        val cx = ((i * 270f + drift - cameraX * 0.045f) % (viewportWidth + 320f)) - 160f
                        val cy = 72f + (i % 3) * 58f
                        drawOval(Color(0xFF5F3B69).copy(alpha = 0.34f), Offset(cx, cy), Size(190f, 30f))
                    }
                    repeat(20) { i ->
                        val px = ((i * 149f - cameraX * 0.22f + elapsedMs / (45f + i % 4 * 4f)) % (viewportWidth + 180f)) - 60f
                        val py = 100f + (i * 67 % (viewportHeight.toInt().coerceAtLeast(220) - 120))
                        drawCircle(Color(0xFFFFD07A).copy(alpha = 0.18f + (i % 3) * 0.07f), 2f + i % 3, Offset(px, py.toFloat()))
                    }
                }
                AdventureBiome.UNDERGROUND -> {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFF1A1718), Color(0xFF3A2C28), Color(0xFF171C20))), size = size)
                    repeat(11) { i ->
                        val rockX = ((i * 210f - cameraX * (0.08f + i % 3 * 0.03f)) % (viewportWidth + 240f)) - 100f
                        val rockY = 75f + (i % 4) * 115f
                        drawOval(Color(0xFF66534A).copy(alpha = 0.30f), Offset(rockX, rockY), Size(180f + i % 3 * 35f, 95f))
                    }
                    repeat(12) { i ->
                        val rootX = ((i * 173f - cameraX * 0.16f) % (viewportWidth + 180f)) - 60f
                        val sway = sin(elapsedMs / 700.0 + i).toFloat() * 7f
                        drawLine(Color(0xFF5C3927).copy(alpha = 0.72f), Offset(rootX, 0f), Offset(rootX + sway + 38f, 155f + (i % 4) * 42f), 6f + i % 3)
                    }
                    repeat(28) { i ->
                        val dustX = ((i * 113f + elapsedMs / (42f + i % 5 * 5f) - cameraX * 0.08f) % (viewportWidth + 100f)) - 50f
                        val dustY = 45f + (i * 59 % (viewportHeight.toInt().coerceAtLeast(160) - 70))
                        drawCircle(Color(0xFFD8B08C).copy(alpha = 0.14f + i % 3 * 0.05f), 1.5f + i % 3, Offset(dustX, dustY.toFloat()))
                    }
                }
                AdventureBiome.CAVE_NIGHT -> {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFF080B24), Color(0xFF17133B), Color(0xFF102D35))), size = size)
                    repeat(34) { i ->
                        val px = ((i * 127f - cameraX * (0.025f + i % 3 * 0.015f)) % (viewportWidth + 120f)) - 40f
                        val py = 26f + (i * 79 % 330)
                        drawCircle(Color(0xFFC9E9FF).copy(alpha = 0.25f + i % 4 * 0.08f), 1.3f + i % 3, Offset(px, py.toFloat()))
                    }
                    drawCircle(Color(0xFFDCEBFF).copy(alpha = 0.20f), 58f, Offset(viewportWidth - 108f, 82f))
                    drawCircle(Color(0xFFE8F2FF).copy(alpha = 0.86f), 36f, Offset(viewportWidth - 108f, 82f))
                    repeat(18) { i ->
                        val fx = ((i * 173f + sin(elapsedMs / 650.0 + i).toFloat() * 44f - cameraX * 0.16f) % (viewportWidth + 140f)) - 45f
                        val fy = 90f + (i * 61 % (viewportHeight.toInt().coerceAtLeast(190) - 100)) + sin(elapsedMs / 410.0 + i * 1.7).toFloat() * 22f
                        val glow = 4f + sin(elapsedMs / 180.0 + i).toFloat() * 1.4f
                        drawCircle(Color(0xFFA8FF78).copy(alpha = 0.14f), glow * 3f, Offset(fx, fy))
                        drawCircle(Color(0xFFD7FF7A).copy(alpha = 0.88f), glow, Offset(fx, fy))
                    }
                    repeat(9) { i ->
                        val cx = ((i * 245f - cameraX * 0.31f) % (viewportWidth + 260f)) - 80f
                        val base = viewportHeight - 74f
                        val h = 34f + (i % 4) * 19f
                        val crystal = Path().apply { moveTo(cx, base); lineTo(cx + 15f, base - h); lineTo(cx + 30f, base); close() }
                        drawPath(crystal, Color(0xFF65D8FF).copy(alpha = 0.32f + i % 3 * 0.10f))
                    }
                }
                AdventureBiome.DESERT_DAWN -> {
                    drawRect(Brush.verticalGradient(listOf(Color(0xFF4E5B89), Color(0xFFFFA868), Color(0xFFFFD99A), Color(0xFFC58A47))), size = size)
                    val dawnPulse = 1f + sin(elapsedMs / 2_200.0).toFloat() * 0.04f
                    drawCircle(Color(0xFFFFF0B0).copy(alpha = 0.25f), 78f * dawnPulse, Offset(viewportWidth * 0.72f, 105f))
                    drawCircle(Color(0xFFFFD166), 45f, Offset(viewportWidth * 0.72f, 105f))
                    repeat(9) { i ->
                        val rx = ((i * 260f - cameraX * 0.19f) % (viewportWidth + 300f)) - 80f
                        val top = sy(245f + i % 3 * 65f)
                        drawRect(Color(0xFF80684E).copy(alpha = 0.52f), Offset(rx, top), Size(48f + i % 2 * 20f, sy(590f) - top))
                        drawRect(Color(0xFFAC8B62).copy(alpha = 0.42f), Offset(rx - 14f, top), Size(76f + i % 2 * 20f, 18f))
                    }
                    repeat(26) { i ->
                        val sandX = ((i * 119f + elapsedMs / (19f + i % 4 * 5f) - cameraX * 0.30f) % (viewportWidth + 180f)) - 80f
                        val sandY = 80f + (i * 57 % (viewportHeight.toInt().coerceAtLeast(170) - 90))
                        drawLine(Color(0xFFFFE0A3).copy(alpha = 0.20f + i % 3 * 0.05f), Offset(sandX, sandY.toFloat()), Offset(sandX + 18f, sandY.toFloat() + 2f), 2f)
                    }
                }
            }

            val movingPlatforms = level.movingPlatforms.mapIndexed { index, moving ->
                val phase = elapsedMs / 1000f / moving.periodSeconds * (Math.PI * 2.0) + index * 0.68
                val offset = sin(phase).toFloat() * moving.travel
                GamePlatform(if (moving.vertical) moving.x else moving.x + offset, if (moving.vertical) moving.y + offset else moving.y, moving.width, 26f)
            }

            level.platforms.forEachIndexed { index, p ->
                val visible = when (p.kind) {
                    PlatformKind.SOLID, PlatformKind.BOUNCE -> true
                    PlatformKind.REVEALING -> playerX >= p.triggerX || activeSwitches.isNotEmpty()
                    PlatformKind.DISAPPEARING, PlatformKind.PROXIMITY_DISAPPEARING -> {
                        val delay = if (p.kind == PlatformKind.DISAPPEARING) maxOf(p.delayMs, 700L) else p.delayMs
                        platformTriggeredAt[index]?.let { elapsedMs - it <= delay } ?: true
                    }
                    PlatformKind.FALLING -> platformTriggeredAt[index]?.let { elapsedMs - it <= p.delayMs } ?: true
                }
                if (!visible) return@forEachIndexed
                val triggered = platformTriggeredAt[index]
                val fallOffset = if (p.kind == PlatformKind.FALLING && triggered != null) ((elapsedMs - triggered).coerceAtLeast(0L) / 4f).coerceAtMost(120f) else 0f
                val terrainBodyColor = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> Color(0xFF6B4528)
                    AdventureBiome.FOREST_SUNSET -> Color(0xFF7C4E2F)
                    AdventureBiome.UNDERGROUND -> Color(0xFF51463F)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF24434C)
                    AdventureBiome.DESERT_DAWN -> Color(0xFFA4723E)
                }
                val terrainTopColor = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> Color(0xFF3FAE59)
                    AdventureBiome.FOREST_SUNSET -> Color(0xFF72A04A)
                    AdventureBiome.UNDERGROUND -> Color(0xFF726557)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF3D7B82)
                    AdventureBiome.DESERT_DAWN -> Color(0xFFD7B15D)
                }
                val terrainShadowColor = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> Color(0xFF4C311D)
                    AdventureBiome.FOREST_SUNSET -> Color(0xFF573521)
                    AdventureBiome.UNDERGROUND -> Color(0xFF3A312C)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF1A2F35)
                    AdventureBiome.DESERT_DAWN -> Color(0xFF7E582E)
                }
                val color = when (p.kind) {
                    PlatformKind.FALLING -> Color(0xFFD06A3A)
                    PlatformKind.DISAPPEARING, PlatformKind.PROXIMITY_DISAPPEARING -> Color(0xFF7B61FF).copy(alpha = 0.82f)
                    PlatformKind.REVEALING -> Color(0xFF4FC3F7).copy(alpha = 0.82f)
                    PlatformKind.BOUNCE -> Color(0xFF8AF07C)
                    else -> terrainBodyColor
                }
                val topColor = when (p.kind) {
                    PlatformKind.SOLID -> terrainTopColor
                    PlatformKind.FALLING -> Color(0xFFFFB56A)
                    PlatformKind.DISAPPEARING, PlatformKind.PROXIMITY_DISAPPEARING -> Color(0xFFAC95FF)
                    PlatformKind.REVEALING -> Color(0xFF8BE5FF)
                    PlatformKind.BOUNCE -> Color(0xFFC2FF7A)
                }
                val shadowColor = when (p.kind) {
                    PlatformKind.SOLID -> terrainShadowColor
                    else -> color.copy(alpha = 0.88f)
                }
                val renderedPlatform = p.copy(y = p.y + fallOffset)
                splitPlatformByOpenFloor(renderedPlatform).forEach { piece ->
                    val topLeft = Offset(piece.x - cameraX, sy(piece.y))
                    val bodyHeight = piece.height * scaleY
                    val bodySize = Size(piece.width, bodyHeight)
                    val surfaceHeight = (bodyHeight * if (p.kind == PlatformKind.SOLID) 0.30f else 0.22f).coerceIn(6f, 14f)
                    drawRoundRect(shadowColor, Offset(topLeft.x, topLeft.y + 5f), bodySize, androidx.compose.ui.geometry.CornerRadius(8f))
                    drawRoundRect(color, topLeft, bodySize, androidx.compose.ui.geometry.CornerRadius(8f))
                    drawRoundRect(topColor, topLeft, Size(piece.width, surfaceHeight + 2f), androidx.compose.ui.geometry.CornerRadius(8f))

                    // Textura de tierra/piedra para que los pisos, techos y paredes
                    // se lean como estructuras reales de laberinto y no como líneas planas.
                    if (p.kind == PlatformKind.SOLID && bodyHeight >= 28f) {
                        val rowHeight = 26f
                        val rows = (bodyHeight / rowHeight).toInt().coerceIn(1, 12)
                        repeat(rows) { row ->
                            val rowY = topLeft.y + surfaceHeight + row * rowHeight
                            if (rowY < topLeft.y + bodyHeight - 3f) {
                                drawLine(terrainShadowColor.copy(alpha = 0.48f), Offset(topLeft.x + 2f, rowY), Offset(topLeft.x + piece.width - 2f, rowY), 1.4f)
                                val brickWidth = 46f
                                val offset = if (row % 2 == 0) 0f else brickWidth * 0.5f
                                var brickX = topLeft.x + offset
                                while (brickX < topLeft.x + piece.width) {
                                    drawLine(
                                        terrainShadowColor.copy(alpha = 0.40f),
                                        Offset(brickX, rowY),
                                        Offset(brickX, (rowY + rowHeight).coerceAtMost(topLeft.y + bodyHeight - 2f)),
                                        1.2f
                                    )
                                    brickX += brickWidth
                                }
                            }
                        }
                    }

                    val detailCount = (piece.width / 72f).toInt().coerceIn(1, 6)
                    repeat(detailCount) { detail ->
                        val px = topLeft.x + 12f + detail * ((piece.width - 24f) / detailCount)
                        drawCircle(Color.White.copy(alpha = 0.10f), 1.8f, Offset(px, topLeft.y + surfaceHeight + 7f + (detail % 2) * 4f))
                        if (p.kind == PlatformKind.SOLID) {
                            val rootTipX = px + if (detail % 2 == 0) -4f else 4f
                            drawLine(terrainShadowColor.copy(alpha = 0.58f), Offset(px, topLeft.y + bodyHeight - 8f), Offset(rootTipX, topLeft.y + bodyHeight + 2f), 2f)
                        }
                    }
                    drawRect(Color.White.copy(alpha = 0.12f), Offset(topLeft.x + 5f, topLeft.y + 4f), Size((piece.width - 10f).coerceAtLeast(0f), 3f))
                }
            }
            movingPlatforms.forEach { p ->
                drawRoundRect(Color(0xFF56CFE1), Offset(p.x - cameraX, sy(p.y)), Size(p.width, p.height * scaleY), androidx.compose.ui.geometry.CornerRadius(9f))
                drawCircle(Color.White.copy(alpha = 0.55f), 5f, Offset(p.x + p.width / 2f - cameraX, sy(p.y + 12f)))
            }

            level.fans.forEachIndexed { index, fan ->
                val active = fan.cycleMs <= 0 || ((elapsedMs + fan.phaseMs) % fan.cycleMs) < fan.cycleMs * 0.66f
                val reversed = fan.switchIndex?.let { it in activeSwitches } == true
                val dirX = if (reversed) -fan.forceX else fan.forceX
                val dirY = if (reversed) -fan.forceY else fan.forceY
                drawCircle(if (active) Color(0xFF9BE7FF) else Color(0xFF526D79), 27f, Offset(fan.x - cameraX, sy(fan.y + fan.height / 2f)))
                repeat(4) { blade ->
                    val angle = elapsedMs / 120.0 + blade * Math.PI / 2
                    val bx = fan.x - cameraX + kotlin.math.cos(angle).toFloat() * 20f
                    val by = sy(fan.y + fan.height / 2f) + sin(angle).toFloat() * 20f
                    drawLine(Color.White.copy(alpha = 0.7f), Offset(fan.x - cameraX, sy(fan.y + fan.height / 2f)), Offset(bx, by), 5f)
                }
                if (active) repeat(7) { particle ->
                    val progress = ((elapsedMs.toFloat() / 7f + particle * 83f) % max(fan.width, fan.height))
                    val px = if (abs(dirX) > abs(dirY)) fan.x + (if (dirX > 0f) progress else fan.width - progress) else fan.x + (particle % 3) * fan.width / 3f
                    val py = if (abs(dirY) > abs(dirX)) fan.y + (if (dirY > 0f) progress else fan.height - progress) else fan.y + 18f + (particle % 4) * 28f
                    drawLine(Color(0xFFB8F2FF).copy(alpha = 0.48f), Offset(px - cameraX, sy(py)), Offset(px - cameraX - dirX.sign * 24f, sy(py - dirY.sign * 12f)), 2f)
                }
                if (index % 2 == 0 && active) drawCircle(Color(0xFFB8F2FF).copy(alpha = 0.14f), 44f, Offset(fan.x - cameraX, sy(fan.y + fan.height / 2f)))
            }

            fun drawSpikes(h: GameHazard, active: Boolean) {
                if (!active) return
                val supportColor = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> Color(0xFF355E43)
                    AdventureBiome.FOREST_SUNSET -> Color(0xFF5A4635)
                    AdventureBiome.UNDERGROUND -> Color(0xFF554A43)
                    AdventureBiome.CAVE_NIGHT -> Color(0xFF334957)
                    AdventureBiome.DESERT_DAWN -> Color(0xFF92704F)
                }
                when (h.orientation) {
                    HazardOrientation.UP -> drawRoundRect(supportColor, Offset(h.x - 5f - cameraX, sy(h.y + h.height - 9f)), Size(h.width + 10f, 13f * scaleY), androidx.compose.ui.geometry.CornerRadius(4f))
                    HazardOrientation.DOWN -> drawRoundRect(supportColor, Offset(h.x - 9f - cameraX, sy(h.y - 20f)), Size(h.width + 18f, 22f * scaleY), androidx.compose.ui.geometry.CornerRadius(4f))
                    HazardOrientation.LEFT -> drawRoundRect(supportColor, Offset(h.x + h.width - cameraX - 2f, sy(h.y - 7f)), Size(22f, (h.height + 14f) * scaleY), androidx.compose.ui.geometry.CornerRadius(4f))
                    HazardOrientation.RIGHT -> drawRoundRect(supportColor, Offset(h.x - 20f - cameraX, sy(h.y - 7f)), Size(22f, (h.height + 14f) * scaleY), androidx.compose.ui.geometry.CornerRadius(4f))
                }
                val count = max(2, ((if (h.orientation == HazardOrientation.LEFT || h.orientation == HazardOrientation.RIGHT) h.height else h.width) / 22f).toInt())
                val path = Path()
                when (h.orientation) {
                    HazardOrientation.UP -> {
                        val baseY = sy(h.y + h.height)
                        path.moveTo(h.x - cameraX, baseY)
                        repeat(count) { i ->
                            val left = h.x - cameraX + h.width * i / count
                            val mid = h.x - cameraX + h.width * (i + 0.5f) / count
                            val right = h.x - cameraX + h.width * (i + 1f) / count
                            path.lineTo(left, baseY); path.lineTo(mid, sy(h.y)); path.lineTo(right, baseY)
                        }
                    }
                    HazardOrientation.DOWN -> {
                        val baseY = sy(h.y)
                        path.moveTo(h.x - cameraX, baseY)
                        repeat(count) { i ->
                            val left = h.x - cameraX + h.width * i / count
                            val mid = h.x - cameraX + h.width * (i + 0.5f) / count
                            val right = h.x - cameraX + h.width * (i + 1f) / count
                            path.lineTo(left, baseY); path.lineTo(mid, sy(h.y + h.height)); path.lineTo(right, baseY)
                        }
                    }
                    HazardOrientation.LEFT -> {
                        val baseX = h.x + h.width - cameraX
                        path.moveTo(baseX, sy(h.y))
                        repeat(count) { i ->
                            val top = sy(h.y + h.height * i / count)
                            val mid = sy(h.y + h.height * (i + 0.5f) / count)
                            val bottom = sy(h.y + h.height * (i + 1f) / count)
                            path.lineTo(baseX, top); path.lineTo(h.x - cameraX, mid); path.lineTo(baseX, bottom)
                        }
                    }
                    HazardOrientation.RIGHT -> {
                        val baseX = h.x - cameraX
                        path.moveTo(baseX, sy(h.y))
                        repeat(count) { i ->
                            val top = sy(h.y + h.height * i / count)
                            val mid = sy(h.y + h.height * (i + 0.5f) / count)
                            val bottom = sy(h.y + h.height * (i + 1f) / count)
                            path.lineTo(baseX, top); path.lineTo(h.x + h.width - cameraX, mid); path.lineTo(baseX, bottom)
                        }
                    }
                }
                path.close()
                val spikeColor = when {
                    h.kind == HazardKind.HIDDEN_SPIKES || h.camouflaged -> Color(0xFFFF5A64)
                    h.kind == HazardKind.CEILING_SPIKES -> Color(0xFFFFB74D)
                    else -> Color(0xFFF2F5F7)
                }
                drawPath(path, spikeColor)
            }
            level.hazards.forEachIndexed { index, h ->
                val active = if (h.kind != HazardKind.HIDDEN_SPIKES) {
                    h.cycleMs <= 0L || ((elapsedMs + h.phaseMs) % h.cycleMs) < h.cycleMs * 0.62f
                } else {
                    val trigger = hazardTriggeredAt[index]
                    if (trigger == null) false else {
                        val age = elapsedMs - trigger
                        age > 150L && (h.cycleMs <= 0L || ((age - 150L + h.phaseMs) % h.cycleMs) < h.cycleMs * 0.56f)
                    }
                }
                if (h.camouflaged) {
                    when (h.orientation) {
                        HazardOrientation.UP -> Unit
                        HazardOrientation.DOWN -> drawRect(Color(0xFF274E3D), Offset(h.x - cameraX, sy(h.y - 18f)), Size(h.width, 20f * scaleY))
                        HazardOrientation.LEFT -> drawRect(Color(0xFF274E3D), Offset(h.x + h.width - cameraX, sy(h.y)), Size(20f, h.height * scaleY))
                        HazardOrientation.RIGHT -> drawRect(Color(0xFF274E3D), Offset(h.x - 20f - cameraX, sy(h.y)), Size(20f, h.height * scaleY))
                    }
                }
                when (h.kind) {
                    HazardKind.SAW -> if (active) {
                        val center = Offset(h.x + h.width / 2f - cameraX, sy(h.y + h.height / 2f))
                        drawCircle(Color(0xFFE0E0E0), h.width / 2f, center)
                        drawCircle(Color(0xFF455A64), h.width / 5f, center)
                        repeat(8) { tooth ->
                            val a = elapsedMs / 170.0 + tooth * Math.PI / 4
                            drawLine(Color(0xFFFF5252), center, Offset(center.x + kotlin.math.cos(a).toFloat() * h.width * 0.58f, center.y + sin(a).toFloat() * h.width * 0.58f), 4f)
                        }
                    }
                    HazardKind.FIRE -> if (active) {
                        repeat(4) { flame ->
                            val fx = h.x + h.width * (flame + 0.5f) / 4f - cameraX
                            val wave = sin(elapsedMs / 90.0 + flame).toFloat() * 8f
                            val p = Path().apply {
                                moveTo(fx - 10f, sy(h.y + h.height))
                                quadraticBezierTo(fx - 18f + wave, sy(h.y + h.height * 0.45f), fx, sy(h.y))
                                quadraticBezierTo(fx + 18f - wave, sy(h.y + h.height * 0.45f), fx + 10f, sy(h.y + h.height))
                                close()
                            }
                            drawPath(p, if (flame % 2 == 0) Color(0xFFFF6D00) else Color(0xFFFFD600))
                        }
                    }
                    else -> drawSpikes(h, active)
                }
            }

            level.fallingObjects.forEachIndexed { treeIndex, trap ->
                if (trap.kind != FallingObjectKind.FRUIT) return@forEachIndexed
                val treeState = treeRuntime.getOrNull(treeIndex)
                val progress = treeFallProgress(treeState?.fallStartedAt)
                val warningWobble = if (treeWarningActive(treeState?.fallStartedAt)) {
                    sin(elapsedMs / 42.0 + treeIndex).toFloat() * 7f
                } else 0f
                val direction = if ((treeIndex + level.number) % 2 == 0) 1f else -1f
                val baseX = trap.x + trap.size / 2f - cameraX
                val baseY = sy(trap.targetY)
                val trunkTop = trap.startY - 28f
                val trunkHeight = (trap.targetY - trunkTop).coerceAtLeast(180f)
                val tipX = baseX + direction * trunkHeight * scaleY * progress + warningWobble
                val tipY = baseY - trunkHeight * scaleY * (1f - progress)
                drawLine(Color(0xFF704326), Offset(baseX, baseY), Offset(tipX, tipY), 20f)
                drawLine(Color(0xFF815135), Offset(baseX, baseY), Offset(tipX, tipY), 8f)
                val crownColors = when (level.biome) {
                    AdventureBiome.FOREST_DAY -> listOf(Color(0xFF67B94D), Color(0xFF78CA58), Color(0xFF8AD568))
                    AdventureBiome.FOREST_SUNSET -> listOf(Color(0xFF8C7A3E), Color(0xFFB9853F), Color(0xFFC96B3A))
                    AdventureBiome.UNDERGROUND -> listOf(Color(0xFF49624A), Color(0xFF5B6D4F), Color(0xFF3F5143))
                    AdventureBiome.CAVE_NIGHT -> listOf(Color(0xFF315A61), Color(0xFF3A6E73), Color(0xFF284950))
                    AdventureBiome.DESERT_DAWN -> listOf(Color(0xFF806B3E), Color(0xFF9A7840), Color(0xFF6D5C36))
                }
                val crownCenters = listOf(
                    Offset(tipX, tipY - 10f),
                    Offset(tipX - 42f, tipY + 8f),
                    Offset(tipX + 42f, tipY + 8f),
                    Offset(tipX - 20f, tipY - 42f),
                    Offset(tipX + 25f, tipY - 40f)
                )
                crownCenters.forEachIndexed { index, center ->
                    drawCircle(crownColors[(index + treeIndex) % crownColors.size], if (index == 0) 49f else 39f, center)
                }
                drawApple(Offset(tipX - 33f, tipY - 5f), appleRadius)
                drawApple(Offset(tipX + 26f, tipY - 23f), appleRadius)
                drawApple(Offset(tipX + 47f, tipY + 15f), appleRadius)
            }

            val decorativeTreePlatforms = if (level.biome == AdventureBiome.FOREST_DAY || level.biome == AdventureBiome.FOREST_SUNSET) {
                level.platforms
                    .filter { it.kind == PlatformKind.SOLID && it.y >= 540f && it.width >= 360f }
                    .filterIndexed { index, _ -> (index + level.number) % 4 == 1 }
                    .take(3)
            } else emptyList()
            decorativeTreePlatforms.forEachIndexed { index, platform ->
                val treeX = platform.x + platform.width * 0.72f - cameraX
                if (level.fallingObjects.any { abs((it.x + it.size / 2f) - (treeX + cameraX)) < 210f }) return@forEachIndexed
                val baseY = sy(platform.y)
                val tipY = sy(platform.y - 245f)
                drawLine(Color(0xFF704326), Offset(treeX, baseY), Offset(treeX, tipY), 18f)
                val decorativeCrown = if (level.biome == AdventureBiome.FOREST_DAY) {
                    listOf(Color(0xFF67B94D), Color(0xFF78CA58), Color(0xFF8AD568))
                } else {
                    listOf(Color(0xFF8C7A3E), Color(0xFFB9853F), Color(0xFFC96B3A))
                }
                listOf(
                    Offset(treeX, tipY - 8f),
                    Offset(treeX - 36f, tipY + 12f),
                    Offset(treeX + 36f, tipY + 12f)
                ).forEachIndexed { crownIndex, center ->
                    drawCircle(decorativeCrown[(crownIndex + index) % 3], 38f, center)
                }
                drawApple(Offset(treeX - 24f, tipY + 4f), appleRadius)
                drawApple(Offset(treeX + 22f, tipY - 18f), appleRadius)
            }

            level.fallingObjects.forEachIndexed { index, trap ->
                val runtime = fallingRuntime[index]
                if (runtime.disabled) return@forEachIndexed
                val y = runtime.y
                val copies = if (trap.behavior == FallingBehavior.CHAIN) trap.chainCount else 1
                repeat(copies) { copyIndex ->
                    val x = runtime.x + (copyIndex - (copies - 1) / 2f) * trap.chainSpacing
                    val center = Offset(x + trap.size / 2f - cameraX, sy(y + trap.size / 2f))
                    val waitingOnSupport = trap.kind != FallingObjectKind.FRUIT && runtime.landedAt == null &&
                        (runtime.triggeredAt == null || elapsedMs - runtime.triggeredAt < trap.delayMs)
                    if (waitingOnSupport) {
                        val anchorY = sy((trap.startY - 72f).coerceAtLeast(18f))
                        drawLine(Color(0xFF59656A).copy(alpha = 0.82f), Offset(center.x, anchorY), Offset(center.x, center.y - trap.size * 0.40f), 5f)
                        drawRoundRect(Color(0xFF6D7473), Offset(center.x - 26f, anchorY - 7f), Size(52f, 14f), androidx.compose.ui.geometry.CornerRadius(4f))
                        repeat(3) { crack ->
                            val crackX = center.x - 17f + crack * 17f
                            drawLine(Color(0xFF353B3D), Offset(crackX, anchorY + 5f), Offset(crackX + 7f, anchorY + 16f), 2f)
                        }
                    }
                    when (trap.kind) {
                        FallingObjectKind.FRUIT -> drawApple(center, appleRadius, trap.behavior == FallingBehavior.EXPLODE)
                        FallingObjectKind.ROCK -> drawCircle(Color(0xFF78909C), trap.size / 2f, center)
                        FallingObjectKind.CRATE -> drawRoundRect(Color(0xFF9A6A3A), Offset(x - cameraX, sy(y)), Size(trap.size, trap.size * scaleY), androidx.compose.ui.geometry.CornerRadius(7f))
                        FallingObjectKind.SPIKE_BALL -> {
                            drawCircle(Color(0xFF37474F), trap.size / 2f, center)
                            repeat(10) { k ->
                                val a = k * Math.PI * 2 / 10
                                drawLine(Color(0xFFECEFF1), center, Offset(center.x + kotlin.math.cos(a).toFloat() * trap.size * 0.66f, center.y + sin(a).toFloat() * trap.size * 0.66f), 4f)
                            }
                        }
                    }
                }
                runtime.explodedAt?.let { exploded ->
                    val age = elapsedMs - exploded
                    if (age < 360L) {
                        val progress = age / 360f
                        drawCircle(Color(0xFFFF6D00).copy(alpha = 1f - progress), trap.explosionRadius * progress.coerceAtLeast(0.18f), Offset(runtime.x + trap.size / 2f - cameraX, sy(runtime.y + trap.size / 2f)))
                    }
                }
            }

            level.crushers.forEachIndexed { index, trap ->
                val runtime = crusherRuntime[index]
                val triggeredAt = runtime.triggeredAt
                if (triggeredAt != null && trap.despawnAfterMs > 0L && elapsedMs - triggeredAt >= trap.despawnAfterMs) return@forEachIndexed
                var offset = 0f
                var warningShake = 0f
                if (triggeredAt != null) {
                    val age = elapsedMs - triggeredAt
                    if (age < trap.delayMs) warningShake = sin(elapsedMs / 35.0 + index).toFloat() * 4f
                    val activeMs = (age - trap.delayMs).coerceAtLeast(0L)
                    val maxDistance = abs(trap.travel)
                    val forward = (activeMs / 1000f * trap.speed).coerceAtMost(maxDistance)
                    val reverseStart = trap.delayMs + trap.reverseAfterMs
                    val distance = if (age <= reverseStart) forward else {
                        val reversed = ((age - reverseStart) / 1000f * trap.speed).coerceAtMost(maxDistance)
                        (maxDistance - reversed).coerceAtLeast(0f)
                    }
                    offset = trap.travel.sign * distance
                }
                val x = trap.x + if (trap.axis == CrusherAxis.HORIZONTAL) offset else warningShake
                val y = trap.y + if (trap.axis == CrusherAxis.VERTICAL) offset else warningShake
                val crusherX = x - cameraX
                val crusherY = sy(y)
                val crusherHeight = trap.height * scaleY
                val (outer, inner) = when (trap.style) {
                    CrusherStyle.STONE_COLUMN -> Color(0xFF4A504D) to Color(0xFF69706C)
                    CrusherStyle.FALLING_WALL -> Color(0xFF5A5148) to Color(0xFF807364)
                    CrusherStyle.LOG_PRESS -> Color(0xFF5B3422) to Color(0xFF8A5738)
                    CrusherStyle.RUIN_BLOCK -> Color(0xFF806B52) to Color(0xFFA98D67)
                }
                if (trap.axis == CrusherAxis.VERTICAL) {
                    val anchorX = trap.x + trap.width / 2f - cameraX
                    drawLine(Color(0xFF3D4546).copy(alpha = 0.75f), Offset(anchorX, gameTop), Offset(anchorX, crusherY), 5f)
                    repeat(5) { link ->
                        val linkY = gameTop + ((crusherY - gameTop) * (link + 0.5f) / 5f)
                        drawCircle(Color(0xFF7E8A8B).copy(alpha = 0.65f), 4f, Offset(anchorX, linkY))
                    }
                } else {
                    val supportY = crusherY + crusherHeight / 2f
                    drawLine(Color(0xFF3D4546).copy(alpha = 0.75f), Offset(trap.x - cameraX, supportY), Offset(crusherX, supportY), 5f)
                }
                drawRoundRect(outer, Offset(crusherX, crusherY), Size(trap.width, crusherHeight), androidx.compose.ui.geometry.CornerRadius(9f))
                drawRoundRect(inner, Offset(crusherX + 4f, crusherY + 4f), Size((trap.width - 8f).coerceAtLeast(10f), (crusherHeight - 8f).coerceAtLeast(10f)), androidx.compose.ui.geometry.CornerRadius(7f))
                repeat(4) { line ->
                    val lineY = crusherY + (line + 1) * crusherHeight / 5f
                    drawLine(outer.copy(alpha = 0.75f), Offset(crusherX + 7f, lineY), Offset(crusherX + trap.width - 7f, lineY), 3f)
                }
                repeat(3) { crack ->
                    val cx = crusherX + trap.width * (0.25f + crack * 0.24f)
                    val cy = crusherY + crusherHeight * (0.22f + (crack % 2) * 0.28f)
                    drawLine(outer.copy(alpha = 0.85f), Offset(cx, cy), Offset(cx + 10f, cy + 14f), 2f)
                    drawLine(outer.copy(alpha = 0.85f), Offset(cx + 10f, cy + 14f), Offset(cx + 3f, cy + 25f), 2f)
                }
            }

            level.barriers.filter { it.switchIndex !in activeSwitches }.forEach { b ->
                val gateX = b.x - cameraX
                val gateY = sy(b.y)
                val gateHeight = b.height * scaleY
                drawRoundRect(
                    Color(0xFF4B514F),
                    Offset(gateX, gateY),
                    Size(b.width, gateHeight),
                    androidx.compose.ui.geometry.CornerRadius(7f)
                )
                repeat(5) { block ->
                    val blockY = gateY + block * gateHeight / 5f
                    drawLine(Color(0xFF2C302F), Offset(gateX + 3f, blockY), Offset(gateX + b.width - 3f, blockY), 3f)
                }
                drawLine(Color(0xFF777F7B), Offset(gateX + 7f, gateY + 6f), Offset(gateX + 7f, gateY + gateHeight - 6f), 4f)
                val spikeCount = max(4, (gateHeight / 52f).toInt())
                repeat(spikeCount) { spike ->
                    val centerY = gateY + (spike + 0.5f) * gateHeight / spikeCount
                    val path = Path().apply {
                        moveTo(gateX, centerY - 10f)
                        lineTo(gateX - 23f, centerY)
                        lineTo(gateX, centerY + 10f)
                        close()
                    }
                    drawPath(path, Color(0xFFE7D6B2))
                }
            }
            level.switches.forEachIndexed { index, sw ->
                val active = index in activeSwitches
                val pulse = 1f + sin(elapsedMs / 180.0 + index).toFloat() * 0.15f
                if (!active) drawCircle(Gold.copy(alpha = 0.18f), 33f * pulse, Offset(sw.x + 17f - cameraX, sy(sw.y + 22f)))
                drawRoundRect(if (active) NeonGreen else Gold, Offset(sw.x - cameraX, sy(sw.y)), Size(34f, 50f * scaleY), androidx.compose.ui.geometry.CornerRadius(8f))
                drawCircle(Color.White, 5f, Offset(sw.x + 17f - cameraX, sy(sw.y + 14f)))
            }

            level.checkpoints.forEachIndexed { index, cp ->
                if (index !in revealedCheckpoints || index in brokenDecoys) return@forEachIndexed
                val active = index in activatedCheckpoints
                val pulse = 1f + sin(elapsedMs / 170.0 + index).toFloat() * 0.12f
                val color = when {
                    active -> NeonGreen
                    level.number <= 4 -> Color(0xFF62D9C7)
                    cp.kind == CheckpointKind.DECOY -> Color(0xFFFFC857)
                    cp.kind == CheckpointKind.POPUP -> Gold
                    else -> Color(0xFF62D9C7)
                }
                drawCircle(color.copy(alpha = 0.18f), 34f * pulse, Offset(cp.x - cameraX, sy(cp.y + 20f)))
                drawRect(Color(0xFF37474F), Offset(cp.x - 3f - cameraX, sy(cp.y)), Size(6f, 82f * scaleY))
                val flag = Path().apply {
                    moveTo(cp.x - cameraX, sy(cp.y))
                    lineTo(cp.x + 43f - cameraX, sy(cp.y + 12f))
                    lineTo(cp.x - cameraX, sy(cp.y + 28f))
                    close()
                }
                drawPath(flag, color)
                if (level.number > 4 && cp.kind == CheckpointKind.DECOY && !active && (elapsedMs / 250L) % 5L == 0L) drawCircle(Color(0xFFFF1744), 3f, Offset(cp.x + 31f - cameraX, sy(cp.y + 12f)))
            }

            level.crates.forEachIndexed { index, crate ->
                if (index in destroyedCrates) return@forEachIndexed
                drawRoundRect(Color(0xFF9A6A3A), Offset(crate.x - cameraX, sy(crate.y)), Size(54f, 54f * scaleY), androidx.compose.ui.geometry.CornerRadius(5f))
                drawLine(Color(0xFF4F311E), Offset(crate.x - cameraX, sy(crate.y)), Offset(crate.x + 54f - cameraX, sy(crate.y + 54f)), 5f)
                drawLine(Color(0xFF4F311E), Offset(crate.x + 54f - cameraX, sy(crate.y)), Offset(crate.x - cameraX, sy(crate.y + 54f)), 5f)
            }

            enemies.forEachIndexed { index, e ->
                if (e.health <= 0) return@forEachIndexed
                val kind = level.enemies[index].kind
                val color = when (kind) {
                    GameEnemyKind.WALKER -> Color(0xFF7B2CBF)
                    GameEnemyKind.JUMPER -> Color(0xFFE76F51)
                    GameEnemyKind.FLYER -> Color(0xFF00A6A6)
                    GameEnemyKind.SHOOTER -> Color(0xFFB5179E)
                    GameEnemyKind.GUARDIAN -> Color(0xFF5A189A)
                }
                drawRoundRect(color, Offset(e.x - cameraX, sy(e.y)), Size(50f, 56f * scaleY), androidx.compose.ui.geometry.CornerRadius(14f))
                drawCircle(Color.White, 5f, Offset(e.x + 15f - cameraX, sy(e.y + 18f)))
                drawCircle(Color.White, 5f, Offset(e.x + 35f - cameraX, sy(e.y + 18f)))
            }
            bullets.forEach { b -> drawCircle(Gold, 6f, Offset(b.x - cameraX, sy(b.y))) }
            enemyBullets.forEach { b -> drawCircle(Color(0xFFFF4D8D), 6f, Offset(b.x - cameraX, sy(b.y))) }

            level.crystals.forEachIndexed { index, c ->
                if (index in collected) return@forEachIndexed
                val p = Path().apply {
                    moveTo(c.x - cameraX, sy(c.y - 24f)); lineTo(c.x + 18f - cameraX, sy(c.y)); lineTo(c.x - cameraX, sy(c.y + 24f)); lineTo(c.x - 18f - cameraX, sy(c.y)); close()
                }
                drawPath(p, Color(0xFF00E5FF))
            }
            level.pickups.forEachIndexed { index, pickup ->
                if (index in collectedPickups) return@forEachIndexed
                val color = when (pickup.kind) {
                    GamePickupKind.ENERGY -> Color(0xFFFF5A5F)
                    GamePickupKind.SHIELD -> Color(0xFF56CFE1)
                    GamePickupKind.POWER -> Gold
                }
                drawCircle(color.copy(alpha = 0.25f), 24f, Offset(pickup.x - cameraX, sy(pickup.y)))
                drawCircle(color, 13f, Offset(pickup.x - cameraX, sy(pickup.y)))
            }

            level.keys.forEachIndexed { index, key ->
                val visible = playerX >= key.revealTriggerX && (key.hiddenUntilSwitch == null || key.hiddenUntilSwitch in activeSwitches)
                if (!visible || index in collectedKeys) return@forEachIndexed
                val pulse = 1f + sin(elapsedMs / 170.0 + index).toFloat() * 0.12f
                val center = Offset(key.x - cameraX, sy(key.y))
                drawCircle(Gold.copy(alpha = 0.20f), 30f * pulse, center)
                drawCircle(Gold, 12f, center)
                drawCircle(Color(0xFF2C2B21), 5f, center)
                drawLine(Gold, Offset(center.x + 10f, center.y + 5f), Offset(center.x + 34f, center.y + 21f), 8f)
                drawLine(Gold, Offset(center.x + 26f, center.y + 16f), Offset(center.x + 21f, center.y + 27f), 6f)
                drawLine(Gold, Offset(center.x + 34f, center.y + 21f), Offset(center.x + 29f, center.y + 32f), 6f)
            }

            val exitReady = (!level.requiresKey || collectedKeys.size >= level.keys.size) && activeSwitches.size >= level.requiredMechanisms
            val exitX = level.goalX - cameraX
            val exitY = sy(level.goalY)
            val exitHeight = 135f * scaleY
            val readyColor = if (exitReady) NeonGreen else Color(0xFF68747A)
            when (level.exitKind) {
                LevelExitKind.DOOR -> {
                    drawRoundRect(Color(0xFF473A30), Offset(exitX - 18f, exitY), Size(76f, exitHeight), androidx.compose.ui.geometry.CornerRadius(18f))
                    drawRoundRect(if (exitReady) Color(0xFF8A633E) else Color(0xFF514B48), Offset(exitX - 11f, exitY + 7f), Size(62f, exitHeight - 7f), androidx.compose.ui.geometry.CornerRadius(15f))
                    repeat(4) { plank -> drawLine(Color(0xFF332A24).copy(alpha = 0.75f), Offset(exitX - 8f, exitY + 25f + plank * 24f * scaleY), Offset(exitX + 48f, exitY + 25f + plank * 24f * scaleY), 3f) }
                    drawCircle(if (exitReady) Gold else Color(0xFFB0BEC5), 6f, Offset(exitX + 34f, exitY + exitHeight * 0.55f))
                    if (!exitReady) {
                        drawRoundRect(Color(0xFF263238), Offset(exitX + 5f, exitY + exitHeight * 0.34f), Size(28f, 31f), androidx.compose.ui.geometry.CornerRadius(6f))
                        drawCircle(Color(0xFF263238), 11f, Offset(exitX + 19f, exitY + exitHeight * 0.34f))
                    }
                }
                LevelExitKind.CAVE, LevelExitKind.TUNNEL -> {
                    drawCircle(Color(0xFF253039), 55f, Offset(exitX + 18f, exitY + 48f))
                    drawRoundRect(Color(0xFF111922), Offset(exitX - 22f, exitY + 45f), Size(80f, exitHeight - 45f), androidx.compose.ui.geometry.CornerRadius(18f))
                    repeat(7) { rock ->
                        val angle = rock * Math.PI / 6.0
                        val rx = exitX + 18f + kotlin.math.cos(angle).toFloat() * 54f
                        val ry = exitY + 48f + sin(angle).toFloat() * 45f
                        drawCircle(Color(0xFF566169), 12f + rock % 3 * 3f, Offset(rx, ry))
                    }
                    drawCircle(readyColor.copy(alpha = 0.22f), 28f, Offset(exitX + 18f, exitY + 76f))
                }
                LevelExitKind.ASCENT, LevelExitKind.SUMMIT -> {
                    repeat(4) { step ->
                        val w = 82f - step * 12f
                        drawRoundRect(Color(0xFF82715E), Offset(exitX - 24f + step * 6f, exitY + exitHeight - 22f - step * 23f), Size(w, 18f), androidx.compose.ui.geometry.CornerRadius(5f))
                    }
                    drawLine(readyColor, Offset(exitX + 18f, exitY + 15f), Offset(exitX + 18f, exitY + 72f), 7f)
                    val arrow = Path().apply { moveTo(exitX + 18f, exitY + 5f); lineTo(exitX, exitY + 30f); lineTo(exitX + 36f, exitY + 30f); close() }
                    drawPath(arrow, readyColor)
                }
                LevelExitKind.DESCENT -> {
                    drawRoundRect(Color(0xFF403A35), Offset(exitX - 25f, exitY + 30f), Size(86f, exitHeight - 30f), androidx.compose.ui.geometry.CornerRadius(16f))
                    repeat(4) { step -> drawRect(Color(0xFF766656), Offset(exitX - 18f + step * 5f, exitY + 48f + step * 22f), Size(72f - step * 10f, 13f)) }
                    val arrow = Path().apply { moveTo(exitX + 18f, exitY + exitHeight - 4f); lineTo(exitX, exitY + exitHeight - 30f); lineTo(exitX + 36f, exitY + exitHeight - 30f); close() }
                    drawPath(arrow, readyColor)
                }
                LevelExitKind.LIFT -> {
                    drawRoundRect(Color(0xFF455A64), Offset(exitX - 28f, exitY + 5f), Size(92f, exitHeight - 5f), androidx.compose.ui.geometry.CornerRadius(9f))
                    drawLine(Color(0xFF90A4AE), Offset(exitX - 4f, exitY + 8f), Offset(exitX - 4f, exitY + exitHeight - 5f), 5f)
                    drawLine(Color(0xFF90A4AE), Offset(exitX + 40f, exitY + 8f), Offset(exitX + 40f, exitY + exitHeight - 5f), 5f)
                    drawCircle(readyColor, 8f, Offset(exitX + 53f, exitY + 23f))
                }
                LevelExitKind.BRIDGE -> {
                    repeat(6) { plank -> drawRoundRect(Color(0xFF805335), Offset(exitX - 35f + plank * 22f, exitY + 78f + sin(elapsedMs / 360.0 + plank).toFloat() * 3f), Size(19f, 16f), androidx.compose.ui.geometry.CornerRadius(3f)) }
                    drawLine(Color(0xFF4D3526), Offset(exitX - 40f, exitY + 70f), Offset(exitX + 98f, exitY + 70f), 4f)
                    drawLine(Color(0xFF4D3526), Offset(exitX - 40f, exitY + 104f), Offset(exitX + 98f, exitY + 104f), 4f)
                    drawCircle(readyColor.copy(alpha = 0.22f), 27f, Offset(exitX + 75f, exitY + 86f))
                }
                LevelExitKind.RUIN_GATE -> {
                    drawRect(Color(0xFF8B7357), Offset(exitX - 25f, exitY + 6f), Size(20f, exitHeight - 6f))
                    drawRect(Color(0xFF8B7357), Offset(exitX + 48f, exitY + 6f), Size(20f, exitHeight - 6f))
                    drawRect(Color(0xFFA78B67), Offset(exitX - 36f, exitY), Size(115f, 22f))
                    drawRoundRect(Color(0xFF30271F), Offset(exitX - 2f, exitY + 35f), Size(45f, exitHeight - 35f), androidx.compose.ui.geometry.CornerRadius(14f))
                    drawCircle(readyColor.copy(alpha = 0.25f), 25f, Offset(exitX + 20f, exitY + 78f))
                }
                LevelExitKind.TRAIL -> {
                    val trail = Path().apply { moveTo(exitX - 35f, exitY + exitHeight); quadraticBezierTo(exitX + 8f, exitY + 55f, exitX + 80f, exitY + 26f); lineTo(exitX + 100f, exitY + 64f); quadraticBezierTo(exitX + 25f, exitY + 96f, exitX - 12f, exitY + exitHeight); close() }
                    drawPath(trail, Color(0xFF9B7B55))
                    drawCircle(readyColor.copy(alpha = 0.24f), 27f, Offset(exitX + 65f, exitY + 46f))
                }
            }

            if (level.acechantePresent) {
                drawRoundRect(Color(0xFF08050D), Offset(acechanteX - cameraX, sy(playerY - 25f)), Size(42f, 98f * scaleY), androidx.compose.ui.geometry.CornerRadius(18f))
                drawCircle(Color.White, 3.5f, Offset(acechanteX + 12f - cameraX, sy(playerY + 1f)))
                drawCircle(Color.White, 3.5f, Offset(acechanteX + 29f - cameraX, sy(playerY + 1f)))
            }

            level.companion?.let { name ->
                val cx = playerX - 63f
                val color = if (name == "Luma") Color(0xFF62D9C7) else Color(0xFF7CB342)
                drawCircle(color.copy(alpha = 0.24f), 31f, Offset(cx - cameraX, sy(playerY + 34f)))
                drawCircle(color, 22f, Offset(cx - cameraX, sy(playerY + 34f)))
            }

            val playerColor = when {
                elapsedMs < invulnerableUntil && (elapsedMs / 100L) % 2L == 0L -> Color.White
                run.lifeType == "premium" -> Gold
                else -> Color(0xFFE53935)
            }
            val displayPlayerY = playerY
            val playerScale = 1f
            val displayHeight = playerHeight * playerScale
            val displayWidth = playerWidth * (0.82f + playerScale * 0.18f)
            val displayX = playerX + (playerWidth - displayWidth) / 2f
            if (!onGround && jumpsRemaining > 0 && !deathPending) drawCircle(Color(0xFF8EF6E4).copy(alpha = 0.18f), 38f, Offset(playerX + playerWidth / 2f - cameraX, sy(playerY + playerHeight / 2f)))
            drawRoundRect(playerColor, Offset(displayX - cameraX, sy(displayPlayerY)), Size(displayWidth, displayHeight * scaleY), androidx.compose.ui.geometry.CornerRadius(12f))
            if (playerScale > 0.35f) {
                drawCircle(Color.White, 5f * playerScale, Offset(displayX + displayWidth * 0.30f - cameraX, sy(displayPlayerY + displayHeight * 0.31f)))
                drawCircle(Color.White, 5f * playerScale, Offset(displayX + displayWidth * 0.70f - cameraX, sy(displayPlayerY + displayHeight * 0.31f)))
            }

            if (level.biome == AdventureBiome.FOREST_DAY || level.biome == AdventureBiome.FOREST_SUNSET) {
                repeat(20) { i ->
                    val leafX = ((i * 149f - cameraX * 0.70f + elapsedMs / (25f + i % 3 * 5f)) % (viewportWidth + 300f)) - 100f
                    val leafY = sy(185f + (i * 79 % 430))
                    val leafColor = if (level.biome == AdventureBiome.FOREST_DAY) Color(0xFF9CCC65) else Color(0xFFFFB05A)
                    drawOval(leafColor.copy(alpha = 0.18f), Offset(leafX, leafY), Size(17f, 7f))
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().background(Color(0xE8061827)).padding(horizontal = 10.dp, vertical = 4.dp).align(Alignment.TopCenter),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Text("N${level.number} · ${level.levelName}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            HudPill("❤️", "$livesRemaining/$maxLives", Color(0xFFE53935))
            HudPill("CP", "${activatedCheckpoints.count { level.checkpoints[it].kind != CheckpointKind.DECOY }}/${level.checkpoints.count { it.kind != CheckpointKind.DECOY }}", Color(0xFF62D9C7))
            if (level.requiresKey) HudPill("🔑", "${collectedKeys.size}/${level.keys.size}", Gold)
            if (level.requiredMechanisms > 0) HudPill("⚙", "${activeSwitches.size}/${level.requiredMechanisms}", Color(0xFF90A4AE))
            HudPill("↑", "x$jumpsRemaining", NeonGreen)
            Spacer(Modifier.weight(1f))
            if (shieldHits > 0) HudPill("🛡", "$shieldHits", Color(0xFF8EF6E4))
            if (!guestMode && activationRewards > 0) HudPill("⭐", "+$activationRewards", Gold)
            Text("${elapsedSeconds}s", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            IconButton(onClick = { paused = true }, modifier = Modifier.size(38.dp)) { Icon(Icons.Rounded.Pause, contentDescription = "Pausa") }
        }

        objectiveHint?.let { hint ->
            Card(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 50.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xDD0B321E)),
                shape = RoundedCornerShape(16.dp)
            ) { Text(hint, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp), color = Gold, fontWeight = FontWeight.Bold) }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                HoldButton(Icons.Rounded.ArrowBack, "Izquierda") { pressed -> moveDirection = if (pressed) -1f else if (moveDirection < 0f) 0f else moveDirection }
                HoldButton(Icons.Rounded.ArrowForward, "Derecha") { pressed -> moveDirection = if (pressed) 1f else if (moveDirection > 0f) 0f else moveDirection }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (level.weaponEnabled || weaponPowerUntil > elapsedMs) HoldButton(Icons.Rounded.PlayArrow, "Disparar", accent = Gold) { if (it) shootQueued = true }
                HoldButton(Icons.Rounded.TouchApp, "Interactuar", accent = Color(0xFF62D9C7)) { if (it) interactQueued = true }
                HoldButton(Icons.Rounded.KeyboardArrowUp, "Doble salto", accent = NeonGreen) { if (it) jumpQueued = true }
            }
        }

        if (paused) {
            OverlayCard(title = "Partida en pausa", compact = true) {
                Text("N${level.number} · ${level.levelName}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                Button(
                    onClick = { paused = false },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                ) { Text("Continuar", fontWeight = FontWeight.Bold) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedButton(
                        onClick = { musicEnabled = !musicEnabled },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (musicEnabled) "Música: sí" else "Música: no") }
                    OutlinedButton(
                        onClick = { effectsEnabled = !effectsEnabled },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (effectsEnabled) "Efectos: sí" else "Efectos: no") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedButton(
                        onClick = { vibrationEnabled = !vibrationEnabled },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (vibrationEnabled) "Vibración: sí" else "Vibración: no") }
                    OutlinedButton(
                        onClick = {
                            val enableAll = !(musicEnabled || effectsEnabled)
                            musicEnabled = enableAll
                            effectsEnabled = enableAll
                        },
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) { Text(if (musicEnabled || effectsEnabled) "Silenciar" else "Activar sonido") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    TextButton(
                        onClick = {
                            paused = false
                            pendingExitTarget = ExitTarget.LEVELS
                            endGame(GameOutcome.LOST)
                        },
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) { Text("Volver a niveles") }
                    TextButton(
                        onClick = {
                            paused = false
                            pendingExitTarget = ExitTarget.GEO_ADVENTURES
                            endGame(GameOutcome.LOST)
                        },
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) { Text("Salir del juego", color = Color(0xFFFFB4AB)) }
                }
            }
        }

        LaunchedEffect(resultSaved, pendingExitTarget) {
            if (!resultSaved) return@LaunchedEffect
            when (pendingExitTarget) {
                ExitTarget.LEVELS -> onExit()
                ExitTarget.GEO_ADVENTURES -> onQuit()
                null -> Unit
            }
            pendingExitTarget = null
        }

        LaunchedEffect(outcome, resultSaved, pendingExitTarget) {
            val finalOutcome = outcome ?: return@LaunchedEffect
            if (!resultSaved || pendingExitTarget != null || autoTransitionStarted) return@LaunchedEffect
            autoTransitionStarted = true
            when (finalOutcome) {
                GameOutcome.WON -> {
                    delay(if (level.outroStory != null) 2_500L else 1_450L)
                    if (level.number < GeoGameRules.LEVEL_COUNT) onAdvance(level.number + 1, run.lifeType) else onExit()
                }
                GameOutcome.LOST -> {
                    delay(1_350L)
                    onExit()
                }
            }
        }

        if (outcome != null) {
            OverlayCard(title = if (outcome == GameOutcome.WON) "¡Nivel superado!" else "Vidas 0/$maxLives") {
                Text("Checkpoints: ${activatedCheckpoints.size} · Muertes: $deathCount · Tiempo: ${elapsedSeconds}s")
                if (outcome == GameOutcome.WON) {
                    level.outroStory?.let { Text(it, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Text(
                        if (level.number < GeoGameRules.LEVEL_COUNT) "Continuando automáticamente al nivel ${level.number + 1}…" else "Aventura completada. Regresando al mapa…",
                        color = NeonGreen,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text("La partida terminó. Regresando automáticamente a la selección de niveles…", color = Gold, textAlign = TextAlign.Center)
                }
                resultError?.let {
                    Text(it, color = Color(0xFFFFB4AB), textAlign = TextAlign.Center)
                    Button(
                        onClick = { reportAttempt++ },
                        enabled = !reportingResult,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                    ) {
                        if (reportingResult) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = DeepGreen)
                        else Icon(Icons.Rounded.Refresh, contentDescription = null)
                        Text(" Reintentar guardado")
                    }
                }
            }
        }
    }
}

@Composable
private fun HudPill(symbol: String, value: String, accent: Color) {
    Row(
        modifier = Modifier
            .background(accent.copy(alpha = 0.16f), RoundedCornerShape(12.dp))
            .padding(horizontal = 7.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(symbol, style = MaterialTheme.typography.bodySmall)
        Text(value, color = accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun HoldButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    accent: Color = Color(0xFF90A4AE),
    onPressed: (Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .background(Color(0xD91A2C38), CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    onPressed(true)
                    tryAwaitRelease()
                    onPressed(false)
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = accent, modifier = Modifier.size(41.dp))
    }
}

@Composable
private fun OverlayCard(
    title: String,
    compact: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.78f)), contentAlignment = Alignment.Center) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0B321E)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth(if (compact) 0.70f else 0.62f)
        ) {
            Column(
                Modifier.padding(horizontal = if (compact) 18.dp else 22.dp, vertical = if (compact) 14.dp else 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 11.dp)
            ) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                content()
            }
        }
    }
}

@Composable
private fun ImmersiveLandscapeEffect() {
    val context = LocalContext.current
    DisposableEffect(context) {
        val activity = context.findActivity()
        val previousOrientation = activity?.requestedOrientation
        val window = activity?.window
        val previousSystemUiVisibility = window?.decorView?.systemUiVisibility
        val previousWindowFlags = window?.attributes?.flags
        val previousCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window?.attributes?.layoutInDisplayCutoutMode
        } else null

        fun applyImmersive() {
            val targetWindow = window ?: return
            val appBackground = android.graphics.Color.rgb(4, 13, 19)
            targetWindow.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(appBackground))
            targetWindow.decorView.setBackgroundColor(appBackground)
            targetWindow.decorView.setPadding(0, 0, 0, 0)
            targetWindow.decorView.fitsSystemWindows = false
            targetWindow.statusBarColor = android.graphics.Color.TRANSPARENT
            targetWindow.navigationBarColor = android.graphics.Color.TRANSPARENT
            targetWindow.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN or
                    android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                targetWindow.navigationBarDividerColor = android.graphics.Color.TRANSPARENT
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                targetWindow.isStatusBarContrastEnforced = false
                targetWindow.isNavigationBarContrastEnforced = false
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                targetWindow.attributes = targetWindow.attributes.apply {
                    layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    } else {
                        android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
                }
            }
            WindowCompat.setDecorFitsSystemWindows(targetWindow, false)
            ViewCompat.setOnApplyWindowInsetsListener(targetWindow.decorView) { _, _ ->
                WindowInsetsCompat.CONSUMED
            }
            ViewCompat.requestApplyInsets(targetWindow.decorView)
            @Suppress("DEPRECATION")
            run {
                targetWindow.decorView.systemUiVisibility =
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }
            WindowInsetsControllerCompat(targetWindow, targetWindow.decorView).apply {
                hide(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }

        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        applyImmersive()
        val focusListener = android.view.ViewTreeObserver.OnWindowFocusChangeListener { hasFocus ->
            if (hasFocus) applyImmersive()
        }
        window?.decorView?.viewTreeObserver?.addOnWindowFocusChangeListener(focusListener)

        onDispose {
            window?.decorView?.viewTreeObserver?.let { observer ->
                if (observer.isAlive) observer.removeOnWindowFocusChangeListener(focusListener)
            }
            window?.let { targetWindow ->
                val appBackground = android.graphics.Color.rgb(6, 29, 18)
                targetWindow.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(appBackground))
                targetWindow.decorView.setBackgroundColor(appBackground)
                targetWindow.statusBarColor = appBackground
                targetWindow.navigationBarColor = appBackground
                ViewCompat.setOnApplyWindowInsetsListener(targetWindow.decorView, null)
                ViewCompat.requestApplyInsets(targetWindow.decorView)
                if (previousWindowFlags != null) {
                    targetWindow.attributes = targetWindow.attributes.apply { flags = previousWindowFlags }
                }
                if (previousSystemUiVisibility != null) {
                    @Suppress("DEPRECATION")
                    run { targetWindow.decorView.systemUiVisibility = previousSystemUiVisibility }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && previousCutoutMode != null) {
                    targetWindow.attributes = targetWindow.attributes.apply {
                        layoutInDisplayCutoutMode = previousCutoutMode
                    }
                }
                WindowInsetsControllerCompat(targetWindow, targetWindow.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
                WindowCompat.setDecorFitsSystemWindows(targetWindow, true)
            }
            if (previousOrientation != null) activity?.requestedOrientation = previousOrientation
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
