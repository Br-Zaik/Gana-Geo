package com.ganageo.app.tools

import java.util.ArrayDeque
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class GeoAdventureLevelsTest {
    private val levels get() = (1..GeoGameRules.LEVEL_COUNT).map(GeoAdventureLevelFactory::build)

    @Test
    fun createsTwentyConnectedAdventureLevelsWithoutMandatoryCollectibles() {
        assertEquals(20, levels.size)
        levels.forEachIndexed { index, level ->
            assertEquals(index + 1, level.number)
            assertTrue("Nivel ${level.number}: demasiado corto", level.width >= 6_800f)
            assertEquals("Nivel ${level.number}: no debe exigir cristales", 0, level.requiredCrystals)
            assertTrue("Nivel ${level.number}: quedaron cristales obligatorios", level.crystals.isEmpty())
            assertTrue("Nivel ${level.number}: faltan enemigos", level.enemies.isNotEmpty())
            val threatCount = level.hazards.size + level.enemies.size + level.fallingObjects.size +
                level.crushers.size + level.chasingHoles.size + level.fans.size
            assertTrue("Nivel ${level.number}: pocas amenazas jugables", threatCount >= 25)
            assertTrue("Nivel ${level.number}: par inválido", level.parSeconds >= GeoGameRules.PREMIUM_ACTIVATION_SECONDS)
        }
    }

    @Test
    fun everyExitContinuesIntoTheNextLevelEntry() {
        levels.zipWithNext().forEach { (current, next) ->
            assertEquals(
                "La salida del nivel ${current.number} no conecta con la entrada del ${next.number}",
                current.exitConnection,
                next.entryConnection
            )
        }
        assertEquals("awakening", levels.first().entryConnection)
        assertEquals("adventure-end", levels.last().exitConnection)
    }

    @Test
    fun actsProgressFromDayToDepthsNightAndDesertDawn() {
        assertTrue(levels.slice(0..3).all { it.biome == AdventureBiome.FOREST_DAY })
        assertTrue(levels.slice(4..7).all { it.biome == AdventureBiome.FOREST_SUNSET })
        assertTrue(levels.slice(8..9).all { it.biome == AdventureBiome.UNDERGROUND })
        assertTrue(levels.slice(10..14).all { it.biome == AdventureBiome.CAVE_NIGHT })
        assertTrue(levels.slice(15..19).all { it.biome == AdventureBiome.DESERT_DAWN })
    }

    @Test
    fun terrainIsARealMazeWithFloorsCeilingsAndSideStructures() {
        levels.forEach { level ->
            val distinctHeights = level.platforms.map { it.y }.distinct()
            val verticalRange = distinctHeights.maxOrNull()!! - distinctHeights.minOrNull()!!
            val tallStructures = level.platforms.count { it.height >= 90f }
            val roofStructures = level.platforms.count { it.y <= 1f && it.height >= 90f }
            assertTrue("Nivel ${level.number}: muy pocas alturas", distinctHeights.size >= 6)
            assertTrue("Nivel ${level.number}: todavía se siente plano", verticalRange >= 180f)
            assertTrue("Nivel ${level.number}: faltan muros y bloques laterales", tallStructures >= 5)
            assertTrue("Nivel ${level.number}: faltan techos de laberinto", roofStructures >= 2)
        }
    }

    @Test
    fun adjacentLevelsDoNotRepeatTheSameOpening() {
        fun openingSignature(level: AdventureLevel): String {
            val firstTerrain = level.platforms.sortedBy { it.x }.take(3)
                .joinToString("|") { "${it.y.toInt()}:${it.kind}" }
            return "${level.biome}:${level.entryKind}:${level.spawnY.toInt()}:$firstTerrain"
        }
        levels.zipWithNext().forEach { (current, next) ->
            assertTrue(
                "Los niveles ${current.number} y ${next.number} repiten el mismo inicio",
                openingSignature(current) != openingSignature(next)
            )
        }
        assertTrue("No debe repetirse pinchos + checkpoint falso al inicio", levels.all { level ->
            level.checkpoints.none { it.kind == CheckpointKind.DECOY && it.x < 600f }
        })
    }

    @Test
    fun spikesAreAttachedToRealFloorOrCeilingStructures() {
        levels.forEach { level ->
            level.hazards.forEach { hazard ->
                when (hazard.orientation) {
                    HazardOrientation.UP -> assertTrue("Nivel ${level.number}: pinchos de piso flotantes", level.platforms.any { platform ->
                        platform.x <= hazard.x + 3f && platform.x + platform.width >= hazard.x + hazard.width - 3f &&
                            abs(platform.y - (hazard.y + hazard.height)) <= 5f
                    })
                    HazardOrientation.DOWN -> assertTrue("Nivel ${level.number}: pinchos de techo sin techo", level.platforms.any { platform ->
                        platform.x <= hazard.x && platform.x + platform.width >= hazard.x + hazard.width &&
                            abs((platform.y + platform.height) - hazard.y) <= 5f
                    })
                    HazardOrientation.LEFT, HazardOrientation.RIGHT -> assertTrue(
                        "Nivel ${level.number}: pincho lateral sin ciclo aprendible",
                        hazard.cycleMs > 0L && hazard.height <= 120f
                    )
                }
            }
        }
    }

    @Test
    fun keysOpenOnlyPurposefulLockedDoors() {
        val keyLevels = levels.filter { it.requiresKey }
        assertEquals(setOf(4, 9, 15, 18, 20), keyLevels.map { it.number }.toSet())
        keyLevels.forEach { level ->
            assertTrue("Nivel ${level.number}: puerta con llave sin llave", level.keys.isNotEmpty())
            assertEquals("Nivel ${level.number}: la llave debe abrir una puerta", LevelExitKind.DOOR, level.exitKind)
            level.keys.forEach { key ->
                assertTrue("Nivel ${level.number}: llave fuera del terreno", level.platforms.any { platform ->
                    key.x in platform.x..(platform.x + platform.width) && abs(key.y - (platform.y - 72f)) <= 1f
                })
            }
        }
    }

    @Test
    fun realCheckpointsStayPermanentAndSafe() {
        levels.forEach { level ->
            val real = level.checkpoints.filter { it.kind != CheckpointKind.DECOY }
            assertTrue("Nivel ${level.number}: faltan checkpoints reales", real.size >= 2)
            real.forEach { checkpoint ->
                assertTrue("Nivel ${level.number}: checkpoint sin plataforma sólida", level.platforms.any { platform ->
                    platform.kind == PlatformKind.SOLID &&
                        checkpoint.x in platform.x..(platform.x + platform.width) &&
                        abs(platform.y - (checkpoint.y + 85f)) < 0.1f
                })
                assertTrue("Nivel ${level.number}: checkpoint junto a peligro", level.hazards.none { hazard ->
                    abs((hazard.x + hazard.width / 2f) - checkpoint.x) < 85f
                })
                assertTrue("Nivel ${level.number}: checkpoint bajo objeto que cae", level.fallingObjects.none { falling ->
                    abs((falling.x + falling.size / 2f) - checkpoint.x) < 100f
                })
            }
        }
        assertTrue("Los checkpoints falsos deben usarse con moderación", levels.sumOf { level ->
            level.checkpoints.count { it.kind == CheckpointKind.DECOY }
        } <= 5)
    }

    @Test
    fun applesAndFallingObjectsHaveBoundedUsefulLifecycles() {
        val falling = levels.flatMap { it.fallingObjects }
        val fruit = falling.filter { it.kind == FallingObjectKind.FRUIT }
        assertTrue(fruit.any { it.behavior == FallingBehavior.EXPLODE })
        assertTrue(fruit.any { it.behavior == FallingBehavior.CHASE })
        assertTrue(fruit.any { it.behavior == FallingBehavior.CHAIN })
        assertTrue(fruit.any { it.treeFallsAfterTrap })
        assertTrue(fruit.filter { it.behavior == FallingBehavior.CHASE }.all {
            it.chaseDurationMs <= 5_500L && it.chaseMaxTravel <= 850f
        })
        assertTrue(fruit.filter { it.behavior == FallingBehavior.EXPLODE }.all {
            it.explosionDelayMs >= 650L
        })
        assertTrue("Debe haber rocas que se convierten en camino", falling.any { it.becomesPlatform })
    }

    @Test
    fun fallingWallsAreSmallerWarnedAndAestheticallyTemporary() {
        val crushers = levels.flatMap { it.crushers }
        val fallingWalls = crushers.filter { it.style == CrusherStyle.FALLING_WALL }
        assertTrue(fallingWalls.isNotEmpty())
        fallingWalls.forEach { wall ->
            assertTrue("Muro demasiado ancho", wall.width <= 170f)
            assertTrue("Muro sin aviso", wall.delayMs >= 300L)
            assertTrue("Muro permanente tras caer", wall.despawnAfterMs in 2_500L..3_500L)
        }
        crushers.filter { it.axis == CrusherAxis.HORIZONTAL }.forEach { wall ->
            assertTrue("Prensa horizontal demasiado larga", abs(wall.travel) <= 150f)
            assertTrue("Prensa horizontal demasiado rápida", wall.speed <= 300f)
            assertTrue("Prensa horizontal sin ventana", wall.reverseAfterMs >= 1_450L)
        }
    }

    @Test
    fun reactivePlatformFamiliesExistWithoutTimerOnlyFloors() {
        val allPlatforms = levels.flatMap { it.platforms }
        assertTrue(allPlatforms.any { it.kind == PlatformKind.FALLING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.PROXIMITY_DISAPPEARING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.REVEALING })
        assertTrue(allPlatforms.any { it.kind == PlatformKind.BOUNCE })
        assertTrue("No debe haber pisos que desaparezcan solo por reloj", allPlatforms.none {
            it.kind == PlatformKind.DISAPPEARING
        })
        assertTrue(allPlatforms.filter { it.kind == PlatformKind.PROXIMITY_DISAPPEARING }.all {
            it.delayMs >= 900L
        })
    }

    @Test
    fun everyLevelHasAnApproximateReachableRouteFromSpawnToExit() {
        levels.forEach { level ->
            val platforms = (level.platforms + level.movingPlatforms.map {
                GamePlatform(it.x, it.y, it.width, 26f)
            }).sortedBy { it.x }
            val startIndices = platforms.indices.filter { index ->
                val platform = platforms[index]
                level.spawnX in platform.x..(platform.x + platform.width) &&
                    abs(platform.y - (level.spawnY + 58f)) < 15f
            }
            assertTrue("Nivel ${level.number}: el inicio no está sobre terreno", startIndices.isNotEmpty())

            val reachable = startIndices.toMutableSet()
            val pending = ArrayDeque<Int>()
            startIndices.forEach(pending::add)

            while (pending.isNotEmpty()) {
                val currentIndex = pending.removeFirst()
                val current = platforms[currentIndex]
                for (candidateIndex in platforms.indices) {
                    if (candidateIndex in reachable) continue
                    val candidate = platforms[candidateIndex]
                    val horizontalGap = when {
                        candidate.x > current.x + current.width -> candidate.x - (current.x + current.width)
                        current.x > candidate.x + candidate.width -> current.x - (candidate.x + candidate.width)
                        else -> 0f
                    }
                    val upwardDistance = current.y - candidate.y
                    val downwardDistance = candidate.y - current.y
                    if (horizontalGap <= 260f && upwardDistance <= 190f && downwardDistance <= 260f) {
                        reachable += candidateIndex
                        pending.add(candidateIndex)
                    }
                }
            }

            val goalHasRoute = platforms.indices.any { index ->
                val platform = platforms[index]
                index in reachable &&
                    level.goalX in platform.x..(platform.x + platform.width) &&
                    abs(platform.y - (level.goalY + 135f)) < 20f
            }
            assertTrue("Nivel ${level.number}: no hay una ruta aproximada desde GEO hasta la salida", goalHasRoute)
        }
    }

    @Test
    fun exitTypesStayVariedAcrossTheAdventure() {
        val exitTypes = levels.map { it.exitKind }.toSet()
        assertTrue(exitTypes.contains(LevelExitKind.ASCENT))
        assertTrue(exitTypes.contains(LevelExitKind.DESCENT))
        assertTrue(exitTypes.contains(LevelExitKind.DOOR))
        assertTrue(exitTypes.contains(LevelExitKind.CAVE))
        assertTrue(exitTypes.contains(LevelExitKind.TUNNEL))
        assertTrue(exitTypes.contains(LevelExitKind.BRIDGE))
        assertTrue(exitTypes.contains(LevelExitKind.LIFT))
        assertTrue(exitTypes.contains(LevelExitKind.RUIN_GATE))
        assertTrue(exitTypes.contains(LevelExitKind.SUMMIT))
    }

    @Test
    fun everyLevelKeepsTensionAcrossTheWholeRoute() {
        levels.forEach { level ->
            val threatPositions = buildList {
                level.hazards.forEach { add(it.x + it.width / 2f) }
                level.enemies.forEach { add(it.x) }
                level.fallingObjects.forEach { add(it.x + it.size / 2f) }
                level.crushers.forEach { add(it.x + it.width / 2f) }
                level.chasingHoles.forEach { add(it.startX + it.width / 2f) }
                level.fans.forEach { add(it.x + it.width / 2f) }
            }.sorted()
            assertTrue("Nivel ${level.number}: faltan amenazas", threatPositions.size >= 25)
            val structureCount = level.platforms.count { it.height >= 90f }
            assertTrue("Nivel ${level.number}: el recorrido sigue demasiado abierto", structureCount >= 5)
        }
    }

    @Test
    fun everyLevelStillUsesExactlyFifteenInternalLives() {
        levels.forEach { level ->
            assertEquals(15, GeoGameRules.attemptsForLevel(level.number))
        }
    }
}
