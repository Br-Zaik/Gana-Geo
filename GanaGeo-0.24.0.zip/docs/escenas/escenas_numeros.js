PAL.MATH={container:'#102A48',badge:'#123B63',accent:'#6EC1FF'};
const MDARK='#0A1B30',MMUTED='#9CC3E6';
Object.assign(SCENES,{
 SCIENTIFIC_CALCULATOR(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=22,y=8,w=58,h=84;rr(c,x,y,w,h,7,'#1C2430',fi);rr(c,x+5,y+6,w-10,20,3,'#DCEBFA',fi);
  const keys=[];for(let r=0;r<4;r++)for(let k=0;k<4;k++)keys.push([x+6+k*12.5,y+31+r*12.5]);
  const press=[[0,.08],[7,.14],[1,.2],[11,.26],[15,.34]];
  keys.forEach(([kx,ky],i)=>{const op=(i%4==3);rr(c,kx,ky,10,10,2.5,op?pal.accent:'#334155',fi);});
  press.forEach(([i,st])=>{const t=seg(p,st,st+.06);if(t>0&&t<1){const [kx,ky]=keys[i];rr(c,kx,ky,10,10,2.5,'#FFFFFF',.7*Math.sin(t*Math.PI)*fl);}});
  const res=seg(p,.4,.5);textR(c,'2+3×4',x+w-8,y+12,6.5,'#2B3A55',fi*(1-res*.4));if(res>0){c.save();c.translate(x+w-8,y+21);const s=back(res);c.scale(s,s);textR(c,'= 14',0,0,8.5,'#0B4F8A',fl);c.restore();}
  const gx=92,gy=50;line(c,gx,gy,gx+64,gy,'#FFFFFF',.8,.4*fi);line(c,gx+6,20,gx+6,80,'#FFFFFF',.8,.4*fi);
  const ct=seg(p,.3,.7);if(ct>0){c.save();c.globalAlpha*=fl;c.strokeStyle=pal.accent;c.lineWidth=1.8;c.lineCap='round';c.beginPath();const N=40;for(let i=0;i<=N*ct;i++){const u=i/N;const xx=gx+6+u*56,yy=gy-Math.sin(u*Math.PI*2.4)*18;i?c.lineTo(xx,yy):c.moveTo(xx,yy);}c.stroke();c.restore();}
  textL(c,'sin x',gx+40,24,6,MMUTED,seg(p,.6,.7)*fl,false);
 },
 UNIT_CONVERTER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const rx=14,ry=18;rr(c,rx,ry,74,14,2,'#F4D27A',fi);for(let i=0;i<=14;i++){const xx=rx+3+i*5;line(c,xx,ry,xx,ry+(i%5==0?7:4),'#8A6A1E',.8,fi);}
  const ft=eOut(seg(p,.06,.28));rr(c,rx,ry+15,74*ft,3,1.5,pal.accent,fi*fl);
  textL(c,'100 cm',rx,ry+26,6.4,'#FFFFFF',fi);
  const at=seg(p,.28,.4);if(at>0){arrow(c,96,112,ry+7,pal.accent,eOut(at),fl);c.save();c.translate(136,ry+7);const s=back(seg(p,.34,.46));c.scale(s,s);rr(c,-18,-8,36,16,5,MDARK,fl);text(c,'1 m',0,.4,7.4,'#FFFFFF',fl);c.restore();}
  const tx=30,ty=56;rr(c,tx-4,ty,8,30,4,'#E9EEF5',fi);circle(c,tx,ty+32,6,'#E9EEF5',fi);
  const mt=eIO(seg(p,.45,.66));circle(c,tx,ty+32,4.2,'#FF6B6B',fi);rr(c,tx-2,lerp(ty+26,ty+6,mt),4,lerp(6,26,mt)+2,1.5,'#FF6B6B',fi*fl);
  textL(c,'0 °C',tx+12,ty+16,6.4,'#FFFFFF',fi);
  const bt=seg(p,.62,.72);if(bt>0){arrow(c,96,112,ty+16,pal.accent,eOut(bt),fl);c.save();c.translate(136,ty+16);const s=back(seg(p,.66,.78));c.scale(s,s);rr(c,-18,-8,36,16,5,MDARK,fl);text(c,'32 °F',0,.4,6.4,'#FFFFFF',fl);c.restore();}
 },
 PERCENT_RULE(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  c.save();c.globalAlpha*=fi;c.fillStyle='#F4F6F8';c.beginPath();c.moveTo(12,40);c.lineTo(22,26);c.lineTo(78,26);c.lineTo(78,54);c.lineTo(22,54);c.closePath();c.fill();c.restore();circle(c,22,40,2.4,'#102A48',fi);
  const st=seg(p,.28,.38);text(c,'S/ 80',50,40.5,9,'#102A48',fi*(1-.45*st));line(c,36,41,64,39,'#E5484D',1.6,fl*st);
  const sk=seg(p,.12,.24);if(sk>0){const s=lerp(2.2,1,eOut(sk));c.save();c.translate(70,26);c.rotate(-.2);c.scale(s,s);circle(c,0,0,11,'#E5484D',fl*clamp(sk*2));text(c,'-25%',0,.4,6.4,'#FFFFFF',fl*clamp(sk*2));c.restore();}
  const nt=seg(p,.38,.5);if(nt>0){c.save();c.translate(46,72);const s=back(nt);c.scale(s,s);rr(c,-20,-9,40,18,6,GREEN,fl);text(c,'S/ 60',0,.6,9,'#06210F',fl);c.restore();}
  const cx=128,cy=50,r=22;const pull=eOut(seg(p,.5,.66))*6;
  c.save();c.globalAlpha*=fi;c.fillStyle=pal.accent;c.beginPath();c.moveTo(cx,cy);c.arc(cx,cy,r,0,Math.PI*1.5);c.closePath();c.fill();c.restore();
  const ox=Math.cos(-Math.PI/4)*pull,oy=Math.sin(-Math.PI/4)*pull;
  c.save();c.globalAlpha*=fi;c.fillStyle='#E5484D';c.beginPath();c.moveTo(cx+ox,cy+oy);c.arc(cx+ox,cy+oy,r,-Math.PI/2,0);c.closePath();c.fill();c.restore();
 },
 GRADES_AVERAGES(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const base=82,vals=[12,15,9,17],labels=['12','15','09','17'];
  line(c,14,base,96,base,'#FFFFFF',.8,.4*fi);
  vals.forEach((v,i)=>{const t=eOut(seg(p,.06+i*.08,.24+i*.08));const bx=20+i*19,bh=v*3*t;rr(c,bx,base-bh,12,bh,2,v<11?'#FF6B6B':pal.accent,fi*fl);
   text(c,labels[i],bx+6,base-bh-5,5.4,'#FFFFFF',fi*fl*clamp(t*3));});
  const at=seg(p,.44,.56);if(at>0){const ay=base-13.25*3;c.save();c.globalAlpha*=fl*at;c.strokeStyle='#FFD54F';c.lineWidth=1;c.setLineDash([3,2]);c.beginPath();c.moveTo(14,ay);c.lineTo(14+82*eOut(at),ay);c.stroke();c.restore();
   c.save();c.translate(128,36);const s=back(at);c.scale(s,s);rr(c,-22,-8,44,16,5,MDARK,fl);text(c,'Prom. 13',0,.4,6.2,'#FFD54F',fl);c.restore();}
  const pt=seg(p,.6,.72);if(pt>0){c.save();c.translate(128,64);c.rotate(-.14);const s=lerp(1.8,1,eOut(pt));c.scale(s,s);rrStroke(c,-24,-8,48,16,4,GREEN,1.6,fl*clamp(pt*2));text(c,'Aprobado',0,.4,6.4,GREEN,fl*clamp(pt*2));c.restore();}
 },
 GEOMETRY(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const A=[22,30],B=[22,80],C=[82,80];const pts=[A,B,C,A];
  const ft=eOut(seg(p,.4,.52));if(ft>0){c.save();c.globalAlpha*=.35*ft*fl;c.fillStyle=pal.accent;c.beginPath();c.moveTo(...A);c.lineTo(...B);c.lineTo(...C);c.closePath();c.fill();c.restore();}
  const et=seg(p,.06,.38)*3;c.save();c.globalAlpha*=fi*Math.max(fl, et<3?1:fl);c.strokeStyle='#FFFFFF';c.lineWidth=1.8;c.lineJoin='round';c.lineCap='round';c.beginPath();c.moveTo(...A);
  for(let k=0;k<3;k++){const t=clamp(et-k);if(t<=0)break;const [x1,y1]=pts[k],[x2,y2]=pts[k+1];c.lineTo(lerp(x1,x2,t),lerp(y1,y2,t));}c.stroke();c.restore();
  if(et>1.2){rrStroke(c,22,74,6,6,0,'#FFFFFF',1,fi*fl);}
  text(c,'6',14,56,6,MMUTED,fi*clamp(et-0.5));text(c,'8',52,88,6,MMUTED,fi*clamp(et-1.5));
  const at=seg(p,.52,.64);if(at>0){c.save();c.translate(42,66);c.scale(back(at),back(at));text(c,'A = 24',0,0,6.4,'#FFFFFF',fl);c.restore();}
  const cx=128,cy=50,r=22;const rt=eIO(seg(p,.3,.62));
  if(rt>0){c.save();c.globalAlpha*=fl;c.strokeStyle=pal.accent;c.lineWidth=1.8;c.lineCap='round';c.beginPath();c.arc(cx,cy,r,0,Math.PI*2*rt);c.stroke();c.restore();
   c.save();c.globalAlpha*=.18*fl*rt;c.fillStyle=pal.accent;c.beginPath();c.moveTo(cx,cy);c.arc(cx,cy,r,0,Math.PI*2*rt);c.closePath();c.fill();c.restore();}
  const ang=Math.PI*2*rt;line(c,cx,cy,cx+Math.cos(ang)*r,cy+Math.sin(ang)*r,'#FFFFFF',1.4,fi*fl);circle(c,cx,cy,2,'#FFFFFF',fi);
  text(c,'r',cx+Math.cos(ang)*r*.5,cy+Math.sin(ang)*r*.5-4,6,'#FFFFFF',fi*fl*clamp(rt*4));
 }
});
