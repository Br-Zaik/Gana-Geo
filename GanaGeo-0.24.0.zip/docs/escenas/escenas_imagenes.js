PAL.IMAGE={container:'#402511',badge:'#5A3517',accent:'#FFB35A'};
function dashedRect(c,x,y,w,h,col,lw,alpha=1){c.save();c.globalAlpha*=alpha;c.strokeStyle=col;c.lineWidth=lw;c.setLineDash([3,2]);c.strokeRect(x,y,w,h);c.restore();}
function pill(c,label,x,y,w,col,txt,size,alpha=1,scale=1){c.save();c.translate(x,y);c.scale(scale,scale);rr(c,-w/2,-5,w,10,5,col,alpha);text(c,label,0,0.4,size,txt,alpha);c.restore();}
const IMG_COLS=[['#6FB7FF','#3DDC84'],['#FFB35A','#E5484D'],['#C997FF','#6DE1D2'],['#74F1FF','#22A06B']];
Object.assign(SCENES,{
 IMAGE_BATCH_STUDIO(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const fx=62,fy=14,fw=58,fh=72;
  const ft=eOut(seg(p,.46,.6));rr(c,fx-2,fy-2,fw+4,fh+4,4,'#FFFFFF',ft*fl);
  for(let i=0;i<4;i++){const t=eIO(seg(p,.08+i*.08,.34+i*.08));
    const sx=18+i*3,sy=26+i*4,sw=36,sh=27;const cw=(fw-6)/2,ch=(fh-6)/2;const tx=fx+2+(i%2)*(cw+2),ty=fy+2+Math.floor(i/2)*(ch+2);
    const x=lerp(sx,tx,t),y=lerp(sy,ty,t),w=lerp(sw,cw,t),h=lerp(sh,ch,t);const rot=(1-t)*(i-1.5)*0.12;
    c.save();c.translate(x+w/2,y+h/2);c.rotate(rot);photo(c,-w/2,-h/2,w,h,fl*fi,...IMG_COLS[i]);c.restore();}
  const zt=seg(p,.64,.76);if(zt>0){arrow(c,126,138,50,pal.accent,eOut(zt),fl);badge(c,'ZIP',153,50,'#C97A1E',fl,back(zt));}
 },
 COMPRESS_IMAGE(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const t=eIO(seg(p,.12,.5));
  const x=lerp(14,100,t),y=lerp(12,24,t),w=lerp(70,44,t),h=lerp(52,33,t);
  dashedRect(c,14,12,70,52,'#FFFFFF',.8,.4*seg(p,.2,.4)*fl);
  photo(c,x,y,w,h,fl*fi,'#6FB7FF','#3DDC84');
  const la=lerp(1,.55,seg(p,.12,.3))*fi*fl;text(c,'4.2 MB',49,76,6,'#FFFFFF',la);line(c,38,76,60,76,'#FFFFFF',.9,la*seg(p,.3,.42));
  const bw=lerp(60,16,t);const bc=t<.5?'#E5484D':GREEN;rr(c,20,86,60,4,2,'#000',.25*fi*fl);rr(c,20,86,bw,4,2,bc,fl*fi);
  arrow(c,86,96,40,pal.accent,eOut(seg(p,.5,.6)),fl*.0);
  const rt=seg(p,.52,.64);if(rt>0){text(c,'320 KB',122,66,6,'#FFFFFF',fl*rt);pill(c,'-92%',122,79,22,GREEN,'#06210F',5.4,fl,back(seg(p,.6,.72)));}
 },
 RESIZE_IMAGE(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=24,y=12;const t=eIO(seg(p,.15,.55));const w=lerp(84,52,t),h=lerp(63,39,t);
  dashedRect(c,x,y,84,63,'#FFFFFF',.8,.45*fi);
  photo(c,x,y,w,h,fl*fi,'#FFB35A','#E5484D');
  const hx=x+w,hy=y+h;circle(c,hx,hy,3.4,'#FFFFFF',fl*fi);circle(c,hx,hy,2,pal.accent,fl*fi);
  const lbl=t<.5?'1920 × 1080':'800 × 450';pill(c,lbl,140,40,38,t<.5?'#2A1608':pal.accent,t<.5?'#FFFFFF':'#3A1F06',5.4,fl*fi);
  if(t>=1){const ct=seg(p,.58,.7);check(c,140,56,7,GREEN,ct,fl);}
 },
 CONVERT_IMAGE(c,p,pal){
  const fl=fadeLoop(p);
  photo(c,14,24,52,40,1,'#6FB7FF','#3DDC84');badge(c,'JPG',58,24,'#C97A1E');
  arrow(c,72,90,44,pal.accent,eOut(seg(p,.08,.2)),fl);
  const outs=[['PNG','#3D7BFF',98,12,'#C997FF','#6DE1D2'],['WEBP','#22A06B',98,52,'#74F1FF','#22A06B']];
  outs.forEach(([l,col,ox,oy,s1,s2],i)=>{const t=seg(p,.22+i*.18,.38+i*.18);if(t<=0)return;const s=back(t);
    c.save();c.translate(ox+22,oy+16);c.scale(s,s);photo(c,-22,-16,44,32,fl,'#6FB7FF','#3DDC84');c.restore();badge(c,l,ox+44,oy+2,col,fl,s);});
 },
 CROP_ROTATE_IMAGE(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const px=12,py=16,pw=72,ph=54;photo(c,px,py,pw,ph,fi,'#C997FF','#6DE1D2');
  const t=eIO(seg(p,.08,.36));const cx=lerp(px,px+16,t),cy=lerp(py,py+8,t),cw=lerp(pw,40,t),ch=lerp(ph,38,t);
  const dim=.5*t*fi;rr(c,px,py,pw,cy-py,0,'#000',dim);rr(c,px,cy+ch,pw,py+ph-cy-ch,0,'#000',dim);rr(c,px,cy,cx-px,ch,0,'#000',dim);rr(c,cx+cw,cy,px+pw-cx-cw,ch,0,'#000',dim);
  c.save();c.globalAlpha*=fi;c.strokeStyle='#fff';c.lineWidth=.6;c.strokeRect(cx,cy,cw,ch);c.globalAlpha*=.5;for(let k=1;k<3;k++){c.beginPath();c.moveTo(cx+cw*k/3,cy);c.lineTo(cx+cw*k/3,cy+ch);c.moveTo(cx,cy+ch*k/3);c.lineTo(cx+cw,cy+ch*k/3);c.stroke();}c.restore();
  const L=5;[[cx,cy,1,1],[cx+cw,cy,-1,1],[cx,cy+ch,1,-1],[cx+cw,cy+ch,-1,-1]].forEach(([x,y,dx,dy])=>{line(c,x,y,x+L*dx,y,'#fff',1.8,fi);line(c,x,y,x,y+L*dy,'#fff',1.8,fi);});
  arrow(c,90,104,44,pal.accent,eOut(seg(p,.4,.5)),fl);
  const at=seg(p,.48,.56);if(at>0){const rt=eIO(seg(p,.56,.76));c.save();c.translate(134,44);c.rotate(rt*Math.PI/2);photo(c,-20,-19,40,38,fl*at,'#C997FF','#6DE1D2');c.restore();
   c.save();c.globalAlpha*=fl*at;c.strokeStyle=pal.accent;c.lineWidth=1.6;c.lineCap='round';c.beginPath();c.arc(134,44,27,-Math.PI*0.35,-Math.PI*0.35+rt*Math.PI*0.6);c.stroke();c.restore();}
 },
 WATERMARK_IMAGE(c,p,pal){
  const fl=fadeLoop(p);
  const px=14,py=10,pw=104,ph=78;photo(c,px,py,pw,ph,1,'#FFB35A','#E5484D');
  const t1=eOut(seg(p,.1,.32));if(t1>0){text(c,'© Tu marca',lerp(110,96,t1)+.5,78.6,7,'#000000',.35*t1*fl);text(c,'© Tu marca',lerp(110,96,t1),78,7,'#FFFFFF',t1*fl*.95);}
  const t2=seg(p,.4,.6);if(t2>0){c.save();c.beginPath();c.rect(px,py,pw,ph);c.clip();for(let r=0;r<3;r++)for(let k=0;k<3;k++){c.save();c.translate(px+18+k*34+(r%2)*12,py+16+r*22);c.rotate(-0.45);text(c,'Tu marca',0,0,5,'#FFFFFF',.35*t2*fl);c.restore();}c.restore();}
  const sx=142;line(c,sx,18,sx,80,'#FFFFFF',2.2,.25);const kt=eIO(seg(p,.12,.6));const ky=lerp(72,30,kt);line(c,sx,ky,sx,80,pal.accent,2.2,fl);circle(c,sx,ky,4,'#FFFFFF',fl);circle(c,sx,ky,2.2,pal.accent,fl);
 }
});
