PAL.ACADEMIC={container:'#2E184B',badge:'#43216C',accent:'#C997FF'};
const SDARK='#1E0F33',SMUTED='#BFA8DE';
Object.assign(SCENES,{
 NUMBER_SYSTEMS(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);const bits=[1,0,1,0];
  for(let i=0;i<4;i++){const x=16+i*19,y=24;const t=seg(p,.08+i*.08,.16+i*.08);const on=bits[i]==1&&t>.5;
   rr(c,x,y,16,22,3,on?pal.accent:SDARK,fi);text(c,t>.5?String(bits[i]):'0',x+8,y+11.5,9,on?'#2E184B':'#7E6A9C',fi);}
  text(c,'BIN',50,54,5,SMUTED,fi);
  arrow(c,90,100,44,pal.accent,eOut(seg(p,.42,.5)),fl);
  const cards=[['DEC','10',16,.5],['HEX','A',52,.62]];
  cards.forEach(([k,v,y,st])=>{const t=seg(p,st,st+.12);if(t<=0)return;c.save();c.translate(130,y+13);const s=back(t);c.scale(s,s);rr(c,-24,-13,48,26,5,SDARK,fl);textL(c,k,-19,-6,5,SMUTED,fl);text(c,v,4,2,12,'#FFFFFF',fl);c.restore();});
 },
 CITATION_GENERATOR(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  rr(c,14,24,26,36,2,'#7B4FB8',fi);rr(c,14,24,4,36,1,'#5B3790',fi);line(c,22,32,36,32,'#E9DDFB',1.4,fi);line(c,22,37,33,37,'#E9DDFB',1.2,fi);
  const cx=58,cy=26,cw=98,ch=52;rr(c,cx+1.2,cy+1.6,cw,ch,4,'#000',.22*fi);rr(c,cx,cy,cw,ch,4,PAPER,fi);
  text(c,'“ ”',cx+10,cy+12,12,pal.accent,fi);
  const chips=[['Autor',.06,0],['Título',.16,1],['Año',.26,2]];
  chips.forEach(([l,st,i])=>{const t=eIO(seg(p,st,st+.16));const tx=cx+20,ty=cy+16+i*11;const x=lerp(28,tx+12,t),y=lerp(44,ty,t);
   if(t<1){c.save();c.translate(x,y);rr(c,-12,-4.5,24,9,4.5,pal.accent,fi);text(c,l,0,.4,5,'#2E184B',fi,false);c.restore();}
   else{line(c,tx,ty,tx+(i==1?60:i==0?44:24),ty,i==1?'#2B3A55':'#9AA6B4',i==1?2:1.6,fl);}});
  const tabs=['APA','MLA','IEEE'];const sel=p<.42?-1:p<.55?2:p<.68?1:0;
  tabs.forEach((l,i)=>{const x=cx+16+i*28,y=16;const on=i==sel;rr(c,x-12,y-5,24,10,5,on?pal.accent:SDARK,fi);text(c,l,x,y+.4,5.4,on?'#2E184B':SMUTED,fi);});
 },
 EXAM_BUILDER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=18,y=10,w=98,h=80;rr(c,x+1.2,y+1.6,w,h,4,'#000',.22);rr(c,x,y,w,h,4,PAPER);
  line(c,x+8,y+11,x+80,y+11,'#2B3A55',2.2);line(c,x+8,y+17,x+60,y+17,'#9AA6B4',1.5);
  const opts=['A','B','C','D'];const pick=seg(p,.3,.38);
  opts.forEach((o,i)=>{const oy=y+30+i*13;const chosen=i==1&&pick>0;const dimO=(i!=1)?1-.45*pick:1;
   if(chosen){rr(c,x+5,oy-5.5,w-10,11,5.5,GREEN,.25*pick*fl);}
   circle(c,x+12,oy,4.6,chosen?GREEN:'#E3E8EE',fi);text(c,o,x+12,oy+.4,5.4,chosen?'#06210F':'#5F6B7A',fi*dimO);
   line(c,x+21,oy,x+21+(i%2?44:56),oy,'#9AA6B4',1.5,fi*dimO);});
  if(pick>0){const r=lerp(2,10,seg(p,.28,.36));c.save();c.globalAlpha*=(1-seg(p,.28,.4))*fl;c.strokeStyle=GREEN;c.lineWidth=1.2;c.beginPath();c.arc(x+60,y+43,r,0,Math.PI*2);c.stroke();c.restore();
   check(c,x+w-12,y+43,6,'#06210F',seg(p,.36,.46),fl);}
  const tc=140,tr=10;c.save();c.globalAlpha*=fi;c.strokeStyle=SDARK;c.lineWidth=3.5;c.beginPath();c.arc(tc,26,tr,0,Math.PI*2);c.stroke();c.restore();
  const left=1-eIO(seg(p,.05,.55))*.7;c.save();c.globalAlpha*=fl;c.strokeStyle=pal.accent;c.lineWidth=3.5;c.lineCap='round';c.beginPath();c.arc(tc,26,tr,-Math.PI/2,-Math.PI/2+Math.PI*2*left);c.stroke();c.restore();
  line(c,tc,26,tc,20,'#FFFFFF',1.2,fi);line(c,tc,26,tc+4,26,'#FFFFFF',1.2,fi);
  const st=seg(p,.58,.7);if(st>0){c.save();c.translate(140,62);const s=back(st);c.scale(s,s);rr(c,-17,-9,34,18,6,GREEN,fl);text(c,'18/20',0,.6,8.4,'#06210F',fl);c.restore();}
 },
 STUDY_PLANNER_PRO(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const cx=40,cy=50,r=24;c.save();c.globalAlpha*=fi;c.strokeStyle=SDARK;c.lineWidth=6;c.beginPath();c.arc(cx,cy,r,0,Math.PI*2);c.stroke();c.restore();
  const t=eIO(seg(p,.05,.55));if(t>0){c.save();c.globalAlpha*=fl;c.strokeStyle=pal.accent;c.lineWidth=6;c.lineCap='round';c.beginPath();c.arc(cx,cy,r,-Math.PI/2,-Math.PI/2+Math.PI*2*t);c.stroke();c.restore();}
  text(c,'25 min',cx,cy+.6,7.4,'#FFFFFF',fi);
  const days=['L','M','M','J','V'];const gx=82,gy=22;
  days.forEach((d,i)=>text(c,d,gx+6+i*15,gy-6,5,SMUTED,fi));
  const fill=[[0,0],[1,1],[2,0],[3,2],[4,1],[0,2],[2,2],[1,0]];const cols=[pal.accent,'#6DE1D2','#FFB35A'];
  for(let col=0;col<5;col++)for(let row=0;row<3;row++)rr(c,gx+col*15,gy+row*17,12,14,2.5,SDARK,fi);
  fill.forEach(([col,row],i)=>{const tt=seg(p,.12+i*.05,.2+i*.05);if(tt<=0)return;const s=back(tt);c.save();c.translate(gx+col*15+6,gy+row*17+7);c.scale(s,s);rr(c,-6,-7,12,14,2.5,cols[i%3],fl);c.restore();});
  const bt=seg(p,.62,.74);if(bt>0){const sw=Math.sin(p*Math.PI*20)*.25*(1-seg(p,.7,.8));c.save();c.translate(cx+20,cy-22);c.rotate(sw);c.scale(back(bt),back(bt));circle(c,0,0,6.5,'#FFD54F',fl);rr(c,-7,1,14,3,1.5,'#FFD54F',fl);circle(c,0,5.4,1.8,'#FFD54F',fl);c.restore();}
 },
 FINANCE_CALCULATOR(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const hs=[3,5,8];for(let s=0;s<3;s++){const t=eOut(seg(p,.06+s*.1,.26+s*.1));const n=Math.round(hs[s]*t);for(let k=0;k<n;k++){const x=14+s*20,y=80-k*5;rr(c,x,y,16,4.4,2.2,'#E7B84B',fi*fl);line(c,x+3,y+2.2,x+13,y+2.2,'#C9962E',.8,fi*fl);}}
  const ct=seg(p,.36,.56);if(ct>0){c.save();c.globalAlpha*=fl;c.strokeStyle='#FFFFFF';c.lineWidth=1.6;c.lineCap='round';c.beginPath();const N=20;for(let i=0;i<=N*ct;i++){const u=i/N;const x=14+u*54,y=70-Math.pow(u,1.8)*44;i==0?c.moveTo(x,y):c.lineTo(x,y);}c.stroke();c.restore();}
  const pt=seg(p,.52,.62);if(pt>0)pill(c,'+12%',58,18,24,GREEN,'#06210F',6,fl,back(pt));
  const cx=124,cy=50,r=20;const segs=[[.5,pal.accent],[.3,'#6DE1D2'],[.2,'#FFB35A']];let a0=-Math.PI/2;
  c.save();c.globalAlpha*=fi;c.strokeStyle=SDARK;c.lineWidth=8;c.beginPath();c.arc(cx,cy,r,0,Math.PI*2);c.stroke();c.restore();
  segs.forEach(([f,col],i)=>{const t=eIO(seg(p,.2+i*.12,.34+i*.12));if(t>0){c.save();c.globalAlpha*=fl;c.strokeStyle=col;c.lineWidth=8;c.beginPath();c.arc(cx,cy,r,a0+.03,a0+Math.PI*2*f*t-.03);c.stroke();c.restore();}a0+=Math.PI*2*f;});
 },
 FLASHCARDS(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  rr(c,58,24,60,58,6,'#5A3590',.6*fi);rr(c,54,20,60,58,6,'#6A41A6',.8*fi);
  const ft=seg(p,.2,.4);const sx=Math.abs(Math.cos(ft*Math.PI));const back_=ft>.5;
  c.save();c.translate(80,46);c.scale(Math.max(sx,.02),1);
  if(!back_){rr(c,-32,-30,64,60,6,pal.accent,fi);text(c,'?',0,1.5,22,'#2E184B',fi);}
  else{rr(c,-32,-30,64,60,6,PAPER,fl);line(c,-22,-14,18,-14,'#2B3A55',2.2,fl);line(c,-22,-6,10,-6,'#9AA6B4',1.5,fl);line(c,-22,1,16,1,'#9AA6B4',1.5,fl);circle(c,18,16,7,GREEN,fl);check(c,18,16.4,7,'#06210F',seg(p,.42,.52),fl);}
  c.restore();
  for(let i=0;i<5;i++){const t=seg(p,.48+i*.06,.54+i*.06);circle(c,60+i*10,90,2.6,SDARK,fi);circle(c,60+i*10,90,2.6*back(t),pal.accent,fl*(t>0?1:0));}
 },
 ACADEMIC_PLANNER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=14,y=12,w=72,h=78;rr(c,x+1.2,y+1.6,w,h,4,'#000',.22);rr(c,x,y,w,h,4,PAPER);rr(c,x,y,w,14,4,'#5B3790');text(c,'NOV',x+w/2,y+7.4,6,'#FFFFFF');
  for(let r=0;r<4;r++)for(let k=0;k<5;k++){const dx=x+6+k*13,dy=y+20+r*14;rr(c,dx,dy,10,10,2,'#E9EDF2');}
  const dots=[[1,0,pal.accent],[3,1,'#6DE1D2'],[0,2,'#FFB35A'],[4,2,pal.accent],[2,3,'#6DE1D2']];
  dots.forEach(([k,r,col],i)=>{const t=seg(p,.08+i*.06,.16+i*.06);if(t<=0)return;circle(c,x+11+k*13,y+25+r*14,3.4*back(t),col,fi*fl);});
  const ct=eOut(seg(p,.42,.56));if(ct>0){const ox=lerp(30,0,ct);const cx=96+ox,cy=34;rr(c,cx+1.2,cy+1.6,62,30,4,'#000',.22*ct*fl);rr(c,cx,cy,62,30,4,PAPER,ct*fl);rr(c,cx,cy,4,30,2,pal.accent,ct*fl);
   line(c,cx+20,cy+10,cx+54,cy+10,'#2B3A55',2,ct*fl);line(c,cx+20,cy+18,cx+46,cy+18,'#9AA6B4',1.4,ct*fl);
   const k=seg(p,.6,.7);rrStroke(c,cx+8,cy+6,8,8,2,'#9AA6B4',1.2,ct*fl);if(k>0){rr(c,cx+8,cy+6,8,8,2,GREEN,fl*clamp(k*2));check(c,cx+12,cy+10.2,5.4,'#06210F',k,fl);}}
 },
 TEXT_TOOLKIT(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=14,y=14,w=80,h=72;rr(c,x,y,w,h,5,SDARK,fi);
  const lens=[30,54,22,44,38];const offs=[12,2,20,8,4];const order=[2,0,4,3,1];
  const t=eIO(seg(p,.1,.45));
  for(let i=0;i<5;i++){const ry0=y+12+i*12;const target=order.indexOf(i);const ry=lerp(ry0,y+12+target*12,t);const ox=lerp(offs[i],0,t);
   line(c,x+8+ox,ry,x+8+ox+lens[i],ry,i==1&&t<.5?'#FF8A8A':'#E9DDFB',2,fi);
   if(t<.4&&i%2==0){const sq=x+8+ox+lens[i]*.4;c.save();c.globalAlpha*=fi*(1-t*2.5);c.strokeStyle='#FF6B6B';c.lineWidth=.8;c.beginPath();for(let k=0;k<=8;k++){const xx=sq+k*1.5,yy=ry+2.5+(k%2?1:-1)*.8;k?c.lineTo(xx,yy):c.moveTo(xx,yy);}c.stroke();c.restore();}}
  const at=seg(p,.5,.62);const up=seg(p,.62,.66)>0;
  c.save();c.translate(130,50);const s=at>0?back(at):0;c.scale(s,s);rr(c,-22,-14,44,28,7,pal.accent,fl);text(c,up?'AA':'Aa',0,1,11,'#2E184B',fl);c.restore();
  if(at>0)arrow(c,98,106,50,pal.accent,eOut(at),fl);
  const sp=seg(p,.62,.72);if(sp>0&&sp<1){for(let k=0;k<4;k++){const a=k*Math.PI/2+.4;const d=lerp(22,32,sp);circle(c,130+Math.cos(a)*d,50+Math.sin(a)*d*.7,1.6*(1-sp),'#FFD54F',fl);}}
 }
});
