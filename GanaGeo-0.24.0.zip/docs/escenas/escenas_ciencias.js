PAL.SCIENCE={container:'#113A3F',badge:'#1B4F55',accent:'#74F1FF'};
const CDARK='#0A2528',CMUTED='#9FD9DF';
function reveal(c,s,x,y,size,col,t,alpha=1){if(t<=0)return;c.save();c.font=`700 ${size}px Roboto, Arial`;const w=c.measureText(s).width;c.beginPath();c.rect(x,y-size,w*t,size*2);c.clip();textL(c,s,x,y,size,col,alpha);c.restore();}
Object.assign(SCENES,{
 ADVANCED_MATH(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const bx=14,by=24,bw=46,bh=44;
  [[bx,1],[bx+bw,-1]].forEach(([x,d])=>{line(c,x,by,x,by+bh,'#FFFFFF',1.6,fi);line(c,x,by,x+5*d,by,'#FFFFFF',1.6,fi);line(c,x,by+bh,x+5*d,by+bh,'#FFFFFF',1.6,fi);});
  const nums=[['2',bx+13,by+13],['1',bx+33,by+13],['0',bx+13,by+31],['3',bx+33,by+31]];
  nums.forEach(([n,x,y],i)=>{const t=seg(p,.06+i*.06,.14+i*.06);if(t<=0)return;c.save();c.translate(x,y);const s=back(t);c.scale(s,s);text(c,n,0,.5,8,'#FFFFFF',fi*fl);c.restore();});
  const dt=seg(p,.34,.46);if(dt>0)pill(c,'det = 6',bx+bw/2,84,34,pal.accent,'#06292D',6.2,fl,back(dt));
  const gx=74,base=76;line(c,gx,base,gx+84,base,'#FFFFFF',.8,.4*fi);line(c,gx+4,16,gx+4,base,'#FFFFFF',.8,.4*fi);
  const f=(x)=>base-10-Math.sin((x-gx)/84*Math.PI)*42;
  const at=eIO(seg(p,.46,.7));if(at>0){const x1=gx+20,x2=gx+20+(48*at);c.save();c.globalAlpha*=.35*fl;c.fillStyle=pal.accent;c.beginPath();c.moveTo(x1,base);for(let x=x1;x<=x2;x+=2)c.lineTo(x,f(x));c.lineTo(x2,base);c.closePath();c.fill();c.restore();}
  c.save();c.globalAlpha*=fi;c.strokeStyle=pal.accent;c.lineWidth=1.8;c.beginPath();for(let x=gx+4;x<=gx+82;x+=2){x==gx+4?c.moveTo(x,f(x)):c.lineTo(x,f(x));}c.stroke();c.restore();
  const it=seg(p,.42,.54);if(it>0){c.save();c.translate(gx+16,28);c.scale(back(it),back(it));text(c,'∫',0,0,16,'#FFFFFF',fl);c.restore();}
 },
 EQUATION_SOLVER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  rr(c,14,10,112,80,6,CDARK,fi);
  reveal(c,'2x + 4 = 10',24,28,7,'#FFFFFF',seg(p,.06,.24),fi*fl);
  if(p>.24){line(c,40,36,40,40,CMUTED,1,fl*seg(p,.24,.28));}
  reveal(c,'2x = 6',24,48,7,'#FFFFFF',seg(p,.28,.42),fl);
  const ft=seg(p,.46,.58);if(ft>0){rr(c,20,60,52,18,5,GREEN,.25*ft*fl);reveal(c,'x = 3',26,69.5,9,GREEN,ft,fl);}
  const ct=seg(p,.62,.74);if(ct>0){circle(c,146,69,9*back(ct),GREEN,fl);check(c,146,69.5,9,'#06210F',seg(p,.66,.78),fl);}
 },
 FUNCTION_GRAPHER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);const ox=86,oy=52;
  c.save();c.globalAlpha*=.12*fi;c.strokeStyle='#FFFFFF';c.lineWidth=.5;for(let x=22;x<=150;x+=16){c.beginPath();c.moveTo(x,14);c.lineTo(x,90);c.stroke();}for(let y=20;y<=86;y+=16){c.beginPath();c.moveTo(18,y);c.lineTo(156,y);c.stroke();}c.restore();
  line(c,18,oy,156,oy,'#FFFFFF',1,.6*fi);line(c,ox,14,ox,90,'#FFFFFF',1,.6*fi);text(c,'x',152,oy-5,5.4,CMUTED,fi);text(c,'y',ox+5,16,5.4,CMUTED,fi);
  const curves=[[pal.accent,.08,.3,x=>oy-(x-ox)*.45,22,150],['#FFB35A',.3,.52,x=>30+Math.pow((x-ox)/36,2)*50,50,122],['#C997FF',.52,.74,x=>oy-Math.sin((x-22)/128*Math.PI*3)*16,22,150]];
  curves.forEach(([col,a,b,f,x0,x1])=>{const t=seg(p,a,b);if(t<=0)return;c.save();c.globalAlpha*=fl;c.strokeStyle=col;c.lineWidth=1.8;c.lineCap='round';c.beginPath();const xe=lerp(x0,x1,t);for(let x=x0;x<=xe;x+=2){x==x0?c.moveTo(x,f(x)):c.lineTo(x,f(x));}c.stroke();c.restore();});
 },
 STATISTICS(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);const hs=[6,12,22,34,40,34,22,12,6];const base=80;
  line(c,10,base,104,base,'#FFFFFF',.8,.4*fi);
  hs.forEach((h,i)=>{const t=eOut(seg(p,.05+i*.035,.2+i*.035));rr(c,14+i*10,base-h*t,8,h*t,1.5,pal.accent,.85*fi*fl);});
  const ct=seg(p,.42,.62);if(ct>0){c.save();c.globalAlpha*=fl;c.strokeStyle='#FFFFFF';c.lineWidth=1.6;c.beginPath();const xe=lerp(10,104,ct);for(let x=10;x<=xe;x+=2){const u=(x-58)/18;const y=base-44*Math.exp(-u*u/2);x==10?c.moveTo(x,y):c.lineTo(x,y);}c.stroke();c.restore();}
  const mt=seg(p,.6,.7);if(mt>0){c.save();c.globalAlpha*=fl*mt;c.strokeStyle='#FFD54F';c.lineWidth=1;c.setLineDash([3,2]);c.beginPath();c.moveTo(58,30);c.lineTo(58,base);c.stroke();c.restore();
   c.save();c.translate(134,32);c.scale(back(mt),back(mt));rr(c,-22,-8,44,16,5,CDARK,fl);text(c,'Media 14',0,.4,6,'#FFD54F',fl);c.restore();}
  const bt=seg(p,.68,.8);if(bt>0){const y=62;line(c,110,y,158,y,'#FFFFFF',1,fl*bt);rr(c,122,y-6,24,12,2,pal.accent,fl*bt*.9);line(c,133,y-6,133,y+6,CDARK,1.4,fl*bt);line(c,110,y-4,110,y+4,'#FFFFFF',1,fl*bt);line(c,158,y-4,158,y+4,'#FFFFFF',1,fl*bt);}
 },
 PHYSICS_CALCULATOR(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  line(c,10,78,104,78,'#FFFFFF',1,.5*fi);for(let x=12;x<104;x+=8)line(c,x,78,x-4,84,'#FFFFFF',.6,.25*fi);
  const t=eIO(seg(p,.08,.5));const bx=lerp(16,70,t);
  for(let k=0;k<3;k++){const a=Math.sin(t*Math.PI)*fl;line(c,bx-4-k*2,66+k*4,bx-12-k*4,66+k*4,'#FFFFFF',1,.5*a);}
  rr(c,bx,62,20,16,3,pal.accent,fi);
  arrow(c,bx-18,bx-2,70,'#FFB35A',1,fi*clamp(seg(p,.04,.12)*1)*(1-seg(p,.5,.6)));
  const lt=seg(p,.18,.3);if(lt>0)text(c,'F = m·a',56,26,7,'#FFFFFF',lt*fl);
  const cx=136,cy=44;const on=seg(p,.56,.64);
  if(on>0){const pulse=.85+.15*Math.sin(p*Math.PI*12);circle(c,cx,cy,22*pulse,'#FFD54F',.18*on*fl);for(let k=0;k<8;k++){const a=k*Math.PI/4;line(c,cx+Math.cos(a)*16,cy+Math.sin(a)*16,cx+Math.cos(a)*(20+3*pulse),cy+Math.sin(a)*(20+3*pulse),'#FFD54F',1.4,on*fl);}}
  circle(c,cx,cy,12,on>0?'#FFE58A':'#2C5A60',fi);rr(c,cx-6,cy+10,12,10,2,'#9AA6B4',fi);line(c,cx-6,cy+14,cx+6,cy+14,'#5F6B7A',.8,fi);line(c,cx-6,cy+17,cx+6,cy+17,'#5F6B7A',.8,fi);
  line(c,cx-4,cy+4,cx,cy-3,on>0?'#C9962E':'#7FA9AE',1,fi);line(c,cx,cy-3,cx+4,cy+4,on>0?'#C9962E':'#7FA9AE',1,fi);
 },
 PERIODIC_TABLE(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);const cs=5.2,x0=8,y0=16;
  const groupCol=(col)=>col==0?'#FF8A8A':col==1?'#FFB35A':col<12?'#5CC8D1':col<17?pal.accent:'#C997FF';
  const has=(r,col)=>r==0?(col==0||col==17):r<3?(col<2||col>11):true;
  for(let r=0;r<7;r++)for(let col=0;col<18;col++){if(!has(r,col))continue;const t=seg(p,.04+col*.02,.12+col*.02);const fe=(r==3&&col==7);
   rr(c,x0+col*cs,y0+r*cs,cs-1,cs-1,.8,t>0?groupCol(col):'#1E474C',fi*(t>0?(fe&&p>.46?1:.85):1));}
  for(let r=0;r<2;r++)for(let k=0;k<14;k++){const t=seg(p,.4+k*.005,.46+k*.005);rr(c,x0+(3+k)*cs,y0+7.6*cs+r*cs,cs-1,cs-1,.8,t>0?'#8FE3B0':'#1E474C',fi);}
  const zt=eOut(seg(p,.48,.64));if(zt>0){const fx=x0+7*cs,fy=y0+3*cs;const x=lerp(fx,114,zt),y=lerp(fy,22,zt),w=lerp(cs-1,44,zt),h=lerp(cs-1,54,zt);
   rr(c,x,y,w,h,lerp(.8,5,zt),'#5CC8D1',fl);if(zt>.6){const a=seg(zt,.6,1)*fl;textL(c,'26',x+5,y+8,5,'#06292D',a);text(c,'Fe',x+w/2,y+h/2+1,14,'#06292D',a);text(c,'55.85',x+w/2,y+h-8,5,'#06292D',a);}}
 },
 CHEMISTRY_CALCULATOR(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const O=[44,44],H1=[26,62],H2=[62,62];
  const bt=seg(p,.18,.32);line(c,O[0],O[1],lerp(O[0],H1[0],bt),lerp(O[1],H1[1],bt),'#FFFFFF',2,fi*fl);line(c,O[0],O[1],lerp(O[0],H2[0],bt),lerp(O[1],H2[1],bt),'#FFFFFF',2,fi*fl);
  const ot=seg(p,.04,.16);if(ot>0){c.save();c.translate(...O);c.scale(back(ot),back(ot));circle(c,0,0,12,'#FF6B6B',fi*fl);text(c,'O',0,.5,8,'#FFFFFF',fi*fl);c.restore();}
  [H1,H2].forEach((h,i)=>{const t=seg(p,.26+i*.06,.36+i*.06);if(t<=0)return;c.save();c.translate(...h);c.scale(back(t),back(t));circle(c,0,0,7,'#F4F6F8',fi*fl);text(c,'H',0,.4,6,'#113A3F',fi*fl);c.restore();});
  const fx=128;c.save();c.globalAlpha*=fi;c.strokeStyle='#FFFFFF';c.lineWidth=1.4;c.lineJoin='round';c.beginPath();c.moveTo(fx-6,16);c.lineTo(fx-6,36);c.lineTo(fx-22,72);c.quadraticCurveTo(fx-24,78,fx-17,78);c.lineTo(fx+17,78);c.quadraticCurveTo(fx+24,78,fx+22,72);c.lineTo(fx+6,36);c.lineTo(fx+6,16);c.stroke();c.restore();
  const lv=eIO(seg(p,.38,.6));if(lv>0){const ly=lerp(77,52,lv);const half=(y)=>6+(y-36)/(72-36)*16;c.save();c.globalAlpha*=.8*fl;c.fillStyle=pal.accent;c.beginPath();c.moveTo(fx-half(ly),ly);c.lineTo(fx+half(ly),ly);c.lineTo(fx+21,76.5);c.lineTo(fx-21,76.5);c.closePath();c.fill();c.restore();
   for(let k=0;k<3;k++){const bp=(p*3+k*.33)%1;circle(c,fx-8+k*8,lerp(74,ly+2,bp),1.4,'#FFFFFF',.7*fl*lv*(1-bp));}}
  const rt=seg(p,.62,.74);if(rt>0)pill(c,'18 g/mol',fx,89,40,GREEN,'#06210F',6.4,fl,back(rt));
 }
});
