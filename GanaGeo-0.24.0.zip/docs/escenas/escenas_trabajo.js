PAL.WORK={container:'#173825',badge:'#214B31',accent:'#7CF3A6'};
function stroke(c,x,y,w,h,r,col,lw,alpha=1){rrStroke(c,x,y,w,h,r,col,lw,alpha);}
function textL(c,s,x,y,size,col,alpha=1,bold=true){c.save();c.globalAlpha*=alpha;c.fillStyle=col;c.font=`${bold?'700':'500'} ${size}px Roboto, Arial`;c.textAlign='left';c.textBaseline='middle';c.fillText(s,x,y);c.restore();}
function textR(c,s,x,y,size,col,alpha=1,bold=true){c.save();c.globalAlpha*=alpha;c.fillStyle=col;c.font=`${bold?'700':'500'} ${size}px Roboto, Arial`;c.textAlign='right';c.textBaseline='middle';c.fillText(s,x,y);c.restore();}
Object.assign(SCENES,{
 CV_BUILDER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const sel=seg(p,.04,.14);
  for(let i=0;i<2;i++){const ty=16+i*36;rr(c,12,ty,26,32,2.5,PAPER,.9);rr(c,12,ty,26,7,2.5,i==0?pal.accent:'#9AA6B4',.9);line(c,16,ty+13,32,ty+13,LINE,1.2);line(c,16,ty+18,28,ty+18,LINE,1.2);line(c,16,ty+23,33,ty+23,LINE,1.2);}
  stroke(c,10.5,14.5,29,35,3.5,pal.accent,1.4,sel*fl);
  const x=48,y=8,w=62,h=84;rr(c,x+1.2,y+1.6,w,h,3,'#000',.22);rr(c,x,y,w,h,3,PAPER);rr(c,x,y,w,14,3,'#1F5135');
  circle(c,x+10,y+14,7,pal.accent);circle(c,x+10,y+12.2,2.6,'#1F5135');rr(c,x+5.6,y+15.6,8.8,4,2,'#1F5135');
  line(c,x+21,y+6,x+50,y+6,'#FFFFFF',2.2);line(c,x+21,y+10.5,x+40,y+10.5,'#A8E6C0',1.4);
  const secs=[[y+28,3],[y+48,2]];secs.forEach(([sy,n],k)=>{const t=seg(p,.12+k*.16,.28+k*.16);if(t<=0)return;rr(c,x+6,sy-3,14*eOut(t),3.2,1.5,'#1F5135',fi);
    for(let j=0;j<n;j++){const lt=seg(p,.16+k*.16+j*.04,.26+k*.16+j*.04);line(c,x+6,sy+4+j*5,x+6+lerp(0,j%2?36:46,eOut(lt)),sy+4+j*5,LINE,1.4,fi*clamp(lt*4));}});
  const sk=[.9,.7,.8];sk.forEach((v,j)=>{const t=eOut(seg(p,.46+j*.05,.6+j*.05));const by=y+66+j*6;rr(c,x+6,by,46,2.6,1.3,'#DDE3EA',fi);rr(c,x+6,by,46*v*t,2.6,1.3,pal.accent,fi);});
  const pt=seg(p,.64,.76);if(pt>0){arrow(c,116,128,50,pal.accent,eOut(pt),fl);badge(c,'PDF',143,50,RED,fl,back(pt));}
 },
 WORK_HOURS(c,p,pal){
  const fl=fadeLoop(p);
  const cx=42,cy=48,r=29;circle(c,cx,cy,r+3,'#0E2417');circle(c,cx,cy,r,'#F4F6F8');
  for(let i=0;i<12;i++){const a=i/12*Math.PI*2;line(c,cx+Math.cos(a)*(r-3),cy+Math.sin(a)*(r-3),cx+Math.cos(a)*(r-(i%3?5:7)),cy+Math.sin(a)*(r-(i%3?5:7)),'#9AA6B4',i%3?1:1.6);}
  const t=eIO(seg(p,.05,.55));const arcEnd=-Math.PI/2+t*Math.PI*2*0.83;
  c.save();c.globalAlpha*=.35*fl;c.fillStyle=pal.accent;c.beginPath();c.moveTo(cx,cy);c.arc(cx,cy,r-2,-Math.PI/2,arcEnd);c.closePath();c.fill();c.restore();
  const ma=-Math.PI/2+t*Math.PI*2*10,ha=-Math.PI/2+t*Math.PI*2*0.83;
  line(c,cx,cy,cx+Math.cos(ha)*15,cy+Math.sin(ha)*15,'#1F3A2B',3);line(c,cx,cy,cx+Math.cos(ma)*22,cy+Math.sin(ma)*22,'#2B6A47',1.8);circle(c,cx,cy,2.6,'#1F3A2B');
  const bx=86,by=16,bw=68,bh=68;rr(c,bx,by,bw,bh,5,'#0E2417',.9);
  const rows=[['Normal','8 h','#FFFFFF',.25],['Extra','+2 h',pal.accent,.38]];
  rows.forEach(([k,v,col,st],i)=>{const tt=seg(p,st,st+.1);if(tt<=0)return;const ry=by+14+i*14;textL(c,k,bx+7,ry,5.4,'#A8C4B2',tt*fl,false);textR(c,v,bx+bw-7,ry,6.4,col,tt*fl);});
  const tt=seg(p,.55,.68);if(tt>0){line(c,bx+7,by+40,bx+bw-7,by+40,'#2F5A40',1,fl);textL(c,'Total',bx+7,by+52,5.6,'#A8C4B2',tt*fl,false);
   c.save();c.translate(bx+bw-7,by+52);const s=back(tt);c.scale(s,s);textR(c,'S/ 96',0,0,10,GREEN,fl);c.restore();}
 },
 QUOTE_IGV(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=34,y=8,w=84,h=84;rr(c,x+1.2,y+1.6,w,h,3,'#000',.22);rr(c,x,y,w,h,3,PAPER);
  rr(c,x,y,w,12,3,'#1F5135');textL(c,'Cotización',x+6,y+6.4,5.6,'#FFFFFF');
  for(let i=0;i<3;i++){const t=seg(p,.08+i*.08,.18+i*.08);const ry=y+22+i*9;line(c,x+6,ry,x+6+lerp(0,i==1?30:38,eOut(t)),ry,'#9AA6B4',1.5,fi*clamp(t*4));rr(c,x+w-20,ry-2,14*eOut(t),4,1.5,'#C9D3DD',fi*clamp(t*4));}
  const st=seg(p,.34,.42);line(c,x+6,y+52,x+w-6,y+52,'#DDE3EA',1,st*fi);
  const it=seg(p,.42,.54);if(it>0){c.save();c.translate(x+w-18,y+60);const s=back(it);c.scale(s,s);rr(c,-14,-4.5,28,9,4.5,pal.accent,fl);text(c,'IGV 18%',0,0.4,5.2,'#0B2A17',fl);c.restore();}
  const tt=seg(p,.58,.7);if(tt>0){rr(c,x+5,y+68,w-10,12,3,'#1F5135',fl*tt);textL(c,'Total',x+10,y+74.4,5.6,'#A8E6C0',fl*tt,false);c.save();c.translate(x+w-10,y+74.4);const s=back(tt);c.scale(s,s);textR(c,'S/ 118',0,0,7.4,'#FFFFFF',fl);c.restore();}
  const ct=seg(p,.72,.84);if(ct>0){circle(c,x+w+14,y+20,8*back(ct),GREEN,fl);check(c,x+w+14,y+20.5,8,'#06210F',seg(p,.76,.86),fl);}
 },
 INCOME_EXPENSE_TRACKER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const base=56,x0=16;line(c,x0,base,x0+92,base,'#FFFFFF',.8,.4*fi);
  const inc=[22,30,18,34,26],exp=[12,16,20,10,14];
  for(let i=0;i<5;i++){const t=eOut(seg(p,.06+i*.06,.22+i*.06));const bx=x0+6+i*18;rr(c,bx,base-inc[i]*t,6,inc[i]*t,1.5,GREEN,fi*fl);rr(c,bx+7,base,6,exp[i]*t,1.5,'#FF6B6B',fi*fl);}
  const lt=seg(p,.42,.66);if(lt>0){const pts=[];let acc=0;for(let i=0;i<5;i++){acc+=inc[i]-exp[i];pts.push([x0+12+i*18,base-6-acc*0.55]);}
   c.save();c.globalAlpha*=fl;c.strokeStyle='#FFFFFF';c.lineWidth=1.6;c.lineJoin='round';c.lineCap='round';c.beginPath();const n=lt*(pts.length-1);c.moveTo(...pts[0]);for(let i=1;i<=Math.floor(n);i++)c.lineTo(...pts[i]);const f=n-Math.floor(n);if(f>0&&Math.floor(n)+1<pts.length){const a=pts[Math.floor(n)],b=pts[Math.floor(n)+1];c.lineTo(lerp(a[0],b[0],f),lerp(a[1],b[1],f));}c.stroke();c.restore();
   if(lt>=1)circle(c,...pts[4],2.4,'#FFFFFF',fl);}
  const rx=120;const items=[['S/ 2,450',GREEN,22,.3],['S/ 1,280','#FF6B6B',38,.4]];
  items.forEach(([l,col,yy,st])=>{const t=seg(p,st,st+.1);textL(c,l,rx,yy,6.2,col,t*fl);});
  const tt=seg(p,.66,.78);if(tt>0){rr(c,rx-3,60,46,14,4,'#0E2417',fl*tt);textL(c,'S/ 1,170',rx+1,67.4,7.6,'#FFFFFF',fl*tt);}
 },
 INVENTORY_BASIC(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  line(c,12,44,92,44,'#C8A57A',2.4,fi);line(c,12,80,92,80,'#C8A57A',2.4,fi);
  const boxes=[[16,44,22,18],[40,44,18,14],[60,44,24,20],[18,80,20,16],[42,80,26,22],[70,80,18,14]];
  boxes.forEach(([bx,by,bw,bh],i)=>{const t=seg(p,.04+i*.05,.14+i*.05);if(t<=0)return;const yy=lerp(by-bh-30,by-bh,eOut(t));const a=fi*fl*clamp(t*3);
   rr(c,bx,yy,bw,bh,1.5,'#D9A066',a);rr(c,bx+bw/2-2,yy,4,bh,0,'#B9824A',a);line(c,bx+2,yy+3,bx+bw-2,yy+3,'#E8BE8A',.8,a);});
  const bars=[[.9,.62],[.7,.48],[.6,.14]];const bx=104;
  bars.forEach(([a,b],i)=>{const by=26+i*20;const t=eIO(seg(p,.4,.66));const v=lerp(a,b,t);const low=v<.25;rr(c,bx,by,46,6,3,'#0E2417',fi);rr(c,bx,by,46*v,6,3,low?'#FF6B6B':pal.accent,fi*fl);});
  line(c,bx+46*.25,20,bx+46*.25,74,'#FFD54F',.8,.7*fi);
  const at=seg(p,.66,.74);if(at>0){const pulse=1+.12*Math.sin(p*Math.PI*14);c.save();c.translate(bx+40,66+9);c.scale(back(at)*pulse,back(at)*pulse);circle(c,0,0,6,'#FF6B6B',fl);text(c,'!',0,0.5,8,'#FFFFFF',fl);c.restore();}
 },
 COMMISSION_MARGIN(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  c.save();c.globalAlpha*=fi;c.fillStyle='#F4F6F8';c.beginPath();c.moveTo(14,36);c.lineTo(22,26);c.lineTo(62,26);c.lineTo(62,52);c.lineTo(22,52);c.closePath();c.fill();c.restore();
  circle(c,23,39,2.2,'#173825',fi);text(c,'S/ 100',43,39.5,8,'#173825',fi);
  const bt=eIO(seg(p,.12,.4));rr(c,14,66,80,8,4,'#9AA6B4',fi*fl);rr(c,14+80*(1-.3*bt),66,80*.3*bt,8,4,GREEN,fi*fl);
  if(bt>0){line(c,14+80*.7,62,14+80*.7,78,'#FFFFFF',.8,.6*bt*fl);}
  const cx=128,cy=48,r=20;c.save();c.globalAlpha*=fi;c.strokeStyle='#0E2417';c.lineWidth=7;c.beginPath();c.arc(cx,cy,r,0,Math.PI*2);c.stroke();c.restore();
  const at=eIO(seg(p,.42,.66));if(at>0){c.save();c.globalAlpha*=fl;c.strokeStyle=GREEN;c.lineWidth=7;c.lineCap='round';c.beginPath();c.arc(cx,cy,r,-Math.PI/2,-Math.PI/2+Math.PI*2*.3*at);c.stroke();c.restore();}
  const tt=seg(p,.6,.72);if(tt>0){c.save();c.translate(cx,cy);const s=back(tt);c.scale(s,s);text(c,'30%',0,0.6,9,'#FFFFFF',fl);c.restore();}
 },
 WORK_CHECKLIST(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=24,y=12,w=70,h=80;rr(c,x+1.2,y+1.6,w,h,4,'#000',.22);rr(c,x,y,w,h,4,PAPER);rr(c,x+w/2-12,y-4,24,9,3,'#5F6B7A');
  let done=0;const lens=[40,32,44,28];
  for(let i=0;i<4;i++){const ry=y+18+i*16;const t=seg(p,.12+i*.13,.2+i*.13);rrStroke(c,x+7,ry-4.5,9,9,2,'#9AA6B4',1.2);
   if(t>0){rr(c,x+7,ry-4.5,9,9,2,GREEN,clamp(t*2)*fl);check(c,x+11.5,ry+.2,6,'#06210F',t,fl);done++;}
   line(c,x+21,ry,x+21+lens[i],ry,'#9AA6B4',1.6,fi);if(t>0)line(c,x+21,ry,x+21+lens[i]*eOut(seg(p,.16+i*.13,.26+i*.13)),ry,'#5F6B7A',1,fl);}
  const cx=128,cy=50,r=18;c.save();c.globalAlpha*=fi;c.strokeStyle='#0E2417';c.lineWidth=5;c.beginPath();c.arc(cx,cy,r,0,Math.PI*2);c.stroke();c.restore();
  const prog=clamp((p-.12)/(.65-.12));if(prog>0){c.save();c.globalAlpha*=fl;c.strokeStyle=pal.accent;c.lineWidth=5;c.lineCap='round';c.beginPath();c.arc(cx,cy,r,-Math.PI/2,-Math.PI/2+Math.PI*2*Math.min(done/4,prog*1.02));c.stroke();c.restore();}
  text(c,`${done}/4`,cx,cy+.6,8,'#FFFFFF',fi*Math.max(fl,done<4?1:fl));
 }
});
