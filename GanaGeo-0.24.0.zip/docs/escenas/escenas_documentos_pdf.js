// Escenas animadas (unidades 170x100). Mismo diseño que se porta a Kotlin.
const W=170,H=100;
const clamp=(v)=>Math.max(0,Math.min(1,v));
const seg=(p,a,b)=>clamp((p-a)/(b-a));
const eOut=(t)=>1-Math.pow(1-t,3);
const eIO=(t)=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
const back=(t)=>{const c1=1.70158,c3=c1+1;return 1+c3*Math.pow(t-1,3)+c1*Math.pow(t-1,2);};
const lerp=(a,b,t)=>a+(b-a)*t;
const PAL={PDF:{container:'#401415',badge:'#5B1D1F',accent:'#FF7D7D'}};
const PAPER='#F4F6F8', LINE='#C3CAD3', RED='#E5484D', GREEN='#3DDC84', DARK='#1C2430', INK='#2B3A55';
function rgba(hex,a){const n=parseInt(hex.slice(1),16);return `rgba(${n>>16&255},${n>>8&255},${n&255},${a})`;}
function rr(c,x,y,w,h,r,fill,alpha=1){c.save();c.globalAlpha*=alpha;c.fillStyle=fill;c.beginPath();c.roundRect(x,y,w,h,r);c.fill();c.restore();}
function rrStroke(c,x,y,w,h,r,col,lw,alpha=1){c.save();c.globalAlpha*=alpha;c.strokeStyle=col;c.lineWidth=lw;c.beginPath();c.roundRect(x,y,w,h,r);c.stroke();c.restore();}
function line(c,x1,y1,x2,y2,col,lw,alpha=1){c.save();c.globalAlpha*=alpha;c.strokeStyle=col;c.lineWidth=lw;c.lineCap='round';c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();c.restore();}
function circle(c,x,y,r,col,alpha=1){c.save();c.globalAlpha*=alpha;c.fillStyle=col;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();c.restore();}
function text(c,s,x,y,size,col,alpha=1,bold=true){c.save();c.globalAlpha*=alpha;c.fillStyle=col;c.font=`${bold?'700':'500'} ${size}px Roboto, Arial`;c.textAlign='center';c.textBaseline='middle';c.fillText(s,x,y);c.restore();}
function bg(c,pal){const g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,pal.badge);g.addColorStop(1,pal.container);c.fillStyle=g;c.fillRect(0,0,W,H);
  c.save();c.globalAlpha=.07;c.strokeStyle='#fff';c.lineWidth=.5;for(let x=10;x<W;x+=14){c.beginPath();c.moveTo(x,0);c.lineTo(x,H);c.stroke();}for(let y=8;y<H;y+=14){c.beginPath();c.moveTo(0,y);c.lineTo(W,y);c.stroke();}c.restore();
  const rg=c.createRadialGradient(W*.5,H*.1,2,W*.5,H*.1,W*.6);rg.addColorStop(0,rgba(pal.accent,.18));rg.addColorStop(1,rgba(pal.accent,0));c.fillStyle=rg;c.fillRect(0,0,W,H);}
function page(c,x,y,w,h,alpha=1,lines=4,lineCol=LINE){rr(c,x+1.2,y+1.6,w,h,3,'#000',.22*alpha);rr(c,x,y,w,h,3,PAPER,alpha);
  for(let i=0;i<lines;i++){const ly=y+h*0.30+i*(h*0.15);if(ly>y+h-4)break;line(c,x+w*.14,ly,x+w*(i%2?0.70:0.86),ly,lineCol,1.6,alpha);}}
function badge(c,label,x,y,col,alpha=1,scale=1){c.save();c.translate(x,y);c.scale(scale,scale);rr(c,-11,-5.5,22,11,3,col,alpha);text(c,label,0,0.4,6.4,'#fff',alpha);c.restore();}
function arrow(c,x1,x2,y,col,t,alpha=1){if(t<=0)return;const xe=lerp(x1,x2,t);line(c,x1,y,xe,y,col,2.2,alpha);if(t>.6){const a=alpha*seg(t,.6,1);line(c,xe,y,xe-4.5,y-3.5,col,2.2,a);line(c,xe,y,xe-4.5,y+3.5,col,2.2,a);}}
function check(c,x,y,s,col,t,alpha=1){if(t<=0)return;c.save();c.globalAlpha*=alpha;c.strokeStyle=col;c.lineWidth=s*0.28;c.lineCap='round';c.lineJoin='round';c.beginPath();
  const p1=[x-s*.5,y],p2=[x-s*.15,y+s*.35],p3=[x+s*.55,y-s*.4];const t1=clamp(t*2),t2=clamp(t*2-1);c.moveTo(...p1);c.lineTo(lerp(p1[0],p2[0],t1),lerp(p1[1],p2[1],t1));if(t2>0)c.lineTo(lerp(p2[0],p3[0],t2),lerp(p2[1],p3[1],t2));c.stroke();c.restore();}
function photo(c,x,y,w,h,alpha=1,sky='#6FB7FF',hill='#3DDC84'){rr(c,x,y,w,h,2.5,'#fff',alpha);const ix=x+1.6,iy=y+1.6,iw=w-3.2,ih=h-3.2;rr(c,ix,iy,iw,ih,1.6,sky,alpha);
  c.save();c.globalAlpha*=alpha;c.beginPath();c.roundRect(ix,iy,iw,ih,1.6);c.clip();c.fillStyle=hill;c.beginPath();c.moveTo(ix,iy+ih);c.lineTo(ix+iw*.35,iy+ih*.45);c.lineTo(ix+iw*.6,iy+ih*.8);c.lineTo(ix+iw*.78,iy+ih*.58);c.lineTo(ix+iw,iy+ih);c.closePath();c.fill();c.restore();
  circle(c,ix+iw*.78,iy+ih*.28,Math.min(iw,ih)*.13,'#FFD54F',alpha);}
function fadeLoop(p){return 1-seg(p,.93,1);}

const SCENES={
 // 1. Escáner: la luz recorre la hoja en el celular y sale un PDF limpio.
 DOCUMENT_SCANNER(c,p,pal){
  const fl=fadeLoop(p);
  rr(c,22,10,44,80,8,DARK);rrStroke(c,22,10,44,80,8,'#3E4A5C',1.2);rr(c,40,13,8,2,1,'#3E4A5C');
  const sx=26,sy=18,sw=36,sh=64;rr(c,sx,sy,sw,sh,2.5,'#E9EDF2');
  for(let i=0;i<6;i++)line(c,sx+5,sy+12+i*8,sx+(i%2?24:31),sy+12+i*8,'#AEB7C2',1.5);
  const br=pal.accent,bl=6;const corners=[[sx+1,sy+1,1,1],[sx+sw-1,sy+1,-1,1],[sx+1,sy+sh-1,1,-1],[sx+sw-1,sy+sh-1,-1,-1]];
  const ca=.6+.4*Math.sin(p*Math.PI*6);for(const [x,y,dx,dy] of corners){line(c,x,y,x+bl*dx,y,br,1.6,ca);line(c,x,y,x,y+bl*dy,br,1.6,ca);}
  const st=seg(p,.06,.48);if(st>0&&st<1){const ly=sy+sh*eIO(st);const g=c.createLinearGradient(0,ly-9,0,ly);g.addColorStop(0,rgba(pal.accent,0));g.addColorStop(1,rgba(pal.accent,.45));c.fillStyle=g;c.fillRect(sx,ly-9,sw,9);line(c,sx-2,ly,sx+sw+2,ly,'#FFFFFF',1.6);}
  arrow(c,74,96,50,pal.accent,eOut(seg(p,.48,.6)),fl);
  const pt=eOut(seg(p,.56,.72));if(pt>0){const ox=lerp(12,0,pt);page(c,106+ox,16,46,64,pt*fl,0);
    for(let i=0;i<3;i++){const t=seg(p,.68+i*.06,.76+i*.06);const ly=34+i*13;check(c,114+ox,ly,6,GREEN,t,fl);line(c,121+ox,ly,lerp(121,145,eOut(t))+ox,ly,LINE,1.6,fl*clamp(t*3));}
    badge(c,'PDF',112+ox,16,RED,pt*fl,back(seg(p,.6,.74)));}
 },
 // 2. Editor: se escribe en la hoja con la barra de formato y sale en PDF/Word/Excel.
 TEXT_TO_PDF(c,p,pal){
  const fl=fadeLoop(p);
  const x=50,y=9,w=70,h=82;rr(c,x+1.2,y+1.6,w,h,3,'#000',.22);rr(c,x,y,w,h,3,PAPER);
  rr(c,x+4,y+4,w-8,9,2,'#DDE3EA');['B','I','U'].forEach((s,i)=>{text(c,s,x+10+i*8,y+8.8,6,INK);});rr(c,x+w-20,y+6,12,5,1.5,pal.accent,.8);
  const widths=[48,40,52,30,44];let curX=null,curY=null;
  for(let i=0;i<5;i++){const t=seg(p,.06+i*.1,.15+i*.1);if(t<=0)break;const ly=y+22+i*10;const lw=widths[i]*t;line(c,x+8,ly,x+8+lw,ly,i==0?INK:'#9AA6B4',i==0?2.4:1.7);curX=x+8+lw+1.5;curY=ly;}
  if(curX!==null&&p<.6&&Math.floor(p*12)%2==0)line(c,curX,curY-3.5,curX,curY+3.5,pal.accent,1.2);
  const fmt=[['DOCX','#3D7BFF',22],['XLSX','#22A06B',50],['PDF',RED,78]];
  fmt.forEach(([l,col,yy],i)=>{const t=seg(p,.58+i*.06,.7+i*.06);if(t>0){arrow(c,123,134,yy,pal.accent,eOut(t),fl);badge(c,l,149,yy,col,fl,back(t));}});
 },
 // 3. Marca, numera y protege: marca de agua, números de página y candado que se cierra.
 PDF_WATERMARK_SECURITY(c,p,pal){
  const fl=fadeLoop(p);
  page(c,34,14,56,76,1,0);page(c,28,10,56,76,1,5);
  const wm=seg(p,.08,.3);if(wm>0){c.save();c.translate(56,50);c.rotate(-0.55);text(c,'GANA GEO',0,0,9.5,pal.accent,.55*wm*fl);c.restore();}
  const nt=seg(p,.3,.45);if(nt>0){rr(c,48,78,16,7,3.5,INK,fl*nt);text(c,'1 / 2',56,81.7,4.8,'#fff',fl*nt);}
  const lx=126,ly=56;const lt=eOut(seg(p,.5,.66));const lift=lerp(-9,0,lt);
  c.save();c.globalAlpha*=fl;c.strokeStyle='#E7ECF2';c.lineWidth=4;c.lineCap='round';c.beginPath();c.moveTo(lx-8,ly-4+lift*0.15);c.lineTo(lx-8,ly-12+lift);c.arc(lx,ly-12+lift,8,Math.PI,0);c.lineTo(lx+8,ly-4+(lift<0?lift:0));c.stroke();c.restore();
  const locked=seg(p,.64,.72);const bodyCol=locked>0.5?GREEN:pal.accent;rr(c,lx-14,ly-5,28,24,5,bodyCol,fl);circle(c,lx,ly+4,3,'#2A0E10',fl);rr(c,lx-1.2,ly+4,2.4,7,1,'#2A0E10',fl);
  if(locked>0){const r=lerp(14,24,locked);c.save();c.globalAlpha*=(1-locked)*fl;c.strokeStyle=GREEN;c.lineWidth=1.5;c.beginPath();c.arc(lx,ly+7,r,0,Math.PI*2);c.stroke();c.restore();}
 },
 // 4. Imágenes a PDF: las fotos vuelan y se acomodan dentro de un PDF.
 IMAGES_TO_PDF(c,p,pal){
  const fl=fadeLoop(p);
  const px=108,py=12,pw=48,ph=72;rr(c,px+1.2,py+1.6,pw,ph,3,'#000',.22);rr(c,px,py,pw,ph,3,PAPER);
  const starts=[[12,12,'#6FB7FF','#3DDC84'],[30,38,'#FFB35A','#E5484D'],[12,64,'#C997FF','#6DE1D2']];
  arrow(c,74,96,48,pal.accent,1,0.35);
  starts.forEach(([sx,sy,sky,hill],i)=>{const t=eIO(seg(p,.12+i*.12,.38+i*.12));const tx=px+5,ty=py+8+i*21;
    const x=lerp(sx,tx,t),y=lerp(sy,ty,t),w=lerp(34,38,t),h=lerp(24,17,t);const rot=(1-t)*(i-1)*0.18;
    c.save();c.translate(x+w/2,y+h/2);c.rotate(rot);photo(c,-w/2,-h/2,w,h,i*.12+.38<p? fl:1,sky,hill);c.restore();});
  badge(c,'PDF',px+pw-6,py+2,RED,fl*seg(p,.72,.8),back(seg(p,.72,.84)));
 },
 // 5. Organizar PDF: las páginas se ordenan 1-2-3 y se unen en un solo PDF.
 PDF_ORGANIZER(c,p,pal){
  const fl=fadeLoop(p);
  const order0=[3,1,2];const slots=[22,68,114];const y0=24,w=34,h=48;
  const t1=eIO(seg(p,.1,.42));const t2=eIO(seg(p,.5,.7));
  const items=order0.map((n,i)=>{const from=slots[i];const to=slots[n-1];let x=lerp(from,to,t1);let y=y0-Math.sin(Math.PI*t1)*(n==3?14:-8);
    const sx=58+(3-n)*4,sy=16+(3-n)*3; x=lerp(x,sx,t2);y=lerp(y,sy,t2);return {n,x,y};});
  items.sort((a,b)=>t2>0?b.n-a.n:a.n-b.n);
  items.forEach(({n,x,y})=>{rr(c,x+1.2,y+1.6,w,h,3,'#000',.22);rr(c,x,y,w,h,3,PAPER);line(c,x+6,y+9,x+24,y+9,LINE,1.5);line(c,x+6,y+15,x+28,y+15,LINE,1.5);text(c,String(n),x+w/2,y+h*0.62,15,pal.accent);});
  const bt=seg(p,.7,.82);if(bt>0)badge(c,'PDF',100,19,RED,fl,back(bt));
  if(bt>0){const ct=seg(p,.74,.86);rr(c,62,78,34,10,5,GREEN,fl*ct);text(c,'Unido',79,83.4,6,'#06210F',fl*ct);}
 },
 // 6. PDF a imágenes: del PDF salen fotos en cuadrícula.
 PDF_TO_IMAGES(c,p,pal){
  const fl=fadeLoop(p);
  page(c,16,12,48,72,1,5);badge(c,'PDF',26,13,RED);
  arrow(c,70,92,48,pal.accent,eOut(seg(p,.08,.22)),fl);
  const cols=[['#6FB7FF','#3DDC84'],['#FFB35A','#E5484D'],['#C997FF','#6DE1D2'],['#74F1FF','#22A06B']];
  for(let i=0;i<4;i++){const t=seg(p,.22+i*.09,.36+i*.09);if(t<=0)continue;const gx=100+(i%2)*32,gy=22+Math.floor(i/2)*30;const s=back(t);
    c.save();c.translate(gx+14,gy+11);c.scale(s,s);photo(c,-14,-11,28,22,fl,...cols[i]);c.restore();}
  const jt=seg(p,.66,.78);if(jt>0)badge(c,'JPG',148,84,'#FFB35A',fl,back(jt));
 },
 // 7. Firmar PDF: una pluma dibuja la firma sobre la línea y aparece el check.
 SIGN_PDF(c,p,pal){
  const fl=fadeLoop(p);
  page(c,36,8,98,84,1,2);
  line(c,52,74,118,74,'#9AA6B4',1.2);text(c,'Firma',85,80.5,5.2,'#8792A2',1,false);
  const pts=SIG;const t=seg(p,.1,.62);const n=Math.max(1,Math.floor(pts.length*eIO(t)));
  if(t>0){c.save();c.globalAlpha*=fl;c.strokeStyle='#1F3A93';c.lineWidth=1.9;c.lineCap='round';c.lineJoin='round';c.beginPath();c.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<n;i++)c.lineTo(pts[i][0],pts[i][1]);c.stroke();c.restore();
   if(t<1){const [ex,ey]=pts[n-1];c.save();c.translate(ex,ey);c.rotate(-0.7);rr(c,-1.6,-18,3.2,15,1.2,'#2B3A55');c.beginPath();c.fillStyle='#E7B84B';c.moveTo(-1.6,-3);c.lineTo(1.6,-3);c.lineTo(0,1);c.closePath();c.fill();c.restore();}}
  const ct=seg(p,.66,.78);if(ct>0){circle(c,124,22,9*back(ct),GREEN,fl);check(c,124,22.5,9,'#06210F',seg(p,.7,.82),fl);}
 }
};
// Firma: curvas tipo cursiva, en puntos (se arma una vez).
const SIG=(()=>{const segs=[[[54,70],[58,52],[64,52],[63,64]],[[63,64],[62,74],[70,60],[74,62]],[[74,62],[78,64],[78,70],[82,66]],[[82,66],[88,56],[92,58],[90,68]],[[90,68],[89,74],[98,62],[102,60]],[[102,60],[108,58],[106,70],[112,66]],[[112,66],[116,62],[118,58],[120,58]]];
 const out=[];for(const [a,b,c2,d] of segs){for(let i=0;i<=14;i++){const t=i/14,mt=1-t;out.push([mt*mt*mt*a[0]+3*mt*mt*t*b[0]+3*mt*t*t*c2[0]+t*t*t*d[0],mt*mt*mt*a[1]+3*mt*mt*t*b[1]+3*mt*t*t*c2[1]+t*t*t*d[1]]);}}return out;})();
function drawScene(c,id,p,pal,pw,ph){c.save();c.scale(pw/W,ph/H);bg(c,pal);c.restore();c.save();const s=Math.min(pw/W,ph/H);c.translate((pw-W*s)/2,(ph-H*s)/2);c.scale(s,s);SCENES[id](c,p,pal);c.restore();}
