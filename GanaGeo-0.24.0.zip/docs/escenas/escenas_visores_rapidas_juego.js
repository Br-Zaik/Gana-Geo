PAL.VIEWERS={container:'#233244',badge:'#31455D',accent:'#C5D9F1'};
PAL.QUICK={container:'#16343A',badge:'#1E4950',accent:'#6DE1D2'};
PAL.GAME={container:'#102E45',badge:'#1C425E',accent:'#B7FF00'};
const VDARK='#151F2B';
const QR=(()=>{const n=11,g=[];let seed=7;const rnd=()=>{seed=(seed*1103515245+12345)&0x7fffffff;return seed/0x7fffffff;};
 for(let r=0;r<n;r++){g.push([]);for(let c=0;c<n;c++){const inF=(rr,cc)=>r>=rr&&r<rr+3&&c>=cc&&c<cc+3;const f=inF(0,0)||inF(0,8)||inF(8,0);g[r].push(f?2:(rnd()>.5?1:0));}}
 const order=[];for(let r=0;r<n;r++)for(let c=0;c<n;c++)if(g[r][c]==1)order.push([r,c,rnd()]);order.sort((a,b)=>a[2]-b[2]);return {g,order};})();
Object.assign(SCENES,{
 PDF_VIEWER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const vx=16,vy=10,vw=70,vh=80;rr(c,vx,vy,vw,vh,6,VDARK,fi);
  const off=eIO(seg(p,.06,.5))*48;c.save();c.beginPath();c.rect(vx+4,vy+4,vw-8,vh-8);c.clip();
  for(let k=0;k<4;k++){const py=vy+8+k*48-off;page(c,vx+10,py,vw-20,42,fi,4);if(k==2&&p>.5){const ht=seg(p,.5,.6);rr(c,vx+16,py+42*.3+42*.15-2.5,32*ht,5,1.5,'#FFD54F',.6*fl);}}c.restore();
  badge(c,'PDF',vx+12,vy+6,RED,fi);
  const pt=seg(p,.06,.12);rr(c,vx+vw/2-14,vy+vh-11,28,9,4.5,'#000',.5*fi);text(c,p<.3?'1 / 12':'3 / 12',vx+vw/2,vy+vh-6.2,5.4,'#FFFFFF',fi);
  const mt=eOut(seg(p,.58,.74));if(mt>0){const mx=lerp(60,126,mt),my=lerp(56,46,mt),r=20;c.save();c.beginPath();c.arc(mx,my,r,0,Math.PI*2);c.clip();rr(c,mx-r,my-r,2*r,2*r,0,PAPER,fl);line(c,mx-16,my-8,mx+14,my-8,LINE,3,fl);rr(c,mx-16,my-1,26,6,2,'#FFD54F',.6*fl);line(c,mx-16,my+10,mx+10,my+10,LINE,3,fl);c.restore();
   c.save();c.globalAlpha*=fl;c.strokeStyle=pal.accent;c.lineWidth=3;c.beginPath();c.arc(mx,my,r,0,Math.PI*2);c.stroke();c.restore();line(c,mx+r*.72,my+r*.72,mx+r*1.15,my+r*1.15,pal.accent,4.5,fl);}
 },
 WORD_VIEWER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=26,y=8,w=78,h=84;rr(c,x+1.2,y+1.6,w,h,3,'#000',.22);rr(c,x,y,w,h,3,PAPER);
  const items=[['t',y+12,50,2.8,'#2B3A55'],['l',y+22,62,1.5,'#9AA6B4'],['l',y+28,56,1.5,'#9AA6B4'],['l',y+34,60,1.5,'#9AA6B4'],['h',y+44,36,2.2,'#3D7BFF'],['l',y+52,58,1.5,'#9AA6B4']];
  items.forEach(([k,ly,len,lw,col],i)=>{const t=seg(p,.06+i*.06,.14+i*.06);line(c,x+8,ly,x+8+len*eOut(t),ly,col,lw,fi*clamp(t*4));});
  const tt=seg(p,.44,.58);if(tt>0){const tx=x+8,ty=y+60,tw=62,th=18;c.save();c.globalAlpha*=fl*tt;c.strokeStyle='#9AA6B4';c.lineWidth=.8;c.strokeRect(tx,ty,tw,th);c.beginPath();c.moveTo(tx,ty+9);c.lineTo(tx+tw,ty+9);c.moveTo(tx+tw/3,ty);c.lineTo(tx+tw/3,ty+th);c.moveTo(tx+tw*2/3,ty);c.lineTo(tx+tw*2/3,ty+th);c.stroke();c.restore();rr(c,tx,ty,tw,9,0,'#3D7BFF',.25*fl*tt);}
  badge(c,'DOCX',x+12,y+2,'#3D7BFF',fi);
  const et=seg(p,.6,.72);if(et>0){const ex=136,ey=50,blink=Math.abs(Math.sin(p*Math.PI*3))>.97?.2:1;c.save();c.translate(ex,ey);c.scale(back(et),back(et)*blink);c.globalAlpha*=fl;c.strokeStyle=pal.accent;c.lineWidth=2.4;c.beginPath();c.ellipse(0,0,18,10,0,0,Math.PI*2);c.stroke();c.fillStyle=pal.accent;c.beginPath();c.arc(0,0,5.5,0,Math.PI*2);c.fill();c.fillStyle='#233244';c.beginPath();c.arc(0,0,2.4,0,Math.PI*2);c.fill();c.restore();}
 },
 EXCEL_VIEWER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=14,y=14,cw=26,ch=12,cols=4,rows=5;rr(c,x-1,y-1,cols*cw+10+2,rows*ch+2,3,PAPER,fi);
  rr(c,x+10,y,cols*cw,ch,0,'#22A06B',fi);['A','B','C','D'].forEach((l,i)=>text(c,l,x+10+i*cw+cw/2,y+6.4,4.6,'#FFFFFF',fi));
  for(let r=1;r<rows;r++){text(c,String(r),x+5,y+r*ch+6.4,4.6,'#5F6B7A',fi);}
  c.save();c.globalAlpha*=.6*fi;c.strokeStyle='#C9D3DD';c.lineWidth=.6;for(let i=0;i<=cols;i++){c.beginPath();c.moveTo(x+10+i*cw,y);c.lineTo(x+10+i*cw,y+rows*ch);c.stroke();}for(let r=0;r<=rows;r++){c.beginPath();c.moveTo(x,y+r*ch);c.lineTo(x+10+cols*cw,y+r*ch);c.stroke();}c.restore();
  const vals=[.7,.4,.9,.55,.3,.8,.6,.45,.85,.5,.65,.35,.75,.6,.4,.9];
  for(let i=0;i<16;i++){const r=1+Math.floor(i/4),k=i%4;const t=seg(p,.06+i*.025,.12+i*.025);rr(c,x+12+k*cw,y+r*ch+4,(cw-6)*vals[i]*eOut(t),4,1.5,k==3?'#22A06B':'#9AA6B4',fi*fl*clamp(t*3));}
  const st=eIO(seg(p,.5,.7));const sr=1+Math.round(lerp(0,3,st)),sk=3;rrStroke(c,x+10+sk*cw,y+sr*ch,cw,ch,1,'#22A06B',1.8,fl*seg(p,.48,.52));
  badge(c,'XLSX',x+cols*cw+22,y+4,'#22A06B',fi);
  const tt=seg(p,.72,.82);if(tt>0)pill(c,'Σ 2,450',x+cols*cw+22,y+40,34,'#22A06B','#FFFFFF',5.4,fl,back(tt));
 },
 POWERPOINT_VIEWER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const sx=30,sy=10,sw=96,sh=54;rr(c,sx+1.2,sy+1.6,sw,sh,3,'#000',.22*fi);
  const slide=p<.3?0:p<.6?1:2;const tr=p<.3?0:p<.6?seg(p,.3,.38):seg(p,.6,.68);
  c.save();c.beginPath();c.rect(sx,sy,sw,sh);c.clip();
  const draw=(k,ox)=>{rr(c,sx+ox,sy,sw,sh,3,PAPER,fi);rr(c,sx+ox,sy,sw,12,0,'#D35230',fi);line(c,sx+ox+8,sy+6,sx+ox+50,sy+6,'#FFFFFF',2,fi);
   if(k==0){line(c,sx+ox+10,sy+24,sx+ox+70,sy+24,'#2B3A55',3,fi);line(c,sx+ox+10,sy+34,sx+ox+56,sy+34,'#9AA6B4',1.6,fi);line(c,sx+ox+10,sy+41,sx+ox+62,sy+41,'#9AA6B4',1.6,fi);}
   if(k==1){[16,26,20,34].forEach((h,i)=>rr(c,sx+ox+14+i*14,sy+50-h,9,h,1.5,i==3?'#D35230':'#F0A58E',fi));}
   if(k==2){c.save();c.globalAlpha*=fi;c.fillStyle='#D35230';c.beginPath();c.moveTo(sx+ox+48,sy+32);c.arc(sx+ox+48,sy+32,15,-Math.PI/2,Math.PI*0.8);c.closePath();c.fill();c.fillStyle='#F0A58E';c.beginPath();c.moveTo(sx+ox+48,sy+32);c.arc(sx+ox+48,sy+32,15,Math.PI*0.8,Math.PI*1.5);c.closePath();c.fill();c.restore();}};
  if(tr>0&&tr<1){draw(slide-1,-sw*eIO(tr));draw(slide,sw*(1-eIO(tr)));}else draw(slide,0);c.restore();
  for(let i=0;i<3;i++){const tx=sx+14+i*24,ty=sy+sh+8;rr(c,tx,ty,20,12,2,i==slide?PAPER:'#4A5D75',fi);if(i==slide)rrStroke(c,tx-1.5,ty-1.5,23,15,3,'#D35230',1.4,fl);}
  badge(c,'PPTX',sx+sw-4,sy-1,'#D35230',fi);
 },
 QR_TOOL(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=20,y=12,m=6.6,n=11;rr(c,x-4,y-4,n*m+8,n*m+8,4,'#FFFFFF',fi);
  [[0,0],[0,8],[8,0]].forEach(([r,k])=>{rr(c,x+k*m,y+r*m,3*m,3*m,1.5,'#0B1F24',fi);rr(c,x+k*m+m*.6,y+r*m+m*.6,3*m-m*1.2,3*m-m*1.2,1,'#FFFFFF',fi);rr(c,x+k*m+m,y+r*m+m,m,m,.8,'#0B1F24',fi);});
  const tot=QR.order.length;const shown=Math.floor(tot*eOut(seg(p,.05,.45)));for(let i=0;i<shown;i++){const [r,k]=QR.order[i];rr(c,x+k*m+.4,y+r*m+.4,m-.8,m-.8,1,'#0B1F24',fi*fl);}
  const st=seg(p,.5,.72);if(st>0&&st<1){const ly=y-2+(n*m+4)*eIO(st);line(c,x-6,ly,x+n*m+6,ly,pal.accent,2,fl);rr(c,x-4,ly-6,n*m+8,6,0,pal.accent,.18*fl);}
  const ct=seg(p,.72,.84);if(ct>0){circle(c,x+n*m,y,8*back(ct),GREEN,fl);check(c,x+n*m,y+.5,8,'#06210F',seg(p,.76,.86),fl);}
  const bx=114,by=22;const bars=[2,1,1,3,1,2,1,1,2,3,1,1,2,1,3,1];let cx=bx;rr(c,bx-4,by-4,48,50,3,'#FFFFFF',fi);
  bars.forEach((w,i)=>{const t=seg(p,.2+i*.015,.26+i*.015);if(i%2==0)rr(c,cx,by,w*1.3,38*eOut(t),0,'#0B1F24',fi*fl*(t>0?1:0));cx+=w*1.3+.8;});
 },
 WORD_COUNTER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const x=14,y=12,w=82,h=76;rr(c,x,y,w,h,5,'#0F262B',fi);
  const lens=[64,58,66,40,60,52,30];let lastX=null,lastY=null;
  lens.forEach((L,i)=>{const t=seg(p,.05+i*.07,.12+i*.07);if(t<=0)return;const ly=y+12+i*9;line(c,x+8,ly,x+8+L*t,ly,'#E3F7F4',1.6,fi*fl);lastX=x+8+L*t+2;lastY=ly;});
  if(lastX&&p<.56&&Math.floor(p*14)%2==0)line(c,lastX,lastY-3,lastX,lastY+3,pal.accent,1.1,fl);
  const label=p<.22?'12 palabras':p<.42?'64 palabras':'128 palabras';
  c.save();c.translate(134,32);rr(c,-28,-10,56,20,6,pal.accent,fi);text(c,label,0,.5,6,'#06292D',fi);c.restore();
  const rt=seg(p,.58,.7);if(rt>0){c.save();c.translate(134,62);c.scale(back(rt),back(rt));rr(c,-28,-9,56,18,6,'#0F262B',fl);circle(c,-17,0,5,'#FFFFFF',fl);line(c,-17,0,-17,-3,'#0F262B',1,fl);line(c,-17,0,-15,0,'#0F262B',1,fl);text(c,'1 min',4,.5,6.4,'#FFFFFF',fl);c.restore();}
 },
 STOPWATCH_TIMER(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const cx=48,cy=56,r=27;const press=1-.12*Math.sin(Math.PI*seg(p,.02,.08));
  rr(c,cx-5,cy-r-11*press,10,6,2,'#9AA6B4',fi);rr(c,cx-2,cy-r-6,4,6,1,'#9AA6B4',fi);
  circle(c,cx,cy,r+3,'#0F262B',fi);circle(c,cx,cy,r,PAPER,fi);
  for(let i=0;i<12;i++){const a=i/12*Math.PI*2;line(c,cx+Math.cos(a)*(r-3),cy+Math.sin(a)*(r-3),cx+Math.cos(a)*(r-6),cy+Math.sin(a)*(r-6),'#9AA6B4',i%3?1:1.6,fi);}
  const t=eIO(seg(p,.06,.7));c.save();c.globalAlpha*=.3*fl;c.fillStyle=pal.accent;c.beginPath();c.moveTo(cx,cy);c.arc(cx,cy,r-2,-Math.PI/2,-Math.PI/2+Math.PI*2*t);c.closePath();c.fill();c.restore();
  const a=-Math.PI/2+t*Math.PI*2*3;line(c,cx,cy,cx+Math.cos(a)*(r-6),cy+Math.sin(a)*(r-6),'#E5484D',1.6,fi);circle(c,cx,cy,2.4,'#2B3A55',fi);
  const rows=[['Estudio','25:00',.2],['Descanso','5:00',.45]];
  rows.forEach(([k,v,st],i)=>{const tt=seg(p,st,st+.12);if(tt<=0)return;const ry=34+i*26;c.save();c.translate(130,ry);c.scale(back(tt),back(tt));rr(c,-28,-10,56,20,6,i==0?pal.accent:'#0F262B',fl);textL(c,k,-24,-4,4.8,i==0?'#06292D':'#A8D5CF',fl,false);textR(c,v,24,3,8,i==0?'#06292D':'#FFFFFF',fl);c.restore();});
 },
 GEO_ADVENTURES(c,p,pal){
  const fl=fadeLoop(p),fi=seg(p,0,.05);
  const plats=[[10,72,42],[64,58,42],[118,44,42]];
  plats.forEach(([x,y,w])=>{rr(c,x,y,w,10,3,'#2C5A7A',fi);rr(c,x,y,w,3.5,2,'#3DDC84',fi);});
  const pos=(t)=>{const j1=seg(t,.1,.34),j2=seg(t,.4,.64);if(j2>0){const x=lerp(85,139,eIO(j2)),y=lerp(51,37,j2)-Math.sin(Math.PI*j2)*22;return [x,y];}const x=lerp(31,85,eIO(j1)),y=lerp(65,51,j1)-Math.sin(Math.PI*j1)*22;return [x,y];};
  const coins=[[58,36,.22],[112,22,.52]];
  coins.forEach(([x,y,tc])=>{const got=p>tc;if(!got){const sw=Math.abs(Math.cos(p*Math.PI*6));c.save();c.translate(x,y);c.scale(Math.max(sw,.15),1);circle(c,0,0,4.6,'#FFD54F',fi);circle(c,0,0,2.6,'#E7B84B',fi);c.restore();}
   else{const sp=seg(p,tc,tc+.1);if(sp<1)for(let k=0;k<5;k++){const a=k*Math.PI*2/5;circle(c,x+Math.cos(a)*8*sp,y+Math.sin(a)*8*sp,1.6*(1-sp),'#FFD54F',fl);}}});
  const [hx,hy]=pos(p);const squash=1+.12*Math.sin(p*Math.PI*30)*(1-seg(p,.64,.7));
  c.save();c.translate(hx,hy);c.scale(1/squash,squash);circle(c,0,0,7,pal.accent,fi);circle(c,-2.4,-1.5,1.6,'#102E45',fi);circle(c,2.4,-1.5,1.6,'#102E45',fi);c.restore();
  const ht=seg(p,.68,.8);if(ht>0){c.save();c.translate(150,18);const s=back(ht);c.scale(s,s);c.globalAlpha*=fl;c.fillStyle='#FFD54F';c.beginPath();c.arc(-3,-1,3.6,0,Math.PI*2);c.arc(3,-1,3.6,0,Math.PI*2);c.fill();c.beginPath();c.moveTo(-6.4,0);c.lineTo(6.4,0);c.lineTo(0,7.5);c.closePath();c.fill();c.restore();}
 }
});
