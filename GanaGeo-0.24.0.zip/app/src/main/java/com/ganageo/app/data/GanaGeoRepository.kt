package com.ganageo.app.data

import com.ganageo.app.model.AppFeatures
import com.ganageo.app.model.DashboardData
import com.ganageo.app.model.GeoGameActivation
import com.ganageo.app.model.GeoGameFinish
import com.ganageo.app.model.GeoGameLifePurchase
import com.ganageo.app.model.GeoGameRunStart
import com.ganageo.app.model.GeoGameStatus
import com.ganageo.app.model.LedgerEntry
import com.ganageo.app.model.PlayPurchaseVerification
import com.ganageo.app.model.Profile
import com.ganageo.app.model.ToolCreditAccount
import com.ganageo.app.model.ToolOperationReservation
import com.ganageo.app.model.ToolOperationResult
import com.ganageo.app.model.Wallet
import com.ganageo.app.model.Withdrawal
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.Google
import io.github.jan.supabase.auth.providers.builtin.IDToken
import io.github.jan.supabase.functions.functions
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import io.ktor.client.statement.bodyAsText
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class GanaGeoRepository(
    private val client: SupabaseClient
) {
    suspend fun signInWithGoogleIdToken(idToken: String, nonce: String) {
        require(idToken.isNotBlank()) { "Google no devolvió un token de acceso válido." }
        require(nonce.isNotBlank()) { "No se pudo validar la solicitud de acceso con Google." }
        client.auth.signInWith(IDToken) {
            this.idToken = idToken
            provider = Google
            this.nonce = nonce
        }
    }

    suspend fun signOut() {
        client.auth.signOut()
    }

    fun currentUserId(): String? = client.auth.currentSessionOrNull()?.user?.id

    suspend fun registerMyDevice(installationId: String) {
        client.postgrest.rpc(
            function = "register_my_device",
            parameters = buildJsonObject {
                put("p_installation_hash", installationId)
            }
        )
    }

    /**
     * Vincula esta instalación. Si es una instalación nueva del mismo dueño,
     * el servidor cambia solo de celular (con límite) y devuelve true.
     */
    suspend fun linkMyDevice(installationId: String): Boolean {
        val result = client.postgrest.rpc(
            function = "link_my_device",
            parameters = buildJsonObject {
                put("p_installation_hash", installationId)
            }
        )
        return result.data.contains("switched")
    }

    /** true si la última carga del panel cambió la cuenta a este celular. */
    @Volatile
    var lastLinkSwitched: Boolean = false
        private set

    fun consumeLastLinkSwitched(): Boolean {
        val switched = lastLinkSwitched
        lastLinkSwitched = false
        return switched
    }

    suspend fun replaceMyDevice(installationId: String) {
        client.postgrest.rpc(
            function = "replace_my_device",
            parameters = buildJsonObject {
                put("p_installation_hash", installationId)
            }
        )
    }

    suspend fun loadDashboard(installationId: String): DashboardData {
        val userId = currentUserId() ?: error("No hay una sesión activa.")

        // Se valida antes de cualquier lectura. Sin la RPC segura, el panel no se abre.
        try {
            lastLinkSwitched = try {
                linkMyDevice(installationId)
            } catch (linkError: Throwable) {
                val linkRaw = linkError.message.orEmpty()
                val linkMissing = linkRaw.contains("PGRST202", ignoreCase = true) ||
                    linkRaw.contains("Could not find the function", ignoreCase = true)
                if (!linkMissing) throw linkError
                // Servidor antiguo: control anterior.
                registerMyDevice(installationId)
                false
            }
        } catch (error: Throwable) {
            val raw = error.message.orEmpty()
            val functionMissing = raw.contains("PGRST202", ignoreCase = true) ||
                raw.contains("Could not find the function", ignoreCase = true) ||
                (raw.contains("register_my_device", ignoreCase = true) &&
                    raw.contains("not found", ignoreCase = true))

            if (functionMissing) {
                error(
                    "El control de instalación no está actualizado en Supabase. " +
                        "Ejecuta supabase/04_native_login_device_replacement.sql."
                )
            }
            throw error
        }

        // Después de validar la instalación, las lecturas se hacen en paralelo:
        // la cuenta abre más rápido, sobre todo con datos móviles.
        return coroutineScope {
            val profileAsync = async {
                client.from("profiles")
                    .select {
                        filter { eq("user_id", userId) }
                    }
                    .decodeSingle<Profile>()
            }

            val walletAsync = async {
                client.from("wallets")
                    .select {
                        filter { eq("user_id", userId) }
                    }
                    .decodeSingle<Wallet>()
            }

            val ledgerAsync = async {
                client.from("ledger_entries")
                    .select {
                        filter { eq("user_id", userId) }
                        order("created_at", Order.DESCENDING)
                        limit(50)
                    }
                    .decodeList<LedgerEntry>()
            }

            val withdrawalsAsync = async {
                client.from("withdrawals")
                    .select {
                        filter { eq("user_id", userId) }
                        order("requested_at", Order.DESCENDING)
                        limit(50)
                    }
                    .decodeList<Withdrawal>()
            }

            val toolCreditsAsync = async {
                try {
                    client.from("tool_credit_accounts")
                        .select {
                            filter { eq("user_id", userId) }
                        }
                        .decodeSingle<ToolCreditAccount>()
                } catch (_: Throwable) {
                    ToolCreditAccount(userId = userId)
                }
            }

            val featuresAsync = async { loadAppFeatures() }

            DashboardData(
                profile = profileAsync.await(),
                wallet = walletAsync.await(),
                ledger = ledgerAsync.await(),
                withdrawals = withdrawalsAsync.await(),
                deviceNotice = null,
                toolCredits = toolCreditsAsync.await(),
                features = featuresAsync.await()
            )
        }
    }

    /** Si la función aún no existe en el servidor, todo lo monetario queda apagado. */
    suspend fun loadAppFeatures(): AppFeatures = try {
        client.postgrest.rpc(function = "get_app_features")
            .decodeList<AppFeatures>()
            .firstOrNull() ?: AppFeatures()
    } catch (_: Throwable) {
        AppFeatures()
    }

    suspend fun deleteMyAccount() {
        client.postgrest.rpc(function = "delete_my_account")
    }

    /**
     * Envía el token de Google Play a la Edge Function. El servidor valida la compra
     * con Google y acredita UNA sola vez. El teléfono nunca suma créditos.
     */
    suspend fun verifyPlayPurchase(
        productId: String,
        purchaseToken: String,
        orderId: String?
    ): PlayPurchaseVerification {
        val response = client.functions.invoke(
            function = "verify-play-purchase",
            body = buildJsonObject {
                put("product_id", productId)
                put("purchase_token", purchaseToken)
                if (!orderId.isNullOrBlank()) put("order_id", orderId)
            }
        )
        val raw = response.bodyAsText()
        val parsed = runCatching { lenientJson.decodeFromString<PlayPurchaseVerification>(raw) }
            .getOrElse { PlayPurchaseVerification(ok = false, error = raw.take(160)) }
        if (!parsed.ok) error(parsed.error ?: "No se pudo verificar la compra.")
        return parsed
    }

    suspend fun beginToolOperation(
        toolCode: String,
        creditCost: Long,
        installationId: String,
        requestId: String
    ): ToolOperationReservation {
        return client.postgrest.rpc(
            function = "begin_tool_operation_v2",
            parameters = buildJsonObject {
                put("p_tool_code", toolCode)
                put("p_credit_cost", creditCost)
                put("p_installation_hash", installationId)
                put("p_request_id", requestId)
            }
        ).decodeList<ToolOperationReservation>().single()
    }

    suspend fun completeToolOperation(
        operationId: String,
        installationId: String
    ): ToolOperationResult {
        return client.postgrest.rpc(
            function = "complete_tool_operation",
            parameters = buildJsonObject {
                put("p_operation_id", operationId)
                put("p_installation_hash", installationId)
            }
        ).decodeList<ToolOperationResult>().single()
    }

    suspend fun cancelToolOperation(operationId: String, installationId: String) {
        client.postgrest.rpc(
            function = "cancel_tool_operation",
            parameters = buildJsonObject {
                put("p_operation_id", operationId)
                put("p_installation_hash", installationId)
            }
        )
    }


    suspend fun getGeoGameStatus(installationId: String): GeoGameStatus {
        return client.postgrest.rpc(
            function = "get_geo_game_status",
            parameters = buildJsonObject {
                put("p_installation_hash", installationId)
            }
        ).decodeList<GeoGameStatus>().single()
    }

    suspend fun buyGeoGameLives(packageCode: String, installationId: String, requestId: String): GeoGameLifePurchase {
        return client.postgrest.rpc(
            function = "buy_geo_game_lives",
            parameters = buildJsonObject {
                put("p_package_code", packageCode)
                put("p_installation_hash", installationId)
                put("p_request_id", requestId)
            }
        ).decodeList<GeoGameLifePurchase>().single()
    }

    suspend fun startGeoGameRun(levelNo: Int, lifeType: String, installationId: String, requestId: String): GeoGameRunStart {
        return client.postgrest.rpc(
            function = "start_geo_game_run",
            parameters = buildJsonObject {
                put("p_level_no", levelNo)
                put("p_life_type", lifeType)
                put("p_installation_hash", installationId)
                put("p_request_id", requestId)
            }
        ).decodeList<GeoGameRunStart>().single()
    }

    suspend fun activateGeoGameRun(runId: String, installationId: String): GeoGameActivation {
        return client.postgrest.rpc(
            function = "activate_geo_game_run",
            parameters = buildJsonObject {
                put("p_run_id", runId)
                put("p_installation_hash", installationId)
            }
        ).decodeList<GeoGameActivation>().single()
    }

    suspend fun finishGeoGameRun(
        runId: String,
        won: Boolean,
        stars: Int,
        score: Long,
        timeMs: Long,
        installationId: String
    ): GeoGameFinish {
        return client.postgrest.rpc(
            function = "finish_geo_game_run",
            parameters = buildJsonObject {
                put("p_run_id", runId)
                put("p_won", won)
                put("p_stars", stars)
                put("p_score", score)
                put("p_time_ms", timeMs)
                put("p_installation_hash", installationId)
            }
        ).decodeList<GeoGameFinish>().single()
    }

    suspend fun cancelGeoGameRun(runId: String, installationId: String) {
        client.postgrest.rpc(
            function = "cancel_geo_game_run",
            parameters = buildJsonObject {
                put("p_run_id", runId)
                put("p_installation_hash", installationId)
            }
        )
    }

    suspend fun requestWithdrawal(
        amount: Double,
        paymentMethod: String,
        destination: String,
        installationId: String
    ) {
        client.postgrest.rpc(
            function = "request_withdrawal",
            parameters = buildJsonObject {
                put("p_amount", amount)
                put("p_payment_method", paymentMethod)
                put("p_payment_destination", destination.trim())
            }
        )
    }

    suspend fun cancelWithdrawal(withdrawalId: String, installationId: String) {
        client.postgrest.rpc(
            function = "cancel_my_withdrawal",
            parameters = buildJsonObject {
                put("p_withdrawal_id", withdrawalId)
            }
        )
    }

    private companion object {
        val lenientJson = Json { ignoreUnknownKeys = true }
    }
}
