package com.ganageo.app.ui.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import com.ganageo.app.data.RecentFilesTracker

/**
 * Igual que "Guardar como" de Android, pero además anota el archivo en
 * "Tus últimos archivos" de Inicio. No cambia cómo trabaja la herramienta.
 */
class TrackedCreateDocument(private val mimeType: String) : ActivityResultContract<String, Uri?>() {
    private val delegate = TrackedCreateDocument(mimeType)
    private var lastSuggestedName: String? = null
    private var lastContext: Context? = null

    override fun createIntent(context: Context, input: String): Intent {
        lastSuggestedName = input
        lastContext = context.applicationContext
        RecentFilesTracker.init(context)
        return delegate.createIntent(context, input)
    }

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? {
        val uri = delegate.parseResult(resultCode, intent)
        val context = lastContext
        if (uri != null && context != null) {
            runCatching { RecentFilesTracker.record(context, uri, lastSuggestedName, mimeType) }
        }
        return uri
    }
}
