package com.ganageo.app.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Un archivo que la app creó (PDF, imagen, Word, CSV…). */
data class RecentFile(
    val uri: String,
    val name: String,
    val mime: String,
    val createdMs: Long
)

/**
 * Anota los archivos que crean las herramientas para mostrarlos en Inicio.
 * Solo guarda la dirección del archivo en este celular; nunca lo sube.
 */
object RecentFilesTracker {
    private const val PREFS = "gana_geo_recent_files"
    private const val KEY_FILES = "files"
    private const val KEY_CREATED_TIMES = "created_times"
    private const val MAX_FILES = 8
    private const val WEEK_MS = 7L * 24 * 60 * 60 * 1000

    @Volatile
    private var appContext: Context? = null
    private val _files = MutableStateFlow<List<RecentFile>>(emptyList())
    val files: StateFlow<List<RecentFile>> = _files.asStateFlow()

    fun init(context: Context) {
        if (appContext != null) return
        appContext = context.applicationContext
        _files.value = readFiles()
    }

    /** Se llama justo cuando el usuario eligió dónde guardar o al guardar en Galería. */
    fun record(context: Context, uri: Uri, suggestedName: String?, mimeType: String?) {
        init(context)
        val ctx = appContext ?: return
        runCatching {
            ctx.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        val name = queryName(ctx, uri) ?: suggestedName?.takeIf { it.isNotBlank() } ?: "Archivo"
        val mime = runCatching { ctx.contentResolver.getType(uri) }.getOrNull()
            ?.takeIf { it.isNotBlank() && !it.endsWith("/*") }
            ?: mimeType?.takeIf { !it.endsWith("/*") }
            ?: guessMime(name)
        val now = System.currentTimeMillis()
        val entry = RecentFile(uri.toString(), name, mime, now)
        val current = _files.value.filterNot { it.uri == entry.uri }
        val updated = (listOf(entry) + current).take(MAX_FILES)
        current.drop(MAX_FILES - 1).forEach { evicted -> releaseGrant(ctx, evicted.uri) }
        _files.value = updated
        writeFiles(updated)
        addCreatedTime(now)
    }

    fun remove(uri: String) {
        val ctx = appContext ?: return
        releaseGrant(ctx, uri)
        val updated = _files.value.filterNot { it.uri == uri }
        _files.value = updated
        writeFiles(updated)
    }

    fun clear() {
        val ctx = appContext ?: return
        _files.value.forEach { releaseGrant(ctx, it.uri) }
        _files.value = emptyList()
        runCatching { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply() }
    }

    /** Cuántos archivos se crearon en los últimos 7 días. */
    fun createdThisWeek(nowMs: Long = System.currentTimeMillis()): Int =
        readCreatedTimes().count { nowMs - it in 0..WEEK_MS }

    private fun releaseGrant(ctx: Context, uri: String) {
        runCatching {
            ctx.contentResolver.releasePersistableUriPermission(
                Uri.parse(uri),
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
    }

    private fun queryName(ctx: Context, uri: Uri): String? = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
    }.getOrNull()?.takeIf { it.isNotBlank() }

    private fun guessMime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "pdf" -> "application/pdf"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "csv" -> "text/csv"
        "zip" -> "application/zip"
        else -> "application/octet-stream"
    }

    private fun prefs() = appContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun readFiles(): List<RecentFile> = runCatching {
        val raw = prefs()?.getString(KEY_FILES, null) ?: return emptyList()
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val uri = item.optString("uri").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            RecentFile(
                uri = uri,
                name = item.optString("name", "Archivo"),
                mime = item.optString("mime", "application/octet-stream"),
                createdMs = item.optLong("time", 0L)
            )
        }.take(MAX_FILES)
    }.getOrDefault(emptyList())

    private fun writeFiles(files: List<RecentFile>) {
        runCatching {
            val array = JSONArray()
            files.forEach { file ->
                array.put(
                    JSONObject()
                        .put("uri", file.uri)
                        .put("name", file.name)
                        .put("mime", file.mime)
                        .put("time", file.createdMs)
                )
            }
            prefs()?.edit()?.putString(KEY_FILES, array.toString())?.apply()
        }
    }

    private fun readCreatedTimes(): List<Long> = runCatching {
        prefs()?.getString(KEY_CREATED_TIMES, null)
            ?.split(',')
            ?.mapNotNull { it.trim().toLongOrNull() }
            .orEmpty()
    }.getOrDefault(emptyList())

    private fun addCreatedTime(nowMs: Long) {
        val kept = readCreatedTimes().filter { nowMs - it in 0..WEEK_MS }.takeLast(300) + nowMs
        runCatching { prefs()?.edit()?.putString(KEY_CREATED_TIMES, kept.joinToString(","))?.apply() }
    }
}
