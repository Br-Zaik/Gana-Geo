package com.ganageo.app.data

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import kotlinx.coroutines.suspendCancellableCoroutine
import java.security.MessageDigest
import kotlin.coroutines.resume

/** Paquete de créditos a la venta en Google Play (productos consumibles). */
data class CreditPack(
    val productId: String,
    val credits: Long,
    val fallbackPrice: String,
    val formattedPrice: String? = null
) {
    val displayPrice: String get() = formattedPrice ?: fallbackPrice
}

/** Resultado de una compra entregado por Google Play al teléfono. */
sealed interface BillingEvent {
    data class Purchased(val purchase: Purchase) : BillingEvent
    data class Pending(val productId: String) : BillingEvent
    data object Cancelled : BillingEvent
    data class Failed(val message: String) : BillingEvent
}

/**
 * Integración con Google Play Billing.
 *
 * Reglas de seguridad:
 * - El teléfono NUNCA suma créditos por su cuenta. Solo envía el token de compra a
 *   Supabase (Edge Function) y el servidor lo valida con la API de Google Play.
 * - Las compras PENDIENTES no se acreditan.
 * - La compra se consume solo después de que el servidor confirme la acreditación.
 *   Si se corta Internet, al volver a abrir la app se reintenta (el servidor es idempotente).
 */
class PlayBillingManager(
    context: Context,
    private val onEvent: (BillingEvent) -> Unit
) {
    private val listener = PurchasesUpdatedListener { result, purchases ->
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> purchases.orEmpty().forEach(::dispatchPurchase)
            BillingClient.BillingResponseCode.USER_CANCELED -> onEvent(BillingEvent.Cancelled)
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED ->
                onEvent(BillingEvent.Failed("Tienes una compra anterior sin acreditar. Se volverá a verificar."))
            else -> onEvent(BillingEvent.Failed(result.readableMessage()))
        }
    }

    private val client: BillingClient = BillingClient.newBuilder(context.applicationContext)
        .setListener(listener)
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .build()
        )
        .enableAutoServiceReconnection()
        .build()

    private var cachedDetails: Map<String, ProductDetails> = emptyMap()

    private fun dispatchPurchase(purchase: Purchase) {
        when (purchase.purchaseState) {
            Purchase.PurchaseState.PURCHASED -> onEvent(BillingEvent.Purchased(purchase))
            Purchase.PurchaseState.PENDING ->
                onEvent(BillingEvent.Pending(purchase.products.firstOrNull().orEmpty()))
            else -> Unit
        }
    }

    private suspend fun ensureConnected(): Boolean {
        if (client.isReady) return true
        return suspendCancellableCoroutine { continuation ->
            runCatching {
                client.startConnection(object : BillingClientStateListener {
                    override fun onBillingSetupFinished(result: BillingResult) {
                        if (continuation.isActive) {
                            continuation.resume(result.responseCode == BillingClient.BillingResponseCode.OK)
                        }
                    }

                    override fun onBillingServiceDisconnected() {
                        // enableAutoServiceReconnection vuelve a conectar en la siguiente llamada.
                    }
                })
            }.onFailure {
                if (continuation.isActive) continuation.resume(false)
            }
        }
    }

    /** Consulta precios reales en soles desde Google Play. Sin conexión devuelve los precios base. */
    suspend fun loadPacks(): List<CreditPack> {
        if (!ensureConnected()) return DEFAULT_PACKS
        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(
                DEFAULT_PACKS.map { pack ->
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(pack.productId)
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build()
                }
            )
            .build()

        val details: List<ProductDetails> = suspendCancellableCoroutine { continuation ->
            runCatching {
                client.queryProductDetailsAsync(params) { result, queryResult ->
                    val list = if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                        queryResult.productDetailsList
                    } else {
                        emptyList()
                    }
                    if (continuation.isActive) continuation.resume(list)
                }
            }.onFailure {
                if (continuation.isActive) continuation.resume(emptyList())
            }
        }

        cachedDetails = details.associateBy { it.productId }
        return DEFAULT_PACKS.map { pack ->
            val price = cachedDetails[pack.productId]?.oneTimePurchaseOfferDetails?.formattedPrice
            pack.copy(formattedPrice = price)
        }
    }

    /**
     * Abre la hoja de pago de Google Play. [userId] se envía cifrado (hash) para que el
     * servidor compruebe que la compra pertenece a la misma cuenta.
     */
    suspend fun launchPurchase(activity: Activity, productId: String, userId: String): Result<Unit> = runCatching {
        check(ensureConnected()) { "Google Play no está disponible en este momento." }
        if (cachedDetails[productId] == null) loadPacks()
        val details = cachedDetails[productId]
            ?: error("Este paquete todavía no está disponible en Google Play.")

        val flowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(
                listOf(
                    BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details)
                        .build()
                )
            )
            .setObfuscatedAccountId(accountHash(userId))
            .build()

        val result = client.launchBillingFlow(activity, flowParams)
        if (result.responseCode != BillingClient.BillingResponseCode.OK) {
            error(result.readableMessage())
        }
    }

    /** Compras pagadas que todavía no se consumieron (por ejemplo, si se cortó Internet). */
    suspend fun unfinishedPurchases(): List<Purchase> {
        if (!ensureConnected()) return emptyList()
        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP)
            .build()
        return suspendCancellableCoroutine { continuation ->
            runCatching {
                client.queryPurchasesAsync(params) { result, purchases ->
                    val list = if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                        purchases.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED }
                    } else {
                        emptyList()
                    }
                    if (continuation.isActive) continuation.resume(list)
                }
            }.onFailure {
                if (continuation.isActive) continuation.resume(emptyList())
            }
        }
    }

    /** Se llama SOLO después de que Supabase confirmó la acreditación. */
    suspend fun consume(purchaseToken: String): Boolean {
        if (!ensureConnected()) return false
        val params = ConsumeParams.newBuilder().setPurchaseToken(purchaseToken).build()
        return suspendCancellableCoroutine { continuation ->
            runCatching {
                client.consumeAsync(params) { result, _ ->
                    if (continuation.isActive) {
                        continuation.resume(result.responseCode == BillingClient.BillingResponseCode.OK)
                    }
                }
            }.onFailure {
                if (continuation.isActive) continuation.resume(false)
            }
        }
    }

    fun close() {
        runCatching { client.endConnection() }
    }

    private fun BillingResult.readableMessage(): String = when (responseCode) {
        BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE,
        BillingClient.BillingResponseCode.SERVICE_DISCONNECTED,
        BillingClient.BillingResponseCode.NETWORK_ERROR -> "Sin conexión con Google Play. Inténtalo de nuevo."
        BillingClient.BillingResponseCode.BILLING_UNAVAILABLE -> "Google Play no permite compras en este dispositivo o cuenta."
        BillingClient.BillingResponseCode.ITEM_UNAVAILABLE -> "Este paquete no está disponible."
        BillingClient.BillingResponseCode.DEVELOPER_ERROR -> "La tienda aún no está configurada para esta versión."
        else -> "No se pudo completar la compra."
    }

    companion object {
        val DEFAULT_PACKS = listOf(
            CreditPack(productId = "pack_geo_50", credits = 50, fallbackPrice = "S/ 5.00"),
            CreditPack(productId = "pack_geo_100", credits = 100, fallbackPrice = "S/ 10.00")
        )

        /** Hash SHA-256 del id de usuario: Google lo guarda junto a la compra sin datos personales. */
        fun accountHash(userId: String): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(userId.toByteArray(Charsets.UTF_8))
            return digest.joinToString("") { "%02x".format(it) }
        }
    }
}
