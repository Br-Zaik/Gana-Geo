package com.ganageo.app.ui.tools

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.DateUtils
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ganageo.app.data.RecentFile
import com.ganageo.app.data.RecentFilesTracker
import com.ganageo.app.model.LedgerEntry
import com.ganageo.app.model.ToolId
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen

// Lo que antes estaba en Inicio y ahora vive arriba en Herramientas
// ("Continuar", "Tus últimos archivos", consejo) y en Billetera ("Tu semana").

private val CardSurface = Color(0xFF0F2A1C)

/** "Continuar": la última herramienta que usaste, a un toque. */
@Composable
internal fun ContinueToolCard(tool: ToolId, onClick: () -> Unit) {
    val accent = categoryAccentColor(tool.category)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = categoryContainerColor(tool.category)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolThumbnail(
                tool = tool,
                modifier = Modifier
                    .size(width = 64.dp, height = 40.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "Continuar",
                    style = MaterialTheme.typography.labelMedium,
                    color = accent,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    tool.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(Icons.Rounded.ArrowForward, contentDescription = null, tint = accent)
        }
    }
}

/** Últimos archivos que crearon las herramientas: abrir o compartir. */
@Composable
internal fun RecentFilesCard(files: List<RecentFile>) {
    val context = LocalContext.current
    val shown = files.take(3)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "Tus últimos archivos",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = CardSurface),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column {
                shown.forEachIndexed { index, file ->
                    RecentFileRow(
                        file = file,
                        onOpen = { openRecentFile(context, file) },
                        onShare = { shareRecentFile(context, file) }
                    )
                    if (index < shown.lastIndex) {
                        HorizontalDivider(color = Color.White.copy(alpha = 0.06f))
                    }
                }
            }
        }
    }
}

@Composable
private fun RecentFileRow(file: RecentFile, onOpen: () -> Unit, onShare: () -> Unit) {
    val (icon, tint) = fileIcon(file.mime)
    val whenText = remember(file.createdMs) {
        DateUtils.getRelativeTimeSpanString(
            file.createdMs,
            System.currentTimeMillis(),
            DateUtils.MINUTE_IN_MILLIS
        ).toString()
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(tint.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                file.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                whenText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
        IconButton(onClick = onShare) {
            Icon(Icons.Rounded.Share, contentDescription = "Compartir ${file.name}", tint = NeonGreen)
        }
    }
}

private fun fileIcon(mime: String): Pair<ImageVector, Color> = when {
    mime == "application/pdf" -> Icons.Rounded.PictureAsPdf to Color(0xFFFF7A7A)
    mime.startsWith("image/") -> Icons.Rounded.Image to Color(0xFFFFB86B)
    mime.contains("sheet") || mime.contains("csv") -> Icons.Rounded.TableChart to Color(0xFF7BE0A0)
    else -> Icons.Rounded.Description to Color(0xFF8FC3FF)
}

/** Una línea corta de ayuda. */
@Composable
internal fun TipLine(tip: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Gold.copy(alpha = 0.08f))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Lightbulb, contentDescription = null, tint = Gold, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(tip, style = MaterialTheme.typography.bodySmall, color = Color(0xFFE7F2EA))
    }
}

internal val ToolTips = listOf(
    "Busca con tus palabras: \"bajar peso foto\", \"jale\" o \"igv\".",
    "Mantén presionado el ícono de Gana Geo para abrir el escáner al toque.",
    "Las herramientas gratis funcionan sin internet.",
    "En Perfil puedes poner la letra más grande.",
    "Junta tus fotos en un solo PDF con Imágenes a PDF.",
    "¿Cuánto necesitas para aprobar? Busca \"nota\".",
    "Comprime tus fotos antes de mandarlas por WhatsApp o correo.",
    "Usa créditos en herramientas premium y gana Geo Rewards."
)

internal fun tipOfToday(): String = ToolTips[java.time.LocalDate.now().dayOfYear % ToolTips.size]

/** "Tu semana": usos, archivos y Rewards de los últimos 7 días (va en Billetera). */
@Composable
fun WeekSummaryCard(toolUses: Int, files: Int, rewards: Long, hideBalances: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Tu semana", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                WeekStat(toolUses.toString(), "usos", NeonGreen, Modifier.weight(1f))
                WeekStat(files.toString(), "archivos", Color(0xFF8FC3FF), Modifier.weight(1f))
                WeekStat(if (hideBalances) "•••" else "+$rewards", "Rewards", Gold, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun WeekStat(value: String, label: String, color: Color, modifier: Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

fun rewardsInLastWeek(ledger: List<LedgerEntry>): Long {
    val limit = java.time.Instant.now().minus(java.time.Duration.ofDays(7))
    return ledger.sumOf { entry ->
        val created = entry.createdAt?.let { raw ->
            runCatching { java.time.OffsetDateTime.parse(raw).toInstant() }.getOrNull()
        }
        if (entry.pointsDelta > 0 && created != null && created.isAfter(limit)) entry.pointsDelta else 0L
    }
}

/** Abre el archivo con la app que el usuario elija. Si ya no existe, se quita de la lista. */
private fun openRecentFile(context: Context, file: RecentFile) {
    val uri = Uri.parse(file.uri)
    val readable = runCatching {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
    }.getOrDefault(false)
    if (!readable) {
        RecentFilesTracker.remove(file.uri)
        Toast.makeText(context, "Ese archivo ya no está. Lo quitamos de la lista.", Toast.LENGTH_SHORT).show()
        return
    }
    val view = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, file.mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    val opened = runCatching {
        context.startActivity(Intent.createChooser(view, "Abrir con").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.isSuccess
    if (!opened) {
        Toast.makeText(context, "No hay una app para abrir este archivo.", Toast.LENGTH_SHORT).show()
    }
}

private fun shareRecentFile(context: Context, file: RecentFile) {
    val uri = Uri.parse(file.uri)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = file.mime
        putExtra(Intent.EXTRA_STREAM, uri)
        clipData = ClipData.newRawUri(file.name, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    val shared = runCatching {
        context.startActivity(Intent.createChooser(send, "Compartir").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.isSuccess
    if (!shared) {
        RecentFilesTracker.remove(file.uri)
        Toast.makeText(context, "No se pudo compartir. Quizá el archivo ya no está.", Toast.LENGTH_SHORT).show()
    }
}
