package com.ganageo.app

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ganageo.app.data.DashboardCacheStore
import com.ganageo.app.data.DeviceIdentityStore
import com.ganageo.app.data.GanaGeoRepository
import com.ganageo.app.data.GeoGameLocalStore
import com.ganageo.app.data.LocalToolReservation
import com.ganageo.app.data.SupabaseProvider
import com.ganageo.app.data.PendingToolCompletionStore
import com.ganageo.app.data.BillingEvent
import com.ganageo.app.data.CreditPack
import com.ganageo.app.data.PlayBillingManager
import com.ganageo.app.data.RecentToolsStore
import com.ganageo.app.data.FavoriteToolsStore
import com.ganageo.app.data.RecentFilesTracker
import com.ganageo.app.data.SessionHintStore
import com.ganageo.app.data.UiPrefsStore
import com.ganageo.app.data.YapeRules
import com.ganageo.app.data.TestToolBalance
import com.ganageo.app.data.ToolCreditsStore
import com.ganageo.app.model.DashboardData
import com.ganageo.app.model.GeoGameActivation
import com.ganageo.app.model.GeoGameFinish
import com.ganageo.app.model.GeoGameLifePurchase
import com.ganageo.app.model.GeoGameRunStart
import com.ganageo.app.model.GeoGameStatus
import com.ganageo.app.model.ToolOperationReservation
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.GeoGameRules
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.status.SessionStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import com.android.billingclient.api.Purchase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.UUID

sealed interface AuthPhase {
    data object ConfigurationMissing : AuthPhase
    data object Initializing : AuthPhase
    data object CompletingSignIn : AuthPhase
    data object SignedOut : AuthPhase
    data object Guest : AuthPhase
    data object DeviceConflict : AuthPhase
    data object SignedIn : AuthPhase
}

data class GanaGeoUiState(
    val authPhase: AuthPhase = AuthPhase.Initializing,
    val dashboard: DashboardData? = null,
    val testToolBalance: TestToolBalance = TestToolBalance(),
    val isLoading: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    val deviceConflictMessage: String? = null,
    val canReplaceDevice: Boolean = false,
    val recentToolNames: List<String> = emptyList(),
    val creditPacks: List<CreditPack> = PlayBillingManager.DEFAULT_PACKS,
    val purchaseInProgress: Boolean = false,
    val hideBalances: Boolean = false,
    val loginPromptToolName: String? = null,
    val isOffline: Boolean = false,
    val favoriteToolNames: List<String> = emptyList(),
    /** Herramienta pedida desde un atajo del ícono de la app. */
    val shortcutToolName: String? = null,
    /** 0 = normal, 1 = grande, 2 = muy grande. */
    val textSizeStep: Int = 0,
    /** Pedir calificación en Google Play (una sola vez, en una pausa natural). */
    val reviewPromptRequested: Boolean = false,
    /** Herramientas usadas en los últimos 7 días (para "Tu semana"). */
    val weeklyToolUses: Int = 0,
    /** Presentaciones animadas en Herramientas. */
    val animationsEnabled: Boolean = true
)

data class ToolUseReservation(
    val id: String,
    val cost: Long,
    val isLocalTest: Boolean,
    val localReservation: LocalToolReservation? = null
)

class GanaGeoViewModel(application: Application) : AndroidViewModel(application) {
    private val client = SupabaseProvider.client
    private val repository = client?.let(::GanaGeoRepository)
    private val deviceStore = DeviceIdentityStore(application)
    private val dashboardCacheStore = DashboardCacheStore(application)
    private val toolCreditsStore = ToolCreditsStore(application)
    private val pendingToolCompletionStore = PendingToolCompletionStore(application)
    private val geoGameLocalStore = GeoGameLocalStore(application)
    private val recentToolsStore = RecentToolsStore(application)
    private val favoriteToolsStore = FavoriteToolsStore(application)

    init {
        // Lista de "Tus últimos archivos" (lectura pequeña y local).
        RecentFilesTracker.init(application)
    }
    private val sessionHintStore = SessionHintStore(application)
    private val uiPrefsStore = UiPrefsStore(application)

    // Arranque instantáneo: se decide con datos locales, sin esperar a la red.
    private val startupHint = sessionHintStore.read()
    private val startupInactivityExpired = startupHint.isExpired(System.currentTimeMillis())
    private val startupDashboard: DashboardData? = run {
        val hintUserId = startupHint.userId
        if (client != null && !startupInactivityExpired && hintUserId != null) {
            runCatching { dashboardCacheStore.read(hintUserId) }.getOrNull()
        } else {
            null
        }
    }
    private var pendingInactivitySignOut = startupInactivityExpired

    // Herramienta que el invitado quería abrir: tras iniciar sesión se abre sola.
    private var pendingToolAfterLogin: String? = null

    private val connectivityManager =
        application.getSystemService(android.content.Context.CONNECTIVITY_SERVICE)
            as? android.net.ConnectivityManager
    private val networkCallback = object : android.net.ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: android.net.Network) {
            _uiState.update { it.copy(isOffline = false) }
        }

        override fun onLost(network: android.net.Network) {
            _uiState.update { it.copy(isOffline = !hasInternetNow()) }
        }
    }

    private fun hasInternetNow(): Boolean = runCatching {
        val manager = connectivityManager ?: return true
        val capabilities = manager.getNetworkCapabilities(manager.activeNetwork) ?: return false
        capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }.getOrDefault(true)
    private val billingManager: PlayBillingManager? = runCatching {
        PlayBillingManager(application, ::onBillingEvent)
    }.getOrNull()
    private val verifyingPurchaseTokens = mutableSetOf<String>()

    private var dashboardJob: Job? = null
    private var loadedDashboardUserId: String? = null

    // Navegación temporal conservada fuera de la composición. Android puede
    // pausar o recrear pantallas al abrir galería, cámara o documentos.
    var rememberedMainTab: Int = 0
        private set
    var rememberedToolName: String? = null
        private set
    var rememberedToolsScrollIndex: Int = 0
        private set
    var rememberedToolsScrollOffset: Int = 0
        private set
    var rememberedToolsCategory: String = "Todas"
        private set

    fun rememberToolsCategory(category: String) {
        rememberedToolsCategory = category
    }

    /** Invitado tocó una herramienta con candado: mostrar la hoja para iniciar sesión. */
    fun requestLoginForTool(toolName: String) {
        _uiState.update { it.copy(loginPromptToolName = toolName) }
    }

    fun dismissLoginPrompt() {
        _uiState.update { it.copy(loginPromptToolName = null) }
    }

    /** El invitado aceptó: recordar la herramienta y abrirla al terminar el acceso. */
    fun acceptLoginPrompt() {
        pendingToolAfterLogin = _uiState.value.loginPromptToolName
        _uiState.update { it.copy(loginPromptToolName = null) }
    }

    /** Ocultar/mostrar saldos (como "Mostrar saldo" de Yape). Se recuerda en el celular. */
    fun toggleHideBalances() {
        val hidden = !_uiState.value.hideBalances
        uiPrefsStore.hideBalances = hidden
        _uiState.update { it.copy(hideBalances = hidden) }
    }

    fun rememberMainTab(index: Int) {
        rememberedMainTab = index.coerceIn(0, MAIN_TAB_COUNT - 1)
    }

    fun rememberTool(name: String?) {
        val previous = rememberedToolName
        rememberedToolName = name
        if (!name.isNullOrBlank()) {
            val recents = recentToolsStore.push(name)
            var weekly = _uiState.value.weeklyToolUses
            if (name != ToolId.GEO_ADVENTURES.name) {
                uiPrefsStore.toolOpenCount = uiPrefsStore.toolOpenCount + 1
                weekly = uiPrefsStore.addToolUse()
            }
            _uiState.update { it.copy(recentToolNames = recents, weeklyToolUses = weekly) }
        } else if (previous != null) {
            maybeAskForReview()
        }
    }

    fun setAnimationsEnabled(enabled: Boolean) {
        uiPrefsStore.animationsEnabled = enabled
        _uiState.update { it.copy(animationsEnabled = enabled) }
    }

    fun setTextSize(step: Int) {
        val clean = step.coerceIn(0, 2)
        uiPrefsStore.textSizeStep = clean
        _uiState.update { it.copy(textSizeStep = clean) }
    }

    /** Al volver de una herramienta (pausa natural), tras varios usos. Una sola vez. */
    private fun maybeAskForReview() {
        if (uiPrefsStore.reviewAsked) return
        if (uiPrefsStore.toolOpenCount < REVIEW_AFTER_TOOL_OPENS) return
        uiPrefsStore.reviewAsked = true
        _uiState.update { it.copy(reviewPromptRequested = true) }
    }

    fun consumeReviewPrompt() {
        _uiState.update { it.copy(reviewPromptRequested = false) }
    }

    fun toggleFavoriteTool(name: String) {
        val (favorites, added) = favoriteToolsStore.toggle(name)
        _uiState.update {
            it.copy(
                favoriteToolNames = favorites,
                message = if (added) "Guardada en favoritos" else "Quitada de favoritos"
            )
        }
    }

    /** Atajo del ícono: abre la herramienta (o pide cuenta si es premium e invitado). */
    fun openFromShortcut(toolName: String?) {
        val clean = toolName?.trim()?.takeIf { name -> ToolId.entries.any { it.name == name } } ?: return
        _uiState.update { it.copy(shortcutToolName = clean) }
    }

    fun consumeShortcut() {
        _uiState.update { it.copy(shortcutToolName = null) }
    }

    fun rememberToolsScroll(index: Int, offset: Int) {
        rememberedToolsScrollIndex = index.coerceAtLeast(0)
        rememberedToolsScrollOffset = offset.coerceAtLeast(0)
    }

    private val _uiState = MutableStateFlow(
        GanaGeoUiState(
            authPhase = when {
                !SupabaseProvider.isConfigured -> AuthPhase.ConfigurationMissing
                client == null -> AuthPhase.Guest
                // Con cuenta guardada: Inicio aparece al instante con los últimos datos.
                startupDashboard != null -> AuthPhase.SignedIn
                // Sin cuenta guardada: herramientas gratis al instante, sin pantalla de carga.
                // Si Supabase encuentra una sesión, la app cambia sola a la cuenta.
                else -> AuthPhase.Guest
            },
            dashboard = startupDashboard,
            hideBalances = uiPrefsStore.hideBalances,
            textSizeStep = uiPrefsStore.textSizeStep,
            weeklyToolUses = uiPrefsStore.toolUsesThisWeek(),
            animationsEnabled = uiPrefsStore.animationsEnabled,
            error = if (SupabaseProvider.isConfigured && client == null) {
                "No se pudo iniciar la conexión. Gana Geo abrió en modo invitado para evitar un cierre inesperado."
            } else {
                null
            }
        )
    )
    val uiState: StateFlow<GanaGeoUiState> = _uiState.asStateFlow()

    init {
        _uiState.update { it.copy(recentToolNames = recentToolsStore.read(),
            favoriteToolNames = favoriteToolsStore.read(), isOffline = !hasInternetNow()) }
        runCatching { connectivityManager?.registerDefaultNetworkCallback(networkCallback) }
        // Ninguna lectura local de arranque puede tumbar el proceso. En Debug el saldo
        // de prueba es auxiliar; si su almacenamiento falla se usa saldo cero y la app
        // sigue abierta.
        viewModelScope.launch {
            if (BuildConfig.DEBUG) {
                try {
                    toolCreditsStore.recoverInterruptedReservations()
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Throwable) {
                    // ToolCreditsStore tiene además un corruptionHandler; este catch cubre
                    // I/O y fallos inesperados para que el arranque siempre sea seguro.
                }
            }
            refreshTestToolBalance()
        }

        if (client != null && repository != null) {
            viewModelScope.launch {
                try {
                    client.auth.sessionStatus.collect { status ->
                        when (status) {
                            SessionStatus.Initializing -> {
                                val current = _uiState.value
                                // El selector de archivos y la cámara pausan temporalmente la app.
                                // Supabase puede volver a emitir Initializing al regresar. Si ya hay
                                // un panel autenticado cargado, conservar toda la navegación y el
                                // estado de la herramienta en lugar de desmontar MainShell.
                                if (current.dashboard == null &&
                                    current.authPhase !in setOf(
                                        AuthPhase.CompletingSignIn,
                                        AuthPhase.DeviceConflict,
                                        AuthPhase.SignedIn,
                                        AuthPhase.Guest
                                    )
                                ) {
                                    _uiState.update { it.copy(authPhase = AuthPhase.Initializing) }
                                }
                            }

                            is SessionStatus.Authenticated -> {
                                if (pendingInactivitySignOut) {
                                    pendingInactivitySignOut = false
                                    signOutForInactivity()
                                } else {
                                    markAuthenticatedAndLoad()
                                }
                            }

                            is SessionStatus.NotAuthenticated -> {
                                val state = _uiState.value
                                if (state.authPhase == AuthPhase.Guest) return@collect
                                val preserveError = state.authPhase == AuthPhase.SignedOut &&
                                    !state.error.isNullOrBlank()
                                val stillHasSession = client.auth.currentSessionOrNull() != null
                                if (stillHasSession && state.dashboard != null) {
                                    // Emisión transitoria al volver de una actividad externa.
                                    _uiState.update { it.copy(authPhase = AuthPhase.SignedIn) }
                                } else if (!preserveError && state.authPhase != AuthPhase.CompletingSignIn) {
                                    enterGuestMode()
                                }
                            }

                            is SessionStatus.RefreshFailure -> {
                                if (_uiState.value.authPhase == AuthPhase.Guest) return@collect
                                loadedDashboardUserId = null
                                _uiState.update {
                                    it.copy(
                                        authPhase = AuthPhase.Guest,
                                        dashboard = null,
                                        isLoading = false,
                                        error = "La sesión venció. Puedes seguir como invitado o iniciar sesión nuevamente.",
                                        deviceConflictMessage = null,
                                        canReplaceDevice = false
                                    )
                                }
                            }

                            else -> Unit
                        }
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Throwable) {
                    // Una restauración de Auth dañada o un fallo inesperado de la librería
                    // no debe provocar un crash loop. Se conserva la aplicación utilizable.
                    loadedDashboardUserId = null
                    dashboardJob?.cancel()
                    _uiState.update {
                        it.copy(
                            authPhase = AuthPhase.Guest,
                            dashboard = null,
                            isLoading = false,
                            error = "No se pudo restaurar la sesión. Puedes seguir usando Gana Geo como invitado e iniciar sesión nuevamente.",
                            deviceConflictMessage = null,
                            canReplaceDevice = false
                        )
                    }
                }
            }
        }
    }


    private fun signOutForInactivity() {
        val repo = repository ?: return
        val userId = repo.currentUserId() ?: startupHint.userId
        viewModelScope.launch {
            runCatching { repo.signOut() }
            dashboardCacheStore.clear(userId)
            sessionHintStore.clear()
            loadedDashboardUserId = null
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.Guest,
                    dashboard = null,
                    isLoading = false,
                    message = "Por seguridad cerramos tu sesión: no usaste Gana Geo en 30 días."
                )
            }
        }
    }

    fun enterGuestMode() {
        sessionHintStore.clear()
        dashboardJob?.cancel()
        loadedDashboardUserId = null
        rememberedMainTab = TAB_TOOLS
        rememberedToolName = null
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.Guest,
                dashboard = null,
                isLoading = false,
                message = null,
                error = null,
                deviceConflictMessage = null,
                canReplaceDevice = false
            )
        }
    }

    fun leaveGuestMode() {
        rememberedMainTab = 0
        rememberedToolName = null
        resetToSignedOut()
    }

    fun onNativeGoogleSignInStarted() {
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.CompletingSignIn,
                dashboard = null,
                isLoading = true,
                error = null,
                message = null,
                deviceConflictMessage = null,
                canReplaceDevice = false
            )
        }
    }

    fun onNativeGoogleSignInCancelled() {
        pendingToolAfterLogin = null
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.Guest,
                isLoading = false,
                error = "Cancelaste el inicio de sesión. Puedes seguir como invitado."
            )
        }
    }

    fun onNativeGoogleSignInError(message: String) {
        pendingToolAfterLogin = null
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.Guest,
                dashboard = null,
                isLoading = false,
                error = message
            )
        }
    }

    fun signInWithGoogleIdToken(idToken: String, nonce: String) {
        val repo = repository ?: run {
            onNativeGoogleSignInError("Supabase no está configurado en esta compilación.")
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.CompletingSignIn,
                    isLoading = true,
                    error = null,
                    message = null
                )
            }

            runCatching {
                withTimeout(SIGN_IN_TIMEOUT_MS) {
                    repo.signInWithGoogleIdToken(idToken, nonce)
                }
            }.onSuccess {
                markAuthenticatedAndLoad()
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedOut,
                        dashboard = null,
                        isLoading = false,
                        error = error.userMessage("No se pudo completar el acceso nativo con Google.")
                    )
                }
            }
        }
    }

    fun reconcileSession() {
        val current = _uiState.value
        if (client == null || current.authPhase == AuthPhase.ConfigurationMissing) return
        // No recargar el panel cada vez que la galería, el selector de documentos
        // o la cámara devuelve el control a la app. Esto conserva pestaña,
        // herramienta, desplazamiento y formularios abiertos.
        if (current.authPhase == AuthPhase.SignedIn && current.dashboard != null) return
        // El cierre por 30 días sin uso lo resuelve el observador de sesión.
        if (pendingInactivitySignOut) return

        viewModelScope.launch {
            if (client.auth.currentSessionOrNull() != null &&
                _uiState.value.authPhase != AuthPhase.DeviceConflict
            ) {
                markAuthenticatedAndLoad()
            }
        }
    }

    fun refreshDashboard() {
        refreshDashboardInternal(showLoading = true)
    }

    /**
     * Sincroniza el panel con Supabase. Cuando [showLoading] es false se conserva
     * el dashboard local visible y la actualización ocurre silenciosamente.
     */
    private fun refreshDashboardInternal(showLoading: Boolean) {
        val repo = repository ?: return
        dashboardJob?.cancel()
        dashboardJob = viewModelScope.launch {
            val existingDashboard = _uiState.value.dashboard
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.SignedIn,
                    isLoading = showLoading,
                    error = null,
                    deviceConflictMessage = null,
                    canReplaceDevice = false
                )
            }

            runCatching {
                withTimeout(DASHBOARD_TIMEOUT_MS) {
                    val installationId = deviceStore.getOrCreateInstallationId()
                    repo.loadDashboard(installationId)
                }
            }.onSuccess { dashboard ->
                val userId = repo.currentUserId()
                loadedDashboardUserId = userId
                if (!userId.isNullOrBlank()) {
                    dashboardCacheStore.write(userId, dashboard)
                    sessionHintStore.save(userId)
                }
                val switched = repo.consumeLastLinkSwitched()
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedIn,
                        dashboard = dashboard,
                        isLoading = false,
                        error = null,
                        deviceConflictMessage = null,
                        canReplaceDevice = false,
                        message = if (switched) DEVICE_SWITCHED_MESSAGE else it.message
                    )
                }
                if (dashboard.features.purchasesEnabled) restoreUnfinishedPurchases()
            }.onFailure { error ->
                if (error is CancellationException) return@onFailure
                val conflict = error.deviceConflictInfo()
                if (conflict != null) {
                    val userId = repo.currentUserId() ?: loadedDashboardUserId
                    dashboardCacheStore.clear(userId)
                    loadedDashboardUserId = null
                    _uiState.update {
                        it.copy(
                            authPhase = AuthPhase.DeviceConflict,
                            dashboard = null,
                            isLoading = false,
                            error = null,
                            deviceConflictMessage = conflict.message,
                            canReplaceDevice = conflict.canReplace
                        )
                    }
                } else if (existingDashboard != null) {
                    // Una caída de red no desmonta Inicio ni vuelve a mostrar
                    // "Cargando tu cuenta". El último panel válido sigue visible.
                    _uiState.update {
                        it.copy(
                            authPhase = AuthPhase.SignedIn,
                            dashboard = existingDashboard,
                            isLoading = false,
                            error = if (showLoading) {
                                error.userMessage("No se pudieron actualizar tus datos.")
                            } else {
                                null
                            }
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            authPhase = AuthPhase.SignedIn,
                            dashboard = null,
                            isLoading = false,
                            error = error.userMessage("No se pudieron cargar tus datos.")
                        )
                    }
                }
            }
        }
    }

    fun replacePreviousInstallation() {
        val repo = repository ?: return
        if (!_uiState.value.canReplaceDevice) return

        // Usa el mismo Job del panel para evitar dos autorizaciones simultáneas.
        dashboardJob?.cancel()
        dashboardJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.DeviceConflict,
                    dashboard = null,
                    isLoading = true,
                    error = null,
                    message = null
                )
            }

            runCatching {
                withTimeout(DASHBOARD_TIMEOUT_MS) {
                    val installationId = deviceStore.getOrCreateInstallationId()

                    // El servidor reemplaza la instalación anterior y activa esta.
                    repo.replaceMyDevice(installationId)

                    // La validación y la carga se completan antes de cambiar de pantalla.
                    repo.loadDashboard(installationId)
                }
            }.onSuccess { dashboard ->
                val userId = repo.currentUserId()
                loadedDashboardUserId = userId
                if (!userId.isNullOrBlank()) {
                    dashboardCacheStore.write(userId, dashboard)
                    sessionHintStore.save(userId)
                }
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.SignedIn,
                        dashboard = dashboard,
                        isLoading = false,
                        error = null,
                        deviceConflictMessage = null,
                        canReplaceDevice = false,
                        message = DEVICE_SWITCHED_MESSAGE
                    )
                }
            }.onFailure { error ->
                val conflict = error.deviceConflictInfo()
                _uiState.update {
                    it.copy(
                        authPhase = AuthPhase.DeviceConflict,
                        dashboard = null,
                        isLoading = false,
                        error = error.userMessage(
                            "No se pudo autorizar esta instalación. Comprueba la conexión y vuelve a intentarlo."
                        ),
                        deviceConflictMessage = conflict?.message
                            ?: it.deviceConflictMessage,
                        canReplaceDevice = conflict?.canReplace
                            ?: it.canReplaceDevice
                    )
                }
            }
        }
    }

    fun hasEnoughToolCredits(cost: Long): Boolean {
        if (cost <= 0) return true
        val serverCredits = _uiState.value.dashboard?.toolCredits?.availableCredits ?: 0
        val testCredits = if (BuildConfig.DEBUG) _uiState.value.testToolBalance.availableCredits else 0
        return serverCredits >= cost || testCredits >= cost
    }

    fun addTestToolCredits(amount: Long) {
        if (!BuildConfig.DEBUG) return
        viewModelScope.launch {
            runCatching { toolCreditsStore.addTestCredits(amount) }
                .onSuccess {
                    refreshTestToolBalance()
                    _uiState.update {
                        it.copy(message = "Se agregaron $amount créditos de prueba. No tienen valor real.")
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(error = error.userMessage("No se pudieron agregar créditos de prueba."))
                    }
                }
        }
    }

    suspend fun reserveToolUse(toolCode: String, cost: Long): Result<ToolUseReservation> {
        if (cost <= 0) {
            return Result.success(
                ToolUseReservation(UUID.randomUUID().toString(), 0, isLocalTest = true)
            )
        }

        val serverAvailable = _uiState.value.dashboard?.toolCredits?.availableCredits ?: 0
        val repo = repository
        if (serverAvailable >= cost && repo != null) {
            return runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                val requestId = UUID.randomUUID().toString()
                val reservation: ToolOperationReservation = repo.beginToolOperation(
                    toolCode = toolCode,
                    creditCost = cost,
                    installationId = installationId,
                    requestId = requestId
                )
                refreshDashboard()
                ToolUseReservation(
                    id = reservation.operationId,
                    cost = reservation.reservedCredits,
                    isLocalTest = false
                )
            }
        }

        if (BuildConfig.DEBUG) {
            return runCatching {
                val local = toolCreditsStore.reserve(cost)
                refreshTestToolBalance()
                ToolUseReservation(
                    id = local.id,
                    cost = local.cost,
                    isLocalTest = true,
                    localReservation = local
                )
            }
        }

        return Result.failure(IllegalStateException("No tienes créditos suficientes."))
    }

    suspend fun completeToolUse(reservation: ToolUseReservation): Result<Long> {
        if (reservation.cost == 0L) return Result.success(0)
        return if (reservation.isLocalTest) {
            val local = reservation.localReservation
                ?: return Result.failure(IllegalStateException("Reserva local inválida."))
            runCatching { toolCreditsStore.complete(local) }
                .onSuccess { refreshTestToolBalance() }
        } else {
            val repo = repository
                ?: return Result.failure(IllegalStateException("Servidor no disponible."))
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.completeToolOperation(reservation.id, installationId).awardedPoints
            }.onSuccess {
                repository?.currentUserId()?.let { pendingToolCompletionStore.remove(it, reservation.id) }
                refreshDashboard()
            }
        }
    }

    suspend fun cancelToolUse(reservation: ToolUseReservation) {
        if (reservation.cost == 0L) return
        if (reservation.isLocalTest) {
            reservation.localReservation?.let { toolCreditsStore.cancel(it) }
            refreshTestToolBalance()
        } else {
            val installationId = deviceStore.getOrCreateInstallationId()
            repository?.cancelToolOperation(reservation.id, installationId)
            repository?.currentUserId()?.let { pendingToolCompletionStore.remove(it, reservation.id) }
            refreshDashboard()
        }
    }


    suspend fun rememberPendingToolCompletion(operationId: String) {
        val userId = repository?.currentUserId() ?: return
        pendingToolCompletionStore.add(userId, operationId)
    }

    fun retryPendingToolCompletions() {
        val repo = repository ?: return
        val userId = repo.currentUserId() ?: return
        viewModelScope.launch {
            try {
                val operationIds = pendingToolCompletionStore.readAll(userId)
                if (operationIds.isEmpty()) return@launch
                val installationId = deviceStore.getOrCreateInstallationId()
                var completedAny = false
                operationIds.forEach { operationId ->
                    runCatching { repo.completeToolOperation(operationId, installationId) }
                        .onSuccess {
                            pendingToolCompletionStore.remove(userId, operationId)
                            completedAny = true
                        }
                }
                if (completedAny) refreshDashboard()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                // Las operaciones pendientes se volverán a intentar más adelante. Un fallo
                // local/remoto aquí nunca debe cerrar la pantalla principal.
            }
        }
    }

    suspend fun loadGeoGameStatus(preferLocalTest: Boolean = false): Result<GeoGameStatus> {
        if (preferLocalTest) {
            return runCatching { geoGameLocalStore.status() }
        }

        val repo = repository
        if (repo != null && _uiState.value.dashboard != null) {
            val server = runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.getGeoGameStatus(installationId)
            }
            if (server.isSuccess) return server
            if (!BuildConfig.DEBUG) return server
        }

        return if (BuildConfig.DEBUG) {
            runCatching { geoGameLocalStore.status() }
        } else {
            Result.failure(IllegalStateException("Geo Aventuras necesita conexión con Supabase."))
        }
    }

    suspend fun buyGeoGameLives(packageCode: String): Result<GeoGameLifePurchase> {
        val packageInfo = GeoGameRules.packageByCode(packageCode)
            ?: return Result.failure(IllegalArgumentException("Paquete de vidas no válido."))
        val realAvailable = _uiState.value.dashboard?.toolCredits?.availableCredits ?: 0
        val repo = repository

        if (repo != null && realAvailable >= packageInfo.creditCost) {
            return runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.buyGeoGameLives(packageCode, installationId, UUID.randomUUID().toString())
            }.onSuccess { refreshDashboard() }
        }

        if (BuildConfig.DEBUG && _uiState.value.testToolBalance.availableCredits >= packageInfo.creditCost) {
            return runCatching {
                toolCreditsStore.spendForGameLives(packageInfo.creditCost.toLong())
                geoGameLocalStore.addPremiumLives(packageInfo.lives)
                refreshTestToolBalance()
                val status = geoGameLocalStore.status()
                GeoGameLifePurchase(
                    livesAdded = packageInfo.lives,
                    creditsSpent = packageInfo.creditCost,
                    remainingCredits = _uiState.value.testToolBalance.availableCredits,
                    premiumLives = status.premiumLives,
                    isLocalTest = true
                )
            }
        }

        return Result.failure(IllegalStateException("No tienes créditos suficientes para comprar vidas."))
    }

    suspend fun startGeoGameRun(
        level: Int,
        lifeType: String,
        localTest: Boolean
    ): Result<GeoGameRunStart> {
        return if (localTest) {
            runCatching { geoGameLocalStore.start(level, lifeType) }
        } else {
            val repo = repository ?: return Result.failure(IllegalStateException("Servidor no disponible."))
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.startGeoGameRun(level, lifeType, installationId, UUID.randomUUID().toString())
            }
        }
    }

    suspend fun activateGeoGameRun(run: GeoGameRunStart): Result<GeoGameActivation> {
        return if (run.isLocalTest) {
            runCatching {
                val newlyActivated = geoGameLocalStore.activate(run.runId)
                val awarded = if (newlyActivated) toolCreditsStore.rewardUsedGameLife(GeoGameRules.PREMIUM_LIFE_CREDIT_COST.toLong()) else 0
                refreshTestToolBalance()
                val status = geoGameLocalStore.status()
                GeoGameActivation(
                    awardedPoints = awarded,
                    premiumLivesRemaining = status.premiumLives,
                    premiumUsedToday = status.premiumUsedToday,
                    isLocalTest = true
                )
            }
        } else {
            val repo = repository ?: return Result.failure(IllegalStateException("Servidor no disponible."))
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.activateGeoGameRun(run.runId, installationId)
            }.onSuccess { refreshDashboard() }
        }
    }

    suspend fun finishGeoGameRun(
        run: GeoGameRunStart,
        won: Boolean,
        stars: Int,
        score: Long,
        timeMs: Long
    ): Result<GeoGameFinish> {
        return if (run.isLocalTest) {
            runCatching { geoGameLocalStore.finish(run.runId, won, stars, score) }
        } else {
            val repo = repository ?: return Result.failure(IllegalStateException("Servidor no disponible."))
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.finishGeoGameRun(
                    runId = run.runId,
                    won = won,
                    stars = stars,
                    score = score,
                    timeMs = timeMs,
                    installationId = installationId
                )
            }
        }
    }

    suspend fun cancelGeoGameRun(run: GeoGameRunStart) {
        if (run.isLocalTest) {
            geoGameLocalStore.cancel(run.runId)
        } else {
            val installationId = deviceStore.getOrCreateInstallationId()
            repository?.cancelGeoGameRun(run.runId, installationId)
        }
    }

    private suspend fun refreshTestToolBalance() {
        if (!BuildConfig.DEBUG) return
        val balance = try {
            toolCreditsStore.readBalance()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Throwable) {
            TestToolBalance()
        }
        _uiState.update { it.copy(testToolBalance = balance) }
    }

    fun requestWithdrawal(amountText: String, method: String, destination: String) {
        val repo = repository ?: return
        val amount = amountText.replace(',', '.').toDoubleOrNull()
        val available = _uiState.value.dashboard?.wallet?.availableAmount ?: 0.0

        when {
            amount == null || amount < 5.0 -> {
                _uiState.update { it.copy(error = "El retiro mínimo es S/5.") }
                return
            }

            amount > available -> {
                _uiState.update { it.copy(error = "No tienes saldo disponible suficiente.") }
                return
            }

            !isValidYapePhone(destination) -> {
                _uiState.update { it.copy(error = "Escribe tu número de Yape: 9 dígitos y empieza con 9.") }
                return
            }

            _uiState.value.dashboard?.features?.withdrawalsEnabled != true -> {
                _uiState.update { it.copy(error = "Los retiros por Yape todavía no están habilitados.") }
                return
            }
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.requestWithdrawal(amount, "yape", destination, installationId)
            }.onSuccess {
                _uiState.update {
                    it.copy(
                        message = "Solicitud registrada. El saldo quedó bloqueado hasta su revisión.",
                        isLoading = false
                    )
                }
                refreshDashboard()
            }.onFailure { error ->
                handleSensitiveOperationFailure(
                    error = error,
                    fallback = "No se pudo registrar el retiro."
                )
            }
        }
    }

    fun cancelWithdrawal(withdrawalId: String) {
        val repo = repository ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching {
                val installationId = deviceStore.getOrCreateInstallationId()
                repo.cancelWithdrawal(withdrawalId, installationId)
            }.onSuccess {
                _uiState.update {
                    it.copy(message = "Solicitud cancelada y saldo liberado.", isLoading = false)
                }
                refreshDashboard()
            }.onFailure { error ->
                handleSensitiveOperationFailure(error, "No se pudo cancelar la solicitud.")
            }
        }
    }

    private fun handleSensitiveOperationFailure(error: Throwable, fallback: String) {
        val conflict = error.deviceConflictInfo()
        if (conflict != null) {
            loadedDashboardUserId = null
            dashboardJob?.cancel()
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.DeviceConflict,
                    dashboard = null,
                    isLoading = false,
                    error = null,
                    deviceConflictMessage = conflict.message,
                    canReplaceDevice = conflict.canReplace
                )
            }
        } else {
            _uiState.update {
                it.copy(isLoading = false, error = error.userMessage(fallback))
            }
        }
    }

    /**
     * Elimina la cuenta desde la app (requisito de Google Play). El servidor borra la
     * cuenta y sus datos; solo conserva un registro mínimo sin datos personales.
     */
    fun deleteAccount() {
        val repo = repository ?: return
        val userId = repo.currentUserId() ?: loadedDashboardUserId
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching {
                withTimeout(DASHBOARD_TIMEOUT_MS) { repo.deleteMyAccount() }
            }.onSuccess {
                runCatching { repo.signOut() }
                dashboardCacheStore.clear(userId)
                sessionHintStore.clear()
                pendingToolCompletionStoreClear(userId)
                recentToolsStore.clear()
                favoriteToolsStore.clear()
                RecentFilesTracker.clear()
                loadedDashboardUserId = null
                dashboardJob?.cancel()
                resetToSignedOut()
                enterGuestMode()
                _uiState.update { it.copy(message = "Tu cuenta fue eliminada. Puedes seguir usando las herramientas gratis.") }
            }.onFailure { error ->
                val raw = error.message.orEmpty()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = if (raw.contains("open withdrawal", ignoreCase = true)) {
                            "Primero cancela tu solicitud de retiro abierta."
                        } else {
                            error.userMessage("No se pudo eliminar la cuenta.")
                        }
                    )
                }
            }
        }
    }

    private suspend fun pendingToolCompletionStoreClear(userId: String?) {
        if (userId.isNullOrBlank()) return
        runCatching {
            pendingToolCompletionStore.readAll(userId).forEach { pendingToolCompletionStore.remove(userId, it) }
        }
    }

    // ---------------------------------------------------------------
    // Google Play Billing
    // ---------------------------------------------------------------

    fun loadCreditPacks() {
        val manager = billingManager ?: return
        viewModelScope.launch {
            val packs = runCatching { manager.loadPacks() }.getOrDefault(PlayBillingManager.DEFAULT_PACKS)
            _uiState.update { it.copy(creditPacks = packs) }
        }
    }

    fun buyCreditPack(activity: Activity, productId: String) {
        val manager = billingManager
        val repo = repository
        val userId = repo?.currentUserId()
        val features = _uiState.value.dashboard?.features
        when {
            manager == null || repo == null || userId.isNullOrBlank() -> {
                _uiState.update { it.copy(error = "Inicia sesión para comprar créditos.") }
                return
            }
            features?.purchasesEnabled != true -> {
                _uiState.update { it.copy(error = "Las compras con Google Play estarán disponibles pronto.") }
                return
            }
            _uiState.value.purchaseInProgress -> return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(purchaseInProgress = true, error = null, message = null) }
            manager!!.launchPurchase(activity, productId, userId!!)
                .onFailure { error ->
                    _uiState.update {
                        it.copy(purchaseInProgress = false, error = error.message ?: "No se pudo abrir Google Play.")
                    }
                }
        }
    }

    private fun onBillingEvent(event: BillingEvent) {
        when (event) {
            is BillingEvent.Purchased -> verifyAndConsume(event.purchase)
            is BillingEvent.Pending -> _uiState.update {
                it.copy(
                    purchaseInProgress = false,
                    message = "Pago pendiente. Los créditos se sumarán cuando Google Play lo confirme."
                )
            }
            BillingEvent.Cancelled -> _uiState.update {
                it.copy(purchaseInProgress = false, message = "Compra cancelada. No se cobró nada.")
            }
            is BillingEvent.Failed -> {
                _uiState.update { it.copy(purchaseInProgress = false, error = event.message) }
                restoreUnfinishedPurchases()
            }
        }
    }

    private fun restoreUnfinishedPurchases() {
        val manager = billingManager ?: return
        viewModelScope.launch {
            runCatching { manager.unfinishedPurchases() }
                .getOrDefault(emptyList())
                .forEach(::verifyAndConsume)
        }
    }

    private fun verifyAndConsume(purchase: Purchase) {
        val repo = repository ?: return
        val manager = billingManager ?: return
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return
        val token = purchase.purchaseToken
        val productId = purchase.products.firstOrNull() ?: return
        synchronized(verifyingPurchaseTokens) {
            if (!verifyingPurchaseTokens.add(token)) return
        }
        viewModelScope.launch {
            try {
                val result = withTimeout(DASHBOARD_TIMEOUT_MS) {
                    repo.verifyPlayPurchase(productId, token, purchase.orderId)
                }
                // Solo después de que el servidor acreditó se consume la compra.
                manager.consume(token)
                _uiState.update {
                    it.copy(
                        purchaseInProgress = false,
                        message = if (result.alreadyProcessed) {
                            "Compra ya acreditada anteriormente."
                        } else {
                            "¡Listo! Se sumaron ${result.creditsGranted} créditos."
                        }
                    )
                }
                refreshDashboardInternal(showLoading = false)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                _uiState.update {
                    it.copy(
                        purchaseInProgress = false,
                        error = "Tu pago está a salvo. Se volverá a verificar al abrir la app. " +
                            (error.message?.take(120) ?: "")
                    )
                }
            } finally {
                synchronized(verifyingPurchaseTokens) { verifyingPurchaseTokens.remove(token) }
            }
        }
    }

    override fun onCleared() {
        runCatching { connectivityManager?.unregisterNetworkCallback(networkCallback) }
        billingManager?.close()
        super.onCleared()
    }

    fun signOut() {
        val repo = repository ?: return
        val signedOutUserId = repo.currentUserId() ?: loadedDashboardUserId
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            runCatching { repo.signOut() }
                .onSuccess {
                    sessionHintStore.clear()
                    dashboardCacheStore.clear(signedOutUserId)
                    loadedDashboardUserId = null
                    dashboardJob?.cancel()
                    resetToSignedOut()
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = error.userMessage("No se pudo cerrar la sesión.")
                        )
                    }
                }
        }
    }

    fun clearNotice() {
        _uiState.update { it.copy(message = null, error = null) }
    }

    private fun markAuthenticatedAndLoad() {
        val repo = repository ?: return
        pendingToolAfterLogin?.let { toolName ->
            pendingToolAfterLogin = null
            rememberedMainTab = TAB_TOOLS
            rememberTool(toolName)
        }
        val userId = repo.currentUserId()
        if (userId.isNullOrBlank()) {
            _uiState.update {
                it.copy(authPhase = AuthPhase.CompletingSignIn, isLoading = true)
            }
            return
        }

        if (_uiState.value.authPhase == AuthPhase.DeviceConflict) return

        val current = _uiState.value
        if (loadedDashboardUserId == userId && current.dashboard != null) {
            _uiState.update {
                it.copy(authPhase = AuthPhase.SignedIn, isLoading = false, error = null)
            }
            return
        }

        // El evento de sesión y el resultado del selector de Google pueden llegar
        // casi al mismo tiempo. No inicies una segunda carga para el mismo usuario.
        if (dashboardJob?.isActive == true && current.authPhase == AuthPhase.SignedIn) return

        val cachedDashboard = dashboardCacheStore.read(userId)
        if (cachedDashboard != null) {
            sessionHintStore.save(userId)
            // La sesión local ya identifica al usuario: mostrar Inicio de inmediato.
            // La validación del dispositivo y los datos nuevos llegan después desde
            // Supabase, sin bloquear la interfaz.
            loadedDashboardUserId = userId
            _uiState.update {
                it.copy(
                    authPhase = AuthPhase.SignedIn,
                    dashboard = cachedDashboard,
                    isLoading = false,
                    error = null,
                    deviceConflictMessage = null,
                    canReplaceDevice = false
                )
            }
            refreshDashboardInternal(showLoading = false)
            return
        }

        // Primera entrada de este usuario en el dispositivo: todavía no existe un
        // panel local y sí es necesario esperar la primera descarga.
        _uiState.update {
            it.copy(
                authPhase = AuthPhase.SignedIn,
                dashboard = null,
                isLoading = true,
                error = null
            )
        }
        refreshDashboardInternal(showLoading = true)
    }

    private fun resetToSignedOut() {
        loadedDashboardUserId = null
        dashboardJob?.cancel()
        rememberedMainTab = 0
        rememberedToolName = null
        rememberedToolsScrollIndex = 0
        rememberedToolsScrollOffset = 0
        sessionHintStore.clear()
        rememberedToolsCategory = "Todas"
        // Directo a invitado: sin pantalla intermedia de "Abriendo como invitado".
        _uiState.value = GanaGeoUiState(
            authPhase = AuthPhase.Guest,
            recentToolNames = recentToolsStore.read(),
            favoriteToolNames = favoriteToolsStore.read(),
            hideBalances = uiPrefsStore.hideBalances,
            textSizeStep = uiPrefsStore.textSizeStep,
            weeklyToolUses = uiPrefsStore.toolUsesThisWeek(),
            animationsEnabled = uiPrefsStore.animationsEnabled
        )
    }

    private data class DeviceConflictInfo(
        val message: String,
        val canReplace: Boolean
    )

    private fun Throwable.deviceConflictInfo(): DeviceConflictInfo? {
        val raw = message.orEmpty()
        return when {
            raw.contains("account is already linked to another active device", ignoreCase = true) ->
                DeviceConflictInfo(
                    message = "Tu cuenta sigue vinculada a una instalación anterior. Puede ser una reinstalación o un cambio de teléfono.",
                    canReplace = true
                )

            raw.contains("device is already linked to another account", ignoreCase = true) ->
                DeviceConflictInfo(
                    message = "Esta instalación ya está vinculada a otra cuenta. Cierra sesión y entra con esa cuenta, o solicita ayuda para liberarla.",
                    canReplace = false
                )

            raw.contains("installation was replaced by another device", ignoreCase = true) ||
                raw.contains("installation is not active", ignoreCase = true) ->
                DeviceConflictInfo(
                    message = "Tu cuenta se abrió en otro celular. Si fuiste tú y quieres usarla aquí, toca \"Usar mi cuenta aquí\".",
                    canReplace = true
                )

            raw.contains("Device change limit reached", ignoreCase = true) ->
                DeviceConflictInfo(
                    message = "Ya cambiaste de celular 3 veces este mes. Para usar tu cuenta aquí, escríbenos a soporte.",
                    canReplace = false
                )

            else -> null
        }
    }

    private fun Throwable.userMessage(fallback: String): String {
        if (this is TimeoutCancellationException) {
            return "$fallback La conexión está lenta. Vuelve a intentarlo."
        }

        val raw = message.orEmpty()
        val isNetwork = this is java.io.IOException ||
            cause is java.io.IOException ||
            listOf(
                "Unable to resolve host", "UnknownHost", "failed to connect",
                "timeout", "timed out", "Connection reset", "No address associated",
                "network is unreachable", "SocketException"
            ).any { raw.contains(it, ignoreCase = true) }
        if (isNetwork || _uiState.value.isOffline) {
            return "Sin internet. Revisa tu conexión y vuelve a intentar."
        }

        return when {
            raw.contains("paused after a device change", ignoreCase = true) ->
                "Por seguridad, los retiros a Yape se activan 24 horas después de cambiar de celular."

            raw.contains("Device change limit reached", ignoreCase = true) ->
                "Ya cambiaste de celular 3 veces este mes. Escríbenos a soporte."

            raw.contains("account is not active", ignoreCase = true) ->
                "Tu cuenta no está activa. Escríbenos a soporte."

            raw.contains("insufficient", ignoreCase = true) ->
                "No tienes saldo o créditos suficientes."

            raw.contains("JWT", ignoreCase = true) && raw.contains("expired", ignoreCase = true) ->
                "Tu sesión venció. Vuelve a iniciar sesión."

            raw.contains("PGRST202", ignoreCase = true) ||
                (raw.contains("function", ignoreCase = true) &&
                    raw.contains("not", ignoreCase = true)) ->
                "$fallback Esta opción aún no está lista. Actualiza la app."

            raw.contains("Nonces mismatch", ignoreCase = true) ->
                "$fallback Actualiza Gana Geo a la última versión."

            raw.isNotBlank() -> {
                val concise = raw
                    .substringBefore("\nURL:")
                    .substringBefore(" URL:")
                    .substringBefore("\nHeaders:")
                    .substringBefore(" Headers:")
                    .trim()
                // Solo mostramos mensajes cortos y legibles; lo técnico se oculta.
                val looksTechnical = concise.isBlank() || concise.length > 120 ||
                    listOf("http", "{", "Exception", "PGRST", "SQL", "null", "status").any {
                        concise.contains(it, ignoreCase = true)
                    }
                if (looksTechnical) "$fallback Inténtalo de nuevo." else "$fallback $concise"
            }

            else -> "$fallback Inténtalo de nuevo."
        }
    }

    companion object {
        private const val SIGN_IN_TIMEOUT_MS = 25_000L
        private const val DASHBOARD_TIMEOUT_MS = 20_000L
        const val MAIN_TAB_COUNT = 3
        private const val REVIEW_AFTER_TOOL_OPENS = 12
        private const val DEVICE_SWITCHED_MESSAGE =
            "Tu cuenta ahora está en este celular. Los retiros a Yape se activan en 24 horas."
        // Inicio se quitó: Herramientas es la pantalla principal.
        const val TAB_TOOLS = 0
        const val TAB_WALLET = 1
        const val TAB_PROFILE = 2

        /** Celular peruano para Yape: 9 dígitos que empiezan con 9 (acepta +51). */
        fun isValidYapePhone(raw: String): Boolean = YapeRules.isValidPhone(raw)
    }
}
