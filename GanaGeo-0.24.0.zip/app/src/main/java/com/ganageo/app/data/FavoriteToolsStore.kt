package com.ganageo.app.data

import android.content.Context

/**
 * Herramientas marcadas como favoritas en este celular (pulsación larga).
 * Solo guarda nombres internos; nada de archivos ni datos personales.
 */
class FavoriteToolsStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    fun read(): List<String> = runCatching {
        preferences.getString(KEY_FAVORITES, null)
            ?.split(SEPARATOR)
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?.distinct()
            ?.take(MAX_FAVORITES)
            .orEmpty()
    }.getOrDefault(emptyList())

    /** Agrega o quita. Devuelve la lista nueva y si quedó como favorita. */
    fun toggle(toolName: String): Pair<List<String>, Boolean> {
        val clean = toolName.trim()
        val current = read()
        if (clean.isEmpty()) return current to false
        val added = clean !in current
        val updated = if (added) {
            (current + clean).takeLast(MAX_FAVORITES)
        } else {
            current.filterNot { it == clean }
        }
        runCatching {
            preferences.edit().putString(KEY_FAVORITES, updated.joinToString(SEPARATOR)).apply()
        }
        return updated to added
    }

    fun clear() {
        runCatching { preferences.edit().remove(KEY_FAVORITES).apply() }
    }

    private companion object {
        const val PREFS_NAME = "gana_geo_favorite_tools"
        const val KEY_FAVORITES = "favorite_tool_names"
        const val SEPARATOR = ","
        const val MAX_FAVORITES = 12
    }
}
