package com.ganageo.app.data

import android.content.Context

/** Preferencias visuales del usuario en este celular (no se envían al servidor). */
class UiPrefsStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        "gana_geo_ui_prefs",
        Context.MODE_PRIVATE
    )

    var hideBalances: Boolean
        get() = runCatching { preferences.getBoolean(KEY_HIDE_BALANCES, false) }.getOrDefault(false)
        set(value) {
            runCatching { preferences.edit().putBoolean(KEY_HIDE_BALANCES, value).apply() }
        }

    /** 0 = normal, 1 = grande, 2 = muy grande. */
    var textSizeStep: Int
        get() = runCatching { preferences.getInt(KEY_TEXT_SIZE, 0) }.getOrDefault(0).coerceIn(0, 2)
        set(value) {
            runCatching { preferences.edit().putInt(KEY_TEXT_SIZE, value.coerceIn(0, 2)).apply() }
        }

    var toolOpenCount: Int
        get() = runCatching { preferences.getInt(KEY_TOOL_OPENS, 0) }.getOrDefault(0)
        set(value) {
            runCatching { preferences.edit().putInt(KEY_TOOL_OPENS, value).apply() }
        }

    /** Presentaciones animadas de las herramientas (se pueden apagar en Perfil). */
    var animationsEnabled: Boolean
        get() = runCatching { preferences.getBoolean(KEY_ANIMATIONS, true) }.getOrDefault(true)
        set(value) {
            runCatching { preferences.edit().putBoolean(KEY_ANIMATIONS, value).apply() }
        }

    var reviewAsked: Boolean
        get() = runCatching { preferences.getBoolean(KEY_REVIEW_ASKED, false) }.getOrDefault(false)
        set(value) {
            runCatching { preferences.edit().putBoolean(KEY_REVIEW_ASKED, value).apply() }
        }

    /** Usos de herramientas en los últimos 7 días (se guarda solo la hora). */
    fun addToolUse(nowMs: Long = System.currentTimeMillis()): Int {
        val kept = readToolUses().filter { nowMs - it in 0..WEEK_MS }.takeLast(400) + nowMs
        runCatching { preferences.edit().putString(KEY_TOOL_USES, kept.joinToString(",")).apply() }
        return kept.size
    }

    fun toolUsesThisWeek(nowMs: Long = System.currentTimeMillis()): Int =
        readToolUses().count { nowMs - it in 0..WEEK_MS }

    private fun readToolUses(): List<Long> = runCatching {
        preferences.getString(KEY_TOOL_USES, null)
            ?.split(',')
            ?.mapNotNull { it.trim().toLongOrNull() }
            .orEmpty()
    }.getOrDefault(emptyList())

    private companion object {
        const val WEEK_MS = 7L * 24 * 60 * 60 * 1000
        const val KEY_TOOL_USES = "tool_use_times"
        const val KEY_ANIMATIONS = "tool_animations"
        const val KEY_HIDE_BALANCES = "hide_balances"
        const val KEY_TEXT_SIZE = "text_size_step"
        const val KEY_TOOL_OPENS = "tool_open_count"
        const val KEY_REVIEW_ASKED = "review_asked"
    }
}
