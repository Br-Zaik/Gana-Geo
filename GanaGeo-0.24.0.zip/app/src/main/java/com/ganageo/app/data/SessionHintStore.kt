package com.ganageo.app.data

import android.content.Context

/**
 * Pista local para abrir la app al instante: recuerda qué cuenta estaba abierta y
 * cuándo se usó por última vez. No guarda tokens ni contraseñas (eso lo maneja
 * Supabase de forma segura). Sirve para:
 * - Invitado: entrar directo sin pantalla de carga.
 * - Con cuenta: mostrar Inicio con los datos guardados mientras se actualiza.
 * - Cerrar la sesión sola después de [INACTIVITY_LIMIT_MS] sin abrir la app.
 */
class SessionHintStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    data class Hint(val userId: String?, val lastActiveMs: Long) {
        fun isExpired(nowMs: Long): Boolean =
            userId != null && lastActiveMs > 0 && nowMs - lastActiveMs > INACTIVITY_LIMIT_MS
    }

    fun read(): Hint = runCatching {
        Hint(
            userId = preferences.getString(KEY_USER, null)?.takeIf { it.isNotBlank() },
            lastActiveMs = preferences.getLong(KEY_LAST_ACTIVE, 0L)
        )
    }.getOrDefault(Hint(null, 0L))

    fun save(userId: String, nowMs: Long = System.currentTimeMillis()) {
        runCatching {
            preferences.edit()
                .putString(KEY_USER, userId)
                .putLong(KEY_LAST_ACTIVE, nowMs)
                .apply()
        }
    }

    fun clear() {
        runCatching { preferences.edit().clear().apply() }
    }

    companion object {
        private const val PREFS_NAME = "gana_geo_session_hint"
        private const val KEY_USER = "last_user_id"
        private const val KEY_LAST_ACTIVE = "last_active_ms"
        /** 30 días sin abrir la app cierran la sesión por seguridad. */
        const val INACTIVITY_LIMIT_MS = 30L * 24 * 60 * 60 * 1000
    }
}
