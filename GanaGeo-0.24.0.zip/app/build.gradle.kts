import java.io.File
import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

val localProperties = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) file.inputStream().use(::load)
}

fun quoted(value: String): String = "\"${value.replace("\\", "\\\\").replace("\"", "\\\"")}\""

fun configValue(name: String, defaultValue: String = ""): String {
    val fromFile = localProperties.getProperty(name)?.trim().orEmpty()
    if (fromFile.isNotBlank()) return fromFile

    return System.getenv(name)?.trim()?.takeIf { it.isNotBlank() } ?: defaultValue
}

val supabaseUrl = configValue(
    name = "SUPABASE_URL",
    defaultValue = "https://pnbpeehcbqkdhjueyldn.supabase.co"
)
val supabaseAnonKey = configValue("SUPABASE_ANON_KEY")
val googleWebClientId = configValue("GOOGLE_WEB_CLIENT_ID")
// Correo público de soporte (el mismo de la ficha de Play Console). Opcional.
val supportEmail = configValue("SUPPORT_EMAIL")

val debugKeystorePath = configValue(
    name = "ANDROID_DEBUG_KEYSTORE",
    defaultValue = File(System.getProperty("user.home"), ".android/debug.keystore").absolutePath
)
if (System.getenv("GITHUB_ACTIONS") == "true" &&
    System.getenv("ANDROID_DEBUG_KEYSTORE").isNullOrBlank() &&
    gradle.startParameter.taskNames.any { it.contains("Debug", ignoreCase = true) }) {
    throw GradleException("Compilacion Debug en GitHub sin firma privada. Configura ANDROID_DEBUG_KEYSTORE_BASE64 y usa el workflow oficial.")
}

val debugKeystorePassword = configValue("ANDROID_DEBUG_STORE_PASSWORD", "android")
val debugKeyAlias = configValue("ANDROID_DEBUG_KEY_ALIAS", "androiddebugkey")
val debugKeyPassword = configValue("ANDROID_DEBUG_KEY_PASSWORD", "android")

// Firma de publicación (Play Console). Solo existe si GitHub Actions recibe los
// secretos; nunca se guardan claves en el repositorio ni dentro del APK.
val releaseKeystorePath = configValue("ANDROID_RELEASE_KEYSTORE")
val releaseStorePassword = configValue("ANDROID_RELEASE_STORE_PASSWORD")
val releaseKeyAlias = configValue("ANDROID_RELEASE_KEY_ALIAS")
val releaseKeyPassword = configValue("ANDROID_RELEASE_KEY_PASSWORD")
val hasReleaseSigning = releaseKeystorePath.isNotBlank() &&
    File(releaseKeystorePath).exists() &&
    releaseStorePassword.isNotBlank() &&
    releaseKeyAlias.isNotBlank() &&
    releaseKeyPassword.isNotBlank()

if (supabaseAnonKey.isBlank()) {
    throw GradleException(
        "Falta SUPABASE_ANON_KEY. Crea el secreto de GitHub con ese nombre exacto " +
            "y vuelve a ejecutar Actions. Se canceló la compilación para no generar otro APK desconectado."
    )
}

logger.lifecycle("Configuración de Supabase detectada correctamente (clave pública de ${supabaseAnonKey.length} caracteres).")
if (googleWebClientId.isBlank()) {
    logger.warn(
        "GOOGLE_WEB_CLIENT_ID no está configurado. El APK compilará, pero el acceso nativo con Google " +
            "mostrará una instrucción de configuración hasta que agregues ese valor."
    )
}

android {
    namespace = "com.ganageo.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.ganageo.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 71
        versionName = "0.24.0"

        buildConfigField("String", "SUPABASE_URL", quoted(supabaseUrl))
        buildConfigField("String", "SUPABASE_ANON_KEY", quoted(supabaseAnonKey))
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", quoted(googleWebClientId))
        buildConfigField("String", "SUPPORT_EMAIL", quoted(supportEmail))
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file(debugKeystorePath)
            storePassword = debugKeystorePassword
            keyAlias = debugKeyAlias
            keyPassword = debugKeyPassword
        }
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(releaseKeystorePath)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        debug {
            // Evita que Gradle firme con una clave distinta a la mostrada por GitHub Actions.
            signingConfig = signingConfigs.getByName("debug")
        }

        release {
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            }
            // R8 queda apagado hasta probar la versión de tienda en un equipo real:
            // pdfbox, ML Kit y la serialización necesitan reglas verificadas.
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += setOf(
            "/META-INF/{AL2.0,LGPL2.1}",
            "META-INF/INDEX.LIST",
            "META-INF/io.netty.versions.properties"
        )
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.09.01"))
    androidTestImplementation(platform("androidx.compose:compose-bom:2025.09.01"))

    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.core:core-ktx:1.17.0")
    // Logo al abrir la app (Android 6 a 16) en vez de pantalla vacía.
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.navigation:navigation-compose:2.9.5")
    implementation("androidx.datastore:datastore-preferences:1.1.7")
    implementation("androidx.documentfile:documentfile:1.1.0")

    implementation("androidx.credentials:credentials:1.5.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.5.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.2.0")

    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.zxing:core:3.5.4")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation(platform("io.github.jan-tennert.supabase:bom:3.6.0"))
    implementation("io.github.jan-tennert.supabase:auth-kt")
    implementation("io.github.jan-tennert.supabase:postgrest-kt")
    implementation("io.github.jan-tennert.supabase:functions-kt")
    implementation("com.android.billingclient:billing:8.3.0")
    // Calificación dentro de la app (Google Play In-App Review).
    implementation("com.google.android.play:review:2.0.2")
    // Instala los perfiles de arranque que ya traen Compose y AndroidX (abre y desliza más fluido).
    implementation("androidx.profileinstaller:profileinstaller:1.4.1")
    implementation("io.ktor:ktor-client-okhttp:3.4.3")

    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
}
