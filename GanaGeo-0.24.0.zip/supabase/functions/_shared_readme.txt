Edge Functions de Gana Geo
- verify-play-purchase: valida compras de Google Play y acredita créditos UNA vez.
- play-rtdn: recibe avisos de Google (reembolsos/anulaciones) y retira créditos no usados.
Secretos necesarios (Supabase > Edge Functions > Secrets): ver GUIA_PASOS_MANUALES.txt
